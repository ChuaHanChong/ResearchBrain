# Section: notation

A full page (and the same content in the app bar's Notation drawer).

- **Symbol anatomy strip at the top:** the book's central equation (RL: the TD error; MARL: the joint-action value update; MR: the product of exponentials) broken into braced parts with plain-language labels (`.sb-anatomy`).
- **Notation sheet:** `NotationSheet` in the book's own notation-table order, filterable by kind (sets, random variables, functions, parameters, agents, frames), searchable, with the first-use `.sb-ref`.
- **Live linking:** hovering a row lights that symbol in the anatomy strip and anywhere else on the page; hovering a symbol in any topic lights its row in the open drawer.
- **Per-site:** RL and MARL use their books' Summary of Notation tables (MARL: pp. xiii–xvi); MR adds a Notation page built from Appendix A and the book's chapter definitions. MR currently has none.
