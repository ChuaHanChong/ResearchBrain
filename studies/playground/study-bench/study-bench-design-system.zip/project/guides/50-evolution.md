# Section: Evolution and Compare (two pages, two purposes)

**Evolution (`#evolution`) — learn the story.** How each method changed one thing about an earlier one, in the book's order. All views follow one selected method.
1. **Lineage:** `LineageMap`, columns by chapter, an arrow wherever a method changes one thing about its parent, with a two-line **How to read this map** and a legend. The selected method's detail shows the problem it fixes, what changed from its parent, its update equation with a symbol key, and its § reference. The toolbar holds **Compare with parent →** and the "Selected: …" count.
2. **Story:** `StoryMode`, a 6–12 step filmstrip of picture cards (problem → change → result), visually distinct from the map, controls in the toolbar; it moves only when the learner presses Next or Play.
3. **Equation changes:** `EquationLineage` from the root to the selected method; each step is diffed (`sb-new`, `sb-chg`) and names the one idea that changed.
4. **Check yourself — "What changed?":** a 3-question quiz on what changed between named methods.

**Compare (`#compare`) — choose between methods.** A tool you use, not a story.
1. **Side by side:** `SideBySide` for any number of methods on aligned rows; the odd cell in each row is highlighted; each column has **See its lineage →**.
2. **Master table:** `MasterTable` of every method: sortable, property filters, search, sticky first column, ●/○ with text alternatives; each row has **Add to side by side**.
3. **Race:** a comprehensive experiment: every method the site can run on the book's task, ≥ 20 seeded runs each, mean with a shaded 95% band, a sortable results table (final performance, area under the curve, steps to a threshold, rank), parameter controls where the book varies them, and a methods note (task, runs, parameters, seeds, what "performance" means, book reference; says if precomputed).
4. **Decision guide:** `DecisionGuide` ("Which method should I use?"); questions are about the problem, leaves open this site's methods and topics.
5. **Check yourself — "Tell them apart":** a 2–3 question quiz on telling methods apart.

Both pages use only the site's own book: no roots or nodes linking to other sites. MR uses the same pages for its algorithms (IK methods, planners, controllers) with the family switch in each section's toolbar.
