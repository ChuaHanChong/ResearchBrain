# Section: the TL;DR page (the whole book in animated pictures)

A ninth page, **TL;DR** (`#tldr`), second in the nav after Overview. It gives the big picture of the book in one sitting: a single scrolling page partitioned into sections, each an **animated visual guide** (AnimatedGuide) beside a **short TL;DR** (TldrSection). It is watched, not operated. For hands-on work it links into the Topic Explorer and the Lab.

## Structure
1. **Page head:**
   - eyebrow "N sections · about M min" (M ≈ sections × 40 s), h1 "TL;DR" and a lede of one sentence;
   - a PageGuide with three steps: "Scroll: each picture plays by itself" · "Read the TL;DR beside it" · "Go deeper on any section";
   - the **Pause animations** toggle;
   - the **section map** (`ol.sb-tldr-map`).
2. **Parts** (`section.sb-sec.sb-tldr-part`, a sec-head only: eyebrow, h2, lede): 2–4 parts that follow the book's own division. Each part has 2–6 sections, and the section titles are h3.
3. **Sections** (`section.sb-tldr`): one big idea each, picture and text alternating sides. How many depends on the book: as many as it has big ideas, no padding.
4. **Recap** (last section): "The whole book in one picture". An animated map lights the sections in order and draws how they connect. Its TL;DR is 3 lines.
5. Page pager.

## Motion
- **Tokens:** `dur-beat` 1800ms per beat, `dur-draw` 900ms, `ease-anim` cubic-bezier(.65,0,.35,1). Loops after a 2.2 s hold.
- **Motion carries meaning:** things that move are quantities flowing (a reward travelling back, a gradient step, a twist), things that draw are relationships appearing, things that pulse are what to look at now. Nothing moves for decoration.
- **Accessibility:**
  - Only the figure in view animates. The page's Pause toggle stops all of them and is remembered (WCAG 2.2.2).
  - prefers-reduced-motion and print show the finished picture with the numbered steps.
  - Every figure has an accessible name, and its caption track is real text.

## Visual vocabulary (per site, the same on every section)
- **RL:**
  - the agent (rounded box, `data-2` edge) and the world (rounded box, `data-3`), the gridworld, value bars (`q-value`), reward coins (`q-reward`), policy arrows (`q-policy`);
  - backup diagrams (open state circle, filled action dot), traces (`q-trace`), model (`q-model`).
- **MARL:**
  - agents as numbered discs (`agent-1`, `agent-2`, `agent-3`), the joint action as two arrows meeting, the payoff matrix with cells lighting;
  - equilibrium as a green ring (`equilibrium`), Pareto frontier (`pareto`), the centralized critic as a dashed box over the agents.
- **MR:**
  - the planar arm with orange links (`robot-body`), frames as RGB = XYZ axes (`frame-x/y/z`), the screw axis as a violet line with its twist arrow (`vec-twist`);
  - wrenches (`vec-wrench`), the configuration-space dot moving on its surface, the trajectory as a drawn path.

## Writing
- Title 8 words. TL;DR sentence 30. Points: 2–3, 15 each. Remember 15. Beat captions 12, the book's terms.
- Each section has at most one equation, with EquationKey. The book's notation, own book only. Illustrative numbers are labelled.
