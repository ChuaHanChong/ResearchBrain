# Visual learning principles

These rules apply to every section on all three sites. The sites are built for a learner who understands by seeing and doing.

- **Every section has a picture that moves.** A topic section is a diagram, a chart, a step-through or a live playground, with prose around it. A section of prose alone is not allowed.
- **Show the mechanism, not its name.** Draw the arrow from estimate to target, the loop between agent and environment, the one term that changed. Never a decorative icon.
- **Link every representation.** An idea appears as a symbol, a shape in a diagram, a line of pseudocode and a curve in a chart. `StudyBench.link` lights them all at once (use `data-sym`, or `\class{sym-…}` in TeX).
- **Step, don't dump.** Derivations, algorithms and processes are step-throughs (`WorkedExample`, `Algorithm`, `FlowDiagram`, `StoryMode`): one change per step, one sentence per step, Play plus ← → by hand.
- **Same idea, same color, every site.** Quantity roles (`q-*`), agents (`agent-*`), frames (`frame-*`) and diff marks (`q-new`, `q-changed`) never change meaning.
- **Compare side by side.** Differences between methods are shown as diffs (equation lineage), aligned rows (side-by-side) or overlaid curves (race), never as two separate descriptions.
- **Everything readable without color.** Color is always paired with a label, a line style or a glyph. Every chart has a data table, and every scene has a caption.
- **Start in a working state.** Playgrounds open with a real run already drawn and a Try callout that says what to change.

## Visual weight: pictures and words in balance (v2.11)
On every page, the pictures carry about as much of the page as the words do. Measure it with `vizaudit.js`, which reports the area of pictures and of prose and the longest runs of prose with no picture between them.

- **No long walls of text.** In the Topic Explorer, at most 200 words of prose may run without a picture between them. Equation blocks don't count as pictures. A longer run gets either a picture of its mechanism, drawn from the book's own figure where there is one, or its detail folded into `details.sb-more` ("More detail"). Never pad a section with a decorative picture.
- **Topic balance.** Across a topic, picture area is at least 0.8× prose area (measured at 1280px).
- **Size tiers:**
  - **Hero figure** (`.sb-fig--hero`, the section's main explanatory picture): the full content width up to 760px, 260–480px tall, never taller than 60% of the viewport.
  - **Side figure** (`.sb-split`, picture beside text): the picture gets at least half the row (`.sb-split--fig-wide` gives it 60%). A picture squeezed into a narrow column beside a long text is the most common imbalance.
  - **Small multiples** (`.sb-multiples`): each at least 180px wide, and together they fill the row. Backup diagrams and before/after pairs use this.
  - **Playground scenes:** the canvas is as tall as its drawing needs, at most 520px at 1280px, with no empty band over 15% of its height.
  - **Concept art:** icon-sized (about 120×72). It carries no text, or text at least 11px.
- **Type in pictures:** at least 11px at 1280px and 10px at 400px, after the SVG is scaled.
- **Grids and axes** are solid hairlines. Dashes mean something: a target, a threshold, or training only.
- **Every chart** has a legend when it has two or more series, and a table view. Every SVG has `role="img"` and an `aria-label`; decorative repeats are `aria-hidden`.
