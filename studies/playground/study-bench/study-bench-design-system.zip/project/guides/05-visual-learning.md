# Visual learning principles

These rules apply to every section on all three sites. The sites are built for a learner who understands by seeing and doing.

- **Every section has a picture that moves.** A topic section is a diagram, a chart, a step-through or a live playground, with prose around it. A section of prose alone is not allowed.
- **Show the mechanism, not its name.** Draw the arrow from estimate to target, the loop between agent and environment, the one term that changed. Never a decorative icon.
- **Link every representation.** An idea appears as a symbol, a shape in a diagram, a line of pseudocode and a curve in a chart. `StudyBench.link` lights them all at once (use `data-sym`, or `\class{sym-…}` in TeX).
- **Step, don't dump.** Derivations, algorithms and processes are step-throughs (`WorkedExample`, `Algorithm`, `FlowDiagram`, `StoryMode`): one change per step, one sentence per step, Play plus ← → by hand.
- **Same idea, same color, every site.** Quantity roles (`q-*`), agents (`agent-*`), frames (`frame-*`) and diff marks (`q-new`, `q-changed`) never change meaning.
- **Compare side by side.** Differences between methods are shown as diffs (equation lineage), aligned rows (side-by-side) or overlaid curves (race), never as two separate descriptions.
- **Everything readable without color.** Color is always paired with a label, a line style or a glyph. Every chart has a data table, and every scene has a caption.
- **Start in a working state.** Playgrounds open with a real run already drawn and a Try callout that says what to change.
