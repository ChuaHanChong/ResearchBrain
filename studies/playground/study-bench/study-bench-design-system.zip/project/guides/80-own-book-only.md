# Section: each site uses only its own book

- **Content:** every sentence, example, figure, equation, symbol, term and quiz on a site comes from that site's book (Study Bench · Reinforcement Learning: Sutton & Barto; Study Bench · Multi-Agent RL: Albrecht, Christianos & Schäfer; Study Bench · Modern Robotics: Lynch & Park). Cite it with a `.sb-ref` chip.
- **No cross-book parts:** no symbol concordance, no CrossLink cards, no links to the other sites, no "the other book calls this…" notes. Where a book defers to another text, say what this book says ("The book reviews single-agent RL in Chapter 2").
- **Other authors:** named only where the site's own book cites them.
- **Check:** the shell checker fails on links to the other sites and on cross-book blocks, and lists every mention of another book's authors or title for review.
