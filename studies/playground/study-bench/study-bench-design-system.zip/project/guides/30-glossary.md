# Section: glossary

Three views of one data set (`{id, name, sym, def, ref, part, uses:[ids], showMe}`):

- **Drawer:** the `Drawer` list, searchable and filterable by part, with each term's definition, symbol, `.sb-ref`, "Show me" (opens the lab on a demo) and "Open topic".
- **Glossary map:** `GlossaryMap` with terms in columns by the book's parts and arrows for "defined using". Hover shows what a term needs and what builds on it; click opens the drawer card.
- **Inline:** `TermHover` cards on the first use of a term in each section.

"Show me" runs a `GuidedTour` step in the lab that spotlights where the term lives in the scene. The same data feeds `Search`.
