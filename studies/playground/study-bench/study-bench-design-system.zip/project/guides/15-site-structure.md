# Site structure: the eight pages

Every Study Bench site has the same eight pages, with the same names, in the same order, and the same PageShell layout. Only the content differs, and it comes only from that site's own book.

| # | Page | id | Purpose | Sub-tabs (in order) |
|---|---|---|---|---|
| 1 | Overview | `#overview` | Where am I, what next: Continue, ways to study, course map, chapter summaries. | — |
| 2 | Topic Explorer | `#explorer` | Learn one book idea per page, in the book's order. | — (TOC on the left) |
| 3 | Evolution | `#evolution` | **Learn the story:** how each method changed one thing about an earlier one. Ends with a "What changed?" check. | Lineage · Story · Equation changes |
| 4 | Compare | `#compare` | **Choose:** line up any number of methods, filter all of them, race them, pick one. Ends with a "Tell them apart" check. | Side by side · Master table · Race · Decision guide |
| 5 | Interactive Lab | `#lab` | Run every method on one bench, with a demo for each. | One per lab world (site-specific) |
| 6 | Reference | `#reference` | Look things up fast. | Formula sheet · Review cards · Differences from the book |
| 7 | Glossary | `#glossary` | Every key term shown in a picture. | Visual · Map · A–Z |
| 8 | Notation | `#notation` | Every symbol, read aloud, with its anatomy. | — |

## Rules
- Labels, ids and order are fixed. Old ids redirect: `#home`/`#path` → Overview, `#chapters`/`#topics` → Topic Explorer, `#lineage` → Evolution, `#decide` and `#reference/decide` → Compare, `#machine`/`#playground` → Interactive Lab, `#formulas` → Reference.
- Evolution and Compare link to each other: a selected method on Evolution has **Compare with parent →** (a `.sb-btn` in the section toolbar, before the "Selected: …" count); Master table rows have **Add to side by side**; side-by-side columns have **See its lineage →**.
- Every page ends with a page pager (`nav.sb-pager.sb-page-pager`): ← previous page · Next: next page →.
- Deep links: `#explorer/<topic>`, `#evolution/<tab>`, `#compare/<tab>`, `#lab/<world>`, `#reference/<tab>`, `#glossary/<term>`, `#notation/<symbol>`.
- A site whose book lacks a sub-tab's material omits that sub-tab; it never fills it from another book.

## Each site uses only its own book
- No links to the other sites, no cross-book cards, no symbol concordance, no "in the other book" notes.
- Other authors are named only where the site's own book cites them.

## Every interactive section gets a demo
- A `▶ Watch demo` and `Guide me` pair (`.sb-demo-launch`) is the last item of the section head. 4–8 steps. Watch performs each action and narrates; Guide me turns each action into a task and waits.
- The first launcher on each page carries the "New here? Press Watch demo." hint (`StudyBench.demoHint`).

## Key-term notes everywhere
- One term dictionary per site feeds the Glossary (visual, map, A–Z), `autolink` in all prose, and Search.

## Text width
- Text is fluid: ledes, prose, captions and cards fill the column and reflow with the window. There is no fixed measure.
