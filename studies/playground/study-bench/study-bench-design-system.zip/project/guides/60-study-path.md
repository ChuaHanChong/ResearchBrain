# Section: study path and progress

- **Course map** on each home page, under the hero: `CourseMap` with every topic, its prerequisites and progress. Its edges must match each topic's Builds on list.
- **Progress:** `StudyBench.progress("<site>", ids)` drives the TOC checks, the course map and the meter from the same per-browser state. It works when storage is blocked; progress just isn't kept.
- **Outcomes and takeaways** on every topic (see the topic page section).
- **Review:** `Flashcards` beside every quiz, plus one "Review all" deck on the home page built from every topic's cards.
- **Resume:** the home page's "Continue: <topic>" button opens the first topic that isn't marked understood.
