# Writing, notation and terminology

These rules apply to every word and every equation on the three sites. Check against them before publishing.

## Word limits

Limits are maximums. Shorter is better when nothing is lost. A text that needs more words is split into steps, cards or a figure.

| Text | Limit |
|---|---|
| Hero lede | 40 words |
| Topic lede (under the topic title) | 25 words |
| Orientation: Why this exists | 60 words |
| Orientation: each outcome | 15 words, 3–5 outcomes |
| Concept card definition | 20 words |
| Paragraph of running prose | 80 words |
| Running prose per topic section | 200 words |
| Running prose per topic, excluding figures, tables and quizzes | 900 words |
| Figure caption | 35 words |
| Step text (worked example, algorithm, flow, story) | 30 words per step |
| Callout (Try, Note, Takeaway, Differs from the book) | 40 words |
| Takeaway | 25 words each, 3–5 per topic |
| Quiz question / option / explanation | 25 / 12 / 40 words |
| Flashcard front / back | 15 / 30 words |
| Glossary definition / hover card | 35 / 25 words |
| Tour step | 35 words |
| Decision guide question / result reason | 15 / 25 words |
| Methods table "What it's for", side-by-side cell, equation-lineage step | 12 words |
| Button label / tab / eyebrow | 3 / 2 / 6 words (the hero eyebrow that cites the book: 12) |

## Notation

- **Use the book's notation, exactly, on that book's site.** Study Bench · Reinforcement Learning writes Sₜ, Aₜ, Rₜ₊₁ with subscript time. Study Bench · Multi-Agent RL writes sᵗ, aᵗ, rᵗ with superscript time and agent subscripts (aᵢ). Study Bench · Modern Robotics writes θ, T_sb, 𝒱, 𝒮 as Lynch & Park do. Never convert one book's notation into another's, and never mention another book's notation.
- **One form per block.** Numbered equations use the book's time-indexed form, such as Eq. 6.2 with V(Sₜ). Pseudocode, methods tables, target columns and the lab's update tokens use the book's pseudocode form, such as R + γV(S′). Never mix the two forms inside one equation, table or step-through.
- **True values and estimates stay distinct.** In RL, v_π, q_π, v_*, q_* are true value functions; V and Q are estimates. Random variables are uppercase and their values lowercase, as in the book.
- **Every symbol has one meaning per site and one `data-sym` id**, listed in that site's Notation sheet. A symbol used in an equation but missing from the sheet is a bug.
- **Equation numbers and references follow the book.** Use `(6.2)` beside an equation (`.sb-eq-no`) and `Eq. 6.2`, `§6.4`, `Fig. 4.1`, `Ex. 6.6` in chips and text.
- **Typeset site math with MathJax.** Unicode subscripts (Sₜ, Rₜ₊₁) are only for readouts, chips, buttons and canvas labels, and they must match the typeset form.
- **Vectors and matrices follow the book's type style**, such as bold **w** and **x**(s) in RL Chapter 9 or [Ad_T] in MR.

## Terminology

- **Use the book's term for every concept.** When the three books name the same idea differently, each site uses its own book's term. Don't give the other books' names for it.

| Idea | Study Bench · Reinforcement Learning (Sutton & Barto) | Study Bench · Multi-Agent RL (Albrecht et al.) | Study Bench · Modern Robotics (Lynch & Park) |
|---|---|---|---|
| α | step-size parameter | learning rate | — |
| γ | discount rate | discount factor | — |
| transition model | dynamics p(s′, r \| s, a) | state transition function T, reward function R | — |
| the policy that generates the data | behavior policy b | check in the book | — |
| return | return Gₜ | discounted return u; expected return U | — |
| network or policy weights | weight vector **w**; policy parameter θ | value parameters θ; policy parameters ϕ | — |
| joint variables | — | — | joint angles θ (joint variables) |
| velocity and force of a rigid body | — | — | twist 𝒱, wrench ℱ |

- **Define on first use.** Every technical term gets a hover card (`TermHover`) at its first use in each section, with the book's definition in 25 words or fewer.
- **Spell out abbreviations once per topic:** temporal-difference (TD), dynamic programming (DP), Monte Carlo (MC), importance sampling (IS), centralized training with decentralized execution (CTDE), degrees of freedom (dof).
- **Avoid jargon the book doesn't use.** Terms such as rollout buffer, SOTA, loss landscape and ablation don't appear unless the book uses them, and then only with a definition.
- **Plain words in the interface.** Controls and labels say what happens ("Run 500 episodes", "Show the equations") and never name internals ("engine", "rack", "bench state", "spotlight").
- **No filler:** avoid "simply", "just", "obviously", "clearly", "basically", "leverage", "utilize", "robust", "powerful" and "seamless".
- **American spelling, as in all three books:** behavior, color, center, modeling, labeled.

## Checking

Run `StudyBench.audit()` in the browser console on every page before publishing. It lists each element over its word limit, including hidden step texts. The list must be empty.
