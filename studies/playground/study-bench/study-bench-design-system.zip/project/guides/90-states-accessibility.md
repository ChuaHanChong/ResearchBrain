# Section: states, mobile and accessibility

- **States:** every panel has loading (`.sb-skel`, "Typesetting equations…"), empty (`.sb-empty` with one action), running, paused and error (`.sb-live`), and failure (`.sb-error` saying what to do). Never show `NaN`, `undefined` or a blank canvas.
- **Figures:** every canvas or SVG sits in a `figure` with a `figcaption` that states what it shows. `LineChart` and `GridWorld` include keyboard reading and a data table. Diagrams get `role="img"` and an `aria-label`.
- **Keyboard:** every hover interaction also works on focus: linked highlighting, term cards, DAG nodes, grid cells and chart crosshairs (← →). Steppers take ← →, flashcards take Space, search opens with Ctrl/⌘ K and closes with Esc, and tours close with Esc.
- **Motion:** Play and animated tokens respect `prefers-reduced-motion` (they jump instead of animate).
- **Mobile (< 960px):** the TOC becomes a Topics select (`.sb-mobile-toc`), benches stack to one column, tables and maps scroll inside `.sb-scroll-x`, and targets stay ≥ 32px. The page never scrolls sideways at 400px.
- **Color:** data colors are for marks only. Text stays in ink, and every color meaning has a word, line style or glyph beside it.
- **Touch:** nothing depends on hover. Tap pins linked highlights and opens term cards (tap again or Escape to close), tap selects map nodes, and dragging moves the chart crosshair. On `pointer: coarse` screens, controls grow to 44px and hover fills are switched off.
- **Keyboard:** a skip link comes first on every page. Segmented controls are one Tab stop with arrow keys. Maps move with arrow keys, select with Enter and clear with Escape. Drawers trap focus and return it on close. Answering a quiz question moves focus to its explanation.
- **Chart legends** are buttons that hide or show a series without changing any colors.
