# Section: reference tools

- **Formula sheet:** `FormulaSheet` with every numbered equation in book order: toolbar with search, count and chapter chips; cards with the equation number, § chip, Open topic → and Copy TeX.
- **Review cards:** `Flashcards` with decks in the toolbar (Key terms · Equations · Concepts, as the site has them).
- **Differences from the book:** `DiffLedger`, one page listing every `.sb-prov` and `.sb-callout--differs` on the site, each row linked back to where it appears.
- **Search:** `Search` (Ctrl/⌘ K) over topics, methods, terms, symbols and formulas, with the button in the app bar.
- The Decision guide lives on the Compare page. There is no cross-book table: each site uses only its own book.
