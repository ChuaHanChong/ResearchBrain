# Section: the interactive lab (all methods)

One `Bench` per site where every method in the book runs on the same machine: RL Machine (38 methods), MARL Lab (21 methods, three worlds) and Robot Lab (193 terms on one mobile manipulator).

- **Bench bar:** monogram, lab name, world or mode `Segmented`, Tours, Glossary.
- **Left column:** `MethodRack` grouped by family, the same families and order as the evolution map. MR's Robot Lab uses the glossary term list here instead.
- **Center:** the world scene (canvas or SVG on `surface`), `Trajectory` strip, transport and `.sb-live` status, and the `LineChart` learning curve under the scene.
- **Right column:** `UpdateEngine` with live token values and "changed vs base" marks, the method card (`BackupDiagram`, what changed, `.sb-ref`, `.sb-prov` for simplifications), and the glossary panel.
- **Guidance:** `GuidedTour` missions (3–8 steps each) and "Show me" from any glossary term. Deep links select method, world and tour (`#m-<method>-w-<world>`, `#tour-<id>`).
- **Themes:** the bench follows light and dark. Canvas colors come from `StudyBench.palette()` and redraw in `StudyBench.onThemeChange`.
