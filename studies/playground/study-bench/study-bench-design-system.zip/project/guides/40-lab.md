# Section: the interactive lab (all methods)

One `Bench` per site where every method in the book runs on the same machine: RL Machine (38 methods), MARL Lab (21 methods, three worlds) and Robot Lab (193 terms on one mobile manipulator).

- **Bench bar:** monogram, lab name, subtitle, `.sb-prov` on the left; status, **Tours ▾**, **On this bench** on the right (identical on all three sites). World or mode switches sit on the left or in the bench.
- **Left column:** `MethodRack` grouped by family, the same families and order as the evolution map. MR's Robot Lab uses its term list here to drive the robot (name and § only, no definitions).
- **Center:** the world scene (canvas or SVG on `surface`), `Trajectory` strip, transport and `.sb-live` status, and the `LineChart` learning curve under the scene.
- **Right column:** `UpdateEngine` with live token values and "changed vs base" marks, the method card (`BackupDiagram`, what changed, `.sb-ref`, `.sb-prov` for simplifications). No glossary panel.
- **Two purposes, split:** the Glossary page teaches the words (definitions, pictures, map, A–Z); the Lab shows them at work. **On this bench** (`BenchTerms`) lists only the terms visible now, grouped by where they are, with what to watch, a live value, Point to it and Definition ↗. The Glossary page's Show in Lab ▶ opens the Lab with the panel pointing at that term.
- **Guidance:** `GuidedTour` tours from **Tours ▾** (3–8 steps, Look at → Run it ▶ → Notice, Back / Next only), never the site tour. Deep links select method, world and tour (`#m-<method>-w-<world>`, `#tour-<id>`).
- **Themes:** the bench follows light and dark. Canvas colors come from `StudyBench.palette()` and redraw in `StudyBench.onThemeChange`.
