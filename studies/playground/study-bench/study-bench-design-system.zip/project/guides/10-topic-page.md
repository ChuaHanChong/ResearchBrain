# Section: topic explanations

Every topic on every site uses the same sequence (see the `TopicPage` template).

1. **Topic head:** `eyebrow` (part · chapter · name), `display-l` title with the topic number, `lede`, chips (`.sb-ref` section range, playground count, quiz count).
2. **Orientation:** `Orientation` with Why this exists, After this you can (3–5 testable outcomes) and How it connects (Builds on / Leads to). Optionally add a "Where it fits" mini `CourseMap` with only the neighbouring topics.
3. **Key concepts:** `ConceptCards`, each with a small mechanism drawing and a link to where it's shown working.
4. **Where it happens:** a `FlowDiagram` of the process the topic changes (the agent–environment loop, GPI, the robot control loop, the MARL learning process), walked through step by step.
5. **Worked example:** a `WorkedExample` stepper with real numbers, synced to a picture.
6. **The rule:** the `Equation` diffed against its predecessor, with `LinkedHighlight` across the equation, `BackupDiagram` and `Algorithm`, and the `SymbolAnatomy` parts of `NotationSheet` for any new symbol.
7. **Playgrounds:** `Panel`s with live scenes, `LineChart` / `GridWorld` / `PayoffMatrix`, a `Try` callout, `Controls` and `States`. Book deviations go in `.sb-callout--differs`.
8. **Methods table:** `MethodsTable` with Compare ↗ and Run ▶ into the evolution page and the lab.
9. **Close:** `Takeaways`, then `Quiz` (`StudyBench.quiz`) with a Flashcards switch (`Flashcards`), then Mark as understood (`Takeaways` + `StudyBench.progress`), then the Previous / Next `TopicPager`.

Every `h2` and `h3` carries an `.sb-anchor` link so a learner can share any section. The TOC starts with a Continue button for the first topic not yet understood.

Terms in the prose use `TermHover`. No links or comparisons to the other books or sites.
