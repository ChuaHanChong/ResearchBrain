Study Bench is the shared design language for the three textbook companions: **Study Bench · Reinforcement Learning** (Sutton & Barto), **Study Bench · Multi-Agent RL** (Albrecht, Christianos & Schäfer) and **Study Bench · Modern Robotics** (Lynch & Park). Each site reads a book one mechanism at a time: prose in the book's notation, an equation, a playground you can run, a self-check. The system exists so the three look like one shelf. Only the book's name, its monogram and its content differ.

## Naming

- One family, one pattern: **Study Bench · <subject>**. Titles: Study Bench · Reinforcement Learning, Study Bench · Multi-Agent RL, Study Bench · Modern Robotics. Files: `study-bench-rl.html`, `study-bench-marl.html`, `study-bench-robotics.html`. This system: Study Bench Design System.
- App bar brand: the monogram (RL, MA, MR), then "STUDY BENCH" in small mono caps over the subject (`.sb-brand-family` + subject in `.sb-brand-name`).
- Browser tab title: "<Page> · Study Bench · <subject>"; on Overview just "Study Bench · <subject>".

## Content fundamentals

- Write like a patient teaching assistant: plain, specific, second person ("Press Step and watch δₜ change sign"). Use short sentences, no hype, no exclamation marks and no emoji.
- Keep within the word limits in "Writing, notation and terminology" (for example: hero lede 40 words, caption 35, step text 30, prose per topic 900). A text that needs more words becomes steps, cards or a figure.
- **Each site uses only its own book.** No content, symbols, examples, links or comparisons from the other books or sites. Other authors appear only where the site's own book cites them.
- Use each book's notation and terms exactly on its own site. RL writes Sₜ, Rₜ₊₁ and "step-size parameter"; MARL writes sᵗ, rᵗ and "learning rate"; MR writes θ, 𝒱, T_sb. Don't mix a numbered equation's time-indexed form with the pseudocode form (S, R, S′) in one block.
- Every equation is self-contained: an **In words** line and a symbol key (EquationKey) sit under it, so no symbol needs a lookup elsewhere.
- Cite as `Ch 6 · §6.4`, `Eq. 6.2`, `Fig. 4.1`, `Ex. 6.6`, always in a `.sb-ref` chip; put `(6.2)` beside the equation itself.
- Say where things come from. Anything not from the book carries a `.sb-prov` badge ("Not in the book", "Our choice: κ = 0.001", "Simplified: tabular", "Illustrative"). Numbers that differ from the book get a `.sb-callout--differs` with both values.
- Define every technical term at its first use in a section (`TermHover`), and spell out abbreviations once per topic. Avoid jargon the book doesn't use.
- Sentence case everywhere: titles, buttons, tabs. Uppercase only for `eyebrow`, `readout` keys and `.sb-eq-k`, which are set in the mono face with tracking.
- Captions say what to look at, not what the widget is: "Dashed = true q*(a). The ▲ marks the greedy action."
- Button labels are verbs: Run, Step, Run 50 episodes, Reset, Start story, Show in the lab.
- Placeholders before a run are `–`. Never show `NaN`, `undefined` or a fake 0.
- Use American spelling, as all three books do.

## Visual foundations

### Color

- One accent, `accent` (petrol), for every site. It marks what you can act on: primary buttons, links (`link`), the current TOC number, slider thumbs, the Interactive eyebrow, the focus ring (`focus`), and new terms in an equation diff (`q-new`). Nothing decorative is accent.
- Grounds, lightest to deepest in light theme: `surface` (panels, cards) on `paper` (page), with `surface-sunk` for wells inside a panel and `surface-strong` for hover. Lab scenes sit on `bench`.
- Text: `ink` for content, `ink-2` for secondary copy, `ink-3` for metadata only. All three pass 4.5:1 on `paper`, `surface` and `surface-sunk` in both themes.
- The highlighter `hl` (with `hl-ink`) is the one flourish: one phrase in each hero, the glossary search match, and the term a guided tour points at. Never a panel fill.
- Semantic colors `good`, `bad`, `warn` (each with a `-soft` ground) mean correct, wrong and caution. Always pair them with a word or ✓ / ✗.
- Data: `data-1` … `data-7` in that order for categorical series; they are validated as a set (adjacent pairs, color-blind and normal vision, both themes) and are for **marks only**: lines, bars, dots, fills, swatches. Labels and values stay in `ink`, `ink-2`, `ink-3`. Draw charts on `surface`, never on `surface-sunk`. `data-8` is not a slot: it means Other, baseline or a grayed predecessor. An eighth series folds into Other or becomes small multiples; scatter-type charts cap at three series. Heatmaps interpolate `seq-lo` → `seq-hi`; signed values use `div-neg` · `div-mid` · `div-pos`.
- Quantity roles are aliases of the data colors, so the same idea has the same color on all three sites:
  - RL: `q-reward` gold, `q-value` blue, `q-policy` magenta, `q-ratio` green, `q-trace` violet, `q-model` orange.
  - MARL: `agent-1` blue, `agent-2` orange, `agent-3` magenta, `equilibrium` green, `pareto` violet.
  - Robotics: `frame-x` red, `frame-y` green, `frame-z` blue (the RGB = XYZ convention), `robot-body` orange, `vec-twist` violet, `vec-wrench` magenta.
  - In the lab's update engine a role colors the token's tint and underline; the token text stays `ink`.
- Equation diffs use only `q-new` (accent) and `q-changed` (violet, a text-safe step), via `\class{sb-new}{…}` and `\class{sb-chg}{…}` in TeX.

### Type

- Three faces, all on Google Fonts: **Schibsted Grotesk** (`--font-display`) for headings, **Atkinson Hyperlegible Next** (`--font-body`) for everything read, **Atkinson Hyperlegible Mono** (`--font-mono`) for numbers, references and labels-as-data. Atkinson keeps l / I / 1 and O / 0 distinct, which matters beside math.
- Scale: `display-xl` 48 (hero only) · `display-l` 32 (topic title) · `heading` 22 · `subheading` 16 (panel titles) · `lede` 18 · `body` 16/26 · `body-s` 14 · `label` 13 · mono `readout` 20 · `mono` 13 · `eyebrow` and `ref` 12. No other sizes.
- Text width is fluid: prose, ledes and captions fill their column and reflow with the window (no fixed measure). Headings get `text-wrap: balance`. Digits that line up use `tabular-nums`.
- Math stays MathJax 3.2.2 `tex-svg` from cdnjs on all three sites and inherits `ink`.

### Space, layout, shape

- Spacing steps: `space-1` 4 · `space-2` 8 · `space-3` 12 · `space-4` 16 · `space-5` 24 · `space-6` 32 · `space-7` 48 · `space-8` 72. Lay out with grid/flex `gap`.
- Shell: sticky `.sb-appbar` (`appbar-h` 56px) → `.sb-toc` (`sidebar-w` 256px) beside a content column capped at `content-w` 1200px. Lab benches go full-bleed up to `bench-w` 1440px.
- Breakpoints: `bp-sm` 640 (single column, smaller display sizes), `bp-md` 960 (TOC becomes a Topics select), `bp-lg` 1200 (bench goes to three columns). Minimum gutter 16px; the page never scrolls sideways.
- Radii: `radius-xs` 3 for chips and swatches, `radius-sm` 6 for controls, `radius-md` 10 for panels. Nothing larger, and no text pills. `radius-round` only for circles.
- Borders separate things: `line` for hairlines, `line-strong` for borders that carry meaning (inputs, options, secondary buttons). Shadows only for things that float: `shadow-pop` on drawers and popovers, `shadow-seg` on the selected segment.
- Motion: `dur-fast` 120ms for hover and press, `dur-base` 200ms for drawers, `ease-out`. Simulations keep their own clocks. Honour `prefers-reduced-motion`.

### Themes

- Light and dark are both first-class, including the lab benches. A bench follows the theme like the rest of the page. It is no longer a forced dark island.
- Wire themes with the three-state pattern: the light values on `:root`, dark values under `@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) {…} }` and again under `:root[data-theme="dark"]`, with `color-scheme` set in each. `body` gets `background: var(--paper)`.
- Canvas and SVG scenes never hard-code hex. Read colors with `StudyBench.palette()` and redraw from `StudyBench.onThemeChange(cb)`.
- In dark theme `accent` lightens, so text on an accent fill is `on-accent` (dark), never literal white.

### States and focus

- Focus: 2px solid `focus` ring, 2px offset, on every interactive element, both themes.
- Selected: segmented and view switchers use `control-on` + `shadow-seg`. Current TOC item: `surface` + `line` inset + accent number. Pressed filter tags: `accent-soft` with `accent-strong` text.
- Disabled: `disabled` attribute and 45% opacity; never color alone.

## Iconography

- No icon font and no emoji. Use typographic glyphs in the mono face inside `.sb-glyph`: ▶ run, → step, ⏭ episode, ↺ reset, ↗ opens elsewhere, ✓ / ✗ feedback, ✕ close, · separators.
- Book monograms replace logos: `.sb-mono-mark` with RL, MA or MR, `ink` square with `paper` letters.
- Diagrams are inline SVG or canvas drawn with the role colors, 1.5px strokes, labels in `body-s` or `ref`.

## Components

- **Shell:** PageShell (one layout for every page of every site), ReturnNav (jumps you can undo), AppBar (the seven pages), TopicNav, Hero, and the TopicPage template (the order every topic follows). See the guide "Site structure: the seven pages".
- **Actions:** Button, Segmented, Controls.
- **Labels:** Chips (`.sb-ref`, `.sb-tag`, `.sb-prov`).
- **Containers:** Panel, Bench, Drawer.
- **Diagrams:** LinkedHighlight, EquationKey (words line + symbol key under every equation), FlowDiagram, BackupDiagram.
- **Charts:** LineChart, GridWorld, PayoffMatrix, Legend, Readout.
- **Topic page:** Orientation, ConceptCards, WorkedExample, Algorithm, Equation, MethodsTable, Callout, Quiz, Takeaways, TopicPager.
- **Notation & glossary:** NotationSheet (with symbol anatomy), TermHover, KeyTermNotes (autolink), VisualGlossary, GlossaryMap.
- **Lab:** MethodRack, UpdateEngine, Trajectory, GuidedTour, DemoMode (Watch and Guide me).
- **Evolution** (how methods grew): LineageMap, StoryMode, EquationLineage. **Compare** (choose between methods): SideBySide, MasterTable, race, DecisionGuide.
- **Study path:** Overview (chapter summaries), PageGuide (how to use this page, in three steps), CourseMap, Flashcards.
- **Reference:** FormulaSheet, Flashcards, DiffLedger, Search.
- **States:** States (loading, empty, running, paused, error).

All of them are CSS classes in `components/bundle.css` (prefix `sb-`) plus the engines in `components/bundle.js` (`window.StudyBench`): `link`, `stepper`, `flow`, `dag`, `lineChart`, `grid`, `table`, `terms`, `autolink`, `demo`, `visualGlossary`, `quiz`, `drawer`, `flashcards`, `decide`, `search`, `tour`, `progress`, `audit`, `themeToggle`, `demoHint`, `returnNav`, `facetCounts`, `cardLinks`, `anatomyJump`, `flash`, `palette`, `onThemeChange`. Every interaction works with mouse, keyboard and touch; nothing depends on hover alone. No framework is required. The guide sections that follow the brand book give the blueprint for each part of a site: the topic page, notation, glossary, lab, evolution, study path, reference tools, the own-book rule, and states and accessibility.

Each site is one self-contained HTML file. Paste the token block and `bundle.css` into its `<style>`, and inline `bundle.js` before the site's own script.
