# LineageMap

How every method grew out of an earlier one. Columns follow the book's chapters; arrows point from a method to the ones built on it. Hover to trace a method's ancestry (solid) and descendants (dashed); click to select it for the equation lineage and side-by-side.

## Consumer provides
- `StudyBench.dag(host, {cols, nodes, edges, onSelect, selected})`; node `sub` = the chapter or section.
- `onSelect` updates `EquationLineage` and adds the method to `SideBySide`.
- Keyboard: Tab into the map, arrow keys move between methods, Enter selects, Escape clears. Touch: tap selects; tap the background to clear.
- Methods from another book shown as grayed starting points get `state: "muted"` in the node class (`is-muted`).

## Rules
- Families are columns and labels, not colors: the map uses neutral boxes and the accent for the selected path only.
- Keep every edge meaningful: "B changes one thing about A".
