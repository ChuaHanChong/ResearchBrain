# Trajectory

The run's trajectory as a strip (S₀, A₀, R₁, S₁, …) with the current step outlined and future steps faded, plus the transport controls and a live status line.

## Consumer provides
- `.sb-traj` of `.sb-traj-cell` (value + `<small>` label), `--c` set to the role (`q-policy` for actions, `q-reward` for rewards, neutral for states), `.is-now` on the current cell, `.is-future` on planned ones (n-step, MCTS rollouts); future cells get a dashed outline and stay readable.
- `.sb-transport`: Run (primary) / Step / Episode / Reset, a speed `.sb-seg--sm`, and `.sb-live` with `.is-running`, paused (default) or `.is-error`.

## Rules
- The strip scrolls inside itself and auto-scrolls to keep `.is-now` visible.
- The live line always says where the run is: `Running · episode 12 · step 7`.
