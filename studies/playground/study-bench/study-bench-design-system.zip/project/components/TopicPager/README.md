# TopicPager

Navigation around a topic: a Continue card at the top of the topic list (the first topic not yet marked understood), a heading anchor for sharing a link to any section, and Previous / Next topic cards at the end of every topic.

## Consumer provides
- `.sb-toc-resume` at the top of the TOC with "Continue: <topic>" as a `.sb-btn--primary`, driven by `StudyBench.progress`.
- `<a class="sb-anchor" href="#id" aria-label="Link to this section">#</a>` inside each `h2`/`h3`; it shows on hover or focus and is always visible on touch screens.
- `nav.sb-pager` after Mark as understood, with `a` (`.sb-pager-k` "Previous" / "Next", `.sb-pager-t` title with number) and `.is-next` on the next link.

## Rules
- Every topic ends with the pager, so a learner never has to scroll back up to move on.
- The sticky app bar never covers a linked heading: `[id]` targets get `scroll-margin-top`.

## Word limits
- Pager title: the topic's TOC title. Continue label 4 words.
