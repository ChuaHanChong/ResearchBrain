# Panel

The container for every playground, diagram, table and bench module.

## Consumer provides
- `.sb-panel-head`: a kind label in `.sb-eyebrow` (Interactive, Diagram, World, Agent, Update engine, Table), the title in `.sb-panel-title`, optional `.sb-panel-meta` (mono status: `block 1 · 0/100`, `10 estimates · one state`).
- `.sb-panel-body`: the scene, canvas or table, then a `.sb-caption` that says what to look at.
- Optional `.sb-panel-foot`: controls (buttons, fields, status line).

## Rules
- Use `.sb-eyebrow--live` (accent) only for panels you can run or drag.
- Panels have borders, not shadows, and never nest a bordered panel inside another; inside a panel use `surface-sunk` wells.
- Wide canvases and tables scroll inside `.sb-scroll-x`, never the page.

## Word limits
- Title 8 words; caption 35 words. See "Writing, notation and terminology".
