# Drawer

Right-hand sheet for the glossary and the notation table, opened from the app bar or a bench.

## Consumer provides
- `.sb-drawer` (a `role="dialog"` with `aria-modal="true"` and a label) + `.sb-scrim` behind it.
- `.sb-drawer-head` (title, close `.sb-btn--icon`), `.sb-drawer-tools` (search `.sb-input`, filter `button.sb-tag`s), `.sb-terms` list of `.sb-term`.
- Each `.sb-term`: `.sb-term-name`, `.sb-term-sym` (the symbol, rendered as math), `.sb-term-def`, `.sb-term-links` (`.sb-ref` to the section, "Show in machine" as `.sb-btn--ghost`).

## Rules
- Width `min(420px, 100%)`, `shadow-pop`, focus trapped while open, Esc closes, focus returns to the opener.
- The search match inside a definition is marked with `.sb-hl`.

## Word limits
- Definition 35 words. See "Writing, notation and terminology".

## Engine
- `StudyBench.drawer(el, {openers: [button]})` makes the sheet modal: it opens from the app bar button, traps Tab inside, closes on Escape, the scrim or any `[data-drawer-close]`, locks page scroll while open and returns focus to the opener.
