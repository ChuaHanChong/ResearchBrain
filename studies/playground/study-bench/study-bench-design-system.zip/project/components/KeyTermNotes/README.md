# KeyTermNotes

Every key term in the prose is a link to a short note. Hover (or focus) previews it; click, tap or Enter pins it. A pinned note shows the book's definition, an extra note, the section reference, **Show me ▶** (opens the Lab or the visual glossary on that term) and **Glossary ↗**.

## Consumer provides
- One term dictionary per site: `{key: {name, aliases, sym, def, note, ref, href}}` — the same list the Glossary uses.
- `StudyBench.autolink(root, dict, {onShow})` once after render. It wraps the **first occurrence per section** of every term name or alias (plurals included), skipping headings, links, buttons, code, equations and SVG, and wires the notes. It returns `{linked, perTerm, missing}` — a coverage report: every glossary term should be linked somewhere, or be listed in `missing` on purpose.
- Hand-written `<span class="sb-term-link" data-term="…">` still works for terms whose wording differs from the name.

## Rules
- Link the first use in each section, not every use. Dotted underline, not link color.
- Every term used in the prose of a topic must be in the dictionary. Run the coverage report in review.
- Notes add something the definition doesn't: a common confusion, why the index is t + 1, how it differs from a neighbor term.

## Word limits
- Definition 35 words (hover shows ≤ 25), note 30.
