/** Study Bench engines, loaded as window.StudyBench. Components are CSS classes (prefix sb-) in bundle.css; these functions add the interaction. */
declare namespace StudyBench {
  /** Animated visual guide: figure.sb-anim with data-a parts and ol.sb-anim-beats > li beats (data-on/off/cls/move/set/text/dur). Plays in view, loops, obeys Pause and reduced motion. */
  function anim(fig: HTMLElement): { refresh(): void; reset(): void; go(beat: number): void; fig: HTMLElement };
  /** Wires every figure.sb-anim and [data-anim-toggle] (Pause animations) under root. */
  function animAll(root?: ParentNode): { pause(): void; play(): void };
  /** Lab "On this bench" panel: terms visible in the bench now, grouped by where, with watch text, live value, Point to it and Definition ↗. host gets .has-benchterms while open. */
  function benchTerms(opts: { button: HTMLButtonElement; host: HTMLElement; title?: () => string; items: () => { id: string; name: string; sym?: string; where: string; watch: string; value?: () => string; target?: () => Element | null; href?: string }[]; onPoint?: (item: object) => void }): { open(): void; close(): void; refresh(): void; panel: HTMLElement; isOpen(): boolean };
  /** Faceted filters: sets data-facet-count on every chip and data-facet-empty on chips that would give no results; call after every filter change. */
  function facetCounts(items: ArrayLike<any>, groups: { chips: ArrayLike<HTMLElement>; match: (item: any, val: string) => boolean; selected: () => string | null }[]): void;
  function returnNav(opts?: { onReturn?: (snap: { hash: string; y: number; sub: string | null; label: string }) => void }): { stack(): object[]; back(): void } | null;
  function cardLinks(root?: ParentNode, opts?: { termHref?: (conceptName: string) => string | null }): void;
  function anatomyJump(root?: ParentNode): void;
  function flash(el: Element): void;
  function themeToggle(btn: HTMLButtonElement, opts?: { key?: string; onChange?: (mode: "system" | "light" | "dark") => void }): { get(): string; set(mode: string): void };
  function demoHint(launchRow: HTMLElement, siteKey?: string): HTMLElement | null;
  type Pal = Record<string, string>;
  /** Resolved value of one token for the current theme, e.g. token("data-1"). */
  function token(name: string): string;
  /** Every color a canvas or SVG scene needs, resolved for the current theme. */
  function palette(): Pal;
  /** Calls cb now and on every theme change (OS setting or data-theme). Returns an unsubscribe function. */
  function onThemeChange(cb: (p: Pal) => void): () => void;
  /** Single selection for a .sb-seg group of buttons (aria-pressed); one Tab stop, arrow keys move. */
  function segmented(el: HTMLElement, onChange?: (value: string, button: HTMLButtonElement) => void): void;
  /** Sequential and diverging scale colors, t in [0, 1]. */
  function seq(t: number): string;
  function div(t: number): string;
  /** Linked highlighting: every [data-sym="x"] or .sym-x inside scope lights up together on hover/focus. */
  function link(scope?: HTMLElement): { light(sym: string): void; clear(sym: string): void };
  /** Step-through: root has data-steps; controls [data-act=prev|next|play|reset|scrub|goto]; [data-on="2 4-6 7+"] and [data-step-text="n"] react. */
  function stepper(root: HTMLElement, opts?: { steps?: number; interval?: number; onStep?: (i: number) => void }): { go(i: number): void; play(): void; stop(): void; readonly step: number };
  interface FlowNode { id: string; x: number; y: number; w: number; h: number; label: string; sub?: string; kind?: "agent" | "env" | "store" | "decision"; sym?: string }
  interface FlowEdge { from: string; to: string; id?: string; label?: string; sides?: [string, string]; via?: [number, number][]; dashed?: boolean; dx?: number; dy?: number }
  /** Workflow diagram with a Play / Back / Next walk-through. Step `on` lists node ids and "from>to" edge ids. */
  function flow(host: HTMLElement, spec: { w: number; h: number; title?: string; caption?: string; nodes: FlowNode[]; edges: FlowEdge[]; steps?: { on: string[]; text: string }[]; interval?: number }): { svg: SVGSVGElement; stepper?: ReturnType<typeof stepper> };
  interface DagNode { id: string; label: string; sub?: string; col: number; row: number; state?: "done" | "current" | "muted" }
  /** Layered graph for course maps, glossary maps and method lineage. Hover traces ancestors (solid) and descendants (dashed). */
  function dag(host: HTMLElement, spec: { nodes: DagNode[]; edges: [string, string][]; cols?: string[]; nodeW?: number; nodeH?: number; gapX?: number; gapY?: number; title?: string; selected?: string; onSelect?: (id: string, node: DagNode) => void }): { select(id: string): void; ancestors(id: string): string[] };
  /** Line chart with crosshair tooltip, keyboard reading, direct labels (≤4 series), legend and data table. color = token name. */
  function lineChart(host: HTMLElement, spec: { title?: string; caption?: string; height?: number; directLabels?: boolean; x: { label?: string; min: number; max: number; ticks?: number[] }; y: { label?: string; min: number; max: number; ticks?: number[]; fmt?: (v: number) => string }; series: { name: string; color: string; points: [number, number][]; dash?: boolean }[] }): { redraw(): void };
  /** Gridworld / heatmap. null values are walls. */
  function grid(host: HTMLElement, spec: { rows: number; cols: number; values: (number | null)[][]; min: number; max: number; scale?: "seq" | "div"; arrows?: string[][]; marks?: Record<string, [number, number]>; cell?: number; fmt?: (v: number) => string; label?: string; valueLabel?: string; caption?: string; showValues?: boolean }): { update(values: (number | null)[][]): void; destroy(): void };
  /** Sortable th[data-sort], filter chips [data-filter-for=id], search [data-search-for=id], count [data-count-for=id]. */
  function table(tbl: HTMLTableElement): { apply(): void; clear(): void };
  /** Hover/focus cards for .sb-term-link[data-term]. */
  interface Term { name: string; aliases?: string[]; sym?: string; def: string; note?: string; ref?: string; href?: string; viz?: string; showMe?: boolean }
  function terms(scope: HTMLElement | Document, dict: Record<string, Term>, opts?: { onShow?: (key: string, term: Term) => void }): void;
  function autolink(root: HTMLElement, dict: Record<string, Term>, opts?: { section?: string; everywhere?: boolean; noCards?: boolean; onShow?: (key: string, term: Term) => void }): { linked: number; perTerm: Record<string, number>; missing: string[] };
  interface DemoApi { click(sel: string | Element): Promise<void>; set(sel: string | Element, value: number | string): Promise<void>; wait(ms: number): Promise<void>; until(fn: () => boolean, ms?: number): Promise<void>; show(sel: string | Element): void; step(): number }
  interface DemoStep { target?: string | Element; title: string; text: string; before?(api: DemoApi): any; do?(api: DemoApi): any; wait?: number; until?(): boolean; timeout?: number; task?: string; expect?(api: DemoApi): boolean; done?: string }
  function demo(steps: DemoStep[], opts?: { title?: string; mode?: "watch" | "guide"; onEnd?: () => void; onExit?: () => void }): { start(mode?: "watch" | "guide"): void; stop(): void; go(i: number): void; api: DemoApi };
  interface VgTerm { id: string; name: string; group?: string; sym?: string; def: string; note?: string; ref?: string; scene: string; focus: string[]; label?: string; related?: string[]; topic?: { href: string; label: string } }
  function visualGlossary(host: HTMLElement, spec: { terms: VgTerm[]; scenes: Record<string, { title: string; svg: string }>; groups?: { id: string; name: string }[]; onShow?: (t: VgTerm) => void; onSelect?: (t: VgTerm) => void; start?: string }): { select(id: string): void; stop(): void }; // card shows ← Back · n of N · Next → over the filtered list; never auto-advances
  /** Flip cards with Again / I knew it; known state per browser under storageKey. */
  function flashcards(host: HTMLElement, cards: { front: string; back: string; ref?: string }[], storageKey: string): void;
  interface DecideNode { q?: string; why?: string; a?: { label: string; next: DecideNode }[]; result?: string; ref?: string; href?: string }
  /** "Which method should I use?" with a clickable trail. */
  function decide(host: HTMLElement, tree: DecideNode): void;
  /** Ctrl/⌘ K palette; also opens from any [data-open-search]. */
  function search(index: { kind: string; label: string; sub?: string; href?: string; alias?: string }[], opts?: { container?: HTMLElement }): { open(): void; close(): void };
  /** Coach-mark tour with a spotlight ring, placed inside opts.container. */
  function tour(steps: { target: string | Element; title: string; text: string }[], opts?: { title?: string; container?: HTMLElement; scope?: ParentNode; onEnd?: () => void }): { start(i?: number): void; end(): void };
  /** "Understood" state behind [data-understood], [data-check] and .sb-meter[data-progress]. */
  /** Lists every element over its word limit (see "Writing, notation and terminology") and logs a table. Run it before publishing. */
  function audit(scope?: ParentNode): { selector: string; words: number; limit: number; text: string }[];
  const WORD_LIMITS: Record<string, number>;
  /** Wires .sb-q questions: button.sb-opt[data-correct="true"], .sb-q-why, [data-quiz-score], [data-quiz-reset]. */
  function quiz(root: HTMLElement, opts?: { onAnswer?: (correct: boolean, q: HTMLElement) => void }): void;
  /** Modal side sheet: focus trap, Escape, scrim, scroll lock, focus return. */
  function drawer(el: HTMLElement, opts?: { openers?: HTMLElement[]; scrim?: HTMLElement; onOpen?: () => void; onClose?: () => void }): { open(from?: HTMLElement): void; close(): void };
  function progress(siteKey: string, ids: string[]): { get(id: string): boolean; set(id: string, v: boolean): void; count(): number; onChange(cb: (state: Record<string, boolean>) => void): void };
}
