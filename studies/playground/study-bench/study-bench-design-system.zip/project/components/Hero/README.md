# Hero

The opening of each site: mono eyebrow naming the book, one display headline, a lede, and a meta line with the edition and chapter range.

## Consumer provides
- Eyebrow: `Companion to <Authors>, <Title>` in `.sb-eyebrow`.
- Headline in `h1` using `display-xl`; mark ONE phrase with `.sb-hl` (the study highlighter). The three sites share the pattern "<Subject>, one mechanism at a time".
- Lede in `.sb-lede`: what is on the site.
- Meta line `.sb-hero-meta` with `.sb-ref` chips: edition, chapter range, count of topics.

## Rules
- Size the hero to its content; never 100vh.
- The highlighter is the only decoration. No gradients, images or illustrations in the hero.

## Word limits
- Lede 40 words; eyebrow 6 words. See "Writing, notation and terminology".
