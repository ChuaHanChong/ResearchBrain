# MasterTable

Every method in one sortable, filterable table: chapter, target, and yes/no properties (bootstraps, off-policy, model, approximation). Click a row to select it on the map and add it to side-by-side.

## Consumer provides
- `table.sb-table.sb-table--sticky-col` with an `id`; `th[data-sort="text|num"]` for sortable columns; rows with `data-*` properties for filtering and `data-v` on numeric cells.
- Filter chips (`data-filter-for`), a search (`data-search-for`), a count (`data-count-for`) and a hidden Clear filters button (`data-clear-for`) that appears when anything is filtered. When nothing matches, the table shows a row with a Clear filters link.
- `StudyBench.table(tableEl)`.

## Rules
- Yes/no cells use ● yes / ○ no in mono with a text alternative (`<span class="sb-sr">yes</span>`), never color.
- Keep the first column (method) sticky when the table scrolls sideways.
