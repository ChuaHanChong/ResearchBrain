# BenchTerms

"On this bench": the Lab's term panel. It shows only the words you can see at work in the bench right now, where they are and what to watch, so the Lab has a different job from the Glossary page (which teaches the definitions).

## Consumer provides
- A bench-bar button **On this bench** and `StudyBench.benchTerms({ button, host, title, items })`. `host` is the bench root; while the panel is open it gets `.has-benchterms`, which pads it on the right so the bench reflows beside the panel.
- `items()` returns the terms visible for the current method, world, scene or term (typically 6–15): `{ id, name, sym?, where, watch, value?(), target?(), href? }`.
  - `where` groups the rows by bench part (Controls, Scene, Update, Learning curve, Robot, Payoff matrix …).
  - `watch` says what to watch during a run, not a definition (15 words).
  - `value()` returns the live value as the bench formats it; the panel shows `–` until there is one.
  - `target()` is the element **Point to it** centres and outlines (`.sb-pointed`).
  - `href` defaults to `#glossary/<id>`, shown as **Definition ↗**, the only route from the Lab to definitions.
- Call `api.refresh()` when the method, world, scene or selected term changes. The Glossary page's **Show in Lab ▶** opens the Lab with that setup, opens the panel and points at the row.

## Rules
- Non-modal: the bench stays usable while the panel is open. Esc or ✕ closes it and focus returns to the button.
- A fixed sheet under the app bar on the right (360px); a bottom sheet at 640px and below.
- Same placement, order and behaviour on every site. A lab in an iframe draws the panel in the parent page.

## Word limits
- watch 15 words; title "Method · World" or the term's name.
