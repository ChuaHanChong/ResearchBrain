# States

What a panel shows while it loads, before anything has happened, while running, when paused, and when something breaks.

## Parts
- `.sb-skel` blocks while MathJax typesets or a scene mounts; sized like the real content.
- `.sb-empty` before a first run or when a filter matches nothing: a title, one sentence, one action.
- `.sb-live` status: default (paused), `.is-running` (pulsing dot), `.is-error`.
- `.sb-error` callout: what failed and what to do ("The run stopped because α > 1 diverged. Lower α and press Reset.").

## Rules
- Never show `NaN`, `undefined`, an empty canvas or a spinner with no words.
- Every canvas or SVG scene sits in a `figure` with a caption, and charts include a data table; a scene that can't be a table gets a text description.
- Mobile: under 960px the TOC becomes a Topics select (`.sb-mobile-toc`), benches stack, and touch targets stay ≥ 32px.

## Word limits
- Empty and error text 30 words. See "Writing, notation and terminology".
