# Search

One search for the whole site (Ctrl/⌘ K): topics, methods, glossary terms and symbols in grouped results; ↑ ↓ to move, Enter to open, Esc to close. Symbols are searchable by name ("alpha") and glyph (α).

## Consumer provides
- `StudyBench.search(index)` with `index = [{kind, label, sub, href, alias}]` built from the TOC, the master table, the glossary and the notation sheet.
- A `.sb-searchbtn[data-open-search]` in the app bar showing the shortcut.

## Rules
- Results link to deep anchors (`#t-td`, `#c-q`, `#term-bootstrapping`). The empty state suggests an example query.
- The input is an ARIA combobox: screen readers announce the highlighted result as ↑ ↓ move.
