# BackupDiagram

Backup diagrams in the book's convention: open circles are states, filled dots are actions, a square is a terminal state, an arc under branches means max. Use them in method cards, the method rack, the master table and side-by-side comparisons.

## Consumer provides
- Inline SVG, 64px wide per diagram, using `.sb-bk-state`, `.sb-bk-action`, `.sb-bk-term`, `.sb-bk-edge`, `.sb-bk-dots` (the rest of an episode) and `.sb-bk-max` (the max arc).
- `.is-new` on the part that differs from the predecessor method (drawn in `q-new`).
- A label under each in `.sb-backup`.

## Rules
- Same geometry for every method so differences are the only thing that changes.
- Always pair with the method name; never use the diagram alone as a label.
