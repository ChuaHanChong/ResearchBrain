# CourseMap

The whole book as a map of topics and prerequisites, with progress: understood topics in `good-soft` with a ✓ dot, the current topic outlined in accent. Hover shows what a topic needs first and what it unlocks; click opens it. Sits on each site's home page, under the hero.

## Consumer provides
- `StudyBench.dag(host, {cols: book parts, nodes: [{id,label,sub,col,row,state}], edges, onSelect})`, states from `StudyBench.progress(...).onChange`.
- A `.sb-meter[data-progress]` above it and the key (`.sb-dag-key`).
- Keyboard: arrow keys move between topics, Enter opens. Touch: tap opens.

## Rules
- Prerequisite edges come from each topic's "Builds on" list; the two must agree.
- The map fits 960px wide; wider books scroll inside `.sb-scroll-x`.
