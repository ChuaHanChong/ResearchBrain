# TopicNav

Left-hand list of topics grouped by the book's parts, with mono topic numbers, optional chapter sub-lines and an 'understood' check.

## Consumer provides
- `.sb-toc-part` headings (the book's own part names), each followed by an `<ol>` of links.
- Per link: `.sb-toc-n` (two-digit topic number, or the book's chapter number when topics map 1:1 to chapters), the title, optional `.sb-toc-sub` (`Ch 6 · §6.4`), optional `.sb-check` (`.is-done` when understood).
- `aria-current="location"` on the topic in view (scroll-spy).

## Rules
- Width `sidebar-w`; hidden under 960px, replaced by a Topics `.sb-select` at the top of the content.
- Numbers mean order in the site, so use them only for the topic sequence. Special entries (playground, glossary, formula sheet) go in their own part with no number.
- Current item: `surface` fill, `line` inset border, number in `accent`.
