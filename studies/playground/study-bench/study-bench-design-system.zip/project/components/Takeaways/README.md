# Takeaways

The close of every topic: numbered takeaways, then the understood toggle that feeds the course map, TOC checks and progress meter.

## Consumer provides
- `ol.sb-takeaways` with one sentence per takeaway.
- `button.sb-btn[data-understood="<topic-id>"]` and, anywhere on the page, `.sb-meter[data-progress]` with `.sb-meter-track > .sb-meter-fill` and `.sb-meter-text`; TOC checks with `data-check="<topic-id>"`.
- `StudyBench.progress("<site>", [topic ids])` once per page.

## Rules
- Progress is per viewer, stored in the browser, and optional: the page works without it.
- Understood is the viewer's claim, not a quiz score. Don't gate content on it.

## Word limits
- 3–5 takeaways of 25 words each. See "Writing, notation and terminology".
