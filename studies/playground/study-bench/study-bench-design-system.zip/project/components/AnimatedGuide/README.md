# AnimatedGuide

A looping, captioned SVG animation that explains one mechanism in 3–6 beats. It plays by itself when it scrolls into view. The caption track under it says what each beat shows, so the picture and the words move together.

## Consumer provides
- `figure.sb-anim` > `svg` (viewBox 420 wide, labels ≥ 14px, 1.5px strokes, tokens only) + `figcaption.sb-anim-cap > ol.sb-anim-beats > li` (one per beat).
- Parts that change carry `data-a="<id>"`. They start hidden; `.a-base` parts are always shown.
- Motion classes on parts:
  - `.a-draw`: the path draws itself.
  - `.a-flow`: dashes stream along the path.
  - `.a-pulse`: the part breathes.
  - `.a-glow`: an accent glow.
- Each beat `li` may carry:
  - `data-on` / `data-off`: part ids to show or hide.
  - `data-cls="id:a-flow"`: add a motion class.
  - `data-move="token:path"`: move a token along a path.
  - `data-set="bar.width=120"`: tween a number.
  - `data-text="val=0.42"`: change a label.
  - `data-dur` (ms, default 1800).
- `data-hold` on the figure: the pause before it loops (default 2200 ms). `StudyBench.animAll(root)` wires every figure and every `[data-anim-toggle]`.

## Rules
- A beat changes one thing. The caption names it in the book's words (12 words).
- Loops forever while visible, pauses off screen and when the page's **Pause animations** is on (remembered per browser). With prefers-reduced-motion, it shows the finished picture with every step listed; print does the same.
- Same visual vocabulary on every slide of a site: the agent, world, robot, agents, value bars and arrows look the same every time they appear. Color by role (`q-*`, `agent-*`, `frame-*`), never decoration.
- A scene explains a mechanism: what moves where. It is not a decorative icon or a chart of fake data. Illustrative numbers carry `.sb-prov` in the text column.
