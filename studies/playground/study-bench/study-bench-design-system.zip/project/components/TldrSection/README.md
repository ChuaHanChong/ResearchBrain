# TldrSection

One partition of the TL;DR page: an animated visual guide on one side and the TL;DR on the other, so one big idea of the book reads in under a minute without touching anything.

## Consumer provides
- `section.sb-sec.sb-tldr#tldr-<id>` with two children: `figure.sb-anim` (see AnimatedGuide) and `div.sb-tldr-text`. Add `.is-flip` to every other section so the picture alternates sides.
- `.sb-tldr-text`, in this order:
  - `.sb-tldr-n`: number and book reference ("03 · Ch 4").
  - `h3.sb-tldr-title`: the idea in 3–8 words (the part is the h2).
  - `p.sb-tldr-sum`: `<b>TL;DR</b>` plus one sentence.
  - `ul.sb-tldr-points`: 2–3 points.
  - Optional: the one equation with EquationKey (`p.sb-eqwords` + `ul.sb-eqkey`).
  - `p.sb-tldr-remember`: **Remember:** one line.
  - `.sb-chips`: `.sb-ref` and **Go deeper →** (a link to the topic).
- Page wrapper: `main.sb-page.sb-page--tldr[data-page="tldr"]`.
  - Page head: eyebrow "N sections · about M min", h1 "TL;DR" and a lede, then `.sb-tldr-bar` with `button[data-anim-toggle]`, then `ol.sb-tldr-map` (a numbered list of all sections, as links).
  - Sections are grouped into parts. Each part opens with its own `section.sb-sec.sb-tldr-part` holding only a `header.sb-sec-head` (eyebrow "Part I · Ch 2–8", `h2.sb-sec-title`, a one-line lede). That keeps the 48px rhythm with nothing between sections. The page closes with a recap section.
  - The page ends with `nav.sb-pager.sb-page-pager`. Call `StudyBench.animAll(page)`.

## Rules
- Not interactive: no buttons in a section except **Go deeper →**, and nothing to click in the scene. The only control on the page is Pause animations.
- One idea per section; the picture carries the idea, and the text says it in words once.
- Everything comes from the site's own book, in its notation, with `.sb-ref` chips. Anything simplified or illustrative carries `.sb-prov`.

## Word limits
- Title 8 words, TL;DR sentence 30, point 15, Remember 15, beat caption 12.
