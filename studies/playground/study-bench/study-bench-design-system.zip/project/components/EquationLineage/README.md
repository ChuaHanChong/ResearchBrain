# EquationLineage

The chain of update rules from the root method to the selected one, each written against its predecessor: new terms in `q-new`, changed terms in `q-changed`, and a label on each connector saying the one idea that changed.

## Consumer provides
- `.sb-lineage` list of `.sb-eq` blocks; between them `.sb-lineage-step` with the change in words.
- Diff marks in TeX via `\class{sb-new}{…}` and `\class{sb-chg}{…}`.

## Rules
- One idea per step. If two things changed, there is a missing method in between.
- The root is always the incremental mean NewEstimate ← OldEstimate + StepSize [Target − OldEstimate] (§2.4), so every method reads as a choice of target.

## Word limits
- 12 words per change label. See "Writing, notation and terminology".
