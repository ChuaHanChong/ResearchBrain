# VisualGlossary

The Glossary page's main view: pick a term and see where it lives in a picture of the book's core setting, with the book's definition, a short note, related terms and a link into the Interactive Lab.

## Consumer provides
- One to four **scenes**: inline SVGs of the book's core settings (RL: the agent–environment loop over a gridworld; MARL: two agents in a stochastic game with their joint action and payoff matrix; MR: the robot arm with frames, joints and screw axes). Every drawable part carries `data-part="<id>"`. Colors come from tokens only.
- **Terms**: `{id, name, group, sym, def, note, ref, scene, focus: [part ids], label, related: [ids], topic: {href, label}}`. `def` follows the book's wording (35 words). `label` says what to look at (8 words).
- `StudyBench.visualGlossary(host, {terms, scenes, groups, onShow, onSelect, start})`. `onShow(term)` opens the Interactive Lab with that term's demo.

## Rules
- Every glossary term has a scene and at least one focused part. When a term has no natural place in a scene (a theorem, a named algorithm), focus the part it acts on and say so in `label`.
- The glossary, the key-term notes (`autolink`) and search share one term list per site.
- **← Back · n of N · Next →** walks the terms of the current (filtered) list one at a time. It never advances by itself: the learner presses Next. There is no Play through.
- The Map and A–Z views give the same Back / Next when a term is open; A–Z has a **Walk through** mode that steps entry by entry.
- The Glossary page has three sub-tabs: **Visual** (this), **Map** (GlossaryMap) and **A–Z** (a plain list for scanning and printing).

## Word limits
- Definition 35 words, note 30, look-at label 8.
