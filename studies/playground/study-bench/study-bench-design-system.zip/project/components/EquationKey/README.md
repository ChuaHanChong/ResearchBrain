# EquationKey

The words line and symbol key under every displayed equation, so the equation reads on its own without a trip to the Notation page.

## Consumer provides
- `p.sb-eqwords`: **In words:** what the equation computes, in the book's terms.
- `ul.sb-eqkey` (with `data-no-autolink`): one `li[data-sym="<id>"]` per distinct symbol, in order of appearance, each `span.sb-eqkey-sym` (the glyph as the book writes it) + its meaning.
- In the equation's TeX, each symbol wrapped as `\class{sym-<id>}{…}` with the same id as the key and the Notation page; then `StudyBench.link(block)` so hovering or tapping a symbol lights it in the equation and in the key.

## Rules
- Every symbol gets an entry, including sub/superscripted forms and operators the book defines (𝔼, argmax, ∇, [·]). A letter whose meaning changes in one part of the book gets its own entry there.
- Meanings use the book's own term. Ids match the Notation page so one symbol has one id across the site.
- Applies to topic rules, worked examples, algorithm update lines, Overview summary cards, the lineage detail, story steps and the formula sheet.

## Word limits
- In words 25 (20 on cards). Each key meaning 6.
