# Bench

The lab-bench layout used by RL Machine, MARL Lab and Robot Lab: one scene where every method or term is shown on the same machine.

## Consumer provides
- `.sb-bench` (full-bleed, `bench` ground with the `bench-grid` graph paper) > `.sb-bench-inner`.
- `.sb-bench-bar`: title (`.sb-bench-title`), the world or mode `.sb-seg`, and tools (Tours, Glossary) on the right.
- `.sb-bench-grid` of `.sb-panel`s: left = method list or world, middle = scene / agent internals, right = update engine or glossary. Scenes draw into `.sb-scene`.

## Rules
- The bench follows the theme like every other part of the page. It is NOT a forced dark island: light theme gets a light bench.
- Text never sits on `bench` directly; it goes in panels. Canvas scenes read colors from `StudyBench.palette()` and redraw on theme change.
- Columns: 1 under 960px, 2 up to 1200px, 3 above (280px · fluid · 320px).
