# Bench

The lab-bench layout used by RL Machine, MARL Lab and Robot Lab: one scene where every method or term is shown on the same machine.

## Consumer provides
- `.sb-bench` (full-bleed, `bench` ground with the `bench-grid` graph paper) > `.sb-bench-inner`.
- `.sb-bench-bar`: monogram, title (`.sb-bench-title`), subtitle and any `.sb-prov` on the left; on the right, in this order and nothing else: the status (or progress meter), **Tours ▾** and **On this bench**. World or mode switches sit on the left or inside the bench.
- `.sb-bench-grid` of `.sb-panel`s: left = method list or world, middle = scene / agent internals, right = update engine or term card. Scenes draw into `.sb-scene`.

## Rules
- The Lab never holds a second copy of the glossary (no full term list, definitions list or search over all terms). Words at work are shown by **On this bench** (BenchTerms); definitions live on the Glossary page.
- The bench follows the theme like every other part of the page. It is NOT a forced dark island: light theme gets a light bench.
- Text never sits on `bench` directly; it goes in panels. Canvas scenes read colors from `StudyBench.palette()` and redraw on theme change.
- Columns: 1 under 960px, 2 up to 1200px, 3 above (280px · fluid · 320px).
