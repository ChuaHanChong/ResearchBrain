# ReturnNav

Jumps you can undo. Any click that takes the learner to another page, sub-tab or a far-away section (a course-map box, a summary card, a concept card, a lineage box, a glossary chip, a symbol part) records where they were; a "← Return to <page · tab · section>" button appears bottom left and brings them back to the same page, sub-tab and scroll position (anchored to the element they clicked, so it survives content that grows).

## Consumer provides
- `StudyBench.returnNav()` once (the shared `wire.html` snippet does it), plus `StudyBench.cardLinks(document, {termHref})` and `StudyBench.anatomyJump(document)`.
- Boxes that navigate: course-map boxes → `#explorer/<topic>`; summary and concept cards → their link (concepts without one get "In the glossary →"); lineage boxes → select and bring the detail into view; flow nodes naming another chapter → that topic; glossary map boxes → `#glossary/<term>`; symbol-anatomy parts → their table row.
- `StudyBench.flash(el)` on the landing element so the learner sees where they arrived.

## Rules
- The button hides while a demo runs and when there is nowhere to return to; ✕ clears it. Browser Back still works for page changes.
- A box that looks clickable must go somewhere. Otherwise remove its pointer and hover style.

## Word limits
- Return label: page · tab · section, each shortened to 40 characters.
