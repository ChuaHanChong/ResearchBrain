# AppBar

Sticky top bar: book monogram and site name ("STUDY BENCH" in small mono caps over the subject: `.sb-brand-name` > `.sb-brand-family` + subject), the **eight pages** in fixed order, then Search and the theme toggle.

## The eight pages (same names, order and ids on all three sites)
| # | Label | id | Old ids that redirect |
|---|---|---|---|
| 1 | Overview | `#overview` | `#home`, `#path` |
| 2 | Topic Explorer | `#explorer` | `#chapters`, `#topics` |
| 3 | Evolution | `#evolution` | `#lineage` |
| 4 | Compare | `#compare` | `#decide`, `#reference/decide` |
| 5 | Interactive Lab | `#lab` | `#machine`, `#playground` |
| 6 | Reference | `#reference` | `#formulas` |
| 7 | Glossary | `#glossary` | — |
| 8 | Notation | `#notation` | — |

Deep links: `#explorer/<topic>`, `#glossary/<term>`, `#lab/<method>`, `#reference/<tab>`.

## Rules
- Labels are exact: no site renames a page. Content inside each page follows the site's own book.
- Below 1180px the page switcher moves to its own full-width row. The views row is a `nav.sb-views` with `aria-current="page"`; it scrolls sideways within itself below 1100px and never pushes the page wider.
- Pages with parts use `nav.sb-subtabs` right under the page title (see guide "Site structure").

## Word limits
- Page label 3 words; brand name 4 words.
