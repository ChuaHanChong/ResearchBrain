# Algorithm

The book's pseudocode box, with line numbers, synced to a run: the line being executed is highlighted as the simulation steps. Symbols inside it take part in linked highlighting.

## Consumer provides
- `.sb-algo` > `.sb-algo-head` (title + `.sb-ref` with the book page) > `ol` of lines. Indent with spaces (the lines keep whitespace). `.kw` for keywords, `.cm` for comments.
- `data-on` on lines when driven by a stepper, or toggle `.is-on` from your own simulation loop.

## Rules
- Copy the book's pseudocode faithfully; mark any change with `.sb-prov`.
- Pair it with the playground it drives, side by side from 960px up.

## Word limits
- 30 words per step text; pseudocode copied from the book. See "Writing, notation and terminology".
