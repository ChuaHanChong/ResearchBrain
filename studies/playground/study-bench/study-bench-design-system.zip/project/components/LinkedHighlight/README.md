# LinkedHighlight

Hover or focus any symbol and every place it appears lights up at once: in the equation, the diagram, the pseudocode and the notation list. This is the main visual-learning device: it connects what the symbol *is* to where it *acts*.

## Consumer provides
- `data-sym="<id>"` on every occurrence: equation parts, SVG shapes in diagrams, pseudocode spans, notation rows, legend keys. In MathJax write `\class{sym-<id>}{…}` (e.g. `\class{sym-alpha}{\alpha}`); the engine treats `.sym-<id>` the same as `data-sym`.
- Call `StudyBench.link(scopeElement)` once per topic or panel. The scope limits what lights up.
- Mouse: hover. Keyboard: focus. Touch: tap a symbol to pin its highlight; tap it again, tap elsewhere or press Escape to clear.
- Make non-interactive occurrences focusable (`tabindex="0"`) in at least one place so keyboard users can trigger it.

## Rules
- Lit HTML text gets the `hl` highlighter; lit SVG shapes get an `accent` stroke. Nothing else changes.
- One symbol id per concept across the whole site (`alpha`, `gamma`, `q`, `v`, `r`, `delta`, `pi`), matching the Notation sheet.
- Add the hint line `.sb-lit-hint` ("Hover a symbol to see it everywhere") the first time a topic uses it.
