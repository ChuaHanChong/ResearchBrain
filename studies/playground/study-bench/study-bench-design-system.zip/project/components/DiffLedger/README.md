# DiffLedger

One page that lists every place the site differs from the book: what the book says, what the page does, why, and where. It collects every `.sb-prov` and `.sb-callout--differs` on the site.

## Consumer provides
- A `table.sb-table` with columns Where · Book · This page · Why, and a `.sb-prov` kind in the Why cell ("Simplified", "Our choice", "Not in the book", "Differs").

## Rules
- Every deviation on the site has a row here, and every row links back to where it appears.
