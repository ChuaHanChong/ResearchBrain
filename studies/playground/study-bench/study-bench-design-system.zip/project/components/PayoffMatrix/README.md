# PayoffMatrix

Normal-form games: each cell shows both agents' payoffs, underlined in `agent-1` and `agent-2`; equilibria are outlined in `equilibrium`, Pareto-optimal outcomes dashed in `pareto`, each also tagged in text.

## Consumer provides
- `table.sb-matrix` with row actions (agent 1) in `th` and column actions (agent 2) in the header row.
- Cells: `<span class="sb-pay"><span class="a1">r₁</span><span class="a2">r₂</span></span>`, plus `.is-eq` / `.is-pareto` and a `.sb-cell-tag` ("NE", "PO").
- A legend with `agent-1`, `agent-2`, `equilibrium`, `pareto`.

## Rules
- Editable payoffs use `input` inside the cells with the same underline colors.
- Mixed strategies are shown as a bar or simplex next to the matrix, not inside it.

## Word limits
- Caption 35 words. See "Writing, notation and terminology".
