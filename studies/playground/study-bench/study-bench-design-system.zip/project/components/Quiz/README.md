# Quiz

The self-check at the end of each topic: multiple-choice questions with immediate feedback and a one-line why.

## Consumer provides
- `.sb-q` per question: `.sb-q-text` (with `.sb-q-n` number), `.sb-opts` of `button.sb-opt`, each holding an empty `.sb-opt-mark` and the option text wrapped in one `<span>`, `.sb-q-why` shown after answering.
- On answer set `data-state`: `correct` on the chosen right one (mark ✓), `wrong` on a chosen wrong one (mark ✗) plus `answer` on the right one, `dim` on the rest.

## Rules
- Feedback always pairs color with ✓ / ✗ and the words Correct / Not quite in `.sb-q-why`.
- Move focus to `.sb-q-why` after answering. Flashcards use the Segmented control to switch mode.

## Word limits
- Question 25 words, option 12, explanation 40. See "Writing, notation and terminology".

## Engine
- `StudyBench.quiz(root)` wires every `.sb-q` inside `root`: mark the right option with `data-correct="true"`, leave `data-state` empty. Answering locks the question, marks ✓ / ✗, adds "Correct." or "Not quite." to `.sb-q-why`, reveals it and moves focus to it. `[data-quiz-score]` shows the running score and `[data-quiz-reset]` clears all answers.
