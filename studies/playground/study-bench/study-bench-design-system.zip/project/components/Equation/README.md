# Equation

An equation block, alone or as a before → after diff that shows how one method grows out of another.

## Consumer provides
- `.sb-eq-head`: the name and an `.sb-ref` (equation number or section).
- One `.sb-eq-row` per line: `.sb-eq-k` (Before / After, or From / To), `.sb-eq-math` (MathJax), optional `.sb-eq-no` (`(6.2)`).
- Diff marks in TeX: `\class{sb-new}{…}` for a new term (`q-new`), `\class{sb-chg}{…}` for a changed term (`q-changed`). Add `.sb-eq-key` so the colors are named.

## Rules
- Diff colors only mean new/changed. Quantity roles (`q-reward`, `q-value` …) are for live update tokens in the benches, never mixed into a diff.
- Keep MathJax (tex-svg, v3.2.2 from cdnjs) on all three sites; the math inherits `ink`.
- Long equations scroll inside `.sb-eq-math`, not the page.

## Self-contained: words and symbol key
- Every displayed equation (topic rule, worked example, algorithm update line, summary card, lineage detail, story step) is readable without looking elsewhere. Under it:
  - `p.sb-eqwords`: **In words:** what it computes, in the book's terms (25 words; 20 on cards).
  - `ul.sb-eqkey`: one `li[data-sym]` per distinct symbol, in order of appearance: `.sb-eqkey-sym` + meaning (6 words, the book's term). Operators the book defines (𝔼, argmax, ∇) count as symbols.
- In the TeX, wrap each symbol as `\class{sym-<id>}{…}` with the key's `data-sym` id (the Notation page's ids), then call `StudyBench.link(block)`: hovering or tapping either lights both. See EquationKey.

## Notation
- Use the book's notation exactly. One form per block: numbered equations use the time-indexed form, such as V(Sₜ), and pseudocode-style targets use the book's pseudocode form, such as V(S′). Never mix the two in one block.
- Every symbol in the block appears in the site's Notation sheet with the same `data-sym` id.
