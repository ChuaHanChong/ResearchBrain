# MethodsTable

The per-topic table of methods: what each is for, its update target, a backup glyph, and actions to compare it or run it in the lab.

## Consumer provides
- `table.sb-table` inside `.sb-scroll-x` with columns Method · What it's for · Target · Backup · Actions. Actions are `.sb-btn--ghost` "Compare ↗" (to the evolution page with the method preselected) and "Run ▶" (opens the lab with that method).
- Book reference in the Method cell as `.sb-ref`.

## Rules
- Same columns on every topic and every site. Targets use the book's notation.

## Word limits
- "What it's for" 12 words. See "Writing, notation and terminology".

## Small screens
- Tables inside `.sb-scroll-x` keep a 560px minimum width and scroll sideways instead of squeezing columns.
