# UpdateEngine

The update rule as live tokens: each term is a chip colored by its quantity role, with its current value underneath. Terms that differ from the base method are outlined (`is-new` dashed in `q-new`, `is-changed` dotted in `q-changed`).

## Consumer provides
- `.sb-engine` > `.sb-engine-row` (an `.sb-eyebrow` label + `.sb-toks`) > `.sb-tok` with `style="--c: var(--q-value)"`, the symbol wrapped in `.sb-tok-s`, and the `.sb-tok-v` value; operators as `.sb-tok-op`.
- Update `.sb-tok-v` text on every step. Add `data-sym` so tokens link to the notation.

## Rules
- Token text is always ink; the color lives in the tint and the 3px underline.
- Role colors: `q-reward`, `q-value`, `q-policy`, `q-ratio`, `q-trace`, `q-model`. Parameters (α, γ, λ) use the default neutral `--c`.
- Show a legend of the roles once per bench.
