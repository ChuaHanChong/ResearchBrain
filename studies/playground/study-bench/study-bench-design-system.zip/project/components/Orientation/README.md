# Orientation

The first block of every topic, the same on all three sites: why the topic exists, what you can do after it, and where it sits (builds on → leads to). It replaces RL's "Why this topic / How it connects", MARL's "What this is for" and MR's "Why this chapter exists / After this chapter you can".

## Consumer provides
- `.sb-orient` with three `.sb-orient-card`s: **Why this exists**, **After this you can** (`.sb-outcomes`, outcomes that start with a verb), **How it connects** (`.sb-connect`: Builds on / Leads to, each item an `.sb-ref` + title linking to the topic).
- Optionally a fourth card with a mini course map (`StudyBench.dag` of only the neighbours) under "Where it fits".

## Rules
- Outcomes start with a verb you could test: "Compute", "Explain why", "Choose between".
- Links in How it connects go to topics on the same site; other books use `.sb-xlink`.

## Word limits
- Why this exists 60 words; 3–5 outcomes of 15 words each. See "Writing, notation and terminology".
