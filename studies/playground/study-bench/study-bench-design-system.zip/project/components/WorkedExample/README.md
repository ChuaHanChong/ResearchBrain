# WorkedExample

A numbered, step-through derivation or calculation: each step highlights the part of the equation and the part of the picture it talks about, with one sentence of explanation. Play auto-advances; ← → keys and the scrubber move by hand.

## Consumer provides
- A root with `class="sb-stepper sb-stepper--reveal"` and `data-steps="N"`; controls with `data-act="prev|next|play|reset|scrub"` and a `[data-status]`.
- `data-on="2"`, `data-on="3-5"` or `data-on="4+"` on any element (equation spans, SVG groups, table rows) that belongs to those steps; `data-step-text="n"` paragraphs for the explanation.
- `StudyBench.stepper(root, {onStep})`. Use `onStep` to drive a simulation or a chart.
- With `sb-stepper--reveal`, text for later steps is shown in `ink-3` (still readable) and drawing parts for later steps stay hidden until their step. At the end, Play becomes Replay.

## Rules
- 3–7 steps. Each step changes one thing and says what changed.
- Numbers must be the ones the code computes; show units.
- The finished state (last step) is a complete, readable picture.

## Word limits
- 30 words per step. See "Writing, notation and terminology".

## Small screens
- Put the drawing in `.sb-scroll-x`; it keeps a 520px minimum width and scrolls sideways instead of shrinking its labels.
