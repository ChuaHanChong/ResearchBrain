# StoryMode

A guided walk through the evolution as a **step-card filmstrip**: the current step is a large card, the others small clickable thumbnails. It must look different from the lineage map: cards and pictures, not boxes and arrows.

## Consumer provides
- A stepper root (`data-steps`) with toolbar controls Play ▶ · ← · → · scrub · "Step n of N".
- Per step: a small purpose-drawn SVG (the problem → the change → the result, tokens only, 1.5px strokes), a title, the step text and the equation diff with its symbol key.
- Do not reuse the lineage DAG. A step card may link "Show on map".

## Rules
- 6–12 steps for a whole book. Each step must be reachable later from the map by clicking.

## Word limits
- 30 words per step. See "Writing, notation and terminology".
