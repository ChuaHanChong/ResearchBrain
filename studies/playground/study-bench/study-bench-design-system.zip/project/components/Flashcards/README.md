# Flashcards

Spaced-review cards for every topic (and the glossary): front question, flip for the answer and its section, then "Again" or "I knew it". Keyboard: Space flips, ← → move.

## Consumer provides
- `StudyBench.flashcards(host, cards, storageKey)` with `cards = [{front, back, ref}]`. Pair it with the quiz using a Quiz / Flashcards `.sb-seg`.

## Rules
- One idea per card; every answer has a section reference.
- Known counts live in the viewer's browser only.

## Word limits
- Front 15 words, back 30. See "Writing, notation and terminology".
