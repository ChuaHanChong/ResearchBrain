# MethodRack

The lab's method picker: every method on the site, grouped by family, each with its backup glyph and chapter. Picking one reconfigures the whole machine.

## Consumer provides
- `.sb-rack` > `.sb-rack-group` (eyebrow = family) > `button.sb-rack-item[aria-pressed]` with `.sb-rack-glyph` (a 28px backup diagram), `.sb-rack-name`, `.sb-rack-sub` (`§6.5 · off-policy`).
- `StudyBench.segmented(groupEl)` or your own handler to keep one pressed.

## Rules
- The same family names and order as the evolution map, so a learner sees the same structure in both places.
