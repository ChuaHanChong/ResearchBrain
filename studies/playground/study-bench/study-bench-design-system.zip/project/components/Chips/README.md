# Chips

Three small labels with fixed meanings: chapter references, topic tags, and provenance badges.

## Parts
- `.sb-ref`: a reference into the book, always `Ch N`, `Ch N · §N.M`, `Eq. 6.2`, `Fig. 9.2` or `Ex. 3.7`. Mono, `line` outline. Link it when the target is on the page.
- `.sb-tag`: a concept or method name. `button.sb-tag[aria-pressed]` for filters (glossary categories).
- `.sb-prov`: where a thing comes from when it is NOT straight from the book: "Not in the book", "Our choice", "Simplified". `.sb-prov--differs` (warn) for "Differs from the book: …".

## Faceted filters
- Every filter row is faceted: each chip shows how many items it would give (`data-facet-count`, drawn after the label), and a chip that would give no results under the other filters disappears (`data-facet-empty`). **All** always stays and shows the total.
- Call `StudyBench.facetCounts(items, groups)` after the first render and after every filter change; each group is `{chips, match(item, val), selected()}`. Applies to the formula sheet, review cards, master table, notation kinds, glossary groups and the differences table.

## Rules
- Every result, parameter or example that is not from the book carries a `.sb-prov`. This is the house honesty rule.
- No pills: chips use `radius-xs`. No emoji. No color per chapter.
