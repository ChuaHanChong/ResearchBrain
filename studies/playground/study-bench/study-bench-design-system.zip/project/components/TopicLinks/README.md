# TopicLinks

Every topic can be seen at three depths: its **Summary** card on Overview (about 10 seconds), its **TL;DR** section (a 40-second animated picture) and the full lesson in the **Topic Explorer**. TopicLinks is the one row of links that ties the three together, with the same words in the same order everywhere.

## Consumer provides
- `div.sb-topiclinks[role=group][aria-label="This topic elsewhere"]` with, in this order and leaving out the place you are on:
  - `a.sb-link[href="#overview/<topic>"]` **Summary**
  - `a.sb-link[href="#tldr/<section>"]` **▶ TL;DR**
  - `a.sb-link[href="#explorer/<topic>"]` **Open topic →**
- `span.sb-done[hidden]` **✓ Understood**, shown when the topic is marked understood (`StudyBench.progress`). The same state shows on the Overview card, the TL;DR section, its box in the TL;DR section list, and the Topic Explorer.
- Where it sits: the foot of each Overview summary card; the chips row of each TL;DR section (in place of "Go deeper →"); under the title of each Topic Explorer topic.

## Rules
- The labels never change: **Summary**, **▶ TL;DR**, **Open topic →**. "Go deeper" and a bare "Open topic" without its arrow are retired.
- Many-to-one: a TL;DR section that covers two topics shows one **Open topic →** per topic, naming each ("Open topic: Psychology →"). A topic covered by two TL;DR sections links to the first. Recap sections link to Evolution instead ("See the evolution →").
- Every jump shows "← Return to …" (ReturnNav), and the landing card or section flashes.
