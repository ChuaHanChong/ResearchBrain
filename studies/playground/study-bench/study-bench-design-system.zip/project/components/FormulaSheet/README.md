# FormulaSheet

All key equations of a book on one page, grouped by chapter, each with its number, a one-line "what it says", and a Copy TeX button. Linked highlighting works across the whole sheet.

## Consumer provides
- `.sb-formulas` grid of `.sb-formula`: `.sb-formula-head` (`.sb-formula-name` + `.sb-ref`), `.sb-formula-math` (MathJax), a one-line `.sb-caption`, `.sb-formula-foot` with `button.sb-btn--ghost[data-copy="<tex>"]`.
- Copy with `navigator.clipboard.writeText` inside the click handler; on failure select the TeX in a `<code>` instead.

## Rules
- Only numbered equations from the book, in book order. Filter by chapter with chips.

## Word limits
- One-line meaning, 20 words. See "Writing, notation and terminology".
