# PageGuide

"How to use this page" in three numbered steps, at the top of every one of the seven pages, so the learner never has to work out what to do first.

## Consumer provides
- `<ol class="sb-howto" aria-label="How to use this page">` with three `<li>`: a `<b>` action (3–5 words), a `<span>` (≤ 15 words) and, where it helps, one button that does the step (Watch demo, Open first topic, Start tour).
- Mark a step done with `li.is-done` once the learner has done it (the number becomes ✓).
- Optional first-visit hint `.sb-demo-hint` beside a demo launcher: "New here? Press Watch demo." with a dismiss button; remember dismissal in localStorage inside try/catch.

## Rules
- Three steps, always in the order: look/read → watch or try → check yourself.
- The step buttons call the same functions as the page's own controls. No step is a dead end.

## Word limits
- Action 5 words; text 15 words; button 3 words.
