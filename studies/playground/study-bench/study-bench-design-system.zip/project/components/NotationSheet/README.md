# NotationSheet

The notation page (and drawer): every symbol with its meaning, kind and where it first appears, filterable by kind. Hovering a row lights the symbol wherever it appears on the page, including the anatomy diagram above the table.

## Consumer provides
- A `table.sb-table` with `id`, rows carrying `data-kind` (sets, variables, functions, parameters) and `data-sym`, and cells: symbol (math, 18px), meaning, first use (`.sb-ref`).
- Filter chips in a container with `data-filter-for="<table id>"` (`button.sb-tag[data-key="kind"][data-val="…"]`), a search `input[data-search-for]`, a count `[data-count-for]`.
- `StudyBench.table(tableEl)` and `StudyBench.link(scope)`.

## Rules
- The book's notation table order is the default order.
