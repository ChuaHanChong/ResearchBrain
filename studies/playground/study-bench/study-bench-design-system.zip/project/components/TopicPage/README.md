# TopicPage

The template every topic follows on all three sites, top to bottom: orientation, key concepts as pictures, a workflow diagram of where the topic acts, a step-through worked example, the rule with linked highlighting, the playground, the methods table, then takeaways, the quiz or flashcards, and "Mark as understood".

## Consumer provides
- The topic's content in this order. Sections with nothing real to show are left out; they are not filled with filler.
- The same component in the same slot on every topic, so learners know where to look.

## Rules
- The first screen of a topic shows the orientation and at least one picture.
- Every section has a visual: a diagram, a chart, a stepper or a live playground. Prose alone is never a section.
- The quiz (with a Flashcards switch) and Mark as understood close every topic.
