# PageShell

The one application shell every Study Bench site uses, so the three sites feel like one application: same app bar, same page container, same page head, same sub-tabs, same section heads, same place for demo launchers and controls, same footer. Only content differs.

## Structure (every page)
`main.sb-page[data-page]` (Topic Explorer: `.sb-page.sb-page--toc` with a sticky `nav.sb-toc` column) → `header.sb-page-head` (`.sb-eyebrow`, `h1.sb-page-title` 32px, `.sb-lede`, `ol.sb-howto`) → optional `nav.sb-subtabs` → `section.sb-sec`s, each `header.sb-sec-head` (`.sb-eyebrow`?, `h2.sb-sec-title` 22px, `.sb-sec-lede`?, `.sb-demo-launch`?) → optional `.sb-toolbar` (switches, selects, search, chips, `.sb-count`) → body (panel, table, `.sb-cards`). One `footer.sb-footer` after all pages. Overview uses `header.sb-hero` + `.sb-hero-actions` + `.sb-hero-meta` instead of a page head.

## Rules
- App bar end holds exactly Search ⌘K and the theme button (`StudyBench.themeToggle`).
- Demo launchers live only in a section head, a `.sb-demo-card`, or inside a lab bench. The "New here?" hint is `StudyBench.demoHint(row, site)`, inline at the end of the row.
- Controls never sit inside a panel body; they go in the toolbar under the section head.
- Section titles are never numbered; only topic titles carry `.sb-topic-num`.
- Topic sections use the fixed eyebrow → title pairs: Orientation → Before you start · Key concepts → Terms to know · Methods → Methods in this topic · Takeaways → What to remember · Check yourself → Quiz and flashcards.
- Lab: the bench (`.sb-bleed`) first, then `details.sb-demo-list` with a card per method.

## Section rhythm
- Every gap between two consecutive sections is `space-7` (48px), on every page and in every topic, including sections inside wrappers or side-by-side grids (grid row gap 48px).
- Nothing sits between sections: callouts, dividers and "Try" notes go inside the section they belong to (after its head).
- Only the last section of a page, topic or tab panel drops its bottom margin.

## Word limits
- Page title 3 words; section title 6 words; section lede 30 words.
