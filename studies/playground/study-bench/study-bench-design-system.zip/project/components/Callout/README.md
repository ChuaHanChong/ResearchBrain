# Callout

Short set-apart notes inside a topic: Try, Note, Takeaway, and Differs from the book.

## Variants
- `.sb-callout` (Note): background facts, definitions in passing.
- `.sb-callout--try`: one concrete thing to do in the playground above ("Set ε to 0 and press Run 50: …").
- `.sb-callout--takeaway`: the end-of-topic summary, bordered on `surface`.
- `.sb-callout--differs` (warn): where this page's numbers or behavior differ from the book, and why.

## Rules
- The key word in `.sb-callout-k` is the variant's name. No icons, no colored left borders.
- Longer material belongs in the prose.

## Word limits
- 40 words. See "Writing, notation and terminology".
