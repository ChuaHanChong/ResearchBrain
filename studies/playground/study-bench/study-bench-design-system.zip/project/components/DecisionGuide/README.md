# DecisionGuide

"Which method should I use?" as a clickable decision tree: one question at a time, the answered path stays visible as a trail you can click back into, and the result names the method, why, and links to its topic.

## Consumer provides
- `StudyBench.decide(host, tree)` with `tree = {q, why, a:[{label, next}]}` and leaves `{result, why, ref, href}`.

## Rules
- Questions are about the problem (model known? episodes end? huge state space? several agents?), never about the methods' names.
- Lives on the Compare page (last sub-tab). Every leaf links to a topic or method on this site only.

## Word limits
- Question 15 words; answers 3 words; result reason 25. See "Writing, notation and terminology".
