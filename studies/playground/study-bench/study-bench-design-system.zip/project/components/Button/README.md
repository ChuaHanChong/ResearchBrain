# Button

Buttons for running and resetting simulations, opening tools, and moving through stories.

## Variants
- `.sb-btn--primary` (`accent` fill, `on-accent` label): the ONE main action in a panel, usually Run or Train. At most one per panel.
- `.sb-btn` (default: `surface`, `line-strong` border): Step, Episode, Reset, Clear.
- `.sb-btn--ghost`: toolbar actions in the app bar and drawer heads.
- `.sb-btn--icon`: square 32px, needs `aria-label`.
- `.sb-btn--lg`: hero or empty-state call to action only.

## Rules
- Labels are verbs that say what happens: Run, Step, Run 50 episodes, Reset, Start story. Glyphs go in `.sb-glyph` (▶ ⏭ ↺ ↗) after or before the word, never alone without `aria-label`.
- While running, the primary button reads Pause; disabled buttons use `disabled`, not color.
- Don't color-code buttons per method (no blue Run, purple Watch, teal Train). Method identity lives in the data colors, not in controls.

## Word limits
- 3 words per label. See "Writing, notation and terminology".

## Touch
- On touch screens (`pointer: coarse`) buttons, selects and inputs grow to 44px tall; hover fills are switched off so taps never leave a stuck highlight.
