# GuidedTour

Guided tours and "Show me" demos: a spotlight ring around one part of the bench and a coach card with the step, title, one or two sentences and Back / Next. Used for the labs' tours and every glossary term's "Show me".

## Consumer provides
- `StudyBench.tour(steps, {title, container, scope, onEnd})` with `steps = [{target, title, text}]`; `container` is the positioned element the ring and card are placed in (the bench).
- Each step may also call your own code (load a demo, set a slider) before it shows.

## Tours ▾ in the bench bar
- `button.sb-btn` "Tours ▾" (`aria-haspopup="menu"`, unique id such as `labTourBtn`) opens `.sb-tourmenu` under the button, inside the bench: each tour shows its title (8 words), goal (15 words) and "n steps". Choosing one starts it in the bench only; it never starts the site tour.
- The tour card: one idea per step (Look at → Run it ▶ → Notice), **← Back · n of N · Next →** and ✕. It never advances by itself and has no Replay.

## Rules
- 3–8 steps per tour; Escape or ✕ ends it; focus moves into the card.
- The target scrolls into view if needed, and the card opens above the target when there is no room below.
- The spotlight never blocks the scene: people can still press Run while a tour is open.

## Word limits
- 35 words per step; title 5 words. See "Writing, notation and terminology".
