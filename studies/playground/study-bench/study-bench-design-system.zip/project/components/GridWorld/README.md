# GridWorld

Gridworld values, greedy policies and heatmaps (value functions, visit counts, TD errors). Cells are colored on the sequential scale (`seq-lo` → `seq-hi`) or the diverging scale for signed values; hover or focus a cell for its value and action.

## Consumer provides
- `StudyBench.grid(host, {rows, cols, values, min, max, scale:"seq"|"div", arrows, marks, cell, fmt, label, valueLabel, caption})`. `null` in `values` is a wall. `marks` puts short labels (S, G, T) in corners.
- Call `.update(values, arrows)` to animate sweeps (policy evaluation, value iteration, TD updates).
- Show a `.sb-scale` key next to the grid.

## Rules
- Value text picks ink or white by the cell's lightness, so it stays readable in both themes.
- Diverging scales are for signed quantities only (δ, advantages), centered on zero.

## Word limits
- Caption 35 words. See "Writing, notation and terminology".
