# FlowDiagram

A workflow or process diagram with a built-in walk-through: Play steps through the process, lighting the active box and arrow and moving a token along the edge, with one sentence per step. Use it for loops and pipelines: the agent–environment loop, the robot control loop (planner → trajectory → controller → robot → sensors), the MARL learning process, GPI.

## Consumer provides
- `StudyBench.flow(host, spec)` with `spec = {w, h, title, caption, nodes, edges, steps}`.
- `nodes`: `{id, x, y, w, h, label, sub, kind}` where `kind` is `agent`, `env`, `store` (dashed: buffers, models, tables) or `decision`. Lay nodes on a 10px grid.
- `edges`: `{from, to, label, sides:["r","l"], via:[[x,y]], dashed}`. Every edge gets a short verb or quantity label ("action Aₜ", "reward Rₜ₊₁", "writes").
- `steps`: `{on:[node ids and "from>to" edge ids], text}`. 3–7 steps.

## Rules
- Label the arrows with what moves along them. An unlabeled arrow is not allowed.
- The diagram reads left→right or top→bottom; loops close with one return edge.
- Keep node labels to three words; explanation goes in the step text.
- The caption states the claim of the picture.

## Word limits
- Node labels 3 words; 30 words per step; caption 35 words. See "Writing, notation and terminology".

## Interaction
- Play, Back and Next walk through the steps; clicking (or pressing Enter on) a box jumps to the first step that involves it.
- On narrow screens the diagram keeps a 520px minimum width and scrolls sideways, so labels never shrink below reading size.
