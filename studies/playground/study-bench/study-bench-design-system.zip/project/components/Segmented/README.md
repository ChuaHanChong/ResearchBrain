# Segmented

One-of-many switch: view switchers, world pickers, speed (Slow / Medium / Fast), mode (Explore / Guided tour / Flashcards), quiz vs flashcards.

## Consumer provides
- `<button>`s inside `.sb-seg`, each with `aria-pressed` (or `role="tab"` + `aria-selected`, or links with `aria-current`).
- `StudyBench.segmented(el, onChange)` wires single selection if you don't have your own handler.

## Rules
- Selected segment uses `control-on` + `shadow-seg`, text `ink`; others `ink-2`. Never a filled accent or dark pill.
- `.sb-seg--sm` inside dense panels. Wraps onto a second line at phone width instead of scrolling.
- Sentence case labels, no ALL CAPS.

## Word limits
- 2 words per option. See "Writing, notation and terminology".

## Keyboard
- `StudyBench.segmented(el)` makes the group one Tab stop: ← → (or ↑ ↓), Home and End move and select. Touch targets grow to 44px on touch screens.
