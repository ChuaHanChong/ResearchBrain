# DemoMode

A demonstration mode for every interactive section. **Watch** plays the whole demonstration: it scrolls to each part, spotlights it, does the action (sets a slider, presses Run) and narrates what happened, then moves on. **Guide me** walks through the same steps but gives the learner each action as a task ("Your turn: set α to 0.5"), waits until it's done and confirms it. It never moves on by itself: the learner presses Next → when ready. A task must not be already done when its step opens.

## Consumer provides
- A `▶ Watch demo` primary button and a `Guide me` button beside the section's controls (`.sb-demo-launch`).
- `StudyBench.demo(steps, {title})` with steps `{target, title, text, do(api), wait, until(), task, expect(), done}`:
  - `target`: a selector or element to spotlight.
  - `do(api)`: what Watch mode does, using `api.click(sel)`, `api.set(sel, value)`, `api.wait(ms)`, `api.until(fn, ms)`.
  - `task` + `expect()`: what Guide me asks the learner to do and how to tell it's done. `done`: the confirmation line.
  - `until()`: wait for a result (a run finishing) before narrating the next step.
- `.start("watch")` or `.start("guide")`.

## Rules
- Every playground, lab world, workflow diagram and map has a demo. 4–8 steps, and each step is one action plus one sentence about what to notice.
- Any real click or key press outside the demo bar pauses Watch ("You took over"). ← → move between steps; Esc exits; 1× / 2× / ½× speed.
- The last step always says what to try next on your own.

## Word limits
- Step title 6 words; step text 30 words; task 12 words.
