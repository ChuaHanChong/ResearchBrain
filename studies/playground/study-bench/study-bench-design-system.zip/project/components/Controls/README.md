# Controls

Parameter controls for playgrounds: labeled sliders with a live value, selects, and a mono status line.

## Consumer provides
- `.sb-field` = `<label>` text (use the book's symbol: `Step size α`, `ε`, `λ`, `View radius`), `<input type="range" class="sb-range">`, `<output>` with the formatted value.
- `.sb-select` for presets and worlds; `.sb-status` for run state (`episode 412 / 4,000 · ε 0.10`).
- Group them in `.sb-controls` inside a `.sb-panel-foot` or the bench bar.

## Rules
- Every slider shows its value in mono, with units (`rad/s`, `m`) where they exist.
- Changing a parameter mid-run either restarts the run or is blocked; say which in the caption.
- Give every control a stable `id`.
