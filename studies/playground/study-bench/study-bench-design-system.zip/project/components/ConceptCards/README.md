# ConceptCards

Key concepts as small picture cards: a 56px diagram, the name, a one-line definition, and a link to where the concept is shown working. Replaces text-only key-concept lists.

## Consumer provides
- `.sb-concepts` grid of `.sb-concept`: `.sb-concept-art` (inline SVG, token colors), `.sb-concept-name`, `.sb-concept-def`, optional link ("See it in the lab ↗").
- `data-sym` on the art when it depicts a symbol, so linked highlighting reaches it.

## Rules
- 3–8 concepts per topic. The picture shows the mechanism (an arrow from estimate to target), not a decorative icon.

## Word limits
- Definition 20 words. See "Writing, notation and terminology".
