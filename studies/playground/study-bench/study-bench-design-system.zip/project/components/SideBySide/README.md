# SideBySide

Any number of picked methods in aligned columns: the same rows (target, backup diagram, policy, what happens on a known example) so every difference sits on one line.

## Consumer provides
- `.sb-sbs` grid with a `.sb-sbs-k` label column and one `.sb-sbs-col` per method; each row is a `.sb-sbs-row` so heights align.
- The differing cell in each row gets `.is-diff` (highlighter mark on the text).

## Rules
- No limit on methods: the toolbar reads "n selected" and has **Add all** (in this family) and **Clear**; the grid scrolls sideways with the row labels sticky. Rows come from the master table's columns plus one "on the book's example" row.

## Word limits
- 12 words per cell. See "Writing, notation and terminology".
