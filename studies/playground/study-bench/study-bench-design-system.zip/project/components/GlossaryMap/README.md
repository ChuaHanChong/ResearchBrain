# GlossaryMap

The glossary as a map: terms laid out in columns by the book's parts, with arrows for "defined using". Hover a term to see what it depends on (solid) and what depends on it (dashed); click to open its card in the drawer.

## Consumer provides
- `StudyBench.dag(host, {cols, nodes:[{id,label,sub,col,row}], edges:[[from,to]], onSelect})`. `sub` is the section.
- The drawer opens on `onSelect`.
- Keyboard: arrow keys move between terms, Enter opens, Escape clears. Touch: tap to select.

## Rules
- Edges mean "you need A to define B". Keep one kind of edge per map.
- Show at most ~40 terms per view; filter by part for more.

## Word limits
- Node label 4 words. See "Writing, notation and terminology".
