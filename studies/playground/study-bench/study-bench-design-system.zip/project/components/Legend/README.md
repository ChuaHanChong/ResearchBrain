# Legend

Keys for charts, scenes and equations, using the data and role colors.

## Consumer provides
- `.sb-legend` list of `.sb-key`, each a swatch `.sb-sw` with `style="--c: var(--agent-1)"` and a label.
- Swatch shapes match the mark: `.sb-sw` (area/bar), `--line` (line), `--dash` (target, true value, training-only), `--dot` (points).

## Rules
- Series order is `data-1` … `data-7`; two-series charts use `data-1` + `data-2` (blue/orange). `data-8` means Other or baseline. Label text stays in ink; only the swatch carries color.
- Use the role aliases when a color has meaning: `agent-1`, `agent-2`, `equilibrium`, `pareto`, `q-reward`, `q-value`, `q-policy`, `q-ratio`, `q-trace`, `q-model`, `frame-x/y/z`, `vec-twist`, `vec-wrench`.
- Canvas code reads colors with `StudyBench.palette()` and redraws in `StudyBench.onThemeChange`.
