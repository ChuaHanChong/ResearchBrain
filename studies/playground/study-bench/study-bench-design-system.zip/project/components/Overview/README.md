# Overview

Page 1 of every site. It answers "where am I, and what do I do next?" in one screen, then summarizes every chapter the site covers.

## Order
1. **Hero** — the book, one lede (40 words), **Continue ▶** (last topic visited, else the first) and progress (`n of N topics studied`).
2. **Ways to study** — seven cards, one per page: Topic Explorer, Evolution, Compare, Interactive Lab, Reference, Glossary, Notation. Each card says what the page is for in 15 words.
3. **Course map** — the CourseMap engine (dependencies between topics).
4. **Chapter summaries** — one `.sb-sumcard` per chapter or part the site covers: chapter number, title, a 25-word summary, the key equation, "Key terms" chips (linked to the glossary) and **Open topic →**.

## Rules
- Summaries come only from the site's own book, cite the chapter, and use its notation.
- Sum cards are the only place a chapter is summarized; Topic Explorer pages end with Takeaways instead.

## Word limits
- Card summary 25 words; way-to-study text 15 words.
