# LineChart

Learning curves, method races and error-over-episodes plots. Hover (or focus and use ← →) for a crosshair and a tooltip with every series; endpoints are dotted and up to four series are labeled directly; a data table sits under every chart.

## Consumer provides
- `StudyBench.lineChart(host, {title, x:{label,min,max}, y:{label,min,max,fmt}, series:[{name, color, points, dash}], caption, height})`.
- The legend entries are buttons: click one to hide or show that series (at least one stays visible). Colors never shift when a series is hidden.
- On touch screens, drag across the plot to move the crosshair; vertical scrolling still works.
- `color` is a token name: `data-1`…`data-7` in order, or a role (`agent-1`, `q-value`). `dash: true` for targets, true values and baselines.
- Points share x positions across series (needed for the crosshair and the table).

## Rules
- One y-axis. Two measures of different scale are two charts.
- Series colors follow the method, never its rank; a filter that hides a series keeps the others' colors.
- An 8th series never gets a new hue: fold into `data-8` "Other" or use small multiples.
- Races: seeds must not depend on which methods are ticked; show the seed and run count in the caption.
- Curves that are not the page's own runs are labeled "Illustrative" in the caption.
- Text stays in ink; only the lines carry color.

## Word limits
- Caption 35 words. See "Writing, notation and terminology".
