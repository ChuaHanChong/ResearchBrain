# TermHover

Glossary terms inside prose get a dotted underline; hovering or focusing shows a small card with the definition, symbol and section, without leaving the page.

## Consumer provides
- `<span class="sb-term-link" tabindex="0" data-term="<key>">…</span>` around the first use of a term in each section.
- `StudyBench.terms(scope, dict)` with `dict[key] = {name, sym, def, ref}`, the same data as the Glossary page.
- Mouse: hover. Keyboard: focus. Touch: tap to open, tap again or elsewhere to close. Escape closes.

## Rules
- Link the first occurrence per section only; don't underline every word.
- The card is a preview. "Open in glossary" happens from the drawer, not the card.

## Word limits
- Card definition 25 words. See "Writing, notation and terminology".
