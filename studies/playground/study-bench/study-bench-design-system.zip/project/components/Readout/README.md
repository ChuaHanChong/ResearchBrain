# Readout

Live numeric values from a running simulation: pulls, returns, % optimal, episode, win rate.

## Consumer provides
- `.sb-readouts` grid of `.sb-readout`, each with `.sb-readout-k` (short uppercase key) and `.sb-readout-v` (value, mono, tabular), optional `.sb-readout-u` unit.
- `.is-good` / `.is-bad` on a value only when it crosses a meaningful threshold, and say so in words nearby.

## Rules
- Placeholder before a run is an en dash `–`, never `NaN`, `undefined` or `0` that isn't real.
- Fixed decimals per readout (don't let widths jump). Big-number tiles are for live values only, not decoration on landing pages.
