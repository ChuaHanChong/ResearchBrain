/* ===== Study Bench · Robot Learning — core utilities and registries =====
   Everything site-specific hangs off window.RB. Content files (topics/*.js, stations/*.js, data/*.js)
   only call the registration functions below; renderers in core/ turn the data into pages. */
(function () {
  "use strict";
  var RB = window.RB = window.RB || {};
  RB.SITE = "robot-learning";
  RB.topics = RB.topics || {};        /* id -> topic spec (see AUTHORING.md) */
  RB.topicOrder = RB.topicOrder || []; /* filled from data/topics-index.js */
  RB.stations = RB.stations || {};    /* id -> station spec */
  RB.stationOrder = RB.stationOrder || [];
  RB.terms = RB.terms || {};          /* id -> glossary term */
  RB.symbols = RB.symbols || {};      /* id -> notation symbol */
  RB.symbolOrder = RB.symbolOrder || [];
  RB.ledger = RB.ledger || [];        /* differences / provenance rows */
  RB.warnings = RB.warnings || [];

  function warn(msg) { RB.warnings.push(msg); if (window.console) console.warn("[RB] " + msg); }
  RB.warn = warn;

  /* ---------- registration ---------- */
  RB.topic = function (spec) {
    if (!spec || !spec.id) { warn("topic without id"); return; }
    if (RB.topics[spec.id] && RB.topics[spec.id].__full) warn("topic registered twice: " + spec.id);
    var base = RB.topics[spec.id] || {};
    Object.keys(spec).forEach(function (k) { base[k] = spec[k]; });
    base.__full = true;
    RB.topics[spec.id] = base;
    (spec.terms ? Object.keys(spec.terms) : []).forEach(function (k) { RB.term(k, spec.terms[k], spec.id); });
    (spec.symbols || []).forEach(function (s) { RB.symbol(s, spec.id); });
    (spec.ledger || []).forEach(function (r) { r.topic = spec.id; RB.ledger.push(r); });
  };
  RB.station = function (spec) {
    if (!spec || !spec.id) { warn("station without id"); return; }
    if (RB.stations[spec.id]) warn("station registered twice: " + spec.id);
    RB.stations[spec.id] = spec;
    (spec.terms ? Object.keys(spec.terms) : []).forEach(function (k) { RB.term(k, spec.terms[k], "lab:" + spec.id); });
    (spec.ledger || []).forEach(function (r) { r.station = spec.id; RB.ledger.push(r); });
  };
  RB.term = function (id, t, from) {
    if (RB.terms[id]) {
      /* first definition wins; later ones may add aliases, related terms and uses */
      var cur = RB.terms[id];
      (t.aliases || []).forEach(function (a) { cur.aliases = cur.aliases || []; if (cur.aliases.indexOf(a) < 0) cur.aliases.push(a); });
      (t.related || []).forEach(function (a) { cur.related = cur.related || []; if (cur.related.indexOf(a) < 0) cur.related.push(a); });
      if (!cur.from2) cur.from2 = [];
      cur.from2.push(from);
      return;
    }
    t.id = id; t.from = t.from || from; RB.terms[id] = t;
  };
  RB.symbol = function (s, from) {
    if (!s || !s.id) return;
    if (RB.symbols[s.id]) { if (from && RB.symbols[s.id].tex !== s.tex && s.tex) warn("symbol " + s.id + " redefined by " + from + " (kept the first)"); return; }
    s.from = s.from || from; RB.symbols[s.id] = s; RB.symbolOrder.push(s.id);
  };

  /* ---------- DOM helpers ---------- */
  RB.$ = function (sel, root) { return (root || document).querySelector(sel); };
  RB.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  RB.esc = function (s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); };
  RB.h = function (tag, attrs, inner) {
    var e = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) { if (attrs[k] == null || attrs[k] === false) return; if (k === "class") e.className = attrs[k]; else if (k === "text") e.textContent = attrs[k]; else e.setAttribute(k, attrs[k] === true ? "" : attrs[k]); });
    if (inner != null) { if (typeof inner === "string") e.innerHTML = inner; else if (inner.nodeType) e.appendChild(inner); else inner.forEach(function (c) { if (c) e.appendChild(typeof c === "string" ? document.createTextNode(c) : c); }); }
    return e;
  };
  RB.slug = function (s) { return String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""); };
  RB.fmt = function (v, n) { if (v == null || isNaN(v)) return "–"; var s = (+v).toFixed(n == null ? 2 : n); if (/^-0(\.0*)?$/.test(s)) s = s.slice(1); return s; };
  RB.clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

  /* Seeded random number generator (mulberry32) — every simulation on the site is reproducible. */
  RB.rng = function (seed) {
    var a = (seed >>> 0) || 1;
    var f = function () { a |= 0; a = a + 0x6D2B79F5 | 0; var t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
    f.normal = function () { var u = 1 - f(), v = f(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
    f.int = function (n) { return Math.floor(f() * n); };
    f.pick = function (arr) { return arr[Math.floor(f() * arr.length)]; };
    return f;
  };

  /* Colors for canvas/SVG drawing, resolved for the current theme. Never hard-code hex in content files. */
  RB.pal = function () {
    var P = (window.StudyBench && StudyBench.palette) ? StudyBench.palette() : {};
    var tok = function (n) { return StudyBench.token(n); };
    ["paper", "surface", "surface-sunk", "surface-strong", "bench", "bench-grid", "line", "line-strong", "ink", "ink-2", "ink-3", "accent", "accent-strong", "accent-soft", "on-accent", "good", "good-soft", "bad", "bad-soft", "warn", "warn-soft", "hl",
      "data-1", "data-2", "data-3", "data-4", "data-5", "data-6", "data-7", "data-8", "q-new", "q-changed", "q-reward", "q-value", "q-policy", "q-ratio", "q-trace", "q-model",
      "frame-x", "frame-y", "frame-z", "robot-body", "vec-twist", "vec-wrench", "seq-lo", "seq-hi", "div-neg", "div-mid", "div-pos"].forEach(function (k) { if (!P[k]) { var v = tok(k); if (v) P[k] = v; } });
    return P;
  };
  RB.onTheme = function (cb) { if (window.StudyBench && StudyBench.onThemeChange) StudyBench.onThemeChange(cb); };

  /* HiDPI canvas: returns ctx sized to css width/height */
  RB.canvas = function (cv, w, h) {
    var dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); cv.style.width = "100%"; cv.style.maxWidth = Math.min(w, Math.round(520 * w / h)) + "px"; /* v2.11: a playground scene is at most 520px tall */ cv.style.aspectRatio = w + " / " + h; cv.style.height = "auto";
    var ctx = cv.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); return ctx;
  };

  /* ---------- math ---------- */
  var mjQueue = [], mjReady = false;
  /* survey ids (P01 … P14, X1 … X3) get their paper title on hover wherever they appear in a reference chip */
  RB.annotateRefs = function (root) {
    if (!root || !RB.PAPERS) return;
    var map = {}; RB.PAPERS.forEach(function (p) { map[p.id] = p; });
    RB.$$(".sb-ref, .sb-prov, .rb-src, .rb-arch-pchip, .sb-tag", root).forEach(function (el) {
      if (el.title) return; var ids = (el.textContent.match(/\b(P\d\d|X\d)\b/g) || []).filter(function (k, i, a) { return map[k] && a.indexOf(k) === i; });
      if (ids.length) el.title = ids.map(function (k) { return k + ": " + map[k].title + (map[k].arxiv ? " (arXiv " + map[k].arxiv + ")" : ""); }).join("\n");
    });
  };
  var mjChain = Promise.resolve();
  RB.typeset = function (el) {
    if (!el) return Promise.resolve();
    try { RB.annotateRefs(el); } catch (e) { }
    if (window.MathJax && MathJax.typesetPromise && mjReady) {
      /* one typeset at a time: two overlapping typesets running together find the same \\( … \\) twice and draw it twice */
      return (mjChain = mjChain.then(function () { if (!document.contains(el)) return; return MathJax.typesetPromise([el]); }).then(function () { RB.$$(".rb-math", el).forEach(function (m) { m.classList.add("is-typeset"); }); RB.fitMath(el); }).catch(function (e) { warn("MathJax: " + e.message); }));
    }
    mjQueue.push(el); return Promise.resolve();
  };
  /* Wide equations: shrink to fit their box (down to 72%) instead of hiding the end behind a sideways scroll.
     Wider still: keep 72% and let the box scroll, with a fade on the cut edge. Re-fits whenever the box changes size. */
  var fitRO = window.ResizeObserver ? new ResizeObserver(function (es) { es.forEach(function (e) { fitOne(e.target); }); }) : null;
  function fitOne(box) {
    var c = box.querySelector("mjx-container"); if (!c || !box.clientWidth) return;
    c.style.fontSize = "";
    var need = box.scrollWidth, have = box.clientWidth;
    if (need <= have + 1) { box.classList.remove("is-cut"); return; }
    var r = Math.max(0.72, Math.floor((have - 2) / need * 100) / 100);
    c.style.fontSize = Math.round(r * 100) + "%";
    var cut = function () { box.classList.toggle("is-cut", box.scrollLeft + box.clientWidth < box.scrollWidth - 1); };
    cut(); if (!box._cutHook) { box._cutHook = true; box.addEventListener("scroll", cut, { passive: true }); }
  }
  /* any sideways-scrolling box: .is-cut while content hides past the right edge */
  var cutRO = window.ResizeObserver ? new ResizeObserver(function (es) { es.forEach(function (e) { e.target._cut && e.target._cut(); }); }) : null;
  RB.watchCut = function (root) {
    RB.$$(".sb-scroll-x, .rb-fig-scroll", root || document).forEach(function (box) {
      if (box._cut) return box._cut();
      box._cut = function () { box.classList.toggle("is-cut", box.scrollLeft + box.clientWidth < box.scrollWidth - 2); };
      box.addEventListener("scroll", box._cut, { passive: true }); if (cutRO) cutRO.observe(box); box._cut();
    });
  };
  window.addEventListener("hashchange", function () { setTimeout(function () { RB.watchCut(); }, 400); });
  window.addEventListener("load", function () { setTimeout(function () { RB.watchCut(); }, 1500); });
  RB.fitMath = function (root) {
    RB.$$("mjx-container[display], .rb-math mjx-container, .sb-eq-math mjx-container", root).forEach(function (c) {
      var box = c.parentElement; while (box && box !== root.parentElement && !/(auto|scroll)/.test(getComputedStyle(box).overflowX)) box = box.parentElement;
      if (!box || box === root.parentElement || box.querySelectorAll("mjx-container").length > 1) return;
      if (box._fit) return; box._fit = true; fitOne(box); if (fitRO) fitRO.observe(box);
    });
  };
  window.MathJax = window.MathJax || {
    tex: { inlineMath: [["\\(", "\\)"]], displayMath: [["\\[", "\\]"]], packages: { "[+]": ["html"] } },
    svg: { fontCache: "global" },
    loader: { load: ["[tex]/html"] },
    startup: {
      typeset: false,
      ready: function () {
        MathJax.startup.defaultReady(); mjReady = true;
        var q = mjQueue.slice(); mjQueue = [];
        q.forEach(function (el) { if (document.contains(el)) RB.typeset(el); });
      }
    }
  };
  /* Inline TeX span; display math is wrapped so it scrolls sideways inside .sb-eq-math */
  RB.tex = function (tex, display) { return '<span class="rb-math" tabindex="0" role="region" aria-label="Equation, scrolls sideways">' + (display === false ? "\\(" + tex + "\\)" : "\\[" + tex + "\\]") + "</span>"; };
  RB.itex = function (tex) { return "\\(" + tex + "\\)"; };

  /* An equation block with In words + symbol key (EquationKey).
     spec: {name, ref, no, tex, words, key:[{sym: id, glyph, meaning}] | ["id", ...], diff: true} */
  RB.eqBlock = function (spec, opts) {
    opts = opts || {};
    var head = (spec.name || spec.ref) ? '<div class="sb-eq-head">' + (spec.term ? '<span class="sb-term-link" tabindex="0" role="button" data-term="' + spec.term + '">' + RB.esc(spec.name) + "</span>" : RB.esc(spec.name || "")) + (spec.ref ? ' <span class="sb-ref">' + RB.esc(spec.ref) + "</span>" : "") + (spec.prov ? ' <span class="sb-prov">' + RB.esc(spec.prov) + "</span>" : "") + "</div>" : "";
    var rows = "";
    if (spec.before) rows += '<div class="sb-eq-row"><span class="sb-eq-k">' + (spec.beforeLabel || "Before") + '</span><div class="sb-eq-math">' + RB.tex(spec.before) + "</div></div>";
    rows += '<div class="sb-eq-row' + (spec.before ? "" : " rb-eq-row1") + '">' + (spec.before ? '<span class="sb-eq-k">' + (spec.afterLabel || "After") + "</span>" : "") + '<div class="sb-eq-math">' + RB.tex(spec.tex) + "</div>" + (spec.no ? '<span class="sb-eq-no">' + RB.esc(spec.no) + "</span>" : "") + "</div>";
    var words = spec.words ? '<p class="sb-eqwords"><b>In words:</b> ' + spec.words + "</p>" : "";
    var key = RB.eqKey(spec.key);
    var diffKey = spec.diff ? '<p class="sb-eq-key"><span class="sb-eq-new">new term</span> <span class="sb-eq-chg">changed term</span></p>' : "";
    return '<div class="sb-eq' + (opts.cls ? " " + opts.cls : "") + '"' + (spec.id ? ' id="' + spec.id + '"' : "") + ">" + head + rows + diffKey + words + key + (spec.fig ? '<figure class="sb-fig rb-eq-fig">' + spec.fig + (spec.figCap ? '<figcaption class="sb-caption">' + spec.figCap + "</figcaption>" : "") + "</figure>" : "") + "</div>";
  };
  RB.eqKey = function (key) {
    if (!key || !key.length) return "";
    return '<ul class="sb-eqkey" data-no-autolink aria-label="Symbols in this equation">' + key.map(function (k) {
      if (typeof k === "string") { var s = RB.symbols[k]; if (!s) { warn("unknown symbol id in key: " + k); return ""; } k = { sym: k, glyph: s.tex ? RB.itex(s.tex) : s.glyph, meaning: s.short || s.meaning }; }
      var s2 = k.sym && RB.symbols[k.sym];
      var glyph = k.glyph || (s2 ? (s2.tex ? RB.itex(s2.tex) : s2.glyph) : k.sym);
      /* plain-text glyphs written with _ or ^ (v_θ, a_t) are typeset as math so they match the equation above */
      if (glyph && /[_^]/.test(glyph) && glyph.indexOf("\\(") < 0 && !/<[a-z]/i.test(glyph)) glyph = RB.itex(glyph.replace(/([_^])([^{}_^\s,]{2,})/g, "$1{$2}"));  /* e_ee → e_{ee}: a multi-letter subscript stays one subscript */
      var meaning = k.meaning || (s2 ? (s2.short || s2.meaning) : "");
      return "<li" + (k.sym ? ' data-sym="' + k.sym + '"' : "") + '><span class="sb-eqkey-sym">' + glyph + "</span> " + meaning + "</li>";
    }).join("") + "</ul>";
  };

  /* ---------- small UI builders shared by pages ---------- */
  RB.secHead = function (o) {
    return '<header class="sb-sec-head">' + (o.eyebrow ? '<p class="sb-eyebrow">' + o.eyebrow + "</p>" : "") +
      "<" + (o.level || "h3") + ' class="sb-sec-title"' + (o.id ? ' id="' + o.id + '"' : "") + ">" + o.title + (o.anchor ? ' <a class="sb-anchor" href="' + o.anchor + '" aria-label="Link to this section">#</a>' : "") + "</" + (o.level || "h3") + ">" +
      (o.lede ? '<p class="sb-sec-lede">' + o.lede + "</p>" : "") + (o.demo ? RB.demoLaunch(o.demo, o.demoMeta) : "") + "</header>";
  };
  RB.demoLaunch = function (id, meta) {
    return '<div class="sb-demo-launch" data-demo="' + id + '"><button class="sb-btn sb-btn--primary" type="button" data-demo-watch="' + id + '">▶ Watch demo</button><button class="sb-btn" type="button" data-demo-guide="' + id + '">Guide me</button>' + (meta ? '<span class="sb-caption">' + meta + "</span>" : "") + "</div>";
  };
  RB.panel = function (o) {
    return '<div class="sb-panel"' + (o.id ? ' id="' + o.id + '"' : "") + ">" + ((o.title || o.eyebrow || o.meta || o.ref) ? '<div class="sb-panel-head">' + (o.eyebrow ? '<span class="sb-eyebrow' + (o.live ? " sb-eyebrow--live" : "") + '">' + o.eyebrow + "</span>" : "") + (o.title ? '<h4 class="sb-panel-title">' + o.title + "</h4>" : "") + (o.ref ? '<span class="sb-ref">' + o.ref + "</span>" : "") + (o.prov ? '<span class="sb-prov">' + o.prov + "</span>" : "") + (o.meta ? '<span class="sb-panel-meta">' + o.meta + "</span>" : "") + "</div>" : "") +
      '<div class="sb-panel-body">' + (o.body || "") + "</div>" + (o.foot ? '<div class="sb-panel-foot">' + o.foot + "</div>" : "") + "</div>";
  };
  RB.callout = function (kind, text) {
    var k = { try: "Try", note: "Note", takeaway: "Takeaway", differs: "Differs from the source" }[kind] || "Note";
    return '<div class="sb-callout' + (kind && kind !== "note" ? " sb-callout--" + kind : "") + '"><span class="sb-callout-k">' + k + "</span><span>" + text + "</span></div>";
  };
  RB.slider = function (o) {
    /* {id, label, min, max, step, value, fmt(v) -> string} */
    var f = o.fmt || function (v) { return v; };
    return '<label class="sb-field" for="' + o.id + '"><span>' + o.label + '</span><input class="sb-range" type="range" id="' + o.id + '" min="' + o.min + '" max="' + o.max + '" step="' + (o.step || 1) + '" value="' + o.value + '"><output for="' + o.id + '" data-out="' + o.id + '">' + f(o.value) + "</output></label>";
  };
  /* wire a slider built with RB.slider: calls cb(value) on input and keeps the output text in sync */
  RB.bindSlider = function (root, id, fmt, cb) {
    var inp = root.querySelector("#" + id), out = root.querySelector('[data-out="' + id + '"]');
    if (!inp) { warn("slider not found: " + id); return; }
    var f = fmt || function (v) { return v; };
    inp.addEventListener("input", function () { var v = +inp.value; if (out) out.textContent = f(v); cb(v); });
    return inp;
  };
  RB.seg = function (o) {
    /* {id, label, options:[{value,label}], value} */
    return '<div class="sb-seg sb-seg--sm" role="group" aria-label="' + RB.esc(o.label) + '" id="' + o.id + '">' + o.options.map(function (x) { return '<button type="button" value="' + x.value + '" aria-pressed="' + (x.value === o.value) + '">' + x.label + "</button>"; }).join("") + "</div>";
  };
  RB.bindSeg = function (root, id, cb) {
    var el = root.querySelector("#" + id); if (!el) { warn("seg not found: " + id); return; }
    StudyBench.segmented(el, function (v) { cb(v); });
    return el;
  };
  RB.readouts = function (items) {
    /* [{id, k, u}] */
    return '<div class="sb-readouts" data-no-autolink>' + items.map(function (r) { return '<div class="sb-readout"><span class="sb-readout-k">' + r.k + '</span><span class="sb-readout-v" data-ro="' + r.id + '">–</span>' + (r.u ? '<span class="sb-readout-u">' + r.u + "</span>" : "") + "</div>"; }).join("") + "</div>";
  };
  RB.setRO = function (root, id, v) { var e = root.querySelector('[data-ro="' + id + '"]'); if (e) e.textContent = v; };
  RB.legend = function (items) {
    /* [{c: token, label, kind: line|dash|dot|area}] */
    return '<ul class="sb-legend">' + items.map(function (i) { return '<li class="sb-key"><span class="sb-sw' + (i.kind && i.kind !== "area" ? " sb-sw--" + i.kind : "") + '" style="--c: var(--' + i.c + ')"></span>' + i.label + "</li>"; }).join("") + "</ul>";
  };

  /* ---------- sources ---------- */
  RB.paper = function (id) { return (RB.PAPERS || []).filter(function (p) { return p.id === id; })[0]; };
  RB.method = function (id) { return RB.M && RB.M[id]; };
  RB.methodsFor = function (topicId) { return (RB.METHODS || []).filter(function (m) { return m.topic === topicId.toUpperCase() && !m.alias_of; }); };
  RB.arxivLink = function (m) { if (!m) return ""; var u = m.arxiv ? "https://arxiv.org/abs/" + m.arxiv : m.url; return u ? '<a class="sb-link" href="' + RB.esc(u) + '" target="_blank" rel="noopener">' + (m.arxiv ? "arXiv " + m.arxiv : "Paper") + " ↗</a>" : ""; };
  RB.coverageTag = function (m) {
    if (!m) return "";
    if (m.coverage !== "primary") return '<span class="sb-prov" title="No paper found; described from the surveys only">Survey only</span>';
    return '<span class="sb-prov" title="' + (m.tier === 1 ? "Read in full from the method paper" : "Fact card from the method paper") + '">' + (m.tier === 1 ? "Read in full" : "Fact card") + "</span>";
  };
})();
