/* Blueprint: the whole model, layer by layer, in the style of Sebastian Raschka's LLM architecture figures.
   Each network is a grey "tower": input at the bottom, the repeated block drawn once inside a coloured frame with N ×,
   residual lines and ⊕ nodes, side inputs (RoPE, FiLM, AdaLN) on the left, dotted callouts with the key numbers on the right,
   and numbered zoom-ins (feed-forward, attention heads, FiLM, AdaLN) below. Data: spec.blueprint (see data/arch/*.js). */
(function () {
  var RB = window.RB, esc = RB.esc;
  var MK = "rbbpA", MKN = 0;
  var PW = 172, PH = 28, GAP = 16, ADDH = 18, BPAD = 16, CPAD = 18, LZ = 116, CW = 256, RZ = 150;

  function roleC(s, modId) { var m = (s.modules || []).filter(function (x) { return x.id === modId; })[0]; var R = m && RB.ARCH_ROLE[m.role] || RB.ARCH_ROLE.net; return R.c; }
  function ctext(c) { return Array.isArray(c) ? String(c[0]) : String(c || ""); }
  function wrap(t, n) { var w = String(t).split(" "), out = [], cur = ""; w.forEach(function (x) { if ((cur + " " + x).trim().length > n && cur) { out.push(cur); cur = x; } else cur = (cur + " " + x).trim(); }); if (cur) out.push(cur); return out; }
  function numSpans(line) {
    return esc(line).replace(/(\d(?:[\d,.]*\d)?(?:\s?[kKMB](?![\w_]))?(?:\s?[×x](?![\w_]))?)/g, '<tspan class="rb-bp-num">$1</tspan>');
  }
  function hRow(r) {
    if (r.t === "block" || r.t === "group") return BPAD + r.rows.reduce(function (a, x, i) { return a + hRow(x) + (i ? GAP : 0); }, 0) + BPAD + (r.t === "group" ? 14 : 0);
    return r.t === "add" ? ADDH : PH;
  }
  function towerW(t) { return (t.compact ? LZ - 20 : LZ) + CW + (t.compact ? RZ - 30 : RZ); }

  /* ---------- zoom-in templates ---------- */
  function zoomSVG(z, c) {
    var o = "", W = 250, H = 150;
    function pill(x, y, w, label, cls) { return '<rect class="rb-bp-pill ' + (cls || "") + '" x="' + (x - w / 2) + '" y="' + y + '" width="' + w + '" height="24" rx="6"/><text class="rb-bp-pt" x="' + x + '" y="' + (y + 16) + '" text-anchor="middle">' + esc(label) + "</text>"; }
    function arrow(x1, y1, x2, y2) { return '<line class="rb-bp-ln" x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '" marker-end="url(#' + MK + ')"/>'; }
    if (z.k === "glu") {
      W = 280; H = 190;
      var L = "Linear " + (z.d || "d") + " → " + (z.ff || "ff");
      o += pill(72, 140, 128, L) + arrow(72, 140, 72, 110) + pill(72, 84, 128, (z.act || "GELU") + " activation") + pill(208, 84, 128, L);
      o += '<circle class="rb-bp-op" cx="140" cy="58" r="8"/><text class="rb-bp-opt" x="140" y="62" text-anchor="middle">×</text>';
      o += '<path class="rb-bp-ln" d="M72 84 V58 H132"/><path class="rb-bp-ln" d="M208 84 V58 H148"/><path class="rb-bp-ln" d="M72 186 V166" marker-end="url(#' + MK + ')"/><path class="rb-bp-ln" d="M72 176 H208 V110" marker-end="url(#' + MK + ')"/><text class="rb-bp-cap" x="84" y="188">x</text>';
      o += arrow(140, 50, 140, 34) + pill(140, 8, 150, "Linear " + (z.ff || "ff") + " → " + (z.d || "d"));
    } else if (z.k === "mlp") {
      H = 136;
      o += pill(125, 100, 170, "Linear " + (z.d || "d") + " → " + (z.ff || "ff")) + arrow(125, 100, 125, 80) + pill(125, 54, 170, (z.act || "GELU") + " activation") + arrow(125, 54, 125, 34) + pill(125, 8, 170, "Linear " + (z.ff || "ff") + " → " + (z.d || "d"));
    } else if (z.k === "heads") {
      var q = z.q, kv = z.kv, show = Math.min(q, 8), bw = 22, gx = 12, x0 = W / 2 - (show * (bw + 4) - 4) / 2, kvShow = Math.min(kv, 8), kx0 = W / 2 - (kvShow * (bw + 4) - 4) / 2;
      H = 150;
      for (var i = 0; i < show; i++) {
        var qx = x0 + i * (bw + 4) + bw / 2, g = Math.floor(i * kvShow / show), kx = kx0 + g * (bw + 4) + bw / 2;
        o += '<line class="rb-bp-ln is-thin" x1="' + qx + '" y1="44" x2="' + kx + '" y2="92"/>';
        o += '<rect class="rb-bp-q" x="' + (qx - bw / 2) + '" y="22" width="' + bw + '" height="22" rx="4"/>';
      }
      for (var j = 0; j < kvShow; j++) o += '<rect class="rb-bp-kv" x="' + (kx0 + j * (bw + 4)) + '" y="92" width="' + bw + '" height="22" rx="4"/>';
      o += '<text class="rb-bp-cap" x="' + (W / 2) + '" y="14" text-anchor="middle">' + esc(q + " query heads" + (q > show ? " (8 drawn)" : "")) + "</text>";
      o += '<text class="rb-bp-cap" x="' + (W / 2) + '" y="132" text-anchor="middle">' + esc(kv + " key/value head" + (kv > 1 ? "s" : "") + (kv > kvShow ? " (8 drawn)" : "") + (z.hd ? " · dim " + z.hd : "")) + "</text>";
      o += '<text class="rb-bp-cap is-strong" x="' + (W / 2) + '" y="146" text-anchor="middle">' + esc(kv === 1 ? "Multi-query attention" : kv === q ? "Multi-head attention" : "Grouped-query attention") + "</text>";
    } else if (z.k === "film") {
      H = 160;
      o += pill(70, 124, 110, "Conv block out x") + pill(190, 124, 100, "cond c") + arrow(190, 124, 190, 102) + pill(190, 76, 110, z.proj || "Mish → Linear") + '<text class="rb-bp-cap" x="190" y="64" text-anchor="middle">split → γ, β</text>';
      o += '<circle class="rb-bp-op" cx="70" cy="80" r="8"/><text class="rb-bp-opt" x="70" y="84" text-anchor="middle">×</text><circle class="rb-bp-op" cx="70" cy="40" r="8"/><text class="rb-bp-opt" x="70" y="44" text-anchor="middle">+</text>';
      o += arrow(70, 124, 70, 90) + arrow(70, 72, 70, 50) + '<path class="rb-bp-ln" d="M150 70 H80" marker-end="url(#' + MK + ')"/><path class="rb-bp-ln" d="M190 58 V40 H80" marker-end="url(#' + MK + ')"/>' + '<text class="rb-bp-cap" x="116" y="66">γ</text><text class="rb-bp-cap" x="130" y="36">β</text>' + arrow(70, 32, 70, 12) + '<text class="rb-bp-cap is-strong" x="96" y="12">γ ⊙ x + β</text>';
    } else if (z.k === "adaln") {
      H = 150;
      o += pill(125, 112, 200, "cond = [obs ‖ emb(tₐ) ‖ emb(tₒ′)]") + arrow(125, 112, 125, 90) + pill(125, 64, 150, "SiLU → Linear → 6 × " + (z.d || "d")) + arrow(125, 64, 125, 44);
      ["shift₁", "scale₁", "gate₁", "shift₂", "scale₂", "gate₂"].forEach(function (l, i) { o += '<rect class="rb-bp-kv" x="' + (22 + i * 36) + '" y="14" width="32" height="24" rx="4"/><text class="rb-bp-cap" x="' + (38 + i * 36) + '" y="30" text-anchor="middle">' + l + "</text>"; });
    }
    else if (z.k === "moe") {
      var ne = z.experts || 8, sh = Math.min(ne, 5); H = 150;
      o += pill(125, 116, 110, "Router (top-" + (z.topk || 2) + ")") + '<circle class="rb-bp-op" cx="125" cy="14" r="8"/><text class="rb-bp-opt" x="125" y="18" text-anchor="middle">+</text>';
      for (var e = 0; e < sh; e++) { var ex = 30 + e * 48; o += '<rect class="rb-bp-pill is-ffn" x="' + ex + '" y="56" width="42" height="24" rx="5"/><text class="rb-bp-pt" x="' + (ex + 21) + '" y="72" text-anchor="middle">' + (e === sh - 1 && ne > sh ? ne : e + 1) + "</text>" + '<line class="rb-bp-ln is-thin" x1="125" y1="116" x2="' + (ex + 21) + '" y2="80"/><line class="rb-bp-ln is-thin" x1="' + (ex + 21) + '" y1="56" x2="125" y2="22"/>'; }
      o += '<text class="rb-bp-cap" x="125" y="146" text-anchor="middle">' + esc((z.caption || ne + " experts, " + (z.topk || 2) + " active per token")) + "</text>";
    } else if (z.k === "rows") {
      var rs = (z.rows || []).slice().reverse(); H = rs.length * 34 + 6;
      rs.forEach(function (r, i) { var y = i * 34; o += pill(125, y + 4, 210, r); if (i < rs.length - 1) o += arrow(125, y + 58, 125, y + 30); });
    }
    return { svg: o, w: W, h: H };
  }

  /* ---------- one tower ---------- */
  function drawTower(s, t, x0, yBase, ctx) {
    var c = t.c || roleC(s, t.mod), lz = t.compact ? LZ - 20 : LZ, cx = x0 + lz + CW / 2, cl = x0 + lz, cr = cl + CW, o = "", rows = t.rows || [];
    var inner = rows.reduce(function (a, r, i) { return a + hRow(r) + (i ? GAP : 0); }, 0), contH = CPAD * 2 + inner;
    var inY = yBase - 26, contBottom = inY - 30, contTop = contBottom - contH, pos = {}, calls = [];
    /* input pill and caption below */
    o += '<text class="rb-bp-inl" x="' + cx + '" y="' + yBase + '" text-anchor="middle">' + esc(t.input && t.input.caption || "") + "</text>";
    o += '<line class="rb-bp-ln" x1="' + cx + '" y1="' + (inY - 4) + '" x2="' + cx + '" y2="' + (contBottom + 1) + '"/>';
    o += '<rect class="rb-bp-pill is-io" x="' + (cx - PW / 2) + '" y="' + (inY - 4 - PH) + '" width="' + PW + '" height="' + PH + '" rx="7"/><text class="rb-bp-pt" x="' + cx + '" y="' + (inY - 4 - PH + 18) + '" text-anchor="middle">' + esc(t.input && t.input.label || "Input") + "</text>";
    pos.input = { l: cx - PW / 2, r: cx + PW / 2, y: inY - 4 - PH / 2 };
    /* container */
    var body = "", spine = "";
    function place(list, yb, depth) {
      var bottoms = [];
      list.forEach(function (r, i) {
        var h = hRow(r), top = yb - h, mid = top + h / 2;
        bottoms.push(yb);
        if (r.t === "block" || r.t === "group") {
          var fx = cx - PW / 2 - 24 + depth * 7, fw = PW + 48 - depth * 14;
          body += '<rect class="rb-bp-frame' + (r.t === "group" ? " is-group" : "") + '" style="--c:var(--' + c + ')" x="' + fx + '" y="' + top + '" width="' + fw + '" height="' + h + '" rx="14"/>';
          if (r.label) body += '<text class="rb-bp-ft" x="' + (fx + 10) + '" y="' + (top + 12) + '">' + esc(r.label) + "</text>";
          if (r.n) {
            body += '<path class="rb-bp-brace" style="--c:var(--' + c + ')" d="M' + (fx - 6) + " " + (top + 8) + " q -6 0 -6 8 V " + (mid - 6) + " q 0 6 -6 6 q 6 0 6 6 V " + (top + h - 16) + " q 0 8 6 8" + '"/>';
            body += '<text class="rb-bp-n" style="--c:var(--' + c + ')" x="' + (fx - 16) + '" y="' + (mid + 5) + '" text-anchor="end">' + esc(r.n) + " ×</text>";
          }
          place(r.rows, yb - BPAD - (r.t === "group" ? 0 : 0), depth + 1);
        } else if (r.t === "add") {
          body += '<circle class="rb-bp-op" cx="' + cx + '" cy="' + mid + '" r="8"/><text class="rb-bp-opt" x="' + cx + '" y="' + (mid + 4) + '" text-anchor="middle">+</text>';
          if (r.span) { var ys = bottoms[i - r.span] + GAP / 2, rx = cx + PW / 2 + 8; body += '<path class="rb-bp-ln" d="M' + cx + " " + ys + " H" + rx + " V" + mid + " H" + (cx + 9) + '" marker-end="url(#' + MK + ')"/>'; }
        } else {
          var cls = { attn: "is-attn", ffn: "is-ffn", moe: "is-ffn", film: "is-cond", adaln: "is-cond", norm: "is-norm" }[r.t] || "";
          body += '<g class="rb-bp-row"><rect class="rb-bp-pill ' + cls + '" style="--c:var(--' + c + ')" x="' + (cx - PW / 2) + '" y="' + top + '" width="' + PW + '" height="' + PH + '" rx="7"/>';
          wrap(r.label, 27).slice(0, 2).forEach(function (l, j, arr) { body += '<text class="rb-bp-pt' + (r.t === "attn" ? " is-inv" : "") + '" x="' + cx + '" y="' + (mid + 4 - (arr.length - 1) * 6 + j * 12) + '" text-anchor="middle">' + esc(l) + "</text>"; });
          if (r.zoom) { var k = ctx.zooms.length + 1; ctx.zooms.push({ z: r.zoom, c: c, tower: t.title, mod: t.mod, row: r.label, k: k }); body += '<circle class="rb-bp-badge" style="--c:var(--' + c + ')" cx="' + (cx + PW / 2) + '" cy="' + top + '" r="9"/><text class="rb-bp-bt" x="' + (cx + PW / 2) + '" y="' + (top + 4) + '" text-anchor="middle">' + k + "</text>"; }
          if (r.loop) body += '<path class="rb-bp-ln" d="M' + (cx + PW / 2) + " " + (mid - 6) + " h 14 v 12 h -12" + '" marker-end="url(#' + MK + ')"/><text class="rb-bp-ts" x="' + (cx + PW / 2 + 18) + '" y="' + (mid + 4) + '">' + esc(r.loop === true ? "t → t+1" : r.loop) + "</text>";
          if (r.note) body += "<title>" + esc(r.note) + "</title>";
          body += "</g>";
          if (r.side) {
            var sw = 92, sx = cl - lz + 8;
            body += '<rect class="rb-bp-pill is-side" x="' + sx + '" y="' + (mid - 12) + '" width="' + sw + '" height="24" rx="6"/><text class="rb-bp-pt" x="' + (sx + sw / 2) + '" y="' + (mid + 4) + '" text-anchor="middle">' + esc(r.side) + "</text>";
            body += '<line class="rb-bp-ln" x1="' + (sx + sw) + '" y1="' + mid + '" x2="' + (cx - PW / 2 - 2) + '" y2="' + mid + '" marker-end="url(#' + MK + ')"/>';
            pos[(r.id || "") + ":side"] = { x: sx, y: mid };
          }
          if (r.call) calls.push({ y: mid + (r.callDy || 0), ly: mid, x: cx + PW / 2, text: ctext(r.call), src: Array.isArray(r.call) ? r.call.slice(1) : [] });
          if (r.id) pos[r.id] = { l: cx - PW / 2, r: cx + PW / 2, y: mid };
        }
        yb = top - GAP;
      });
    }
    place(rows, contBottom - CPAD, 0);
    o += '<rect class="rb-bp-cont" x="' + cl + '" y="' + contTop + '" width="' + CW + '" height="' + contH + '" rx="18"/>';
    spine = '<line class="rb-bp-ln" x1="' + cx + '" y1="' + (contBottom - 2) + '" x2="' + cx + '" y2="' + (contTop - 34) + '" marker-end="url(#' + MK + ')"/>';
    o += spine + body;
    /* output caption beside the arrow tip */
    var outLines = wrap(t.output && t.output.label || "", 26);
    outLines.forEach(function (l, j) { o += '<text class="rb-bp-inl" x="' + (cx + 10) + '" y="' + (contTop - 26 + j * 13 - (outLines.length - 1) * 13) + '">' + esc(l) + "</text>"; });
    /* callouts on the right, pushed down to avoid overlap (placed top to bottom) */
    calls.sort(function (a, b) { return a.y - b.y; });
    var lastBottom = -1e9, tx = cr + 12, rz = t.compact ? RZ - 30 : RZ;
    calls.forEach(function (k) {
      var lines = wrap(k.text, Math.floor((rz - 12) / 7.3)), hh = lines.length * 14, ty = Math.max(k.y - hh / 2 + 10, lastBottom + 8);
      o += '<path class="rb-bp-lead" d="M' + (k.x + 2) + " " + (k.ly + (k.ly !== k.y ? -6 : 0)) + " L" + (tx - 3) + " " + (ty + hh / 2 - 7) + '"/>';
      o += "<g>" + (k.src.length ? "<title>" + esc("Source: " + k.src.map(function (x) { var v = s.sources[x]; return v ? (v.kind === "code" ? v.repo + "/" + v.path : v.ref) : x; }).join("; ")) + "</title>" : "");
      lines.forEach(function (l, j) { o += '<text class="rb-bp-call" style="--c:var(--' + c + ')" x="' + tx + '" y="' + (ty + j * 14) + '">' + numSpans(l) + "</text>"; });
      o += "</g>";
      lastBottom = ty + hh - 8;
    });
    var below = !!ctx.below[t.mod], ttY = below ? yBase + 30 : contTop - 26 - outLines.length * 13 - 30;
    o += '<text class="rb-bp-tt" style="--c:var(--' + c + ')" x="' + cx + '" y="' + ttY + '" text-anchor="middle">' + esc(t.title) + "</text>" + (t.sub ? '<text class="rb-bp-ts" x="' + cx + '" y="' + (ttY + 16) + '" text-anchor="middle">' + esc(t.sub) + "</text>" : "");
    return { svg: '<g class="rb-bp-tower" data-tower="' + t.mod + '">' + o + '</g>', pos: pos, top: below ? contTop - 26 - outLines.length * 13 - 20 : ttY - 22, bottom: below ? ttY + 24 : yBase + 6, cx: cx, outY: contTop - 34, x0: x0, w: towerW(t), c: c, t: t };
  }

  function tHeight(t) { return (t.rows || []).reduce(function (a, r, i) { return a + hRow(r) + (i ? GAP : 0); }, 0) + CPAD * 2; }

  /* Two feeders on the same side of one target make the far one's link cross the near tower (long, through a box).
     Put the far feeder on the target's other side instead, when that feeder has no other link to keep it in place. */
  /* Feeder placement. Two feeders on the same side of one target make the far one's link cross the near tower.
     - Into a side input (FiLM, cross-attention: drawn as a box on the target's left): every feeder goes on the left and they share the line.
     - Into anything else (the input box, a row): the far feeder moves to the target's other side.
     A feeder with another link of its own stays where the author put it. */
  function arrange(towers, links) {
    var order = towers.slice(), idx = function (m) { for (var i = 0; i < order.length; i++) if (order[i].mod === m) return i; return -1; };
    var deg = {}; links.forEach(function (l) { deg[l.from] = (deg[l.from] || 0) + 1; deg[l.to] = (deg[l.to] || 0) + 1; });
    function findRow(rows, id) { for (var i = 0; i < (rows || []).length; i++) { var r = rows[i]; if (r.id === id) return r; var q = findRow(r.rows, id); if (q) return q; } return null; }
    var groups = {};
    links.forEach(function (l) {
      var t = order[idx(l.to)], r = t && findRow(t.rows, l.toRow), side = !!(r && r.side);
      var k = l.to + "|" + (side ? "side" : "any"); (groups[k] = groups[k] || { to: l.to, side: side, F: [] }).F.push(l.from);
    });
    /* a side input sits on the target's left: its feeders belong on the left, so other feeders of that target go right */
    Object.keys(groups).forEach(function (k) {
      var g = groups[k]; if (!g.side) return;
      g.F.filter(function (f) { return deg[f] === 1 && idx(f) > idx(g.to); }).forEach(function (f) { var t = order.splice(idx(f), 1)[0]; order.splice(idx(g.to), 0, t); });
      var other = groups[g.to + "|any"];
      if (other) other.F.filter(function (f) { return deg[f] === 1 && idx(f) < idx(g.to); }).forEach(function (f) { var t = order.splice(idx(f), 1)[0]; order.splice(idx(g.to) + 1, 0, t); });
    });
    Object.keys(groups).forEach(function (k) {
      var g = groups[k]; if (g.F.length < 2) return;
      var movable = g.F.filter(function (f) { return deg[f] === 1; });
      if (g.side) {
        movable.forEach(function (f) { if (idx(f) > idx(g.to)) { var t = order.splice(idx(f), 1)[0]; order.splice(idx(g.to), 0, t); } });
        return;
      }
      var ti = idx(g.to), L = g.F.filter(function (f) { return idx(f) < ti; }), R = g.F.filter(function (f) { return idx(f) > ti; });
      var sideList = L.length >= 2 && !R.length ? L : R.length >= 2 && !L.length ? R : null; if (!sideList) return;
      var far = sideList.filter(function (f) { return deg[f] === 1; }).sort(function (p, q) { return Math.abs(idx(q) - ti) - Math.abs(idx(p) - ti); })[0];
      if (!far || Math.abs(idx(far) - ti) < 2) return;
      var t = order.splice(idx(far), 1)[0]; ti = idx(g.to);
      order.splice(sideList === L ? ti + 1 : ti, 0, t);
    });
    return order;
  }

  function blueprint(s, o) {
    o = o || {}; var B = s.blueprint; if (!B) return ""; MK = "rbbp" + (++MKN);
    var towers = arrange(B.towers, B.links || []), X = {}, base = {}, x = 10, Y0 = 1000;
    towers.forEach(function (t, i) { X[t.mod] = x; base[t.mod] = Y0; x += towerW(t) + (i < towers.length - 1 ? 28 : 0); });
    var below = {}; (B.links || []).forEach(function (l) { below[l.from] = 1; });
    function measure(mod) { var t = towers.filter(function (q) { return q.mod === mod; })[0]; return drawTower(s, t, X[mod], base[mod], { zooms: [], below: below }); }
    /* 1) rows joined by shared attention sit on one line */
    (B.shared || []).forEach(function (l) { var a = measure(l.a[0]), b = measure(l.b[0]), pa = a.pos[l.a[1]], pb = b.pos[l.b[1]]; if (pa && pb) base[l.b[0]] += pa.y - pb.y; });
    /* 2) a feeding tower is moved up or down so its output arrow ends just below the row it feeds: short elbows, no detours */
    /*    Chains (A feeds B, B feeds C) need several passes: moving B after A was placed would undo A's elbow. Sinks never move,
          so repeating until nothing changes settles every feeder relative to its (already settled) target. */
    for (var pass = 0; pass < 8; pass++) {
      var moved = 0;
      (B.links || []).forEach(function (l) { var a = measure(l.from), b = measure(l.to), tg = b.pos[l.toRow + ":side"] || b.pos[l.toRow]; if (!tg) return; var d = (tg.y + 22) - a.outY; if (Math.abs(d) > 0.5) { base[l.from] += d; moved++; } });
      if (!moved) break;
    }
    var ctx = { zooms: [], below: below }, parts = [], T = {};
    towers.forEach(function (t) { var r = drawTower(s, t, X[t.mod], base[t.mod], ctx); T[t.mod] = r; parts.push(r.svg); });
    var W = x + 10, top = Math.min.apply(null, towers.map(function (t) { return T[t.mod].top; })), bottom = Math.max.apply(null, towers.map(function (t) { return T[t.mod].bottom; })), links = "";
    (B.links || []).forEach(function (l) {
      var a = T[l.from], b = T[l.to]; if (!a || !b) return;
      var tg = b.pos[l.toRow + ":side"] || b.pos[l.toRow]; if (!tg) return;
      var right = a.cx > b.cx, tx = right ? (tg.r != null ? tg.r : tg.x + 92) : (tg.x != null ? tg.x : tg.l);
      links += '<path class="rb-bp-xl" d="M' + a.cx + " " + (a.outY - 2) + " V" + tg.y + " H" + (tx + (right ? 3 : -3)) + '" marker-end="url(#' + MK + ')"/>';
      if (l.label) links += '<text class="rb-bp-xlt" x="' + ((a.cx + tx) / 2) + '" y="' + (tg.y - 7) + '" text-anchor="middle">' + esc(l.label) + "</text>";
    });
    (B.shared || []).forEach(function (l) {
      var a = T[l.a[0]], b = T[l.b[0]]; if (!a || !b) return; var pa = a.pos[l.a[1]], pb = b.pos[l.b[1]]; if (!pa || !pb) return;
      links += '<path class="rb-bp-sh" d="M' + (pa.r + 3) + " " + pa.y + " H" + (pb.l - 3) + '" marker-start="url(#' + MK + ')" marker-end="url(#' + MK + ')"/>';
      links += '<text class="rb-bp-sht" x="' + ((pa.r + pb.l) / 2) + '" y="' + (pa.y + 20) + '" text-anchor="middle">' + esc(l.label || "") + "</text>";
    });
    var yBase = bottom;
    var H = yBase + 16, zooms = "";
    /* zoom-ins in a row below */
    if (ctx.zooms.length) {
      var zx = 16, zy = H + 16, rowH = 0, maxW = Math.max(W, 900) - 16;
      ctx.zooms.forEach(function (z) {
        var d = zoomSVG(z.z, z.c), bw = d.w + 20, bh = d.h + 48;
        if (zx + bw > maxW && zx > 16) { zx = 16; zy += rowH + 16; rowH = 0; }
        zooms += '<g data-tower="' + z.mod + '" class="rb-bp-zg" transform="translate(' + zx + "," + zy + ')"><rect class="rb-bp-zoom" style="--c:var(--' + z.c + ')" width="' + bw + '" height="' + bh + '" rx="12"/>' +
          '<circle class="rb-bp-badge" style="--c:var(--' + z.c + ')" cx="18" cy="18" r="9"/><text class="rb-bp-bt" x="18" y="22" text-anchor="middle">' + z.k + '</text><text class="rb-bp-zt" x="34" y="22">' + esc(z.z.title || z.row) + '</text><text class="rb-bp-ts" x="34" y="38">' + esc(z.tower) + "</text>" +
          '<g transform="translate(10,44)">' + d.svg + "</g></g>";
        zx += bw + 16; rowH = Math.max(rowH, bh);
      });
      H = zy + rowH + 12; W = Math.max(W, zx);
    }
    var head = B.headline ? '<text class="rb-bp-head" x="' + (W / 2) + '" y="' + (top - 6) + '" text-anchor="middle">' + esc(B.headline) + "</text>" : "";
    var y0 = top - (B.headline ? 30 : 8);
    return '<svg class="rb-bp-svg" style="max-width:' + W + 'px;min-width:' + Math.min(W, 760) + 'px" viewBox="0 ' + y0 + " " + W + " " + (H - y0) + '" width="' + W + '" height="' + (H - y0) + '" role="img" aria-label="' + esc(s.name + " blueprint: " + towers.map(function (t) { return t.title; }).join(", ")) + '"><defs><marker id="' + MK + '" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path class="rb-arch-head" d="M0 0L10 5L0 10z"/></marker></defs>' + head + links + parts.join("") + zooms + "</svg>";
  }

  RB.arch.blueprint = blueprint;
})();
