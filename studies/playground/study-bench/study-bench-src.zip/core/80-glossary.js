/* ===== Glossary (visual, map, A–Z) and Notation ===== */
(function () {
  "use strict";
  var RB = window.RB, esc = RB.esc, vg = null;

  function groups() { return RB.TERM_GROUPS || [{ id: "general", name: "General" }]; }
  function termList() {
    return Object.keys(RB.terms).map(function (k) { return RB.terms[k]; }).sort(function (a, b) { return a.name.localeCompare(b.name); });
  }
  function topicLink(t) { var k = (t.from || "").replace(/^lab:/, ""); if (RB.topics[k]) return { href: "#explorer/" + k, label: "Topic " + RB.topics[k].num }; if (RB.stations[k]) return { href: "#lab/" + k, label: "Lab" }; return null; }

  function visual() {
    var host = document.getElementById("gl-visual"), scenes = RB.SCENES || {}, sk = Object.keys(scenes);
    var terms = termList().map(function (t) {
      return { id: t.id, name: t.name, group: t.group || "general", sym: t.symTex ? RB.itex(t.symTex) : (t.sym || ""), def: t.def, note: t.note, ref: t.ref, scene: t.scene && scenes[t.scene] ? t.scene : sk[0], focus: t.focus || [], label: t.look || "", related: t.related || [], topic: topicLink(t) };
    });
    if (!terms.length) { host.innerHTML = '<div class="sb-empty"><p>The glossary fills in as topics are written.</p></div>'; return; }
    host.innerHTML = '<section class="sb-sec" id="gl-v-sec">' + RB.secHead({ level: "h2", title: "Visual glossary", lede: "Pick a term: the picture shows where it lives. Back and Next walk the list; nothing advances by itself.", demo: "gl-visual", demoMeta: "4 steps" }) + '<div id="vgHost"></div></section>';
    var sc = {}; sk.forEach(function (k) { sc[k] = scenes[k]; });
    /* Phone: the whole map would draw its labels at ~5px. Zoom the picture onto the highlighted parts (about 2×, so labels
       read at ~10–11px) and move the callout with it; "Whole map" shows everything again. Wide screens keep the full map. */
    var vgWhole = false, vgLast = null;
    function vgZoom(t) {
      vgLast = t || vgLast; t = vgLast;
      var host = document.getElementById("vgHost"), art = host && host.querySelector(".sb-vg-art"), svg = art && art.querySelector("svg");
      if (!svg) return;
      if (!svg.__vb) svg.__vb = svg.getAttribute("viewBox");
      var full = svg.__vb.split(/[\s,]+/).map(Number), btn = host.querySelector(".rb-vg-zoom");
      var focus = (t && t.focus) || [], small = art.clientWidth > 0 && art.clientWidth < 600;
      if (!btn) {
        btn = document.createElement("button"); btn.type = "button"; btn.className = "sb-btn sb-btn--ghost rb-vg-zoom";
        btn.addEventListener("click", function () { vgWhole = !vgWhole; vgZoom(); });
        var head = host.querySelector(".sb-vg-stage-head"); if (head) head.appendChild(btn);
      }
      svg.setAttribute("viewBox", svg.__vb);
      btn.hidden = !small || !focus.length; btn.textContent = vgWhole ? "Zoom in" : "Whole map";
      if (!small || !focus.length || vgWhole) return placeCallout(art, focus);
      /* union of the focused parts in viewBox units */
      var sr = svg.getBoundingClientRect(), k = full[2] / sr.width, x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      focus.forEach(function (id) { RB.$$('[data-part="' + id + '"]', art).forEach(function (el) { var r = el.getBoundingClientRect(); if (!r.width && !r.height) return; x0 = Math.min(x0, r.left); y0 = Math.min(y0, r.top); x1 = Math.max(x1, r.right); y1 = Math.max(y1, r.bottom); }); });
      if (!isFinite(x0)) return placeCallout(art, focus);
      var bx = full[0] + (x0 - sr.left) * k, by = full[1] + (y0 - sr.top) * k, bw = (x1 - x0) * k, bh = (y1 - y0) * k;
      var z = Math.min(2.2, Math.max(1, Math.min(full[2] / (bw + full[2] * 0.12), full[3] / (bh + full[3] * 0.18))));
      var w = full[2] / z, h = full[3] / z, cx = bx + bw / 2, cy = by + bh / 2;
      var vx = Math.max(full[0], Math.min(full[0] + full[2] - w, cx - w / 2)), vy = Math.max(full[1], Math.min(full[1] + full[3] - h, cy - h / 2));
      svg.setAttribute("viewBox", [vx, vy, w, h].map(function (n) { return Math.round(n * 10) / 10; }).join(" "));
      placeCallout(art, focus);
    }
    /* same rule as the design system: centred above the first highlighted part, kept inside the picture */
    function placeCallout(art, focus) {
      var co = art.parentElement.querySelector(".sb-vg-callout"), first = focus[0] && art.querySelector('[data-part="' + focus[0] + '"]');
      if (!co || co.hidden || !first) return;
      var fr = first.getBoundingClientRect(), hr = art.getBoundingClientRect();
      co.style.left = (art.offsetLeft + Math.max(4, Math.min(hr.width - co.offsetWidth - 4, fr.left - hr.left + fr.width / 2 - co.offsetWidth / 2))) + "px";
      co.style.top = (art.offsetTop + Math.max(4, fr.top - hr.top - co.offsetHeight - 6)) + "px";
    }
    var vgRT; window.addEventListener("resize", function () { clearTimeout(vgRT); vgRT = setTimeout(function () { vgZoom(); }, 150); });
    vg = StudyBench.visualGlossary(document.getElementById("vgHost"), { terms: terms, scenes: sc, groups: groups(), onShow: function (t) { var h = RB.labTermHref && RB.labTermHref(t.id); if (h) RB.go(h); }, onSelect: function (t) { vgZoom(t); var c = document.querySelector("#vgHost .sb-vg-card"); if (c) { RB.typeset(c); var b = c.querySelector('[data-act="show"]'); if (b) { var h = RB.labTermHref && RB.labTermHref(t.id); b.style.display = h ? "" : "none"; if (h) b.title = "Opens the Lab with On this bench pointing at this term"; } } } });
    RB.demos["gl-visual"] = function () {
      var first = terms[0].id, two = terms[Math.min(5, terms.length - 1)].id;
      return [
        { target: "#vgHost .sb-vg-list", title: "Pick a term", text: "The list holds every term on the site. Choosing one lights its place in the picture.", do: function (a) { vg.select(first); return a.wait(300); } },
        { target: "#vgHost .sb-vg-stage", title: "Look where it lives", text: "The highlighted parts are where this term acts in a robot-learning system." },
        { target: "#vgHost .sb-vg-card", title: "Read the card", text: "The card gives the definition, a note on common confusions, the source and related terms.", do: function (a) { vg.select(two); return a.wait(300); } },
        { target: "#vgHost .sb-vg-groups", title: "Your turn", text: "Filter by group, then use Back and Next to walk the terms of that group one at a time." }
      ];
    };
  }

  function mapView() {
    var host = document.getElementById("gl-map"), G = groups();
    host.innerHTML = '<section class="sb-sec" id="gl-m-sec">' + RB.secHead({ level: "h2", title: "Glossary map", lede: "Terms in columns by group; an arrow means the later term is defined using the earlier one. Pick a group to keep the map readable." }) + '<div class="sb-toolbar">' + RB.seg({ id: "gmGroup", label: "Group", value: G[0].id, options: G.map(function (g) { return { value: g.id, label: g.short || g.name.split(" ")[0] }; }) }) + '<span class="sb-count" id="gmCount"></span></div><div class="sb-panel"><div class="sb-panel-body"><div id="gmHost"></div><div class="rb-gm-card" id="gmCard" hidden></div></div></div></section>';
    function draw(gid) {
      var inG = termList().filter(function (t) { return (t.group || "general") === gid; });
      var ids = {}; inG.forEach(function (t) { ids[t.id] = 1; });
      /* include direct prerequisites from other groups as a first column */
      var pre = {}; inG.forEach(function (t) { (t.uses || []).forEach(function (u) { if (!ids[u] && RB.terms[u]) pre[u] = 1; }); });
      var level = {}; function lv(id, d) { if (d > 12) return 0; if (level[id] != null) return level[id]; var t = RB.terms[id]; var us = (t && t.uses || []).filter(function (u) { return ids[u]; }); level[id] = us.length ? 1 + Math.max.apply(null, us.map(function (u) { return lv(u, d + 1); })) : 1; return level[id]; }
      var nodes = [], rows = {};
      Object.keys(pre).slice(0, 10).forEach(function (id) { rows[0] = (rows[0] || 0) + 1; nodes.push({ id: id, label: RB.terms[id].name, sub: "other group", col: 0, row: rows[0] - 1 }); });
      inG.slice(0, 40).forEach(function (t) { var c = Math.min(5, lv(t.id, 0)); rows[c] = (rows[c] || 0) + 1; nodes.push({ id: t.id, label: t.name, sub: t.ref || "", col: c, row: rows[c] - 1 }); });
      var have = {}; nodes.forEach(function (n) { have[n.id] = 1; });
      var edges = []; inG.forEach(function (t) { (t.uses || []).forEach(function (u) { if (have[u] && have[t.id]) edges.push([u, t.id]); }); });
      var ncol = 0; nodes.forEach(function (n) { ncol = Math.max(ncol, n.col + 1); });
      var h = document.getElementById("gmHost"); h.innerHTML = ""; h.className = "";
      if (!nodes.length) { h.innerHTML = '<div class="sb-empty"><p>No terms in this group yet.</p></div>'; return; }
      StudyBench.dag(h, { cols: Array.from({ length: ncol }, function (_, i) { return i === 0 ? "Needed first" : "Level " + i; }), nodes: nodes, edges: edges, nodeW: 180, onSelect: function (id) { var t = RB.terms[id], c = document.getElementById("gmCard"); c.hidden = false; c.innerHTML = '<p class="sb-eyebrow">' + esc(t.ref || "") + '</p><h3 class="rb-h4">' + esc(t.name) + "</h3><p>" + t.def + '</p><a class="sb-btn" href="#glossary/' + id + '">Open in the visual glossary →</a>'; } });
      document.getElementById("gmCount").textContent = Math.min(40, inG.length) + " of " + inG.length + " terms";
    }
    StudyBench.segmented(document.getElementById("gmGroup"), function (_v, b) { draw(b.value); });
    draw(G[0].id);
  }

  function az() {
    var host = document.getElementById("gl-az"), list = termList(), letters = [];
    list.forEach(function (t) { var L = t.name[0].toUpperCase(); if (letters.indexOf(L) < 0) letters.push(L); });
    host.innerHTML = '<section class="sb-sec" id="gl-az-sec">' + RB.secHead({ level: "h2", title: "A–Z", lede: "Every term, alphabetically, with its definition and source. Walk through steps entry by entry." }) + '<div class="sb-toolbar"><input class="sb-input" type="search" id="azSearch" placeholder="Search terms" aria-label="Search terms"><button class="sb-btn" type="button" id="azWalk">Walk through</button><span class="sb-count" id="azCount"></span></div><nav class="sb-az-letters" aria-label="Letters">' + letters.map(function (L) { return '<a class="sb-tag" href="#glossary/az" data-letter="' + L + '">' + L + "</a>"; }).join("") + "</nav>" +
      letters.map(function (L) { return '<div class="rb-az-sec" data-letter-sec="' + L + '"><h3 class="sb-az-letter" id="az-' + L + '">' + L + '</h3><div class="rb-az-grid">' + list.filter(function (t) { return t.name[0].toUpperCase() === L; }).map(function (t) { var tl = topicLink(t); return '<article class="sb-az-entry" id="term-' + t.id + '" data-text="' + esc((t.name + " " + (t.aliases || []).join(" ")).toLowerCase()) + '"><p class="sb-az-name">' + esc(t.name) + (t.symTex ? " " + RB.itex(t.symTex) : "") + "</p><p>" + t.def + "</p>" + (t.note ? '<p class="sb-caption"><b>Note.</b> ' + t.note + "</p>" : "") + '<div class="sb-az-foot">' + (t.ref ? '<span class="sb-ref">' + esc(t.ref) + "</span>" : "") + (tl ? '<a class="sb-link" href="' + tl.href + '">' + tl.label + " →</a>" : "") + '<a class="sb-link" href="#glossary/visual/' + t.id + '">In the picture →</a></div></article>'; }).join("") + "</div></div>"; }).join("") + "</section>";
    var entries = RB.$$(".sb-az-entry", host), walkI = -1;
    document.getElementById("azSearch").addEventListener("input", function (e) { var q = e.target.value.trim().toLowerCase(), n = 0; entries.forEach(function (x) { var ok = !q || x.getAttribute("data-text").indexOf(q) >= 0; x.hidden = !ok; if (ok) n++; }); RB.$$(".rb-az-sec", host).forEach(function (s) { s.hidden = !s.querySelector(".sb-az-entry:not([hidden])"); }); document.getElementById("azCount").textContent = n + " of " + entries.length; });
    host.querySelector(".sb-az-letters").addEventListener("click", function (e) { var a = e.target.closest("[data-letter]"); if (!a) return; e.preventDefault(); document.getElementById("az-" + a.getAttribute("data-letter")).scrollIntoView({ block: "start" }); });
    document.getElementById("azWalk").addEventListener("click", function () {
      walkI = (walkI + 1) % entries.length; var e = entries[walkI]; e.scrollIntoView({ block: "center" }); StudyBench.flash && StudyBench.flash(e);
      document.getElementById("azWalk").textContent = "Next entry →"; document.getElementById("azCount").textContent = (walkI + 1) + " of " + entries.length;
    });
    document.getElementById("azCount").textContent = entries.length + " terms";
    RB.typeset(host);
  }

  RB.pages.glossary = {
    init: function () { document.getElementById("glEyebrow").textContent = Object.keys(RB.terms).length + " terms · each in a picture"; visual(); mapView(); az(); RB.hintFirstDemo("glossary"); },
    show: function (o) {
      var id = o.tab === "visual" ? o.rest[0] : null;
      if (id && vg && RB.terms[id]) { vg.select(id); var st = document.getElementById("vgHost"); if (st) st.scrollIntoView({ block: "start" }); }
      if (o.tab === "az" && o.rest[0]) { var e = document.getElementById("term-" + o.rest[0]); if (e) e.scrollIntoView({ block: "center" }); }
    }
  };
  RB.howto["gl-visual"] = function () { RB.go("#glossary/visual"); };
  RB.howto["gl-map"] = function () { RB.go("#glossary/map"); };
  RB.howto["gl-az"] = function () { RB.go("#glossary/az"); };

  /* ---------- Notation ---------- */
  function notation() {
    var host = document.getElementById("notationHost"), kinds = [];
    RB.symbolOrder.forEach(function (k) { var s = RB.symbols[k]; if (kinds.indexOf(s.kind) < 0) kinds.push(s.kind); });
    var A = RB.ANATOMY || { tex: "\\mathcal{L}", parts: [] };
    host.innerHTML = '<section class="sb-sec" id="n-anatomy">' + RB.secHead({ level: "h2", title: "Symbol anatomy", lede: A.lede || "" }) + '<div class="sb-panel"><div class="sb-panel-body"><div class="sb-anatomy">' + (A.parts || []).map(function (p) { return '<span class="sb-part" data-sym="' + p.sym + '" tabindex="0"><span class="sb-part-math">' + RB.itex(p.tex) + '</span><span class="sb-part-label">' + esc(p.label) + "</span></span>"; }).join("") + "</div>" + (A.eq ? RB.eqBlock(A.eq) : "") + "</div></div></section>" +
      '<section class="sb-sec" id="n-table">' + RB.secHead({ level: "h2", title: "All symbols", lede: "House notation, filterable by kind. The last column shows how the papers write the same idea." }) +
      '<div class="sb-chips" data-filter-for="notationTable" role="group" aria-label="Filter by kind">' + kinds.map(function (k) { return '<button type="button" class="sb-tag" data-key="kind" data-val="' + esc(k) + '" aria-pressed="false">' + esc(k) + "</button>"; }).join("") + '</div><div class="sb-toolbar"><input class="sb-input" type="search" id="nSearch" data-search-for="notationTable" placeholder="Search by name or glyph, e.g. tau or τ" aria-label="Search symbols"><span class="sb-count" data-count-for="notationTable"></span><button class="sb-btn sb-btn--ghost" type="button" data-clear-for="notationTable" hidden>Clear filters</button></div>' +
      '<div class="sb-scroll-x"><table class="sb-table" id="notationTable"><thead><tr><th scope="col">Symbol</th><th scope="col" data-sort="text">Meaning</th><th scope="col" data-sort="text">Kind</th><th scope="col">Read aloud</th><th scope="col">First use</th><th scope="col" id="n-conc">How the papers write it</th></tr></thead><tbody>' +
      RB.symbolOrder.map(function (k) { var s = RB.symbols[k], ft = RB.topics[s.first]; return '<tr data-sym="' + k + '" data-kind="' + esc(s.kind) + '" id="sym-' + k + '"><td class="rb-sym">' + RB.itex(s.tex) + '<span class="sb-sr"> ' + esc(s.read || k) + " " + esc(s.glyph) + "</span></td><td>" + esc(s.meaning) + "</td><td>" + esc(s.kind) + "</td><td>" + esc(s.read || "") + "</td><td>" + (ft ? '<a class="sb-ref" href="#explorer/' + s.first + '">Topic ' + ft.num + "</a>" : "") + '</td><td class="rb-conc">' + esc(s.papers || "") + "</td></tr>"; }).join("") + "</tbody></table></div></section>";
    StudyBench.table(document.getElementById("notationTable"));
    StudyBench.link(document.getElementById("view-notation"));
    RB.typeset(host);
    var rows = RB.$$("#notationTable tbody tr[data-kind]"), fb = host.querySelector('[data-filter-for="notationTable"]'), chips = RB.$$("button", fb);
    function facets() { StudyBench.facetCounts(rows, [{ chips: chips, match: function (r, v) { return r.getAttribute("data-kind") === v; }, selected: function () { var on = chips.filter(function (c) { return c.getAttribute("aria-pressed") === "true"; })[0]; return on ? on.getAttribute("data-val") : "all"; } }]); }
    fb.addEventListener("click", function () { setTimeout(facets, 0); }); facets();
  }
  RB.pages.notation = {
    init: notation,
    show: function (o) { if (o.rest[0]) { var r = document.getElementById("sym-" + o.rest[0]); if (r) { r.scrollIntoView({ block: "center" }); StudyBench.flash && StudyBench.flash(r); } } }
  };
  RB.howto["n-anatomy"] = function () { document.getElementById("n-anatomy").scrollIntoView({ block: "start" }); };
  RB.howto["n-search"] = function () { var i = document.getElementById("nSearch"); if (i) { i.scrollIntoView({ block: "center" }); i.focus(); } };
  RB.howto["n-conc"] = function () { var c = document.getElementById("n-conc"); if (c) c.scrollIntoView({ block: "center" }); };
})();
