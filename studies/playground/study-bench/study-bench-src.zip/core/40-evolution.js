/* ===== Evolution: lineage lanes (LineageMap), story filmstrip (StoryMode), equation changes (EquationLineage) =====
   Data: RB.LINEAGE = {lanes:[...], story:[...], quiz:[...]} from data/lineage.js; method facts from RB.M. */
(function () {
  "use strict";
  var RB = window.RB, esc = RB.esc;
  var L = null, lane = null, selected = null, lens = "year", map = null;

  function laneById(id) { return L.lanes.filter(function (x) { return x.id === id; })[0] || L.lanes[0]; }
  function node(id) { return (lane.nodes || []).filter(function (n) { return n.id === id; })[0]; }
  function method(id) { var n = node(id); return RB.M[(n && n.method) || id]; }
  function parentsOf(id) { return lane.edges.filter(function (e) { return e[1] === id; }).map(function (e) { return e[0]; }); }
  function edgeLabel(a, b) { var e = lane.edges.filter(function (x) { return x[0] === a && x[1] === b; })[0]; return e ? e[2] : ""; }
  function chain(id) { var out = [id], cur = id, guard = 0; while (guard++ < 40) { var p = parentsOf(cur)[0]; if (!p) break; out.unshift(p); cur = p; } return out; }
  function nodeName(id) { var n = node(id), m = method(id); return (n && n.label) || (m && m.name) || id; }

  /* equation for a node: hand-written diff (RB.EQ_LINEAGE) first, else the method card's first key equation */
  function eqFor(id) {
    var ov = (RB.EQ_LINEAGE || {})[id];
    if (ov) return ov;
    var m = method(id); if (!m || !m.eqs || !m.eqs.length) return null;
    var e = m.eqs[0];
    return { tex: e.tex, words: e.meaning, key: (e.symbols || []).slice(0, 8).map(function (s) { return { glyph: RB.itex(s.sym), meaning: s.meaning }; }), fromCard: true };
  }

  function archBlock(m) {
    var asp = m && RB.arch && RB.arch.forMethod(m.id);
    if (asp) { var note = RB.arch.aliasNote(m.id); return '<section class="rb-evo-archsec"><h4 class="rb-h5">Architecture</h4>' + (note ? '<p class="sb-caption">' + esc(note) + "</p>" : "") + '<div class="rb-evo-arch" data-evo-arch="' + asp.id + '"></div></section>'; }
    var why = m && RB.arch && RB.arch.none(m.id);
    return '<section class="rb-evo-archsec"><h4 class="rb-h5">Architecture</h4><p class="sb-caption">' + (why ? "No network to draw. " + esc(why) : "Not drawn: this method has a fact card only, and its paper gives no layer-level detail we could verify.") + "</p></section>";
  }
  function mountArch(host) {
    RB.$$("[data-evo-arch]", host).forEach(function (el) { var sp = RB.arch.get(el.getAttribute("data-evo-arch")); if (sp) el.__arch = RB.arch.mount(el, [sp], { view: "system" }); });
  }

  function detail(id) {
    var host = document.getElementById("evoDetail"), m = method(id), n = node(id);
    if (!m && !n) { host.innerHTML = '<div class="sb-empty"><p>Pick a box on the map to see what that method changed, its architecture and how it differs from its parent.</p></div>'; return; }
    var ps = parentsOf(id), eq = eqFor(id);
    var s = '<div class="rb-evo-head"><div><p class="sb-eyebrow">' + esc(lane.name) + (m && m.year ? " · " + m.year : "") + '</p><h3 class="rb-h4">' + esc(nodeName(id)) + "</h3>" + (m && m.title ? '<p class="sb-caption">' + esc(m.title) + (m.authors ? " · " + esc(m.authors) : "") + "</p>" : "") + "</div>" +
      '<div class="sb-btn-row">' + (ps.length ? '<button class="sb-btn sb-btn--primary" type="button" data-evo-cmp="' + id + '">Compare with ' + esc(nodeName(ps[0])) + "</button>" : "") + (m && m.topic ? '<a class="sb-btn sb-btn--ghost" href="#explorer/' + m.topic.toLowerCase() + '">Topic ' + (RB.topics[m.topic.toLowerCase()] || {}).num + " →</a>" : "") + (m ? RB.arxivLink(m) : "") + "</div></div>";
    s += '<dl class="rb-kv"><dt>Problem it fixes</dt><dd>' + esc((n && n.problem) || (m && m.problem) || "–") + "</dd>";
    s += "<dt>Change from " + (ps.length ? esc(nodeName(ps[0])) : "its parent") + "</dt><dd>" + esc((ps.length && edgeLabel(ps[0], id)) || (m && m.changed) || "Root of this lane.") + "</dd>";
    if (m && m.action) s += "<dt>Actions</dt><dd>" + esc(m.action) + "</dd>";
    s += "</dl>";
    s += archBlock(m);
    if (eq) s += RB.eqBlock({ name: "Defining equation", ref: m && m.arxiv ? "arXiv " + m.arxiv : "", prov: eq.fromCard ? "From the method paper" : "", tex: eq.tex, words: eq.words, key: eq.key });
    s += '<div id="evoCmp"></div>';
    host.innerHTML = s;
    mountArch(host);
    RB.$$(".sb-eq", host).forEach(function (e) { StudyBench.link(e); });
    RB.typeset(host);
  }

  /* parent vs child, inside the page: the one change, the rows that differ, both architectures, both equations */
  var cmpView = "system";
  function compareParent(id) {
    var ps = parentsOf(id); if (!ps.length) return;
    var pid = ps[0], c = method(id), p = method(pid), host = document.getElementById("evoCmp"); if (!host) return;
    var cs = c && RB.arch.forMethod(c.id), psp = p && RB.arch.forMethod(p.id);
    var rows = [["Year", function (m) { return m.year; }], ["Problem it fixes", function (m) { return m.problem; }], ["Architecture", function (m) { return m.arch; }], ["Action output", function (m) { return m.action; }], ["Parameters", function (m) { return m.params; }], ["Training data", function (m) { return m.data; }]];
    var t = '<div class="sb-scroll-x"><table class="sb-table sb-table--compact rb-evo-cmpt"><thead><tr><th scope="col"></th><th scope="col">' + esc(nodeName(pid)) + '</th><th scope="col">' + esc(nodeName(id)) + "</th></tr></thead><tbody>" +
      rows.map(function (r) { var a = p ? r[1](p) : "", b = c ? r[1](c) : ""; return "<tr><th scope=\"row\">" + r[0] + "</th><td>" + esc(a || "–") + "</td><td>" + esc(b || "–") + "</td></tr>"; }).join("") + "</tbody></table></div>";
    var archPart = "";
    if (cs && psp) archPart = '<div class="rb-arch-bar"><h4 class="rb-h5">Architectures</h4>' + RB.seg({ id: "evoCmpView", label: "Diagram", value: cmpView, options: [{ value: "system", label: "System" }, { value: "blueprint", label: "Blueprint" }] }) + '</div><div id="evoCmpArch"></div><p class="rb-h5">Architecture rows</p>' + RB.arch.summary([psp, cs]);
    else archPart = '<p class="sb-caption">' + (cs || psp ? "Only " + esc(cs ? nodeName(id) : nodeName(pid)) + " has an architecture diagram, so the diagrams are not lined up." : "Neither method has an architecture diagram.") + "</p>";
    var e1 = eqFor(pid), e2 = eqFor(id);
    var eqs = (e1 || e2) ? '<div class="rb-evo-eqs">' + (e1 ? RB.eqBlock({ name: nodeName(pid), tex: e1.tex, words: e1.words, key: e1.key }) : '<p class="sb-caption">No equation for ' + esc(nodeName(pid)) + ".</p>") + (e2 ? RB.eqBlock({ name: nodeName(id), tex: e2.tex, words: e2.words, key: e2.key }) : "") + "</div>" : "";
    host.innerHTML = '<section class="sb-panel rb-evo-cmp" aria-labelledby="evoCmpH"><div class="sb-panel-head"><span class="sb-eyebrow">Parent and child</span><h4 class="sb-panel-title" id="evoCmpH">' + esc(nodeName(pid)) + " → " + esc(nodeName(id)) + '</h4><button class="sb-btn sb-btn--sm sb-btn--ghost" type="button" data-evo-cmp-close>Close</button></div><div class="sb-panel-body">' +
      '<p class="rb-evo-change"><b>The one change:</b> ' + esc(edgeLabel(pid, id) || (c && c.changed) || "–") + "</p>" + t + archPart + eqs +
      '<p><a class="sb-link" href="#compare/sbs/' + (p ? p.id + "," : "") + (c ? c.id : "") + '">Open just these two in Compare →</a></p></div></section>';
    function drawArch() {
      var ah = document.getElementById("evoCmpArch"); if (!ah) return;
      ah.innerHTML = [psp, cs].map(function (sp, i) { return '<figure class="rb-sbs-afig"><figcaption>' + esc(i ? nodeName(id) : nodeName(pid)) + '</figcaption><div class="sb-scroll-x ' + (cmpView === "blueprint" ? "rb-bp-scroll" : "rb-arch-scroll") + '">' + (cmpView === "blueprint" && sp.blueprint ? RB.arch.blueprint(sp) : RB.arch.systemAuto(sp, { uid: "ec" + i })) + "</div></figure>"; }).join("");
    }
    if (cs && psp) { RB.bindSeg(host, "evoCmpView", function (v) { cmpView = v; drawArch(); }); drawArch(); }
    RB.$$(".sb-eq", host).forEach(function (e) { StudyBench.link(e); });
    RB.typeset(host);
    host.scrollIntoView({ block: "start", behavior: "smooth" });
  }

  /* lenses: how each survey classifies the methods of a lane */
  var LENS = {
    year: { label: "Year" },
    P02: { label: "VLA type · P02", what: "P02 is the survey “Vision-Language-Action Models for Robotics: Toward Real-World Applications” (arXiv 2510.07077). It sorts VLAs into seven architecture types." },
    P04: { label: "WAM philosophy · P04", what: "P04 is the survey “World Action Models: A Survey” (arXiv 2606.20781). It sorts world action models into three philosophies: render-and-decode, latent-only and video-generation-free." },
    X4: { label: "Context operation · X4", what: "X4 is the survey “In-Context Learning for Robots: Methods and Applications” (arXiv 2609.36012). Its Table 3 names what a context-conditioned policy does with the demonstrations: retrieve records, attend to their elements, encode them into a representation or parse them as text." },
    X1: { label: "WAM coupling · X1", what: "X1 is the survey “World Action Models: The Next Frontier” (arXiv 2605.12090). It sorts world action models by how video and action are coupled: cascaded or joint." }
  };
  function lensCats() { var c = {}; lane.nodes.forEach(function (n) { var v = n.labels && n.labels[lens]; if (v) c[v] = (c[v] || 0) + 1; }); return c; }
  function paintLens() {
    var key = document.getElementById("evoLensKey"); if (!key) return;
    RB.$$("#evoLens button").forEach(function (b) { var k = b.value; if (k === "year") return; var any = lane.nodes.some(function (n) { return n.labels && n.labels[k]; }); b.disabled = !any; b.title = any ? LENS[k].what : "This survey does not classify the methods in the " + lane.name + " lane."; });
    if (lens === "year") { key.hidden = true; return; }
    var cats = lensCats(), names = Object.keys(cats), none = lane.nodes.length - names.reduce(function (a, k) { return a + cats[k]; }, 0);
    names.forEach(function (k, i) { cats[k] = { n: cats[k], c: "data-" + (i % 8 + 1) }; });
    RB.$$("#evoMap .sb-dag-node").forEach(function (g) { var nd = node(g.getAttribute("data-id")), v = nd && nd.labels && nd.labels[lens]; g.classList.add("rb-cat"); g.classList.toggle("rb-cat-none", !v); if (v) g.style.setProperty("--c", "var(--" + cats[v].c + ")"); else g.style.removeProperty("--c"); });
    key.hidden = false;
    key.innerHTML = "<p>" + esc(LENS[lens].what) + "</p><ul class=\"sb-legend\">" + names.map(function (k) { return '<li class="sb-key"><span class="sb-sw" style="--c: var(--' + cats[k].c + ')"></span>' + esc(k) + " (" + cats[k].n + ")</li>"; }).join("") + (none ? '<li class="sb-key"><span class="sb-sw rb-sw-none"></span>Not classified by this survey (' + none + ")</li>" : "") + "</ul>";
  }

  function lensSub(n) {
    var m = RB.M[n.method || n.id];
    if (lens === "year") return (m && m.year) ? String(m.year) : (n.sub || "");
    return (n.labels && n.labels[lens]) || "not classified";
  }

  function drawMap() {
    var host = document.getElementById("evoMap"); host.innerHTML = "";
    host.classList.remove("sb-dag", "has-focus");
    var nodes = lane.nodes.map(function (n) { return { id: n.id, label: n.label || (RB.M[n.method || n.id] || {}).name || n.id, sub: lensSub(n), col: n.col, row: n.row }; });
    map = StudyBench.dag(host, { cols: lane.cols, nodes: nodes, edges: lane.edges.map(function (e) { return [e[0], e[1]]; }), nodeW: lane.nodeW || 176, onSelect: function (id) { select(id, true); }, title: lane.name + " lineage" });
    document.getElementById("evoLaneNote").innerHTML = "<b>How to read this map.</b> " + (lane.blurb || "") + " Columns are periods, left to right. An arrow means the later method changes one thing about the earlier one. Click a box: its ancestors and descendants light up and its detail opens below.";
    if (lens !== "year" && !lane.nodes.some(function (n) { return n.labels && n.labels[lens]; })) { lens = "year"; RB.$$("#evoLens button").forEach(function (b) { b.setAttribute("aria-pressed", b.value === "year"); }); return drawMap(); }
    paintLens();
    if (selected && node(selected)) map.select(selected); else { selected = null; detail(null); updateCount(); }
  }
  function updateCount() { document.getElementById("evoSel").textContent = "Selected: " + (selected ? nodeName(selected) : "none"); var b = document.getElementById("evoParent"); b.disabled = !selected || !parentsOf(selected).length; }
  function select(id, fromMap) {
    selected = id; updateCount(); detail(id); drawEq();
    if (!fromMap && map) map.select(id);
  }

  function lineageTab() {
    var host = document.getElementById("evo-lineage");
    host.innerHTML = '<section class="sb-sec" id="evo-map-sec">' + RB.secHead({ level: "h2", title: "Lineage map", lede: "Pick a lane. An arrow means the later method changes one thing about the earlier one.", demo: "evo-lineage", demoMeta: "5 steps" }) +
      '<div class="sb-toolbar"><label class="sb-field" for="evoLane"><span>Lane</span><select class="sb-select" id="evoLane">' + L.lanes.map(function (x) { return '<option value="' + x.id + '">' + esc(x.name) + " (" + x.nodes.length + ")</option>"; }).join("") + '</select></label>' +
      RB.seg({ id: "evoLens", label: "Label boxes by", value: "year", options: [{ value: "year", label: "Year" }, { value: "P02", label: "VLA type" }, { value: "P04", label: "WAM philosophy" }, { value: "X1", label: "WAM coupling" }, { value: "X4", label: "Context operation" }] }) +
      '<button class="sb-btn" type="button" id="evoParent" disabled>Compare with parent →</button><span class="sb-count" id="evoSel">Selected: none</span></div>' +
      '<div class="sb-panel"><div class="sb-panel-body"><p class="rb-howread" id="evoLaneNote"></p><div id="evoMap"></div><div class="rb-lens-key" id="evoLensKey" hidden></div><div class="sb-dag-key"><span><i class="k-sel"></i>Selected</span><span><i></i>Ancestor</span><span><i class="k-desc"></i>Descendant</span></div></div></div>' +
      '<div class="sb-panel rb-evo-detail"><div class="sb-panel-body" id="evoDetail"></div></div></section>';
    document.getElementById("evoLane").addEventListener("change", function (e) { lane = laneById(e.target.value); selected = null; drawMap(); drawEq(); });
    StudyBench.segmented(document.getElementById("evoLens"), function (_v, b) { if (b.disabled) return; lens = b.value; drawMap(); });
    /* arrow keys skip lenses that do not apply to this survey (the shared control would land on a disabled button) */
    document.getElementById("evoLens").addEventListener("keydown", function (e) {
      var dir = e.key === "ArrowRight" || e.key === "ArrowDown" ? 1 : e.key === "ArrowLeft" || e.key === "ArrowUp" ? -1 : 0; if (!dir) return;
      var bs = RB.$$("#evoLens button"), k = bs.indexOf(document.activeElement); if (k < 0) return;
      e.preventDefault(); e.stopPropagation();
      for (var i = 1; i <= bs.length; i++) { var nb = bs[(k + dir * i + bs.length * 2) % bs.length]; if (!nb.disabled) { nb.click(); nb.focus(); return; } }
    }, true);
    document.getElementById("evoParent").addEventListener("click", function () { if (selected) compareParent(selected); });
    document.getElementById("evoDetail").addEventListener("click", function (e) { var b = e.target.closest("[data-evo-cmp]"); if (b) compareParent(b.getAttribute("data-evo-cmp")); var x = e.target.closest("[data-evo-cmp-close]"); if (x) document.getElementById("evoCmp").innerHTML = ""; });
    RB.demos["evo-lineage"] = function () {
      var first = lane.nodes[0], last = lane.nodes[lane.nodes.length - 1];
      return [
        { target: "#evoLane", title: "Choose a lane", text: "Each lane is one family: policy heads, VLAs, world models, world action models and more. This demo uses " + lane.name + ".", task: "Pick any lane from the list", expect: function () { return true; } },
        { target: "#evoMap", title: "Select the root", text: "The left column holds the earliest method of the lane.", do: function (a) { select(first.id); return a.wait(300); }, task: "Click the leftmost box", expect: function () { return selected === first.id; } },
        { target: "#evoDetail", title: "Read what changed", text: "The detail names the problem the method fixed and the one change from its parent, with its defining equation." },
        { target: "#evoMap", title: "Jump to the newest", text: "Selecting a late method lights up its whole ancestry.", do: function (a) { select(last.id); return a.wait(300); }, task: "Click a box in the last column", expect: function () { return selected && node(selected) && node(selected).col === last.col; } },
        { target: "#evoLens", title: "Switch the lens", text: "Label the boxes by how each survey classifies them. Where surveys disagree, the labels change.", do: function (a) { var b = document.querySelector('#evoLens button:not([disabled]):not([value="year"])'); return b ? a.click(b) : a.wait(100); }, task: "Choose a survey lens", expect: function () { return lens !== "year"; } }
      ];
    };
    lane = L.lanes[0]; drawMap();
  }

  /* ---------- story filmstrip ---------- */
  function storyTab() {
    var S = L.story || [], host = document.getElementById("evo-story");
    if (!S.length) { host.innerHTML = '<div class="sb-empty"><p>The story is being written.</p></div>'; return; }
    host.innerHTML = '<section class="sb-sec" id="evo-story-sec">' + RB.secHead({ level: "h2", title: "Story: from tokens to flows to futures", lede: "Fourteen steps, each a problem, the change that fixed it and the result. It moves only when you press Next or Play.", demo: "evo-story", demoMeta: S.length + " steps" }) +
      '<div class="sb-stepper rb-film" data-steps="' + S.length + '" id="evoFilm"><div class="sb-toolbar sb-stepper-bar"><button class="sb-btn sb-btn--primary" data-act="play">Play ▶</button><button class="sb-btn" data-act="prev" aria-label="Previous step">←</button><button class="sb-btn" data-act="next" aria-label="Next step">→</button><input class="sb-range" type="range" data-act="scrub" aria-label="Step"><span class="sb-status" data-status></span></div>' +
      '<div class="rb-film-main" aria-live="polite"></div><ol class="rb-film-thumbs">' + S.map(function (st, i) { return '<li><button type="button" data-film="' + (i + 1) + '"><span class="rb-film-n">' + (i + 1) + "</span>" + (st.art || "") + '<span class="rb-film-tt">' + esc(st.title) + "</span></button></li>"; }).join("") + "</ol></div></section>";
    var main = host.querySelector(".rb-film-main"), film = host.querySelector("#evoFilm");
    var api = StudyBench.stepper(film, {
      onStep: function (i) {
        var st = S[i - 1];
        /* v2.11 visual guide: the picture leads; its three zones (problem · change · result) light up in turn, and each
           zone's sentence sits right under it. The equation's words and symbols fold into More detail. */
        var zone = function (n, k, txt) { return '<li class="rb-film-z rb-film-z' + n + '"><span class="rb-film-k"><b>' + n + "</b> " + k + "</span><p>" + txt + "</p></li>"; };
        main.innerHTML = '<div class="rb-film-card rb-film-guide"><header class="rb-film-head"><p class="sb-eyebrow">Step ' + i + " of " + S.length + (st.years ? " · " + esc(st.years) : "") + '</p><h3 class="rb-h4">' + esc(st.title) + "</h3></header>" +
          '<div class="rb-film-stage"><figure class="rb-film-art">' + (st.art || "") + '</figure><ol class="rb-film-zones">' + zone(1, "Problem", st.problem) + zone(2, "Change", st.change) + zone(3, "Result", st.result) + "</ol></div>" +
          (st.eq ? RB.eqBlock(st.eq) : "") + '<div class="sb-btn-row">' + (st.lane ? '<button class="sb-btn" type="button" data-showmap="' + st.lane + "|" + (st.node || "") + '">Show on map →</button>' : "") + (st.topic ? '<a class="sb-btn sb-btn--ghost" href="#explorer/' + st.topic + '">Topic ' + (RB.topics[st.topic] || {}).num + " →</a>" : "") + "</div></div>";
        RB.$$(".sb-eq", main).forEach(function (eq) {
          var w = eq.querySelector(".sb-eqwords"), k = eq.querySelector(".sb-eqkey"); if (!w && !k) return;
          var d = document.createElement("details"); d.className = "sb-more"; d.innerHTML = "<summary>More detail: in words and symbols</summary>";
          if (w) d.appendChild(w); if (k) d.appendChild(k); eq.appendChild(d);
        });
        var card = main.querySelector(".rb-film-guide"); requestAnimationFrame(function () { card.classList.add("is-play"); });
        RB.$$("[data-film]", host).forEach(function (b) { b.setAttribute("aria-current", +b.getAttribute("data-film") === i ? "step" : "false"); });
        RB.$$(".sb-eq", main).forEach(function (e) { StudyBench.link(e); });
        RB.typeset(main); RB.linkTerms(main);
      }
    });
    host.addEventListener("click", function (e) {
      var b = e.target.closest("[data-film]"); if (b) { api.stop(); api.go(+b.getAttribute("data-film")); }
      var m = e.target.closest("[data-showmap]"); if (m) { var p = m.getAttribute("data-showmap").split("|"); RB.go("#evolution/lineage"); var sel = document.getElementById("evoLane"); sel.value = p[0]; lane = laneById(p[0]); drawMap(); if (p[1]) select(p[1]); }
    });
    RB.demos["evo-story"] = function () { return S.slice(0, 6).map(function (st, i) { return { target: "#evoFilm .rb-film-main", title: st.title, text: st.change, do: function (a) { api.go(i + 1); return a.wait(200); } }; }).concat([{ target: "#evoFilm .rb-film-thumbs", title: "Your turn", text: "Click any thumbnail to jump to that step, or press Play ▶ to run the whole story." }]); };
    RB.storyApi = api;
  }

  /* ---------- equation changes ---------- */
  function drawEq() {
    var host = document.getElementById("evoEqHost"); if (!host) return;
    var id = selected || (lane.nodes[lane.nodes.length - 1] || {}).id, ch = chain(id);
    document.getElementById("evoEqWho").textContent = "Chain: " + ch.map(nodeName).join(" → ");
    var s = '<div class="sb-lineage">';
    ch.forEach(function (k, i) {
      if (i > 0) s += '<p class="sb-lineage-step">' + esc(edgeLabel(ch[i - 1], k) || "changes one thing") + "</p>";
      var eq = eqFor(k), m = method(k);
      s += eq ? RB.eqBlock({ name: nodeName(k), ref: m && m.year ? String(m.year) : "", prov: eq.fromCard ? "From the method paper" : "", tex: eq.tex, words: eq.words, key: eq.key, diff: !eq.fromCard && /sb-(new|chg)/.test(eq.tex) }) : '<div class="sb-eq"><div class="sb-eq-head">' + esc(nodeName(k)) + '</div><p class="sb-caption">No defining equation: this method changes data, hardware or pipeline, not a formula.</p></div>';
    });
    host.innerHTML = s + "</div>";
    RB.$$(".sb-eq", host).forEach(function (e) { StudyBench.link(e); });
    RB.typeset(host);
  }
  function eqTab() {
    var host = document.getElementById("evo-equations");
    host.innerHTML = '<section class="sb-sec" id="evo-eq-sec">' + RB.secHead({ level: "h2", title: "Equation changes", lede: "The chain of defining equations from the lane's root to the selected method. Hand-written diffs mark new and changed terms." }) + '<div class="sb-toolbar"><span class="sb-count" id="evoEqWho"></span><a class="sb-btn" href="#evolution/lineage">Pick another method</a></div><div id="evoEqHost"></div></section>';
    drawEq();
  }

  function quiz() {
    var Q = L.quiz || [], host = document.getElementById("evoQuiz");
    host.innerHTML = '<div class="sb-panel"><div class="sb-panel-body rb-quiz">' + Q.map(function (q, qi) { return '<div class="sb-q"><p class="sb-q-text"><span class="sb-q-n">' + (qi + 1) + "</span>" + q.q + '</p><div class="sb-opts">' + q.options.map(function (o, oi) { return '<button type="button" class="sb-opt"' + (oi === q.correct ? ' data-correct="true"' : "") + '><span class="sb-opt-mark" aria-hidden="true"></span><span>' + o + "</span></button>"; }).join("") + '</div><p class="sb-q-why" hidden>' + q.why + "</p></div>"; }).join("") + '<div class="sb-btn-row"><span class="sb-status" data-quiz-score aria-live="polite"></span><button class="sb-btn sb-btn--ghost" type="button" data-quiz-reset>Reset quiz</button></div></div></div>';
    StudyBench.quiz(host);
  }

  RB.pages.evolution = {
    init: function () {
      L = RB.LINEAGE || { lanes: [], story: [], quiz: [] };
      if (!L.lanes.length) { document.getElementById("evo-lineage").innerHTML = '<div class="sb-empty"><p>The lineage lanes are being written.</p></div>'; return; }
      document.getElementById("evoEyebrow").textContent = L.lanes.length + " lanes · " + L.lanes.reduce(function (a, x) { return a + x.nodes.length; }, 0) + " methods";
      lineageTab(); storyTab(); eqTab(); quiz();
      RB.linkTerms(document.getElementById("view-evolution"));
      RB.hintFirstDemo("evolution");
    },
    show: function (o) {
      if (!L || !L.lanes.length) return;
      if (o.tab === "lineage" && o.rest[0]) {
        var id = o.rest[0], ln = L.lanes.filter(function (x) { return x.nodes.some(function (n) { return n.id === id || n.method === id; }); })[0];
        if (ln) { lane = ln; document.getElementById("evoLane").value = ln.id; drawMap(); var n = ln.nodes.filter(function (x) { return x.id === id || x.method === id; })[0]; select(n.id); }
      }
      if (o.tab === "equations") drawEq();
    }
  };
  RB.howto["evo-lineage"] = function () { RB.go("#evolution/lineage"); };
  RB.howto["evo-story"] = function () { RB.go("#evolution/story"); setTimeout(function () { if (RB.storyApi) RB.storyApi.play(); }, 200); };
  RB.howto["evo-eq"] = function () { RB.go("#evolution/equations"); };
})();
