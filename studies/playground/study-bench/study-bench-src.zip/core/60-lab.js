/* ===== Interactive Lab: one bench, twelve stations =====
   A station registers with RB.station({...}) (see AUTHORING.md). The bench mounts one station at a time. */
(function () {
  "use strict";
  var RB = window.RB, esc = RB.esc;
  var cur = null, curApi = null;

  function S(id) { return RB.stations[id]; }
  function groups() { var g = []; RB.STATION_INDEX.forEach(function (s) { if (g.indexOf(s.group) < 0) g.push(s.group); }); return g; }

  function build() {
    var host = document.getElementById("benchHost");
    host.innerHTML = '<div class="sb-bench rb-bench" id="labBench"><div class="sb-bench-inner"><header class="sb-bench-bar"><span class="sb-mono-mark" aria-hidden="true">RB</span><h2 class="sb-bench-title">Robot Learning Bench</h2><span class="sb-status rb-bench-sub">Twelve stations, one bench</span><span class="sb-prov" title="Every station is a small simulation of a mechanism described in the surveys">Simplified models</span><div class="rb-bench-tools"><span class="sb-live" id="stLive"><span class="sb-live-dot"></span><span>Paused</span></span><button type="button" class="sb-btn" id="labTourBtn" aria-haspopup="menu" aria-controls="labTourMenu" aria-expanded="false">Tours ▾</button><button type="button" class="sb-btn" id="labBenchBtn">On this bench</button></div></header>' +
      '<div class="sb-bench-grid rb-bench-grid"><aside class="sb-panel rb-rail" aria-label="Stations"><div class="sb-panel-head"><h3 class="sb-panel-title">Stations</h3></div><div class="sb-panel-body"><div class="sb-rack" id="labRack">' +
      groups().map(function (g) { return '<div class="sb-rack-group"><p class="sb-eyebrow">' + esc(g) + "</p>" + RB.STATION_INDEX.filter(function (s) { return s.group === g; }).map(function (s) { var st = S(s.id) || {}; return '<button type="button" class="sb-rack-item" aria-pressed="false" data-station="' + s.id + '"><span class="sb-rack-name">' + esc(st.name || s.name) + '</span><span class="sb-rack-sub">' + esc(st.sub || s.topics.map(function (k) { return RB.topics[k].num; }).join(" · ")) + "</span></button>"; }).join("") + "</div>"; }).join("") +
      '</div></div></aside><section class="rb-bench-center"><div class="sb-panel rb-scene-panel"><div class="sb-panel-head"><span class="sb-eyebrow sb-eyebrow--live">Station</span><h3 class="sb-panel-title" id="stTitle">–</h3><span id="stRefs"></span><span class="sb-panel-meta" id="stMeta"></span></div><div class="sb-panel-body"><div id="stScene" class="rb-scene"></div></div></div></section>' +
      '<div class="rb-side-col"><section class="sb-panel rb-ctl-panel" aria-label="Controls"><div class="sb-panel-head"><h3 class="sb-panel-title">Controls</h3></div><div class="sb-panel-body"><div class="sb-controls" id="stControls"></div></div></section>' +
      '<details class="sb-panel rb-side" open aria-label="About this station"><summary class="sb-panel-head"><h3 class="sb-panel-title">What to notice</h3></summary><div class="sb-panel-body" id="stSide"></div></details></div></div></div></div>';
    host.addEventListener("click", function (e) { var b = e.target.closest("[data-station]"); if (b) RB.go("#lab/" + b.getAttribute("data-station")); });
    RB.$$("#labRack .sb-rack-item").forEach(function (b) { b.addEventListener("keydown", function (e) { if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return; e.preventDefault(); var all = RB.$$("#labRack .sb-rack-item"), k = all.indexOf(b), n = all[RB.clamp(k + (e.key === "ArrowDown" ? 1 : -1), 0, all.length - 1)]; n.focus(); }); });
    /* demo cards */
    document.getElementById("demoCards").innerHTML = RB.STATION_INDEX.map(function (s) { var st = S(s.id) || {}; return '<article class="sb-demo-card"><div class="sb-demo-card-t"><span>' + esc(st.name || s.name) + '</span><span class="sb-ref">' + s.topics.map(function (k) { return RB.topics[k].num; }).join(" · ") + '</span></div><p class="sb-caption">' + esc(st.card || st.summary || "") + '</p><div class="sb-btn-row"><button class="sb-btn sb-btn--primary" type="button" data-lab-demo="' + s.id + '" data-mode="watch">▶ Watch demo</button><button class="sb-btn" type="button" data-lab-demo="' + s.id + '" data-mode="guide">Guide me</button></div></article>'; }).join("");
    document.getElementById("demoCards").addEventListener("click", function (e) { var b = e.target.closest("[data-lab-demo]"); if (!b) return; var id = b.getAttribute("data-lab-demo"), m = b.getAttribute("data-mode"); open(id); document.getElementById("benchHost").scrollIntoView({ block: "start" }); setTimeout(function () { RB.runDemo("lab-" + id, m); }, 250); });
    document.getElementById("benchDemo").innerHTML = RB.demoLaunch("lab-current", "runs the station you picked");
    RB.demos["lab-current"] = function () { return RB.demos["lab-" + (cur || RB.stationOrder[0])] ? RB.demos["lab-" + (cur || RB.stationOrder[0])]() : []; };
  }

  function live(state, text) { var l = document.getElementById("stLive"); if (!l) return; l.classList.toggle("is-running", state === "running"); l.classList.toggle("is-error", state === "error"); l.lastChild.textContent = text || (state === "running" ? "Running" : "Paused"); }

  function open(id) {
    if (!S(id)) id = RB.stationOrder.filter(function (k) { return S(k); })[0] || RB.stationOrder[0];
    if (cur === id && curApi) return;
    if (curApi && curApi.destroy) { try { curApi.destroy(); } catch (e) { } }
    cur = id; curApi = null;
    RB.$$("#labRack .sb-rack-item").forEach(function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-station") === id ? "true" : "false"); });
    var st = S(id), idx = RB.STATION_INDEX.filter(function (s) { return s.id === id; })[0] || {};
    var scene = document.getElementById("stScene"), ctl = document.getElementById("stControls"), side = document.getElementById("stSide");
    scene.innerHTML = ""; ctl.innerHTML = ""; side.innerHTML = ""; live("paused", "Paused");
    document.getElementById("stTitle").textContent = st ? st.name : idx.name;
    document.getElementById("stRefs").innerHTML = st ? (st.refs || []).map(function (r) { return '<span class="sb-ref">' + esc(r) + "</span>"; }).join("") + (st.prov ? '<span class="sb-prov">' + esc(st.prov) + "</span>" : "") : "";
    document.getElementById("stMeta").textContent = "";
    if (!st) { scene.innerHTML = '<div class="sb-empty"><p class="sb-empty-t">This station is being built.</p><p>It will cover topics ' + idx.topics.map(function (k) { return RB.topics[k].num; }).join(", ") + ".</p></div>"; return; }
    side.innerHTML = (st.summary ? "<p>" + st.summary + "</p>" : "") + (st.notice && st.notice.length ? '<ol class="rb-notice">' + st.notice.map(function (n) { return "<li>" + n + "</li>"; }).join("") + "</ol>" : "") + '<div class="rb-side-extra" id="stSideExtra"></div><div class="sb-chips">' + idx.topics.map(function (k) { return '<a class="sb-tag" href="#explorer/' + k + '">Topic ' + RB.topics[k].num + " →</a>"; }).join("") + "</div>";
    var api = { scene: scene, controls: ctl, side: document.getElementById("stSideExtra"), live: live, meta: function (t) { document.getElementById("stMeta").textContent = t; }, pal: RB.pal, id: id };
    try { curApi = st.mount(api) || {}; }
    catch (e) { scene.innerHTML = '<div class="sb-error">This station failed to start (' + esc(e.message) + "). Pick another station and come back.</div>"; live("error", "Error"); RB.warn("station " + id + ": " + e.message); console.error(e); return; }
    RB.demos["lab-" + id] = function () { return curApi && curApi.demo ? curApi.demo() : []; };
    foldRefs(api.side);
    if (window.MutationObserver && api.side && !api.side._foldObs) { api.side._foldObs = new MutationObserver(function () { foldRefs(api.side); }); api.side._foldObs.observe(api.side, { childList: true }); }
    RB.typeset(document.getElementById("benchHost"));
    RB.linkTerms(side);
  }
  /* v2.11 visual weight: published numbers beside a station are reference detail, so they fold into More detail
     (a heading "Numbers from the papers" / "Reference numbers" and everything after it up to the next heading) */
  function foldRefs(box) {
    if (!box) return;
    RB.$$(":scope > .rb-h5, :scope > h4, :scope > .rb-stack > .rb-h5", box).forEach(function (h) {
      if (!/numbers from the papers|reference numbers|which gripper/i.test(h.textContent) || h.closest("details.rb-lab-more")) return;
      var d = document.createElement("details"); d.className = "sb-more rb-lab-more";
      d.innerHTML = "<summary>More detail: " + RB.esc(h.textContent.trim().toLowerCase()) + "</summary>";
      var n = h.nextSibling; h.parentNode.insertBefore(d, h); h.remove();
      while (n && !(n.nodeType === 1 && n.matches(".rb-h5, h4"))) { var nx = n.nextSibling; d.appendChild(n); n = nx; }
    });
  }
  RB.openStation = open;

  /* ===== Bench bar (design system v2.8): "On this bench" and "Tours ▾" =====
     Data: RB.LAB_BENCH (data/lab-bench.js). Terms point at real elements of the mounted station and read live values
     from its DOM; tours drive its controls with the same actions a person would take. */
  var BENCH = function () { return (RB.LAB_BENCH || {})[cur] || { terms: [], tours: [] }; };
  var PART_ORDER = ["Scene", "Controls", "Readouts", "Chart"];
  var bt = null, tourMenu = null, tourCard = null, tourBtn = null, tour = null, tourI = 0, runId = 0;

  function ref(r) {
    if (!r) return null;
    if (r.indexOf("ro:") === 0) return document.querySelector('#benchHost [data-ro="' + r.slice(3) + '"]');
    return document.getElementById(r.replace(/^#/, ""));
  }
  function visible(el) { return !!(el && el.isConnected && el.getClientRects().length && !el.closest("[hidden]")); }
  /* the element to outline: a readout's box, a slider's or checkbox's field, otherwise the element itself */
  function box(el) {
    if (!el) return null;
    if (el.hasAttribute("data-ro")) return el.closest(".sb-readout") || el;
    if (el.tagName === "INPUT" || el.tagName === "SELECT") return el.closest("label, .sb-field") || el;
    return el;
  }
  function valueOf(el) {
    if (!el) return null;
    if (el.hasAttribute("data-ro")) { var u = el.parentNode.querySelector(".sb-readout-u"), v = el.textContent.trim(); return v === "–" || !v ? null : v + (u ? " " + u.textContent.trim() : ""); }
    if (el.tagName === "INPUT" && el.type === "checkbox") return el.checked ? "on" : "off";
    if (el.tagName === "INPUT") { var o = document.querySelector('#benchHost [data-out="' + el.id + '"]'); return o ? o.textContent.trim() : el.value; }
    if (el.tagName === "SELECT") { var op = el.options[el.selectedIndex]; return op ? op.textContent.trim() : null; }
    if (el.classList.contains("sb-seg")) { var b = el.querySelector('[aria-pressed="true"]'); return b ? b.textContent.trim() : null; }
    return null;
  }
  function conds(w) { return (w || "").split("&").map(function (c) { var m = c.trim().match(/^seg:([\w-]+)=(.+)$/); return m ? { seg: m[1], vals: m[2].split(",") } : null; }).filter(Boolean); }
  function condOk(c) { var s = document.getElementById(c.seg), b = s && s.querySelector('[aria-pressed="true"]'); return !!(b && c.vals.indexOf(b.value) >= 0); }
  function termItems() {
    var seen = {}, out = [];
    (BENCH().terms || []).forEach(function (e) {
      var T = RB.terms[e.t]; if (!T || seen[e.t]) return;
      if (!conds(e.when).every(condOk)) return;
      var el = ref(e.at); if (!visible(el)) return;
      seen[e.t] = 1;
      var vref = e.val === false ? null : (e.val || e.at), it = { id: e.t, name: T.name, where: e.w, watch: e.watch, target: function () { var x = ref(e.at); return visible(x) ? box(x) : null; } };
      if (vref && valueOf(ref(vref)) != null) it.value = function () { return valueOf(ref(vref)); };
      out.push(it);
    });
    return out.sort(function (a, b) { return PART_ORDER.indexOf(a.where) - PART_ORDER.indexOf(b.where); });
  }
  /* the station a glossary term is shown on: its own station first, then the first in rack order */
  function stationFor(id) {
    var T = RB.terms[id]; if (!T || !RB.LAB_BENCH) return null;
    var has = RB.stationOrder.filter(function (s) { return RB.stations[s] && (RB.LAB_BENCH[s] ? RB.LAB_BENCH[s].terms : []).some(function (e) { return e.t === id; }); });
    var own = (T.from || "").replace(/^lab:/, "");
    return has.indexOf(own) >= 0 ? own : has[0] || null;
  }
  RB.labTermHref = function (id) { var s = stationFor(id); return s ? "#lab/" + s + "/term-" + id : null; };

  function pointTerm(id) {
    if (!bt) return;
    var e = (BENCH().terms || []).filter(function (x) { return x.t === id; })[0]; if (!e) return;
    var unmet = conds(e.when).filter(function (c) { return !condOk(c); }), k = 0;
    (function next() {
      if (k < unmet.length) { var c = unmet[k++], b = document.querySelector("#" + c.seg + ' [value="' + c.vals[0] + '"]'); if (b) b.click(); setTimeout(next, 250); return; }
      if (!bt.isOpen()) bt.open(); else bt.refresh();
      var li = bt.panel.querySelector('.sb-benchterm[data-term="' + id + '"]');
      RB.$$(".sb-benchterm.is-current", bt.panel).forEach(function (x) { x.classList.remove("is-current"); });
      if (!li) return;
      li.classList.add("is-current"); li.scrollIntoView({ block: "nearest" });
      var pb = li.querySelector("[data-point]"); if (pb) { pb.click(); pb.focus({ preventScroll: true }); }
    })();
  }

  function initBench() {
    var host = document.getElementById("labBench"), btn = document.getElementById("labBenchBtn");
    if (!host || !btn || !window.StudyBench || !StudyBench.benchTerms) return;
    bt = StudyBench.benchTerms({ button: btn, host: host, items: termItems, title: function () { var st = RB.stations[cur]; return st ? st.name : "Robot Learning Bench"; } });
    /* the bench sits in a full-bleed wrapper that is transformed, which would pin a fixed panel to the bench instead of the
       window; the panel lives in the page instead, while the bench keeps the .has-benchterms class that makes room */
    document.getElementById("view-lab").appendChild(bt.panel);
    /* the list follows the station's mode and presets; the bench redraws its canvases when it makes room */
    var t = 0, again = function () { clearTimeout(t); t = setTimeout(function () { if (bt.isOpen()) bt.refresh(); }, 250); };
    ["click", "change"].forEach(function (ev) { host.querySelector(".rb-bench-grid").addEventListener(ev, again); });
    var was = false;
    new MutationObserver(function () { var now = host.classList.contains("has-benchterms") + "," + host.classList.contains("rb-has-tour"); if (now === was) return; was = now; setTimeout(function () { window.dispatchEvent(new Event("resize")); }, 60); }).observe(host, { attributes: true, attributeFilter: ["class"] });
  }

  /* ---------- Tours ▾ ---------- */
  function tourEl(html) { var d = document.createElement("div"); d.innerHTML = html; return d.firstElementChild; }
  function initTours() {
    var bench = document.getElementById("labBench"); tourBtn = document.getElementById("labTourBtn");
    tourMenu = tourEl('<div class="sb-tourmenu rb-tourmenu" id="labTourMenu" role="menu" aria-label="Tours for this station" hidden></div>');
    bench.appendChild(tourMenu);
    tourCard = tourEl('<section class="rb-tour-card" id="labTourCard" role="region" aria-label="Lab tour" hidden>' +
      '<div class="rb-tour-top"><span class="rb-tour-kicker" id="labTourKicker"></span><button type="button" class="sb-btn sb-btn--ghost rb-tour-x" id="labTourExit" aria-label="End tour">✕</button></div>' +
      '<div class="rb-tour-prog" id="labTourProg" aria-hidden="true"></div><div class="rb-tour-body" id="labTourBody"></div>' +
      '<div class="rb-tour-nav"><button type="button" class="sb-btn" id="labTourBack">← Back</button><span class="sb-count" id="labTourCount" aria-live="polite"></span><span class="rb-grow"></span><button type="button" class="sb-btn sb-btn--primary" id="labTourNext">Next →</button></div></section>');
    document.getElementById("view-lab").appendChild(tourCard);
    /* On this bench stacks above the card: keep its bottom edge in step with the card's height */
    if (window.ResizeObserver) new ResizeObserver(function () { if (!tourCard.hidden) document.body.style.setProperty("--rb-tour-h", tourCard.offsetHeight + "px"); }).observe(tourCard);
    tourBtn.addEventListener("click", function () { tourMenu.hidden ? openMenu() : closeMenu(true); });
    tourMenu.addEventListener("click", function (e) { var b = e.target.closest("[data-tour]"); if (b) startTour(b.getAttribute("data-tour")); });
    tourMenu.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { e.preventDefault(); closeMenu(true); return; }
      if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return; e.preventDefault();
      var it = RB.$$(".rb-tour-item", tourMenu), k = it.indexOf(document.activeElement), n = it[(k + (e.key === "ArrowDown" ? 1 : -1) + it.length) % it.length]; if (n) n.focus();
    });
    document.addEventListener("pointerdown", function (e) { if (!tourMenu.hidden && !tourMenu.contains(e.target) && !tourBtn.contains(e.target)) closeMenu(); });
    document.getElementById("labTourExit").addEventListener("click", function () { stopTour(true); });
    document.getElementById("labTourBack").addEventListener("click", function () { if (tour && tourI > 0) { tourI--; showStep(true); } });
    document.getElementById("labTourNext").addEventListener("click", function () { if (!tour) return; if (tourI < tour.steps.length - 1) { tourI++; showStep(true); } else stopTour(true); });
    tourCard.addEventListener("click", function (e) {
      if (e.target.closest("#labTourRun")) runStep();
      if (e.target.closest("[data-tour-look]") && tour) look(tour.steps[tourI].at, true);
    });
    tourCard.addEventListener("keydown", function (e) { if (e.key === "Escape") stopTour(true); });
  }
  function openMenu() {
    var ts = BENCH().tours || [], st = RB.stations[cur];
    tourMenu.innerHTML = '<p class="rb-tourmenu-h"><b>Tours · ' + esc(st ? st.name : "") + '</b><span>Each tour: look at a part, run it, notice what changes.</span></p>' +
      (ts.length ? ts.map(function (t) { return '<button type="button" role="menuitem" class="rb-tour-item" data-tour="' + esc(t.id) + '"><b>' + esc(t.title) + "</b><span>" + esc(t.goal) + '</span><span class="rb-tour-meta">' + t.steps.length + " steps</span></button>"; }).join("") : '<p class="sb-empty">No tours for this station yet.</p>');
    tourMenu.hidden = false; tourBtn.setAttribute("aria-expanded", "true");
    var bench = tourMenu.parentElement, br = bench.getBoundingClientRect(), bb = tourBtn.getBoundingClientRect();
    tourMenu.style.left = "auto"; tourMenu.style.top = (bb.bottom - br.top + 6) + "px"; tourMenu.style.right = Math.max(0, br.right - bb.right) + "px";
    var mr = tourMenu.getBoundingClientRect(); if (mr.left < 8) { tourMenu.style.right = "auto"; tourMenu.style.left = (8 - br.left) + "px"; }
    setTimeout(function () { var f = tourMenu.querySelector(".rb-tour-item"); if (f) f.focus(); }, 30);
  }
  function closeMenu(focusBtn) { if (!tourMenu || tourMenu.hidden) return; tourMenu.hidden = true; tourBtn.setAttribute("aria-expanded", "false"); if (focusBtn) tourBtn.focus(); }
  function startTour(id, at) {
    var t = (BENCH().tours || []).filter(function (x) { return x.id === id; })[0]; if (!t) return false;
    closeMenu(); tour = t; tourI = Math.max(0, Math.min(at || 0, t.steps.length - 1));
    tourCard.hidden = false; document.body.classList.add("rb-tour-on"); document.getElementById("labBench").classList.add("rb-has-tour");
    showStep(true); return true;
  }
  function stopTour(focusBtn) {
    runId++; if (!tour) return; tour = null;
    tourCard.hidden = true; document.body.classList.remove("rb-tour-on"); document.getElementById("labBench").classList.remove("rb-has-tour");
    RB.$$(".rb-tour-look-on").forEach(function (x) { x.classList.remove("rb-tour-look-on"); });
    if (focusBtn && tourBtn) tourBtn.focus();
  }
  function look(at, flash) {
    var el = box(ref(at)); RB.$$(".rb-tour-look-on").forEach(function (x) { x.classList.remove("rb-tour-look-on"); });
    if (!visible(el)) return false;
    el.classList.add("rb-tour-look-on");
    /* keep the part clear of the app bar and of the tour card */
    var r = el.getBoundingClientRect(), top = (parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--appbar-h")) || 56) + 12;
    var cr = tourCard.hidden ? null : tourCard.getBoundingClientRect(), bottom = cr && cr.left < r.right && cr.right > r.left ? cr.top - 12 : window.innerHeight - 12;
    if (r.top < top || r.bottom > bottom) window.scrollBy(0, r.height <= bottom - top ? r.top - top - Math.max(0, (bottom - top - r.height) / 3) : r.top - top);
    if (flash) { el.classList.remove("sb-pointed"); void el.offsetWidth; el.classList.add("sb-pointed"); setTimeout(function () { el.classList.remove("sb-pointed"); }, 2400); }
    return true;
  }
  function showStep(focus) {
    runId++;
    var t = tour, st = t.steps[tourI], n = t.steps.length;
    document.getElementById("labTourKicker").textContent = "Tour · " + t.title;
    document.getElementById("labTourProg").innerHTML = t.steps.map(function (_, i) { return '<i class="' + (i <= tourI ? "on" : "") + '"></i>'; }).join("");
    document.getElementById("labTourBody").innerHTML = '<h3 class="rb-tour-t" id="labTourStepT" tabindex="-1">' + (tourI + 1) + ". " + esc(st.title) + "</h3>" +
      '<p class="rb-tour-text"><b class="rb-tour-k">Look at</b> <button type="button" class="rb-tour-look" data-tour-look>' + esc(st.name) + "</button></p>" +
      (st.run ? '<div class="rb-tour-run"><button type="button" class="sb-btn" id="labTourRun">Run it ▶</button><span class="rb-tour-status" id="labTourStatus" aria-live="polite"></span></div>' : "") +
      '<p class="rb-tour-text"><b class="rb-tour-k">Notice</b> ' + esc(st.text) + "</p>";
    document.getElementById("labTourBack").disabled = tourI === 0;
    document.getElementById("labTourNext").textContent = tourI === n - 1 ? "Finish" : "Next →";
    document.getElementById("labTourCount").textContent = (tourI + 1) + " of " + n;
    document.body.style.setProperty("--rb-tour-h", tourCard.offsetHeight + "px");
    look(st.at, true);
    if (focus) setTimeout(function () { var h = document.getElementById("labTourStepT"); if (h) h.focus({ preventScroll: true }); }, 30);
  }
  function act(a) {
    var el = a[0] === "wait" ? null : document.getElementById(a[1]);
    if (a[0] === "seg") { var b = el && el.querySelector('[value="' + a[2] + '"]'); if (b && b.getAttribute("aria-pressed") !== "true") b.click(); }
    else if (a[0] === "set" || a[0] === "select") { if (el) { el.value = a[2]; el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); } }
    else if (a[0] === "check") { if (el && el.checked !== !!a[2]) el.click(); }
    else if (a[0] === "click") { if (el) el.click(); }
    return a[0] === "wait" ? a[1] : 180;
  }
  function runStep() {
    if (!tour) return;
    var my = ++runId, st = tour.steps[tourI], q = (st.run || []).slice(), status = document.getElementById("labTourStatus");
    if (status) { status.textContent = "Running this step on the bench…"; status.classList.remove("is-done"); }
    (function next() {
      if (my !== runId || !tour) return;
      if (!q.length) {
        setTimeout(function () {
          if (my !== runId) return;
          look(st.at, true); if (bt && bt.isOpen()) bt.refresh();
          var s = document.getElementById("labTourStatus"), rb = document.getElementById("labTourRun");
          if (s) { s.textContent = "Done. Read what to notice, then press Next."; s.classList.add("is-done"); } if (rb) rb.textContent = "Run again ▶";
        }, 250);
        return;
      }
      var ms = 180; try { ms = act(q.shift()); } catch (e) { RB.warn("lab tour: " + e.message); }
      setTimeout(next, ms);
    })();
  }
  RB.labTour = { start: startTour, stop: stopTour, openMenu: openMenu, closeMenu: closeMenu, point: pointTerm, isOn: function () { return !!tour; } };

  RB.pages.lab = {
    init: function () {
      build();
      initBench();
      initTours();
      RB.hintFirstDemo("lab");
    },
    show: function (o) {
      var id = o.rest[0] || cur || RB.stationOrder[0], changed = id !== cur || !curApi;
      if (changed) { stopTour(); closeMenu(); }
      open(id);
      if (changed && bt && bt.isOpen()) bt.refresh();
      var extra = o.rest[1] || "";
      if (/^tour-/.test(extra)) setTimeout(function () { startTour(extra.slice(5)); }, 300);
      else if (/^term-/.test(extra)) setTimeout(function () { pointTerm(extra.slice(5)); }, 300);
    },
    /* leaving the lab stops the running station (it is mounted again on return) */
    hide: function () { stopTour(); closeMenu(); if (bt && bt.isOpen()) bt.close(); if (curApi && curApi.destroy) { try { curApi.destroy(); } catch (e) { } curApi = null; } }
  };
  RB.howto["lab-pick"] = function () { var r = document.getElementById("labRack"); if (r) { r.scrollIntoView({ block: "center" }); StudyBench.flash && StudyBench.flash(r); } };
  RB.howto["lab-watch"] = function () { document.getElementById("benchHost").scrollIntoView({ block: "start" }); RB.runDemo("lab-current", "watch"); };
  RB.howto["lab-guide"] = function () { document.getElementById("benchHost").scrollIntoView({ block: "start" }); RB.runDemo("lab-current", "guide"); };
})();
