/* ===== Overview: hero, ways to study, full-stack flow, three layers, course map, task map, shelf, summaries, frontier ===== */
(function () {
  "use strict";
  var RB = window.RB, esc = RB.esc;

  var WAYS = [
    ["#tldr", "TL;DR", "The whole field in 24 animated pictures, each with a short TL;DR."],
    ["#explorer", "Topic Explorer", "One idea per page, with pictures, playgrounds and a check."],
    ["#evolution", "Evolution", "How each method changed one thing about an earlier one."],
    ["#compare", "Compare", "Line up 646 methods and their architectures, map them, and choose."],
    ["#lab", "Interactive Lab", "Twelve stations that run policy heads, world models, grasps and verifiers."],
    ["#reference", "Reference", "Formula sheet, review cards, disagreements, datasets and the shelf."],
    ["#glossary", "Glossary", "Every key term shown in a picture of a robot-learning system."],
    ["#notation", "Notation", "One house notation, and how each paper writes the same idea."]
  ];

  function ways() {
    document.getElementById("waysHost").innerHTML = WAYS.map(function (w) { return '<a class="sb-way" href="' + w[0] + '"><b class="sb-way-t">' + w[1] + ' →</b><span class="sb-way-d">' + w[2] + "</span></a>"; }).join("");
  }

  function heroMeta() {
    var n = (RB.METHODS || []).filter(function (m) { return !m.alias_of; }).length, t1 = (RB.METHODS || []).filter(function (m) { return m.tier === 1; }).length;
    document.getElementById("heroMeta").innerHTML = ["16 surveys", n + " method papers", t1 + " read in full", RB.topicOrder.length + " topics", "12 lab stations"].map(function (x) { return '<span class="sb-ref">' + x + "</span>"; }).join("");
    function upd() { var d = RB.progress ? RB.progress.count() : 0, nx = RB.nextUp(); document.getElementById("heroProgress").textContent = d + " of " + RB.topicOrder.length + " topics studied · next: " + RB.topics[nx].num + " " + RB.topicTitle(nx); }
    if (RB.progress) RB.progress.onChange(upd); else upd();
    document.getElementById("heroContinue").addEventListener("click", function () { RB.go("#explorer/" + RB.nextUp()); });
    document.getElementById("heroTour").addEventListener("click", function () { RB.startTour && RB.startTour(); });
  }

  /* The full stack as a walkable flow. Node ids name the topic they open. */
  var STACK = {
    title: "The robot learning stack", w: 980, h: 330,
    caption: "Data trains a policy; post-training and verifiers improve and check it; at run time the policy sends action chunks to a controller that closes the loop at a much higher rate.",
    nodes: [
      { id: "d1", x: 20, y: 30, w: 170, h: 56, label: "Data pyramid", sub: "five layers", kind: "store" },
      { id: "b4", x: 250, y: 30, w: 190, h: 56, label: "Pretrained policy", sub: "VLA or WAM", kind: "agent" },
      { id: "a3", x: 500, y: 30, w: 190, h: 56, label: "Post-training", sub: "RL and rewards", kind: "agent" },
      { id: "f1", x: 750, y: 30, w: 200, h: 56, label: "Verifier", sub: "score, filter, stop", kind: "decision" },
      { id: "b3", x: 250, y: 200, w: 190, h: 56, label: "Action chunk", sub: "H actions", kind: "agent" },
      { id: "a2", x: 500, y: 200, w: 190, h: 56, label: "Controller", sub: "PD, impedance", kind: "agent" },
      { id: "e1", x: 750, y: 200, w: 200, h: 56, label: "Robot and world", sub: "contact", kind: "env" }
    ],
    edges: [
      { from: "d1", to: "b4", label: "pretrain", dy: -10 },
      { from: "b4", to: "a3", label: "fine-tune" },
      { from: "a3", to: "f1", label: "candidates", dashed: true },
      { from: "b4", to: "b3", label: "sample" },
      { from: "b3", to: "a2", label: "targets" },
      { from: "a2", to: "e1", label: "torques" },
      { from: "e1", to: "b4", label: "observation oₜ", sides: ["b", "b"], via: [[850, 300], [345, 300]], dy: 16 },
      { from: "f1", to: "e1", label: "gate", dashed: true }
    ],
    steps: [
      { on: ["d1", "d1>b4", "b4"], text: "Pretraining: a policy learns from a mix of robot demonstrations, handheld-gripper data, human video, simulation and web images and text." },
      { on: ["b4>a3", "a3"], text: "Post-training adapts the policy with reinforcement learning, learned rewards or rollouts inside a world model." },
      { on: ["b4>b3", "b3"], text: "At run time the policy reads the observation and instruction and samples a chunk of H future actions." },
      { on: ["b3>a2", "a2", "a2>e1", "e1"], text: "A controller turns each action into joint torques many times per second, so contact is handled faster than the policy runs." },
      { on: ["e1>b4"], text: "The camera and joint sensors return a new observation, and the policy predicts the next chunk: a closed loop." },
      { on: ["a3>f1", "f1", "f1>e1"], text: "Verifiers score candidates, detect failures and can stop the robot. Every link in this picture is a topic on this site." }
    ]
  };

  function stack() {
    var host = document.getElementById("stackHost");
    var api = StudyBench.flow(host, STACK); host.__flow = api;
    api.svg.addEventListener("dblclick", function (e) { var g = e.target.closest(".sb-flow-node"); if (g) RB.go("#explorer/" + g.getAttribute("data-id")); });
    var links = RB.h("div", { "class": "sb-chips rb-stack-links" });
    links.innerHTML = '<span class="sb-caption">Open a box as a topic:</span>' + STACK.nodes.map(function (n) { return '<a class="sb-tag" href="#explorer/' + n.id + '">' + RB.topics[n.id].num + " " + esc(n.label) + "</a>"; }).join("");
    host.appendChild(links);
    RB.demos["walk-stack"] = function () {
      return STACK.steps.map(function (s, k) { return { target: host, title: "Step " + (k + 1) + " of " + STACK.steps.length, text: s.text, do: function (a) { api.stepper.go(k + 1); return a.wait(200); } }; }).concat([{ target: links, title: "Your turn", text: "Each chip opens the topic behind a box. Start with 01 if you are new, or jump to the box you care about." }]);
    };
    document.getElementById("stackDemo").innerHTML = RB.demoLaunch("walk-stack", "7 steps");
  }

  var LAYERS = [
    { id: "plan", name: "High-level planning", topic: "b5", out: "task plan · code · constraints · affordance · 3D scene · video", text: "Turns an instruction and a scene into a structured artifact. LLM and VLM planners, code as policy, keypoint constraints, affordance maps and generated videos live here.", ref: "P01 §5" },
    { id: "act", name: "Low-level action modeling", topic: "b2", out: "actions: joint or end-effector targets, chunks", text: "Maps observations X, through a latent Z, to actions A. Behavior cloning, diffusion and flow policies, VLAs and RL policies live here.", ref: "P01 §6" },
    { id: "ctl", name: "Actuation-level control", topic: "a2", out: "motor torques", text: "Tracks the targets with joint-space control (position, velocity, torque) or interaction control (impedance, admittance).", ref: "P01 §2.2" }
  ];
  function layers() {
    var host = document.getElementById("layersHost");
    var svg = '<svg viewBox="0 0 760 250" role="img" aria-label="Three layers: planning outputs artifacts to action modeling, which outputs actions to control, which outputs torques to the robot">' +
      LAYERS.map(function (L, i) { var y = 14 + i * 78; return '<g class="rb-layer" data-layer="' + L.id + '" tabindex="0" role="button" aria-label="' + L.name + '"><rect x="10" y="' + y + '" width="500" height="58" rx="8"/><text x="28" y="' + (y + 25) + '" class="rb-layer-t">' + L.name + '</text><text x="28" y="' + (y + 45) + '" class="rb-layer-s">' + L.ref + "</text></g>" + (i < 2 ? '<path class="rb-layer-arrow" d="M260 ' + (y + 58) + " L260 " + (y + 76) + '" marker-end="url(#rbLayArr)"/>' : ""); }).join("") +
      '<path class="rb-layer-arrow" d="M510 199 L600 199" marker-end="url(#rbLayArr)"/><rect x="604" y="176" width="146" height="46" rx="8" class="rb-layer-env"/><text x="677" y="204" text-anchor="middle" class="rb-layer-t">Robot</text>' +
      '<defs><marker id="rbLayArr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 L10 5 L0 10 z" class="rb-arrowhead"/></marker></defs></svg>';
    host.innerHTML = '<div class="sb-panel"><div class="sb-panel-head"><span class="sb-eyebrow">Diagram</span><span class="sb-ref">P01 Fig. 12</span></div><div class="sb-panel-body"><div class="rb-grid2"><div class="sb-scroll-x">' + svg + '</div><div class="rb-layer-card" aria-live="polite"></div></div></div></div>';
    var card = host.querySelector(".rb-layer-card");
    function pick(id) {
      var L = LAYERS.filter(function (x) { return x.id === id; })[0];
      RB.$$(".rb-layer", host).forEach(function (g) { g.classList.toggle("is-on", g.getAttribute("data-layer") === id); });
      card.innerHTML = '<p class="sb-eyebrow">' + esc(L.ref) + '</p><h3 class="rb-h4">' + esc(L.name) + "</h3><p>" + L.text + '</p><p class="sb-caption"><b>Passes down:</b> ' + esc(L.out) + '</p><a class="sb-btn" href="#explorer/' + L.topic + '">Open topic ' + RB.topics[L.topic].num + " →</a>";
    }
    host.addEventListener("click", function (e) { var g = e.target.closest(".rb-layer"); if (g) pick(g.getAttribute("data-layer")); });
    host.addEventListener("keydown", function (e) { var g = e.target.closest(".rb-layer"); if (g && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); pick(g.getAttribute("data-layer")); } });
    pick("act");
  }

  function courseMap() {
    var host = document.getElementById("courseMap");
    var rows = {};
    var nodes = RB.topicOrder.map(function (k) {
      var t = RB.topics[k], col = RB.PARTS.map(function (p) { return p.id; }).indexOf(t.part);
      rows[col] = (rows[col] || 0) + 1;
      return { id: k, label: t.num + " " + (t.map || t.short), col: col, row: rows[col] - 1 };  /* no sub line: survey names are wider than a node */
    });
    var edges = []; RB.topicOrder.forEach(function (k) { (RB.topics[k].buildsOn || []).forEach(function (b) { edges.push([b, k]); }); });
    var map = StudyBench.dag(host, { cols: RB.PARTS.map(function (p) { return "Part " + p.id; }), nodes: nodes, edges: edges, nodeW: 192, onSelect: function (id) { RB.go("#explorer/" + id); } });
    function upd() {
      var nx = RB.nextUp();
      nodes.forEach(function (n) { var g = map.nodes[n.id].g; g.classList.toggle("is-done", RB.progress.get(n.id)); g.classList.toggle("is-current", n.id === nx); });
      document.getElementById("continueNote").textContent = "Next up: " + RB.topics[nx].num + " " + RB.topicTitle(nx) + ".";
    }
    RB.progress.onChange(upd);
  }

  var TASKS = [
    { name: "Grasping", topic: "e1", text: "Predict a stable gripper pose from images or point clouds.", art: '<rect x="70" y="30" width="40" height="18" rx="3" class="rb-a-obj"/><path d="M80 8 V26 M100 8 V26 M80 8 H100" class="rb-a-ink"/>' },
    { name: "Basic manipulation", topic: "b4", text: "Tabletop pick-and-place, pushing, opening and pouring.", art: '<rect x="40" y="36" width="24" height="14" rx="2" class="rb-a-obj"/><path d="M70 43 H118" class="rb-a-acc" marker-end="url(#rbTaskArr)"/><rect x="124" y="36" width="24" height="14" rx="2" class="rb-a-obj rb-a-dash"/>' },
    { name: "Dexterous", topic: "e2", text: "Multi-fingered hands: in-hand rotation, tool use.", art: '<circle cx="90" cy="30" r="12" class="rb-a-obj"/><path d="M70 50 Q72 26 78 22 M84 52 Q86 22 90 16 M98 52 Q100 24 104 20 M110 50 Q112 34 116 30" class="rb-a-ink"/>' },
    { name: "Deformable", topic: "e3", text: "Cloth, rope, cables and food: no fixed pose.", art: '<path d="M40 40 Q60 18 80 38 T120 36 T150 34" class="rb-a-obj-l"/>' },
    { name: "Bimanual and mobile", topic: "e3", text: "Two arms, or an arm on a moving base.", art: '<rect x="66" y="40" width="48" height="12" rx="3" class="rb-a-ink-f"/><path d="M76 40 V24 L88 16 M104 40 V24 L92 16" class="rb-a-ink"/><circle cx="76" cy="54" r="3" class="rb-a-ink-f"/><circle cx="104" cy="54" r="3" class="rb-a-ink-f"/>' },
    { name: "Humanoid", topic: "e4", text: "Whole-body loco-manipulation with legs and arms.", art: '<circle cx="90" cy="12" r="6" class="rb-a-ink"/><path d="M90 18 V36 M90 36 L82 52 M90 36 L98 52 M90 24 L76 30 M90 24 L106 18" class="rb-a-ink"/><rect x="106" y="12" width="12" height="10" rx="2" class="rb-a-obj"/>' },
    { name: "Contact-rich", topic: "e5", text: "Insertion, wiping and assembly that need touch and force.", art: '<rect x="80" y="10" width="20" height="26" rx="2" class="rb-a-ink-f"/><rect x="60" y="40" width="60" height="12" class="rb-a-obj"/><rect x="86" y="36" width="8" height="6" class="rb-a-acc-f"/>' }
  ];
  function tasks() {
    document.getElementById("tasksHost").innerHTML = '<div class="sb-concepts rb-tasks">' + TASKS.map(function (t) {
      return '<article class="sb-concept"><div class="sb-concept-art"><svg viewBox="0 0 180 56" aria-hidden="true"><defs><marker id="rbTaskArr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0 L10 5 L0 10 z" class="rb-arrowhead"/></marker></defs>' + t.art + '</svg></div><p class="sb-concept-name">' + esc(t.name) + '</p><p class="sb-concept-def">' + t.text + '</p><span class="sb-ref">P01 §4</span><a class="sb-link sb-concept-go" href="#explorer/' + t.topic + '">Topic ' + RB.topics[t.topic].num + " →</a></article>";
    }).join("") + "</div>";
  }

  /* the finished frame of an AnimatedGuide scene, drawn once with no motion (same rules as StudyBench.anim's still mode) */
  function finishScene(fig) {
    var parts = {}; RB.$$("[data-a]", fig).forEach(function (el) { parts[el.getAttribute("data-a")] = el; });
    var ids = function (v) { return (v || "").split(/\s+/).filter(function (x) { return x && parts[x]; }); };
    RB.$$(".sb-anim-beats > li", fig).forEach(function (li) {
      ids(li.getAttribute("data-on")).forEach(function (k) { parts[k].classList.add("is-on"); });
      ids(li.getAttribute("data-off")).forEach(function (k) { parts[k].classList.remove("is-on"); });
      (li.getAttribute("data-cls") || "").split(/\s+/).filter(Boolean).forEach(function (x) { var q = x.split(":"); if (parts[q[0]]) parts[q[0]].classList.add("is-on", q[1]); });
      (li.getAttribute("data-move") || "").split(/\s+/).filter(Boolean).forEach(function (x) { var q = x.split(":"), tok = parts[q[0]], path = parts[q[1]]; if (!tok || !path || !path.getTotalLength) return; tok.classList.add("is-on"); try { var pt = path.getPointAtLength(path.getTotalLength()); tok.setAttribute("transform", "translate(" + pt.x + " " + pt.y + ")"); } catch (e) { } });
      (li.getAttribute("data-set") || "").split(/\s+/).filter(Boolean).forEach(function (x) { var m = x.match(/^([\w-]+)\.([\w-]+)=(.+)$/); if (m && parts[m[1]]) parts[m[1]].setAttribute(m[2], parseFloat(m[3])); });
      (li.getAttribute("data-text") || "").split(/\s+(?=[\w-]+=)/).filter(Boolean).forEach(function (x) { var i = x.indexOf("="), id = x.slice(0, i); if (parts[id]) parts[id].textContent = x.slice(i + 1); });
    });
  }

  /* which survey feeds which topic: one row per survey, one column per topic, grouped by part */
  function coverage(ps, kind) {
    var rowName = function (p) { return kind === "survey" ? ((RB.SURVEY_NAMES && RB.SURVEY_NAMES[p.id]) || p.id) : p.title; };
    var tops = RB.topicOrder, LW = 236, CW = 21, RH = 21, TOP = 46, W = LW + tops.length * CW + 8, H = TOP + ps.length * RH + 6;
    var o = '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="' + (kind === "survey" ? "Which survey each topic draws on: " + ps.length + " surveys by " : "Which topics each open problem touches: " + ps.length + " problems by ") + tops.length + ' topics">';
    var x0 = LW;
    RB.PARTS.forEach(function (p) {
      var ids = tops.filter(function (k) { return RB.topics[k].part === p.id; }); if (!ids.length) return;
      var a = x0 + tops.indexOf(ids[0]) * CW, b = x0 + (tops.indexOf(ids[ids.length - 1]) + 1) * CW;
      o += '<text class="rb-cov-part" x="' + ((a + b) / 2) + '" y="14" text-anchor="middle">Part ' + p.id + "</text>" + '<line class="rb-cov-sep" x1="' + a + '" x2="' + a + '" y1="20" y2="' + (H - 4) + '"/>';
    });
    tops.forEach(function (k, j) { o += '<text class="rb-cov-n" x="' + (x0 + j * CW + CW / 2) + '" y="38" text-anchor="middle">' + RB.topics[k].num + "</text>"; });
    ps.forEach(function (p, i) {
      var y = TOP + i * RH;
      if (i % 2) o += '<rect class="rb-cov-band" x="0" y="' + y + '" width="' + W + '" height="' + RH + '"/>';
      o += '<text class="rb-cov-lbl" x="' + (LW - 10) + '" y="' + (y + 15) + '" text-anchor="end">' + esc(rowName(p)) + "</text>";
      tops.forEach(function (k, j) {
        if (p.topics.indexOf(k) < 0) return;
        o += '<a href="#explorer/' + k + '" class="rb-cov-a"><title>' +  esc(rowName(p) + " → " + RB.topics[k].num + " " + (RB.topics[k].short || "")) + '</title><rect class="rb-cov-cell" x="' + (x0 + j * CW + 3) + '" y="' + (y + 3) + '" width="' + (CW - 6) + '" height="' + (RH - 6) + '" rx="3"/></a>';
      });
    });
    return '<figure class="sb-fig sb-fig--hero rb-cov"><figcaption class="sb-caption">' + (kind === "survey" ? "Each square: this survey is a source for that topic. Click one to open the topic." : "Each square: this open problem bears on that topic. Click one to open the topic.") + '</figcaption><div class="sb-scroll-x">' + o + "</svg></div></figure>";
  }

  function shelf() {
    var tools = document.getElementById("shelfTools"), host = document.getElementById("shelfHost");
    var ps = RB.PAPERS.filter(function (p) { return !p.unused; });
    tools.innerHTML = '<div class="sb-seg sb-seg--sm" role="group" aria-label="Filter by part" id="shelfSeg"><button type="button" value="all" aria-pressed="true">All</button>' + RB.PARTS.map(function (p) { return '<button type="button" value="' + p.id + '" aria-pressed="false">Part ' + p.id + "</button>"; }).join("") + '</div><span class="sb-count" id="shelfCount"></span>';
    function draw(part) {
      var list = ps.filter(function (p) { return part === "all" || p.topics.some(function (k) { return RB.topics[k].part === part; }); });
      host.innerHTML = coverage(list, "survey") + '<details class="sb-more rb-shelf-more"' + (part !== "all" ? " open" : "") + '><summary>More detail: the ' + list.length + ' surveys, with titles, authors and arXiv links</summary><div class="rb-shelf">' + list.map(function (p) {
        return '<article class="rb-paper"><p class="sb-eyebrow">' + p.id + " · " + esc(p.date) + '</p><p class="rb-paper-t">' + esc(p.title) + '</p><p class="sb-caption">' + esc(p.authors) + " · " + esc(p.orgs) + "</p><p>" + esc(p.role) + '</p><div class="sb-chips">' + p.topics.map(function (k) { return '<a class="sb-tag" href="#explorer/' + k + '">' + RB.topics[k].num + "</a>"; }).join("") + '</div><a class="sb-link" href="https://arxiv.org/abs/' + p.arxiv + '" target="_blank" rel="noopener">arXiv ' + p.arxiv + " ↗</a></article>";
      }).join("") + "</div></details>";
      document.getElementById("shelfCount").textContent = list.length + " of " + ps.length + " surveys";
    }
    StudyBench.segmented(document.getElementById("shelfSeg"), function (_v, b) { draw(b.value); });
    draw("all");
  }

  /* v2.10: one Summary card per topic (#overview/<topic>), grouped under a strip per part; each card carries TopicLinks */
  function keyRule(id) {
    var t = RB.topics[id] || {}, sec = (RB.TLDR || []).filter(function (s) { return s.eq && s.eq.t === id; })[0];
    return (sec && t.rules && t.rules[sec.eq.r]) || (t.rules || [])[0] || null;
  }
  function undiff(tex) {
    var out = tex, re = /\\class\{sb-(?:new|chg)\}\{/;
    for (var g = 0; g < 50; g++) {
      var m = re.exec(out); if (!m) break;
      var i = m.index + m[0].length, d = 1, j = i;
      for (; j < out.length && d; j++) { if (out[j] === "{" && out[j - 1] !== "\\") d++; else if (out[j] === "}" && out[j - 1] !== "\\") d--; }
      out = out.slice(0, m.index) + out.slice(i, j - 1) + out.slice(j);
    }
    return out;
  }
  function card(id) {
    var t = RB.topics[id] || {}, r = keyRule(id);
    var terms = Object.keys(t.terms || {}).filter(function (k) { return RB.terms[k]; }).slice(0, 4);
    return '<article class="sb-sumcard rb-sumcard" id="ov-' + id + '" data-topic="' + id + '"><header class="sb-sumcard-head"><span class="sb-sumcard-n">' + esc(t.num || "") + '</span><h3 class="sb-sumcard-t">' + esc(t.short || t.title || id) + "</h3></header>" +
      '<p class="sb-sumcard-s">' + (t.lede || "") + "</p>" +
      (RB.topicTldr && RB.TLDR_SCENES && RB.TLDR_SCENES[RB.topicTldr(id)] ? '<div class="rb-sum-pic" data-tlthumb="' + RB.topicTldr(id) + '"></div>' : "") +
      (r ? RB.eqBlock({ name: r.name, ref: r.ref, tex: undiff(r.tex), words: r.words, key: r.key, term: r.term }, { cls: "rb-sum-eq" }) : "") +
      (terms.length ? '<div class="sb-chips"><span class="sb-caption">Key terms</span>' + terms.map(function (k) { return '<a class="sb-tag" href="#glossary/' + k + '">' + esc(RB.terms[k].name) + "</a>"; }).join("") + "</div>" : "") +
      '<footer class="sb-sumcard-foot"><span class="sb-chips"><span class="sb-ref">' + esc(t.sources || "") + "</span></span></footer>" +
      (RB.topicLinks ? RB.topicLinks("overview", [id]) : "") + "</article>";
  }
  function sums() {
    var S = RB.PART_SUMMARIES || {}, host = document.getElementById("sumHost");
    host.innerHTML = RB.PARTS.map(function (p) {
      var s = S[p.id] || {}, ids = RB.topicOrder.filter(function (k) { return RB.topics[k].part === p.id; });
      return '<div class="rb-ov-part"><article class="rb-ov-strip"><p class="sb-eyebrow">Part ' + p.id + " · topics " + RB.topics[ids[0]].num + (ids.length > 1 ? "–" + RB.topics[ids[ids.length - 1]].num : "") + '</p><h3 class="rb-h4">' + esc(p.name) + "</h3><p>" + (s.text || "") + "</p></article>" +
        '<div class="rb-sums">' + ids.map(card).join("") + "</div></div>";
    }).join("");
    /* a card opens its topic wherever you click on it (its TopicLinks also offer ▶ TL;DR) */
    host.addEventListener("click", function (e) {
      if (e.target.closest("a, button, input, select, textarea, [role=button], .sb-term-link, .sb-eqkey li, .rb-math, mjx-container")) return;
      if (window.getSelection && String(window.getSelection()).length) return;
      var c = e.target.closest(".rb-sumcard[data-topic]"); if (c) RB.go("#explorer/" + c.getAttribute("data-topic"));
    });
    /* v2.11 visual weight: each card shows its topic's TL;DR picture as a still (the finished frame), and the equation's
       "In words" and symbol key fold into More detail */
    RB.$$("#sumHost [data-tlthumb]").forEach(function (h) {
      var sec = h.getAttribute("data-tlthumb"), sc = RB.TLDR_SCENES[sec]; if (!sc) return;
      h.innerHTML = RB.tl.figure(sec + "-ov-" + h.closest("[data-topic]").getAttribute("data-topic"), sc);
      var fig = h.querySelector("figure"); fig.classList.add("rb-tl-thumb"); finishScene(fig);
      var cap = fig.querySelector(".sb-anim-cap"); if (cap) cap.remove();
    });
    RB.$$("#sumHost .rb-sum-eq").forEach(function (eq) {
      var w = eq.querySelector(".sb-eqwords"), k = eq.querySelector(".sb-eqkey"); if (!w && !k) return;
      var d = document.createElement("details"); d.className = "sb-more rb-sum-more"; d.innerHTML = "<summary>More detail: in words and symbols</summary>";
      if (w) d.appendChild(w); if (k) d.appendChild(k); eq.appendChild(d);
    });
    RB.$$("#sumHost .sb-eq").forEach(function (e) { StudyBench.link(e); });
    RB.typeset(host);
    if (RB.syncDone) RB.syncDone();
  }
  /* #overview/<topic>: centre and flash that topic's card */
  function focusCard(id) {
    var c = document.querySelector('#sumHost .rb-sumcard[data-topic="' + id + '"]'); if (!c) return;
    var h = location.hash, y1 = null;
    setTimeout(function () { c.scrollIntoView({ block: "center" }); y1 = window.scrollY; if (StudyBench.flash) StudyBench.flash(c); }, 120);
    setTimeout(function () { var r = c.getBoundingClientRect(); if (location.hash === h && window.scrollY === y1 && Math.abs(r.top + r.height / 2 - innerHeight / 2) > 24 && r.height < innerHeight) c.scrollIntoView({ block: "center" }); }, 1100);
  }

  function frontier() {
    var F = RB.FRONTIER || [];
    document.getElementById("frontHost").innerHTML = F.length ? coverage(F.map(function (f) { return { title: f.title, topics: (f.topics || []).filter(function (k) { return RB.topics[k]; }) }; }), "open") + '<div class="rb-open">' + F.map(function (f) { return '<article class="rb-open-card"><p class="rb-open-t">' + esc(f.title) + "</p><p>" + f.text + '</p><div class="sb-chips">' + (f.papers || []).map(function (p) { return '<span class="sb-ref">' + esc(p) + "</span>"; }).join("") + (f.topics || []).map(function (k) { return '<a class="sb-tag" href="#explorer/' + k + '">' + RB.topics[k].num + "</a>"; }).join("") + "</div></article>"; }).join("") + "</div>" : '<div class="sb-empty"><p>The frontier map is being written.</p></div>';
  }

  RB.pages.overview = {
    init: function () {
      ways(); heroMeta(); stack(); layers(); courseMap(); tasks(); shelf(); sums(); frontier();
      RB.linkTerms(document.getElementById("view-overview"));
      RB.hintFirstDemo("overview");
    },
    show: function (o) { if (RB.syncDone) RB.syncDone(); if (o && o.rest && o.rest[0]) focusCard(o.rest[0]); }
  };
})();
