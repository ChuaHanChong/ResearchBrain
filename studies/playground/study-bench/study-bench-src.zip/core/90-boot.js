/* ===== Guided tour (one stop per page) and boot ===== */
(function () {
  "use strict";
  var RB = window.RB, tour = null;
  RB.startTour = function () {
    if (!tour) tour = StudyBench.tour([
      { target: "#tab-overview", title: "Overview", text: "Where you are: progress, the full robot-learning stack, the course map and the paper shelf." },
      { target: "#tab-tldr", title: "TL;DR", text: "The whole field in 24 animated pictures that play by themselves, each beside a short TL;DR." },
      { target: "#tab-explorer", title: "Topic Explorer", text: "Twenty-four topics, one idea each, with a worked example, playgrounds, the methods and a quiz." },
      { target: "#tab-evolution", title: "Evolution", text: "How methods grew from each other, lane by lane, with the one change at every step." },
      { target: "#tab-compare", title: "Compare", text: "Line up any of the 646 method papers with their architectures, map them and choose." },
      { target: "#tab-lab", title: "Interactive Lab", text: "Twelve stations on one bench: policy heads, tokenizers, world models, grasps, contact and verifiers." },
      { target: "#tab-reference", title: "Reference", text: "Formula sheet, review cards, where the papers disagree, the dataset atlas and the shelf." },
      { target: "#tab-glossary", title: "Glossary", text: "Every key term shown where it lives in a picture of a robot-learning system." },
      { target: "#tab-notation", title: "Notation", text: "One house notation for all seventeen surveys, and how each paper writes the same idea." }
    ], { title: "Tour" });
    RB.go("#overview"); tour.start(0);
  };
  function start() {
    try { RB.boot(); } catch (e) { console.error(e); var m = document.getElementById("view-overview"); if (m) m.insertAdjacentHTML("afterbegin", '<div class="sb-error">The site failed to start: ' + RB.esc(e.message) + "</div>"); }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
