/* Topic 17 · Deformable, bimanual and mobile manipulation. Sources: P01 §2.1, §3.2, §4.5–4.7, Tables 2 and 7; P07 §4.4; P02 §VI-A, §VII-A; P05 §2.3.2, §5.4; method cards (topic E3). */
(function () {
  "use strict";
  /* Chamfer distance, drawn: every point of the current shape P1 joins its nearest point of the goal shape P2; d_c is the mean length */
  function chamferFig() {
    var W = 520, H = 240, P1 = [], P2 = [], i;
    for (i = 0; i < 9; i++) { var u = i / 8; P1.push([60 + u * 400, 150 - Math.sin(u * Math.PI) * 70]); }
    for (i = 0; i < 7; i++) { var v = i / 6; P2.push([90 + v * 360, 62 + v * 50]); }
    var segs = "", sum = 0;
    P1.forEach(function (p) {
      var best = null, bd = 1e9; P2.forEach(function (q) { var d = Math.hypot(p[0] - q[0], p[1] - q[1]); if (d < bd) { bd = d; best = q; } });
      sum += bd; segs += '<line class="rb-ch-seg" x1="' + p[0].toFixed(1) + '" y1="' + p[1].toFixed(1) + '" x2="' + best[0].toFixed(1) + '" y2="' + best[1].toFixed(1) + '"/>';
    });
    var dots = P1.map(function (p) { return '<circle class="rb-ch-p1" cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="6"/>'; }).join("") +
      P2.map(function (q) { return '<rect class="rb-ch-p2" x="' + (q[0] - 5).toFixed(1) + '" y="' + (q[1] - 5).toFixed(1) + '" width="10" height="10" rx="2"/>'; }).join("");
    return '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Chamfer distance: each point of the current shape is joined to its nearest point of the goal shape; the distance is the mean length of these segments">' + segs + dots +
      '<text class="rb-ch-lbl" x="30" y="228">● current shape P₁</text><text class="rb-ch-lbl" x="200" y="228">□ goal shape P₂</text><text class="rb-ch-lbl rb-ch-acc" x="352" y="228">— nearest-point gap</text>' +
      '<text class="rb-ch-lbl" x="' + (W - 12) + '" y="22" text-anchor="end">d_c = mean of the ' + P1.length + " gaps</text></svg>";
  }

  var RB = window.RB;

  /* RB.bindSeg passes b.value of a string (undefined) in this core version, so bind segmented controls directly */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); if (el) StudyBench.segmented(el, function (v) { cb(String(v)); }); return el; }
  function mono() { return getComputedStyle(document.body).getPropertyValue("--font-mono") || "monospace"; }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body") || "sans-serif"; }

  /* =====================================================================================
     Playground 1: action space of a mobile manipulator (base + arm commands vs whole-body EE targets)
     Top-down toy. Holonomic or differential base, planar 2-link arm (0.35 m + 0.30 m) at the base center.
     Task: wipe a 1.4 m line on a counter, longer than the arm's reach, in 140 steps.
     Whole-body mode: every step a damped least-squares IK (weights on base, arm and a rest posture) maps the
     end-effector target to base + arm motion, using the measured base pose.
     Base + arm mode: the same solver makes a plan assuming a perfect base; the robot executes the plan's base
     commands (with velocity error) and replays the arm joints, re-planning from the real state every chunk.
     ===================================================================================== */
  var L1 = 0.35, L2 = 0.30, TSTEPS = 140, Q0 = [-0.52, 1.13];
  function mmTarget(k) { return [-0.7 + 1.4 * k / TSTEPS, 0.25]; }
  function mmEE(st) {
    var c = Math.cos(st.th), s = Math.sin(st.th), q1 = st.q[0], q12 = st.q[0] + st.q[1];
    var ax = L1 * Math.cos(q1) + L2 * Math.cos(q12), ay = L1 * Math.sin(q1) + L2 * Math.sin(q12);
    return [st.b[0] + ax * c - ay * s, st.b[1] + ax * s + ay * c];
  }
  function mmElbow(st) { var c = Math.cos(st.th), s = Math.sin(st.th), ax = L1 * Math.cos(st.q[0]), ay = L1 * Math.sin(st.q[0]); return [st.b[0] + ax * c - ay * s, st.b[1] + ax * s + ay * c]; }
  function solveLin(A, b) {
    var n = b.length, M = A.map(function (r, i) { return r.concat([b[i]]); }), i, r, c;
    for (i = 0; i < n; i++) {
      var p = i; for (r = i + 1; r < n; r++) if (Math.abs(M[r][i]) > Math.abs(M[p][i])) p = r;
      var t = M[i]; M[i] = M[p]; M[p] = t;
      for (r = i + 1; r < n; r++) { var f = M[r][i] / M[i][i]; for (c = i; c <= n; c++) M[r][c] -= f * M[i][c]; }
    }
    var x = new Array(n);
    for (i = n - 1; i >= 0; i--) { var sm = M[i][n]; for (c = i + 1; c < n; c++) sm -= M[i][c] * x[c]; x[i] = sm / M[i][i]; }
    return x;
  }
  /* one IK solve: u = [forward, lateral, turn, dq1, dq2] */
  function mmIK(st, tg, holo) {
    var c = Math.cos(st.th), s = Math.sin(st.th), p = mmEE(st), rx = p[0] - st.b[0], ry = p[1] - st.b[1];
    var q1 = st.q[0], q12 = st.q[0] + st.q[1];
    var j1 = [-L1 * Math.sin(q1) - L2 * Math.sin(q12), L1 * Math.cos(q1) + L2 * Math.cos(q12)], j2 = [-L2 * Math.sin(q12), L2 * Math.cos(q12)];
    var cols = [[c, s], [-s, c], [-ry, rx], [j1[0] * c - j1[1] * s, j1[0] * s + j1[1] * c], [j2[0] * c - j2[1] * s, j2[0] * s + j2[1] * c]];
    var W = [1.5, holo ? 1.5 : 1e6, 4.5, 0.5, 0.5], wp = 0.05, e = [tg[0] - p[0], tg[1] - p[1]], A = [], bb = [];
    for (var i = 0; i < 5; i++) {
      A.push([]);
      for (var j = 0; j < 5; j++) A[i].push(cols[i][0] * cols[j][0] + cols[i][1] * cols[j][1] + (i === j ? W[i] * 0.01 + (i > 2 ? wp : 0) : 0));
      bb.push(cols[i][0] * e[0] + cols[i][1] * e[1] + (i > 2 ? wp * (Q0[i - 3] - st.q[i - 3]) : 0));
    }
    var u = solveLin(A, bb), sp = Math.hypot(u[0], u[1]);
    if (sp > 0.05) { u[0] *= 0.05 / sp; u[1] *= 0.05 / sp; }
    u[2] = RB.clamp(u[2], -0.15, 0.15); u[3] = RB.clamp(u[3], -0.2, 0.2); u[4] = RB.clamp(u[4], -0.2, 0.2);
    return u;
  }
  function mmApply(st, u, f, n) {
    var c = Math.cos(st.th), s = Math.sin(st.th), fw = u[0] * f, la = u[1] * f + n;
    st.b = [st.b[0] + fw * c - la * s, Math.min(-0.22, st.b[1] + fw * s + la * c)];
    st.th += u[2] * f;
    st.q = [st.q[0] + u[3], RB.clamp(st.q[1] + u[4], 0.1, 2.8)];
  }
  function mmClone(s) { return { b: s.b.slice(), th: s.th, q: s.q.slice() }; }
  function mmInit() { var st = { b: [-0.7, -0.3], th: Math.PI / 2, q: Q0.slice() }; for (var i = 0; i < 40; i++) { var u = mmIK(st, mmTarget(0), true); mmApply(st, [0, 0, 0, u[3], u[4]], 1, 0); } return st; }
  function mmRun(mode, holo, errPct, chunk, seed) {
    var R = RB.rng(seed), st = mmInit(), bias = 1 + (R() < 0.5 ? -1 : 1) * errPct / 100, plan = [], errs = [], snaps = [], ees = [], travel = 0, turn = 0;
    for (var k = 0; k <= TSTEPS; k++) {
      var tg = mmTarget(k), b0 = st.b.slice(), th0 = st.th, it, du;
      if (mode === "sep") {
        if (k % chunk === 0) {
          var sp = mmClone(st); plan = [];
          for (var j = k; j < k + chunk && j <= TSTEPS; j++) {
            var u = [0, 0, 0, 0, 0];
            for (it = 0; it < 3; it++) { du = mmIK(sp, mmTarget(j), holo); mmApply(sp, du, 1, 0); for (var z = 0; z < 5; z++) u[z] += du[z]; }
            plan.push({ u: u, q: sp.q.slice() });
          }
        }
        var P = plan[k % chunk];
        mmApply(st, [P.u[0], P.u[1], P.u[2], 0, 0], bias, errPct / 100 * 0.01 * R.normal()); st.q = P.q.slice();
      } else {
        for (it = 0; it < 3; it++) { du = mmIK(st, tg, holo); mmApply(st, du, bias, errPct / 100 * 0.01 * R.normal()); }
      }
      travel += Math.hypot(st.b[0] - b0[0], st.b[1] - b0[1]); turn += Math.abs(st.th - th0);
      var p = mmEE(st); ees.push(p); errs.push(Math.hypot(p[0] - tg[0], p[1] - tg[1]));
      if (k % 35 === 0) snaps.push(mmClone(st));
    }
    var mean = errs.reduce(function (a, b) { return a + b; }, 0) / errs.length;
    return { mean: mean, max: Math.max.apply(null, errs), ok: errs.filter(function (e) { return e < 0.03; }).length / errs.length, travel: travel, turn: turn, errs: errs, ees: ees, snaps: snaps, last: mmClone(st) };
  }

  function mountMobile(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Action space", value: "sep", options: [{ value: "sep", label: "Separate commands" }, { value: "wbc", label: "Whole-body" }] }) +
      RB.seg({ id: id + "-base", label: "Base type", value: "holo", options: [{ value: "holo", label: "Holonomic" }, { value: "diff", label: "Differential" }] }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-err", label: "Base velocity error", min: 0, max: 20, step: 1, value: 10, fmt: function (v) { return v + "%"; } }) +
      RB.slider({ id: id + "-chunk", label: "Steps per chunk", min: 5, max: 140, step: 5, value: 140 }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Run again ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Top-down view of a mobile manipulator wiping a line on a counter"></canvas><figcaption class="sb-caption">Top view. Dashed line = the wipe target on the counter. The trace turns red where the end effector is more than 3 cm off. Gray outlines = the base every 35 steps.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "wiped", k: "Wipe line within 3 cm" }, { id: "mean", k: "Mean end-effector error", u: "cm" }, { id: "max", k: "Worst error", u: "cm" }, { id: "travel", k: "Base travel", u: "m" }, { id: "turn", k: "Base turning", u: "°" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "within 3 cm", kind: "line" }, { c: "bad", label: "more than 3 cm off", kind: "line" }, { c: "ink-3", label: "target line", kind: "dash" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), chunkIn = body.querySelector("#" + id + "-chunk");
    var S = { mode: "sep", holo: true, err: 10, chunk: 140, seed: 5 }, last = null, W = 540, H = 320;
    function toPx(p) { return [W / 2 + p[0] * 250, 130 - p[1] * 250]; }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H);
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var y0 = toPx([0, 0])[1];
      c.fillStyle = P["surface-strong"]; c.fillRect(0, 0, W, y0); c.strokeStyle = P["line-strong"]; c.beginPath(); c.moveTo(0, y0); c.lineTo(W, y0); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono(); c.fillText("counter", 10, y0 - 8);
      var a = toPx(mmTarget(0)), b = toPx(mmTarget(TSTEPS));
      c.strokeStyle = P["ink-3"]; c.lineWidth = 2; c.setLineDash([6, 5]); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); c.setLineDash([]); c.lineWidth = 1;
      if (!last) return;
      function base(st, strong) {
        c.save(); var o = toPx(st.b); c.translate(o[0], o[1]); c.rotate(-st.th);
        c.strokeStyle = strong ? P.ink : P["line-strong"]; c.lineWidth = strong ? 2 : 1; c.globalAlpha = strong ? 1 : 0.7;
        c.strokeRect(-0.2 * 250, -0.2 * 250, 0.4 * 250, 0.4 * 250);
        c.beginPath(); c.moveTo(0.12 * 250, 0); c.lineTo(0.2 * 250, 0); c.stroke(); c.restore(); c.globalAlpha = 1; c.lineWidth = 1;
      }
      last.snaps.forEach(function (s) { base(s, false); });
      for (var k = 1; k < last.ees.length; k++) {
        var p0 = toPx(last.ees[k - 1]), p1 = toPx(last.ees[k]);
        c.strokeStyle = last.errs[k] < 0.03 ? P["data-1"] : P.bad; c.lineWidth = 3; c.beginPath(); c.moveTo(p0[0], p0[1]); c.lineTo(p1[0], p1[1]); c.stroke();
      }
      c.lineWidth = 1;
      var st = last.last; base(st, true);
      var o = toPx(st.b), el = toPx(mmElbow(st)), e = toPx(mmEE(st));
      c.strokeStyle = P.ink; c.lineWidth = 4; c.beginPath(); c.moveTo(o[0], o[1]); c.lineTo(el[0], el[1]); c.lineTo(e[0], e[1]); c.stroke(); c.lineWidth = 1;
      c.fillStyle = P.ink; c.beginPath(); c.arc(o[0], o[1], 4, 0, Math.PI * 2); c.fill(); c.beginPath(); c.arc(el[0], el[1], 3, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["data-1"]; c.beginPath(); c.arc(e[0], e[1], 5, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + bodyFont(); c.fillText("end", b[0] - 18, b[1] - 12); c.fillText("start", a[0] - 14, a[1] - 12);
    }
    function run() {
      last = mmRun(S.mode, S.holo, S.err, S.chunk, S.seed);
      RB.setRO(body, "wiped", Math.round(100 * last.ok) + "%");
      RB.setRO(body, "mean", RB.fmt(last.mean * 100, 1)); RB.setRO(body, "max", RB.fmt(last.max * 100, 1));
      RB.setRO(body, "travel", RB.fmt(last.travel, 2)); RB.setRO(body, "turn", RB.fmt(last.turn * 180 / Math.PI, 0));
      chunkIn.disabled = S.mode === "wbc";
      note.textContent = S.mode === "wbc"
        ? "Whole-body: the policy gives only the end-effector target; an IK solve re-reads the base pose every step, so the arm absorbs base error (HoMeR, arXiv 2506.01185)."
        : (S.chunk >= TSTEPS ? "Separate commands, open loop: the arm replays its plan while the base drifts, so the error grows with distance. Mobile ALOHA saw >10 cm base error on a 1 m turn." : "Separate commands, re-planned every " + S.chunk + " steps: each chunk starts from the real state, so drift resets. Mobile ALOHA's ACT used chunks of 45.");
      draw();
    }
    bindSeg(body, id + "-mode", function (v) { S.mode = v; run(); });
    bindSeg(body, id + "-base", function (v) { S.holo = v === "holo"; run(); });
    RB.bindSlider(body, id + "-err", function (v) { return v + "%"; }, function (v) { S.err = v; run(); });
    RB.bindSlider(body, id + "-chunk", null, function (v) { S.chunk = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { S.seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { mode: S.mode, holo: S.holo, err: S.err, chunk: S.chunk, ok: last ? last.ok : 0 }; } };
  }

  /* =====================================================================================
     Playground 2: rope shape control with a chosen state representation
     2-D rope of 21 particles (5 cm links) lying on a table; high friction, so a dragged particle pulls only the
     links that go taut (inextensible chain, slack allowed). Each action picks the tracked point that is farthest
     from its goal (the DeformerNet heuristic: grasp where the shape must move most) and drags it to its goal spot.
     The robot sees only the tracked points; the true error is the full Chamfer distance.
     ===================================================================================== */
  var RN = 21, RSEG = 0.05;
  function rStraight() { var p = []; for (var i = 0; i < RN; i++) p.push([-0.5 + i * RSEG, 0]); return p; }
  function rFix(q, a, b) { var dx = q[b][0] - q[a][0], dy = q[b][1] - q[a][1], L = Math.hypot(dx, dy); if (L > RSEG) { var k = RSEG / L; q[b] = [q[a][0] + dx * k, q[a][1] + dy * k]; } }
  function rDrag(p, g, d) { var q = p.map(function (a) { return a.slice(); }), i; q[g] = [q[g][0] + d[0], q[g][1] + d[1]]; for (i = g + 1; i < RN; i++) rFix(q, i - 1, i); for (i = g - 1; i >= 0; i--) rFix(q, i + 1, i); return q; }
  function rMoveTo(p, g, t) { var n = 12, d = [(t[0] - p[g][0]) / n, (t[1] - p[g][1]) / n]; for (var i = 0; i < n; i++) p = rDrag(p, g, d); return p; }
  function rIdx(K) { var idx = []; for (var j = 0; j < K; j++) idx.push(Math.round(j * (RN - 1) / (K - 1))); return idx; }
  function rMeas(p, goal, K) { var idx = rIdx(K); return idx.reduce(function (s, i) { return s + Math.hypot(p[i][0] - goal[i][0], p[i][1] - goal[i][1]); }, 0) / idx.length; }
  function rChamfer(A, B) {
    function one(X, Y) { return X.reduce(function (s, x) { var m = 1e9; Y.forEach(function (y) { m = Math.min(m, Math.hypot(x[0] - y[0], x[1] - y[1])); }); return s + m; }, 0) / X.length; }
    return 0.5 * (one(A, B) + one(B, A));
  }
  var RGOAL = (function () { var g = rStraight(); g = rMoveTo(g, 14, [0.12, 0.22]); g = rMoveTo(g, 4, [-0.22, -0.12]); return g; })();

  function mountRope(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-rep", label: "State the robot tracks", value: "3", options: [{ value: "2", label: "2 ends" }, { value: "3", label: "3 keypoints" }, { value: "5", label: "5 keypoints" }, { value: "21", label: "All 21" }] }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-act">Take action ▶</button><button class="sb-btn" type="button" id="' + id + '-reset">Reset rope</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Rope on a table with its goal shape"></canvas><figcaption class="sb-caption">Dashed = goal shape. Solid = the rope now. Large dots = the points the robot tracks. The arrow shows where the last grasp was dragged.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "true", k: "True shape error (Chamfer)", u: "cm" }, { id: "seen", k: "Error the robot measures", u: "cm" }, { id: "grasp", k: "Last grasp point" }, { id: "acts", k: "Actions taken" }]) +
      '<p class="sb-caption" data-note></p><div data-chart></div></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), host = body.querySelector("[data-chart]");
    var K = 3, rope = rStraight(), acts = 0, lastG = -1, lastFrom = null, hist = [], done = false, W = 520, H = 300;
    function toPx(p) { return [W / 2 + p[0] * 420, H / 2 - p[1] * 420 + 10]; }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H);
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; for (var gx = 0; gx <= W; gx += 42) { c.beginPath(); c.moveTo(gx, 0); c.lineTo(gx, H); c.stroke(); }
      function line(pts, col, w, dash) { c.strokeStyle = col; c.lineWidth = w; c.setLineDash(dash || []); c.beginPath(); pts.forEach(function (p, i) { var z = toPx(p); if (i) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke(); c.setLineDash([]); c.lineWidth = 1; }
      line(RGOAL, P["ink-3"], 2, [6, 5]);
      line(rope, P["data-1"], 3);
      rope.forEach(function (p) { var z = toPx(p); c.fillStyle = P["data-1"]; c.beginPath(); c.arc(z[0], z[1], 2.5, 0, Math.PI * 2); c.fill(); });
      rIdx(K).forEach(function (i) { var z = toPx(rope[i]), g = toPx(RGOAL[i]); c.fillStyle = P.accent; c.beginPath(); c.arc(z[0], z[1], 6, 0, Math.PI * 2); c.fill(); c.strokeStyle = P.accent; c.beginPath(); c.arc(g[0], g[1], 5, 0, Math.PI * 2); c.stroke(); });
      if (lastG >= 0 && lastFrom) {
        var f = toPx(lastFrom), t = toPx(rope[lastG]); c.strokeStyle = P.ink; c.lineWidth = 2; c.beginPath(); c.moveTo(f[0], f[1]); c.lineTo(t[0], t[1]); c.stroke(); c.lineWidth = 1;
        var ang = Math.atan2(t[1] - f[1], t[0] - f[0]); c.fillStyle = P.ink; c.beginPath(); c.moveTo(t[0], t[1]); c.lineTo(t[0] - 9 * Math.cos(ang - 0.4), t[1] - 9 * Math.sin(ang - 0.4)); c.lineTo(t[0] - 9 * Math.cos(ang + 0.4), t[1] - 9 * Math.sin(ang + 0.4)); c.fill();
      }
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono(); c.fillText("goal (dashed)", 10, 18);
    }
    function chart() {
      host.innerHTML = "";
      if (hist.length < 2) { host.innerHTML = '<p class="sb-caption">The error chart fills in as you take actions.</p>'; return; }
      StudyBench.lineChart(host, { title: "Shape error after each action", height: 180, directLabels: false, x: { label: "actions", min: 0, max: 4 }, y: { label: "error (cm)", min: 0, max: 13, fmt: function (v) { return (+v).toFixed(1); } },
        series: [{ name: "true (Chamfer)", color: "data-1", points: hist.map(function (h) { return [h[0], h[1]]; }) }, { name: "robot measures", color: "data-2", dash: true, points: hist.map(function (h) { return [h[0], h[2]]; }) }] });
    }
    function update() {
      var tr = rChamfer(rope, RGOAL) * 100, se = rMeas(rope, RGOAL, K) * 100;
      RB.setRO(body, "true", RB.fmt(tr, 1)); RB.setRO(body, "seen", RB.fmt(se, 1));
      RB.setRO(body, "grasp", lastG >= 0 ? "point " + lastG : "–"); RB.setRO(body, "acts", acts + " of 4");
      if (done) note.textContent = se < 1 && tr > 3 ? "The robot thinks it is done: its tracked points match the goal, but the true shape is still " + RB.fmt(tr, 1) + " cm off. The bends fall between the tracked points." : "Stopped. The tracked points are as close as this simple pick-and-drag rule can get.";
      else note.textContent = "Each action grasps the tracked point farthest from its goal and drags it there. DeformerNet also grasps where the shape must move most (arXiv 2110.04685).";
      chart(); draw();
    }
    function reset() { rope = rStraight(); acts = 0; lastG = -1; lastFrom = null; done = false; hist = [[0, rChamfer(rope, RGOAL) * 100, rMeas(rope, RGOAL, K) * 100]]; update(); }
    function act() {
      if (done || acts >= 4) { done = true; update(); return; }
      var g = -1, best = 0.01;
      rIdx(K).forEach(function (i) { var d = Math.hypot(rope[i][0] - RGOAL[i][0], rope[i][1] - RGOAL[i][1]); if (d > best) { best = d; g = i; } });
      if (g < 0) { done = true; update(); return; }
      lastFrom = rope[g].slice(); rope = rMoveTo(rope, g, RGOAL[g]); lastG = g; acts++;
      hist.push([acts, rChamfer(rope, RGOAL) * 100, rMeas(rope, RGOAL, K) * 100]);
      if (acts >= 4) done = true;
      update();
    }
    bindSeg(body, id + "-rep", function (v) { K = +v; reset(); });
    body.querySelector("#" + id + "-act").addEventListener("click", act);
    body.querySelector("#" + id + "-reset").addEventListener("click", reset);
    RB.onTheme(draw);
    reset();
    return { state: function () { return { K: K, acts: acts, done: done, trueErr: rChamfer(rope, RGOAL) * 100 }; } };
  }

  /* =====================================================================================
     Playground 3: two arms lift one tray
     Each arm lifts its end of a 0.30 m tray by 0.30 m in 0.8 s on a minimum-jerk profile. Two separate single-arm policies
     start after independent delays and run at slightly different speeds; one joint policy (one 14-D chunk) shares
     timing, so only small tracking noise remains. A cup slides off when the tilt passes arctan(0.2) = 11.3°.
     ===================================================================================== */
  function mj(s) { s = RB.clamp(s, 0, 1); return s * s * s * (10 - 15 * s + 6 * s * s); }
  function trayTrial(joint, jitter, R) {
    var dL = R() * jitter, dR = joint ? dL : R() * jitter, vL = 1 + 0.08 * R.normal(), vR = joint ? vL : 1 + 0.08 * R.normal(), zl = [], zr = [], tilt = [], maxT = 0;
    for (var i = 0; i <= 60; i++) {
      var t = i * 0.025, a = 0.3 * mj((t - dL) * vL / 0.8), b = 0.3 * mj((t - dR) * vR / 0.8);
      if (joint) b += 0.002 * R.normal();
      var th = Math.atan2(Math.abs(a - b), 0.3) * 180 / Math.PI;
      zl.push([+t.toFixed(3), a * 100]); zr.push([+t.toFixed(3), b * 100]); tilt.push(th); maxT = Math.max(maxT, th);
    }
    return { zl: zl, zr: zr, maxT: maxT, ok: maxT < 11.3 };
  }
  function mountTray(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-pol", label: "Policy", value: "sep", options: [{ value: "sep", label: "Two policies" }, { value: "joint", label: "Joint policy" }] }) +
      RB.slider({ id: id + "-jit", label: "Start delay spread", min: 0, max: 400, step: 20, value: 200, fmt: function (v) { return v + " ms"; } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Run 20 lifts ▶</button></div>' +
      '<div class="rb-grid2"><div data-chart></div><div class="rb-stack">' + RB.readouts([{ id: "succ", k: "Lifts that keep the cup" }, { id: "tilt", k: "Worst tilt in lift 1", u: "°" }, { id: "limit", k: "Cup slides above", u: "°" }]) +
      '<p class="sb-caption" data-note></p></div></div>';
    var host = body.querySelector("[data-chart]"), note = body.querySelector("[data-note]"), S = { joint: false, jit: 200, seed: 11 }, res = null;
    function run() {
      var R = RB.rng(S.seed), trials = []; for (var i = 0; i < 20; i++) trials.push(trayTrial(S.joint, S.jit / 1000, R));
      res = trials;
      RB.setRO(body, "succ", trials.filter(function (t) { return t.ok; }).length + " of 20"); RB.setRO(body, "tilt", RB.fmt(trials[0].maxT, 1)); RB.setRO(body, "limit", "11.3");
      note.textContent = S.joint ? "One policy outputs both arms in the same chunk, so their timing is shared. Leader–follower rigs such as ALOHA record both arms together, which is what makes this data possible." : "Each arm starts on its own clock. A late start on one side tilts the tray. P01 §2.1 lists temporal synchronization as a core bimanual challenge.";
      host.innerHTML = "";
      StudyBench.lineChart(host, { title: "Lift 1: height of each tray end", height: 200, directLabels: false, x: { label: "time (s)", min: 0, max: 1.5 }, y: { label: "height (cm)", min: 0, max: 31, fmt: function (v) { return (+v).toFixed(1); } },
        series: [{ name: "left end", color: "data-1", points: trials[0].zl }, { name: "right end", color: "data-2", dash: true, points: trials[0].zr }],
        caption: "The gap between the two lines is the tilt. Illustrative toy: minimum-jerk lifts, 8% speed spread per arm." });
    }
    bindSeg(body, id + "-pol", function (v) { S.joint = v === "joint"; run(); });
    RB.bindSlider(body, id + "-jit", function (v) { return v + " ms"; }, function (v) { S.jit = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { S.seed++; run(); });
    run();
    return { state: function () { return { joint: S.joint, jit: S.jit, succ: res ? res.filter(function (t) { return t.ok; }).length : 0 }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token classes only) ---------- */
  var ropePts = [[14, 40], [30, 30], [46, 26], [62, 30], [78, 40], [94, 44], [110, 38], [126, 26], [142, 18], [158, 20], [174, 30], [188, 38]];
  var ART = {
    dstate: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M' + ropePts.map(function (p) { return p.join(" "); }).join(" L") + '" class="rb-s-acc"/>' + ropePts.map(function (p) { return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="2.6" class="rb-f-acc"/>'; }).join("") + '<text x="100" y="54" text-anchor="middle" class="rb-t-mono">a set of points</text></svg>',
    servo: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 38 Q40 20 70 38" class="rb-s-ink"/><path d="M130 38 Q150 8 190 30" class="rb-s-line" stroke-dasharray="3 3"/><path d="M78 30 H122" class="rb-s-acc"/><path d="M116 26 L122 30 L116 34" class="rb-s-acc"/><text x="40" y="54" text-anchor="middle" class="rb-t-mono">Pc now</text><text x="160" y="54" text-anchor="middle" class="rb-t-mono">Pg goal</text><text x="100" y="20" text-anchor="middle" class="rb-t-acc">Δx</text></svg>',
    mpoint: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 40 H80 Q100 40 120 20 L150 10" class="rb-s-ink"/><path d="M10 40 H190" class="rb-s-line" stroke-dasharray="3 3"/><circle cx="120" cy="20" r="6" class="rb-f-acc"/><text x="132" y="36" class="rb-t-mono">grasp here</text><text x="14" y="54" class="rb-t-mono">fixed end</text></svg>',
    teleop: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M20 46 L34 22 L54 16" class="rb-s-line"/><circle cx="34" cy="22" r="3" class="rb-f-surface"/><path d="M130 46 L148 20 L176 12" class="rb-s-ink"/><circle cx="148" cy="20" r="3.5" class="rb-f-acc"/><path d="M66 30 H118" class="rb-s-acc" stroke-dasharray="4 3"/><path d="M112 26 L118 30 L112 34" class="rb-s-acc"/><text x="36" y="54" text-anchor="middle" class="rb-t-mono">leader</text><text x="152" y="54" text-anchor="middle" class="rb-t-mono">follower</text><text x="92" y="24" text-anchor="middle" class="rb-t-mono">joints</text></svg>',
    bimanual: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="60" y="22" width="80" height="6" rx="2" class="rb-f-soft"/><path d="M30 50 L44 30 L62 25" class="rb-s-ink"/><path d="M170 50 L156 30 L138 25" class="rb-s-ink"/><rect x="92" y="12" width="14" height="10" rx="2" class="rb-f-acc"/><text x="100" y="46" text-anchor="middle" class="rb-t-mono">one action: 14-D</text></svg>',
    wbc: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="16" y="28" width="46" height="20" rx="3" class="rb-f-sunk"/><circle cx="26" cy="50" r="4" class="rb-f-surface"/><circle cx="52" cy="50" r="4" class="rb-f-surface"/><path d="M40 28 L70 12 L104 20" class="rb-s-ink"/><circle cx="104" cy="20" r="4" class="rb-f-acc"/><path d="M112 20 H128" class="rb-s-acc"/><text x="134" y="16" class="rb-t-mono">EE target</text><text x="134" y="32" class="rb-t-mono">↓ IK</text><text x="134" y="48" class="rb-t-mono">base, arm</text></svg>',
    mixing: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="16" y="10" width="54" height="16" rx="3" class="rb-f-soft"/><text x="43" y="22" text-anchor="middle" class="rb-t-mono">A manip</text><rect x="16" y="32" width="54" height="16" rx="3" class="rb-f-sunk"/><text x="43" y="44" text-anchor="middle" class="rb-t-mono">A loco</text><path d="M72 18 L128 18 M72 40 L128 40" class="rb-s-ink"/><path d="M72 40 L128 18" class="rb-s-acc" stroke-dasharray="3 3"/><path d="M72 18 L128 40" class="rb-s-acc" stroke-dasharray="3 3"/><text x="160" y="22" text-anchor="middle" class="rb-t-mono">arm</text><text x="160" y="44" text-anchor="middle" class="rb-t-mono">legs</text><text x="100" y="54" text-anchor="middle" class="rb-t-acc">β</text></svg>',
    cotrain: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="14" y="10" width="60" height="16" rx="3" class="rb-f-soft"/><text x="44" y="22" text-anchor="middle" class="rb-t-mono">mobile</text><rect x="14" y="30" width="60" height="16" rx="3" class="rb-f-sunk"/><text x="44" y="42" text-anchor="middle" class="rb-t-mono">static</text><path d="M78 18 L110 28 M78 38 L110 28" class="rb-s-ink"/><rect x="114" y="18" width="80" height="20" rx="4" class="rb-f-soft"/><text x="154" y="32" text-anchor="middle" class="rb-t-mono">one policy</text></svg>'
  };

  /* ---------- worked example figure: one whole-body IK solve along a line (numbers computed in the steps) ---------- */
  var X = function (v) { return (40 + (v - 0.3) * 480).toFixed(1); };
  function baseBox(b, cls, extra) { return '<rect x="' + (+X(b) - 22).toFixed(1) + '" y="70" width="44" height="26" rx="4" class="' + cls + '"' + (extra || "") + '/>'; }
  var WE_FIG = '<svg viewBox="0 0 560 170" role="img" aria-label="A base and an arm on a line; the end effector moves from 0.90 m toward a target at 1.20 m">' +
    '<line x1="30" y1="100" x2="530" y2="100" class="rb-s-line"/>' +
    '<g class="rb-t-mono"><text x="' + X(0.4) + '" y="118" text-anchor="middle">0.40</text><text x="' + X(0.9) + '" y="118" text-anchor="middle">0.90</text><text x="' + X(1.2) + '" y="118" text-anchor="middle">1.20 m</text></g>' +
    '<g data-on="1+"><line x1="' + X(1.2) + '" y1="30" x2="' + X(1.2) + '" y2="100" class="rb-s-acc" stroke-dasharray="4 3"/><text x="' + X(1.2) + '" y="24" text-anchor="middle" class="rb-t-acc">target</text></g>' +
    '<g data-on="1-2">' + baseBox(0.4, "rb-f-sunk") + '<line x1="' + X(0.4) + '" y1="70" x2="' + X(0.9) + '" y2="58" class="rb-s-ink" stroke-width="3"/><circle cx="' + X(0.9) + '" cy="58" r="6" class="rb-f-surface"/><text x="' + X(0.65) + '" y="50" text-anchor="middle" class="rb-t-ink">e = 0.30</text></g>' +
    '<g data-on="2"><text x="' + X(0.4) + '" y="146" text-anchor="middle" class="rb-t-mono">w_b = 1.5</text><text x="' + X(0.72) + '" y="146" text-anchor="middle" class="rb-t-mono">w_u = 0.5</text></g>' +
    '<g data-on="3">' + baseBox(0.4, "rb-f-surface", ' stroke-dasharray="3 3"') + baseBox(0.455, "rb-f-sunk") + '<line x1="' + X(0.455) + '" y1="70" x2="' + X(1.118) + '" y2="58" class="rb-s-ink" stroke-width="3"/><circle cx="' + X(1.118) + '" cy="58" r="6" class="rb-f-acc"/><text x="' + X(0.455) + '" y="146" text-anchor="middle" class="rb-t-acc">Δb = 0.055</text><text x="' + X(0.86) + '" y="146" text-anchor="middle" class="rb-t-acc">Δu = 0.164</text><text x="' + X(1.118) + '" y="46" text-anchor="middle" class="rb-t-ink">1.118</text></g>' +
    '<g data-on="4">' + baseBox(0.475, "rb-f-sunk") + '<line x1="' + X(0.475) + '" y1="70" x2="' + X(1.194) + '" y2="58" class="rb-s-ink" stroke-width="3"/><circle cx="' + X(1.194) + '" cy="58" r="6" class="rb-f-acc"/><text x="' + X(0.9) + '" y="46" text-anchor="middle" class="rb-t-ink">1.118 → 1.178 → 1.194</text><text x="' + X(0.475) + '" y="146" text-anchor="middle" class="rb-t-acc">base 25%</text></g>' +
    '<g data-on="5-6">' + baseBox(0.475, "rb-f-surface", ' stroke-dasharray="3 3"') + baseBox(0.525, "rb-f-sunk") + '<text x="' + X(0.5) + '" y="146" text-anchor="middle" class="rb-t-mono">base slips +5 cm</text></g>' +
    '<g data-on="5"><line x1="' + X(0.525) + '" y1="70" x2="' + X(1.244) + '" y2="58" class="rb-s-ink" stroke-width="3"/><circle cx="' + X(1.244) + '" cy="58" r="6" class="rb-f-surface"/><text x="' + X(1.244) + '" y="46" text-anchor="middle" class="rb-t-ink">1.244: 5 cm past</text></g>' +
    '<g data-on="6"><line x1="' + X(0.525) + '" y1="70" x2="' + X(1.2) + '" y2="58" class="rb-s-ink" stroke-width="3"/><circle cx="' + X(1.2) + '" cy="58" r="6" class="rb-f-acc"/><text x="' + X(1.0) + '" y="46" text-anchor="middle" class="rb-t-acc">arm pulls back</text></g></svg>';

  RB.topic({
    id: "e3",
    title: "Deformable, bimanual and mobile manipulation",
    eyebrow: "Part E · Beyond the rigid tabletop",
    lede: "Cloth has no single pose, two arms must share one clock, and a moving base shifts every reach. Each changes the state or the action space.",
    refs: ["P01 §4.5–4.7, Table 7", "P07 §4.4", "P02 §VI-A", "P05 §2.3.2"],
    why: "Most policies you have met so far control one fixed arm and a rigid object. Three settings break those assumptions: deformable objects need a new state representation, bimanual tasks need coupled actions and matching data, and mobile manipulators need an action space that coordinates base and arm.",
    outcomes: [
      "Explain why cloth and rope need point-set or latent state representations.",
      "Compare separate base and arm commands with whole-body end-effector actions.",
      "Compute one weighted whole-body inverse kinematics (IK) step by hand.",
      "Describe how leader–follower teleoperation produces synchronized bimanual data.",
      "Trace what DeformerNet, Deep Whole-Body Control, HoMeR and χ0 each changed."
    ],
    concepts: [
      { name: "No fixed pose", def: "A deformable object's shape varies under force, so its state is a point cloud, particle set, mesh or latent.", ref: "P01 §4.5", art: ART.dstate, term: "deformable-object-manipulation" },
      { name: "Shape servoing", def: "Compare current and goal point clouds and move the gripper to shrink the difference, step by step.", ref: "arXiv 2110.04685", art: ART.servo, term: "shape-servoing", sym: "pc" },
      { name: "Manipulation point", def: "Where to grasp a deformable object; a poor choice can make the goal shape unreachable.", ref: "arXiv 2110.04685", art: ART.mpoint, term: "manipulation-point" },
      { name: "Leader–follower teleoperation", def: "An operator moves leader arms; follower arms copy their joints, recording both arms in sync.", ref: "P05 §2.3.2 · P02 §VI-A", art: ART.teleop, term: "leader-follower-teleoperation" },
      { name: "One action for two arms", def: "A bimanual policy outputs both arms' joints together, for example 14 numbers per step on ALOHA.", ref: "P01 §2.1", art: ART.bimanual, term: "bimanual-coordination", sym: "a" },
      { name: "Whole-body controller", def: "Turns an end-effector target into base and arm joint motion with inverse kinematics.", ref: "HoMeR, arXiv 2506.01185", art: ART.wbc, term: "whole-body-control", sym: "Jac" },
      { name: "Advantage mixing", def: "Credits arm actions mainly by manipulation reward and leg actions by locomotion reward, mixed by a curriculum.", ref: "arXiv 2210.10044", art: ART.mixing, term: "advantage-mixing", sym: "adv" },
      { name: "Co-training with static data", def: "Mobile ALOHA trains on its mobile demonstrations plus static bimanual episodes, with base actions set to zero.", ref: "arXiv 2401.02117", art: ART.cotrain, term: "co-training" }
    ],
    flow: {
      title: "Where these methods act in a mobile bimanual system", ref: "P07 §4.4 · P01 §4.6", w: 820, h: 280,
      caption: "Demonstrations shape the policy; the policy's output space decides whether a whole-body solver sits between it and the motors. Deformable objects change what the observation must describe.",
      nodes: [
        { id: "demos", x: 20, y: 30, w: 160, h: 52, label: "Teleop demos", sub: "leader–follower, phone", kind: "store" },
        { id: "obs", x: 20, y: 170, w: 160, h: 52, label: "Observation", sub: "point cloud, RGB", kind: "env" },
        { id: "pol", x: 250, y: 100, w: 160, h: 60, label: "Policy", sub: "EE targets or chunks", kind: "agent" },
        { id: "wbc", x: 470, y: 100, w: 150, h: 60, label: "Whole-body IK", sub: "QP per step", kind: "decision" },
        { id: "robot", x: 670, y: 100, w: 130, h: 60, label: "Base + arms", sub: "joint commands", kind: "env" }
      ],
      edges: [
        { from: "demos", to: "pol", label: "train", sides: ["r", "t"], via: [[330, 56]] },
        { from: "obs", to: "pol", label: "state", sides: ["r", "b"], via: [[330, 196]] },
        { from: "pol", to: "wbc", label: "EE pose", dy: -8 },
        { from: "wbc", to: "robot", label: "joints", dy: -8 },
        { from: "robot", to: "obs", label: "object changes", sides: ["b", "b"], via: [[735, 260], [100, 260]], dy: -6 }
      ],
      steps: [
        { on: ["demos"], text: "Bimanual demonstrations usually come from leader–follower rigs such as ALOHA; TidyBot++ collects mobile demonstrations with a phone interface." },
        { on: ["obs", "obs>pol"], text: "For cloth or rope the observation must describe a shape, not a pose: DeformerNet reads partial point clouds of the current and goal shape." },
        { on: ["demos>pol", "pol"], text: "The policy outputs either separate base and arm commands (Mobile ALOHA's 16-D action) or one end-effector (EE) target (HoMeR)." },
        { on: ["pol>wbc", "wbc", "wbc>robot", "robot"], text: "With end-effector targets, a whole-body solver splits the motion between base and arm every step, using the measured base pose." },
        { on: ["robot>obs", "obs"], text: "Every action deforms the object or moves the base, so the next observation closes the loop." }
      ]
    },
    worked: {
      title: "One whole-body IK solve, by hand",
      ref: "HoMeR QP, arXiv 2506.01185", prov: "Our toy numbers: one base axis, one arm axis",
      eq: { tex: "\\min_{\\Delta b,\\,\\Delta u}\\ (\\Delta b + \\Delta u - e)^2 + w_b\\,\\Delta b^2 + w_u\\,\\Delta u^2", words: "Close the end-effector error e while paying a cost for each motion: moving the base costs w_b, moving the arm costs w_u.", key: [{ glyph: "Δb", meaning: "base motion along the line" }, { glyph: "Δu", meaning: "arm extension change" }, { glyph: "e", meaning: "end-effector error to target" }, { glyph: "w_b, w_u", meaning: "costs of base and arm motion" }] },
      figure: WE_FIG,
      steps: [
        { title: "One base, one arm", text: "Base at 0.40 m plus arm reach 0.50 m puts the end effector at 0.90 m. The target is 1.20 m, so e = 0.30." },
        { title: "Price each motion", text: "Base motion costs w_b = 1.5 (HoMeR's base damping weight), arm motion w_u = 0.5. Both move the end effector equally." },
        { title: "Solve the first step", text: "c = 1/1.5 + 1/0.5 = 2.67, so the step is 0.30 · 0.727 = 0.218 m: Δb = 0.055, Δu = 0.164." },
        { title: "Repeat the solve", text: "The error shrinks 0.300 → 0.082 → 0.022 → 0.006 m. The base always takes w_u / (w_u + w_b) = 25% of the motion." },
        { title: "Base slips 5 cm", text: "Suppose the base overshoots by 5 cm. A policy that replays arm joints cannot see this: the end effector lands 5 cm past, at 1.244 m." },
        { title: "The loop corrects it", text: "The whole-body solver re-reads the base pose, so the next error is 1.20 − 1.244 = −0.044 m and the arm pulls back." }
      ]
    },
    ruleTitle: "Key rules for shapes, whole bodies and credit",
    rules: [
      { name: "DeformerNet shape servo", ref: "arXiv 2110.04685", term: "shape-servoing",
        tex: "\\class{sym-pi}{\\pi_\\theta}(\\class{sym-pc}{P_c}, \\class{sym-pc}{P_g}) = F\\big(\\phi(\\class{sym-pc}{P_c}) - \\phi(\\class{sym-pc}{P_g})\\big) = \\Delta \\class{sym-x}{x}",
        words: "Encode the current and goal point clouds with one network, subtract the features, and regress the gripper displacement that shrinks the difference.",
        key: ["pi", "pc", { glyph: "φ", meaning: "shared PointConv shape encoder" }, { glyph: "F", meaning: "MLP deformation controller" }, "x"] },
      { name: "Chamfer distance between shapes", ref: "arXiv 2110.04685", term: "chamfer-distance",
        tex: "d_c = \\frac{1}{|\\class{sym-pc}{P_1}|} \\sum_{p \\in \\class{sym-pc}{P_1}} \\min_{p' \\in \\class{sym-pc}{P_2}} \\| p - p' \\|_2",
        words: "For every point of one shape, find the nearest point of the other and average the distances. It needs no point correspondences.",
        key: [{ glyph: "d_c", meaning: "Chamfer distance" }, "pc", { glyph: "p, p′", meaning: "points of the two clouds" }],
        fig: chamferFig(), figCap: "Illustrative points. Each gap runs from a point of P₁ to its nearest point of P₂; no point pairs are given in advance, and two P₁ points may share a nearest P₂ point." },
      { name: "HoMeR whole-body IK", ref: "arXiv 2506.01185", term: "whole-body-control",
        tex: "\\min_{\\dot{\\class{sym-qj}{q}}}\\ \\|\\class{sym-Jac}{J(q)}\\,\\dot{\\class{sym-qj}{q}} - e_{ee}\\|^2_{W_{ee}} + \\|\\class{sym-qj}{q} + \\dot{\\class{sym-qj}{q}}\\,\\Delta t - \\class{sym-qj}{q}_{\\text{rest}}\\|^2_{W_{post}} + \\|\\dot{\\class{sym-qj}{q}}_{\\text{base}}\\|^2_{W_{damp}}",
        words: "A quadratic program (QP): track the end-effector error, stay near a tucked posture, damp base motion. HoMeR weights these 1.0, 0.002 and 1.5.",
        key: ["qj", "Jac", { glyph: "e_ee", meaning: "end-effector pose error" }, { glyph: "W", meaning: "weights of the three terms" }, { glyph: "Δt", meaning: "control time step" }] },
      { name: "Advantage mixing (Deep Whole-Body Control)", ref: "arXiv 2210.10044", term: "advantage-mixing",
        before: "\\class{sym-J}{J} = \\tfrac{1}{|\\class{sym-D}{\\mathcal{D}}|}\\sum \\log \\class{sym-pi}{\\pi_\\theta}(\\class{sym-a}{a_t} \\mid \\class{sym-s}{s_t})\\, \\class{sym-adv}{\\hat{A}_t}",
        tex: "\\class{sym-J}{J} = \\tfrac{1}{|\\class{sym-D}{\\mathcal{D}}|}\\sum \\class{sb-chg}{\\log \\class{sym-pi}{\\pi_\\theta}(\\class{sym-a}{a^{arm}_t} \\mid \\class{sym-s}{s_t})\\big(\\class{sym-adv}{\\hat{A}^{manip}} + \\class{sb-new}{\\class{sym-beta}{\\beta}\\, \\class{sym-adv}{\\hat{A}^{loco}}}\\big)} + \\class{sb-new}{\\log \\class{sym-pi}{\\pi_\\theta}(\\class{sym-a}{a^{leg}_t} \\mid \\class{sym-s}{s_t})\\big(\\class{sym-beta}{\\beta}\\, \\class{sym-adv}{\\hat{A}^{manip}} + \\class{sym-adv}{\\hat{A}^{loco}}\\big)}",
        words: "Arm actions are credited mainly by the manipulation advantage, leg actions by the locomotion advantage. β grows from 0 to 1 during training.",
        key: ["J", "D", "pi", "a", "s", "adv", "beta"], diff: true, beforeLabel: "Policy gradient", afterLabel: "Advantage mixing" },
      { name: "MoManipVLA trajectory cost", ref: "arXiv 2503.13446",
        tex: "O = \\lambda_1 F_r + \\lambda_2 F_s + \\lambda_3 F_c, \\qquad (\\lambda_1, \\lambda_2, \\lambda_3) = (10, 1, 0.6)",
        words: "Score base and arm trajectories between two vision-language-action (VLA) waypoints by reachability, smoothness and collision margin. Removing reachability hurt most.",
        key: [{ glyph: "O", meaning: "total trajectory cost" }, { glyph: "F_r", meaning: "reachability (IK effort)" }, { glyph: "F_s", meaning: "smoothness of joints and base" }, { glyph: "F_c", meaning: "collision-margin violation" }, { glyph: "λ₁…λ₃", meaning: "cost weights" }] }
    ],
    algorithm: {
      title: "One HoMeR control step", ref: "arXiv 2506.01185", prov: "Paraphrased from the method card",
      lines: [
        '<span class="kw">input</span> mode m (starts as keypose), point cloud, RGB images, base + arm state <span data-sym="qj">q</span>',
        '<span class="kw">if</span> m = keypose: predict a salient point + offset → absolute end-effector pose <span data-sym="x">x</span>, gripper, next mode',
        '<span class="kw">else</span> (dense): Diffusion Policy predicts 16 relative end-effector deltas; execute 8',
        '<span class="kw">for</span> each end-effector target on the way:',
        '    solve the whole-body QP for <span data-sym="qj">q̇</span> (≤ 20 iterations) <span class="cm">// base 3 DoF + arm 7 DoF</span>',
        '    send base and arm joint commands',
        'm ← predicted next mode; <span class="kw">stop</span> when m = terminate'
      ]
    },
    playgrounds: [
      {
        id: "mobile", title: "Base + arm commands or whole-body targets", ref: "P07 §4.4.4 · HoMeR, Mobile ALOHA", prov: "Simplified: planar toy",
        try: "Start with Separate commands at 10% error: the trace turns red. Lower Steps per chunk to 45, then switch to Whole-body.",
        mount: mountMobile,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e3-mobile";
          return [
            { target: q("canvas"), title: "Open-loop base drift", text: "The base overshoots by 10%. The arm replays joint angles planned for a perfect base, so the end effector drifts off the line." },
            { target: q("#" + id + "-chunk"), title: "Re-plan every chunk", text: "Re-planning from the real state every 45 steps resets the drift. Mobile ALOHA's ACT predicts chunks of 45 actions.", do: function (a) { return a.set(q("#" + id + "-chunk"), 45); }, task: "Set Steps per chunk to 45", expect: function () { return api.state().chunk <= 50; } },
            { target: q("#" + id + "-mode"), title: "Act in end-effector space", text: "Now the policy outputs only end-effector targets. The whole-body solver re-reads the base pose every step.", do: function (a) { return a.click(q("#" + id + '-mode [value="wbc"]')); }, task: "Choose Whole-body", expect: function () { return api.state().mode === "wbc"; } },
            { target: q(".sb-readouts"), title: "Error absorbed", text: "The arm absorbs the base error, so the whole line stays within 3 cm. HoMeR reports 79% success with this design." },
            { target: q("#" + id + "-base"), title: "Your turn", text: "Switch back to Separate commands and try a Differential base. Turning errors act through the arm's lever and hurt more." }
          ];
        }
      },
      {
        id: "rope", title: "What the robot tracks decides when it stops", ref: "P01 §4.5 · DeformerNet", prov: "Simplified: 2-D rope toy",
        try: "With 3 keypoints, take four actions: the measured error reaches zero while the true error stays near 5 cm. Choose All 21 and repeat.",
        mount: mountRope,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e3-rope";
          return [
            { target: q("canvas"), title: "Two bends to make", text: "The goal has two bends. The robot sees only its tracked points and drags the one farthest from its goal." },
            { target: q("#" + id + "-act"), title: "Act on 3 keypoints", text: "Take actions until the rope stops changing. Watch the two readouts separate.", do: function (a) { return a.click(q("#" + id + "-act")).then(function () { return a.click(q("#" + id + "-act")); }).then(function () { return a.click(q("#" + id + "-act")); }); }, task: "Take three actions", expect: function () { return api.state().acts >= 3 || api.state().done; } },
            { target: q(".sb-readouts"), title: "False confidence", text: "The tracked points sit on their goals, so the measured error is near zero. The bends between them are wrong." },
            { target: q("#" + id + "-rep"), title: "Track every point", text: "With all 21 points, the rule grasps near each bend in turn: points 15 and 4 first.", do: function (a) { return a.click(q("#" + id + '-rep [value="21"]')); }, task: "Choose All 21", expect: function () { return api.state().K === 21; } },
            { target: q("#" + id + "-act"), title: "Your turn", text: "Take four actions and compare the true error with the 3-keypoint run. Then try 5 keypoints." }
          ];
        }
      },
      {
        id: "tray", title: "Two arms, one clock", ref: "P01 §2.1 · P05 §2.3.2", prov: "Illustrative: minimum-jerk lift toy",
        try: "Run 20 lifts with Two policies and a 200 ms delay spread. Then switch to Joint policy, one 14-D action for both arms.",
        mount: mountTray,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e3-tray";
          return [
            { target: q("[data-chart]"), title: "Two clocks, one tray", text: "Each arm's policy starts after its own delay. The gap between the two height curves is the tray's tilt." },
            { target: q("#" + id + "-jit"), title: "Wider delay spread", text: "Raise the spread of start delays. More lifts tilt past 11.3°, where the cup slides.", do: function (a) { return a.set(q("#" + id + "-jit"), 400); }, task: "Set the delay spread to 400 ms", expect: function () { return api.state().jit >= 300; } },
            { target: q("#" + id + "-pol"), title: "One joint policy", text: "A joint policy outputs both arms in one action, so they share one clock.", do: function (a) { return a.click(q("#" + id + '-pol [value="joint"]')); }, task: "Choose Joint policy", expect: function () { return api.state().joint; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "All lifts keep the cup. Lower the spread to 0 ms with two policies: speed differences alone still tilt the tray." }
          ];
        }
      }
    ],
    methods: ["deformernet", "dexdeform", "chi0", "deep-whole-body-control", "vbc", "homer", "momanipvla", "tidybot", "mobile-aloha", "aloha-unleashed", "robotwin-2-0", "softgym", "daxbench", "bigym"],
    methodsLede: "How the lines evolved: DeformerNet learned the features that hand-built shape servos used; Deep Whole-Body Control made RMA one-phase and added advantage mixing; VBC moved its arm to end-effector poses; HoMeR brought SPHINX's hybrid policy onto a mobile base; χ0 post-trains π0.5 for garments.",
    open: [
      { title: "Topology and delayed dynamics", text: "Deformation responds late and can change topology, as when dough splits. Latent dynamics models such as DeformNet and DoughNet are early answers.", refs: "P01 §4.5" },
      { title: "Choosing the action space", text: "Mobile manipulators use joint, task-space and factored actions, but there is no principled way to pick one for a task.", refs: "P07 §4.4.4" },
      { title: "Long horizons in large spaces", text: "Mobile tasks are long, partially observable and unsafe to explore. Most reinforcement learning (RL) work trains in simulation.", refs: "P07 §4.4.3–4.4.4" },
      { title: "Bimanual roles and hardware", text: "Two arms need synchronization, collision avoidance and role assignment, and leader–follower data depends on embodiment-specific hardware.", refs: "P01 §2.1 · P05 §2.3.2" }
    ],
    takeaways: [
      "Deformable objects have no fixed pose; methods represent them as point clouds, particles or latents and compare shapes with distances like Chamfer.",
      "What the robot tracks decides when it believes it is done; coarse keypoints can hide real shape error.",
      "Bimanual policies output both arms together, and leader–follower rigs such as ALOHA record synchronized two-arm data.",
      "End-effector actions plus a whole-body solver let the arm absorb base error; HoMeR beat its base-plus-arm variant by 29 points.",
      "Mobile RL uses tricks for credit and transfer: advantage mixing and one-phase adaptation in Deep Whole-Body Control."
    ],
    quiz: [
      { q: "Why can't a 6-DoF pose describe the state of a towel?", options: ["Towels are too light", "Its shape changes under force, with many degrees of freedom", "Cameras cannot see cloth", "Poses only work in simulation"], correct: 1, why: "Deformable objects lack a fixed pose and have high-dimensional state, so methods use point clouds, particles, meshes or latents (P01 §4.5)." },
      { q: "A mobile manipulator's base overshoots by 5 cm. Which action space corrects this within one step?", options: ["Separate base and arm joint commands, replayed", "End-effector targets through a whole-body IK solver", "A larger action chunk", "Base velocity commands only"], correct: 1, why: "The whole-body solver re-reads the base pose, so the error includes the slip and the arm compensates (HoMeR, arXiv 2506.01185)." },
      { q: "In advantage mixing, what does β control early in training?", options: ["The learning rate", "How much arm actions also get credit from locomotion reward", "The number of environments", "The chunk length"], correct: 1, why: "At β = 0 arm actions see only the manipulation advantage and legs only locomotion; β grows to 1 with a curriculum (arXiv 2210.10044)." },
      { q: "What did Mobile ALOHA's co-training with static ALOHA data do on Wipe Wine with ACT?", options: ["Nothing measurable", "Raised success from 50% to 95%", "Lowered success", "Removed the need for mobile data"], correct: 1, why: "With 50 mobile demos, co-training gave 95% versus 50% without it; the 7-task average gain was 34% (arXiv 2401.02117)." },
      { q: "Which cost term mattered most for MoManipVLA's whole-body trajectories on the open-vocabulary mobile manipulation (OVMM) benchmark?", options: ["Collision", "Smoothness", "Reachability", "None: all equal"], correct: 2, why: "Removing reachability dropped overall success from 15.8% to 13.1%, the largest drop; smoothness gave 13.8% and collision 15.3% (arXiv 2503.13446)." }
    ],
    cards: [
      { front: "What does DeformerNet regress, and from what?", back: "A 3-D end-effector displacement, from the difference of PointConv features of current and goal partial point clouds.", ref: "arXiv 2110.04685" },
      { front: "What was DeformerNet's main failure source?", back: "The heuristic manipulation-point choice, which sometimes picked a grasp that could not reach the goal shape.", ref: "arXiv 2110.04685" },
      { front: "How does ALOHA collect bimanual demonstrations?", back: "Leader–follower teleoperation: an operator moves two WidowX leader arms and two ViperX follower arms copy their joints.", ref: "P02 §VI-A" },
      { front: "What action does Mobile ALOHA predict?", back: "A 16-D action: 14 arm joints and grippers plus 2 base velocities, in chunks (45 for action chunking with transformers, ACT).", ref: "arXiv 2401.02117" },
      { front: "What did TidyBot++ find about holonomic bases?", back: "Wipe countertop succeeded 9/10 with a holonomic base versus 4/10 with differential drive, both from 50 demos.", ref: "arXiv 2412.10447" },
      { front: "What three modules does χ0 add to π0.5?", back: "Model Arithmetic (weight merging), Stage Advantage (advantage-weighted cloning) and Train-Deploy Alignment (DAgger, augmentation, chunk smoothing).", ref: "arXiv 2602.09021" },
      { front: "Name three deformable-object benchmarks and their simulators.", back: "SoftGym (NVIDIA FleX), PlasticineLab (Taichi, differentiable) and DaXBench (DaX, differentiable, JAX).", ref: "P01 Table 2" }
    ],
    terms: {
      "deformable-object-manipulation": { name: "deformable object manipulation", aliases: ["DOM", "deformable manipulation"], group: "physics", def: "Perceiving and controlling non-rigid objects, such as cloth, rope and food, whose shapes vary under applied forces.", note: "The hard part is state: a high-dimensional, partly occluded shape instead of a pose.", ref: "P01 §4.5", scene: "robot", focus: ["cloth", "gripper"], look: "the cloth changing shape", uses: [] },
      "shape-servoing": { name: "shape servoing", aliases: ["visual shape servo", "shape servo"], group: "physics", sym: "P", symTex: "P", def: "Closed-loop control that moves a gripper to shrink the difference between the current and goal shape of a deformable object.", note: "It is greedy: good for reaching a shape, weak on long-horizon plans.", ref: "arXiv 2110.04685", scene: "robot", focus: ["cloth", "end-effector"], look: "the gripper reshaping the cloth", uses: ["deformable-object-manipulation", "chamfer-distance"] },
      "manipulation-point": { name: "manipulation point", aliases: ["grasp point"], group: "physics", def: "The point where the robot grasps a deformable object; it determines which shapes are reachable.", note: "Not the same as a rigid grasp pose: the choice depends on the goal shape.", ref: "arXiv 2110.04685", scene: "robot", focus: ["cloth", "grasp-pose"], look: "the grasp on the cloth", uses: ["shape-servoing"] },
      "chamfer-distance": { name: "Chamfer distance", aliases: ["chamfer"], group: "eval", def: "The average distance from each point of one point cloud to its nearest point in another; it compares shapes without correspondences.", note: "Small Chamfer distance does not guarantee matching topology.", ref: "arXiv 2110.04685", scene: "robot", focus: ["cloth"], look: "current and goal cloth shapes", uses: [] },
      "leader-follower-teleoperation": { name: "leader–follower teleoperation", aliases: ["puppeteering", "leader-follower"], group: "data", def: "The operator moves a leader device whose joint motion a kinematically matched follower robot copies, as in ALOHA and GELLO.", note: "It keeps both arms synchronized but needs embodiment-specific hardware.", ref: "P05 §2.3.2 · P02 §VI-A", scene: "system", focus: ["human-teleop", "robot"], look: "operator driving the follower arms", uses: [] },
      "bimanual-coordination": { name: "bimanual coordination", aliases: ["dual-arm manipulation", "bimanual manipulation"], group: "actions", sym: "aₜ", symTex: "a_t", def: "Controlling two arms whose actions only work together, which adds temporal synchronization, inter-arm collision avoidance and role assignment.", note: "Two independent single-arm policies do not share a clock.", ref: "P01 §2.1", scene: "robot", focus: ["arm", "object"], look: "two arms holding one object", uses: ["leader-follower-teleoperation"] },
      "whole-body-control": { name: "whole-body control", aliases: ["WBC", "whole-body controller"], group: "contact", sym: "J(q)", symTex: "J(q)", def: "Choosing actions for all degrees of freedom of the body, such as base, legs and arms, to reach a desired configuration, often an end-effector pose.", note: "Learned (RL) or solved (IK QP); HoMeR solves it, Deep Whole-Body Control learns it.", ref: "P07 §4.4.1", scene: "robot", focus: ["base", "arm", "end-effector"], look: "base and arm moving together", uses: [] },
      "decoupled-base-arm-actions": { name: "decoupled base and arm actions", aliases: ["base + arm action space", "B+A"], group: "actions", def: "An action space where the policy outputs base velocities and arm commands separately, such as Mobile ALOHA's 16-D action.", note: "Base errors reach the end effector unless the next observation corrects them.", ref: "arXiv 2401.02117 · 2506.01185", scene: "robot", focus: ["base", "arm"], look: "base and arm commanded separately", uses: ["whole-body-control"] },
      "holonomic-base": { name: "holonomic base", aliases: ["omnidirectional base"], group: "foundations", def: "A mobile base that can move in any planar direction and turn independently, for example TidyBot++'s powered casters.", note: "A differential-drive base must turn before moving sideways.", ref: "arXiv 2412.10447", scene: "robot", focus: ["base"], look: "the wheeled base", uses: [] },
      "advantage-mixing": { name: "advantage mixing", aliases: [], group: "learning", sym: "Âₜ", symTex: "\\hat{A}_t", def: "Weighting each limb's policy gradient mainly by its own task advantage, with cross terms scaled by a curriculum weight β.", note: "Without it, Deep Whole-Body Control's policy followed end-effector commands but ignored base velocity.", ref: "arXiv 2210.10044", scene: "system", focus: ["policy-update"], look: "the policy update", uses: [] },
      "co-training": { name: "co-training", aliases: ["co-train"], group: "data", def: "Training one policy on a mixture of datasets, such as mobile demonstrations plus static bimanual episodes with zero-padded base actions.", note: "Mobile ALOHA found it beat pre-train-then-fine-tune on Wipe Wine (95% vs 40%).", ref: "arXiv 2401.02117", scene: "system", focus: ["data-robot", "policy-update"], look: "two datasets feeding one policy", uses: [] },
      "hybrid-keypose-policy": { name: "hybrid keypose and dense policy", aliases: ["hybrid imitation", "keypose mode"], group: "actions", def: "A policy that switches between predicting absolute keyposes for long reaches and dense relative actions for fine manipulation.", note: "HoMeR adds a predicted next mode to each action.", ref: "arXiv 2506.01185", scene: "system", focus: ["action-head", "controller"], look: "the head choosing a mode", uses: ["whole-body-control"] }
    },
    symbols: [
      { id: "pc", tex: "P", glyph: "P", kind: "Signals", meaning: "point cloud of an object's surface (current P_c, goal P_g)", short: "point cloud", first: "e3", read: "P (sub c or g)", papers: "DeformerNet: P_c, P_g · DexDeform: g (goal cloud)" }
    ],
    ledger: [
      { where: "Topic 17 · worked example", source: "HoMeR's QP has three weighted terms over base + arm joint velocities", page: "Reduced to one base and one arm axis with our arm weight w_u = 0.5", why: "Makes the split computable by hand.", kind: "Simplified" },
      { where: "Topic 17 · playground 1", source: "Real mobile policies are trained networks with noisy odometry", page: "Toy plans with the same IK solver; base pose is measured exactly", why: "Isolates the effect of the action space.", kind: "Simplified" },
      { where: "Topic 17 · playground 2", source: "DeformerNet picks the manipulation point from displaced keypoints and servoes with a learned network", page: "Toy drags the tracked point farthest from its goal to its goal", why: "Shows how the tracked state limits what the controller sees.", kind: "Simplified" },
      { where: "Topic 17 · playground 3", source: "No survey gives a tray-tilt model", page: "Minimum-jerk lift toy with an 11.3° slide limit (μ = 0.2)", why: "Illustrates synchronization only.", kind: "Our choice" },
      { where: "Topic 17 · DexDeform", source: "P01 §4.5 says DexDeform fine-tunes skills with limited robot data", page: "The method card reports simulation only, refined with differentiable physics", why: "The site follows the method paper.", kind: "Sources disagree" },
      { where: "Topic 17 · SoftGym", source: "P01 Table 2 lists SoftGym as CoRL 2021", page: "The method card dates it CoRL 2020 (arXiv 2011.07215)", why: "Proceedings year differs from conference year.", kind: "Sources disagree" },
      { where: "Topic 17 · rules", source: "DeformerNet writes the encoder as g and the action as A", page: "Written φ and Δx here; g is the site's grasp symbol", why: "Avoids a clash with house notation.", kind: "Our choice" }
    ]
  });
})();
