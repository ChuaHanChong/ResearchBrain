/* Topic 07 · Action representations and timing. Sources: P02 §IV-D.3, X2 §4.4, P01 §6.4.8, P05 §7.2.2, P04 §4.5, method papers (FAST, OpenVLA-OFT, RTC, UMI, SpatialVLA, UniAct, CrossFormer). */
(function () {
  "use strict";
  var RB = window.RB;
  var DT = 33; /* control period in ms at 30 fps (X2 §4.4) */
  /* StudyBench.segmented calls onChange(value, button); read the button's value directly (RB.bindSeg passes value.value). */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }

  /* ---------- playground 1: the async action queue under a threshold g (X2 §4.4, Alg. 1, Fig. 33) ---------- */
  /* Tick-based toy: one request in flight, jittered latency, stale actions dropped on arrival, the rest of the old queue replaced. */
  function simQueue(g, latMs, H, seed, T) {
    var R = RB.rng(seed), q = 0, infl = null, idle = 0, calls = 0, thrown = 0, predicted = 0, trace = [], idleT = [], arrivals = [], started = false;
    for (var t = 0; t < T; t++) {
      if (infl && t >= infl.arr) {
        var stale = t - infl.sent;
        thrown += q + Math.min(stale, H); predicted += H;
        q = Math.max(0, H - stale); infl = null; started = true; arrivals.push(t);
      }
      if (!infl && (q === 0 || q / H < g)) { infl = { sent: t, arr: t + Math.max(1, Math.round(latMs * (1 + 0.15 * R.normal()) / DT)) }; calls++; }
      trace.push(q);
      if (q > 0) { q--; idleT.push(false); } else { if (started) idle++; idleT.push(started); }
    }
    return { idle: idle / T, calls: calls / (T * DT / 1000), discarded: predicted ? thrown / predicted : 0, trace: trace, idleT: idleT, arrivals: arrivals, gmin: latMs / DT / H };
  }

  function mountQueue(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-preset", label: "Policy latency preset", value: "flow", options: [{ value: "flow", label: "Flow VLA" }, { value: "ar", label: "FAST tokens" }, { value: "custom", label: "Custom" }] }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-g", label: "Threshold g", min: 0, max: 1, step: 0.05, value: 0.5, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-lat", label: "Latency E[ℓ_S] (ms)", min: 30, max: 900, step: 10, value: 100 }) +
      RB.slider({ id: id + "-h", label: "Chunk size H", min: 10, max: 100, step: 5, value: 50 }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New latencies ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Action-queue size over ten seconds of control"></canvas><figcaption class="sb-caption">Line = actions left in the queue each 33 ms tick; top edge = a full chunk H. Dashed = g·H, where a new observation is sent. Red bands = nothing to execute.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "idle", k: "Robot idle" }, { id: "gmin", k: "Smallest g that never idles" }, { id: "calls", k: "Chunks requested per second" }, { id: "disc", k: "Predicted actions thrown away" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "queue size |A|", kind: "line" }, { c: "accent", label: "threshold g·H", kind: "dash" }, { c: "bad", label: "idle ticks", kind: "area" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), g = 0.5, lat = 100, H = 50, seed = 5, T = 300, W = 520, Hc = 300, last = null;
    var note = body.querySelector("[data-note]"), latIn = body.querySelector("#" + id + "-lat"), seg = body.querySelector("#" + id + "-preset");
    function setPreset(v) { Array.prototype.forEach.call(seg.querySelectorAll("button"), function (b) { b.setAttribute("aria-pressed", String(b.value === v)); }); }
    function setLat(v) { lat = v; latIn.value = v; var o = body.querySelector('[data-out="' + id + '-lat"]'); if (o) o.textContent = v; }
    function draw() {
      if (!last) return;
      var P = RB.pal(), c = RB.canvas(cv, W, Hc), x0 = 40, x1 = W - 12, y0 = Hc - 30, y1 = 14;
      var sx = function (t) { return x0 + t / T * (x1 - x0); }, sy = function (v) { return y0 - v / H * (y0 - y1); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, Hc);
      c.strokeStyle = P.line; c.lineWidth = 1;
      [0, 0.25, 0.5, 0.75, 1].map(function (f) { return f * H; }).forEach(function (v) { c.beginPath(); c.moveTo(x0, sy(v)); c.lineTo(x1, sy(v)); c.stroke(); });
      c.fillStyle = P["bad-soft"] || P.bad;
      last.idleT.forEach(function (b, t) { if (b) c.fillRect(sx(t), y1, Math.max(1, sx(t + 1) - sx(t)), y0 - y1); });
      c.strokeStyle = P.accent; c.setLineDash([5, 4]); c.lineWidth = 1.5; c.beginPath(); c.moveTo(x0, sy(g * H)); c.lineTo(x1, sy(g * H)); c.stroke(); c.setLineDash([]);
      c.strokeStyle = P["data-1"]; c.lineWidth = 2; c.beginPath();
      last.trace.forEach(function (v, t) { if (t) c.lineTo(sx(t), sy(v)); else c.moveTo(sx(t), sy(v)); }); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + getComputedStyle(document.body).getPropertyValue("--font-mono");
      [0, H / 2, H].forEach(function (v) { c.fillText(String(Math.round(v)), 8, sy(v) + 4); });
      [0, 100, 200, 300].forEach(function (t) { c.fillText((t * DT / 1000).toFixed(1) + " s", sx(t) - (t === 300 ? 30 : 4), Hc - 10); });
    }
    function run() {
      last = simQueue(g, lat, H, seed, T);
      RB.setRO(body, "idle", Math.round(100 * last.idle) + "%");
      RB.setRO(body, "gmin", RB.fmt(last.gmin, 2));
      RB.setRO(body, "calls", RB.fmt(last.calls, 1));
      RB.setRO(body, "disc", Math.round(100 * last.discarded) + "%");
      note.textContent = g === 0 ? "g = 0 is the sequential limit: the queue drains, then the robot waits a full inference round trip (X2 §4.4)." :
        g >= 0.95 ? "g near 1 sends an observation at almost every tick. The queue stays full, but most predicted actions are overwritten before they run." :
        g < last.gmin ? "g is below E[ℓ_S]/Δt/H, so the queue empties before the new chunk arrives and the robot pauses." :
        "g is above E[ℓ_S]/Δt/H: a new chunk arrives before the queue empties, and inference is amortized over (1 − g)·H actions.";
      draw();
    }
    bindSeg(body, id + "-preset", function (v) { if (v === "flow") setLat(100); else if (v === "ar") setLat(750); run(); });
    RB.bindSlider(body, id + "-g", function (v) { return (+v).toFixed(2); }, function (v) { g = v; run(); });
    RB.bindSlider(body, id + "-lat", null, function (v) { lat = v; setPreset("custom"); run(); });
    RB.bindSlider(body, id + "-h", null, function (v) { H = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { g: g, lat: lat, H: H, idle: last ? last.idle : 0 }; } };
  }

  /* ---------- playground 2: what happens at a chunk boundary (RTC, arXiv 2506.07339) ---------- */
  /* 1-D toy: the gripper moves right one unit per tick; the action is its sideways offset y.
     Demonstrations pass a block above or below. Chunks of H = 16, a new one every s = 8 ticks, inference delay d ticks. */
  var CH = 16, CS = 8, AMP = 0.75, OX = 34, OW = 9, LEN = 68;
  function bump(x) { var u = (x - OX) / 16; return Math.abs(u) < 1 ? 0.5 * (1 + Math.cos(Math.PI * u)) : 0; }
  function hitBlock(x, y) { return Math.abs(x - OX) < OW / 2 && Math.abs(y) < 0.4; }
  function planChunk(R, x0, y0, v0, m) {
    if (m == null) { var b = Math.max(bump(x0 + 6), 0.05), p = 1 / (1 + Math.exp(-12 * y0 / (AMP * b))); m = R() < p ? 1 : -1; }
    var off = 0.05 * R.normal(), e0 = y0 - m * AMP * bump(x0), e1 = v0 - m * AMP * (bump(x0) - bump(x0 - 1)) + e0 / 4, a = [];
    for (var i = 0; i < CH; i++) a.push(m * AMP * bump(x0 + i) + (e0 + e1 * i) * Math.exp(-i / 4) + off * (1 - Math.exp(-i / 4)));
    return { m: m, a: a };
  }
  function softW(i, d) { if (i < d) return 1; if (i >= CH - CS) return 0; var c = (CH - CS - i) / (CH - CS - d + 1); return c * (Math.exp(c) - 1) / (Math.E - 1); }
  function rollChunks(method, d, seed) {
    var R = RB.rng(seed), x = 0, y = 0, path = [[0, 0]], pause = 0, jerk = 0, hit = false, switches = [];
    var vel = function () { return path.length > 1 ? y - path[path.length - 2][1] : 0; };
    var cur = planChunk(R, 0, 0, 0, null), ci = 0;
    while (x < LEN) {
      var obs = null;
      for (var k = 0; k < CS && x < LEN; k++) {
        if (method !== "sync" && k === CS - d) obs = [x, y, vel()];
        var ny = cur.a[ci + k], pv = path.length > 1 ? path[path.length - 2][1] : y, j = Math.abs(ny - 2 * y + pv);
        if (j > jerk) jerk = j;
        y = ny; x += 1; path.push([x, y]); if (hitBlock(x, y)) hit = true;
      }
      if (x >= LEN) break;
      switches.push(path.length - 1);
      if (method === "sync") { var o = [x, y, vel()]; for (var p = 0; p < d; p++) { pause++; path.push([x, y]); } cur = planChunk(R, o[0], o[1], o[2], null); ci = 0; continue; }
      if (!obs) obs = [x, y, vel()];
      var fresh = planChunk(R, obs[0], obs[1], obs[2], method === "rtc" ? cur.m : null);
      var old = cur.a.slice(ci + CS - d), na = [];
      for (var i = 0; i < CH; i++) {
        var ov = i < old.length ? old[i] : null;
        if (method === "rtc" && ov != null) { var w = softW(i, d); na.push(w * ov + (1 - w) * fresh.a[i]); }
        else if (method === "te" && ov != null && i >= d) na.push(0.5 * ov + 0.5 * fresh.a[i]);
        else na.push(fresh.a[i]);
      }
      cur = { m: fresh.m, a: na }; ci = d;
    }
    return { path: path, pause: pause, jerk: jerk, hit: hit, switches: switches };
  }

  function mountBoundary(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-m", label: "Execution method", value: "sync", options: [{ value: "sync", label: "Synchronous" }, { value: "naive", label: "Naive async" }, { value: "te", label: "Temporal ensembling" }, { value: "rtc", label: "RTC" }] }) +
      RB.slider({ id: id + "-d", label: "Inference delay d (ticks)", min: 0, max: 6, step: 1, value: 4 }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Run 12 rollouts ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Twelve gripper paths passing a block, with chunk switches marked"></canvas><figcaption class="sb-caption">Gray block = obstacle; dashed = the two demonstrated ways around it. Each line is one rollout; ticks on the bold line mark where a new chunk takes over.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "hit", k: "Rollouts that hit the block" }, { id: "jerk", k: "Worst jerk at a switch", u: "×100" }, { id: "pause", k: "Ticks spent paused per rollout" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "passes the block", kind: "line" }, { c: "bad", label: "hits the block", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), method = "sync", d = 4, seed = 11, runs = [], W = 520, Hc = 300;
    var note = body.querySelector("[data-note]");
    var NOTES = {
      sync: "Synchronous: the robot stops for d ticks at every switch while the next chunk is computed. Smooth, but slower (RTC, arXiv 2506.07339).",
      naive: "Naive async: the new chunk was planned from an observation d ticks old, so it starts where the robot used to be. The switch jerks.",
      te: "Temporal ensembling averages the old and new chunks. When they chose different sides of the block, the average drives into it.",
      rtc: "RTC freezes the first d actions to the old chunk and blends the rest with a decaying mask, so the new chunk continues the same mode."
    };
    var sx = function (x) { return 24 + x / LEN * (W - 48); }, sy = function (v) { return Hc / 2 - v / 0.9 * (Hc / 2 - 16); };
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, Hc);
      c.fillStyle = P.surface; c.fillRect(0, 0, W, Hc);
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"];
      c.fillRect(sx(OX - OW / 2), sy(0.4), sx(OX + OW / 2) - sx(OX - OW / 2), sy(-0.4) - sy(0.4)); c.strokeRect(sx(OX - OW / 2), sy(0.4), sx(OX + OW / 2) - sx(OX - OW / 2), sy(-0.4) - sy(0.4));
      c.strokeStyle = P["ink-3"]; c.setLineDash([4, 4]); c.lineWidth = 1;
      [1, -1].forEach(function (m) { c.beginPath(); for (var x = 0; x <= LEN; x++) { var yy = m * AMP * bump(x); if (x) c.lineTo(sx(x), sy(yy)); else c.moveTo(sx(x), sy(yy)); } c.stroke(); });
      c.setLineDash([]);
      runs.forEach(function (r, k) {
        c.strokeStyle = r.hit ? P.bad : P["data-1"]; c.globalAlpha = k === 0 ? 1 : 0.35; c.lineWidth = k === 0 ? 2.5 : 1.5; c.beginPath();
        var xs = 0; r.path.forEach(function (p, i) { if (i) c.lineTo(sx(p[0]), sy(p[1])); else c.moveTo(sx(p[0]), sy(p[1])); }); c.stroke();
      });
      c.globalAlpha = 1;
      if (runs[0]) { c.strokeStyle = P.ink; c.lineWidth = 1.5; runs[0].switches.forEach(function (i) { var p = runs[0].path[i]; c.beginPath(); c.moveTo(sx(p[0]), sy(p[1]) - 7); c.lineTo(sx(p[0]), sy(p[1]) + 7); c.stroke(); }); }
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + getComputedStyle(document.body).getPropertyValue("--font-mono");
      c.fillText("block", sx(OX) - 16, sy(0) + 4); c.fillText("start", sx(0), sy(0) - 10);
    }
    function run() {
      runs = []; for (var s = 0; s < 12; s++) runs.push(rollChunks(method, d, seed * 31 + s));
      RB.setRO(body, "hit", runs.filter(function (r) { return r.hit; }).length + " of 12");
      RB.setRO(body, "jerk", RB.fmt(100 * Math.max.apply(null, runs.map(function (r) { return r.jerk; })), 1));
      RB.setRO(body, "pause", String(Math.round(runs.reduce(function (a, r) { return a + r.pause; }, 0) / runs.length)));
      note.textContent = NOTES[method];
      draw();
    }
    bindSeg(body, id + "-m", function (v) { method = v; run(); });
    RB.bindSlider(body, id + "-d", null, function (v) { d = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { method: method, d: d }; } };
  }

  /* ---------- concept-card drawings (200×56, token colors only) ---------- */
  var ART = {
    bins: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 38 C50 36 70 6 110 8 S170 32 190 24" class="rb-s-line" stroke-dasharray="3 3"/><path d="M10 38 H30 V35 H50 V26 H70 V16 H90 V10 H110 V8 H130 V13 H150 V20 H170 V24 H190" class="rb-s-acc"/><text x="100" y="53" text-anchor="middle" class="rb-t-mono">one token per step and dim</text></svg>',
    fast: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [30, 22, 12, 6, 3, 2, 1, 1, 0, 0, 0, 0].map(function (h, i) { return '<rect x="' + (12 + i * 14) + '" y="' + (40 - h) + '" width="10" height="' + Math.max(1, h) + '" class="' + (h > 4 ? "rb-f-acc" : "rb-f-sunk") + '"/>'; }).join("") + '<line x1="8" y1="40" x2="180" y2="40" class="rb-s-line"/><text x="12" y="52" class="rb-t-mono">low freq.</text><text x="118" y="52" class="rb-t-mono">high → 0</text></svg>',
    parallel: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="14" width="60" height="28" rx="4" class="rb-f-soft"/><text x="40" y="32" text-anchor="middle" class="rb-t-acc">1 pass</text>' + [0, 1, 2, 3, 4, 5].map(function (i) { return '<path d="M72 28 L' + (100 + i * 15) + ' ' + (10 + i * 7) + '" class="rb-s-line"/><rect x="' + (100 + i * 15) + '" y="' + (5 + i * 7) + '" width="12" height="10" rx="2" class="rb-f-surface"/>'; }).join("") + '<text x="40" y="54" text-anchor="middle" class="rb-t-mono">L1 loss</text></svg>',
    codebook: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (r) { return [0, 1, 2, 3].map(function (k) { return '<rect x="' + (14 + k * 14) + '" y="' + (4 + r * 12) + '" width="11" height="10" class="' + (r === 1 && k === 2 ? "rb-f-acc" : "rb-f-sunk") + '"/>'; }).join(""); }).join("") + '<path d="M72 20 L120 12 M72 20 L120 40" class="rb-s-ink"/><rect x="122" y="4" width="72" height="16" rx="3" class="rb-f-surface"/><rect x="122" y="32" width="72" height="16" rx="3" class="rb-f-surface"/><text x="158" y="16" text-anchor="middle" class="rb-t-mono">arm</text><text x="158" y="44" text-anchor="middle" class="rb-t-mono">bimanual</text></svg>',
    relative: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M30 40 H62 M30 40 V10" class="rb-s-acc"/><circle cx="30" cy="40" r="4" class="rb-f-acc"/><text x="36" y="53" class="rb-t-mono">pose at t₀</text><path d="M30 40 Q90 6 170 20" class="rb-s-ink" stroke-dasharray="4 3"/>' + [70, 110, 150].map(function (x, i) { return '<circle cx="' + x + '" cy="' + [22, 14, 18][i] + '" r="4" class="rb-f-surface"/>'; }).join("") + '<text x="110" y="44" class="rb-t-mono">targets</text></svg>',
    slots: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [["joints", 7, "rb-f-soft", 42], ["EEF", 9, "rb-f-soft", 53], ["grip", 1, "rb-f-soft", 42], ["hand", 12, "rb-f-sunk", 53], ["reserved", 11, "rb-f-sunk", 42]].reduce(function (acc, b) { var w = b[1] * 4.3; acc.s += '<rect x="' + acc.x.toFixed(1) + '" y="8" width="' + (w - 2).toFixed(1) + '" height="20" class="' + b[2] + '"/><text x="' + (acc.x + w / 2).toFixed(1) + '" y="' + b[3] + '" text-anchor="middle" class="rb-t-mono">' + b[0] + "</text>"; acc.x += w; return acc; }, { x: 6, s: "" }).s + '</svg>',
    queue: '<svg viewBox="0 0 200 56" aria-hidden="true">' + Array.apply(null, Array(16)).map(function (_, i) { return '<rect x="' + (12 + i * 11) + '" y="16" width="9" height="16" class="' + (i < 6 ? "rb-f-soft" : "rb-f-surface") + '"/>'; }).join("") + '<line x1="111" y1="8" x2="111" y2="40" class="rb-s-acc"/><text x="111" y="52" text-anchor="middle" class="rb-t-acc">g·H</text><text x="12" y="52" class="rb-t-mono">left</text></svg>',
    rtc: '<svg viewBox="0 0 200 56" aria-hidden="true">' + Array.apply(null, Array(12)).map(function (_, i) { var w = i < 3 ? 1 : i < 8 ? (8 - i) / 6 : 0; return '<rect x="' + (14 + i * 14) + '" y="10" width="12" height="12" class="rb-f-surface"/><rect x="' + (14 + i * 14) + '" y="30" width="12" height="12" class="rb-f-acc" opacity="' + (0.15 + 0.85 * w).toFixed(2) + '"/>'; }).join("") + '<text x="20" y="54" class="rb-t-mono">frozen d</text><text x="84" y="54" class="rb-t-mono">soft</text><text x="140" y="54" class="rb-t-mono">fresh</text></svg>'
  };

  /* ---------- worked example figure: the action queue in numbers ---------- */
  var QX = function (k) { return (40 + k * 9.6).toFixed(1); };
  var WE_FIG = '<svg viewBox="0 0 560 190" role="img" aria-label="A queue of 50 actions; markers show the latency of 3 actions for a flow VLA and 23 actions for autoregressive FAST decoding, against thresholds g">' +
    '<g data-on="1+">' + Array.apply(null, Array(50)).map(function (_, i) { return '<rect x="' + QX(i) + '" y="54" width="8.2" height="22" class="rb-f-surface"/>'; }).join("") +
    '<text x="40" y="22" class="rb-t-ink">Queue of H = 50 actions, one every Δt = 33 ms: 1.65 s of motion</text><text x="40" y="94" class="rb-t-mono">0 left</text><text x="' + QX(49) + '" y="94" class="rb-t-mono">50</text></g>' +
    '<g data-on="2+"><rect x="40" y="54" width="' + (3.03 * 9.6).toFixed(1) + '" height="22" class="rb-f-soft"/><text x="40" y="116" class="rb-t-acc">Flow VLA: 100 ms ≈ 3.03 actions run while waiting</text></g>' +
    '<g data-on="3+"><line x1="' + QX(3.03) + '" y1="44" x2="' + QX(3.03) + '" y2="80" class="rb-s-acc"/><text x="' + QX(3.03) + '" y="40" class="rb-t-acc">g_min = 0.06</text></g>' +
    '<g data-on="4+"><text x="40" y="136" class="rb-t-ink">g = 0: 100 ms idle per 1750 ms cycle = 5.7%</text></g>' +
    '<g data-on="5+"><line x1="' + QX(25) + '" y1="44" x2="' + QX(25) + '" y2="80" class="rb-s-acc"/><text x="' + QX(25) + '" y="40" class="rb-t-acc">g·H = 25</text><text x="40" y="156" class="rb-t-ink">g = 0.5: send at 25 left, about 22 left on arrival</text></g>' +
    '<g data-on="6"><rect x="40" y="54" width="' + (22.7 * 9.6).toFixed(1) + '" height="22" class="rb-f-acc" opacity="0.35"/><text x="40" y="176" class="rb-t-ink">FAST, 750 ms ≈ 22.7 actions: g_min = 0.45, about 2 left at g = 0.5</text></g></svg>';

  RB.topic({
    id: "b3",
    title: "Action representations and timing",
    eyebrow: "Part B · Actions and timing",
    lede: "How a policy writes down its actions sets how long it takes to produce them. Timing then decides whether the robot ever waits.",
    refs: ["P02 §IV-D.3", "X2 §4.4", "P01 §6.4.8", "P05 §7.2.2"],
    why: "Early VLAs wrote each action dimension as one of 256 bins. FAST compressed chunks into fewer tokens; OpenVLA-OFT dropped tokens for continuous chunks decoded in one pass. Each change cut latency. Asynchronous execution and Real-Time Chunking (RTC) then hide the latency that remains, so a slow model can still drive a 50 Hz robot.",
    outcomes: [
      "Compare binned, FAST, continuous and latent action representations.",
      "Compute the smallest queue threshold g that keeps a robot busy.",
      "Explain why naive switching between chunks causes jerks or collisions.",
      "Describe how RTC freezes and blends the overlap between chunks.",
      "Choose an action frame for cross-embodiment data: relative, camera or slotted."
    ],
    concepts: [
      { name: "256-bin tokens", def: "RT-2 and OpenVLA map each action dimension to one of 256 bins, one token per dimension per step.", ref: "P02 §IV-D.3", art: ART.bins, term: "action-tokenization" },
      { name: "FAST compression", def: "FAST applies a DCT per dimension, rounds the coefficients and merges them with BPE: 53 tokens instead of 700.", ref: "P01 §6.4.8", art: ART.fast, term: "fast-tokenization", sym: "dctC", href: "#lab/tokens" },
      { name: "Continuous chunks", def: "OpenVLA-OFT drops tokens: one bidirectional pass, an MLP head and an L1 loss give the whole chunk.", ref: "arXiv 2502.19645", art: ART.parallel, term: "parallel-decoding", sym: "achunk" },
      { name: "Universal action codes", def: "UniAct picks one of 256 shared codes; a small head per robot decodes it into native commands.", ref: "P02 §IV-D.3", art: ART.codebook, term: "universal-action-space" },
      { name: "Relative trajectories", def: "UMI writes future gripper poses in the frame of the pose at inference start, so hand-held demos transfer.", ref: "P05 §3.2.2", art: ART.relative, term: "relative-trajectory-action" },
      { name: "Semantic action slots", def: "Qwen-RobotManip gives each entry of an 80-D action vector a fixed meaning; unused slots are masked.", ref: "P05 §7.2.2", art: ART.slots, term: "semantic-action-slots" },
      { name: "Queue threshold g", def: "Asynchronous inference requests a new chunk when fewer than g·H actions are left in the queue.", ref: "X2 §4.4, Alg. 1", art: ART.queue, term: "action-queue-threshold", sym: "gq", href: "#lab/timing" },
      { name: "Real-Time Chunking", def: "RTC inpaints the next chunk: actions executed during the delay are frozen, the overlap softly guided.", ref: "arXiv 2506.07339", art: ART.rtc, term: "real-time-chunking", sym: "Wmask" }
    ],
    flow: {
      title: "Where timing acts: the asynchronous inference loop", ref: "X2 Fig. 32, Alg. 1", w: 820, h: 270,
      caption: "The robot consumes the queue at a fixed rate. The server refills it after a latency that depends on the action representation. The threshold g decides when to ask.",
      nodes: [
        { id: "queue", x: 20, y: 110, w: 150, h: 56, label: "Action queue A", sub: "H actions", kind: "store" },
        { id: "robot", x: 230, y: 110, w: 150, h: 56, label: "Robot client", sub: "one action per Δt", kind: "env" },
        { id: "check", x: 440, y: 20, w: 150, h: 56, label: "Below g?", sub: "|A| / H < g", kind: "decision" },
        { id: "server", x: 670, y: 20, w: 140, h: 56, label: "Policy server", sub: "VLA, latency ℓ_S", kind: "agent" },
        { id: "merge", x: 670, y: 190, w: 140, h: 56, label: "Aggregate", sub: "merge the overlap", kind: "agent" }
      ],
      edges: [
        { from: "queue", to: "robot", label: "aₜ" },
        { from: "robot", to: "check", label: "queue size", sides: ["t", "l"], via: [[305, 48]] },
        { from: "check", to: "server", label: "new oₜ" },
        { from: "server", to: "merge", label: "chunk" },
        { from: "merge", to: "queue", label: "updated queue", sides: ["l", "b"], via: [[95, 218]] }
      ],
      steps: [
        { on: ["queue", "queue>robot", "robot"], text: "The controller pops one action from the queue every Δt: 33 ms at 30 frames per second in the LeRobot setup." },
        { on: ["robot>check", "check"], text: "After each tick the client compares the fraction of actions left with g. Near-duplicate observations in joint space are skipped." },
        { on: ["check>server", "server"], text: "Below the threshold, the client sends the newest observation. The server needs E[ℓ_S]: about 100 ms for flow π0, 750 ms for autoregressive FAST (arXiv 2501.09747)." },
        { on: ["server>merge", "merge", "merge>queue"], text: "The new chunk arrives and is merged with the actions still queued. UMI drops actions whose time has passed; RTC inpaints them instead." },
        { on: ["queue"], text: "If the queue emptied before the chunk arrived, the robot stood still. That wait is what g, and faster representations, remove." }
      ]
    },
    worked: {
      title: "How small can g be?",
      ref: "X2 §4.4 · arXiv 2501.09747", prov: "Our numbers from cited latencies",
      eq: { tex: "\\class{sym-gq}{g}\\,\\class{sym-H}{H} - \\frac{\\class{sym-E}{\\mathbb{E}}[\\class{sym-lat}{\\ell_S}]}{\\class{sym-dt}{\\Delta t}} \\;\\ge\\; 0", words: "Actions still queued when the new chunk arrives: what was left at the request, minus what ran during inference. Negative means the robot waits.", key: ["gq", "H", "E", "lat", "dt"] },
      figure: WE_FIG,
      steps: [
        { title: "Set up the loop", text: "SmolVLA-style async inference: chunks of H = 50 actions, Δt = 33 ms. One chunk covers 50 × 33 = 1650 ms of motion." },
        { title: "Latency in actions", text: "A flow VLA takes about 100 ms per chunk. That is 100 / 33 = 3.03 actions consumed while waiting." },
        { title: "Smallest safe threshold", text: "The queue never empties if g·50 ≥ 3.03, so g ≥ 0.06. Any g above that hides the latency." },
        { title: "The sequential limit", text: "With g = 0 the client waits for an empty queue: 100 ms idle per 1750 ms cycle, 5.7% of the time." },
        { title: "The default g = 0.5", text: "A request goes out at 25 actions left, every 825 ms. About 22 remain on arrival, so the robot never stops." },
        { title: "Swap the representation", text: "Autoregressive FAST decoding takes about 750 ms: 22.7 actions. Now g must be at least 0.45, and 0.5 leaves two." }
      ]
    },
    ruleTitle: "Five rules for representing and timing actions",
    rules: [
      { name: "Asynchronous inference never idles when", ref: "X2 §4.4", term: "action-queue-threshold",
        tex: "\\class{sym-gq}{g} \\;\\ge\\; \\frac{\\class{sym-E}{\\mathbb{E}}[\\class{sym-lat}{\\ell_S}] \\,/\\, \\class{sym-dt}{\\Delta t}}{\\class{sym-H}{H}}",
        words: "Ask for the next chunk while enough actions remain to cover the expected server latency, measured in control ticks.",
        key: ["gq", "E", "lat", "dt", "H"] },
      { name: "Chunked control is feasible when", ref: "P04 §4.5.2, eq. 34",
        tex: "\\frac{\\class{sym-Nfwd}{N_{\\mathrm{fwd}}}(\\class{sym-H}{H})}{\\class{sym-H}{H}} \\;<\\; \\frac{1}{\\class{sym-fctrl}{f_{\\mathrm{ctrl}}}}",
        words: "The time for one forward pass, spread over the chunk it produces, must be shorter than one control period.",
        key: ["Nfwd", "H", "fctrl"] },
      { name: "FAST: compress before tokenizing", ref: "arXiv 2501.09747 · P02 §IV-D.3", term: "fast-tokenization",
        before: "\\text{tokens} = \\big[\\,\\mathrm{bin}_{256}(\\class{sym-a}{a}^{i}_{t})\\,\\big]_{i = 1..n,\\ t = 1..\\class{sym-H}{H}}",
        tex: "\\begin{aligned} \\class{sb-new}{\\class{sym-dctC}{C^{i}}} &\\class{sb-new}{= \\mathrm{DCT}\\big(\\class{sym-a}{a}^{i}_{1:\\class{sym-H}{H}}\\big)} \\\\ \\text{tokens} &= \\class{sb-new}{\\mathrm{BPE}}\\Big(\\class{sb-chg}{\\mathrm{round}\\big(\\class{sym-qscale}{\\gamma}\\cdot \\class{sym-dctC}{C^{i}}\\big)}\\Big) \\end{aligned}",
        words: "Transform each dimension's trajectory into frequencies, round them (most high frequencies become 0), and merge frequent patterns with BPE.",
        key: ["dctC", "a", "H", "qscale", { glyph: "BPE", meaning: "byte-pair encoding" }, { glyph: "n", meaning: "number of action dimensions" }], diff: true, beforeLabel: "Binning", afterLabel: "FAST" },
      { name: "OpenVLA-OFT: from token classes to an L1 chunk", ref: "arXiv 2502.19645 · P02 §IV-D.3", term: "parallel-decoding",
        before: "\\class{sym-L}{\\mathcal{L}} = -\\sum_{i=1}^{7} \\log \\class{sym-pi}{\\pi_\\theta}\\big(\\mathrm{bin}(\\class{sym-a}{a}^{i}_{t}) \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}, \\text{earlier tokens}\\big)",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sb-chg}{\\frac{1}{\\class{sym-H}{H}}\\sum_{k=0}^{\\class{sym-H}{H}-1} \\big\\| \\hat{a}_{t+k}(\\class{sym-o}{o_t}, \\class{sym-l}{\\ell}) - \\class{sym-a}{a}_{t+k} \\big\\|_1}",
        words: "Predict all H continuous actions at once from empty action slots, and penalize their absolute error instead of a token cross-entropy.",
        key: ["L", "pi", "a", "o", "l", "H", { glyph: "â", meaning: "MLP-head prediction" }], diff: true, beforeLabel: "OpenVLA", afterLabel: "OFT" },
      { name: "RTC soft mask over the previous chunk", ref: "arXiv 2506.07339, eq. 5", term: "real-time-chunking",
        tex: "\\begin{gathered} \\class{sym-Wmask}{W_i} = \\begin{cases} 1 & i < \\class{sym-ddelay}{d} \\\\ c_i\\,\\dfrac{e^{c_i} - 1}{e - 1} & \\class{sym-ddelay}{d} \\le i < \\class{sym-H}{H} - \\class{sym-sexec}{s_{\\mathrm{ex}}} \\\\ 0 & i \\ge \\class{sym-H}{H} - \\class{sym-sexec}{s_{\\mathrm{ex}}} \\end{cases} \\\\ c_i = \\frac{\\class{sym-H}{H} - \\class{sym-sexec}{s_{\\mathrm{ex}}} - i}{\\class{sym-H}{H} - \\class{sym-sexec}{s_{\\mathrm{ex}}} - \\class{sym-ddelay}{d} + 1} \\end{gathered}",
        words: "Actions that run during the delay are fixed; the overlap is guided toward the old chunk with decaying weight; the tail is free.",
        key: ["Wmask", "ddelay", "H", "sexec", { glyph: "cᵢ", meaning: "position within the overlap" }] }
    ],
    algorithm: {
      title: "Asynchronous inference control loop", ref: "X2 Alg. 1", prov: "Our notation: H for Hₐ",
      lines: [
        '<span class="kw">input</span> chunk size <span data-sym="H">H</span>, threshold <span data-sym="gq">g</span> ∈ [0, 1]',
        'send <span data-sym="o">o₀</span> to the policy server; receive the queue A ← <span data-sym="pi">π</span>(<span data-sym="o">o₀</span>)',
        '<span class="kw">every</span> <span data-sym="dt">Δt</span>:',
        '    <span data-sym="a">aₜ</span> ← PopFront(A); execute <span data-sym="a">aₜ</span>',
        '    <span class="kw">if</span> |A| / <span data-sym="H">H</span> &lt; <span data-sym="gq">g</span> <span class="kw">and</span> no request is running:',
        '        capture <span data-sym="o">oₜ₊₁</span>; <span class="kw">if</span> it differs from the last one sent: start AsyncInfer(<span data-sym="o">oₜ₊₁</span>) <span class="cm">// non-blocking</span>',
        '    <span class="kw">if</span> a new chunk Ã has arrived: A ← f(A, Ã) <span class="cm">// merge the overlap</span>',
        '    <span class="cm">// if A is empty, the newest observation is sent regardless of similarity</span>'
      ]
    },
    playgrounds: [
      {
        id: "queue", title: "The action queue under a threshold g", ref: "X2 §4.4, Fig. 33", prov: "Simplified: tick-based toy",
        try: "Set g to 0 and watch the red idle bands. Raise g until they vanish. Then choose FAST tokens: the same g is no longer enough.",
        mount: mountQueue,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b3-queue";
          return [
            { target: q("canvas"), title: "A queue that never empties", text: "At g = 0.5 the client asks for a new chunk at 25 actions left. The 100 ms reply arrives long before the queue runs out." },
            { target: q("#" + id + "-g"), title: "The sequential limit", text: "With g = 0 the client waits until the queue is empty. Red bands appear: the robot stands still for every round trip.", do: function (a) { return a.set(q("#" + id + "-g"), 0); }, task: "Set g to 0", expect: function () { return api.state().g === 0; } },
            { target: q("#" + id + "-g"), title: "Just above the minimum", text: "The minimum is 100 / 33 / 50 ≈ 0.06. At g = 0.1 the red bands are gone, apart from jittered slow replies.", do: function (a) { return a.set(q("#" + id + "-g"), 0.1); }, task: "Set g to 0.1", expect: function () { return Math.abs(api.state().g - 0.1) < 0.01; } },
            { target: q("#" + id + "-preset"), title: "A slower representation", text: "Autoregressive FAST decoding takes about 750 ms per chunk. At g = 0.1 the robot now idles often.", do: function (a) { return a.click(q("#" + id + '-preset [value="ar"]')); }, task: "Choose the FAST tokens preset", expect: function () { return api.state().lat >= 700; } },
            { target: q("#" + id + "-g"), title: "Raise g to compensate", text: "At g = 0.6 the request leaves early enough to cover 750 ms. The price is more requests per second.", do: function (a) { return a.set(q("#" + id + "-g"), 0.6); }, task: "Set g to 0.6", expect: function () { return api.state().g >= 0.55; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Push g to 1 and read the last readout: almost every predicted action is overwritten before it runs. That is compute spent on reactivity." }
          ];
        }
      },
      {
        id: "boundary", title: "What happens when a new chunk takes over", ref: "RTC, arXiv 2506.07339", prov: "Simplified: 1-D toy",
        try: "Start on Synchronous and read the pauses. Switch to Naive async, then Temporal ensembling, then RTC. Move the delay d from 0 to 6.",
        mount: mountBoundary,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b3-boundary";
          return [
            { target: q("canvas"), title: "Synchronous pauses", text: "The robot stops d ticks at each switch while the next chunk is computed. The paths are smooth, but every rollout takes longer." },
            { target: q("#" + id + "-m"), title: "Do not wait", text: "Naive async keeps moving and swaps in the new chunk when it arrives. It was planned from an old observation.", do: function (a) { return a.click(q("#" + id + '-m [value="naive"]')); }, task: "Choose Naive async", expect: function () { return api.state().method === "naive"; } },
            { target: q("#" + id + "-m"), title: "Average the overlap", text: "Temporal ensembling blends the old and new chunks. If they chose different sides of the block, the blend goes through it.", do: function (a) { return a.click(q("#" + id + '-m [value="te"]')); }, task: "Choose Temporal ensembling", expect: function () { return api.state().method === "te"; } },
            { target: q("#" + id + "-m"), title: "Inpaint instead", text: "RTC keeps the first d actions of the old chunk and guides the overlap toward it. No pauses, no hits.", do: function (a) { return a.click(q("#" + id + '-m [value="rtc"]')); }, task: "Choose RTC", expect: function () { return api.state().method === "rtc"; } },
            { target: q("#" + id + "-d"), title: "Longer delays", text: "At d = 6 the frozen prefix is most of the overlap. RTC reported success with delays above 300 ms.", do: function (a) { return a.set(q("#" + id + "-d"), 6); }, task: "Set the delay d to 6", expect: function () { return api.state().d === 6; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Compare Naive async at d = 0 and d = 6. The jerk grows with the delay, because the observation behind the chunk grows older." }
          ];
        }
      }
    ],
    methods: ["real-time-chunking", "fast", "openvla-oft", "umi", "spatialvla", "uniact", "crossformer", "beast", "abpolicy", "qwen-robotmanip", "q-chunking"],
    open: [
      { title: "Tokens or continuous actions", text: "Compressed tokens train fast but decode slowly; continuous heads decode fast. Structured coordinates such as B-splines are a third option, still little compared.", refs: "P01 §6.4.8 · P02 §IV-D.3" },
      { title: "Which coordinate frame", text: "Robot, camera and wrist frames give the same motion different numbers. Controlled ablations across frames are limited, and no convention is known to transfer best.", refs: "P05 §7.2.2, §8.4" },
      { title: "Stale chunks", text: "Long chunks amortize large backbones but go stale when the world changes mid-chunk. Adaptive horizons and early replanning are recent answers.", refs: "P04 §4.5.2 · P01 §6.2.2" },
      { title: "Very different bodies", text: "Shared formats struggle when robots differ as much as arms, mobile bases and legged robots; per-embodiment heads and slots are partial fixes.", refs: "P02 §IV-D.3 · P05 §8.4" }
    ],
    takeaways: [
      "Per-dimension 256-bin tokens make long, redundant sequences; FAST cut a 50 Hz chunk from 700 to 53 tokens.",
      "Autoregressive decoding stays slow (about 750 ms per chunk); continuous chunks in one pass run far faster.",
      "Asynchronous inference never idles if g ≥ E[ℓ_S]/Δt/H; larger g buys reactivity with more compute.",
      "Naive chunk switching jerks and ensembling can average modes; RTC freezes the delay and blends the overlap.",
      "Cross-embodiment data needs a shared action meaning: relative poses, universal codes or semantic slots."
    ],
    quiz: [
      { q: "Chunks of H = 50, Δt = 33 ms, latency 100 ms. What is the smallest g that avoids idling?", options: ["0.01", "About 0.06", "0.5", "1.0"], correct: 1, why: "The latency covers 100 / 33 = 3.03 actions, so g·50 must be at least 3.03: g ≥ 0.06 (X2 §4.4)." },
      { q: "Why did naive binning fail on 50 Hz T-shirt folding in the FAST paper?", options: ["The bins were too coarse", "Consecutive tokens were nearly identical, so training stalled", "BPE removed the gripper", "The robot moved too slowly"], correct: 1, why: "At high rates, per-step tokens are strongly correlated and carry little new information, so next-token training stalls (arXiv 2501.09747)." },
      { q: "What did OpenVLA-OFT change about OpenVLA's action output?", options: ["More bins per dimension", "Parallel decoding of a continuous chunk with an L1 loss", "A diffusion head with 100 steps", "Language-only outputs"], correct: 1, why: "OFT replaced autoregressive 256-bin tokens with a chunk decoded in one bidirectional pass and an L1 loss: 26× throughput on LIBERO (arXiv 2502.19645)." },
      { q: "In RTC, which actions of the previous chunk are fully frozen?", options: ["None", "Those executed during the inference delay d", "The last s_ex actions", "All of them"], correct: 1, why: "The mask weight is 1 for i < d: those actions run before the new chunk is ready, so the new chunk must agree with them (arXiv 2506.07339)." },
      { q: "In UMI's cup arrangement ablation, which action representation succeeded 20 of 20 times?", options: ["Absolute poses", "Delta actions", "Relative trajectories", "Joint angles"], correct: 2, why: "Relative trajectory 20/20, delta 16/20, absolute 5/20 (arXiv 2402.10329)." }
    ],
    cards: [
      { front: "How many tokens for a 1 s, 14-D chunk at 50 Hz: binning versus FAST?", back: "Naive binning: 700 tokens. FAST: 53, a 13.2× compression.", ref: "arXiv 2501.09747" },
      { front: "What are FAST's steps?", back: "Quantile-normalize, DCT per dimension, scale by γ = 10 and round, flatten low frequencies first, compress with BPE (vocabulary 1024).", ref: "arXiv 2501.09747" },
      { front: "What happens at g = 0 and at g = 1 in asynchronous inference?", back: "g = 0: the queue drains before each request, so the robot idles E[ℓ_S]. g = 1: an observation goes out almost every tick.", ref: "X2 §4.4" },
      { front: "What three parts does RTC's soft mask have?", back: "Weight 1 for the d actions executed during the delay, exponentially decaying weights on the overlap, 0 on the last s actions.", ref: "arXiv 2506.07339" },
      { front: "What is a semantic action slot?", back: "A fixed-meaning block in a shared action vector, such as 7 joints or a gripper; robots fill only their slots and the rest are masked.", ref: "P05 §7.2.2" },
      { front: "What does UniAct's universal action space contain?", back: "A codebook of 256 codes of 128 dimensions; a VLM picks one and a per-robot head decodes it.", ref: "arXiv 2501.10105" }
    ],
    terms: {
      "action-tokenization": { name: "action tokenization", aliases: ["binned action tokens", "256-bin discretization"], group: "actions", def: "Discretizing each dimension of the action space into bins, typically 256, and treating each bin ID as a discrete token trained with cross-entropy.", note: "Differs from k-means action binning: bins here are uniform per dimension, and a step needs one token per dimension.", ref: "P02 §IV-D.3", scene: "system", focus: ["llm-backbone", "action-head"], look: "the backbone emitting action tokens", uses: [] },
      "fast-tokenization": { name: "FAST tokenization", aliases: ["FAST", "FAST+", "frequency-space action tokenization"], group: "actions", def: "Applying a discrete cosine transform along time, quantizing the frequency components and compressing them with byte-pair encoding, which shortens action token sequences.", note: "Shorter sequences speed training; decoding is still autoregressive, about 750 ms per chunk.", ref: "P02 §IV-D.3 · arXiv 2501.09747", scene: "system", focus: ["action-chunk", "llm-backbone"], look: "a chunk compressed into few tokens", uses: ["discrete-cosine-transform", "byte-pair-encoding", "action-tokenization"] },
      "discrete-cosine-transform": { name: "discrete cosine transform", aliases: ["DCT"], group: "actions", sym: "C", symTex: "C^{i}_{j}", def: "A transform that writes a signal as a sum of cosines; smooth trajectories put almost all their energy in the first few coefficients.", note: "The transform itself is lossless; FAST's loss comes from rounding the coefficients.", ref: "arXiv 2501.09747", scene: "system", focus: ["action-chunk"], look: "the chunk as frequencies", uses: [] },
      "byte-pair-encoding": { name: "byte-pair encoding", aliases: ["BPE"], group: "actions", def: "A lossless compression that repeatedly merges the most frequent pair of symbols into a new symbol, as language tokenizers do.", note: "FAST trains a 1024-entry BPE vocabulary; without BPE many repeated zero tokens remain.", ref: "P02 §IV-D.2 · arXiv 2501.09747", scene: "system", focus: ["llm-backbone"], look: "merged tokens entering the backbone", uses: [] },
      "parallel-decoding": { name: "parallel decoding", aliases: ["non-autoregressive decoding", "OFT recipe"], group: "actions", def: "Producing all action outputs of a chunk in one forward pass with bidirectional attention, instead of one token after another.", note: "OpenVLA-OFT combined it with an L1 loss: 109.7 Hz versus 4.2 Hz for OpenVLA on LIBERO.", ref: "arXiv 2502.19645", scene: "system", focus: ["llm-backbone", "action-head"], look: "one pass emitting the whole chunk", uses: ["action-chunk"] },
      "adaptive-action-grid": { name: "adaptive action grid", aliases: ["spatial action tokens"], group: "actions", def: "Bins whose edges are set so each holds equal probability under a Gaussian fitted to the data, giving finer bins where motions are common.", note: "SpatialVLA uses 3 tokens per step; linear 256 bins scored 40.7% versus 81.6% on one task.", ref: "P02 §IV-D.3 · arXiv 2501.15830", scene: "system", focus: ["action-head"], look: "uneven bins over the action range", uses: ["action-tokenization"] },
      "universal-action-space": { name: "universal action space", aliases: ["UniAct codebook", "universal actions"], group: "actions", def: "A discrete codebook shared across embodiments; a transformer predicts codes, and embodiment-specific decoders turn them into continuous actions.", note: "Unlike latent actions learned from video frame changes, the codes are trained through real action losses.", ref: "P02 §IV-D.3 · arXiv 2501.10105", scene: "system", focus: ["latent", "action-head"], look: "one code feeding several robot heads", uses: [] },
      "semantic-action-slots": { name: "semantic action slots", aliases: ["canonical action vector", "unified action space"], group: "actions", def: "Fixed physical meanings for predefined blocks of a shared action vector, with unavailable components masked or zero-padded.", note: "Zero-padding alone fixes the size; slots also fix what each entry means.", ref: "P05 §7.2.2", scene: "system", focus: ["action-chunk", "action-head"], look: "labeled blocks of one action vector", uses: [] },
      "relative-trajectory-action": { name: "relative trajectory action", aliases: ["relative end-effector trajectory", "UMI actions"], group: "actions", def: "Future end-effector targets expressed relative to the current end-effector pose, which reduces sensitivity to the global tracking frame.", note: "Not the same as delta actions, which are relative to the previous step.", ref: "P05 §3.2.2 · arXiv 2402.10329", scene: "robot", focus: ["end-effector", "trajectory"], look: "targets drawn from the gripper's frame", uses: [] },
      "synchronous-inference": { name: "synchronous inference", aliases: ["sequential inference", "sync inference"], group: "actions", def: "Executing the whole action chunk and only then predicting the next one; the robot sits idle while the chunk is computed.", note: "X2 also labels the every-step extreme g = 1 as a sync limit; this site uses sync for waiting.", ref: "X2 §4.4", scene: "system", focus: ["controller", "robot"], look: "the robot waiting for the next chunk", uses: ["action-chunk"] },
      "asynchronous-inference": { name: "asynchronous inference", aliases: ["async inference", "decoupled inference"], group: "actions", def: "Decoupling chunk prediction from execution: the client keeps executing queued actions while a server, possibly remote, computes the next chunk.", note: "It hides latency but the new chunk is planned from an older observation.", ref: "X2 §4.4, Fig. 32", scene: "system", focus: ["action-chunk", "controller"], look: "the queue refilled while the robot moves", uses: ["synchronous-inference", "action-chunk"] },
      "action-queue-threshold": { name: "action-queue threshold", aliases: ["threshold g", "chunk size threshold"], group: "actions", sym: "g", symTex: "g", def: "The fraction g of a chunk below which the client captures and sends a new observation; queues never empty if g ≥ E[ℓ_S]/Δt/H.", note: "In LeRobot it is called chunk_size_threshold; the tutorial example uses 0.5.", ref: "X2 §4.4", scene: "system", focus: ["action-chunk"], look: "the refill line on the queue", uses: ["asynchronous-inference"] },
      "real-time-chunking": { name: "real-time chunking", aliases: ["RTC", "inpainting-based chunking"], group: "actions", def: "Treating asynchronous chunking as inpainting: freeze the actions executed during the delay and softly guide the new chunk toward the rest of the old one.", note: "Training-free, but only for diffusion or flow policies; each step costs about 2.5× more.", ref: "arXiv 2506.07339 · P01 §6.4.4", scene: "system", focus: ["action-head", "action-chunk"], look: "the new chunk joined to the old", uses: ["asynchronous-inference", "flow-matching", "temporal-ensembling"] }
    },
    symbols: [
      { id: "gq", tex: "g", glyph: "g", kind: "Parameters", meaning: "action-queue threshold: send a new observation when fewer than g·H actions remain", short: "queue threshold", first: "b3", read: "g", papers: "X2 Alg. 1: g · LeRobot: chunk_size_threshold" },
      { id: "lat", tex: "\\ell_S", glyph: "ℓ_S", kind: "Parameters", meaning: "inference latency of the policy server for one chunk", short: "server latency", first: "b3", read: "ell sub S", papers: "X2 §4.4: ℓ_S (ℓ = full round trip)" },
      { id: "dt", tex: "\\Delta t", glyph: "Δt", kind: "Parameters", meaning: "control period: time between two executed actions", short: "control period", first: "b3", read: "delta t", papers: "X2: Δt · P04: 1/f_ctrl · RTC: δ" },
      { id: "dctC", tex: "C^{i}", glyph: "Cⁱ", kind: "Signals", meaning: "DCT coefficients of action dimension i over a chunk", short: "DCT coefficients", first: "b3", read: "C super i", papers: "FAST: C^i_j" },
      { id: "qscale", tex: "\\gamma", glyph: "γ", kind: "Parameters", meaning: "FAST rounding scale: larger keeps more detail and makes more tokens (default 10)", short: "rounding scale", first: "b3", read: "gamma", papers: "FAST: γ (not the discount factor)" },
      { id: "ddelay", tex: "d", glyph: "d", kind: "Parameters", meaning: "inference delay, in controller steps, between observation and new chunk", short: "inference delay (steps)", first: "b3", read: "d", papers: "RTC: d" },
      { id: "sexec", tex: "s_{\\mathrm{ex}}", glyph: "s_ex", kind: "Parameters", meaning: "execution horizon: actions executed from a chunk before the next one starts", short: "execution horizon", first: "b3", read: "s ex", papers: "RTC: s" },
      { id: "Wmask", tex: "W_i", glyph: "Wᵢ", kind: "Parameters", meaning: "RTC guidance weight on action i of the previous chunk", short: "soft-mask weight", first: "b3", read: "W sub i", papers: "RTC eq. 5: W" }
    ],
    ledger: [
      { where: "Topic 07 · synchronous inference", source: "X2 §4.4 calls exhausting the chunk sync inference, then labels g = 1 (every tick) the sync-inference limit and g = 0 the sequential limit", page: "The site uses synchronous for waiting until the queue is empty (g = 0)", why: "One meaning per word.", kind: "Sources disagree" },
      { where: "Topic 07 · rules", source: "P04 eq. 34 writes the replan period as K", page: "The site writes H, because K is the number of denoising steps", why: "House notation.", kind: "Our choice" },
      { where: "Topic 07 · RTC mask", source: "RTC writes the execution horizon as s", page: "The site writes s_ex", why: "Plain s is the state.", kind: "Our choice" },
      { where: "Topic 07 · FAST rule", source: "FAST writes the rounding scale as γ", page: "The site keeps γ with its own symbol id", why: "It is not the discount factor.", kind: "Our choice" },
      { where: "Topic 07 · FAST quantization", source: "A secondary summary describes FAST as quantizing to 256 levels", page: "The site follows the paper: scale-and-round with γ = 10", why: "The method paper is primary.", kind: "Sources disagree" },
      { where: "Topic 07 · playground 1", source: "LeRobot's client aggregates overlapping chunks with a function f and filters near-duplicate observations", page: "The toy keeps one request in flight, drops stale actions, replaces the old queue and has no filter", why: "Shows the effect of g and latency alone.", kind: "Simplified" },
      { where: "Topic 07 · playground 2", source: "RTC steers flow sampling with gradient guidance toward the old chunk", page: "The toy locks the new chunk to the old mode and blends with the soft mask", why: "Same visible effect without a trained flow model.", kind: "Simplified" }
    ]
  });
})();
