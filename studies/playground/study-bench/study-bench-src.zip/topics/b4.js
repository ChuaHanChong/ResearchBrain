/* Topic 08 · Vision-language-action models. Sources: P02 Def. I.1, §III, §IV-A (Fig. 4), §V, §VIII, §IX; P01 §2.3, §6.2.2 (Fig. 17);
   X2 §5.1–5.4 (eq. 52–53, Fig. 37, 39); method cards (tier 1): Gato, VIMA, RT-1, RT-2, OXE/RT-X, Octo, OpenVLA, RDT-1B, π0, π0.5,
   Knowledge Insulation, GR00T N1, SmolVLA, π0.7, CogACT, RT-H, Hi Robot. */
(function () {
  "use strict";
  var RB = window.RB;

  /* RB.bindSeg passes a string to a callback that reads .value, so segments are wired directly (same as topics a3, b1) */
  function onSeg(root, id, cb) { StudyBench.segmented(root.querySelector("#" + id), function (v) { cb(typeof v === "string" ? v : v.value); }); }
  function pressSeg(root, id, val) { RB.$$("#" + id + " button", root).forEach(function (b) { b.setAttribute("aria-pressed", String(b.value === val)); }); }

  /* =====================================================================================
     Playground 1 · Architecture builder: backbone × action output → a cell of P02 Fig. 4
     The pass counts are a simplified cost model (sequential forward passes per call), not measured latency.
     ===================================================================================== */
  var HEADS = [
    { v: "tok", label: "Tokens" },
    { v: "dh", label: "Diffusion head" },
    { v: "fh", label: "Flow head" },
    { v: "dit", label: "DiT" }
  ];
  var CELLS = {
    "tf-tok": { n: "1", name: "Transformer + discrete action token", ex: "Gato, VIMA, RT-1",
      rep: "RT-1", facts: [["Size", "35M parameters"], ["Output", "11 action dimensions × 256 bins, one step per call"], ["Speed", "3 Hz control; all tokens decoded in one pass"]], ref: "arXiv 2212.06817 · P02 §IV-A(1)" },
    "tf-dh": { n: "2", name: "Transformer + diffusion action head", ex: "Octo, NoMAD, TinyVLA",
      rep: "Octo", facts: [["Size", "27M (Small) or 93M (Base)"], ["Output", "Action chunk from a 3-layer MLP diffusion head"], ["Steps", "20 DDPM steps in the head only"]], ref: "arXiv 2405.12213 · P02 §IV-A(2)" },
    "tf-fh": { n: "–", name: "No cell in P02 Fig. 4", ex: "Flow heads appear with VLM backbones: cells 6 and 7",
      rep: "–", facts: [["Note", "P02 lists flow matching only with a VLM backbone"], ["Nearest", "Cell 2 (Octo) with a diffusion head"]], ref: "P02 Fig. 4" },
    "tf-dit": { n: "3", name: "Diffusion transformer", ex: "RDT-1B, LBM, MDT, Dita",
      rep: "RDT-1B", facts: [["Size", "1.2B diffusion transformer"], ["Output", "64-action chunk in a 128-D unified space"], ["Steps", "5 DPM-Solver++ steps; chunks at 6 Hz"]], ref: "arXiv 2410.07864 · P02 §IV-A(3)" },
    "vlm-tok": { n: "4", name: "VLM + discrete action token", ex: "RT-2, OpenVLA, RT-H, ECoT",
      rep: "RT-2 · OpenVLA", facts: [["Size", "RT-2 up to 55B; OpenVLA 7B"], ["Output", "One step: 7–8 tokens, 256 bins each"], ["Speed", "RT-2-55B 1–3 Hz; OpenVLA about 6 Hz"]], ref: "arXiv 2307.15818 · 2406.09246 · P02 §IV-A(4)" },
    "vlm-dh": { n: "5", name: "VLM + diffusion action head", ex: "DiffusionVLA, DexVLA, GO-1, PointVLA",
      rep: "DexVLA", facts: [["Size", "About 3B: 2B VLM + 1B diffusion expert"], ["Output", "Continuous joint actions, one head per embodiment"], ["Speed", "60 Hz reported on one A6000"]], ref: "arXiv 2502.05855 · P02 §IV-A(5)" },
    "vlm-fh": { n: "6", name: "VLM + flow matching action head", ex: "π0, Hume; π0.5 mixes 4 and 6",
      rep: "π0", facts: [["Size", "3.3B: 3B VLM + 300M action expert"], ["Output", "50-action chunk, 10 Euler flow steps"], ["Speed", "73 ms per chunk on an RTX 4090; up to 50 Hz control"]], ref: "arXiv 2410.24164 · P02 §IV-A(6)" },
    "vlm-dit": { n: "7", name: "VLM + diffusion transformer", ex: "GR00T N1, CogACT, SmolVLA",
      rep: "GR00T N1", facts: [["Size", "2.2B, of which 1.34B VLM"], ["Output", "16-action chunk, 4 flow steps in a DiT"], ["Speed", "63.9 ms per chunk on an L40"]], ref: "arXiv 2503.14734 · P02 §IV-A(7)" }
  };

  function passes(bb, head, D, H, K, par) {
    /* returns {big, small, note}: sequential forward passes of the large model and of the small action module per call */
    if (head === "tok") return par ? { big: 1, small: 0 } : { big: D * H, small: 0 };
    if (head === "dit" && bb === "tf") return { big: K, small: 0 };
    return { big: 1, small: K };
  }

  function stackSVG(bb, head, D, H, K, par) {
    var isTok = head === "tok", big = bb === "vlm" ? "VLM backbone" : "Transformer", bigSub = bb === "vlm" ? "web-pretrained" : "from scratch";
    var outName = { tok: "De-tokenizer", dh: "Diffusion head", fh: "Flow action expert", dit: bb === "tf" ? "MLP decoder" : "DiT expert" }[head];
    var outSub = { tok: "bin index → value", dh: "small, runs K times", fh: "small, runs K times", dit: bb === "tf" ? "maps tokens to actions" : "runs K times" }[head];
    var loopOnBig = (isTok && !par) || (head === "dit" && bb === "tf"), loopOnHead = !isTok && !(head === "dit" && bb === "tf");
    var loopTxt = isTok ? "× " + (D * H) + " sequential tokens" : "× " + K + " denoising steps";
    var nAct = isTok ? H : Math.max(H, 1);
    var s = '<svg class="rb-svg" viewBox="0 0 560 170" role="img" aria-label="Stack: inputs, ' + big + ', ' + outName + ', actions. The loop marks where repeated passes happen.">' +
      '<defs><marker id="b4-ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10z" class="rb-arrowhead"/></marker></defs>' +
      '<rect x="8" y="64" width="96" height="56" rx="6" class="rb-f-sunk"/><text x="56" y="88" text-anchor="middle" class="rb-t-ink">Images oₜ</text><text x="56" y="106" text-anchor="middle" class="rb-t-ink">Instruction ℓ</text>' +
      '<path d="M104 92 H134" class="rb-s-ink" marker-end="url(#b4-ah)"/>' +
      '<rect x="138" y="58" width="150" height="68" rx="8" class="' + (loopOnBig ? "rb-f-soft" : "rb-f-surface") + '"/><text x="213" y="88" text-anchor="middle" class="rb-t-ink">' + big + '</text><text x="213" y="106" text-anchor="middle" class="rb-t-mono">' + bigSub + '</text>' +
      '<path d="M288 92 H318" class="rb-s-ink" marker-end="url(#b4-ah)"/>' +
      '<rect x="322" y="64" width="130" height="56" rx="8" class="' + (loopOnHead ? "rb-f-soft" : "rb-f-surface") + '"/><text x="387" y="88" text-anchor="middle" class="rb-t-ink">' + outName + '</text><text x="387" y="106" text-anchor="middle" class="rb-t-mono">' + outSub + '</text>' +
      '<path d="M452 92 H482" class="rb-s-ink" marker-end="url(#b4-ah)"/>' +
      '<rect x="486" y="64" width="66" height="56" rx="6" class="rb-f-sunk"/><text x="519" y="88" text-anchor="middle" class="rb-t-ink">' + nAct + '</text><text x="519" y="106" text-anchor="middle" class="rb-t-mono">action' + (nAct > 1 ? "s" : "") + '</text>';
    if (loopOnBig) s += '<path d="M180 58 C180 22 246 22 246 56" class="rb-s-acc" marker-end="url(#b4-ah)"/><text x="213" y="18" text-anchor="middle" class="rb-t-acc">' + loopTxt + '</text>';
    if (loopOnHead) s += '<path d="M356 64 C356 28 418 28 418 62" class="rb-s-acc" marker-end="url(#b4-ah)"/><text x="387" y="22" text-anchor="middle" class="rb-t-acc">' + loopTxt + '</text>';
    if (isTok && par) s += '<text x="213" y="40" text-anchor="middle" class="rb-t-acc">1 pass, all tokens at once</text>';
    s += '<text x="280" y="156" text-anchor="middle" class="rb-t-mono">accent = the part that runs repeatedly for one call</text></svg>';
    return s;
  }

  function gridSVG(bb, head) {
    var cols = HEADS.map(function (h) { return h.v; }), rows = [["tf", "Transformer"], ["vlm", "VLM"]];
    var s = '<svg class="rb-svg" viewBox="0 0 560 200" role="img" aria-label="Grid of the seven VLA architectures in P02 Fig. 4: two backbones by four action outputs">';
    var heads2 = [["Discrete", "tokens"], ["Diffusion", "head"], ["Flow", "head"], ["Diffusion", "transformer"]];
    heads2.forEach(function (h, i) { var x = 150 + i * 102; s += '<text x="' + x + '" y="16" text-anchor="middle" class="rb-t-mono">' + h[0] + '</text><text x="' + x + '" y="30" text-anchor="middle" class="rb-t-mono">' + h[1] + "</text>"; });
    rows.forEach(function (r, ri) {
      var y = 40 + ri * 80;
      s += '<text x="46" y="' + (y + 40) + '" text-anchor="middle" class="rb-t-ink">' + r[1] + "</text>";
      cols.forEach(function (c, ci) {
        var cell = CELLS[r[0] + "-" + c], x = 100 + ci * 102, on = r[0] === bb && c === head;
        s += '<g data-cell="' + r[0] + "-" + c + '" style="cursor:pointer"><rect x="' + x + '" y="' + y + '" width="96" height="72" rx="6" class="' + (on ? "rb-f-soft" : cell.n === "–" ? "rb-f-sunk" : "rb-f-surface") + '"/>' +
          '<text x="' + (x + 48) + '" y="' + (y + 30) + '" text-anchor="middle" class="' + (on ? "rb-t-acc" : "rb-t-ink") + '">' + (cell.n === "–" ? "none" : "(" + cell.n + ")") + "</text>" +
          '<text x="' + (x + 48) + '" y="' + (y + 52) + '" text-anchor="middle" class="rb-t-mono">' + (cell.n === "–" ? "–" : RB.esc(cell.rep)) + "</text></g>";
      });
    });
    return s + "</svg>";
  }

  function mountBuilder(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-bb", label: "Backbone", value: "vlm", options: [{ value: "tf", label: "Transformer" }, { value: "vlm", label: "Pretrained VLM" }] }) +
      RB.seg({ id: id + "-head", label: "Action output", value: "tok", options: HEADS.map(function (h) { return { value: h.v, label: h.label }; }) }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-d", label: "Action dims D", min: 1, max: 14, step: 1, value: 7 }) +
      RB.slider({ id: id + "-h", label: "Chunk H", min: 1, max: 50, step: 1, value: 1 }) +
      RB.slider({ id: id + "-k", label: "Denoising steps K", min: 1, max: 20, step: 1, value: 10 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-par"> <span>Decode all tokens in one pass</span></label></div>' +
      '<div class="sb-split sb-split--fig-wide"><figure class="rb-fig"><div data-grid></div><div data-stack></div><figcaption class="sb-caption">Top: the seven cells of P02 Fig. 4; click one. Bottom: the chosen stack. The accent loop shows which part runs again and again for one call.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "cell", k: "Cell in P02 Fig. 4" }, { id: "big", k: "Big-model passes per call" }, { id: "small", k: "Small-module passes per call" }, { id: "acts", k: "Actions per call" }]) +
      '<div class="rb-well"><p class="sb-caption" data-name></p><dl class="rb-kv" data-facts></dl><p class="sb-caption" data-ref></p></div><p class="sb-caption" data-note></p></div></div>';
    var st = { bb: "vlm", head: "tok", D: 7, H: 1, K: 10, par: false };
    var gridHost = body.querySelector("[data-grid]"), stackHost = body.querySelector("[data-stack]"); gridHost.classList.add("rb-fig-scroll"); stackHost.classList.add("rb-fig-scroll");
    function render() {
      var key = st.bb + "-" + st.head, cell = CELLS[key], p = passes(st.bb, st.head, st.D, st.H, st.K, st.par);
      gridHost.innerHTML = gridSVG(st.bb, st.head);
      stackHost.innerHTML = stackSVG(st.bb, st.head, st.D, st.H, st.K, st.par);
      RB.$$("[data-cell]", gridHost).forEach(function (g) { g.addEventListener("click", function () { var k = g.getAttribute("data-cell").split("-"); st.bb = k[0]; st.head = k[1]; pressSeg(body, id + "-bb", st.bb); pressSeg(body, id + "-head", st.head); render(); }); });
      RB.setRO(body, "cell", cell.n === "–" ? "none" : "(" + cell.n + ")");
      RB.setRO(body, "big", String(p.big));
      RB.setRO(body, "small", String(p.small));
      RB.setRO(body, "acts", String(st.H));
      body.querySelector("[data-name]").innerHTML = "<b>" + RB.esc(cell.name) + "</b> · " + RB.esc(cell.ex);
      body.querySelector("[data-facts]").innerHTML = cell.facts.map(function (f) { return "<dt>" + f[0] + "</dt><dd>" + RB.esc(f[1]) + "</dd>"; }).join("");
      body.querySelector("[data-ref]").textContent = "Representative: " + cell.rep + " · " + cell.ref;
      var note;
      if (st.head === "tok" && !st.par) note = "Autoregressive decoding: every token of every action is one more pass of the big model, one after the other.";
      else if (st.head === "tok") note = "One pass for all tokens, as RT-1 does (and OpenVLA-OFT later with continuous outputs).";
      else if (st.head === "dit" && st.bb === "tf") note = "The denoising runs inside the backbone itself, so the big model runs K times.";
      else note = "The big model runs once; the K denoising steps happen in the smaller action module.";
      body.querySelector("[data-note]").textContent = note;
      body.querySelector("#" + id + "-k").disabled = st.head === "tok";
      body.querySelector("#" + id + "-par").disabled = st.head !== "tok";
    }
    onSeg(body, id + "-bb", function (v) { st.bb = v; render(); });
    onSeg(body, id + "-head", function (v) { st.head = v; render(); });
    RB.bindSlider(body, id + "-d", null, function (v) { st.D = v; render(); });
    RB.bindSlider(body, id + "-h", null, function (v) { st.H = v; render(); });
    RB.bindSlider(body, id + "-k", null, function (v) { st.K = v; render(); });
    body.querySelector("#" + id + "-par").addEventListener("change", function (e) { st.par = e.target.checked; render(); });
    render();
    return { state: function () { return { bb: st.bb, head: st.head, D: st.D, H: st.H, K: st.K, par: st.par }; } };
  }

  /* =====================================================================================
     Playground 2 · Freeze, fine-tune, co-train or insulate
     Linear toy: inputs x ∈ R⁶, backbone features f = W x (3 features), pretrained W0 = first three coordinates.
     Two frozen "language" heads read features 1 and 2 (their targets are x1, x2). The robot action a = 0.6 x1 + 0.8 x4 needs x4,
     which W0 does not encode. A randomly initialized action head v reads f. Gradient descent, 200 steps.
     ===================================================================================== */
  function trainToy(mode, scale) {
    var R = RB.rng(11), N = 200, D = 6, X = [], i, j, k;
    for (i = 0; i < N; i++) { var x = []; for (j = 0; j < D; j++) x.push(R.normal()); X.push(x); }
    var g = [0.6, 0, 0, 0.8, 0, 0];
    var W = [[1, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0]], u0 = [1, 0, 0], u1 = [0, 1, 0];
    var v = [scale * R.normal(), scale * R.normal(), scale * R.normal()], h = [0, 0, 0], lr = 0.1;
    var va = 0, vl = 0;
    X.forEach(function (x) { var a = 0.6 * x[0] + 0.8 * x[3]; va += a * a; vl += (x[0] * x[0] + x[1] * x[1]) / 2; });
    va /= N; vl /= N;
    var act = [], lang = [];
    for (var s = 0; s <= 200; s++) {
      var gW = [[0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]], gv = [0, 0, 0], gh = [0, 0, 0], ea = 0, el = 0;
      for (i = 0; i < N; i++) {
        var xx = X[i], f = [0, 0, 0];
        for (k = 0; k < 3; k++) for (j = 0; j < D; j++) f[k] += W[k][j] * xx[j];
        var a = 0; for (j = 0; j < D; j++) a += g[j] * xx[j];
        var pa = 0, pl = 0, pl2 = 0, pt = 0;
        for (k = 0; k < 3; k++) { pa += v[k] * f[k]; pl += u0[k] * f[k]; pl2 += u1[k] * f[k]; pt += h[k] * f[k]; }
        var e = pa - a, e2 = pl - xx[0], e4 = pl2 - xx[1], e3 = pt - a;
        ea += e * e; el += (e2 * e2 + e4 * e4) / 2;
        for (k = 0; k < 3; k++) { gv[k] += e * f[k] / N; gh[k] += e3 * f[k] / N; }
        var df = [0, 0, 0];
        if (mode === "full" || mode === "cotrain") for (k = 0; k < 3; k++) df[k] += e * v[k];        /* action-head gradient reaches the backbone */
        if (mode === "cotrain" || mode === "ki") for (k = 0; k < 3; k++) df[k] += e2 * u0[k] + e4 * u1[k]; /* web (language) data kept in the mix */
        if (mode === "ki") for (k = 0; k < 3; k++) df[k] += e3 * h[k];                                 /* discrete action-token loss on the backbone */
        if (mode !== "frozen") for (k = 0; k < 3; k++) for (j = 0; j < D; j++) gW[k][j] += df[k] * xx[j] / N;
      }
      if (s % 5 === 0) { act.push([s, Math.min(1.5, ea / N / va)]); lang.push([s, Math.min(1.5, el / N / vl)]); }
      for (k = 0; k < 3; k++) { v[k] -= lr * gv[k]; h[k] -= lr * gh[k]; for (j = 0; j < D; j++) W[k][j] -= lr * gW[k][j]; }
    }
    return { act: act, lang: lang };
  }

  var OVLA_FT = [["Full fine-tune", 69.7], ["LoRA, rank 32", 68.2], ["Sandwich", 62.1], ["Frozen vision", 47.0], ["Last layer only", 30.3]];
  function ftBars() {
    var s = '<svg class="rb-svg" viewBox="0 0 320 150" role="img" aria-label="OpenVLA fine-tuning ablation on Franka-Tabletop: full 69.7, LoRA 68.2, sandwich 62.1, frozen vision 47.0, last layer only 30.3 percent success">';
    OVLA_FT.forEach(function (r, i) {
      var y = 8 + i * 28, w = r[1] / 100 * 170;
      s += '<text x="0" y="' + (y + 13) + '" class="rb-t-mono">' + r[0] + '</text><rect x="110" y="' + y + '" width="' + w.toFixed(1) + '" height="18" rx="3" style="fill:var(--data-' + (i === 1 ? 2 : 1) + ')"/><text x="' + (116 + w).toFixed(1) + '" y="' + (y + 13) + '" class="rb-t-ink">' + r[1].toFixed(1) + "%</text>";
    });
    return s + "</svg>";
  }

  function mountTune(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Training recipe", value: "frozen", options: [{ value: "frozen", label: "Frozen" }, { value: "full", label: "Full" }, { value: "cotrain", label: "Co-train" }, { value: "ki", label: "Insulated" }] }) +
      RB.slider({ id: id + "-sc", label: "Random head scale", min: 0.5, max: 2, step: 0.1, value: 1, fmt: function (v) { return (+v).toFixed(1); } }) + "</div>" +
      '<div class="rb-grid2"><div data-chart></div><div class="rb-stack">' +
      RB.readouts([{ id: "act", k: "Final action error" }, { id: "lang", k: "Final language error" }, { id: "peak", k: "Worst language error" }, { id: "reach", k: "Steps to action error < 5%" }]) +
      '<p class="sb-caption" data-note></p><figure class="rb-fig"><div>' + ftBars() + '</div><figcaption class="sb-caption">Real data, not the toy: OpenVLA success on Franka-Tabletop by fine-tuning strategy. LoRA nearly matches full fine-tuning (arXiv 2406.09246).</figcaption></figure></div></div>';
    var mode = "frozen", scale = 1, last = null, host = body.querySelector("[data-chart]"), note = body.querySelector("[data-note]");
    var NOTES = {
      frozen: "Only the action head trains. Language stays intact, but the frozen features lack what the action needs, so the error stays high. KI reports 0% on some tasks with a frozen VLM.",
      full: "Gradients from the random action head reshape the backbone. The action is learned, but the language heads now read corrupted features.",
      cotrain: "Mixing web data back in, as RT-2 does, repairs language in the end. The early spike from the random head remains.",
      ki: "The action expert's gradient is stopped; the backbone learns the action through token prediction plus web data. In this toy that is slower; in the KI paper it trained faster than π0."
    };
    function pct(v) { return Math.round(v * 100) + "%"; }
    function run() {
      last = trainToy(mode, scale);
      var A = last.act, L = last.lang, peak = 0, reach = null;
      L.forEach(function (p) { if (p[1] > peak) peak = p[1]; });
      for (var i = 0; i < A.length; i++) if (A[i][1] < 0.05) { reach = A[i][0]; break; }
      RB.setRO(body, "act", pct(A[A.length - 1][1]));
      RB.setRO(body, "lang", pct(L[L.length - 1][1]));
      RB.setRO(body, "peak", pct(peak));
      RB.setRO(body, "reach", reach == null ? "never" : String(reach));
      note.textContent = NOTES[mode];
      host.innerHTML = "";
      StudyBench.lineChart(host, { title: "Errors during fine-tuning", height: 240, directLabels: false, x: { label: "training step", min: 0, max: 200 }, y: { label: "error (share of variance)", min: 0, max: 1.5, fmt: pct },
        series: [{ name: "robot action error", color: "data-1", points: A }, { name: "language (web task) error", color: "data-2", dash: true, points: L }],
        caption: "Solid: how badly the action head predicts the demonstrated action. Dashed: how badly the pretrained language heads now answer. Both start from the same pretrained backbone." });
    }
    onSeg(body, id + "-mode", function (v) { mode = v; run(); });
    RB.bindSlider(body, id + "-sc", function (v) { return (+v).toFixed(1); }, function (v) { scale = v; run(); });
    run();
    return { state: function () { return { mode: mode, scale: scale }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token colors only) ---------- */
  var ART = {
    vla: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="8" width="34" height="18" rx="3" class="rb-f-sunk"/><text x="23" y="21" text-anchor="middle" class="rb-t-mono">oₜ</text><rect x="6" y="32" width="34" height="18" rx="3" class="rb-f-sunk"/><text x="23" y="45" text-anchor="middle" class="rb-t-mono">ℓ</text><path d="M42 17 L70 26 M42 41 L70 32" class="rb-s-ink"/><rect x="72" y="12" width="70" height="32" rx="6" class="rb-f-soft"/><text x="107" y="32" text-anchor="middle" class="rb-t-acc">VLA</text><path d="M144 28 H168" class="rb-s-ink"/><text x="182" y="32" text-anchor="middle" class="rb-t-ink">aₜ</text></svg>',
    tokens: '<svg viewBox="0 0 200 56" aria-hidden="true">' + ["1", "128", "91", "241", "5", "101", "127"].map(function (t, i) { return '<rect x="' + (4 + i * 28) + '" y="14" width="24" height="20" rx="3" class="' + (i ? "rb-f-surface" : "rb-f-sunk") + '"/><text x="' + (16 + i * 28) + '" y="28" text-anchor="middle" class="rb-t-mono">' + t + "</text>"; }).join("") + '<text x="100" y="50" text-anchor="middle" class="rb-t-mono">one RT-2 action as tokens</text></svg>',
    cotrain: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="10" width="60" height="14" rx="2" class="rb-f-sunk"/><text x="38" y="21" text-anchor="middle" class="rb-t-mono">web</text><rect x="8" y="30" width="60" height="14" rx="2" class="rb-f-soft"/><text x="38" y="41" text-anchor="middle" class="rb-t-mono">robot</text><path d="M72 17 L104 27 M72 37 L104 29" class="rb-s-ink"/><rect x="108" y="14" width="56" height="28" rx="6" class="rb-f-surface"/><text x="136" y="32" text-anchor="middle" class="rb-t-ink">VLM</text><text x="182" y="32" text-anchor="middle" class="rb-t-mono">1 : 1</text></svg>',
    xemb: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (i) { var x = 14 + i * 26; return '<circle cx="' + x + '" cy="' + (16 + (i % 2) * 22) + '" r="9" class="rb-f-surface"/><path d="M' + (x + 9) + " " + (16 + (i % 2) * 22) + ' L128 28" class="rb-s-line"/>'; }).join("") + '<ellipse cx="148" cy="16" rx="22" ry="6" class="rb-f-soft"/><path d="M126 16 V40 A22 6 0 0 0 170 40 V16" class="rb-s-acc"/><text x="148" y="34" text-anchor="middle" class="rb-t-mono">OXE</text><text x="186" y="32" text-anchor="middle" class="rb-t-mono">22</text></svg>',
    expert: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="8" width="96" height="40" rx="6" class="rb-f-surface"/><text x="56" y="26" text-anchor="middle" class="rb-t-ink">VLM</text><text x="56" y="40" text-anchor="middle" class="rb-t-mono">3B</text><path d="M108 22 H132 M132 34 H108" class="rb-s-acc"/><rect x="136" y="14" width="56" height="28" rx="6" class="rb-f-soft"/><text x="164" y="26" text-anchor="middle" class="rb-t-mono">expert</text><text x="164" y="38" text-anchor="middle" class="rb-t-mono">300M</text></svg>',
    ki: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="10" width="80" height="36" rx="6" class="rb-f-surface"/><text x="48" y="32" text-anchor="middle" class="rb-t-ink">backbone</text><rect x="126" y="14" width="66" height="28" rx="6" class="rb-f-soft"/><text x="159" y="32" text-anchor="middle" class="rb-t-mono">expert</text><path d="M92 22 H122" class="rb-s-ink"/><path d="M122 36 H92" class="rb-s-line" stroke-dasharray="3 3"/><path d="M101 30 L113 42 M113 30 L101 42" class="rb-s-acc"/><text x="107" y="54" text-anchor="middle" class="rb-t-mono">no gradient</text></svg>',
    dual: '<svg viewBox="0 0 200 56" aria-hidden="true"><text x="4" y="16" class="rb-t-mono">System 2</text>' + [0, 1, 2].map(function (i) { return '<line x1="' + (70 + i * 60) + '" y1="6" x2="' + (70 + i * 60) + '" y2="20" class="rb-s-acc"/>'; }).join("") + '<text x="4" y="44" class="rb-t-mono">System 1</text>' + Array.apply(null, Array(16)).map(function (_, i) { return '<line x1="' + (70 + i * 8) + '" y1="34" x2="' + (70 + i * 8) + '" y2="48" class="rb-s-ink"/>'; }).join("") + '</svg>',
    hier: '<svg viewBox="0 0 200 56" aria-hidden="true"><text x="14" y="32" text-anchor="middle" class="rb-t-ink">ℓ</text><path d="M24 28 H46" class="rb-s-ink"/><rect x="50" y="12" width="84" height="32" rx="6" class="rb-f-soft"/><text x="92" y="26" text-anchor="middle" class="rb-t-acc">ℓ̂</text><text x="92" y="39" text-anchor="middle" class="rb-t-mono">subtask</text><path d="M138 28 H162" class="rb-s-ink"/><text x="180" y="32" text-anchor="middle" class="rb-t-ink">aₜ…</text></svg>'
  };

  /* ---------- worked example figure: tokenizing one action dimension (numbers computed below) ----------
     bins: q1 = −40 mm, q99 = +40 mm, 256 bins → width 80/256 = 0.3125 mm.
     Δx = 12.3 mm → (12.3 + 40) / 0.3125 = 167.36 → token 167. Bin centre −40 + 167.5 × 0.3125 = 12.34375 mm; error 0.04375 mm. */
  var X = function (v) { return (280 + v * 6).toFixed(1); };
  var WE_FIG = '<svg viewBox="0 0 560 214" role="img" aria-label="Number line from minus 40 to plus 40 millimeters split into 256 bins; the value 12.3 falls in bin 167">' +
    '<g data-on="1+"><line x1="40" y1="40" x2="520" y2="40" class="rb-s-line"/>' + [-40, -20, 0, 20, 40].map(function (v) { return '<line x1="' + X(v) + '" y1="34" x2="' + X(v) + '" y2="46" class="rb-s-line"/><text x="' + X(v) + '" y="60" text-anchor="middle" class="rb-t-mono">' + (v === -40 ? "q₁ = −40" : v === 40 ? "q₉₉ = +40" : (v > 0 ? "+" : "") + v) + "</text>"; }).join("") +
    '<text x="40" y="22" class="rb-t-mono">Δx in mm</text></g>' +
    '<g data-on="2+"><circle cx="' + X(12.3) + '" cy="40" r="6" class="rb-f-acc"/><text x="' + X(12.3) + '" y="22" text-anchor="middle" class="rb-t-acc">Δx = 12.3 → b = 167</text></g>' +
    '<g data-on="3+"><path d="M' + X(12.3) + ' 46 L340 78 M' + X(12.3) + ' 46 L380 78" class="rb-s-line" stroke-dasharray="3 3"/>' +
    [166, 167, 168].map(function (b, i) { return '<rect x="' + (300 + i * 40) + '" y="78" width="40" height="22" class="' + (b === 167 ? "rb-f-soft" : "rb-f-surface") + '"/><text x="' + (320 + i * 40) + '" y="93" text-anchor="middle" class="rb-t-mono">' + b + "</text>"; }).join("") +
    '<line x1="360" y1="74" x2="360" y2="100" class="rb-s-acc"/><text x="360" y="120" text-anchor="middle" class="rb-t-ink">decoded 12.34 mm · error 0.04 mm</text></g>' +
    '<g data-on="4+">' + [1, 2, 3, 4, 5, 6, 7].map(function (d) { return '<rect x="' + (40 + (d - 1) * 34) + '" y="134" width="28" height="22" rx="3" class="' + (d === 1 ? "rb-f-soft" : "rb-f-surface") + '"/><text x="' + (54 + (d - 1) * 34) + '" y="149" text-anchor="middle" class="rb-t-mono">b' + ["₁", "₂", "₃", "₄", "₅", "₆", "₇"][d - 1] + "</text>"; }).join("") + '<text x="290" y="150" class="rb-t-ink">7 tokens → 7 passes, one after another</text></g>' +
    '<g data-on="5+"><text x="40" y="178" class="rb-t-ink">14 dims × 50 Hz = 700 tokens for one second of control</text></g>' +
    '<g data-on="6"><text x="40" y="204" class="rb-t-ink">π0: 1 VLM pass + 10 expert passes → 50 actions in 73 ms</text></g></svg>';

  RB.topic({
    id: "b4",
    title: "Vision-language-action models",
    eyebrow: "Part B · VLAs",
    lede: "A vision-language-action model reuses a web-pretrained vision-language model to turn camera images and an instruction directly into robot actions.",
    refs: ["P02 §III–IV", "P01 §6.2.2", "X2 §5"],
    why: "Robot data alone is too narrow to teach what a mug or a trash bin is. A vision-language-action (VLA) model borrows that knowledge from a vision-language model (VLM) trained on web data, then learns to output actions. Two design questions follow: how actions leave the model, and how to train it without erasing what it knew.",
    outcomes: [
      "Define a VLA and name the seven architecture cells of P02.",
      "Trace what each step from RT-1 to π0.7 changed about its predecessor.",
      "Compute a binned action token and the token count per second.",
      "Compare where autoregressive and flow-based VLAs spend their forward passes.",
      "Explain why knowledge insulation stops action-head gradients at the backbone."
    ],
    concepts: [
      { name: "Vision-language-action model", def: "Takes images and a language instruction as required inputs and directly generates robot control commands.", ref: "P02 Def. I.1", art: ART.vla, term: "vision-language-action-model", sym: "l" },
      { name: "Actions as tokens", def: "RT-2 bins each action dimension into 256 values and writes them as text tokens the VLM can emit.", ref: "arXiv 2307.15818", art: ART.tokens, term: "action-token", sym: "btok" },
      { name: "Co-fine-tuning", def: "Train on robot data and web vision-language data together so the backbone keeps its web knowledge.", ref: "P02 §III · RT-2", art: ART.cotrain, term: "co-fine-tuning" },
      { name: "Cross-embodiment data", def: "Open X-Embodiment pooled 60 datasets from 22 robots; one model trained on all transferred positively.", ref: "arXiv 2310.08864", art: ART.xemb, term: "cross-embodiment-training" },
      { name: "Action expert", def: "π0 adds a 300M-parameter transformer that shares attention with the VLM and outputs chunks by flow matching.", ref: "X2 §5.3, Fig. 37", art: ART.expert, term: "action-expert", sym: "v", href: "#lab/vla" },
      { name: "Knowledge insulation", def: "Stop the action expert's gradients at the backbone; train the backbone on discrete action tokens instead.", ref: "P02 §V · arXiv 2505.23705", art: ART.ki, term: "knowledge-insulation" },
      { name: "Dual system", def: "A slow VLM (System 2) steers a fast action module (System 1); GR00T N1: 10 and 120 Hz.", ref: "P02 §IV-A(7)", art: ART.dual, term: "dual-system-vla" },
      { name: "Hierarchical VLA", def: "The model first predicts a subtask or language motion, then the actions conditioned on it.", ref: "P02 §III", art: ART.hier, term: "hierarchical-vla", sym: "lhat" }
    ],
    flow: {
      title: "Where a VLA acts in one control step", ref: "P02 Fig. 4 · X2 Fig. 37", w: 840, h: 300,
      caption: "Images and the instruction enter one backbone as tokens. The action output is either tokens the backbone decodes itself or a separate expert that reads its features.",
      nodes: [
        { id: "cam", x: 20, y: 30, w: 140, h: 56, label: "Camera images", sub: "oₜ, plus joint state", kind: "env" },
        { id: "instr", x: 20, y: 130, w: 140, h: 56, label: "Instruction ℓ", sub: "a task in words", kind: "env" },
        { id: "web", x: 20, y: 226, w: 140, h: 56, label: "Web data", sub: "image–text pairs", kind: "store" },
        { id: "vlm", x: 250, y: 124, w: 150, h: 68, label: "VLM backbone", sub: "web-pretrained", kind: "agent" },
        { id: "head", x: 480, y: 124, w: 140, h: 68, label: "Action output", sub: "tokens or expert", kind: "agent" },
        { id: "robot", x: 710, y: 124, w: 110, h: 68, label: "Robot", sub: "runs actions", kind: "env" }
      ],
      edges: [
        { from: "cam", to: "vlm", label: "image tokens", sides: ["r", "t"], via: [[325, 58]] },
        { from: "instr", to: "vlm", label: "text tokens", dy: -8 },
        { from: "web", to: "vlm", label: "pretraining", sides: ["r", "b"], via: [[325, 254]], dashed: true },
        { from: "vlm", to: "head", label: "features", dy: -8 },
        { from: "head", to: "robot", label: "actions", dy: -8 },
        { from: "robot", to: "cam", label: "new images", sides: ["t", "t"], via: [[765, 14], [90, 14]], dy: -6 }
      ],
      steps: [
        { on: ["cam", "instr", "cam>vlm", "instr>vlm", "vlm"], text: "Image patches and instruction words become one token sequence for the backbone: PaLI-X in RT-2, Llama 2 in OpenVLA, PaliGemma in π0." },
        { on: ["web", "web>vlm", "vlm"], text: "The backbone learned objects and words from web data. RT-2 keeps training on web data alongside robot data so this knowledge survives." },
        { on: ["vlm>head", "head"], text: "Actions leave either as tokens the backbone decodes itself (RT-2, OpenVLA) or from an expert reading its features (π0, GR00T N1)." },
        { on: ["head>robot", "robot"], text: "The robot receives one step (RT-2, OpenVLA) or a chunk of actions (50 in π0, 16 in GR00T N1)." },
        { on: ["robot>cam", "cam"], text: "A new image closes the loop. The backbone's speed sets the rate: 1–3 Hz for RT-2-55B, chunks for up to 50 Hz control in π0." }
      ]
    },
    worked: {
      title: "Why action tokens got replaced",
      ref: "OpenVLA, arXiv 2406.09246 · FAST, π0", prov: "Our toy numbers for the bin range",
      eq: { tex: "\\class{sym-btok}{b_d} = \\Big\\lfloor 256\\, \\frac{\\class{sym-a}{a_d} - q_1}{q_{99} - q_1} \\Big\\rfloor", words: "Place the action value inside the 1st-to-99th percentile range and cut that range into 256 equal bins; the bin index is the token.", key: ["btok", "a", { glyph: "q₁, q₉₉", meaning: "1st and 99th action percentiles" }, { glyph: "⌊·⌋", meaning: "round down" }] },
      figure: WE_FIG,
      steps: [
        { title: "Set the bins", text: "Say Δx ranges from q₁ = −40 mm to q₉₉ = +40 mm. 256 bins give a width of 80 / 256 = 0.3125 mm." },
        { title: "Encode one value", text: "Δx = 12.3 mm gives (12.3 + 40) / 0.3125 = 167.36, so the token is b = 167." },
        { title: "Decode it back", text: "The bin center is −40 + 167.5 × 0.3125 = 12.34 mm. The error, 0.04 mm, never exceeds half a bin: 0.16 mm." },
        { title: "One step, seven passes", text: "A 7-D action is 7 tokens. RT-2 and OpenVLA decode them one after another, and OpenVLA runs at about 6 Hz." },
        { title: "The rate problem", text: "A 14-D bimanual arm at 50 Hz needs 14 × 50 = 700 tokens per second, the count FAST reports for naive binning." },
        { title: "π0's answer", text: "π0 skips tokens: one VLM pass, then 10 action-expert passes produce 50 continuous actions in 73 ms." }
      ]
    },
    ruleTitle: "Four training objectives, in order of appearance",
    rules: [
      { name: "RT-2 and OpenVLA: actions as next tokens", ref: "OpenVLA, arXiv 2406.09246", term: "action-token",
        tex: "\\class{sym-L}{\\mathcal{L}} = -\\sum_{d=1}^{D} \\log \\class{sym-pi}{\\pi_\\theta}\\big(\\class{sym-btok}{b_d} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}, \\class{sym-btok}{b_{\\lt d}}\\big)",
        words: "Cross-entropy on the action tokens only: predict each dimension's bin given the image, the instruction and the earlier dimensions.",
        key: ["L", "pi", "btok", "o", "l", { glyph: "D", meaning: "action dimensions (7 in OpenVLA)" }] },
      { name: "π0: flow matching in an action expert", ref: "X2 eq. 52 · arXiv 2410.24164", term: "action-expert",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{\\class{sym-tau}{\\tau}, \\class{sym-eps}{\\epsilon}} \\big\\| \\class{sym-v}{v_\\theta}\\big(\\class{sym-tau}{\\tau}\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} + (1-\\class{sym-tau}{\\tau})\\class{sym-eps}{\\epsilon},\\ \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}, \\class{sym-tau}{\\tau}\\big) - (\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} - \\class{sym-eps}{\\epsilon}) \\big\\|^2",
        words: "The expert regresses the velocity from noise to the demonstrated 50-action chunk. In π0 this loss also updates the VLM.",
        key: ["L", "E", "tau", "eps", "v", "achunk", "o", "l"] },
      { name: "Knowledge insulation: add tokens, stop the gradient", ref: "arXiv 2505.23705 · P02 §V", term: "knowledge-insulation",
        before: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}} \\big\\| \\class{sym-v}{v_\\theta}(\\cdot,\\ \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}, \\class{sym-tau}{\\tau}) - (\\class{sym-achunk}{\\mathbf{a}} - \\class{sym-eps}{\\epsilon}) \\big\\|^2",
        tex: "\\begin{aligned}\\class{sym-L}{\\mathcal{L}} = {} & \\class{sb-new}{-\\sum_{j} \\log \\class{sym-pi}{\\pi_\\theta}\\big(\\class{sym-btok}{b_j} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}, \\class{sym-btok}{b_{\\lt j}}\\big)} \\\\ & + \\class{sb-new}{\\alpha}\\, \\class{sym-E}{\\mathbb{E}} \\big\\| \\class{sym-v}{v_\\theta}(\\cdot,\\ \\class{sb-chg}{\\mathrm{sg}[\\class{sym-o}{o_t}, \\class{sym-l}{\\ell}]}, \\class{sym-tau}{\\tau}) - (\\class{sym-achunk}{\\mathbf{a}} - \\class{sym-eps}{\\epsilon}) \\big\\|^2\\end{aligned}",
        words: "The backbone learns from discrete FAST tokens (and web data); the expert reads backbone features through a stop-gradient, so its errors cannot reshape them.",
        key: ["L", "pi", "btok", "o", "l", "E", "v", "tau", "achunk", "eps", { glyph: "α", meaning: "loss weight (1 in KI)" }, { glyph: "sg[·]", meaning: "stop-gradient on backbone features" }], diff: true, beforeLabel: "π0", afterLabel: "KI" },
      { name: "π0.5 and RT-H: subtask first, then actions", ref: "arXiv 2504.16054 · 2403.01823", term: "hierarchical-vla",
        tex: "\\class{sym-pi}{\\pi_\\theta}(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}}, \\class{sym-lhat}{\\hat{\\ell}} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}) = \\class{sym-pi}{\\pi_\\theta}(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\mid \\class{sym-o}{o_t}, \\class{sym-lhat}{\\hat{\\ell}})\\; \\class{sym-pi}{\\pi_\\theta}(\\class{sym-lhat}{\\hat{\\ell}} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})",
        words: "The same model first writes a subtask in words, then produces actions conditioned only on that subtask.",
        key: ["pi", "achunk", "lhat", "o", "l"] }
    ],
    algorithm: {
      title: "Autoregressive action decoding (RT-2, OpenVLA)", ref: "arXiv 2307.15818 · 2406.09246", prov: "Our notation",
      lines: [
        '<span class="kw">input</span> image <span data-sym="o">oₜ</span>, instruction <span data-sym="l">ℓ</span>, bins from the 1st–99th percentiles',
        '<span class="kw">for</span> d = 1 … D: <span class="cm">// D = 7 in OpenVLA</span>',
        '    <span data-sym="btok">b_d</span> ← most likely of the 256 action tokens under <span data-sym="pi">π_θ</span>(· | <span data-sym="o">oₜ</span>, <span data-sym="l">ℓ</span>, <span data-sym="btok">b₍&lt;d₎</span>) <span class="cm">// decoding restricted to action tokens</span>',
        '    <span data-sym="a">a_d</span> ← center of bin <span data-sym="btok">b_d</span>',
        'send <span data-sym="a">aₜ</span> = (a₁ … a_D) to the controller <span class="cm">// one step, then a new image</span>',
        '<span class="kw">repeat</span> from the top <span class="cm">// D sequential passes of the full model per step</span>'
      ]
    },
    playgrounds: [
      {
        id: "build", title: "Architecture builder: backbone × action output", ref: "P02 §IV-A, Fig. 4", prov: "Simplified: pass counts only",
        try: "Start at Pretrained VLM + Tokens (RT-2) and raise Chunk H to 50. Then switch the output to Flow head and compare the big-model passes. Click the Transformer row to see RT-1, Octo and RDT-1B.",
        mount: mountBuilder,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b4-build";
          return [
            { target: q("#" + id + "-bb"), title: "Train from scratch", text: "Early generalists such as Gato and RT-1 trained a transformer on robot data and output discrete action tokens. That is cell (1).", do: function (a) { return a.click(q("#" + id + '-bb [value="tf"]')); }, task: "Choose the Transformer backbone", expect: function () { return api.state().bb === "tf"; } },
            { target: q("#" + id + "-bb"), title: "Swap in a VLM", text: "RT-2 replaced the transformer with a web-pretrained VLM and kept the tokens: cell (4), later reused by OpenVLA.", do: function (a) { return a.click(q("#" + id + '-bb [value="vlm"]')); }, task: "Choose Pretrained VLM", expect: function () { return api.state().bb === "vlm"; } },
            { target: q("#" + id + "-h"), title: "Ask for a chunk", text: "A 50-step chunk of 7-D actions means 350 tokens, each one more pass of the big model, one after another.", do: function (a) { return a.set(q("#" + id + "-h"), 50); }, task: "Set Chunk H to 50", expect: function () { return api.state().H >= 40; } },
            { target: q("#" + id + "-head"), title: "Move actions to an expert", text: "π0 runs the VLM once, then 10 passes of a small flow expert produce all 50 actions: cell (6).", do: function (a) { return a.click(q("#" + id + '-head [value="fh"]')); }, task: "Choose Flow head", expect: function () { return api.state().head === "fh"; } },
            { target: q("[data-grid]"), title: "The dual-system cell", text: "Cell (7) puts a diffusion transformer after the VLM, as GR00T N1 does with 4 flow steps per 16-action chunk.", do: function (a) { return a.click(q("#" + id + '-head [value="dit"]')); } },
            { target: q("#" + id + "-par"), title: "Your turn", text: "Choose Tokens and tick one-pass decoding, as RT-1 does. Then pick Transformer with DiT to see RDT-1B." }
          ];
        }
      },
      {
        id: "tune", title: "Four ways to fine-tune a VLA", ref: "P02 §V, §VIII · arXiv 2505.23705", prov: "Simplified: linear toy",
        try: "Start with Frozen, then Full and watch the dashed language error. Add co-training, raise the random head scale, and compare with Insulated.",
        mount: mountTune,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b4-tune";
          return [
            { target: q("[data-chart]"), title: "A frozen backbone", text: "Only the action head trains. Language stays perfect, but the action error stalls: the pretrained features miss what the robot needs." },
            { target: q("#" + id + "-mode"), title: "Let gradients in", text: "Full fine-tuning learns the action, but the random head's gradients reshape the backbone and language answers break.", do: function (a) { return a.click(q("#" + id + '-mode [value="full"]')); }, task: "Choose Full", expect: function () { return api.state().mode === "full"; } },
            { target: q("#" + id + "-mode"), title: "Keep web data", text: "Co-training on web data, as RT-2 does, pulls language back by the end of training.", do: function (a) { return a.click(q("#" + id + '-mode [value="cotrain"]')); }, task: "Choose Co-train", expect: function () { return api.state().mode === "cotrain"; } },
            { target: q("#" + id + "-sc"), title: "A louder random head", text: "A larger random head sends larger early gradients. Watch the worst language error grow.", do: function (a) { return a.set(q("#" + id + "-sc"), 2); }, task: "Set Random head scale to 2.0", expect: function () { return api.state().scale >= 1.8; } },
            { target: q("#" + id + "-mode"), title: "Insulate the backbone", text: "With a stop-gradient the expert cannot touch the backbone; the worst language error no longer depends on the head.", do: function (a) { return a.click(q("#" + id + '-mode [value="ki"]')); }, task: "Choose Insulated", expect: function () { return api.state().mode === "ki"; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Move the head scale in Insulated mode and in co-train mode. Then compare with the OpenVLA bars: LoRA nearly matches full fine-tuning." }
          ];
        }
      }
    ],
    methods: ["rt-1", "rt-2", "open-x-embodiment-rt-x", "octo", "openvla", "rdt-1b", "pi0", "cogact", "pi0-5", "knowledge-insulation", "gr00t-n1", "smolvla", "pi0-7", "rt-h", "hi-robot", "gato", "vima"],
    open: [
      { title: "Memory and reasoning", text: "Long tasks need the robot to remember what it saw minutes ago and retrieve it; current VLAs mostly react to the present image.", refs: "P02 §IX-B" },
      { title: "Learning after deployment", text: "VLAs are frozen after offline training. Continual learning risks forgetting and untested updates on real robots.", refs: "P02 §IX-C" },
      { title: "Detecting and recovering from failure", text: "Most VLAs treat a failure as the end of an episode; detection and re-planning are only beginning.", refs: "P02 §IX-F" },
      { title: "Fair comparisons", text: "Few VLA studies run enough trials with confidence intervals to show which design is better.", refs: "P02 §IX-G" }
    ],
    takeaways: [
      "A VLA takes images and an instruction and directly outputs control commands; most reuse a web-pretrained VLM.",
      "RT-2 wrote actions as 256-bin tokens; OpenVLA opened that recipe at 7B. Decoding tokens one by one limits the control rate.",
      "π0 moved actions into a flow-matching expert that outputs 50-action chunks, and later VLAs kept a separate action module.",
      "Action-head gradients can erase web knowledge; co-training, freezing and knowledge insulation are the three defenses.",
      "Hierarchical VLAs (RT-H, π0.5, Hi Robot) predict a subtask in words before acting on it."
    ],
    quiz: [
      { q: "By P02's definition, which system is not a VLA?", options: ["RT-2 emitting action tokens", "π0 emitting action chunks", "A VLM that only picks a skill index", "Octo with a diffusion head"], correct: 2, why: "P02 Def. I.1 requires the model to generate control commands directly; choosing an index from pretrained skills is excluded." },
      { q: "An OpenVLA-style bin spans −40 to +40 mm with 256 bins. What token does Δx = 12.3 mm get?", options: ["123", "128", "167", "52"], correct: 2, why: "(12.3 + 40) / 0.3125 = 167.36, rounded down to 167." },
      { q: "What did π0 change about RT-2 and OpenVLA?", options: ["It replaced discrete tokens with a flow-matching action expert", "It removed the vision encoder", "It trained only on web data", "It used a smaller bin count"], correct: 0, why: "π0 adds a 300M expert trained by flow matching that outputs 50-step continuous chunks instead of autoregressive action tokens (arXiv 2410.24164)." },
      { q: "Why does knowledge insulation stop the expert's gradient at the backbone?", options: ["To save memory at inference", "Flow matching cannot be backpropagated", "The backbone is frozen anyway", "A random expert's gradients degrade the VLM's knowledge"], correct: 3, why: "KI found that π0's expert gradients degrade language following; the backbone is trained on FAST tokens instead (arXiv 2505.23705; P02 §V)." },
      { q: "In OpenVLA's fine-tuning study, how did LoRA compare with full fine-tuning?", options: ["LoRA failed completely", "Nearly equal: 68.2% against 69.7%", "LoRA was twice as good", "They were never compared"], correct: 1, why: "LoRA with rank 32 trained 1.4% of the parameters and reached 68.2% against 69.7% for full fine-tuning (arXiv 2406.09246)." }
    ],
    cards: [
      { front: "What makes a model a VLA in P02's definition?", back: "Images and language are required inputs, and it directly generates robot control commands, not a skill index.", ref: "P02 Def. I.1" },
      { front: "How does RT-2 output an action?", back: "Each dimension is binned into 256 values and emitted as tokens, 8 per step, by a 5B–55B VLM.", ref: "arXiv 2307.15818" },
      { front: "What did Open X-Embodiment show?", back: "Pooling 60 datasets from 22 robots let RT-1-X and RT-2-X transfer positively across embodiments.", ref: "arXiv 2310.08864" },
      { front: "What are π0's two sets of weights?", back: "A 3B PaliGemma VLM and a 300M action expert that interact only through attention and output 50-action chunks.", ref: "X2 §5.3" },
      { front: "What is the π0 attention mask?", back: "Three blocks: images and text, then state, then actions. Each block attends to itself and earlier blocks only.", ref: "X2 §5.3" },
      { front: "What does knowledge insulation change?", back: "It adds a FAST-token loss on the backbone and stops the expert's gradients from reaching it.", ref: "arXiv 2505.23705" },
      { front: "How is SmolVLA smaller than π0?", back: "It uses half of SmolVLM-2's layers, 64 visual tokens per frame and a 100M expert: 0.45B against 3.3B.", ref: "X2 §5.4" },
      { front: "What does GR00T N1's dual system run at?", back: "An Eagle-2 VLM at 10 Hz conditions a flow-matching diffusion transformer producing actions at 120 Hz.", ref: "arXiv 2503.14734" }
    ],
    terms: {
      "vision-language-action-model": { name: "vision-language-action model", aliases: ["VLA", "VLA model"], group: "vla", def: "A system that takes visual observations and natural-language instructions as required inputs and produces robot actions by directly generating control commands.", note: "A VLM that only selects an index from pretrained skills is not a VLA under this definition.", ref: "P02 Def. I.1", scene: "system", focus: ["camera-image", "instruction", "llm-backbone", "action-head"], look: "images and words in, actions out", uses: ["vision-language-model"] },
      "vision-language-model": { name: "vision-language model", aliases: ["VLM"], group: "vla", def: "A model built from a pretrained vision encoder and a pretrained language model, trained on image–text data to generate text about images.", note: "In a VLA it is the backbone; its web knowledge is what the robot borrows.", ref: "X2 §5.2.1", scene: "system", focus: ["vision-encoder", "llm-backbone", "data-web"], look: "the backbone fed by web data", uses: [] },
      "action-token": { name: "action token", aliases: ["discrete action token", "action tokenization"], group: "vla", sym: "b_d", symTex: "b_d", def: "A vocabulary entry standing for one bin of one action dimension, so the backbone can output actions as text; RT-2 and OpenVLA use 256 bins per dimension.", note: "Decoding them one by one is slow at high control rates; b3 covers FAST compression.", ref: "arXiv 2307.15818 · 2406.09246", scene: "system", focus: ["llm-backbone", "action-head"], look: "tokens leaving the backbone", uses: ["vision-language-action-model"] },
      "co-fine-tuning": { name: "co-fine-tuning", aliases: ["co-training", "web co-training"], group: "vla", def: "Fine-tuning a VLM on a mixture of robot trajectories and its original web vision-language tasks at the same time.", note: "RT-2 used about half robot data; OpenVLA fine-tuned on robot data only.", ref: "P02 §III · arXiv 2307.15818", scene: "system", focus: ["data-web", "data-robot", "policy-update"], look: "web and robot data mixed", uses: ["vision-language-model"] },
      "cross-embodiment-training": { name: "cross-embodiment training", aliases: ["multi-robot pretraining", "RT-X"], group: "vla", def: "Training one policy on data pooled from many robot types, such as the 22 embodiments of Open X-Embodiment, to get positive transfer.", note: "Action spaces differ; OXE aligned them only coarsely to a 7-DoF end-effector action.", ref: "arXiv 2310.08864", scene: "system", focus: ["data-robot", "robot"], look: "robot data from many arms", uses: [] },
      "action-expert": { name: "action expert", aliases: ["π0 action expert"], group: "vla", sym: "v_θ", symTex: "v_\\theta", def: "A smaller set of transformer weights, next to the VLM, that processes state and noisy action tokens and generates action chunks by flow matching.", note: "It shares attention layers with the VLM; it is not a separate network called afterwards.", ref: "X2 §5.3", scene: "system", focus: ["action-head", "noise", "action-chunk"], look: "the expert beside the backbone", uses: ["flow-matching", "action-chunk"] },
      "blockwise-causal-attention-mask": { name: "blockwise causal attention mask", aliases: ["π0 attention mask"], group: "vla", def: "An attention mask over three token blocks (images and text, state, actions): tokens attend freely within their block and to earlier blocks, never later ones.", note: "The VLM never sees action tokens, so its keys and values can be cached across denoising steps.", ref: "X2 §5.3", scene: "system", focus: ["llm-backbone", "action-head"], look: "attention between backbone and expert", uses: ["action-expert"] },
      "knowledge-insulation": { name: "knowledge insulation", aliases: ["gradient insulation", "KI"], group: "vla", def: "Preventing gradient flow from the action head into the vision-language backbone, which is trained on discrete action tokens instead.", note: "Freezing the backbone also insulates it, but KI reports frozen VLMs reach 0% on some tasks.", ref: "P02 §V · arXiv 2505.23705", scene: "system", focus: ["llm-backbone", "action-head", "policy-update"], look: "the blocked path from head to backbone", uses: ["action-expert"] },
      "low-rank-adaptation": { name: "low-rank adaptation", aliases: ["LoRA"], group: "vla", def: "Fine-tuning only small low-rank update matrices added to the frozen weights, cutting memory and compute.", note: "OpenVLA's LoRA trained 1.4% of parameters and nearly matched full fine-tuning.", ref: "P02 §V · arXiv 2406.09246", scene: "system", focus: ["llm-backbone", "policy-update"], look: "small updates inside the backbone", uses: [] },
      "dual-system-vla": { name: "dual-system VLA", aliases: ["System 1 / System 2", "fast and slow VLA"], group: "vla", def: "A VLA in which a VLM acts as a slow high-level System 2 and a diffusion or flow transformer acts as a fast low-level System 1.", note: "GR00T N1 runs its VLM at 10 Hz and its action module at 120 Hz.", ref: "P02 §IV-A(7)", scene: "system", focus: ["llm-backbone", "action-head", "controller"], look: "slow backbone, fast action module", uses: ["vision-language-model"] },
      "hierarchical-vla": { name: "hierarchical VLA", aliases: ["hierarchical policy"], group: "vla", sym: "ℓ̂", symTex: "\\hat{\\ell}", def: "A VLA that predicts an intermediate representation, such as a language motion or subtask, and then actions conditioned on it.", note: "In RT-H and π0.5 one model does both; Hi Robot uses two separate models.", ref: "P02 §III", scene: "system", focus: ["planner", "instruction", "action-head"], look: "a subtask between instruction and action", uses: ["vision-language-action-model"] },
      "language-motion": { name: "language motion", aliases: [], group: "vla", def: "A short phrase describing a low-level movement, such as \"move arm forward\", predicted by RT-H before the action.", note: "Humans can correct the robot by overriding the language motion instead of teleoperating.", ref: "arXiv 2403.01823 · P02 §III", scene: "system", focus: ["planner", "instruction"], look: "a phrase before the action", uses: ["hierarchical-vla"] }
    },
    symbols: [
      { id: "btok", tex: "b_d", glyph: "b_d", kind: "Signals", meaning: "action token: the bin index of action dimension d", short: "action token (bin index)", first: "b4", read: "b sub d", papers: "OpenVLA: token_d · RT-2: integer 0–255 · Gato: s_l" },
      { id: "lhat", tex: "\\hat{\\ell}", glyph: "ℓ̂", kind: "Signals", meaning: "predicted subtask or language motion in words", short: "predicted subtask", first: "b4", read: "ell hat", papers: "π0.5, Hi Robot: ℓ̂ · RT-H: z (language motion)" }
    ],
    ledger: [
      { where: "Topic 08 · RT-1 action space", source: "X2 §5.1 describes six 256-bin dimensions for a 6-DoF arm", page: "The site uses the RT-1 paper: 11 dimensions (7 arm, 3 base, 1 mode)", why: "The method paper is the primary source.", kind: "Sources disagree" },
      { where: "Topic 08 · Open X-Embodiment size", source: "X2 §5.1 says 1.4M trajectories; the OXE paper says 1M+; OpenVLA later cites 2M+", page: "The site quotes 60 datasets and 22 embodiments, which all agree", why: "The dataset grew between versions.", kind: "Sources disagree" },
      { where: "Topic 08 · π0 and KI losses", source: "X2 eq. 52 regresses ε − a; the π0 paper writes u = A − ε", page: "The site uses a − ε with τ = 1 clean, as in topic 06", why: "One flow-time convention for the whole site.", kind: "Our choice" },
      { where: "Topic 08 · KI loss", source: "The KI paper applies the stop-gradient to backbone keys and values inside attention", page: "The rule writes sg[oₜ, ℓ] on the expert's inputs", why: "Same effect, shorter to read.", kind: "Simplified" },
      { where: "Topic 08 · playground 1", source: "Real latency depends on model size, caching and hardware", page: "The builder counts sequential forward passes only", why: "Shows where repeated computation sits.", kind: "Simplified" },
      { where: "Topic 08 · playground 2", source: "KI trained as fast as π0-FAST; π0 needed 7.5× the steps", page: "In the linear toy the insulated expert learns more slowly", why: "The toy shows the language effect, not training speed.", kind: "Simplified" },
      { where: "Topic 08 · Octo as a VLA", source: "P02 §III calls Octo a VLA; its card notes it has no web-pretrained VLM", page: "The site follows P02 Def. I.1: images and language in, actions out", why: "One definition throughout.", kind: "Our choice" },
      { where: "Topic 08 · SmolVLA data", source: "X2 §5.4: 450+ community datasets, 20k+ trajectories; SmolVLA paper: under 30k episodes", page: "The site quotes neither count", why: "Both are approximate.", kind: "Sources disagree" }
    ]
  });
})();
