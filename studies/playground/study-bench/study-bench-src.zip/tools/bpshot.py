#!/usr/bin/env python3
"""Screenshot one spec's Blueprint (and System) view standalone. usage: python3 tools/bpshot.py FILE id[,id] OUTDIR [--view blueprint|system|both]"""
import asyncio, os, sys
from playwright.async_api import async_playwright
async def main(f, ids, out, view):
    os.makedirs(out, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": 1400, "height": 900})
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto("file://" + os.path.abspath(f) + "#overview"); await pg.wait_for_timeout(5000)
        for i in ids:
            for v in (["blueprint", "system"] if view == "both" else [view]):
                ok = await pg.evaluate("""([id, v]) => { const s = RB.arch.get(id); if (!s) return false; let h = document.getElementById('bpx'); if (!h) { h = document.createElement('div'); h.id = 'bpx'; h.className = 'rb-arch'; h.style.cssText = 'position:absolute;left:0;top:0;z-index:9999;background:var(--surface);padding:16px;width:max-content;max-width:none'; document.body.appendChild(h); }
                  h.innerHTML = v === 'system' ? RB.arch.systemAuto(s, { uid: 'x' + id.replace(/\\W/g, '') }) : RB.arch.blueprint(s, { uid: 'y' + id.replace(/\\W/g, '') }); return true; }""", [i, v])
                if not ok: print("no spec", i); continue
                await pg.wait_for_timeout(200)
                await pg.locator("#bpx").screenshot(path=os.path.join(out, f"{i}-{v}.png"))
        await b.close()
v = "both"
if "--view" in sys.argv: v = sys.argv[sys.argv.index("--view") + 1]
asyncio.run(main(sys.argv[1], sys.argv[2].split(","), sys.argv[3], v))
