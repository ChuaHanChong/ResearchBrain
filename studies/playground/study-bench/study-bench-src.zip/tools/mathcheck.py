#!/usr/bin/env python3
"""Math rendering check.
usage: python3 tools/mathcheck.py FILE [--shots DIR] [--routes a,b]
Visits every page, tab, topic and lab station, waits for MathJax, then reports in the visible view:
  merror    MathJax errors (bad TeX), with the source
  raw       TeX left as text: \\( \\) \\[ \\] $…$ \\cmd, or a_b / a^b written as plain text outside code
  pending   .rb-math spans never typeset
  svgraw    raw _ or ^ left in SVG text (diagrams, where MathJax cannot go)
  overflow  typeset math wider than its box with no scroll wrapper
  tiny      typeset inline math much smaller than the surrounding text
  dup       the same formula typeset twice side by side
  clipped   math wider than its scroll box (the reader has to scroll sideways to see it all)
With --shots: a screenshot crop of the first few equations per route."""
import argparse, asyncio, json, os, re
from playwright.async_api import async_playwright

SCAN = r"""(root) => {
  const v = document.querySelector(root); if (!v) return {missing: true};
  let mj0; const out = {merror: [], raw: [], pending: 0, svgraw: [], overflow: [], tiny: [], clipped: [], dup: [], n: 0};
  mj0 = [...v.querySelectorAll('mjx-container')]; mj0.forEach(c => { const n = c.nextSibling; if (n && n.nodeName === 'MJX-CONTAINER' && n.textContent === c.textContent) out.dup.push((c.closest('li,p,td,div') || c).textContent.slice(0, 60)); });
  const vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden'; };
  v.querySelectorAll('mjx-merror, [data-mjx-error]').forEach(e => { const c = e.closest('mjx-container'); out.merror.push((e.getAttribute('data-mjx-error') || e.textContent || '').slice(0, 80) + ' :: ' + ((c && c.getAttribute('aria-label')) || '')); });
  const mj = [...v.querySelectorAll('mjx-container')].filter(vis); out.n = mj.length;
  out.pending = [...v.querySelectorAll('.rb-math:not(.is-typeset)')].filter(e => vis(e) && !e.querySelector('mjx-container')).length;
  const SKIP = 'script,style,code,pre,textarea,input,select,option,mjx-container,title,kbd,samp,[data-no-textpass]';
  const RAW = /\\\(|\\\)|\\\[|\\\]|\\(frac|mathbf|mathcal|sum|log|theta|pi|epsilon|alpha|beta|lambda|tau|mid|left|right|cdot|hat|tilde|text|operatorname|nabla|partial|in)\b|\$[^$\s][^$]{0,40}\$|(^|[\sα-ωΑ-Ω(,=])[A-Za-zα-ωΑ-Ω](\^|_)[A-Za-z0-9{α-ω]/;
  const w = document.createTreeWalker(v, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = w.nextNode())) {
    const p = node.parentElement; if (!p || p.closest(SKIP)) continue;
    const t = node.nodeValue; if (!t || !/[\\$_^]/.test(t)) continue;
    const inSvg = p.closest('svg');
    if (inSvg) { if (/[A-Za-zα-ωΑ-Ω](\^|_)[A-Za-z0-9{α-ω]/.test(t) && !/[a-z]_[a-z]{3,}/.test(t)) out.svgraw.push(t.trim().slice(0, 60)); continue; }
    if (!vis(p)) continue;
    if (RAW.test(t) && !/[a-z]{2,}_[a-z]{2,}/.test(t)) out.raw.push(t.trim().slice(0, 80));
  }
  mj.forEach(c => {
    const box = c.parentElement; const cr = c.getBoundingClientRect();
    let anc = box, scroll = false; while (anc && anc !== v) { const s = getComputedStyle(anc); if (/(auto|scroll)/.test(s.overflowX)) { scroll = true; break; } anc = anc.parentElement; }
    const host = c.closest('p,li,td,th,div,figcaption,dd,span.sb-eq-math') || box; const hr = host.getBoundingClientRect();
    if (scroll && anc.scrollWidth > anc.clientWidth + 2) out.clipped.push(((c.querySelector('mjx-assistive-mml') ? '' : '') + (c.closest('[data-tex]') ? c.closest('[data-tex]').getAttribute('data-tex') : (c.getAttribute('aria-label')||'')) ).slice(0, 70) + ' +' + (anc.scrollWidth - anc.clientWidth) + 'px');
    if (!scroll && cr.right > hr.right + 2 && cr.width > 40) out.overflow.push((c.getAttribute('aria-label') || '').slice(0, 60) + ' (' + Math.round(cr.right - hr.right) + 'px)');
    if (!c.hasAttribute('display')) { const fs = parseFloat(getComputedStyle(box).fontSize); if (cr.height && cr.height < fs * 0.7) out.tiny.push((c.getAttribute('aria-label') || '').slice(0, 40) + ' h' + Math.round(cr.height) + '/fs' + fs); }
  });
  out.nclipped = out.clipped.length; ['merror', 'raw', 'svgraw', 'overflow', 'tiny', 'clipped', 'dup'].forEach(k => out[k] = [...new Set(out[k])].slice(0, 12));
  return out;
}"""

async def settle(pg):
    await pg.wait_for_timeout(700)
    await pg.evaluate("() => (window.MathJax && MathJax.startup && MathJax.startup.promise) ? MathJax.startup.promise.then(() => (MathJax.typesetPromise ? MathJax.typesetPromise([]) : 0)).catch(() => 0) : 0")
    await pg.wait_for_timeout(500)

async def main(a):
    url = "file://" + os.path.abspath(a.file)
    rep = {}; errors = []
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await (await b.new_context(viewport={"width": a.width, "height": 1000})).new_page()
        pg.on("pageerror", lambda e: errors.append(str(e)[:200]))
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(url + "#overview"); await pg.wait_for_timeout(5000)
        ok = await pg.evaluate("!!(window.MathJax && MathJax.typesetPromise)")
        if not ok: print(json.dumps({"fatal": "MathJax did not load"})); return
        topics = await pg.evaluate("Object.keys(RB.topics)")
        stations = await pg.evaluate("(RB.LAB_ORDER || Object.keys(RB.stations || {}))")
        routes = ["overview", "tldr"] + ["explorer/" + t for t in topics] + \
                 ["evolution/lineage", "evolution/story", "evolution/equations", "compare/sbs", "compare/table", "compare/decide"] + \
                 ["lab/" + s for s in stations] + \
                 ["reference/formulas", "reference/cards", "reference/differences", "reference/datasets", "reference/papers",
                  "glossary/visual", "glossary/map", "glossary/az", "notation"]
        if a.routes: routes = [r for r in routes if r in a.routes.split(",")]
        for r in routes:
            await pg.evaluate(f"location.hash = '#{r}'"); await settle(pg)
            page = r.split("/")[0]
            # long pages lazy-render: scroll through
            h = await pg.evaluate("document.body.scrollHeight")
            for y in range(0, min(h, 60000), 1500):
                await pg.evaluate(f"window.scrollTo(0,{y})"); await pg.wait_for_timeout(60)
            await settle(pg)
            res = await pg.evaluate(SCAN, f"#view-{page}")
            rep[r] = res
            if a.shots and res.get("n"):
                os.makedirs(a.shots, exist_ok=True)
                loc = pg.locator(f"#view-{page} mjx-container:visible")
                cnt = min(await loc.count(), 3)
                for i in range(cnt):
                    el = loc.nth(i)
                    try:
                        await el.scroll_into_view_if_needed(timeout=2000)
                        par = el.locator("xpath=ancestor::*[self::p or self::li or self::figure or self::div][1]")
                        await par.screenshot(path=os.path.join(a.shots, r.replace("/", "_") + f"_{i}.png"), timeout=3000)
                    except Exception:
                        pass
        await b.close()
    bad = {k: {kk: vv for kk, vv in v.items() if vv and kk not in ("n",)} for k, v in rep.items()}
    bad = {k: v for k, v in bad.items() if v}
    print(json.dumps({"routes": len(rep), "equations": sum(v.get("n", 0) for v in rep.values()), "bad": bad, "errors": list(dict.fromkeys(errors))[:10]}, indent=1, ensure_ascii=False))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--shots"); ap.add_argument("--routes"); ap.add_argument("--width", type=int, default=1280)
    asyncio.run(main(ap.parse_args()))
