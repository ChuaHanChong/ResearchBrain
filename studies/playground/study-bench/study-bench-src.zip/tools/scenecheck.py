#!/usr/bin/env python3
"""Playground scenes (design system v2.11): every canvas in the Topic Explorer playgrounds and the Lab stations at 1280px is
at most 520px tall and has no empty horizontal band over 15% of its height.
usage: python3 tools/scenecheck.py FILE"""
import asyncio, json, os, sys
from playwright.async_api import async_playwright
JS = r"""() => [...document.querySelectorAll('canvas')].filter(c => { const r = c.getBoundingClientRect(); return r.width > 100 && r.height > 60 && !c.closest('[hidden]'); }).map(c => {
  const r = c.getBoundingClientRect(), x = c.getContext('2d'); let band = 0, best = 0;
  try { const W = c.width, H = c.height, d = x.getImageData(0, 0, W, H).data, bg = [d[0], d[1], d[2]];
    for (let y = 0; y < H; y++) { let empty = true; for (let i = 0; i < W; i += 2) { const k = (y * W + i) * 4; if (Math.abs(d[k] - bg[0]) + Math.abs(d[k + 1] - bg[1]) + Math.abs(d[k + 2] - bg[2]) > 24 && d[k + 3] > 20) { empty = false; break; } } band = empty ? band + 1 : 0; best = Math.max(best, band); }
    return {id: c.id || (c.closest('[id]') || {}).id, h: Math.round(r.height), band: +(best / H).toFixed(2)};
  } catch (e) { return {id: c.id, h: Math.round(r.height), band: null}; } })"""
async def main(f):
    out = []
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await (await b.new_context(viewport={"width": 1280, "height": 900})).new_page()
        await pg.goto("file://" + os.path.abspath(f) + "#overview"); await pg.wait_for_timeout(4000)
        topics = await pg.evaluate("Object.keys(RB.topics)"); stations = await pg.evaluate("(RB.LAB_ORDER || Object.keys(RB.stations || {}))")
        for r in ["explorer/" + t for t in topics] + ["lab/" + s for s in stations]:
            await pg.evaluate(f"location.hash='#{r}'"); await pg.wait_for_timeout(1500)
            h = await pg.evaluate("document.body.scrollHeight")
            for y in range(0, h, 1400): await pg.evaluate(f"window.scrollTo(0,{y})"); await pg.wait_for_timeout(40)
            await pg.wait_for_timeout(600)
            for c in await pg.evaluate(JS):
                if c["h"] > 523 or (c["band"] or 0) > 0.15: out.append(dict(route=r, **c))
        await b.close()
    print(json.dumps({"problems": out}, indent=1))
asyncio.run(main(sys.argv[1]))
