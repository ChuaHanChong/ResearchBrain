#!/usr/bin/env python3
"""Size balance between visualizations and written content.
usage: python3 tools/sizecheck.py FILE [--width 1280] [--routes a,b] [--detail]
For every visible SVG figure on every page it measures the rendered size and the size its text actually appears at
(font-size × the SVG's scale), and compares that with the body text around it. Reports per component kind:
  text   median / smallest label size in px, vs body text
  box    rendered width (share of the content column) and height (share of the viewport)
Flags: labels below 11px (desktop) / 10px (phone), median label above 1.25× body, figure taller than 0.9 viewport,
figure narrower than 45% of its column while its labels are shrunk below 0.8× body."""
import argparse, asyncio, json, os, statistics
from playwright.async_api import async_playwright

MEASURE = r"""(root) => {
  const v = document.querySelector(root); if (!v) return [];
  const body = parseFloat(getComputedStyle(v.querySelector('p') || v).fontSize) || 16;
  const vh = innerHeight, out = [];
  const kindOf = s => {
    const c = s.getAttribute('class') || '', f = s.closest('figure'), fc = f ? (f.getAttribute('class') || '') : '';
    if (s.closest('mjx-container')) return null;
    if (/rb-bp/.test(c) || s.querySelector('.rb-bp-tower')) return 'arch-blueprint';
    if (s.querySelector('.rb-arch-link, .rb-am-sub') || /rb-arch/.test(c)) return 'arch-system';
    if (/sb-anim/.test(fc)) return s.closest('#view-tldr') ? 'tldr-scene' : 'animated-guide';
    if (s.closest('.sb-lab, [id^=lab-], #view-lab')) return 'lab-station';
    if (s.closest('#view-evolution')) return 'lineage';
    if (s.closest('.sb-viz, figure')) return 'figure:' + ((fc.split(' ').find(x => /^(sb|rb)-/.test(x))) || 'plain');
    return null;
  };
  v.querySelectorAll('svg').forEach(s => {
    const r = s.getBoundingClientRect(); if (r.width < 120 || r.height < 60) return;
    if (s.parentElement && s.parentElement.closest('svg')) return;
    const kind = kindOf(s); if (!kind) return;
    const col = (s.closest('section, article, .sb-sec, main') || v).getBoundingClientRect().width || r.width;
    const sizes = [];
    s.querySelectorAll('text').forEach(t => {
      if (!t.textContent.trim()) return;
      const m = t.getScreenCTM(); if (!m) return;
      const fs = parseFloat(getComputedStyle(t).fontSize); if (!fs) return;
      sizes.push(fs * Math.sqrt(Math.abs(m.a * m.d - m.b * m.c)));
    });
    if (!sizes.length) return;
    sizes.sort((a, b) => a - b);
    const id = (s.closest('[id]') || {}).id || '';
    /* body text = the font size carrying the most prose in the figure's own section */
    const sec = s.closest('section, .sb-sec, article') || v, tally = {};
    sec.querySelectorAll('p, li').forEach(q => { if (q.closest('svg, figure figcaption, .sb-anim-beats') || !q.getBoundingClientRect().width) return; const f = parseFloat(getComputedStyle(q).fontSize); tally[f] = (tally[f] || 0) + q.textContent.length; });
    const fb = Object.keys(tally).sort((a, b) => tally[b] - tally[a])[0]; const bodyHere = fb ? +fb : body;
    out.push({kind, id, w: Math.round(r.width), h: Math.round(r.height), col: Math.round(col), vh, body: bodyHere,
      med: +sizes[Math.floor(sizes.length / 2)].toFixed(1), min: +sizes[0].toFixed(1), n: sizes.length});
  });
  return out;
}"""

async def main(a):
    url = "file://" + os.path.abspath(a.file)
    rows = []
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await (await b.new_context(viewport={"width": a.width, "height": 900})).new_page()
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(url + "#overview"); await pg.wait_for_timeout(5000)
        topics = await pg.evaluate("Object.keys(RB.topics)")
        stations = await pg.evaluate("(RB.LAB_ORDER || Object.keys(RB.stations || {}))")
        routes = ["overview", "tldr"] + ["explorer/" + t for t in topics] + ["evolution/lineage", "evolution/story", "compare/sbs"] + ["lab/" + s for s in stations] + ["glossary/visual"]
        if a.routes: routes = [r for r in routes if r in a.routes.split(",")]
        for r in routes:
            await pg.evaluate(f"location.hash = '#{r}'"); await pg.wait_for_timeout(1200)
            h = await pg.evaluate("document.body.scrollHeight")
            for y in range(0, min(h, 60000), 1500):
                await pg.evaluate(f"window.scrollTo(0,{y})"); await pg.wait_for_timeout(50)
            await pg.wait_for_timeout(400)
            for x in await pg.evaluate(MEASURE, f"#view-{r.split('/')[0]}"):
                x["route"] = r; rows.append(x)
        await b.close()
    lo = 11 if a.width >= 800 else 10
    flags = []
    for x in rows:
        f = []
        if x["min"] < lo: f.append(f"label {x['min']}px")
        if x["med"] > 1.25 * x["body"]: f.append(f"labels {x['med']}px > body {x['body']}")
        if x["h"] > 0.9 * x["vh"]: f.append(f"tall {x['h']}px")
        if x["w"] < 0.45 * x["col"] and x["med"] < 0.8 * x["body"]: f.append(f"narrow {x['w']}/{x['col']} with small labels")
        if f: flags.append({"route": x["route"], "kind": x["kind"], "id": x["id"], "issues": f})
    kinds = {}
    for x in rows: kinds.setdefault(x["kind"], []).append(x)
    summ = {k: {"n": len(v), "label_med": round(statistics.median(i["med"] for i in v), 1), "label_min": round(min(i["min"] for i in v), 1),
                "width_share": round(statistics.median(i["w"] / i["col"] for i in v), 2), "height_vh": round(statistics.median(i["h"] / i["vh"] for i in v), 2),
                "flagged": sum(1 for fl in flags if fl["kind"] == k)} for k, v in sorted(kinds.items())}
    out = {"width": a.width, "body_px": rows[0]["body"] if rows else None, "kinds": summ, "flags": len(flags)}
    if a.detail: out["detail"] = flags
    print(json.dumps(out, indent=1, ensure_ascii=False))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--width", type=int, default=1280); ap.add_argument("--routes"); ap.add_argument("--detail", action="store_true")
    asyncio.run(main(ap.parse_args()))
