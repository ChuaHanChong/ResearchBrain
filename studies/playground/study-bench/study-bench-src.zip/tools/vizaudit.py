#!/usr/bin/env python3
"""Visual weight audit (design system v2.11, guide "Visual learning principles" § Visual weight).
usage: python3 tools/vizaudit.py FILE [--width 1280] [--topics a1,b2] [--detail] [--pages]
Per Topic Explorer topic, measured at 1280px in reading order:
  words      visible prose words (p, li, dd, blockquote, figcaption; text inside closed "More detail" is not visible)
  ratio      picture area / prose area   (rule: >= 0.8)
  run        longest run of prose words with no picture between them (rule: <= 200). Equation blocks are not pictures.
  runs       every run over 200 words, with the section it sits in and its first words
  tiny       SVG text under 11px after scaling (rule: none)
  tall       hero-sized pictures taller than 60% of the viewport
--pages also measures Overview, TL;DR, Evolution, Compare, Lab stations and Glossary (ratio and runs, no rule on ratio)."""
import argparse, asyncio, json, os
from playwright.async_api import async_playwright

AUDIT = r"""(sel) => {
  const root = document.querySelector(sel); if (!root) return null;
  const vis = e => { const r = e.getBoundingClientRect(); if (!r.width || !r.height) return false; for (let x = e; x && x !== document.body; x = x.parentElement) { if (x.hidden) return false; const s = getComputedStyle(x); if (s.display === 'none' || s.visibility === 'hidden') return false; if (x.tagName === 'DETAILS' && !x.open && e !== x && !(e.closest('summary'))) return false; } return true; };
  const isPic = e => {
    if (e.closest('mjx-container, .sb-btn, button, .sb-chip, .sb-tag, .sb-concept-art svg svg')) return false;
    if (e.tagName === 'svg' && e.parentElement && e.parentElement.closest('svg')) return false;
    const r = e.getBoundingClientRect(); return r.width >= 120 && r.height >= 60;
  };
  const PROSE = 'p, li, dd, blockquote, figcaption, .sb-callout, .rb-tl-say';
  const SKIP = '.sb-algo, .sb-key, .sb-legend, .rb-film-thumbs, nav, .sb-toc, .sb-mobile-toc, .sb-vg-list, .sb-topiclinks, .sb-tabs, .sb-seg, button, .sb-eyebrow, .sb-ref, .sb-prov, table, .sb-anim-beats, svg, .sb-eq-key, .sb-eqkey, .sb-pager, .rb-open-card .sb-ref';
  const items = [];
  root.querySelectorAll('svg, canvas, img, ' + PROSE).forEach(e => {
    if (!vis(e)) return;
    if (e.matches('svg, canvas, img')) { if (isPic(e)) { const r = e.getBoundingClientRect(); items.push({k: 'pic', y: r.top + scrollY, x: r.left, a: r.width * r.height, h: r.height, w: r.width, el: e}); } return; }
    if (e.closest(SKIP)) return;
    if (e.parentElement && e.parentElement.closest(PROSE)) return;   /* count the outermost prose block once */
    const clone = e.cloneNode(true); clone.querySelectorAll('mjx-container, svg, details:not([open]) > :not(summary)').forEach(x => x.remove());
    const words = (clone.textContent || '').trim().split(/\s+/).filter(w => /[A-Za-z0-9]/.test(w)).length; if (!words) return;
    const r = e.getBoundingClientRect(); items.push({k: 'txt', y: r.top + scrollY, x: r.left, a: r.width * r.height, words, el: e});
  });
  items.sort((a, b) => a.y - b.y || a.x - b.x);
  let run = 0, runStart = null, longest = 0; const runs = [];
  const close = () => { if (run > 200 && runStart) { const s = runStart.el.closest('section[id], [id]'); runs.push({words: run, at: s ? s.id : '', start: runStart.el.textContent.trim().slice(0, 50)}); } longest = Math.max(longest, run); run = 0; runStart = null; };
  let pic = 0, txt = 0, words = 0, tall = [];
  items.forEach(i => { if (i.k === 'pic') { pic += i.a; if (i.h > 0.6 * innerHeight && i.w > 400) tall.push(((i.el.closest('[id]') || {}).id || '') + ' ' + Math.round(i.h) + 'px'); close(); } else { txt += i.a; words += i.words; if (!runStart) runStart = i; run += i.words; } });
  close();
  /* SVG type below 11px after scaling */
  const tiny = new Set();
  root.querySelectorAll('svg text').forEach(t => { if (!vis(t) || t.closest('mjx-container') || !t.textContent.trim()) return; const m = t.getScreenCTM(); if (!m) return; const fs = parseFloat(getComputedStyle(t).fontSize) * Math.sqrt(Math.abs(m.a * m.d - m.b * m.c)); if (fs < 10.95) tiny.add(((t.closest('[id]') || {}).id || '?') + ':' + (t.getAttribute('class') || t.parentElement.getAttribute('class') || 'text').split(' ')[0] + '@' + fs.toFixed(1)); });
  return {words, ratio: txt ? +(pic / txt).toFixed(2) : null, run: longest, runs, tiny: [...tiny].slice(0, 20), ntiny: tiny.size, tall};
}"""

async def main(a):
    url = "file://" + os.path.abspath(a.file)
    out = {}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await (await b.new_context(viewport={"width": a.width, "height": 900})).new_page()
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(url + "#overview"); await pg.wait_for_timeout(5000)
        topics = await pg.evaluate("Object.keys(RB.topics)")
        if a.topics: topics = [t for t in topics if t in a.topics.split(",")]
        routes = [("explorer/" + t, f"#view-explorer article[data-topic='{t}']") for t in topics]
        if a.pages:
            stations = await pg.evaluate("(RB.LAB_ORDER || Object.keys(RB.stations || {}))")
            routes += [("overview", "#view-overview"), ("tldr", "#view-tldr"), ("evolution/lineage", "#view-evolution"), ("evolution/story", "#view-evolution"), ("compare/sbs", "#view-compare"), ("glossary/visual", "#view-glossary")] + [("lab/" + s, "#view-lab") for s in stations]
        for r, sel in routes:
            await pg.evaluate(f"location.hash = '#{r}'"); await pg.wait_for_timeout(1200)
            h = await pg.evaluate("document.body.scrollHeight")
            for y in range(0, min(h, 80000), 1400):
                await pg.evaluate(f"window.scrollTo(0,{y})"); await pg.wait_for_timeout(40)
            await pg.wait_for_timeout(500)
            out[r] = await pg.evaluate(AUDIT, sel)
        await b.close()
    ex = {k: v for k, v in out.items() if k.startswith("explorer/") and v}
    summ = {"topics": len(ex),
            "ratio_avg": round(sum(v["ratio"] or 0 for v in ex.values()) / max(1, len(ex)), 2),
            "ratio_min": min((v["ratio"] or 0) for v in ex.values()) if ex else None,
            "below_0.8": [k.split("/")[1] for k, v in ex.items() if (v["ratio"] or 0) < 0.8],
            "longest_run": max((v["run"] for v in ex.values()), default=0),
            "runs_over_200": sum(len(v["runs"]) for v in ex.values()),
            "words": sum(v["words"] for v in ex.values()),
            "tiny_svg_text": sum(v["ntiny"] for v in ex.values())}
    rows = {k: {"words": v["words"], "ratio": v["ratio"], "run": v["run"], "runs": len(v["runs"]), "tiny": v["ntiny"], "tall": len(v["tall"])} for k, v in out.items() if v}
    res = {"summary": summ, "rows": rows}
    if a.detail: res["detail"] = {k: {"runs": v["runs"], "tiny": v["tiny"], "tall": v["tall"]} for k, v in out.items() if v and (v["runs"] or v["tiny"] or v["tall"])}
    print(json.dumps(res, indent=1, ensure_ascii=False))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--width", type=int, default=1280); ap.add_argument("--topics"); ap.add_argument("--detail", action="store_true"); ap.add_argument("--pages", action="store_true")
    asyncio.run(main(ap.parse_args()))
