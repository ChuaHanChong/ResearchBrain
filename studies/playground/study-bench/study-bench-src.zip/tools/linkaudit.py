#!/usr/bin/env python3
"""Audit connector lines in every architecture diagram (System and Blueprint views): long links, detours
(path length vs straight distance), and links that pass through a module box or tower they do not connect.
usage: python3 tools/linkaudit.py FILE [--ids a,b] [--maxlen 240] [--ratio 1.6]"""
import argparse, asyncio, json, os
from playwright.async_api import async_playwright
JS = r"""(args) => {
  const [ids, maxlen, ratio] = args;
  const host = document.createElement('div'); host.style.cssText = 'position:absolute;left:0;top:0;width:1400px;background:#fff'; host.className = 'sb-root'; document.body.appendChild(host);
  const out = {};
  const specs = RB.arch.all().filter(s => !ids || ids.includes(s.id));
  for (const s of specs) {
    const probs = [];
    for (const view of ['system', 'blueprint']) {
      let html = '';
      try { html = view === 'system' ? RB.arch.systemAuto(s, { uid: 'la' + s.id.replace(/\W/g, '') }) : (s.blueprint ? RB.arch.blueprint(s, { uid: 'lb' + s.id.replace(/\W/g, '') }) : ''); } catch (e) { probs.push(view + ': render error ' + e.message); continue; }
      if (!html) continue;
      host.innerHTML = html;
      const svg = host.querySelector('svg'); if (!svg) continue;
      const boxes = view === 'system' ? Array.from(svg.querySelectorAll('rect')).filter(r => (+r.getAttribute('width') > 60 && +r.getAttribute('height') > 30)).map(r => r.getBBox())
                                     : Array.from(svg.querySelectorAll('.rb-bp-tower rect')).map(r => r.getBBox()).filter(b => b.width >= 200 && b.height >= 60);
      const links = view === 'system' ? Array.from(svg.querySelectorAll('.rb-arch-link line, .rb-arch-link path')) : Array.from(svg.querySelectorAll('path.rb-bp-xl, path.rb-bp-sh'));
      links.forEach((p, i) => {
        let L, a, b;
        if (p.tagName === 'line') { a = [+p.getAttribute('x1'), +p.getAttribute('y1')]; b = [+p.getAttribute('x2'), +p.getAttribute('y2')]; L = Math.hypot(b[0] - a[0], b[1] - a[1]); }
        else { L = p.getTotalLength(); const p0 = p.getPointAtLength(0), p1 = p.getPointAtLength(L); a = [p0.x, p0.y]; b = [p1.x, p1.y]; }
        const D = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
        const lab = (p.closest('g') && p.closest('g').querySelector('title') ? p.closest('g').querySelector('title').textContent : (p.nextElementSibling && p.nextElementSibling.tagName === 'text' ? p.nextElementSibling.textContent : '')).slice(0, 40);
        if (L > maxlen) probs.push(view + ': long link ' + Math.round(L) + 'px "' + lab + '"');
        if (L / D > ratio && L > 80) probs.push(view + ': detour x' + (L / D).toFixed(1) + ' (' + Math.round(L) + 'px) "' + lab + '"');
        /* passes through a box that neither end touches */
        const n = Math.max(8, Math.round(L / 6)); let hit = 0;
        const inside = (bx, x, y, m) => x > bx.x + m && x < bx.x + bx.width - m && y > bx.y + m && y < bx.y + bx.height - m;
        boxes.forEach(bx => {
          if (inside(bx, a[0], a[1], -6) || inside(bx, b[0], b[1], -6)) return;
          for (let k = 1; k < n; k++) { const t = k / n, pt = p.tagName === 'line' ? [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t] : (q => [q.x, q.y])(p.getPointAtLength(L * t)); if (inside(bx, pt[0], pt[1], 2)) { hit++; break; } }
        });
        if (hit) probs.push(view + ': link crosses ' + hit + ' box(es) "' + lab + '"');
      });
    }
    if (probs.length) out[s.id] = Array.from(new Set(probs));
  }
  host.remove();
  return out;
}"""
async def main(a):
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": 1400, "height": 900})
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto("file://" + os.path.abspath(a.file) + "#overview"); await pg.wait_for_timeout(5000)
        r = await pg.evaluate(JS, [a.ids.split(",") if a.ids else None, a.maxlen, a.ratio])
        print(json.dumps({"n": len(r), "specs": r}, indent=1, ensure_ascii=False))
        await b.close()
ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--ids"); ap.add_argument("--maxlen", type=float, default=240); ap.add_argument("--ratio", type=float, default=1.6)
asyncio.run(main(ap.parse_args()))
