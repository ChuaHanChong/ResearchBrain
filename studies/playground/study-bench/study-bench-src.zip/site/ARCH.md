# Architecture diagrams: the contract

Every model on this site gets its architecture drawn **from one data spec by one renderer**. That keeps all diagrams consistent. You write data only; never edit `core/`, `src/`, `topics/`, `stations/` or another agent's file.

Before you start, read these three reference specs. They set the quality bar:

- `data/arch/b4-vla.js` (π0): VLM + action expert, shared attention, block mask.
- `data/arch/b2-heads.js` (Diffusion Policy): conv U-Net with FiLM.
- `data/arch/c2-wam.js` (UWM): joint DiT with AdaLN, a frozen VAE and a "What changed" diff.

The renderers are `core/35-arch.js` (System view, Modules view, summary, diff) and `core/36-blueprint.js` (Blueprint). Read them to see what each field does.

## Three views, one spec

1. **Blueprint** (default; Sebastian Raschka style). The whole model, layer by layer.
   - Each network is a grey **tower**, with its input at the bottom.
   - The repeated block is drawn once inside a coloured frame marked **N ×**, with residual lines and ⊕ nodes.
   - Side inputs sit on the left (RoPE, FiLM, AdaLN, cond).
   - Dotted **callouts** on the right carry the key numbers.
   - Numbered **zoom-ins** below show feed-forward, attention heads, FiLM, AdaLN, MoE, or any small stack.
2. **System** (OpenWAM style). Modules are coloured by role. Input tokens sit below each module and outputs above it. The link between modules names the coupling. An optional attention-visibility mask and the "At a glance" table sit beside it.
3. **Modules**. One module's layer stack (`module.stack.rows`) plus its facts table (`module.stack.facts`), every number with a source.

There is also **What changed**: when `parent` names another spec, this view shows both models, a `changes` list and the marked `diffRows`.

## File and registration

Write `data/arch/<your-file>.js` (the name is given in your assignment) as an IIFE calling `RB.arch.spec({...})` once per model. `id` is the spec id, normally equal to `method`, which is the exact id in `data/methods.json`.

```js
(function () {
  var RB = window.RB;
  RB.arch.spec({ id: "openvla", method: "openvla", name: "OpenVLA", year: 2024, parent: "rt-2",
    figRef: "Kim et al. Fig. 2 · §3", prov: "", lede: "≤ 40 words: what the model is, in one breath.",
    sources: { p1: { kind: "paper", ref: "Kim et al. 2024, §3.1", url: "https://arxiv.org/abs/2406.09246" },
               c1: { kind: "code", repo: "openvla/openvla", path: "prismatic/models/…", commit: "abc1234", url: "https://github.com/openvla/openvla/blob/abc1234/prismatic/models/…" } },
    summary: { pattern: ["Autoregressive token VLA", "p1"], params: ["7.5B", "p1"], … },
    changes: ["≤ 25 words each, 3–6 items, what changed from the parent"], diffRows: ["backbone", "head", "output"],
    modules: [ … ], inputs: [ … ], outputs: [ … ], links: [ … ], mask: { … }, callouts: [ … ],
    blueprint: { headline, note, towers: [ … ], links: [ … ], shared: [ … ] } });
})();
```

## Integrity rules (the lint enforces the first two)

- **Every number carries a source.** A sourced value is written `["value text", "p1", "c2"]` (the text, then source keys).
  - This applies to summary values, `call` callouts and facts.
  - An unsourced string that contains a digit triggers the warning `unsourced number`, and the check fails.
- **Source keys exist.** Sources have two shapes:
  - `p#` papers: `{kind:"paper", ref:"Author year, §/Table/Fig", url:"https://arxiv.org/abs/…"}`.
  - `c#` code: `{kind:"code", repo:"org/repo", path:"file", commit:"short hash", url:"…/blob/<hash>/<path>"}`.
- **Never guess.** Leave out a value you cannot verify (the page shows *not stated*). For closed models, write `"not disclosed"` without a source.
  - Arithmetic from verified numbers is fine: head dim = width / heads, 224/14 = 16 → 256 patches. Cite the sources of the inputs.
  - Do not estimate parameter counts of sub-modules unless the paper or code states them.
- **Read the paper and the code.**
  - Paper: alphaXiv `answer_pdf_queries` (architecture figure, method section, appendix hyperparameter tables). Batch all questions for one paper into one call.
  - Code: `git clone --depth 1 https://github.com/<org>/<repo>.git` into your scratchpad (the proxy allows GitHub), or alphaXiv `read_files_from_github_repository`. Read the config and model files. Record `git rev-parse --short HEAD`.
  - If there is no official code, say so in your summary and use the paper only.
- **Paper vs code disagreements.** Add a callout to the spec (`callouts`), e.g. "Paper App. B lists 18 heads; the released config uses 8". Also list each disagreement in your final answer so the integrator can add it to the site's "where the papers disagree" table.
- **Notation.**
  - Use Unicode, not LaTeX or underscores: `qₜ`, `Aτ`, `vθ`, `εₐ`, `hₒ`, `tₒ′`, `Aᵏ`, `d → 3,072`.
  - Write numbers with thousands separators (`16,384`).
  - Flow time follows the site's house convention: τ = 0 is noise, τ = 1 is clean.

## Which models

Draw **every model with a learned network** in your assignment, including planners built around a model (PaLM-E, CLIPort, RoboPoint), learned verifiers and RL policies with a stated network.

Skip:

- datasets and benchmarks;
- pure algorithms with no distinctive network (PPO, RLPD, DAgger, domain randomization, RTC, GAT, SINDy);
- attack papers with no model of their own. Draw an attack as an **overlay** on its target model instead: a `callouts` line plus a blueprint row with `note`/`call` marking the injection point (e.g. "FlowHijack: trigger in the flow-matching head"). Put it in a spec for the target, with `topic` set to your topic id and `id` like `flowhijack-on-pi0`.

List every skipped id with a reason in your final answer.

If the paper and code give **no layer-level detail** (closed models), still draw the blueprint at the level disclosed: towers with a few rows whose labels say what is known. Put "not disclosed" callouts on the rest.

## System view fields

- **`modules`**: `[{ id, role, name (≤ 18 chars per line, 2 lines max), sub (≤ 26 chars, sizes like "18 × 2048 · MQA"), col (0, 1, 2 …, left to right), frozen (true | false | "lora" | "partial"), params (only if stated, with a source in summary), short, main (true on the central network), stack }]`
  - At most **4 modules**; 3 is ideal.
  - Order the columns along the data flow.
- **Roles**:
  - `vision-enc`, `vlm`, `lang`
  - `action-head`, `action-expert`
  - `video-gen`, `world`, `joint` (video + action in one network)
  - `state-enc`, `touch-enc`, `fusion`, `latent`, `codec` (tokenizer / VAE), `critic`, `planner`
  - `net` (anything else)
- **`inputs`**: `[{ to: moduleId, mod, label (short), n (count text), k (1–6 squares drawn), noisy: true if it is being denoised }]`. At most 3 per module.
  - `outputs` has the same fields, with `from` instead of `to`.
  - Modalities are `vision`, `lang`, `action`, `future`, `state`, `touch`, `latent`, `time`, `other`.
- **`links`**: `[{ from, to, kind, label ("line 1|line 2"), note }]`, **only between adjacent columns**.
  - Kinds are `prefix` (tokens join the sequence), `joint-attn`, `cross-attn`, `film`, `adaln`, `latent`, `two-stage` and `feeds`.
- **`mask`** (optional, transformers only): `{ name, ref: "p1", axes: [{label, short, mod}], m: ["100","110","111"], note }`. Row i attends to column j when the character is 1.
- **`summary`** keys: `pattern`, `params`, `vision`, `backbone`, `head`, `output`, `attention`, `cond`, `steps`, `chunk`, `rate`, `latency`, `train`.
  - Use the same wording style as the references.
  - `pattern` comes from this vocabulary (extend only if nothing fits):
    - Autoregressive token VLA
    - VLM + diffusion/flow action head
    - VLM + flow-matching action expert (two-expert transformer)
    - Dual-system VLA (slow VLM + fast policy)
    - Encoder–decoder transformer (CVAE)
    - 1-D temporal U-Net (FiLM)
    - Diffusion transformer policy
    - Cascaded WAM: video then inverse dynamics
    - Single-system joint DiT (video + action in one sequence)
    - Dual-system WAM: joint self-attention (MoT)
    - Dual-system WAM: cross-attention
    - Autoregressive unified video-action model
    - Latent-action pretraining
    - RSSM world model
    - Latent world model (JEPA / TD-MPC)
    - Video world foundation model
    - Visual representation encoder
    - Grasp CNN (per-pixel)
    - Point-cloud grasp network
    - Language-conditioned grasp model
    - Grasp VLA
    - Actor–critic
    - Teacher–student policy
    - Physics-structured network
    - Multimodal fusion policy (vision + touch/force)
    - Learned verifier / failure detector
    - Safety layer
    - LLM/VLM planner
- **`callouts`**: 1–3 sentences in HTML (bold allowed). Use them for disagreements and "OpenWAM calls this pattern …" notes.

## Blueprint fields (the part readers look at most)

```js
blueprint: {
  headline: "Model: the idea in ≤ 7 words",
  note: "≤ 60 words: how the towers connect and what repeats.",
  towers: [ { mod: "<module id>", title: "…", sub: "≤ 40 chars", compact: true /* small towers */,
              input: { label: "pill text", caption: "one line under it" },
              rows: [ … bottom → top … ],
              output: { label: "what leaves the top" } } ],
  links:  [ { from: "<tower mod>", to: "<tower mod>", toRow: "input" | "<row id>", label: "≤ 5 words" } ],
  shared: [ { a: ["<mod>", "<row id>"], b: ["<mod>", "<row id>"], label: "shared self-attention" } ]
}
```

**Row types** (bottom to top; `label` ≤ 27 characters per line, 2 lines max):

| Type | What it is |
|---|---|
| `embed`, `linear`, `conv`, `pool`, `mlp` | White pills |
| `norm` | Normalization pill |
| `attn` | Dark pill (like Raschka's attention box) |
| `ffn`, `moe` | Grey pills |
| `film`, `adaln` | Dashed accent pills (conditioning) |
| `add` | ⊕ with `span: n`, a residual line from below the n rows beneath it |
| `block` | `{ t:"block", n:"18", label?, rows:[…] }`, a coloured frame with the **N ×** brace |
| `group` | `{ t:"group", label, rows:[…] }`, a dashed frame, not repeated (e.g. "Down path, 3 levels") |

**Row fields:**

- `id`: needed as a link or shared target.
- `call: ["text ≤ 12 words with the numbers", "p1", "c1"]`. Callouts sit on the right; numbers are auto-highlighted. Use them for vocabulary, embedding dimension, heads, KV heads, hidden (FFN) dimension, context length, channels, experts.
- `callDy`: a vertical nudge if a line would cross the callout.
- `side: "RoPE" | "FiLM" | "AdaLN" | "cond" | "text"` (≤ 10 chars): a left input with an arrow into the row.
- `loop: true | "text"`: a recurrent arrow, e.g. RSSM "hₜ → hₜ₊₁".
- `note`: hover text.
- `zoom`: a numbered zoom-in below the towers. Options:

  | `k` | Fields |
  |---|---|
  | `glu` | `act`, `d`, `ff` (SwiGLU/GeGLU) |
  | `mlp` | `act`, `d`, `ff` |
  | `heads` | `q`, `kv`, `hd`: MHA / GQA / MQA picture |
  | `film` | — |
  | `adaln` | `d` |
  | `moe` | `experts`, `topk`, `caption` |
  | `rows` | `rows: ["bottom", …, "top"]`: any small sub-stack, e.g. a VQ codebook, a PointNet++ SA level, a GRU cell |

  Each zoom may have a `title`. Use zooms where they teach something (2–5 per model).

**Layout rules** (the renderer applies them; you choose the order):

- At most 3 towers (4 if some are `compact`), left to right in reading order.
- A tower that **feeds** another is placed to its **left** when possible. The renderer moves feeding towers up or down so every link is a short elbow; do not fight it.
- Use `shared` only for rows that truly share attention (MoT or two experts). The renderer levels those two rows.
- Pure pipelines of several models (e.g. LLM planner → detector → grasp net) are towers with 1–3 rows each, linked in order.

## Check loop (do not skip)

```
python3 tools/build.py --only <topic ids> --stations none --arch <your file stem>,b2-heads,b4-vla,c2-wam --out dist/a-<your file stem>.html
python3 tools/archcheck.py dist/a-<your file stem>.html --topic <topic id> --shots      # once per topic in your file
```

The check must report no page or console errors, no arch warnings, no overlaps, no box overflows, and no horizontal scroll at 1280 or 400 px.

**Then open and look at** `dist/shots/arch_<id>_bp.png`, `_sys.png` and `_phone.png` for every model. Fix anything that looks wrong: clipped text, crossed lines, a callout far from its row, an empty tower.

Iterate until every model is clean and correct.

## Your final answer

A short report containing:

- the file path;
- the spec ids drawn, with the paper and code (commit) behind each;
- the ids skipped, with reasons;
- every paper-vs-code disagreement found;
- any parent ids you used that live in another agent's file.
