/* Topic 18 · Humanoid whole-body manipulation. Sources: P09 §II-C/D, Table I, §VI (eq. 5–7, Fig. 9), §VII-B/C (Fig. 11, 12, Table V), §IX-A (Table VI); P01 §4.8, Table 7; method cards (topic E4). */
(function () {
  "use strict";
  var RB = window.RB;

  /* segmented controls: accept either a button or a value from StudyBench.segmented */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); if (el) StudyBench.segmented(el, function (b) { var v = (b && b.value !== undefined) ? b.value : b; cb(String(v)); }); return el; }
  function mono() { return getComputedStyle(document.body).getPropertyValue("--font-mono") || "monospace"; }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body") || "sans-serif"; }

  /* =====================================================================================
     Playground: whole-body control priority on a planar body.
     A 3-link planar humanoid (ankle, hip, shoulder) stands on one foot segment. Two tasks per step:
       balance: keep the horizontal center of mass (CoM) over the middle of the foot (1-D)
       hand:    move the hand to a target (2-D)
     Velocity-level (kinematic) resolution each control step, 200 steps:
       hierarchical = null-space cascade (an HQP without inequalities, P09 §VI-B/C)
       weighted     = one least-squares problem with task weights (a weighted QP without inequalities)
     Joint limits act as hard constraints in both: a joint that would pass its limit is locked and the step is re-solved.
     Static balance only: the CoM must project inside the foot. Our numbers throughout.
     ===================================================================================== */
  var LEN = [0.9, 0.6, 0.6], MASS = [25, 30, 5], SUP = [-0.07, 0.17], COM_T = 0.05, HAND_Y = 1.2;
  var LIM = [[-0.5, 0.5], [-0.4, 1.7], [-0.3, 2.8]], Q0 = [0, 0, 1.4], STEPS = 200, DQMAX = 0.08;

  function fk(q, mp) {
    var x = 0, y = 0, phi = 0, pts = [[0, 0]], mx = 0, m = 0;
    for (var i = 0; i < 3; i++) {
      phi += q[i];
      var nx = x + LEN[i] * Math.sin(phi), ny = y + LEN[i] * Math.cos(phi);
      mx += MASS[i] * (x + nx) / 2; m += MASS[i]; x = nx; y = ny; pts.push([x, y]);
    }
    mx += mp * x; m += mp;
    return { pts: pts, hand: [x, y], com: mx / m };
  }
  function jac(q, mp) {
    var f0 = fk(q, mp), h = 1e-6, Jc = [], Jh = [[], []];
    for (var i = 0; i < 3; i++) {
      var qq = q.slice(); qq[i] += h; var f = fk(qq, mp);
      Jc.push((f.com - f0.com) / h); Jh[0].push((f.hand[0] - f0.hand[0]) / h); Jh[1].push((f.hand[1] - f0.hand[1]) / h);
    }
    return { f: f0, Jc: [Jc], Jh: Jh };
  }
  function mm(A, B) { return A.map(function (r) { return B[0].map(function (_, j) { return r.reduce(function (s, v, k) { return s + v * B[k][j]; }, 0); }); }); }
  function tr(A) { return A[0].map(function (_, j) { return A.map(function (r) { return r[j]; }); }); }
  function inv(A) { if (A.length === 1) return [[1 / A[0][0]]]; var d = A[0][0] * A[1][1] - A[0][1] * A[1][0]; return [[A[1][1] / d, -A[0][1] / d], [-A[1][0] / d, A[0][0] / d]]; }
  function addDiag(A, d) { return A.map(function (row, i) { return row.map(function (v, j) { return v + (i === j ? d : 0); }); }); }
  function solve3(H, g) {
    var A = H.map(function (r, i) { return r.concat([g[i]]); });
    for (var c = 0; c < 3; c++) {
      var p = c; for (var r = c + 1; r < 3; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
      var t = A[c]; A[c] = A[p]; A[p] = t;
      for (var r2 = 0; r2 < 3; r2++) { if (r2 === c) continue; var f = A[r2][c] / A[c][c]; for (var k = c; k < 4; k++) A[r2][k] -= f * A[c][k]; }
    }
    return [A[0][3] / A[0][0], A[1][3] / A[1][1], A[2][3] / A[2][2]];
  }
  /* hierarchical: each level acts only in the null space of all levels above it */
  function cascade(tasks) {
    var dq = [[0], [0], [0]], N = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
    tasks.forEach(function (t) {
      var A = mm(t.J, N), r = t.e.map(function (v, i) { return [v - mm([t.J[i]], dq)[0][0]]; });
      var d = mm(mm(tr(A), inv(addDiag(mm(A, tr(A)), 1e-2))), r);
      var nd = Math.sqrt(d.reduce(function (a, v) { return a + v[0] * v[0]; }, 0));
      if (nd > DQMAX) d = d.map(function (v) { return [v[0] * DQMAX / nd]; });
      dq = dq.map(function (v, i) { return [v[0] + d[i][0]]; });
      var ApA = mm(mm(tr(A), inv(addDiag(mm(A, tr(A)), 1e-9))), A);
      N = N.map(function (row, i) { return row.map(function (v, j) { return v - ApA[i][j]; }); });
    });
    return dq.map(function (v) { return v[0]; });
  }
  /* weighted: one problem, sum of w_i ||J_i dq - e_i||^2 plus a small damping */
  function weighted(tasks) {
    var H = [[1e-3, 0, 0], [0, 1e-3, 0], [0, 0, 1e-3]], g = [0, 0, 0];
    tasks.forEach(function (t) {
      var JtJ = mm(tr(t.J), t.J), Jte = mm(tr(t.J), t.e.map(function (v) { return [v]; }));
      for (var i = 0; i < 3; i++) { g[i] += t.w * Jte[i][0]; for (var j = 0; j < 3; j++) H[i][j] += t.w * JtJ[i][j]; }
    });
    var dq = solve3(H, g), n = Math.sqrt(dq[0] * dq[0] + dq[1] * dq[1] + dq[2] * dq[2]);
    return n > DQMAX ? dq.map(function (v) { return v * DQMAX / n; }) : dq;
  }
  function simulate(cfg) {
    var q = Q0.slice(), path = [], solves = 0;
    for (var s = 0; s < STEPS; s++) {
      var j = jac(q, cfg.mp);
      path.push(j.f.hand);
      var tb = { J: j.Jc, e: [0.5 * (COM_T - j.f.com)], w: cfg.w }, th = { J: j.Jh, e: [0.5 * (cfg.reach - j.f.hand[0]), 0.5 * (HAND_Y - j.f.hand[1])], w: 1 };
      var mask = [1, 1, 1], dq = [0, 0, 0];
      for (var it = 0; it < 4; it++) {
        var mk = function (t) { return { J: t.J.map(function (r) { return r.map(function (v, k) { return v * mask[k]; }); }), e: t.e, w: t.w }; };
        var a = mk(tb), b = mk(th);
        if (cfg.mode === "hqp") { dq = cascade(cfg.order === "hand" ? [b, a] : [a, b]); solves += 2; }
        else { dq = weighted([a, b]); solves += 1; }
        var hit = false;
        for (var i = 0; i < 3; i++) if (mask[i] && (q[i] + dq[i] > LIM[i][1] || q[i] + dq[i] < LIM[i][0])) { mask[i] = 0; hit = true; }
        if (!hit) break;
      }
      for (var i2 = 0; i2 < 3; i2++) { if (!mask[i2]) dq[i2] = 0; q[i2] = RB.clamp(q[i2] + dq[i2], LIM[i2][0], LIM[i2][1]); }
    }
    var f = fk(q, cfg.mp);
    path.push(f.hand);
    return { q: q, f: f, path: path, err: Math.hypot(f.hand[0] - cfg.reach, f.hand[1] - HAND_Y), solves: solves / STEPS, inside: f.com >= SUP[0] && f.com <= SUP[1] };
  }

  function mountWBC(body, ctx) {
    var id = ctx.id;
    var fmtW = function (v) { var x = Math.pow(10, +v); return x >= 10 ? String(Math.round(x)) : x.toFixed(x < 1 ? 2 : 1); };
    body.innerHTML =
      '<div class="rb-row">' +
      RB.seg({ id: id + "-mode", label: "Solver", value: "hqp", options: [{ value: "hqp", label: "Hierarchical" }, { value: "wqp", label: "Weighted" }] }) +
      RB.seg({ id: id + "-order", label: "Priority order", value: "bal", options: [{ value: "bal", label: "Balance first" }, { value: "hand", label: "Hand first" }] }) + "</div>" +
      '<div class="rb-row">' +
      RB.slider({ id: id + "-reach", label: "Hand target reach (m)", min: 0.5, max: 1.4, step: 0.05, value: 0.8, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-w", label: "Balance weight w", min: -1, max: 3, step: 0.5, value: 0, fmt: fmtW }) +
      RB.slider({ id: id + "-box", label: "Box in hand (kg)", min: 0, max: 10, step: 1, value: 0 }) + "</div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="A planar humanoid on one foot reaching for a target ring; the center-of-mass line must land on the foot"></canvas>' +
      '<figcaption class="sb-caption">Green band = the foot. The dashed line drops from the center of mass (CoM); it must land in the band. Faint figure = start pose. Thin line = the hand\'s path to the ring.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "com", k: "CoM offset from foot center", u: "cm" }, { id: "bal", k: "Static balance" }, { id: "err", k: "Hand error", u: "cm" }, { id: "solves", k: "Solves per control step" }]) +
      '<p class="sb-caption" data-note></p>' +
      RB.legend([{ c: "good", label: "CoM over the foot", kind: "dot" }, { c: "bad", label: "CoM outside the foot", kind: "dot" }, { c: "accent", label: "hand target", kind: "dot" }, { c: "data-1", label: "hand path", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    var st = { mode: "hqp", order: "bal", reach: 0.8, wexp: 0, mp: 0 }, res = null, W = 520, H = 380;
    var wEl = body.querySelector("#" + id + "-w"), orderEl = body.querySelector("#" + id + "-order");
    function toPx(p) { return [160 + p[0] * 205, H - 30 - p[1] * 205]; }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mf = mono(), bf = bodyFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (var gx = 10; gx <= W; gx += 46) { c.beginPath(); c.moveTo(gx, 0); c.lineTo(gx, H); c.stroke(); }
      for (var gy = H - 30; gy >= 0; gy -= 46) { c.beginPath(); c.moveTo(0, gy); c.lineTo(W, gy); c.stroke(); }
      var g0 = toPx([-0.7, 0]), g1 = toPx([1.55, 0]);
      c.strokeStyle = P["line-strong"]; c.lineWidth = 2; c.beginPath(); c.moveTo(g0[0], g0[1]); c.lineTo(g1[0], g1[1]); c.stroke();
      var s0 = toPx([SUP[0], 0]), s1 = toPx([SUP[1], 0]);
      c.fillStyle = P["good-soft"]; c.fillRect(s0[0], s0[1] - 8, s1[0] - s0[0], 16);
      c.strokeStyle = P.good; c.lineWidth = 1.5; c.strokeRect(s0[0], s0[1] - 8, s1[0] - s0[0], 16);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mf; c.fillText("foot", s0[0] + 10, s0[1] + 24);
      /* start pose ghost */
      var ghost = fk(Q0, 0).pts;
      c.globalAlpha = 0.14; c.strokeStyle = P["ink-3"]; c.lineWidth = 8; c.lineCap = "round"; c.beginPath();
      ghost.forEach(function (p, i) { var z = toPx(p); if (i) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke(); c.globalAlpha = 1;
      /* target ring */
      var tg = toPx([st.reach, HAND_Y]);
      c.strokeStyle = P.accent; c.lineWidth = 2.5; c.beginPath(); c.arc(tg[0], tg[1], 11, 0, Math.PI * 2); c.stroke();
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + bf; c.fillText("target", Math.min(tg[0] + 15, W - 48), tg[1] - 12);
      if (!res) return;
      /* hand path */
      c.strokeStyle = P["data-1"]; c.lineWidth = 1.5; c.beginPath();
      res.path.forEach(function (p, i) { var z = toPx(p); if (i) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke();
      /* body */
      var pts = res.f.pts, col = res.inside ? P.good : P.bad;
      c.strokeStyle = P["robot-body"] || P["ink-2"]; c.lineWidth = 9; c.lineCap = "round"; c.lineJoin = "round"; c.beginPath();
      pts.forEach(function (p, i) { var z = toPx(p); if (i) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke();
      pts.forEach(function (p, i) { if (i === 3) return; var z = toPx(p); c.fillStyle = P.surface; c.strokeStyle = P.ink; c.lineWidth = 2; c.beginPath(); c.arc(z[0], z[1], 5, 0, Math.PI * 2); c.fill(); c.stroke(); });
      var hz = toPx(pts[3]);
      if (st.mp > 0) { var bs = 8 + st.mp * 1.4; c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.lineWidth = 1.5; c.fillRect(hz[0] - bs / 2, hz[1] - 2, bs, bs); c.strokeRect(hz[0] - bs / 2, hz[1] - 2, bs, bs); }
      c.fillStyle = P.accent; c.beginPath(); c.arc(hz[0], hz[1], 5, 0, Math.PI * 2); c.fill();
      /* center of mass */
      var cy = (pts[1][1] + pts[2][1]) / 2, cz = toPx([res.f.com, cy]), cg = toPx([res.f.com, 0]);
      c.strokeStyle = col; c.lineWidth = 1.5; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(cz[0], cz[1]); c.lineTo(cg[0], cg[1]); c.stroke(); c.setLineDash([]);
      c.fillStyle = P.surface; c.strokeStyle = col; c.lineWidth = 2.5; c.beginPath(); c.arc(cz[0], cz[1], 8, 0, Math.PI * 2); c.fill(); c.stroke();
      c.beginPath(); c.moveTo(cz[0] - 8, cz[1]); c.lineTo(cz[0] + 8, cz[1]); c.moveTo(cz[0], cz[1] - 8); c.lineTo(cz[0], cz[1] + 8); c.stroke();
      c.fillStyle = col; c.font = "600 12px " + bf; c.fillText("CoM", cz[0] + 12, cz[1] + 4);
    }
    function run() {
      var w = Math.pow(10, st.wexp);
      res = simulate({ mode: st.mode, order: st.order, reach: st.reach, w: w, mp: st.mp });
      RB.setRO(body, "com", RB.fmt((res.f.com - COM_T) * 100, 1));
      RB.setRO(body, "bal", res.inside ? "Holds" : "Tips over");
      RB.setRO(body, "err", RB.fmt(res.err * 100, 1));
      RB.setRO(body, "solves", RB.fmt(res.solves, 1));
      wEl.disabled = st.mode !== "wqp";
      Array.prototype.forEach.call(orderEl.querySelectorAll("button"), function (b) { b.disabled = st.mode !== "hqp"; });
      var t;
      if (st.mode === "hqp" && st.order === "bal") t = res.err < 0.01 ? "Both tasks fit: the hand reaches while the CoM stays centered." : "Balance is solved first; the hand moves only in its null space, so the hand stops short rather than tipping the body.";
      else if (st.mode === "hqp") t = "Hand first: the reach is met exactly and balance gets only what is left. A wrong order is a design error the solver cannot see.";
      else t = "One solve with soft weights (hand weight 1). " + (res.inside ? "Here balance holds, but only as a trade-off: the CoM still drifts." : "The hand pulls the CoM off the foot: low-priority tasks interfere with high-priority ones (P09 §VI-C).");
      note.textContent = t;
      draw();
    }
    bindSeg(body, id + "-mode", function (v) { st.mode = v; run(); });
    bindSeg(body, id + "-order", function (v) { st.order = v; run(); });
    RB.bindSlider(body, id + "-reach", function (v) { return (+v).toFixed(2); }, function (v) { st.reach = v; run(); });
    RB.bindSlider(body, id + "-w", fmtW, function (v) { st.wexp = v; run(); });
    RB.bindSlider(body, id + "-box", null, function (v) { st.mp = v; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { mode: st.mode, order: st.order, reach: st.reach, w: Math.pow(10, st.wexp), mp: st.mp, inside: res.inside, err: res.err }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token classes only) ---------- */
  var ART = {
    loco: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="6" y1="52" x2="194" y2="52" class="rb-s-line"/><circle cx="60" cy="10" r="5" class="rb-f-surface"/><path d="M60 15 V32 M60 32 L52 51 M60 32 L70 50 M60 20 L78 24" class="rb-s-ink"/><rect x="78" y="16" width="18" height="16" rx="2" class="rb-f-soft"/><path d="M104 30 H150" class="rb-s-acc"/><path d="M146 26 L152 30 L146 34" class="rb-s-acc"/><text x="120" y="22" class="rb-t-mono">walk + carry</text></svg>',
    wbm: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="6" y1="52" x2="194" y2="52" class="rb-s-line"/><circle cx="70" cy="9" r="5" class="rb-f-surface"/><path d="M70 14 V34 M70 34 L64 51 M70 34 L76 51 M70 20 Q96 16 100 26 M70 26 Q94 34 100 40" class="rb-s-ink"/><rect x="88" y="14" width="44" height="36" rx="3" class="rb-f-soft"/><circle cx="90" cy="25" r="3" class="rb-f-acc"/><circle cx="90" cy="39" r="3" class="rb-f-acc"/><circle cx="76" cy="30" r="3" class="rb-f-acc"/><text x="140" y="24" class="rb-t-mono">arms,</text><text x="140" y="38" class="rb-t-mono">chest</text></svg>',
    float: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="6" y1="52" x2="194" y2="52" class="rb-s-line"/><rect x="40" y="10" width="34" height="22" rx="3" class="rb-f-sunk"/><path d="M50 32 L44 51 M64 32 L70 51" class="rb-s-ink"/><path d="M74 21 H96 M57 10 V2" class="rb-s-acc"/><path d="M92 17 L97 21 L92 25" class="rb-s-acc"/><circle cx="44" cy="51" r="3" class="rb-f-acc"/><circle cx="70" cy="51" r="3" class="rb-f-acc"/><text x="106" y="24" class="rb-t-mono">no base motor</text><text x="106" y="44" class="rb-t-mono">feet push</text></svg>',
    task: '<svg viewBox="0 0 200 56" aria-hidden="true"><text x="8" y="32" class="rb-t-acc">eᵢ = Aᵢ</text><rect x="64" y="8" width="28" height="40" rx="3" class="rb-f-surface"/><text x="78" y="21" text-anchor="middle" class="rb-t-mono">q̈</text><text x="78" y="33" text-anchor="middle" class="rb-t-mono">λ</text><text x="78" y="45" text-anchor="middle" class="rb-t-mono">𝛕</text><text x="100" y="32" class="rb-t-acc">− bᵢ</text><text x="136" y="22" class="rb-t-mono">= 0, ≤ 0</text><text x="136" y="40" class="rb-t-mono">or ‖·‖²</text></svg>',
    prio: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="6" width="72" height="16" rx="2" class="rb-f-soft"/><text x="44" y="18" text-anchor="middle" class="rb-t-mono">balance</text><rect x="8" y="30" width="72" height="16" rx="2" class="rb-f-surface"/><text x="44" y="42" text-anchor="middle" class="rb-t-mono">hand</text><path d="M44 22 V30" class="rb-s-ink"/><line x1="100" y1="4" x2="100" y2="52" class="rb-s-line" stroke-dasharray="3 3"/><path d="M122 36 H188 M155 36 V14" class="rb-s-ink"/><rect x="116" y="38" width="20" height="10" rx="2" class="rb-f-soft"/><rect x="172" y="38" width="14" height="10" rx="2" class="rb-f-surface"/><text x="155" y="10" text-anchor="middle" class="rb-t-mono">weights</text></svg>',
    track: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="6" y1="52" x2="194" y2="52" class="rb-s-line"/><g opacity="0.45"><circle cx="50" cy="10" r="5" class="rb-f-surface"/><path d="M50 15 V32 M50 32 L44 51 M50 32 L57 51 M50 20 L32 12 M50 20 L68 12" class="rb-s-line"/></g><text x="30" y="8" class="rb-t-mono">ref</text><path d="M80 30 H104" class="rb-s-acc"/><path d="M100 26 L106 30 L100 34" class="rb-s-acc"/><circle cx="140" cy="10" r="5" class="rb-f-surface"/><path d="M140 15 V32 M140 32 L134 51 M140 32 L147 51 M140 20 L123 13 M140 20 L157 13" class="rb-s-ink"/><circle cx="140" cy="10" r="3" class="rb-f-acc"/><circle cx="123" cy="13" r="3" class="rb-f-acc"/><circle cx="157" cy="13" r="3" class="rb-f-acc"/><text x="164" y="34" class="rb-t-mono">3 pts</text></svg>',
    filter: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="8" y1="48" x2="192" y2="48" class="rb-s-line"/>' +
      [10, 22, 30, 26, 18, 12, 8, 6, 4, 3].map(function (h, i) { return '<rect x="' + (12 + i * 16) + '" y="' + (48 - h) + '" width="12" height="' + h + '" rx="1" class="' + (i < 5 ? "rb-f-soft" : "rb-f-sunk") + '"/>'; }).join("") +
      '<line x1="92" y1="4" x2="92" y2="50" class="rb-s-acc"/><text x="96" y="12" class="rb-t-acc">τ</text><text x="108" y="26" class="rb-t-mono">drop hard</text><text x="12" y="10" class="rb-t-mono">keep</text></svg>',
    shadow: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="12" width="30" height="22" rx="3" class="rb-f-sunk"/><circle cx="23" cy="23" r="6" class="rb-f-surface"/><text x="23" y="48" text-anchor="middle" class="rb-t-mono">RGB</text><path d="M42 23 H66" class="rb-s-ink"/><rect x="70" y="12" width="40" height="22" rx="3" class="rb-f-surface"/><text x="90" y="27" text-anchor="middle" class="rb-t-mono">HST</text><path d="M114 23 H134" class="rb-s-ink"/><rect x="138" y="12" width="52" height="22" rx="3" class="rb-f-soft"/><text x="164" y="27" text-anchor="middle" class="rb-t-mono">HIT</text><text x="90" y="48" text-anchor="middle" class="rb-t-mono">shadow</text><text x="164" y="48" text-anchor="middle" class="rb-t-mono">imitate</text></svg>'
  };

  /* ---------- worked example figure: joint-velocity plane (q̇1, q̇2); scale 800 px per unit, origin (140, 100) ---------- */
  function X(a) { return (140 + a * 800).toFixed(1); }
  function Y(b) { return (100 - b * 800).toFixed(1); }
  var WE_FIG = '<svg viewBox="0 0 560 230" role="img" aria-label="Plane of the two joint velocities: the balance line, the hand\'s wish at 0.20, 0.10, the hierarchical solution on the line and weighted solutions approaching it">' +
    '<line x1="30" y1="100" x2="340" y2="100" class="rb-s-line"/><line x1="140" y1="8" x2="140" y2="222" class="rb-s-line"/>' +
    '<text x="344" y="104" class="rb-t-mono">q̇₁</text><text x="146" y="16" class="rb-t-mono">q̇₂</text>' +
    '<g data-on="1+"><circle cx="' + X(0.2) + '" cy="' + Y(0.1) + '" r="6" class="rb-f-surface"/><text x="' + X(0.2) + '" y="' + (+Y(0.1) + 24) + '" text-anchor="middle" class="rb-t-ink">hand wants (0.20, 0.10)</text></g>' +
    '<g data-on="2+"><line x1="' + X(-0.1) + '" y1="' + Y(0.1) + '" x2="' + X(0.14) + '" y2="' + Y(-0.14) + '" class="rb-s-acc"/><text x="' + (+X(0.14) + 8) + '" y="' + (+Y(-0.14) + 4) + '" class="rb-t-acc">balance: q̇₁ + q̇₂ = 0</text></g>' +
    '<g data-on="3+"><line x1="' + X(0.2) + '" y1="' + Y(0.1) + '" x2="' + X(0.05) + '" y2="' + Y(-0.05) + '" class="rb-s-ink" stroke-dasharray="4 3"/><circle cx="' + X(0.05) + '" cy="' + Y(-0.05) + '" r="6" class="rb-f-acc"/>' +
    '<line x1="' + (+X(0.05) + 6) + '" y1="' + Y(-0.05) + '" x2="366" y2="150" class="rb-s-line"/><text x="370" y="154" class="rb-t-ink">hierarchy (0.05, −0.05)</text></g>' +
    '<g data-on="4+"><circle cx="' + X(0.1) + '" cy="' + Y(0) + '" r="5" class="rb-f-surface"/><line x1="' + (+X(0.1) + 5) + '" y1="' + (+Y(0) - 3) + '" x2="366" y2="80" class="rb-s-line"/><text x="370" y="84" class="rb-t-ink">weighted, w = 1: (0.10, 0.00)</text></g>' +
    '<g data-on="5"><circle cx="' + X(0.0571) + '" cy="' + Y(-0.0429) + '" r="4" class="rb-f-surface"/><circle cx="' + X(0.0507) + '" cy="' + Y(-0.0493) + '" r="3" class="rb-f-surface"/><line x1="' + (+X(0.0571) + 4) + '" y1="' + Y(-0.0429) + '" x2="366" y2="118" class="rb-s-line"/><text x="370" y="122" class="rb-t-mono">w = 10, 100: closer to the line</text></g>' +
    "</svg>";

  RB.topic({
    id: "e4",
    title: "Humanoid whole-body manipulation",
    eyebrow: "Part E · Humanoids",
    lede: "A humanoid manipulates while it balances. See how a whole-body controller ranks competing tasks, and how learned trackers turn human motion into robot motion.",
    refs: ["P09 §II, §VI", "P09 §VII-B–C", "P01 §4.8"],
    why: "A humanoid stands on a floating base that only its contacts can push, so every arm motion shifts the load its feet must carry. Model-based stacks plan with model predictive control and resolve competing tasks in a whole-body quadratic program. Learned stacks train one tracking policy in simulation and feed it human motion from teleoperation or motion capture.",
    outcomes: [
      "Distinguish whole-body manipulation from loco-manipulation using P09 Table I.",
      "Explain why a floating base needs contact forces to balance and manipulate.",
      "Compute hierarchical and weighted solutions for two conflicting tasks by hand.",
      "Predict when a weighted QP lets a reaching task break balance.",
      "Trace how H2O, OmniH2O, ExBody2 and HumanPlus changed the learned tracker."
    ],
    concepts: [
      { name: "Loco-manipulation", def: "Moving objects while the robot itself moves: walking with a box, pushing a cart, opening a door.", ref: "P09 §II-D, Table I", art: ART.loco, term: "loco-manipulation" },
      { name: "Whole-body manipulation", def: "Manipulating with any body surface, such as elbows, chest or palms, not only the fingertips.", ref: "P09 §II-C, Fig. 3", art: ART.wbm, term: "whole-body-manipulation", href: "#lab/compliance" },
      { name: "Floating base", def: "The torso has no motor to the world; balance and motion need contact forces from feet or hands.", ref: "P09 §VI, eq. 5–6", art: ART.float, term: "floating-base", sym: "Sact" },
      { name: "Dynamic task", def: "A linear expression in accelerations, contact forces and torques: an equality, an inequality or a cost.", ref: "P09 eq. 7", art: ART.task, term: "dynamic-task", sym: "wbc-e" },
      { name: "Task priority", def: "Conflicting tasks are ranked strictly (hierarchical QP) or traded off with weights (weighted QP).", ref: "P09 §VI-C, Fig. 9", art: ART.prio, term: "hierarchical-qp", sym: "wbc-w" },
      { name: "Motion tracker", def: "An RL policy tracking human-derived goals. H2O used 8 keypoints; OmniH2O's distilled student tracks head and hands.", ref: "arXiv 2403.04436", art: ART.track, term: "motion-tracking-policy" },
      { name: "Sim-to-data filtering", def: "Drop retargeted clips a simulated tracker cannot follow. H2O kept about 8.5k of 10k clips.", ref: "arXiv 2403.04436", art: ART.filter, term: "sim-to-data-filtering" },
      { name: "Shadow, then imitate", def: "HumanPlus teleoperates with one RGB camera through a tracker, then trains an imitation policy on those demonstrations.", ref: "arXiv 2406.10454", art: ART.shadow, term: "humanoid-shadowing" }
    ],
    flow: {
      title: "Where the whole-body stack acts", ref: "P09 Fig. 2, Fig. 11 · P01 §4.8", w: 880, h: 300,
      caption: "Two sources feed the same low-level tracker: a human through retargeting during data collection, and a learned policy at deployment. The tracker keeps the balance either way.",
      nodes: [
        { id: "human", x: 20, y: 30, w: 160, h: 56, label: "Human operator", sub: "VR, RGB pose, mocap", kind: "env" },
        { id: "ret", x: 230, y: 30, w: 170, h: 56, label: "Retargeting", sub: "human → robot joints", kind: "store" },
        { id: "hi", x: 230, y: 200, w: 170, h: 56, label: "Learned policy", sub: "imitation or VLA", kind: "agent" },
        { id: "trk", x: 440, y: 110, w: 170, h: 60, label: "Whole-body tracker", sub: "RL policy or MPC + WBC", kind: "decision" },
        { id: "robot", x: 700, y: 110, w: 170, h: 60, label: "Humanoid", sub: "PD loop, 200 Hz–1 kHz", kind: "env" }
      ],
      edges: [
        { from: "human", to: "ret", label: "poses" },
        { from: "ret", to: "trk", label: "kinematic goals", sides: ["r", "t"], via: [[525, 58]] },
        { from: "trk", to: "robot", label: "joint targets", dy: -8 },
        { from: "robot", to: "hi", label: "logged demos", sides: ["b", "b"], via: [[785, 282], [315, 282]], dashed: true, dy: -6 },
        { from: "hi", to: "trk", label: "goals", sides: ["r", "b"], via: [[525, 228]] }
      ],
      steps: [
        { on: ["human", "human>ret", "ret"], text: "An operator's motion from a VR headset, an RGB pose estimator or a mocap suit is retargeted to robot joint and keypoint targets (P09 Fig. 11)." },
        { on: ["ret>trk", "trk"], text: "A whole-body tracker turns goals into joint targets: an RL policy at 50 Hz in H2O and ExBody2, or MPC feeding a whole-body QP." },
        { on: ["trk>robot", "robot"], text: "PD loops turn joint targets into torques, at 200 Hz in H2O and 1 kHz in HumanPlus. The tracker keeps the balance while the arms work." },
        { on: ["robot>hi", "hi"], text: "Teleoperated episodes are logged. HumanPlus trains its imitation transformer on 25–40 demonstrations per task; OmniH2O trains a Diffusion Policy." },
        { on: ["hi", "hi>trk", "trk"], text: "At deployment the learned policy replaces the operator: HumanPlus sends 50-step chunks of target poses at 25 Hz to the 50 Hz tracker." }
      ]
    },
    worked: {
      title: "Two tasks, one pair of joint velocities",
      ref: "P09 §VI-B–C", prov: "Our toy numbers",
      eq: { tex: "\\min_{\\dot q}\\ \\class{sym-wbc-w}{w}\\,\\big\\|\\class{sym-Jac}{J_b}\\,\\class{sym-qj}{\\dot q}\\big\\|^2 + \\big\\|\\class{sym-Jac}{J_h}\\,\\class{sym-qj}{\\dot q} - \\dot x_h\\big\\|^2", words: "The weighted form: pay w for every unit of CoM motion and 1 for every unit of hand error.", key: ["wbc-w", "Jac", "qj", { glyph: "ẋ_h", meaning: "velocity the hand task wants" }] },
      figure: WE_FIG,
      steps: [
        { title: "The two tasks", text: "Balance wants the CoM still: q̇₁ + q̇₂ = 0. The hand wants q̇ = (0.20, 0.10). Both cannot hold at once." },
        { title: "Level 1: balance only", text: "Every q̇ = s·(1, −1) keeps the CoM still. That line is the balance task's null space; the hand may only move along it." },
        { title: "Level 2: hand on the line", text: "The closest point to (0.20, 0.10) is s = 0.05: q̇ = (0.05, −0.05). CoM shift 0, hand error 0.21." },
        { title: "Weighted, w = 1", text: "Setting the gradient to zero gives q̇ = (0.10, 0.00). Hand error drops to 0.14, but the CoM shifts 0.10." },
        { title: "Raise the weight", text: "w = 10 gives a CoM shift of 0.014; w = 100 gives 0.0015. The weighted answer approaches the hierarchy but never reaches it." }
      ]
    },
    ruleTitle: "Whole-body control as one linear problem, then two ways to rank tasks",
    rules: [
      { name: "Floating-base dynamics", ref: "P09 eq. 5–6", term: "floating-base",
        tex: "\\class{sym-M}{M(q)}\\,\\class{sym-qj}{\\ddot q} - \\class{sym-Jac}{J}^{\\top}\\class{sym-lambda}{\\lambda} - \\class{sym-Sact}{S}^{\\top}\\class{sym-torque}{\\boldsymbol{\\tau}} = -\\class{sym-C}{C(q,\\dot q)}\\,\\class{sym-qj}{\\dot q} - \\class{sym-G}{G(q)}, \\qquad \\class{sym-Jac}{J_c}\\,\\class{sym-qj}{\\ddot q} + \\dot{\\class{sym-Jac}{J}}_c\\,\\class{sym-qj}{\\dot q} = 0",
        words: "Motors act only through S; the six base coordinates move only through contact forces λ. Contacts that hold do not accelerate.",
        key: ["M", "qj", "Jac", "lambda", "Sact", "torque", "C", "G", { glyph: "J_c", meaning: "Jacobian of holding contacts" }] },
      { name: "A dynamic task", ref: "P09 eq. 7", term: "dynamic-task",
        tex: "\\class{sym-wbc-e}{e_i} = \\class{sym-wbc-A}{A_i}(q, \\dot q, t)\\,\\class{sym-wbc-X}{X} - \\class{sym-wbc-b}{b_i}(q, \\dot q, t), \\qquad \\class{sym-wbc-X}{X} = [\\,\\class{sym-qj}{\\ddot q},\\ \\class{sym-lambda}{\\lambda},\\ \\class{sym-torque}{\\boldsymbol{\\tau}}\\,]",
        words: "Joint accelerations, hand accelerations, momentum rates and contact forces are all linear in X, so each task is one row block.",
        key: ["wbc-e", "wbc-A", "wbc-X", "wbc-b", "qj", "lambda", "torque"] },
      { name: "Weighted QP", ref: "P09 §VI-C", term: "weighted-qp",
        tex: "\\min_{\\class{sym-wbc-X}{X}}\\ \\sum_i \\class{sym-wbc-w}{w_i}\\,\\big\\|\\class{sym-wbc-e}{e_i}(\\class{sym-wbc-X}{X})\\big\\|^2 \\quad \\text{s.t. eq. 5, eq. 6},\\ \\class{sym-lambda}{\\lambda} \\in \\text{friction cone}",
        words: "One solve per step; weights express priority. Fast, but a low-priority task can pull against a high-priority one.",
        key: ["wbc-X", "wbc-w", "wbc-e", "lambda"] },
      { name: "Hierarchical QP", ref: "P09 §VI-C", term: "hierarchical-qp",
        before: "\\min_{\\class{sym-wbc-X}{X}}\\ \\sum_i \\class{sym-wbc-w}{w_i}\\,\\big\\|\\class{sym-wbc-e}{e_i}(\\class{sym-wbc-X}{X})\\big\\|^2",
        tex: "\\min_{\\class{sym-wbc-X}{X}}\\ \\big\\|\\class{sb-chg}{\\class{sym-wbc-e}{e_{k}}}(\\class{sym-wbc-X}{X})\\big\\|^2 \\quad \\class{sb-new}{\\text{s.t. } \\class{sym-wbc-e}{e_j}(\\class{sym-wbc-X}{X}) = \\class{sym-wbc-e}{e_j^{*}}\\ \\ \\forall j < k}",
        words: "Solve one QP per priority level k = 1 … K, keeping every higher level's optimum. Strict priorities, but K solves per step.",
        key: ["wbc-X", "wbc-e", "wbc-w", { glyph: "e_j*", meaning: "optimum already found at level j" }], diff: true, beforeLabel: "WQP", afterLabel: "HQP" },
      { name: "Learned tracker: distillation (OmniH2O)", ref: "arXiv 2406.08858", term: "motion-tracking-policy",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}\\Big\\|\\,\\class{sym-a}{\\hat a_t} - \\class{sym-pi}{\\pi_\\theta}\\big(\\class{sym-o}{o_{t-25:t}},\\ \\tilde p_t\\big)\\Big\\|^2",
        words: "A privileged teacher labels the states the student visits (DAgger). The student sees 25 steps of proprioception and head-and-hand goals.",
        key: ["L", "E", "a", "pi", "o", { glyph: "p̃ₜ", meaning: "head and hand target positions" }] }
    ],
    algorithm: {
      title: "One control step of a hierarchical QP", ref: "P09 §VI-C", prov: "Our summary",
      lines: [
        '<span class="kw">input</span> state <span data-sym="qj">q, q̇</span>, tasks sorted by priority, level 1 = dynamics and contacts',
        '<span class="cm">// eq. 5–6 and friction cones are the top level</span>',
        '<span class="kw">for</span> k = 1 … K:',
        '    solve min ‖<span data-sym="wbc-e">e_k</span>(<span data-sym="wbc-X">X</span>)‖² with <span data-sym="wbc-e">e_j</span>(<span data-sym="wbc-X">X</span>) fixed at their optima for all j &lt; k',
        '    <span class="kw">if</span> infeasible: skip level k and every lower level',
        '<span class="kw">send</span> joint torques <span data-sym="torque">𝛕</span> from <span data-sym="wbc-X">X</span> to the motors <span class="cm">// then repeat next step</span>'
      ]
    },
    playgrounds: [
      {
        id: "wbc", title: "Balance or reach: who wins the conflict?", ref: "P09 §VI-B–C, Fig. 9", prov: "Simplified: planar 3-link toy",
        try: "At reach 0.80 m both tasks fit. Drag the reach to 1.30 m: the hierarchy keeps the CoM centered and gives up on the hand. Then choose Weighted and raise the balance weight.",
        mount: mountWBC,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e4-wbc";
          return [
            { target: q("canvas"), title: "Both tasks fit", text: "The target is close. The hand reaches it while the dashed CoM line stays in the green foot band." },
            { target: q("#" + id + "-reach"), title: "Reach too far", text: "At 1.30 m no pose satisfies both tasks. Balance is solved first, so the hand stops short and the body stays up.", do: function (a) { return a.set(q("#" + id + "-reach"), 1.3); }, task: "Set the reach to 1.30 m or more", expect: function () { return api.state().reach >= 1.25; } },
            { target: q("#" + id + "-mode"), title: "Soft weights instead", text: "The weighted solver makes one solve per step. With equal weights the hand pulls the CoM off the foot.", do: function (a) { return a.click(q("#" + id + '-mode [value="wqp"]')); }, task: "Choose Weighted", expect: function () { return api.state().mode === "wqp"; } },
            { target: q("#" + id + "-w"), title: "Raise the balance weight", text: "At w = 1000 the CoM returns near the center. Balance now dominates, but it is still a trade-off, never a guarantee.", do: function (a) { return a.set(q("#" + id + "-w"), 3); }, task: "Set the balance weight to 100 or more", expect: function () { return api.state().w >= 99; } },
            { target: q("#" + id + "-box"), title: "Carry a box", text: "A box in the hand moves the CoM forward, so the balanced reach shrinks and the hand error grows.", do: function (a) { return a.set(q("#" + id + "-box"), 8); }, task: "Put a box of 5 kg or more in the hand", expect: function () { return api.state().mp >= 5; } },
            { target: q("#" + id + "-order"), title: "Your turn", text: "Choose Hierarchical, then Hand first. The reach is met and the body tips: a priority order is a design choice the solver cannot check." }
          ];
        }
      }
    ],
    methodsLede: "How the learned line evolved: Radosavovic's Digit controller showed that RL with a transformer over history transfers zero-shot. H2O retargeted motion capture, filtered infeasible clips and tracked 8 keypoints; OmniH2O distilled a student that tracks head and hands. ExBody2 filtered by tracking error and split local keypoints from velocity. HumanPlus shadowed humans through such a tracker and imitated them. WoCoCo and FLAM shaped RL rewards instead.",
    methods: ["h2o-omnih2o", "exbody2", "humanplus", "real-world-humanoid-locomotion", "wococo", "flam", "exbody", "mobile-television", "gr00t-n1"],
    open: [
      { title: "Retargeting the whole body", text: "Mapping full human motion, including dexterous hands, onto a different body remains a critical open problem.", refs: "P09 §VII-C.2" },
      { title: "Human data lack force", text: "Motion capture and video record only kinematics, with no tactile or force signal, which limits contact-rich loco-manipulation.", refs: "P09 §VII-C.2" },
      { title: "Tuning and infeasibility", text: "Weight tuning in large whole-body problems is task-dependent and can cause instability; solvers that resolve infeasibility automatically are still missing.", refs: "P09 §VI-C, §VI-E" },
      { title: "No common benchmark", text: "Reported humanoid results are often anecdotal, and VLA models have not yet convincingly mastered humanoid skills.", refs: "P09 §IX-A, Table VI" }
    ],
    takeaways: [
      "Loco-manipulation adds self-motion to manipulation; whole-body manipulation adds contact with any body surface (P09 Table I).",
      "A floating base moves only through contact forces, so balance constrains every arm motion.",
      "Whole-body control writes every task as a linear function of accelerations, contact forces and torques.",
      "Hierarchical QPs keep strict priorities at the cost of several solves; weighted QPs solve once but let tasks interfere.",
      "Learned trackers moved from 8 keypoints (H2O) to head and hands (OmniH2O), then to filtered data and local keypoints (ExBody2)."
    ],
    quiz: [
      { q: "A humanoid pushes a heavy box with its arms and one knee while walking. Which P09 Table I category fits?", options: ["Whole-body manipulation", "Whole-body loco-manipulation", "Loco-manipulation", "Bipedal locomotion"], correct: 1, why: "It moves the object, moves itself and uses a non-end-effector surface. That is the intersection: whole-body loco-manipulation (P09 Table I, Fig. 3)." },
      { q: "Why do WBCs choose accelerations, contact forces and torques as decision variables?", options: ["They are easy to measure", "The dynamics become linear in them, so a QP solves fast", "They remove the need for contacts", "They make the robot fully actuated"], correct: 1, why: "With X = [q̈, λ, 𝛕], eq. 5 is linear, so tasks and dynamics fit a quadratic program solvable in real time (P09 §VI)." },
      { q: "In a weighted QP, balance has weight 1 and reaching has weight 1. What can go wrong?", options: ["The solver needs K solves", "Reaching can pull the CoM off the feet", "Joint limits are ignored", "Nothing: weights are strict"], correct: 1, why: "Weights are soft priorities: without strict hierarchy a low-priority task can interfere with a high-priority one (P09 §VI-C)." },
      { q: "OmniH2O trained its student with RL and history but no DAgger. What happened?", options: ["Success rose to 99%", "Success collapsed from 94.10% to 47.11%", "Nothing changed", "It needed motion capture"], correct: 1, why: "The OmniH2O ablation reports 47.11% success without DAgger against 94.10% with the teacher's labels (arXiv 2406.08858)." },
      { q: "What did ExBody2's data filtering do to the real-robot joint error (MPJPE)?", options: ["It rose from 0.1074 to 0.1361 rad", "It fell from 0.1361 to 0.1074 rad", "It stayed the same", "It was not measured"], correct: 1, why: "Training only on clips the base policy tracks well lowered the real MPJPE from 0.1361 to 0.1074 rad (arXiv 2412.13196)." }
    ],
    cards: [
      { front: "What separates loco-manipulation from whole-body manipulation?", back: "Loco-manipulation needs robot self-motion; whole-body manipulation needs interaction through any body surface. Their intersection is whole-body loco-manipulation.", ref: "P09 Table I" },
      { front: "What are the decision variables of a WBC QP?", back: "Generalized accelerations q̈, contact forces λ and joint torques 𝛕; eq. 5 is linear in them.", ref: "P09 eq. 5" },
      { front: "How does a hierarchical QP keep strict priority?", back: "It solves a cascade: each lower level is optimized only within the optimal set of all higher levels.", ref: "P09 §VI-C" },
      { front: "What is sim-to-data filtering in H2O?", back: "Train a privileged tracker on all retargeted clips and drop those it fails: about 8.5k of 10k clips remained.", ref: "arXiv 2403.04436" },
      { front: "What does OmniH2O's student track?", back: "Head and both hands (3 points) from 25 steps of proprioception, reaching 94.10% success against 94.72% with 22 points.", ref: "arXiv 2406.08858" },
      { front: "What two policies make up HumanPlus?", back: "HST, an RL shadowing tracker at 50 Hz, and HIT, an imitation transformer that sends 50-step pose chunks at 25 Hz.", ref: "arXiv 2406.10454" }
    ],
    terms: {
      "loco-manipulation": { name: "loco-manipulation", aliases: ["locomotion and manipulation"], group: "foundations", def: "Tasks that involve both the movement of objects through manipulation and the mobility of the robot itself through locomotion.", note: "Not the same as whole-body manipulation, which is about which body surfaces touch the object.", ref: "P09 §II-D, Table I", scene: "robot", focus: ["base", "object", "arm"], look: "walking base carrying the object", uses: [] },
      "whole-body-manipulation": { name: "whole-body manipulation", aliases: ["whole-arm manipulation"], group: "contact", def: "The ability to manipulate objects using any part of one's body, such as elbows, chest or palms, not only predefined end-effectors.", note: "The number of possible contacts explodes the contact modes a planner must consider.", ref: "P09 §II-C", scene: "robot", focus: ["arm", "contact-point", "object"], look: "contacts along the whole arm", uses: ["loco-manipulation"] },
      "floating-base": { name: "floating base", aliases: ["underactuated base"], group: "contact", sym: "S", symTex: "S", def: "A robot base not attached to the world; the selection matrix has lower rank than q, so balance and motion require contact forces.", note: "Fixed-base arms can apply any torque to their base; humanoids cannot.", ref: "P09 §VI, eq. 5–6", scene: "robot", focus: ["base", "contact-point"], look: "the base held only by contacts", uses: [] },
      "dynamic-task": { name: "dynamic task", aliases: ["WBC task"], group: "contact", sym: "eᵢ", symTex: "e_i", def: "A task written as eᵢ = Aᵢ X − bᵢ, linear in accelerations, contact forces and torques; used as an equality, inequality or cost.", note: "Tasks may come from MPC, a fixed plan or teleoperation.", ref: "P09 eq. 7", scene: "system", focus: ["planner", "controller"], look: "tasks passed from planner to controller", uses: ["whole-body-control"] },
      "whole-body-control": { name: "whole-body control", aliases: ["WBC"], group: "contact", def: "Controllers that compute joint torques, contact forces and accelerations for a set of tasks at the current time step, usually from full-order dynamics.", note: "Unlike MPC it looks at one instant; MPC plans, WBC executes.", ref: "P09 §VI, eq. 5–6", scene: "system", focus: ["controller", "robot"], look: "the torque-level controller", uses: [] },
      "hierarchical-qp": { name: "hierarchical QP", aliases: ["HQP", "strict task hierarchy", "stack of tasks"], group: "contact", def: "Whole-body control as a cascade of quadratic programs; each lower-priority task is solved in the null space of all higher ones.", note: "Priorities are strict, but several QPs cost time and memory.", ref: "P09 §VI-C", scene: "system", focus: ["controller"], look: "tasks stacked by priority", uses: ["whole-body-control"] },
      "weighted-qp": { name: "weighted QP", aliases: ["WQP", "soft task weighting"], group: "contact", def: "Whole-body control as one quadratic program whose cost sums the tasks with weights that express priority.", note: "Faster than a hierarchical QP, but low-priority tasks can interfere with high-priority ones, and tuning many weights is hard.", ref: "P09 §VI-C", scene: "system", focus: ["controller"], look: "tasks mixed by weights", uses: ["whole-body-control", "hierarchical-qp"] },
      "null-space-projection": { name: "null-space projection", aliases: ["null space"], group: "contact", def: "Restricting a lower-priority task to motions that leave all higher-priority tasks unchanged, so the hierarchy is strictly maintained.", note: "Operational-space control does this in closed form; a hierarchical QP does it with constraints.", ref: "P09 §VI-B", scene: "robot", focus: ["joint", "arm"], look: "joint motions that keep balance", uses: ["hierarchical-qp"] },
      "motion-tracking-policy": { name: "motion-tracking policy", aliases: ["whole-body tracker", "neural WBC"], group: "learning", def: "A goal-conditioned RL policy trained in simulation to follow reference poses or keypoints, outputting joint targets for PD control.", note: "It replaces the WBC QP with a network; the surveys call it neural WBC.", ref: "P09 §VI-D takeaways · H2O", scene: "system", focus: ["controller", "simulator"], look: "the tracker below the policy", uses: ["whole-body-control"] },
      "sim-to-data-filtering": { name: "sim-to-data filtering", aliases: ["motion feasibility filter"], group: "data", def: "Removing retargeted human clips that a simulated tracker cannot follow, so the real tracker trains only on feasible motion.", note: "ExBody2 picks its threshold by the full-set performance of the resulting policy.", ref: "arXiv 2403.04436 · 2412.13196", scene: "system", focus: ["data-human", "simulator"], look: "clips passing through the simulator", uses: ["motion-tracking-policy"] },
      "sparse-keypoint-goals": { name: "sparse keypoint goals", aliases: ["3-point tracking"], group: "learning", def: "Tracking only a few kinematic targets, such as the head and both hands from a VR headset, and letting the policy fill in the body.", note: "OmniH2O: 94.10% success with 3 points against 94.72% with 22.", ref: "arXiv 2406.08858", scene: "system", focus: ["human-teleop", "controller"], look: "headset and hand targets", uses: ["motion-tracking-policy"] },
      "humanoid-shadowing": { name: "humanoid shadowing", aliases: ["shadowing"], group: "data", def: "Real-time whole-body teleoperation in which the robot copies a human pose estimated from one RGB camera through a learned tracker.", note: "The shadowing data then train an autonomous imitation policy.", ref: "arXiv 2406.10454", scene: "system", focus: ["human-teleop", "data-robot"], look: "operator pose driving the robot", uses: ["motion-tracking-policy"] },
      "contact-stage": { name: "contact stage", aliases: ["contact sequence"], group: "learning", def: "One step of a prescribed contact sequence, pairing a contact goal with a task goal; WoCoCo rewards contacts and stages instead of task-specific terms.", note: "The sequence is predefined by hand; the policy learns how to meet it.", ref: "arXiv 2406.06005", scene: "robot", focus: ["contact-point", "trajectory"], look: "planned contacts along the path", uses: [] },
      "stabilizing-reward": { name: "stabilizing reward", aliases: [], group: "learning", def: "FLAM's extra RL reward: map the robot pose to a human model, reconstruct a stable pose with a pretrained motion model, and reward similarity.", note: "Simulation only; it favors static stability and does not teach recovery.", ref: "arXiv 2503.22249", scene: "system", focus: ["reward-model", "policy-update"], look: "a pose model scoring stability", uses: [] }
    },
    symbols: [
      { id: "Sact", tex: "S", glyph: "S", kind: "Robot", meaning: "selection matrix of actuated joints on a floating base", short: "actuation selection matrix", first: "e4", read: "S", papers: "P09 eq. 5: S" },
      { id: "wbc-X", tex: "X", glyph: "X", kind: "Signals", meaning: "WBC decision vector [q̈, λ, 𝛕]", short: "WBC decision vector", first: "e4", read: "X", papers: "P09 eq. 5, 7: X" },
      { id: "wbc-e", tex: "e_i", glyph: "eᵢ", kind: "Signals", meaning: "error of dynamic task i, linear in X", short: "task error", first: "e4", read: "e sub i", papers: "P09 eq. 7: e_i" },
      { id: "wbc-A", tex: "A_i", glyph: "Aᵢ", kind: "Parameters", meaning: "task matrix of dynamic task i", short: "task matrix", first: "e4", read: "A sub i", papers: "P09 eq. 7: A_i" },
      { id: "wbc-b", tex: "b_i", glyph: "bᵢ", kind: "Parameters", meaning: "task offset (reference) of dynamic task i", short: "task reference", first: "e4", read: "b sub i", papers: "P09 eq. 7: b_i" },
      { id: "wbc-w", tex: "w_i", glyph: "wᵢ", kind: "Parameters", meaning: "weight of task i in a weighted QP", short: "task weight", first: "e4", read: "w sub i", papers: "P09 §VI-C (in words)" }
    ],
    ledger: [
      { where: "Topic 18 · rules", source: "P09 writes joint torques as τ, contact forces as λ and decision variables X = [q̈, λ, τ]", page: "The site writes torques in bold 𝛕 (plain τ is flow time) and keeps λ and X", why: "House notation.", kind: "Our choice" },
      { where: "Topic 18 · weighted and hierarchical QP", source: "P09 §VI-C describes both schemes in words, citing Escande et al. for the cascade", page: "The site writes both as formulas over the dynamic tasks of eq. 7", why: "A formula shows exactly what changes between the two.", kind: "Our choice" },
      { where: "Topic 18 · playground", source: "A humanoid WBC solves torque-level QPs with contact forces, friction cones and inequality constraints", page: "The toy solves velocity-level least squares on a 3-link planar body with static balance; joint limits lock a joint and re-solve", why: "Keeps only the priority mechanism; P09 §VI-C says an HQP is equivalent to the stack of tasks without inequalities.", kind: "Simplified" },
      { where: "Topic 18 · distillation rule", source: "OmniH2O writes L = ‖a_t^privileged − a_t‖²", page: "The site writes â_t for the teacher action and makes the student's inputs explicit", why: "House notation for policies and observations.", kind: "Our choice" },
      { where: "Topic 18 · OmniH2O numbers", source: "The method card merges H2O (arXiv 2403.04436) and OmniH2O (arXiv 2406.08858)", page: "OmniH2O-specific numbers cite arXiv 2406.08858", why: "Each number points to the paper that reports it.", kind: "Our choice" }
    ]
  });
})();
