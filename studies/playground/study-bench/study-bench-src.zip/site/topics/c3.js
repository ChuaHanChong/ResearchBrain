/* Topic 12 · World models as simulator and judge. Sources: P03 §4 (eq. 16–19, Fig. 5), X3 §V–VI (Fig. 4–5), §VIII (Table III),
   P05 §5.5, X1 §3.3 (Fig. 4), method cards (World-Env → VLA-RFT → WMPO → World-VLA-Loop / WoVR; WorldEval → WorldGym → Ctrl-World → Veo;
   GPC → VLA-Reasoner / WorldPlanner; DreamGen). */
(function () {
  "use strict";
  var RB = window.RB;

  function monoFont() { return getComputedStyle(document.body).getPropertyValue("--font-mono"); }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body"); }
  /* segmented control: StudyBench.segmented may pass the button or its value string */
  function onSeg(root, id, cb) { StudyBench.segmented(root.querySelector("#" + id), function (v) { cb(v && v.value !== undefined ? v.value : v); }); }
  function clip01(v) { return Math.max(0, Math.min(1, v)); }
  function pct(v) { return Math.round(v * 100) + "%"; }

  /* =====================================================================================
     Playground 1 · RL in imagination: imagined against real success
     Toy: a policy picks one of six ways to lift a mug (softmax over logits). Each way k has a real success p_k.
     The world model's predicted success is q_k = p_k + b_k·(1 − coverage_k): it is wrong where it saw little data.
     Coverage grows with real rollouts that used way k (behavior alignment, co-evolution). The judge adds false positives.
     Training: groups of 8 imagined rollouts, group-normalized advantages, dynamic sampling, softmax policy gradient.
     All numbers are our toy numbers.
     ===================================================================================== */
  var WAYS = [
    { n: "top grasp", p: 0.55, b: 0.10, c: 0.9, pi: 0.28 },
    { n: "side grasp", p: 0.70, b: -0.05, c: 0.9, pi: 0.28 },
    { n: "handle grasp", p: 0.85, b: -0.35, c: 0.15, pi: 0.06 },
    { n: "push to edge", p: 0.30, b: 0.25, c: 0.3, pi: 0.10 },
    { n: "fast swipe", p: 0.05, b: 0.85, c: 0.0, pi: 0.08 },
    { n: "slow approach", p: 0.60, b: 0.05, c: 0.8, pi: 0.20 }
  ];
  var ITERS = 100, GROUP = 8, KAPPA = 12, LR = 0.5, ALIGN_N = 128, CO_EVERY = 10, CO_N = 32;

  function trainImagined(opt) {
    var R = RB.rng(opt.seed), K = WAYS.length, n = WAYS.map(function () { return 0; }), th = WAYS.map(function (w) { return Math.log(w.pi); }), used = 0;
    if (opt.align) { WAYS.forEach(function (w, k) { n[k] += ALIGN_N * w.pi; }); used += ALIGN_N; }
    function cov(k) { return 1 - (1 - WAYS[k].c) * Math.exp(-n[k] / KAPPA); }
    function q(k) { return clip01(WAYS[k].p + WAYS[k].b * (1 - cov(k))); }
    function pol() { var m = Math.max.apply(null, th), e = th.map(function (v) { return Math.exp(v - m); }), z = e.reduce(function (a, b) { return a + b; }, 0); return e.map(function (v) { return v / z; }); }
    var real = [], imag = [], skipped = 0;
    for (var it = 0; it <= ITERS; it++) {
      var P = pol(), re = 0, im = 0, k;
      for (k = 0; k < K; k++) { re += P[k] * WAYS[k].p; im += P[k] * (q(k) + (1 - q(k)) * opt.fp); }
      real.push([it, re]); imag.push([it, im]);
      if (it === ITERS) break;
      if (opt.co && it > 0 && it % CO_EVERY === 0) { for (k = 0; k < K; k++) n[k] += CO_N * P[k]; used += CO_N; }
      var ks = [], rs = [];
      for (var g = 0; g < GROUP; g++) {
        var u = R(), c = 0, kk;
        for (kk = 0; kk < K - 1; kk++) { c += P[kk]; if (u < c) break; }
        var r = R() < q(kk) ? 1 : (R() < opt.fp ? 1 : 0);
        ks.push(kk); rs.push(r);
      }
      var mean = rs.reduce(function (a, b) { return a + b; }, 0) / GROUP;
      var sd = Math.sqrt(rs.reduce(function (a, b) { return a + (b - mean) * (b - mean); }, 0) / GROUP);
      if (sd < 1e-9) { skipped++; continue; } /* dynamic sampling: all-success or all-fail groups carry no signal */
      for (g = 0; g < GROUP; g++) { var A = (rs[g] - mean) / sd; for (k = 0; k < K; k++) th[k] += LR * A * ((k === ks[g] ? 1 : 0) - P[k]) / GROUP; }
    }
    return { real: real, imag: imag, P: pol(), q: WAYS.map(function (w, k) { return q(k); }), used: used, skipped: skipped };
  }

  function mountImagine(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-data", label: "World-model data: demos, or demos + policy rollouts", value: "demos", options: [{ value: "demos", label: "Demos" }, { value: "aligned", label: "+ rollouts" }] }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-co"> <span>Co-evolution (refit every 10 rounds)</span></label>' +
      RB.slider({ id: id + "-fp", label: "Judge false positives", min: 0, max: 0.4, step: 0.05, value: 0.05, fmt: pct }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Train again ▶</button></div>' +
      '<div class="rb-grid2"><div class="rb-stack"><div data-chart></div>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Six ways to lift a mug: the trained policy share of each, its real success and the world model estimate"></canvas>' +
      '<figcaption class="sb-caption">Bars = how often the trained policy uses each way. Compare the filled tick (real success) with the hollow tick (what the world model predicts).</figcaption></figure></div>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "imag", k: "Success in imagination (judged)" }, { id: "real", k: "Success on the real robot" }, { id: "gap", k: "Gap" }, { id: "used", k: "Real rollouts spent on the world model" }]) +
      '<p class="sb-caption" data-note></p>' +
      RB.legend([{ c: "data-1", label: "real success", kind: "line" }, { c: "data-2", label: "imagined success", kind: "dash" }, { c: "data-3", label: "policy share", kind: "area" }]) +
      '<p class="sb-caption">Illustrative toy with our numbers. WMPO fits its video model on 128 real rollouts of the base policy; that is the source of the second data option (arXiv 2511.09515).</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), chart = body.querySelector("[data-chart]"), note = body.querySelector("[data-note]");
    var st = { align: false, co: false, fp: 0.05, seed: 2 }, last = null, W = 520, H = 210;
    function draw() {
      if (!last) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont(), n = WAYS.length, colW = (W - 20) / n;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var y0 = H - 44, hMax = y0 - 16;
      c.strokeStyle = P.line; c.lineWidth = 1; c.beginPath(); c.moveTo(10, y0 + 0.5); c.lineTo(W - 10, y0 + 0.5); c.stroke();
      WAYS.forEach(function (w, k) {
        var x = 10 + k * colW, cx = x + colW / 2, bw = colW * 0.42;
        c.fillStyle = P["data-3"]; c.globalAlpha = 0.85; c.fillRect(cx - bw / 2, y0 - last.P[k] * hMax, bw, last.P[k] * hMax); c.globalAlpha = 1;
        var yr = y0 - w.p * hMax, yq = y0 - last.q[k] * hMax;
        c.lineWidth = 3; c.strokeStyle = P["data-1"]; c.beginPath(); c.moveTo(cx - colW * 0.36, yr); c.lineTo(cx + colW * 0.36, yr); c.stroke();
        c.lineWidth = 2; c.strokeStyle = P["data-2"]; c.setLineDash([5, 3]); c.strokeRect(cx - colW * 0.36, yq - 3, colW * 0.72, 6); c.setLineDash([]);
        c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono; c.textAlign = "center";
        var sp = w.n.indexOf(" "), parts = [w.n.slice(0, sp), w.n.slice(sp + 1)];
        c.fillText(parts[0], cx, y0 + 16); c.fillText(parts[1] || "", cx, y0 + 29);
        c.fillStyle = P.ink; c.fillText(Math.round(last.P[k] * 100) + "%", cx, Math.min(y0 - last.P[k] * hMax, yr, yq) - 8);
      });
      c.textAlign = "left";
    }
    function run() {
      last = trainImagined(st);
      chart.innerHTML = "";
      StudyBench.lineChart(chart, { title: "Success during training in the world model", height: 200, directLabels: false, x: { label: "training round", min: 0, max: ITERS }, y: { label: "success", min: 0, max: 1, fmt: pct },
        series: [{ name: "real robot", color: "data-1", points: last.real }, { name: "imagined, judged", color: "data-2", dash: true, points: last.imag }] });
      var im = last.imag[ITERS][1], re = last.real[ITERS][1], top = 0;
      last.P.forEach(function (v, k) { if (v > last.P[top]) top = k; });
      RB.setRO(body, "imag", pct(im)); RB.setRO(body, "real", pct(re)); RB.setRO(body, "gap", (im - re >= 0 ? "+" : "") + Math.round((im - re) * 100) + " points"); RB.setRO(body, "used", String(last.used));
      var w = WAYS[top];
      note.textContent = "The policy now favors the " + w.n + " (" + pct(last.P[top]) + " of rollouts). The world model predicts " + pct(last.q[top]) + " success for it; the real robot achieves " + pct(w.p) + "." +
        (last.q[top] - w.p > 0.25 ? " The policy is exploiting a hallucination." : "");
      draw();
    }
    onSeg(body, id + "-data", function (v) { st.align = v === "aligned"; run(); });
    body.querySelector("#" + id + "-co").addEventListener("change", function (e) { st.co = e.target.checked; run(); });
    RB.bindSlider(body, id + "-fp", pct, function (v) { st.fp = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { align: st.align, co: st.co, fp: st.fp }; }, result: function () { return last; } };
  }

  /* =====================================================================================
     Playground 2 · rank candidate chunks with a world model (GPC-RANK style)
     Toy: a frozen policy proposes N chunks. Real score y ~ N(0.60, 0.15) for ordinary proposals; a share of
     unusual proposals scores N(0.30, 0.15) on the robot but the world model, which never saw such actions, adds +0.45.
     Predicted score ŷ = y + σ·ε (+ 0.45 if unusual). Pick argmax ŷ. Our toy numbers.
     ===================================================================================== */
  var OOD_BIAS = 0.45, DECISIONS = 300, KMAX = 8;
  function proposal(R, f, sig) {
    var odd = R() < f, y = clip01((odd ? 0.30 : 0.60) + 0.15 * R.normal());
    return { odd: odd, y: y, yh: y + sig * R.normal() + (odd ? OOD_BIAS : 0) };
  }
  function rankCurve(f, sig, seed) {
    var pts = [], pred = [];
    for (var e = 0; e <= KMAX; e++) {
      var N = Math.pow(2, e), R = RB.rng(seed + 31 * e), sy = 0, syh = 0;
      for (var d = 0; d < DECISIONS; d++) {
        var best = null;
        for (var k = 0; k < N; k++) { var p = proposal(R, f, sig); if (!best || p.yh > best.yh) best = p; }
        sy += best.y; syh += best.yh;
      }
      pts.push([e, sy / DECISIONS]); pred.push([e, syh / DECISIONS]);
    }
    return { real: pts, pred: pred };
  }
  function mountRank(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.slider({ id: id + "-n", label: "Candidates N", min: 0, max: KMAX, step: 1, value: 4, fmt: function (v) { return String(Math.pow(2, v)); } }) +
      RB.slider({ id: id + "-sig", label: "World-model error σ", min: 0, max: 0.3, step: 0.02, value: 0.1, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-f", label: "Unusual proposals", min: 0, max: 0.3, step: 0.05, value: 0, fmt: pct }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New decision ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="One decision: each candidate chunk plotted by real score against the world model prediction"></canvas>' +
      '<figcaption class="sb-caption">One decision. Each dot is a candidate chunk: real score across, predicted score up. The ringed dot is the one the ranker picks; the square marks the truly best.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "alone", k: "Policy alone (N = 1)" }, { id: "chosen", k: "Real score of the pick" }, { id: "pred", k: "Predicted score of the pick" }, { id: "calls", k: "World-model rollouts per decision" }]) +
      '<div data-chart></div></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), chart = body.querySelector("[data-chart]"), W = 420, H = 320;
    var st = { e: 4, sig: 0.1, f: 0, seed: 5 }, one = [], oracle = rankCurve(0, 0, 11);
    function toPx(x, y) { return [40 + x * (W - 60), H - 34 - (y + 0.1) / 1.6 * (H - 50)]; }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P.line; c.lineWidth = 1;
      var a = toPx(0, -0.1), b = toPx(1, -0.1), t = toPx(0, 1.5);
      c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.moveTo(a[0], a[1]); c.lineTo(t[0], t[1]); c.stroke();
      var d0 = toPx(0, 0), d1 = toPx(1, 1); c.strokeStyle = P["ink-3"]; c.setLineDash([4, 4]); c.beginPath(); c.moveTo(d0[0], d0[1]); c.lineTo(d1[0], d1[1]); c.stroke(); c.setLineDash([]);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; var dl = toPx(0.5, 0.12); c.fillText("dashed: predicted = real", dl[0], dl[1]);
      c.fillText("real score →", b[0] - 80, b[1] + 18); c.save(); c.translate(a[0] - 26, t[1] + 110); c.rotate(-Math.PI / 2); c.fillText("predicted score →", 0, 0); c.restore();
      var pick = null, best = null;
      one.forEach(function (p) { if (!pick || p.yh > pick.yh) pick = p; if (!best || p.y > best.y) best = p; });
      one.forEach(function (p) { var z = toPx(p.y, Math.max(-0.1, Math.min(1.5, p.yh))); c.fillStyle = p.odd ? P["data-3"] : P["data-1"]; c.globalAlpha = 0.8; c.beginPath(); c.arc(z[0], z[1], 4, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1; });
      if (best) { var zb = toPx(best.y, Math.max(-0.1, Math.min(1.5, best.yh))); c.strokeStyle = P.good; c.lineWidth = 2; c.strokeRect(zb[0] - 8, zb[1] - 8, 16, 16); }
      if (pick) { var zp = toPx(pick.y, Math.max(-0.1, Math.min(1.5, pick.yh))); c.strokeStyle = P.accent; c.lineWidth = 2.5; c.beginPath(); c.arc(zp[0], zp[1], 10, 0, Math.PI * 2); c.stroke(); }
    }
    function run(newCurve) {
      var R = RB.rng(st.seed * 97 + st.e), N = Math.pow(2, st.e); one = [];
      for (var k = 0; k < N; k++) one.push(proposal(R, st.f, st.sig));
      if (newCurve !== false) {
        var cur = rankCurve(st.f, st.sig, 11);
        st.cur = cur;
        chart.innerHTML = "";
        StudyBench.lineChart(chart, { title: "Average over 300 decisions", height: 190, directLabels: false, x: { label: "log₂ N (0 = one candidate, 8 = 256)", min: 0, max: KMAX }, y: { label: "score", min: 0.2, max: 1.4, fmt: function (v) { return (+v).toFixed(1); } },
          series: [{ name: "real score of the pick", color: "data-1", points: cur.real }, { name: "predicted score of the pick", color: "data-2", dash: true, points: cur.pred }, { name: "perfect model", color: "data-4", dash: true, points: oracle.real }] });
      }
      var cr = st.cur.real[st.e][1], cp = st.cur.pred[st.e][1];
      RB.setRO(body, "alone", RB.fmt(st.cur.real[0][1], 2)); RB.setRO(body, "chosen", RB.fmt(cr, 2)); RB.setRO(body, "pred", RB.fmt(cp, 2)); RB.setRO(body, "calls", String(N));
      draw();
    }
    RB.bindSlider(body, id + "-n", function (v) { return String(Math.pow(2, v)); }, function (v) { st.e = v; run(false); });
    RB.bindSlider(body, id + "-sig", function (v) { return (+v).toFixed(2); }, function (v) { st.sig = v; run(); });
    RB.bindSlider(body, id + "-f", pct, function (v) { st.f = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed++; run(false); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { N: Math.pow(2, st.e), sig: st.sig, f: st.f, real: st.cur.real[st.e][1] }; } };
  }

  /* =====================================================================================
     Playground 3 · the world model as a judge of policies
     Six checkpoints with real success s_i (our toy numbers). The world model shifts each by a fixed error ~ σ·N(0,1);
     n imagined rollouts per checkpoint; a judge with true-positive rate TPR and false-positive rate FPR labels each.
     Metrics: Spearman ρ (X3 Table III), Pearson r, MMRV (SIMPLER eq. 1–2, as used by WorldEval).
     ===================================================================================== */
  var REAL = [0.15, 0.30, 0.45, 0.55, 0.70, 0.85];
  function ranks(v) {
    var idx = v.map(function (x, i) { return i; }).sort(function (a, b) { return v[a] - v[b]; }), r = new Array(v.length), i = 0;
    while (i < idx.length) { var j = i; while (j + 1 < idx.length && v[idx[j + 1]] === v[idx[i]]) j++; for (var k = i; k <= j; k++) r[idx[k]] = (i + j) / 2 + 1; i = j + 1; }
    return r;
  }
  function pearson(a, b) {
    var n = a.length, ma = a.reduce(function (s, x) { return s + x; }, 0) / n, mb = b.reduce(function (s, x) { return s + x; }, 0) / n, sab = 0, saa = 0, sbb = 0;
    for (var i = 0; i < n; i++) { sab += (a[i] - ma) * (b[i] - mb); saa += (a[i] - ma) * (a[i] - ma); sbb += (b[i] - mb) * (b[i] - mb); }
    return saa > 0 && sbb > 0 ? sab / Math.sqrt(saa * sbb) : 0;
  }
  function mmrv(real, sim) {
    var n = real.length, tot = 0;
    for (var i = 0; i < n; i++) { var m = 0; for (var j = 0; j < n; j++) { if ((sim[i] < sim[j]) !== (real[i] < real[j])) m = Math.max(m, Math.abs(real[i] - real[j])); } tot += m; }
    return tot / n;
  }
  function judgeRun(o) {
    var R = RB.rng(o.seed), sim = [];
    var err = REAL.map(function () { return o.sig * R.normal(); });
    REAL.forEach(function (s, i) {
      var m = clip01(s + err[i]), cnt = 0;
      for (var k = 0; k < o.n; k++) { var ok = R() < m; if (ok ? R() < o.tpr : R() < o.fpr) cnt++; }
      sim.push(cnt / o.n);
    });
    var rr = ranks(REAL), rs = ranks(sim), rho = pearson(rr, rs), r = pearson(REAL, sim);
    var mx = REAL.reduce(function (a, b) { return a + b; }, 0) / 6, my = sim.reduce(function (a, b) { return a + b; }, 0) / 6, sxy = 0, sxx = 0;
    REAL.forEach(function (x, i) { sxy += (x - mx) * (sim[i] - my); sxx += (x - mx) * (x - mx); });
    var slope = sxy / sxx;
    return { sim: sim, rho: rho, r: r, mmrv: mmrv(REAL, sim), slope: slope, icpt: my - slope * mx };
  }
  function mountJudge(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.slider({ id: id + "-n", label: "Imagined rollouts per checkpoint", min: 5, max: 100, step: 5, value: 20 }) +
      RB.slider({ id: id + "-sig", label: "World-model error σ", min: 0, max: 0.3, step: 0.02, value: 0.04, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-tpr", label: "Judge catches successes", min: 0.5, max: 1, step: 0.05, value: 0.95, fmt: pct }) +
      RB.slider({ id: id + "-fpr", label: "Judge passes failures", min: 0, max: 0.4, step: 0.05, value: 0.05, fmt: pct }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Evaluate again ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Six checkpoints: real success across, success in the world model up"></canvas>' +
      '<figcaption class="sb-caption">Each dot is one checkpoint. Dots on the dashed diagonal agree exactly; the solid line is the fit a · real + b. Rank agreement only asks whether the dots rise from left to right.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "rho", k: "Spearman rank correlation ρₛ" }, { id: "r", k: "Pearson r" }, { id: "mmrv", k: "MMRV (lower is better)" }, { id: "fit", k: "Fit slope a" }, { id: "icpt", k: "Fit offset b" }]) +
      '<p class="sb-caption">Reference points: WorldEval reports Pearson 0.942 and MMRV 0.044 against real trials; WorldGym Pearson 0.78; Ctrl-World a fit of 0.81x − 0.11 for success (arXiv 2505.19017, 2506.00613, 2510.10125). The toy numbers here are ours.</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), W = 420, H = 320, st = { n: 20, sig: 0.04, tpr: 0.95, fpr: 0.05, seed: 3 }, last = null;
    function toPx(x, y) { return [44 + x * (W - 64), H - 36 - y * (H - 56)]; }
    function draw() {
      if (!last) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (var g = 0; g <= 5; g++) { var a = toPx(g / 5, 0), b = toPx(g / 5, 1), l = toPx(0, g / 5), rr = toPx(1, g / 5); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.moveTo(l[0], l[1]); c.lineTo(rr[0], rr[1]); c.stroke(); }
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono;
      for (g = 0; g <= 5; g += 1) { var tx = toPx(g / 5, 0), ty = toPx(0, g / 5); c.fillText(String(g * 20), tx[0] - 6, tx[1] + 14); c.fillText(String(g * 20), ty[0] - 24, ty[1] + 4); }
      c.fillText("real success % →", W - 140, H - 6); c.save(); c.translate(12, H / 2 + 60); c.rotate(-Math.PI / 2); c.fillText("imagined success % →", 0, 0); c.restore();
      var d0 = toPx(0, 0), d1 = toPx(1, 1); c.strokeStyle = P["ink-3"]; c.setLineDash([4, 4]); c.beginPath(); c.moveTo(d0[0], d0[1]); c.lineTo(d1[0], d1[1]); c.stroke(); c.setLineDash([]);
      var f0 = toPx(0, clip01(last.icpt)), x1 = 1, y1 = last.slope + last.icpt; if (y1 > 1) { x1 = (1 - last.icpt) / last.slope; y1 = 1; } if (y1 < 0) { x1 = -last.icpt / last.slope; y1 = 0; }
      var f1 = toPx(Math.max(0, Math.min(1, x1)), y1); if (last.icpt >= 0 && last.icpt <= 1) { c.strokeStyle = P["data-2"]; c.lineWidth = 2; c.beginPath(); c.moveTo(f0[0], f0[1]); c.lineTo(f1[0], f1[1]); c.stroke(); }
      REAL.forEach(function (s, i) { var z = toPx(s, last.sim[i]); c.fillStyle = P["data-1"]; c.beginPath(); c.arc(z[0], z[1], 6, 0, Math.PI * 2); c.fill(); c.fillStyle = P.ink; c.font = "600 11px " + bodyFont(); c.fillText(String.fromCharCode(65 + i), z[0] + 9, z[1] - 7); });
    }
    function run() {
      last = judgeRun(st);
      RB.setRO(body, "rho", RB.fmt(last.rho, 2)); RB.setRO(body, "r", RB.fmt(last.r, 2)); RB.setRO(body, "mmrv", RB.fmt(last.mmrv, 3));
      RB.setRO(body, "fit", RB.fmt(last.slope, 2)); RB.setRO(body, "icpt", (last.icpt < 0 ? "−" : "+") + RB.fmt(Math.abs(last.icpt), 2));
      draw();
    }
    RB.bindSlider(body, id + "-n", null, function (v) { st.n = v; run(); });
    RB.bindSlider(body, id + "-sig", function (v) { return (+v).toFixed(2); }, function (v) { st.sig = v; run(); });
    RB.bindSlider(body, id + "-tpr", pct, function (v) { st.tpr = v; run(); });
    RB.bindSlider(body, id + "-fpr", pct, function (v) { st.fpr = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { n: st.n, sig: st.sig, tpr: st.tpr, fpr: st.fpr, rho: last.rho }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token colors only) ---------- */
  var ART = {
    env: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="16" width="52" height="24" rx="4" class="rb-f-surface"/><text x="34" y="32" text-anchor="middle" class="rb-t-mono">policy</text><rect x="132" y="16" width="60" height="24" rx="4" class="rb-f-soft"/><text x="162" y="32" text-anchor="middle" class="rb-t-acc">p_φ</text><path d="M62 22 H128" class="rb-s-ink"/><path d="M128 34 H62" class="rb-s-acc" stroke-dasharray="4 3"/><text x="95" y="14" text-anchor="middle" class="rb-t-mono">chunk</text><text x="95" y="50" text-anchor="middle" class="rb-t-mono">imagined frame</text></svg>',
    judge: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (8 + i * 26) + '" y="14" width="22" height="18" rx="2" class="rb-f-sunk"/>'; }).join("") + '<path d="M114 23 H134" class="rb-s-ink"/><circle cx="152" cy="23" r="13" class="rb-f-soft"/><text x="152" y="27" text-anchor="middle" class="rb-t-acc">S</text><text x="184" y="27" text-anchor="middle" class="rb-t-ink">0.8</text><text x="60" y="48" text-anchor="middle" class="rb-t-mono">imagined rollout</text></svg>',
    exploit: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 48 C50 46 70 40 100 30 S160 12 192 8" class="rb-s-acc" stroke-dasharray="5 3"/><path d="M10 48 C50 44 80 38 100 38 S160 44 192 46" class="rb-s-ink"/><text x="150" y="10" class="rb-t-acc">imagined</text><text x="150" y="40" class="rb-t-mono">real</text><text x="12" y="14" class="rb-t-mono">training →</text></svg>',
    coevo: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="16" width="56" height="24" rx="4" class="rb-f-soft"/><text x="38" y="32" text-anchor="middle" class="rb-t-acc">p_φ</text><rect x="134" y="16" width="56" height="24" rx="4" class="rb-f-surface"/><text x="162" y="32" text-anchor="middle" class="rb-t-mono">π_θ</text><path d="M68 20 Q100 2 132 20" class="rb-s-ink"/><path d="M132 36 Q100 54 68 36" class="rb-s-acc"/><text x="100" y="10" text-anchor="middle" class="rb-t-mono">imagined data</text><text x="100" y="54" text-anchor="middle" class="rb-t-mono">real rollouts</text></svg>',
    rank: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0.3, 0.8, 0.5, 0.6].map(function (v, i) { var x = 20 + i * 44, h = v * 34; return '<rect x="' + x + '" y="' + (44 - h) + '" width="26" height="' + h + '" rx="2" class="' + (i === 1 ? "rb-f-soft" : "rb-f-sunk") + '"/><text x="' + (x + 13) + '" y="54" text-anchor="middle" class="rb-t-mono">a' + (i + 1) + "</text>"; }).join("") + '<text x="58" y="8" class="rb-t-acc">pick</text></svg>',
    search: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="24" cy="28" r="6" class="rb-f-acc"/><path d="M30 26 L80 10 M30 28 L80 28 M30 30 L80 46" class="rb-s-line"/><circle cx="86" cy="10" r="5" class="rb-f-surface"/><circle cx="86" cy="28" r="5" class="rb-f-soft"/><circle cx="86" cy="46" r="5" class="rb-f-surface"/><path d="M91 28 L140 18 M91 28 L140 38" class="rb-s-acc"/><circle cx="146" cy="18" r="5" class="rb-f-soft"/><circle cx="146" cy="38" r="5" class="rb-f-surface"/><text x="160" y="22" class="rb-t-mono">value</text></svg>',
    neural: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (8 + i * 24) + '" y="10" width="20" height="16" rx="2" class="rb-f-soft" opacity="' + (0.5 + i * 0.15) + '"/>'; }).join("") + '<text x="52" y="40" text-anchor="middle" class="rb-t-mono">generated video</text><path d="M108 18 H128" class="rb-s-ink"/><rect x="132" y="8" width="30" height="20" rx="3" class="rb-f-surface"/><text x="147" y="22" text-anchor="middle" class="rb-t-mono">IDM</text><path d="M164 18 H176" class="rb-s-ink"/><text x="188" y="22" text-anchor="middle" class="rb-t-acc">â</text><text x="160" y="48" text-anchor="middle" class="rb-t-mono">pseudo-actions</text></svg>',
    rankcorr: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M14 50 L110 6" class="rb-s-line" stroke-dasharray="3 3"/>' + [[0.1, 0.2], [0.3, 0.25], [0.5, 0.45], [0.7, 0.55], [0.9, 0.8]].map(function (p) { return '<circle cx="' + (14 + p[0] * 96) + '" cy="' + (50 - p[1] * 44) + '" r="4" class="rb-f-acc"/>'; }).join("") + '<text x="124" y="24" class="rb-t-mono">same order</text><text x="124" y="40" class="rb-t-mono">in both</text></svg>'
  };

  /* ---------- worked example figure: one group of eight imagined rollouts ---------- */
  var CX = function (i) { return 50 + i * 65; };
  var Y0 = 120, SC = 34;
  function bars(vals, tag) {
    return vals.map(function (v, i) {
      var h = Math.abs(v) * SC, y = v >= 0 ? Y0 - h : Y0, ty = v >= 0 ? y - 6 : y + h + 13;
      var s = (v < 0 ? "−" : "+") + Math.abs(v).toFixed(2);
      return '<rect x="' + (CX(i) - 10) + '" y="' + y.toFixed(1) + '" width="20" height="' + h.toFixed(1) + '" rx="2" ' + (v >= 0 ? 'class="rb-f-acc"' : 'style="fill:var(--data-2)"') + (tag && tag[i] ? ' stroke-dasharray="3 2"' : "") + '/><text x="' + CX(i) + '" y="' + ty.toFixed(1) + '" text-anchor="middle" class="rb-t-mono">' + s + "</text>";
    }).join("");
  }
  function labels(ok, flag) {
    return ok.map(function (v, i) { return '<rect x="' + (CX(i) - 22) + '" y="18" width="44" height="26" rx="4" class="' + (v ? "rb-f-soft" : "rb-f-sunk") + '"/><text x="' + CX(i) + '" y="35" text-anchor="middle" class="' + (v ? "rb-t-acc" : "rb-t-mono") + '">' + (v ? (flag === i ? "1 ?" : "1") : "0") + "</text>"; }).join("");
  }
  var G1 = [1, 0, 0, 1, 0, 0, 0, 1], G2 = [1, 0, 0, 1, 1, 0, 0, 1], G3 = [0, 0, 0, 0, 0, 0, 0, 0];
  var WE_FIG = '<svg viewBox="0 0 560 200" role="img" aria-label="Eight imagined rollouts with judge scores and the advantage each receives">' +
    '<g class="rb-t-mono">' + G1.map(function (v, i) { return '<text x="' + CX(i) + '" y="12" text-anchor="middle">#' + (i + 1) + "</text>"; }).join("") + "</g>" +
    '<line x1="16" y1="' + Y0 + '" x2="544" y2="' + Y0 + '" class="rb-s-line"/>' +
    '<g data-on="1-3">' + labels(G1) + "</g>" +
    '<g data-on="4">' + labels(G2, 4) + "</g>" +
    '<g data-on="5">' + labels(G3) + "</g>" +
    '<g data-on="1"><text x="280" y="192" text-anchor="middle" class="rb-t-ink">Judge scores Sᵢ: 3 successes out of 8</text></g>' +
    '<g data-on="2">' + bars(G1.map(function (v) { return v ? 1 - 2 / 7 : -3 / 7; })) + '<text x="280" y="192" text-anchor="middle" class="rb-t-ink">Leave-one-out: Sᵢ minus the mean of the other 7</text></g>' +
    '<g data-on="3">' + bars(G1.map(function (v) { return v ? 0.625 / Math.sqrt(0.234375) : -0.375 / Math.sqrt(0.234375); })) + '<text x="280" y="192" text-anchor="middle" class="rb-t-ink">mean 0.375 · std 0.484</text></g>' +
    '<g data-on="4">' + bars(G2.map(function (v) { return v ? 1 : -1; }), [0, 0, 0, 0, 1, 0, 0, 0]) + '<text x="280" y="192" text-anchor="middle" class="rb-t-ink">mean 0.5 · std 0.5 · #5 is a hallucinated grasp</text></g>' +
    '<g data-on="5"><text x="280" y="92" text-anchor="middle" class="rb-t-acc">std = 0: no advantage, group skipped</text><text x="280" y="192" text-anchor="middle" class="rb-t-ink">All eight imagined rollouts fail</text></g></svg>';

  RB.topic({
    id: "c3",
    title: "World models as simulator and judge",
    eyebrow: "Part C · World models at work",
    lede: "A learned world model can stand in for the robot's surroundings: policies practice, get scored and get ranked in imagination before touching hardware.",
    refs: ["P03 §4", "X3 §V–VI, §VIII", "P05 §5.5", "X1 §3.3"],
    why: "Real robots are slow to reset and risky to explore with, and imitation cannot learn from failure. A learned world model can play the environment: the policy practices in imagination, a judge scores the outcome, and the same parts rank candidate actions or whole policies. All of it depends on imagined success tracking real success.",
    outcomes: [
      "Trace one round of reinforcement learning inside a learned world model.",
      "Compute group-normalized advantages from judged imagined rollouts.",
      "Explain how a policy exploits simulator errors and how co-evolution counters it.",
      "Compare candidate reranking, tree search and policy evaluation with world models.",
      "Interpret rank correlation and MMRV for a world-model evaluator."
    ],
    concepts: [
      { name: "Learned environment", def: "The world model replaces the robot's surroundings: the policy acts, the model predicts the next frames.", ref: "P03 §4.1, eq. 16", art: ART.env, term: "learned-environment", sym: "pphi", href: "#lab/worldmodel" },
      { name: "Outcome scoring", def: "A judge turns an imagined rollout into a reward: a success classifier, a VLM or a distance to a reference.", ref: "X3 §V-E", art: ART.judge, term: "outcome-scoring", sym: "score" },
      { name: "Simulator exploitation", def: "Optimization finds behavior that scores well only because the learned simulator is wrong there.", ref: "X3 §V-D", art: ART.exploit, term: "simulator-exploitation" },
      { name: "Co-evolution", def: "Real rollouts of the improved policy refit the world model, which then trains the policy further.", ref: "P03 eq. 19", art: ART.coevo, term: "co-evolution" },
      { name: "Candidate reranking", def: "A frozen policy proposes several chunks; the world model predicts each outcome and the best one runs.", ref: "X3 §V-B · GPC", art: ART.rank, term: "candidate-reranking", sym: "N" },
      { name: "Search in imagination", def: "Monte Carlo tree search (MCTS) or model-predictive control queries the world model many times per decision.", ref: "X3 §V-C", art: ART.search, term: "search-based-action-evaluation" },
      { name: "Neural trajectories", def: "Generated robot videos labeled with pseudo-actions by an inverse dynamics model (IDM) become training data.", ref: "P05 §5.5.3 · DreamGen", art: ART.neural, term: "neural-trajectory" },
      { name: "Rank agreement", def: "An evaluator is useful if it orders policies the way real trials do, even when absolute rates differ.", ref: "X3 Table III", art: ART.rankcorr, term: "policy-rank-correlation" }
    ],
    flow: {
      title: "The world model in the loop: train or judge", ref: "P03 Fig. 5 · X1 Fig. 4", w: 850, h: 270,
      caption: "Top row: one imagined episode. Right: a judge scores it and the policy updates. Dashed: real rollouts refit the model. Without the update, the loop only evaluates.",
      nodes: [
        { id: "start", x: 20, y: 40, w: 150, h: 52, label: "Real start frame", sub: "o₀ and instruction ℓ", kind: "env" },
        { id: "policy", x: 230, y: 40, w: 150, h: 52, label: "Policy π_θ", sub: "proposes a chunk", kind: "agent" },
        { id: "wm", x: 440, y: 40, w: 150, h: 52, label: "World model p_φ", sub: "imagines the frames", kind: "store" },
        { id: "judge", x: 650, y: 40, w: 150, h: 52, label: "Judge S", sub: "success or progress", kind: "decision" },
        { id: "update", x: 440, y: 190, w: 150, h: 52, label: "Policy update", sub: "group advantage", kind: "agent" },
        { id: "real", x: 650, y: 190, w: 150, h: 52, label: "Real robot", sub: "a few check rollouts", kind: "env" }
      ],
      edges: [
        { from: "start", to: "policy", label: "o₀, ℓ" },
        { from: "policy", to: "wm", label: "chunk" },
        { from: "wm", to: "judge", label: "rollout" },
        { from: "judge", to: "update", label: "scores Sᵢ", sides: ["b", "t"], via: [[725, 150], [515, 150]] },
        { from: "update", to: "policy", label: "new θ", sides: ["l", "b"], via: [[305, 216]] },
        { from: "update", to: "real", label: "deploy" },
        { from: "real", to: "wm", label: "refit φ", dashed: true, sides: ["r", "t"], via: [[830, 216], [830, 14], [515, 14]] }
      ],
      steps: [
        { on: ["start", "start>policy", "policy"], text: "An imagined episode starts from a real camera frame and instruction, as in WMPO and WorldGym. The policy proposes an action chunk." },
        { on: ["policy>wm", "wm"], text: "The world model predicts the frames that chunk would produce. The last frame goes back to the policy, and the loop repeats." },
        { on: ["wm>judge", "judge"], text: "A judge scores the rollout: a success classifier in WMPO, a vision-language model (VLM) reflector in World-Env, a distance to a reference rollout in VLA-RFT." },
        { on: ["judge>update", "update", "update>policy", "policy"], text: "Scores of a group of rollouts become advantages, and a clipped policy-gradient step updates the policy (P03 eq. 18). No robot has moved." },
        { on: ["update>real", "real", "real>wm", "wm"], text: "Every few rounds the new policy runs on the real robot. Those rollouts, failures included, refit the world model: co-evolution (P03 eq. 19)." },
        { on: ["wm", "judge"], text: "Drop the update and the same loop is an evaluator: average judge scores over many rollouts rank policies or checkpoints (WorldEval, WorldGym)." }
      ]
    },
    worked: {
      title: "Advantages from eight imagined rollouts",
      ref: "World-Env eq. RLOO · WMPO eq. Â", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-adv}{\\hat A_i} = \\frac{\\class{sym-score}{S_i} - \\operatorname{mean}_j\\, \\class{sym-score}{S_j}}{\\operatorname{std}_j\\, \\class{sym-score}{S_j}}", words: "Each imagined rollout is pushed up or down by how its judge score compares with the rest of its group.", key: [{ sym: "adv", glyph: "Âᵢ", meaning: "advantage of rollout i" }, { sym: "score", glyph: "Sᵢ", meaning: "judge score of rollout i" }] },
      figure: WE_FIG,
      steps: [
        { title: "Imagine eight rollouts", text: "From one real start frame the policy and world model produce eight rollouts. The judge scores rollouts 1, 4 and 8 as successes." },
        { title: "Leave-one-out baseline", text: "World-Env subtracts the other seven's mean: a success gets 1 − 2/7 = +0.71, a failure 0 − 3/7 = −0.43." },
        { title: "Normalize by the group", text: "WMPO divides by the spread: mean 0.375, std 0.484. Successes get +1.29, failures −0.77." },
        { title: "One judge mistake", text: "Rollout 5 shows a grasp the world model hallucinated; the judge says success. Now mean 0.5, std 0.5: the fake success gets +1.00, like real ones." },
        { title: "No spread, no signal", text: "If all eight fail, std is 0 and every advantage is undefined. WMPO's dynamic sampling drops such groups." }
      ]
    },
    ruleTitle: "Training and judging in a learned simulator",
    rules: [
      { name: "The world model as environment", ref: "P03 eq. 16", term: "learned-environment",
        tex: "(\\class{sym-op}{\\hat o_{t+1}},\\ \\class{sym-r}{\\hat r_t},\\ \\hat d_t) \\sim \\class{sym-pphi}{p_\\phi}\\big(\\cdot \\mid \\class{sym-o}{o_{\\le t}},\\ \\class{sym-a}{a_{\\le t}},\\ \\class{sym-l}{\\ell}\\big)",
        words: "Given the history of frames, actions and the instruction, the model imagines the next frame and, optionally, a reward and a done flag.",
        key: ["op", "r", { glyph: "d̂ₜ", meaning: "predicted termination" }, "pphi", "o", "a", "l"] },
      { name: "Return in imagination", ref: "P03 eq. 17",
        before: "\\class{sym-J}{J}(\\theta) = \\class{sym-E}{\\mathbb{E}}_{\\class{sym-xi}{\\xi} \\sim (\\class{sym-pi}{\\pi_\\theta},\\, \\class{sym-T}{T})} \\Big[\\textstyle\\sum_t \\class{sym-gamma}{\\gamma}^t \\class{sym-r}{r_t}\\Big]",
        tex: "\\class{sym-J}{J}(\\theta) = \\class{sym-E}{\\mathbb{E}}_{\\class{sb-chg}{\\class{sym-xi}{\\hat\\xi}} \\sim (\\class{sym-pi}{\\pi_\\theta},\\, \\class{sb-chg}{\\class{sym-pphi}{p_\\phi}})} \\Big[\\textstyle\\sum_t \\class{sym-gamma}{\\gamma}^t \\class{sb-chg}{\\class{sym-r}{\\hat r_t}}\\Big]",
        words: "The usual RL objective, with the true dynamics swapped for the learned model and real rewards for predicted ones.",
        key: ["J", "E", "xi", "pi", "T", "pphi", "gamma", "r"], diff: true, beforeLabel: "Real world", afterLabel: "Imagined" },
      { name: "Group-normalized advantage", ref: "World-Env · WMPO", term: "group-relative-advantage",
        before: "\\class{sym-adv}{\\hat A_i} = \\class{sym-score}{S_i} - \\frac{1}{\\class{sym-N}{N}-1}\\textstyle\\sum_{j \\ne i} \\class{sym-score}{S_j}",
        tex: "\\class{sym-adv}{\\hat A_i} = \\frac{\\class{sym-score}{S_i} - \\class{sb-chg}{\\frac{1}{\\class{sym-N}{N}}\\sum_{j} \\class{sym-score}{S_j}}}{\\class{sb-new}{\\operatorname{std}_j\\, \\class{sym-score}{S_j}}}",
        words: "World-Env's leave-one-out baseline becomes WMPO's group mean, and dividing by the spread puts every group on the same scale.",
        key: [{ sym: "adv", glyph: "Âᵢ", meaning: "advantage of rollout i" }, { sym: "score", glyph: "Sᵢ", meaning: "judge score of rollout i" }, { sym: "N", glyph: "N", meaning: "rollouts per group" }], diff: true, beforeLabel: "World-Env (RLOO)", afterLabel: "WMPO (GRPO)" },
      { name: "Co-evolution of model and policy", ref: "P03 eq. 19", term: "co-evolution",
        tex: "\\begin{aligned} \\phi_{k+1} &\\leftarrow \\mathrm{UpdateWM}(\\phi_k, \\class{sym-D}{\\mathcal D}_{\\text{real}} \\cup \\class{sym-D}{\\mathcal D}_{\\class{sym-pi}{\\pi_{\\theta_k}}}) \\\\ \\theta_{k+1} &\\leftarrow \\mathrm{UpdatePolicy}\\big(\\theta_k,\\ \\hat{\\class{sym-D}{\\mathcal D}}(\\phi_{k+1})\\big) \\end{aligned}",
        words: "Refit the world model on real data plus the current policy's rollouts, then improve the policy on imagined data from the refit model.",
        key: [{ glyph: "φ", meaning: "world-model parameters" }, "D", "pi", { glyph: "k", meaning: "round of the loop" }] },
      { name: "Rank candidates (GPC-RANK)", ref: "GPC, arXiv 2502.00622", term: "candidate-reranking",
        tex: "k^\\star = \\arg\\max_{k \\le \\class{sym-N}{N}}\\ \\class{sym-score}{S}\\big(\\class{sym-pphi}{p_\\phi}(\\class{sym-o}{o_t},\\ \\class{sym-achunk}{\\mathbf a^{(k)}_{t:t+H}})\\big)",
        words: "Sample N chunks from the frozen policy, imagine each outcome, score it and execute the best one.",
        key: [{ glyph: "k*", meaning: "index of the chosen chunk" }, "N", "score", "pphi", "o", "achunk"] },
      { name: "Policy-rank correlation", ref: "X3 Table III", term: "policy-rank-correlation",
        tex: "\\rho_s = 1 - \\frac{6 \\sum_i d_i^2}{n(n^2 - 1)}",
        words: "Spearman correlation between the policy ranking in the world model and on the real robot; 1 means identical order.",
        key: [{ glyph: "ρₛ", meaning: "Spearman rank correlation" }, { glyph: "dᵢ", meaning: "rank difference of policy i" }, { glyph: "n", meaning: "number of policies" }] }
    ],
    algorithm: {
      title: "RL post-training inside a world model", ref: "P03 eq. 16–19 · WMPO · World-Env", prov: "Our summary of the shared recipe",
      lines: [
        '<span class="kw">input</span> imitation-trained policy <span data-sym="pi">π_θ</span>, world model <span data-sym="pphi">p_φ</span>, judge <span data-sym="score">S</span>, real start frames',
        'refit <span data-sym="pphi">p_φ</span> on demos ∪ real rollouts of <span data-sym="pi">π_θ</span> <span class="cm">// WMPO: behavior alignment</span>',
        '<span class="kw">repeat</span>:',
        '    take a real start frame <span data-sym="o">o₀</span> and instruction <span data-sym="l">ℓ</span>',
        '    <span class="kw">for</span> i = 1 … <span data-sym="N">N</span>: alternate <span data-sym="achunk">chunk</span> ~ <span data-sym="pi">π_θ</span> and frames ~ <span data-sym="pphi">p_φ</span> until done',
        '    <span data-sym="score">Sᵢ</span> ← judge(imagined rollout i)',
        '    <span class="kw">if</span> all <span data-sym="score">Sᵢ</span> equal: skip <span class="cm">// dynamic sampling</span>',
        '    <span data-sym="adv">Âᵢ</span> ← (Sᵢ − mean) / std; clipped update of <span data-sym="pi">π_θ</span> (P03 eq. 18)',
        '    every M rounds: run <span data-sym="pi">π_θ</span> on the robot, refit <span data-sym="pphi">p_φ</span> <span class="cm">// eq. 19</span>'
      ]
    },
    playgrounds: [
      {
        id: "imagine", title: "Imagined success against real success", ref: "X3 §V-D · P03 eq. 19 · WMPO", prov: "Illustrative: six-strategy toy, our numbers",
        try: "Watch imagined success climb while real success falls as the policy drifts to the fast swipe. Then add the policy's own rollouts to the model's data, and tick Co-evolution.",
        mount: mountImagine,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "c3-imagine";
          return [
            { target: q("[data-chart]"), title: "Two curves part ways", text: "Dashed is success as the judge sees it in imagination; solid is what the robot would achieve. Training pushes the dashed curve up and the solid one down." },
            { target: q("canvas"), title: "The exploited strategy", text: "The policy now uses the fast swipe. The model never saw it in the demos and predicts a lift where the real mug falls." },
            { target: q("#" + id + "-data"), title: "Show it the policy", text: "WMPO fits its world model on 128 real rollouts of the base policy, failures included. The swipe's hallucination shrinks.", do: function (a) { return a.click(q("#" + id + '-data [value="aligned"]')); }, task: "Choose + rollouts", expect: function () { return api.state().align; } },
            { target: q("#" + id + "-co"), title: "Keep refitting", text: "Co-evolution refits the model on 32 real rollouts every 10 rounds, so whatever the policy starts to exploit gets corrected.", do: function (a) { return a.click(q("#" + id + "-co")); }, task: "Tick Co-evolution", expect: function () { return api.state().co; } },
            { target: q("#" + id + "-fp"), title: "A lenient judge", text: "A judge that passes failures inflates imagined success for every strategy. The gap grows, though the chosen strategy barely changes here.", do: function (a) { return a.set(q("#" + id + "-fp"), 0.3); }, task: "Raise judge false positives to 30%", expect: function () { return api.state().fp >= 0.25; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Look at the handle grasp: best on the robot, underestimated by the model, rarely tried. Ctrl-World also found imagined rollouts underestimate execution success." }
          ];
        }
      },
      {
        id: "rank", title: "Rank candidate chunks before acting", ref: "GPC, arXiv 2502.00622 · X3 §V-B", prov: "Illustrative: scored-proposal toy, our numbers",
        try: "Raise N and watch the real score of the pick rise. Then allow 10% unusual proposals the model over-rates: with large N the ranker picks some of them and the real gain flattens.",
        mount: mountRank,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "c3-rank";
          return [
            { target: q("canvas"), title: "Sixteen proposals", text: "A frozen policy proposed 16 chunks. The world model predicts each outcome with some error; the ranker executes the highest prediction." },
            { target: q("#" + id + "-n"), title: "More candidates help", text: "With 128 candidates the pick scores well above the policy alone. GPC raised vision Push-T from 0.642 to 0.739 with 100 proposals.", do: function (a) { return a.set(q("#" + id + "-n"), 7); }, task: "Set candidates N to 128", expect: function () { return api.state().N >= 128; } },
            { target: q("#" + id + "-f"), title: "Actions it never saw", text: "Now 10% of proposals are unusual moves the model over-rates by 0.45. Their dots sit high on the left, and some win the ranking.", do: function (a) { return a.set(q("#" + id + "-f"), 0.1); }, task: "Set unusual proposals to 10%", expect: function () { return api.state().f >= 0.1; } },
            { target: q("[data-chart]"), title: "Search amplifies bias", text: "The dashed predicted score keeps rising with N while the real score flattens far below it. X3 warns that search optimizes against the same imperfect predictor." },
            { target: q("#" + id + "-sig"), title: "Your turn", text: "Set unusual proposals back to 0 and raise σ to 0.3. Noise alone flattens the gain; it does not reverse it. Each candidate costs one world-model rollout." }
          ];
        }
      },
      {
        id: "judge", title: "Rank six checkpoints in imagination", ref: "X3 Table III · WorldEval · SIMPLER MMRV", prov: "Illustrative: six-checkpoint toy, our numbers",
        try: "Lower the judge's catch rate to 60%: the fit slope drops but ρₛ stays near 1. Then raise the world-model error to 0.2 and cut rollouts to 5.",
        mount: mountJudge,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "c3-judge";
          return [
            { target: q("canvas"), title: "A good evaluator", text: "Six checkpoints A to F, each rolled out 20 times in the world model. The dots rise in order, so the ranks match." },
            { target: q("#" + id + "-tpr"), title: "A strict judge", text: "A judge that misses 40% of successes scales every rate down. Absolute numbers are off, yet the order survives, so ρₛ stays high.", do: function (a) { return a.set(q("#" + id + "-tpr"), 0.6); }, task: "Set the catch rate to 60%", expect: function () { return api.state().tpr <= 0.65; } },
            { target: q("#" + id + "-sig"), title: "An unfaithful model", text: "Now the world model shifts each checkpoint by its own error. Neighbors swap places and MMRV, the worst rank flip weighted by real gap, rises.", do: function (a) { return a.set(q("#" + id + "-sig"), 0.2); }, task: "Set world-model error to 0.20", expect: function () { return api.state().sig >= 0.18; } },
            { target: q("#" + id + "-n"), title: "Too few rollouts", text: "With five rollouts each, sampling noise adds to model error. WorldEval ran 40 rollouts per task.", do: function (a) { return a.set(q("#" + id + "-n"), 5); }, task: "Set rollouts per checkpoint to 5", expect: function () { return api.state().n <= 5; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Press Evaluate again a few times at σ = 0.2 and 100 rollouts. More rollouts cannot fix a systematic model error." }
          ];
        }
      }
    ],
    methodsLede: "How the line evolved: World-Env moved RIPT-VLA's reinforcement learning (RL) from a physics simulator into a video world model with a VLM judge. VLA-RFT swapped that judge for a verified reward. WMPO aligned a pixel-space model to the policy's own rollouts. World-VLA-Loop and WoVR refit the model with policy failures. WorldEval, WorldGym and Ctrl-World rank policies in imagination; GPC ranks candidate chunks; DreamGen turns generated video into training data.",
    methods: ["world-env", "vla-rft", "wmpo", "world-vla-loop", "wovr", "gpc", "vla-reasoner", "worldeval", "worldgym", "ctrl-world", "dreamgen"],
    open: [
      { title: "Benchmarks for exploitation", text: "Few benchmarks test whether a policy optimized inside a learned world finds shortcuts that fail on the robot. X3 asks for held-out scenes and rollout-depth stress tests.", refs: "X3 §VIII-C–D" },
      { title: "Calibrated predictions", text: "A world model should know when its prediction for a candidate action is unreliable. Few benchmarks test calibration, and confident hallucinations are the most dangerous.", refs: "X3 §VIII-D" },
      { title: "Judges share the generator's blind spots", text: "A verifier trained on the same data as the world model may miss the same contact or feasibility errors. Independent signals or real calibration help.", refs: "X3 §V-E" },
      { title: "Videos without executable actions", text: "Generated videos may show success without the forces or actions to achieve it; recovered pseudo-actions can be misaligned with the pixels.", refs: "P05 §5.5.3 · X3 §V-A" }
    ],
    takeaways: [
      "P03 separates two uses: the world model as a simulator for RL and as an evaluator that scores candidate actions.",
      "RL in imagination needs a judge; World-Env, VLA-RFT and WMPO differ mainly in reward design and how they fit the model.",
      "Optimization seeks out simulator errors, so the second wave refits the world model on the policy's own rollouts (co-evolution).",
      "Candidate reranking only improves what the policy proposes, and larger searches amplify model bias.",
      "Judge a world-model evaluator by rank agreement with real trials (Spearman, MMRV), not by how real its videos look."
    ],
    quiz: [
      { q: "Why does WMPO fine-tune its video world model on real rollouts of the base policy?", options: ["To make the videos sharper", "So it predicts the policy's own states, including failures", "To remove the need for a judge", "To speed up sampling"], correct: 1, why: "Behavior alignment exposes the model to the states and failures the policy actually visits. With 128 such rollouts WMPO reached 47.1% versus 33.2% for GRPO on real rollouts (arXiv 2511.09515)." },
      { q: "All eight imagined rollouts in a group fail. What does WMPO do with the group?", options: ["Gives each rollout advantage −1", "Drops it: zero spread gives no signal", "Doubles the learning rate", "Asks a human to label it"], correct: 1, why: "The group-normalized advantage divides by the standard deviation, which is zero. WMPO's dynamic sampling discards all-success and all-fail groups." },
      { q: "When can candidate reranking with a world model not help?", options: ["When the world model is fast", "When the policy never proposes a successful action", "When N is larger than one", "When the task uses a gripper"], correct: 1, why: "X3 §V-B calls this proposal dependence: filtering only chooses among the actions it receives, so it cannot create a missing solution." },
      { q: "An evaluator reports every checkpoint 15 points below its real success, in the same order. What is Spearman ρₛ?", options: ["0", "1", "−1", "It cannot be computed"], correct: 1, why: "Rank correlation compares only the order. Ctrl-World's imagined success fit 0.81x − 0.11 against real success, yet it tracked which policies were better (arXiv 2510.10125)." },
      { q: "Why does X3 call simulator exploitation worse than ordinary prediction error?", options: ["It only happens in navigation", "Policy optimization actively searches for the model's weaknesses", "It makes rollouts slower", "It needs more GPUs"], correct: 1, why: "A passive error stays where it is; an optimizer is drawn to it, because a wrong optimistic prediction looks like high reward (X3 §V-D)." }
    ],
    cards: [
      { front: "What two uses of world models does P03 Fig. 5 show?", back: "A learned simulator that produces imagined transitions for RL, and an evaluator that scores imagined outcomes of candidate actions.", ref: "P03 Fig. 5" },
      { front: "How does VLA-RFT reward an imagined rollout?", back: "Negative L1 plus perceptual (LPIPS) distance between world-model rollouts of the policy's actions and of expert actions.", ref: "arXiv 2510.00406" },
      { front: "What does P03 eq. 19 alternate?", back: "Refitting the world model on real and current-policy data, and updating the policy on imagined data from the refit model.", ref: "P03 eq. 19" },
      { front: "Name X3's three lifecycle stages for world models.", back: "Prior during pretraining, refine during post-training, adapt at inference.", ref: "X3 Fig. 5" },
      { front: "What is a neural trajectory in DreamGen?", back: "A generated robot video labeled with pseudo-actions from an inverse dynamics model or latent actions, used to train a policy.", ref: "arXiv 2505.12705" },
      { front: "Which three simulator-reliability metrics does X3 Table III list?", back: "Spearman policy-rank correlation, hallucination rate and rollout divergence.", ref: "X3 Table III" },
      { front: "How closely did WorldEval's rankings match real trials?", back: "Average Pearson 0.942 and MMRV 0.044, against 0.411 and 0.261 for a real-to-sim simulator.", ref: "arXiv 2505.19017" }
    ],
    terms: {
      "learned-environment": { name: "learned environment", aliases: ["learned simulator", "world simulator", "world model as simulator"], group: "world", sym: "p_φ", symTex: "p_\\phi", def: "A world model used as a virtual environment in which policies are rolled out, compared, refined or stress-tested instead of the real robot.", note: "It supports closed-loop interaction, unlike synthetic data generation, which only produces offline supervision.", ref: "X3 §V-D · P03 §4", scene: "system", focus: ["world-model", "simulator", "policy-update"], look: "the policy acting inside the world model", uses: [] },
      "outcome-scoring": { name: "outcome scoring", aliases: ["instant reflector", "success classifier", "reward model in imagination"], group: "trust", sym: "S", symTex: "S", def: "Turning imagined futures into rewards, progress estimates, preferences or feasibility judgments that guide learning or decisions.", note: "Scoring asks how good an outcome is; verification asks whether the imagined transition should be trusted at all.", ref: "X3 §V-E", scene: "system", focus: ["reward-model", "predicted-future"], look: "the judge reading the imagined future", uses: ["learned-environment"] },
      "simulator-exploitation": { name: "simulator exploitation", aliases: ["exploiting the learned simulator", "reward hacking in imagination"], group: "trust", def: "A policy trained in a learned environment discovering behaviors that exploit model artifacts rather than transferable manipulation skills.", note: "Worse than passive prediction error, because optimization actively searches for the simulator's weaknesses.", ref: "X3 §V-D", scene: "system", focus: ["world-model", "policy-update"], look: "the policy drifting toward model artifacts", uses: ["learned-environment"] },
      "co-evolution": { name: "co-evolution", aliases: ["world-model–policy co-evolution", "closed-loop world-model refinement"], group: "world", def: "Alternating updates in which policy rollouts refine the world model and the refined model produces better imagined data for the policy.", note: "World-VLA-Loop, VLAW and WoVR are the surveyed examples; P03 writes it as eq. 19.", ref: "P03 eq. 19", scene: "system", focus: ["world-model", "policy-update", "robot"], look: "real rollouts flowing back into the model", uses: ["learned-environment"] },
      "group-relative-advantage": { name: "group-relative advantage", aliases: ["GRPO advantage", "group-normalized advantage"], group: "learning", sym: "Âᵢ", symTex: "\\hat A_i", def: "A rollout's reward minus the mean reward of its group, divided by the group's standard deviation; it replaces a learned critic.", note: "Groups with identical rewards give zero spread, so WMPO drops them (dynamic sampling).", ref: "WMPO, arXiv 2511.09515 · P03 eq. 18", scene: "system", focus: ["policy-update", "reward-model"], look: "scores turning into policy updates", uses: [] },
      "verified-reward": { name: "verified reward", aliases: ["trajectory-similarity reward"], group: "learning", def: "VLA-RFT's reward: the negative pixel and perceptual distance between world-model rollouts of the policy's actions and of expert actions.", note: "It cannot reward doing better than the expert, since similarity to the expert is the target.", ref: "arXiv 2510.00406", scene: "system", focus: ["reward-model", "predicted-future"], look: "two imagined rollouts compared frame by frame", uses: ["outcome-scoring"] },
      "candidate-reranking": { name: "candidate reranking", aliases: ["candidate-action filtering", "GPC-RANK", "generative predictive control"], group: "world", def: "An existing policy proposes actions or chunks; a world model filters, reranks or refines them by predicted feasibility, progress or success.", note: "It can only improve what it receives: if no proposal succeeds, scoring cannot recover one.", ref: "X3 §V-B", scene: "system", focus: ["world-model", "action-chunk", "planner"], look: "several chunks scored before one runs", uses: ["action-chunk"] },
      "search-based-action-evaluation": { name: "search-based action evaluation", aliases: ["MCTS in imagination", "world-model search"], group: "world", def: "Placing the world model inside a repeated decision procedure, such as tree search or model-predictive control, that queries it many times per decision.", note: "Search can amplify the usefulness of a calibrated model, and also its bias.", ref: "X3 §V-C", scene: "system", focus: ["planner", "world-model"], look: "the planner querying the model repeatedly", uses: ["candidate-reranking"] },
      "neural-trajectory": { name: "neural trajectory", aliases: ["synthetic robot video with pseudo-actions"], group: "data", def: "A robot video generated by a fine-tuned video world model and labeled with pseudo-actions from an inverse dynamics model or latent actions.", note: "DreamGen trains policies on them; the video may look right while the recovered actions are not executable.", ref: "arXiv 2505.12705 · P05 §5.5.3", scene: "system", focus: ["world-model", "data-sim"], look: "generated video becoming training data", uses: [] },
      "policy-rank-correlation": { name: "policy-rank correlation", aliases: ["Spearman rank correlation", "rank agreement"], group: "eval", def: "The Spearman correlation between how a learned simulator and the real world rank the same policies; higher is better.", note: "A simulator can be off in absolute success rates and still rank perfectly.", ref: "X3 Table III", scene: "system", focus: ["world-model", "verifier"], look: "the evaluator ordering policies", uses: ["learned-environment"] },
      "mean-maximum-rank-violation": { name: "mean maximum rank violation", aliases: ["MMRV"], group: "eval", def: "For each policy, the largest real-success gap to any policy it is wrongly ordered against; averaged over policies. Lower is better.", note: "Unlike Spearman, it weights a swap by how different the two policies really are.", ref: "SIMPLER eq. 1–2 · arXiv 2505.19017", scene: "system", focus: ["verifier"], look: "rank flips weighted by real gaps", uses: ["policy-rank-correlation"] },
      "hallucination-rate": { name: "hallucination rate", aliases: ["infeasible-transition rate"], group: "eval", def: "The fraction of generated transitions that violate physical or task constraints, such as penetration, teleportation or disappearing objects.", note: "Pixel metrics such as PSNR and FVD do not measure it.", ref: "X3 Table III, §VIII-C", scene: "system", focus: ["predicted-future", "world-model"], look: "an imagined frame breaking physics", uses: [] },
      "prior-refine-adapt-lifecycle": { name: "prior, refine, adapt lifecycle", aliases: ["world-model lifecycle"], group: "world", def: "X3's view of when a world model enters robot learning: a predictive prior in pretraining, a refinement tool in post-training, an adaptation mechanism at inference.", note: "Each stage has its own risk: weak action alignment, simulator exploitation, then latency and miscalibration.", ref: "X3 §VI, Fig. 5", scene: "system", focus: ["world-model", "policy-update", "planner"], look: "the world model at three stages", uses: ["learned-environment"] }
    },
    symbols: [
      { id: "pphi", tex: "p_\\phi", glyph: "p_φ", kind: "Functions", meaning: "learned world model used as a simulator, with parameters φ", short: "world model (simulator)", first: "c3", read: "p phi", papers: "P03 eq. 16: p_ϕ · WMPO: p_ϕ · GPC: W · WorldGym: T̂ · Ctrl-World: W" }
    ],
    ledger: [
      { where: "Topic 12 · rules", source: "P03 writes the simulator as p_ϕ and the imagined trajectory as τ̂; GPC writes W, R and K proposals", page: "The site writes p_φ, ξ̂, the judge as S and the proposal count as N", why: "House notation: p_θ and π_θ would share θ, and K is the step count elsewhere.", kind: "Our choice" },
      { where: "Topic 12 · worked example", source: "WMPO normalizes by std({Rᵢ}) without saying which standard deviation", page: "The example uses the population standard deviation (divide by N)", why: "Gives ±1.00 for a half-successful group, which is easy to check by hand.", kind: "Our choice" },
      { where: "Topic 12 · playground 1", source: "Real systems train video world models and VLA policies with GRPO or PPO", page: "Six discrete strategies, a softmax policy and a world model whose error shrinks with coverage", why: "Shows exploitation and co-evolution in a few milliseconds.", kind: "Simplified" },
      { where: "Topic 12 · playgrounds 2–3", source: "GPC and WorldEval use learned video models, reward models and VLM judges", page: "Scores are drawn from Gaussians and Bernoulli trials with our parameters", why: "Isolates the effect of model error, proposal count and judge errors.", kind: "Simplified" },
      { where: "Topic 12 · rank agreement", source: "X3 Table III writes the simulator-reliability criterion as Spearman rank correlation and credits WorldGym", page: "WorldGym itself reports Pearson r (0.78); WorldEval reports Pearson and MMRV", why: "The playground shows all three; they can disagree.", kind: "Sources disagree" }
    ]
  });
})();
