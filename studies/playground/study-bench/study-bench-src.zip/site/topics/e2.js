/* Topic 16 · Dexterous and in-hand manipulation. Sources: P01 §4.3, P07 §4.3.3, P10 §6, P06 §3.3.1, P05 §3.3, §8.5, method cards (topic E2). */
(function () {
  "use strict";
  var RB = window.RB;
  var D2R = Math.PI / 180;
  /* StudyBench.segmented passes the value string; RB.bindSeg reads .value of it, so wire segments directly */
  function onSeg(root, id, cb) { StudyBench.segmented(root.querySelector("#" + id), function (v) { cb(v); }); }

  /* ---------- shared planar hand kinematics (toy, centimeters, wrist at the origin, fingers point up) ---------- */
  /* A finger is a planar chain: base point, base direction (degrees, 90 = up), link lengths, curl sign (+1 curls toward the thumb side). */
  function chain(b, d, L, q, s) {
    var pts = [[b[0], b[1]]], a = d * D2R, x = b[0], y = b[1];
    for (var i = 0; i < L.length; i++) { a += s * q[i] * D2R; x += L[i] * Math.cos(a); y += L[i] * Math.sin(a); pts.push([x, y]); }
    return pts;
  }
  /* Human hand: 1 wrist + 5 fingers x 4 keypoints = 21 keypoints (the usual hand-tracker layout). */
  var HUMAN = [
    { n: "thumb", b: [-2.6, 1.6], d: 125, L: [4.4, 3.2, 2.8], s: -1 },
    { n: "index", b: [-2.4, 9.0], d: 95, L: [4.2, 2.5, 2.0], s: 1 },
    { n: "middle", b: [-0.8, 9.4], d: 90, L: [4.6, 2.9, 2.2], s: 1 },
    { n: "ring", b: [0.8, 9.1], d: 85, L: [4.3, 2.7, 2.1], s: 1 },
    { n: "pinky", b: [2.3, 8.4], d: 78, L: [3.4, 2.1, 1.9], s: 1 }
  ];
  /* joint flexion (degrees) per finger; the pinch and tripod angles put the thumb tip 0.4 cm from the index tip */
  var POSES = {
    pinch: [[5, 10, 7], [5, 80, 56], [10, 10, 5], [10, 10, 5], [10, 10, 5]],
    tripod: [[5, 10, 7], [5, 80, 56], [0, 45, 32], [10, 10, 5], [10, 10, 5]],
    power: [[20, 20, 10], [60, 60, 40], [60, 60, 40], [60, 60, 40], [60, 60, 40]],
    open: [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]]
  };
  function humanHand(pose) { return HUMAN.map(function (f, i) { return chain(f.b, f.d, f.L, POSES[pose][i], f.s); }); }
  /* Robot hands: longer, uniform links with joint limits; map = which human finger drives each robot finger. */
  var ROBOTS = {
    two: [
      { b: [-2.4, 2.2], d: 120, L: [4.6, 4.0, 3.2], s: -1, lo: [-10, 0, 0], hi: [90, 90, 90], map: 0 },
      { b: [-1.2, 9.4], d: 92, L: [5.2, 4.0, 3.0], s: 1, lo: [-20, 0, 0], hi: [95, 95, 95], map: 1 }
    ],
    four: [
      { b: [-3.0, 2.0], d: 122, L: [5.0, 4.0, 3.2], s: -1, lo: [-10, 0, 0], hi: [90, 90, 90], map: 0 },
      { b: [-2.6, 9.6], d: 95, L: [5.4, 3.8, 3.0], s: 1, lo: [-20, 0, 0], hi: [95, 95, 95], map: 1 },
      { b: [0, 10.0], d: 90, L: [5.4, 3.8, 3.0], s: 1, lo: [-20, 0, 0], hi: [95, 95, 95], map: 2 },
      { b: [2.6, 9.6], d: 85, L: [5.4, 3.8, 3.0], s: 1, lo: [-20, 0, 0], hi: [95, 95, 95], map: 3 }
    ]
  };

  /* Keyvector retargeting: minimize sum_i |v_i^R(q) - eta v_i^H|^2 + w_p sum_i |v_0i^R(q) - eta v_0i^H|^2
     by normalized gradient descent with finite differences, projected onto the joint limits. */
  function retarget(robot, pose, eta, wp) {
    var H = humanHand(pose), R = ROBOTS[robot], n = R.length * 3, q = [];
    var tipsH = H.map(function (c) { return c[3]; });
    R.forEach(function () { q.push(20, 20, 20); });
    function tips(qq) { return R.map(function (f, i) { return chain(f.b, f.d, f.L, qq.slice(i * 3, i * 3 + 3), f.s)[3]; }); }
    function energy(qq) {
      var T = tips(qq), e = 0;
      R.forEach(function (f, i) {
        var h = tipsH[f.map], dx = T[i][0] - eta * h[0], dy = T[i][1] - eta * h[1];
        e += dx * dx + dy * dy;
        if (i > 0 && wp > 0) { var ht = tipsH[0], vx = (T[i][0] - T[0][0]) - eta * (h[0] - ht[0]), vy = (T[i][1] - T[0][1]) - eta * (h[1] - ht[1]); e += wp * (vx * vx + vy * vy); }
      });
      return e;
    }
    function clampQ(qq) { return qq.map(function (v, j) { var f = R[Math.floor(j / 3)], k = j % 3; return Math.max(f.lo[k], Math.min(f.hi[k], v)); }); }
    for (var it = 0; it < 500; it++) {
      var e0 = energy(q), g = [], gn = 0;
      for (var j = 0; j < n; j++) { var qq = q.slice(); qq[j] += 0.5; var gj = (energy(qq) - e0) / 0.5; g.push(gj); gn += gj * gj; }
      gn = Math.sqrt(gn) || 1;
      var step = Math.min(4, e0 / gn), moved = false;
      for (var tries = 0; tries < 3 && !moved; tries++) {
        var qn = clampQ(q.map(function (v, k2) { return v - step * g[k2] / gn; }));
        if (energy(qn) < e0) { q = qn; moved = true; } else step *= 0.3;
      }
      if (!moved) break;
    }
    var T = tips(q), err = 0, lim = 0;
    R.forEach(function (f, i) { var h = tipsH[f.map]; err += Math.hypot(T[i][0] - eta * h[0], T[i][1] - eta * h[1]); });
    q.forEach(function (v, j) { var f = R[Math.floor(j / 3)], k = j % 3; if (v <= f.lo[k] + 0.5 || v >= f.hi[k] - 0.5) lim++; });
    var chains = R.map(function (f, i) { return chain(f.b, f.d, f.L, q.slice(i * 3, i * 3 + 3), f.s); });
    return {
      H: H, chains: chains, q: q, err: err / R.length, lim: lim,
      pinH: eta * Math.hypot(tipsH[1][0] - tipsH[0][0], tipsH[1][1] - tipsH[0][1]),
      pinR: Math.hypot(T[1][0] - T[0][0], T[1][1] - T[0][1]),
      targets: R.map(function (f) { return [eta * tipsH[f.map][0], eta * tipsH[f.map][1]]; })
    };
  }

  function mountRetarget(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-robot", label: "Robot hand", value: "four", options: [{ value: "two", label: "2-finger" }, { value: "four", label: "4-finger" }] }) +
      RB.seg({ id: id + "-pose", label: "Human pose", value: "pinch", options: [{ value: "pinch", label: "Pinch" }, { value: "tripod", label: "Tripod" }, { value: "power", label: "Power" }, { value: "open", label: "Open" }] }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-eta", label: "Scale η", min: 0.8, max: 1.4, step: 0.05, value: 1, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-wp", label: "Pinch weight w_p", min: 0, max: 4, step: 0.5, value: 0, fmt: function (v) { return (+v).toFixed(1); } }) + "</div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Left: a human hand with 21 keypoints. Right: the robot hand after retargeting, with its fingertip targets"></canvas>' +
      '<figcaption class="sb-caption">Left: the 21 human keypoints; ringed tips feed the energy, faded fingers are dropped. Right: crosses are the scaled targets, red lines the leftover fingertip error.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "used", k: "Human keypoints used" }, { id: "err", k: "Mean fingertip error", u: "cm" }, { id: "pinch", k: "Thumb–index gap: human × η → robot", u: "cm" }, { id: "lim", k: "Robot joints at a limit" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "thumb", kind: "line" }, { c: "data-2", label: "index", kind: "line" }, { c: "data-3", label: "other fingers", kind: "line" }, { c: "bad", label: "fingertip error", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 560, H = 360;
    var st = { robot: "four", pose: "pinch", eta: 1, wp: 0 }, res = null;
    var FINGER_COL = ["data-1", "data-2", "data-3", "data-3", "data-3"];
    function colFor(humanIdx) { return FINGER_COL[humanIdx]; }
    function draw() {
      if (!res) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), sc = 12;
      var mono = getComputedStyle(document.body).getPropertyValue("--font-mono");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P.line; c.beginPath(); c.moveTo(W / 2, 14); c.lineTo(W / 2, H - 14); c.stroke();
      var mapped = ROBOTS[st.robot].map(function (f) { return f.map; });
      function P2(o, p) { return [o[0] + p[0] * sc, o[1] - p[1] * sc]; }
      /* human */
      var oh = [165, H - 30];
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + mono; c.fillText("human hand · 21 keypoints", 14, 20);
      res.H.forEach(function (ch, i) {
        var used = mapped.indexOf(i) >= 0;
        c.globalAlpha = used ? 1 : 0.3; c.strokeStyle = P[colFor(i)]; c.lineWidth = 2.5;
        var w0 = P2(oh, [0, 0]); c.beginPath(); c.moveTo(w0[0], w0[1]);
        ch.forEach(function (p) { var z = P2(oh, p); c.lineTo(z[0], z[1]); }); c.stroke();
        ch.forEach(function (p) { var z = P2(oh, p); c.fillStyle = P[colFor(i)]; c.beginPath(); c.arc(z[0], z[1], 2.6, 0, Math.PI * 2); c.fill(); });
        if (used) { var tz = P2(oh, ch[3]); c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.arc(tz[0], tz[1], 6, 0, Math.PI * 2); c.stroke(); }
        c.globalAlpha = 1; c.lineWidth = 1;
      });
      var wz = P2(oh, [0, 0]); c.fillStyle = P.ink; c.beginPath(); c.arc(wz[0], wz[1], 5, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText("wrist", wz[0] + 8, wz[1] + 4);
      /* robot */
      var orr = [W / 2 + 160, H - 30];
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + mono; c.fillText((st.robot === "two" ? "2-finger" : "4-finger") + " robot hand · η = " + st.eta.toFixed(2), W / 2 + 14, 20);
      var rw = P2(orr, [0, 0]); c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"];
      c.beginPath(); c.moveTo(rw[0] - 34, rw[1]); c.lineTo(rw[0] + 34, rw[1]); c.lineTo(rw[0] + 30, rw[1] - 9.6 * sc); c.lineTo(rw[0] - 30, rw[1] - 9.6 * sc); c.closePath(); c.globalAlpha = 0.5; c.fill(); c.globalAlpha = 1; c.stroke();
      c.fillStyle = P.ink; c.beginPath(); c.arc(rw[0], rw[1], 5, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText("palm", rw[0] - 12, rw[1] - 30);
      ROBOTS[st.robot].forEach(function (f, i) {
        var ch = res.chains[i], tg = P2(orr, res.targets[i]), tip = P2(orr, ch[3]);
        c.strokeStyle = P["line-strong"]; c.lineWidth = 7; c.lineCap = "round"; c.beginPath();
        ch.forEach(function (p, k) { var z = P2(orr, p); if (k) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke();
        c.strokeStyle = P[colFor(f.map)]; c.lineWidth = 3; c.beginPath();
        ch.forEach(function (p, k) { var z = P2(orr, p); if (k) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke(); c.lineCap = "butt";
        ch.forEach(function (p) { var z = P2(orr, p); c.fillStyle = P.surface; c.strokeStyle = P.ink; c.lineWidth = 1.2; c.beginPath(); c.arc(z[0], z[1], 3, 0, Math.PI * 2); c.fill(); c.stroke(); });
        c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.moveTo(tg[0] - 5, tg[1] - 5); c.lineTo(tg[0] + 5, tg[1] + 5); c.moveTo(tg[0] + 5, tg[1] - 5); c.lineTo(tg[0] - 5, tg[1] + 5); c.stroke();
        if (Math.hypot(tg[0] - tip[0], tg[1] - tip[1]) > 2) { c.strokeStyle = P.bad; c.lineWidth = 2; c.beginPath(); c.moveTo(tip[0], tip[1]); c.lineTo(tg[0], tg[1]); c.stroke(); }
        c.lineWidth = 1;
      });
    }
    function run() {
      res = retarget(st.robot, st.pose, st.eta, st.wp);
      var nf = ROBOTS[st.robot].length;
      RB.setRO(body, "used", (1 + nf) + " of 21");
      RB.setRO(body, "err", RB.fmt(res.err, 2));
      RB.setRO(body, "pinch", RB.fmt(res.pinH, 1) + " → " + RB.fmt(res.pinR, 1));
      RB.setRO(body, "lim", String(res.lim));
      var msg;
      if (st.robot === "two" && (st.pose === "power" || st.pose === "tripod")) msg = "The 2-finger hand has no fingers for the human middle, ring and little fingers, so their keypoints are dropped: the robot cannot copy this grasp.";
      else if (res.err > 1 && st.wp === 0 && (st.pose === "pinch" || st.pose === "tripod")) msg = "The scaled targets lie beyond the robot's reach. Each fingertip gets as close as it can on its own, and the pinch opens. Raise the pinch weight.";
      else if (st.wp > 0 && res.err > 1) msg = "The pinch term trades fingertip accuracy for contact: the thumb and index tips stay together while both drift from their targets.";
      else if (res.lim > 2) msg = "Several joints sit at a limit: the robot finger cannot bend backward like the relaxed human finger, so a small error remains.";
      else msg = "Every mapped fingertip reaches its scaled target. Change the scale η or the robot hand to see where retargeting breaks.";
      note.textContent = msg;
      draw();
    }
    var fmt2 = function (v) { return (+v).toFixed(2); }, fmt1 = function (v) { return (+v).toFixed(1); };
    onSeg(body, id + "-robot", function (v) { st.robot = v; run(); });
    onSeg(body, id + "-pose", function (v) { st.pose = v; run(); });
    RB.bindSlider(body, id + "-eta", fmt2, function (v) { st.eta = v; run(); });
    RB.bindSlider(body, id + "-wp", fmt1, function (v) { st.wp = v; run(); });
    RB.onTheme(draw);
    run();
    return { get: function () { return { robot: st.robot, pose: st.pose, eta: st.eta, wp: st.wp, pinR: res.pinR, err: res.err }; } };
  }

  /* ---------- playground 2: demonstrations plus RL with a sparse reward (DAPG idea) ---------- */
  /* Toy: d joints must move from 0 to a random goal in T steps. Policy: a_j = theta_j (g_j - x_j) + noise.
     Reward is 1 only if the final error is within 1.3 SIG sqrt(d). Gradient: REINFORCE with a mean baseline, normalized step. */
  var T_STEPS = 8, SIG = 0.25, N_ROLL = 30, ITERS = 60, SEEDS = 3;
  function dRollout(th, d, R) {
    var x = [], g = [], gl = [], j, t;
    for (j = 0; j < d; j++) { x.push(0); g.push(1 + 0.3 * R.normal()); gl.push(0); }
    for (t = 0; t < T_STEPS; t++) for (j = 0; j < d; j++) { var e = g[j] - x[j], m = th[j] * e, a = m + SIG * R.normal(); gl[j] += (a - m) * e / (SIG * SIG); x[j] += a; }
    var err = 0; for (j = 0; j < d; j++) err += (x[j] - g[j]) * (x[j] - g[j]);
    return { ok: Math.sqrt(err) < 1.3 * SIG * Math.sqrt(d) ? 1 : 0, gl: gl };
  }
  function dDemos(d, bias, R) {
    var th = [], S = [], j, k, t;
    for (j = 0; j < d; j++) th.push(0.5 * (1 + bias * R.normal()));
    for (k = 0; k < 25; k++) { var x = [], g = []; for (j = 0; j < d; j++) { x.push(0); g.push(1 + 0.3 * R.normal()); } for (t = 0; t < T_STEPS; t++) for (j = 0; j < d; j++) { var e = g[j] - x[j], a = th[j] * e + 0.05 * R.normal(); S.push([j, e, a]); x[j] += a; } }
    return S;
  }
  function dTrain(method, d, bias, seed) {
    var R = RB.rng(seed), S = dDemos(d, bias, R), th = [], j, k;
    for (j = 0; j < d; j++) th.push(0);
    if (method !== "scratch") { var num = th.map(function () { return 0; }), den = th.map(function () { return 1e-9; }); S.forEach(function (s) { num[s[0]] += s[1] * s[2]; den[s[0]] += s[1] * s[1]; }); th = num.map(function (v, i) { return v / den[i]; }); }
    var curve = [];
    for (k = 0; k < ITERS; k++) {
      var rs = [], sum = 0, i;
      for (i = 0; i < N_ROLL; i++) { var r = dRollout(th, d, R); rs.push(r); sum += r.ok; }
      var mean = sum / N_ROLL; curve.push(mean);
      if (method === "bc") continue;
      var g = th.map(function () { return 0; }), maxA = 0;
      rs.forEach(function (r) { var A = r.ok - mean; if (A > maxA) maxA = A; for (var jj = 0; jj < d; jj++) g[jj] += r.gl[jj] * A / N_ROLL; });
      if (method === "dapg") { var w = 0.1 * Math.pow(0.95, k) * maxA, per = S.length / d; S.forEach(function (s) { var m = th[s[0]] * s[1]; g[s[0]] += w * (s[2] - m) * s[1] / (SIG * SIG) / per; }); }
      var gn = Math.sqrt(g.reduce(function (a2, v) { return a2 + v * v; }, 0));
      if (gn > 1e-9) for (j = 0; j < d; j++) th[j] += 0.05 * Math.sqrt(d) * g[j] / gn;
    }
    return curve;
  }
  function mountDapg(body, ctx) {
    var id = ctx.id, pct = function (v) { return Math.round(v * 100) + "%"; };
    body.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-d", label: "Joints d", min: 1, max: 24, step: 1, value: 12 }) +
      RB.slider({ id: id + "-bias", label: "Demonstrator mismatch", min: 0, max: 0.6, step: 0.1, value: 0.3, fmt: function (v) { return (+v).toFixed(1); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New seeds ▶</button></div>' +
      '<div class="rb-grid2"><div data-chart></div><div class="rb-stack">' + RB.readouts([{ id: "scratch", k: "RL from scratch, last iteration" }, { id: "bc", k: "Behavior cloning only" }, { id: "dapg", k: "Demos + RL (DAPG-style)" }, { id: "first", k: "First success, from scratch" }]) +
      '<p class="sb-caption" data-note></p><p class="sb-caption">Simplified: linear policy, REINFORCE with a normalized step, 25 demos, 3 seeds. DAPG reports the in-hand pen task in 3.33 robot-hours against 322 for sparse-reward NPG (arXiv 1709.10087).</p></div></div>';
    var host = body.querySelector("[data-chart]"), note = body.querySelector("[data-note]"), st = { d: 12, bias: 0.3, seed: 21 }, out = null, timer = null;
    function run() {
      var names = ["scratch", "bc", "dapg"], curves = {};
      names.forEach(function (m) { var acc = null; for (var s = 0; s < SEEDS; s++) { var c = dTrain(m, st.d, st.bias, st.seed + s * 7); if (!acc) acc = c.slice(); else c.forEach(function (v, i) { acc[i] += v; }); } curves[m] = acc.map(function (v) { return v / SEEDS; }); });
      out = curves;
      var fin = function (m) { var c = curves[m], n = c.length; return (c[n - 1] + c[n - 2] + c[n - 3]) / 3; };
      RB.setRO(body, "scratch", pct(fin("scratch"))); RB.setRO(body, "bc", pct(fin("bc"))); RB.setRO(body, "dapg", pct(fin("dapg")));
      var first = -1; curves.scratch.forEach(function (v, i) { if (first < 0 && v > 0) first = i + 1; });
      RB.setRO(body, "first", first < 0 ? "never" : "iteration " + first);
      note.textContent = first < 0 ? "With " + st.d + " joints a random policy never lands inside the goal region, so every advantage is zero and RL from scratch has nothing to learn from." :
        st.d <= 2 ? "With few joints, random exploration sometimes succeeds, so the sparse reward gives RL from scratch a learning signal." :
        "Successes are rare, so RL from scratch learns slowly. Demonstrations start the policy where successes happen.";
      host.innerHTML = "";
      StudyBench.lineChart(host, { title: "Success rate while training", height: 220, directLabels: false, x: { label: "policy-gradient iteration", min: 1, max: ITERS }, y: { label: "success", min: 0, max: 1, fmt: pct },
        series: [{ name: "RL from scratch", color: "data-3", points: curves.scratch.map(function (v, i) { return [i + 1, v]; }) },
          { name: "behavior cloning only", color: "data-2", dash: true, points: curves.bc.map(function (v, i) { return [i + 1, v]; }) },
          { name: "demos + RL (DAPG-style)", color: "data-1", points: curves.dapg.map(function (v, i) { return [i + 1, v]; }) }],
        caption: "Behavior cloning alone (dashed) stays at the demonstrator's level. Demos + RL keep improving; RL from scratch stays at zero once successes are too rare to find." });
    }
    function later() { if (timer) clearTimeout(timer); timer = setTimeout(run, 60); }
    RB.bindSlider(body, id + "-d", null, function (v) { st.d = v; later(); });
    RB.bindSlider(body, id + "-bias", function (v) { return (+v).toFixed(1); }, function (v) { st.bias = v; later(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed += 100; run(); });
    run();
    return { get: function () { return { d: st.d, bias: st.bias, curves: out }; } };
  }

  /* ---------- concept-card drawings (200 x 56, token colors only) ---------- */
  var ART = {
    dof: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M40 52 V36" class="rb-s-ink"/>' + [-2, -1, 0, 1].map(function (k) { var x = 40 + k * 9; return '<path d="M' + (40 + k * 4) + " 36 L" + (x + 2) + " 22 L" + (x + 4) + " 12 L" + (x + 5) + ' 5" class="rb-s-acc"/><circle cx="' + (x + 2) + '" cy="22" r="2" class="rb-f-acc"/><circle cx="' + (x + 4) + '" cy="12" r="2" class="rb-f-acc"/>'; }).join("") + '<path d="M36 40 L20 30 L12 22" class="rb-s-acc"/><circle cx="20" cy="30" r="2" class="rb-f-acc"/><text x="80" y="24" class="rb-t-mono">20–25 DoF</text><text x="80" y="40" class="rb-t-mono">4 per finger</text></svg>',
    reorient: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="28" y="16" width="24" height="24" rx="2" class="rb-f-soft" transform="rotate(0 40 28)"/><path d="M62 28 H96" class="rb-s-ink"/><path d="M90 23 L96 28 L90 33" class="rb-s-ink"/><rect x="108" y="16" width="24" height="24" rx="2" class="rb-f-acc" transform="rotate(35 120 28)"/><path d="M146 12 A 18 18 0 0 1 150 44" class="rb-s-acc" stroke-dasharray="3 3"/><text x="160" y="32" class="rb-t-mono">goal</text></svg>',
    dapg: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M12 48 H188" class="rb-s-line"/><path d="M12 48 Q60 46 90 30 T188 10" class="rb-s-acc"/><path d="M12 48 Q100 47 188 42" class="rb-s-line" stroke-dasharray="3 3"/><circle cx="12" cy="30" r="4" class="rb-f-soft"/><text x="20" y="22" class="rb-t-mono">demos</text><text x="120" y="54" class="rb-t-mono">RL alone</text><text x="96" y="14" class="rb-t-acc">demos + RL</text></svg>',
    extr: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 40 L20 30 L30 36 L40 24 L50 32 L60 20 L70 28" class="rb-s-line"/><text x="10" y="54" class="rb-t-mono">joint history</text><path d="M76 30 H98" class="rb-s-ink"/><rect x="102" y="18" width="28" height="24" rx="4" class="rb-f-soft"/><text x="116" y="34" text-anchor="middle" class="rb-t-acc">ẑ</text><text x="138" y="26" class="rb-t-mono">mass,</text><text x="138" y="40" class="rb-t-mono">friction</text></svg>',
    touch: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="70" y="20" width="40" height="22" rx="3" class="rb-f-soft"/><path d="M50 8 V30 H70" class="rb-s-ink"/><path d="M130 8 V30 H110" class="rb-s-ink"/>' + [0, 1, 2].map(function (i) { return '<circle cx="' + (60 + i * 4) + '" cy="' + (22 + i * 4) + '" r="1.8" class="rb-f-acc"/>'; }).join("") + '<path d="M16 14 L60 28" class="rb-s-line" stroke-dasharray="3 3"/><rect x="4" y="6" width="14" height="10" rx="2" class="rb-f-surface"/><text x="138" y="30" class="rb-t-mono">camera</text><text x="138" y="44" class="rb-t-mono">blocked</text></svg>',
    retarget: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="20" cy="48" r="3" class="rb-f-acc"/>' + [[8, 14], [18, 8], [28, 10], [38, 16]].map(function (p) { return '<path d="M20 48 L' + p[0] + " " + p[1] + '" class="rb-s-line"/><circle cx="' + p[0] + '" cy="' + p[1] + '" r="2.4" class="rb-f-acc"/>'; }).join("") + '<path d="M60 30 H96" class="rb-s-ink"/><text x="64" y="24" class="rb-t-mono">× η</text><circle cx="130" cy="50" r="3" class="rb-f-acc"/><path d="M130 50 L112 12 M130 50 L150 6" class="rb-s-acc"/><circle cx="112" cy="12" r="3" class="rb-f-surface"/><circle cx="150" cy="6" r="3" class="rb-f-surface"/><text x="162" y="36" class="rb-t-acc">𝐯ᵢ</text></svg>',
    wear: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M20 50 V30 M28 50 V22 M36 50 V20 M44 50 V24 M14 44 L6 34" class="rb-s-line"/><rect x="12" y="36" width="36" height="16" rx="4" class="rb-f-soft"/><text x="30" y="47" text-anchor="middle" class="rb-t-mono">glove</text><path d="M58 40 H94" class="rb-s-ink"/><rect x="98" y="30" width="36" height="22" rx="3" class="rb-f-surface"/><text x="116" y="45" text-anchor="middle" class="rb-t-mono">demos</text><text x="140" y="20" class="rb-t-mono">no robot</text><text x="140" y="34" class="rb-t-mono">needed</text></svg>'
  };

  /* ---------- worked example figure: retarget one fingertip onto a 2-link robot finger ---------- */
  var sx = function (x) { return (190 + x * 13).toFixed(1); }, sy = function (y) { return (292 - y * 13).toFixed(1); };
  function seg(a, b, cls) { return '<path d="M' + sx(a[0]) + " " + sy(a[1]) + " L" + sx(b[0]) + " " + sy(b[1]) + '" class="' + cls + '"/>'; }
  function dot(p, r, cls, style) { return '<circle cx="' + sx(p[0]) + '" cy="' + sy(p[1]) + '" r="' + r + '"' + (cls ? ' class="' + cls + '"' : "") + (style ? ' style="' + style + '"' : "") + "/>"; }
  function lab(p, dx, dy, txt, cls, anchor) { return '<text x="' + (+sx(p[0]) + dx) + '" y="' + (+sy(p[1]) + dy) + '"' + (anchor ? ' text-anchor="' + anchor + '"' : "") + ' class="' + (cls || "rb-t-mono") + '">' + txt + "</text>"; }
  function note(y, txt, cls) { return '<text x="370" y="' + y + '" class="' + (cls || "rb-t-mono") + '">' + txt + "</text>"; }
  var BASE = [0, 10], J1 = [0.78, 14.94], TIP = [-2.21, 17.60], TG11 = [-2.2, 17.6], TG13 = [-2.6, 20.8], STR = [-2.10, 18.75];
  var WE_FIG = '<svg viewBox="0 0 640 300" role="img" aria-label="A human wrist-to-fingertip vector is scaled and a two-link robot finger bends to reach it; a larger scale puts the target out of reach">' +
    dot([0, 0], 5, "rb-f-acc") + lab([0, 0], 10, 4, "wrist") +
    '<g data-on="1+">' + '<path d="M' + sx(0) + " " + sy(0) + " L" + sx(-2) + " " + sy(16) + '" class="rb-s-line" stroke-dasharray="4 4"/>' + dot([-2, 16], 4, "rb-f-surface") + lab([-2, 16], -10, 22, "human tip", "rb-t-mono", "end") + note(40, "1. human tip = (−2.0, 16.0) cm") + "</g>" +
    '<g data-on="2+"><rect x="' + (+sx(0) - 24) + '" y="' + sy(10) + '" width="48" height="' + (10 * 13) + '" rx="4" class="rb-f-soft" opacity="0.5"/>' + dot(BASE, 4, "rb-f-surface") + lab(BASE, 10, 16, "base") +
    '<circle cx="' + sx(0) + '" cy="' + sy(10) + '" r="' + (9 * 13) + '" class="rb-s-line" fill="none" stroke-dasharray="2 5"/>' + dot(TG11, 5, "rb-f-acc") + lab(TG11, 10, -8, "η = 1.1", "rb-t-acc") +
    note(70, "2. target = 1.1 × tip = (−2.2, 17.6)") + note(90, "   7.91 cm from base; reach = 5 + 4 = 9.0") + "</g>" +
    '<g data-on="3-4">' + seg(BASE, J1, "rb-s-ink") + dot(J1, 3.5, "rb-f-surface") + lab(J1, 8, 4, "q₂") + note(120, "3. cos q₂ = 0.54 → q₂ = 57.3°") + "</g>" +
    '<g data-on="4">' + seg(J1, TIP, "rb-s-acc") + lab(BASE, 8, -8, "q₁") + note(150, "4. q₁ = 16.1° − 25.2° = −9.0°") + note(170, "   tip on target: error 0", "rb-t-acc") + "</g>" +
    '<g data-on="5">' + dot(TG13, 5, "", "fill:var(--bad)") + lab(TG13, -10, 4, "η = 1.3", "rb-t-mono", "end") + seg(BASE, STR, "rb-s-ink") + seg(STR, TG13, "rb-s-acc") +
    note(200, "5. target 11.11 cm away > 9.0 reach") + note(220, "   cos q₂ = 2.06: no solution") + note(240, "   straight finger, 2.11 cm short", "rb-t-acc") + "</g></svg>";

  RB.topic({
    id: "e2",
    title: "Dexterous and in-hand manipulation",
    eyebrow: "Part E · Dexterous hands",
    lede: "Multi-fingered hands can twist, roll and reorient objects. Learning to control them takes massive simulation, demonstrations, touch and retargeted human hands.",
    refs: ["P01 §4.3", "P07 §4.3.3", "P10 §6.1.3", "P05 §8.5"],
    why: "A gripper opens and closes; a human-like hand has 20 to 25 degrees of freedom and makes many contacts at once, often hidden from the camera. Rewards are sparse, simulation of contact is imperfect, and demonstrations are hard to collect. This topic shows the recipes that made hands work: randomized simulation, demonstrations plus reinforcement learning, touch, and retargeting.",
    outcomes: [
      "Explain why high-DoF hands make sparse-reward RL from scratch fail.",
      "Compare the Dactyl, DeXtreme, Visual Dexterity and HORA sim-to-real recipes.",
      "Compute a fingertip retargeting solution for a two-link finger by hand.",
      "Predict when a pinch term changes a retargeted grasp.",
      "Describe what touch adds when fingers hide the contact."
    ],
    concepts: [
      { name: "Many joints, many contacts", def: "Human hand models have 20–25 degrees of freedom (DoF): about 4 per finger plus thumb, palm and wrist.", ref: "P01 §4.3", art: ART.dof, term: "dexterous-hand", sym: "qj" },
      { name: "In-hand reorientation", def: "Turn a held object to a goal orientation with the fingers while the wrist stays put.", ref: "P07 §4.3.3", art: ART.reorient, term: "in-hand-reorientation", href: "#lab/grasp" },
      { name: "Demos, then RL", def: "DAPG starts from 25 virtual-reality demos and keeps a decaying demo term in the policy gradient.", ref: "arXiv 1709.10087", art: ART.dapg, term: "demo-augmented-policy-gradient", sym: "wdemo" },
      { name: "Feel the object", def: "HORA encodes object size, mass and friction into 8 numbers and estimates them from joint history.", ref: "arXiv 2210.04887", art: ART.extr, term: "object-extrinsics", sym: "z" },
      { name: "Touch where cameras fail", def: "Fingers hide the contact from cameras; touch sensors report it directly.", ref: "P10 §1.1 · arXiv 2404.16823", art: ART.touch, term: "visuotactile-policy" },
      { name: "Retarget the human hand", def: "Match scaled wrist-to-fingertip and thumb-to-finger vectors instead of copying human joint angles.", ref: "arXiv 2202.10448 · P06 §3.3.1", art: ART.retarget, term: "keyvector-retargeting", sym: "kvec" },
      { name: "Wearable hand capture", def: "Gloves, exoskeletons and headsets record dexterous demonstrations without a robot, then map them to robot hands.", ref: "P05 §3.3, §8.3", art: ART.wear, term: "wearable-hand-capture" }
    ],
    flow: {
      title: "Where dexterity is learned", ref: "P01 §4.3 · P07 §4.3.3", w: 820, h: 290,
      caption: "Two routes feed one hand policy: human demonstrations through retargeting, and reinforcement learning in randomized simulation. Vision, joint encoders and touch close the loop on the real hand.",
      nodes: [
        { id: "human", x: 20, y: 24, w: 140, h: 54, label: "Human hand", sub: "gloves, VR, video", kind: "env" },
        { id: "ret", x: 250, y: 24, w: 150, h: 54, label: "Retargeting", sub: "keypoints → joints", kind: "agent" },
        { id: "sim", x: 20, y: 170, w: 160, h: 54, label: "Randomized sim", sub: "physics, noise, delay", kind: "env" },
        { id: "pol", x: 410, y: 100, w: 150, h: 60, label: "Hand policy", sub: "BC, RL or both", kind: "agent" },
        { id: "hand", x: 660, y: 100, w: 155, h: 60, label: "Robot hand", sub: "PD joint control", kind: "env" },
        { id: "sens", x: 660, y: 210, w: 155, h: 54, label: "Sensors", sub: "vision, joints, touch", kind: "store" }
      ],
      edges: [
        { from: "human", to: "ret", label: "keypoints" },
        { from: "ret", to: "pol", label: "demos", sides: ["r", "t"], via: [[485, 51]] },
        { from: "sim", to: "pol", label: "rollouts", sides: ["r", "l"], via: [[300, 197], [300, 130]] },
        { from: "pol", to: "hand", label: "joint targets", dy: -8 },
        { from: "hand", to: "sens", label: "contact, pose", sides: ["b", "t"] },
        { from: "sens", to: "pol", label: "observations", sides: ["l", "b"], via: [[485, 237]] }
      ],
      steps: [
        { on: ["human", "human>ret", "ret"], text: "Gloves, virtual reality or video give human hand keypoints. Retargeting turns them into joint angles for a robot hand with different fingers." },
        { on: ["ret>pol", "pol"], text: "Retargeted demonstrations train the policy by behavior cloning (BC), or give reinforcement learning (RL) a start: DAPG used 25 demonstrations per task." },
        { on: ["sim", "sim>pol", "pol"], text: "Or RL runs in a simulator whose physics, noise and delays are randomized every episode. Dactyl used about 100 years of simulated experience." },
        { on: ["pol>hand", "hand"], text: "The policy sends joint targets to a PD controller: every 80 ms in Dactyl, at 30 Hz in DeXtreme." },
        { on: ["hand>sens", "sens", "sens>pol"], text: "Cameras, joint encoders and touch close the loop. Fingers hide the object, so joint history and touch fill in what vision misses." }
      ]
    },
    worked: {
      title: "Retarget one fingertip onto a robot finger",
      ref: "Our formulation · arXiv 2202.10448", prov: "Our toy numbers",
      eq: { tex: "\\cos \\class{sym-qj}{q_2} = \\frac{\\|\\mathbf{d}\\|^2 - l_1^2 - l_2^2}{2\\, l_1 l_2}, \\qquad \\mathbf{d} = \\class{sym-eta-ret}{\\eta}\\, \\class{sym-kvec}{\\mathbf{v}^H} - \\mathbf{b}", words: "Scale the human wrist-to-tip vector, subtract the robot finger's base, then bend the middle joint so the two links span that distance.", key: ["qj", "eta-ret", "kvec", { glyph: "d", meaning: "target relative to the finger base" }, { glyph: "l₁, l₂", meaning: "robot link lengths, 5 and 4 cm" }, { glyph: "b", meaning: "finger base on the palm" }] },
      figure: WE_FIG,
      steps: [
        { title: "Read two keypoints", text: "Of the 21 human keypoints, take the wrist (0, 0) and the index tip (−2.0, 16.0) cm." },
        { title: "Scale and shift", text: "The robot hand is bigger: η = 1.1 gives target (−2.2, 17.6). From the base (0, 10) that is 7.91 cm, within the 9.0 cm reach." },
        { title: "Bend the middle joint", text: "cos q₂ = (7.91² − 5² − 4²) / (2·5·4) = 0.54, so q₂ = 57.3°." },
        { title: "Aim the base joint", text: "The target lies 16.1° left of straight up; the bend adds 25.2°. So q₁ = 16.1° − 25.2° = −9.0°, inside the joint limits. Error 0." },
        { title: "Scale too far", text: "With η = 1.3 the target is 11.11 cm away. cos q₂ would be 2.06: impossible. The straight finger stops 2.11 cm short." }
      ]
    },
    ruleTitle: "Three rules behind dexterous learning",
    rules: [
      { name: "Keyvector retargeting with a pinch term", ref: "Our formulation · arXiv 2202.10448", term: "keyvector-retargeting",
        before: "\\min_{\\class{sym-qj}{q}} \\sum_{i} \\big\\| \\class{sym-kvec}{\\mathbf{v}_i^R}(\\class{sym-qj}{q}) - \\class{sym-eta-ret}{\\eta}\\, \\class{sym-kvec}{\\mathbf{v}_i^H} \\big\\|^2",
        tex: "\\min_{\\class{sym-qj}{q}} \\sum_{i} \\big\\| \\class{sym-kvec}{\\mathbf{v}_i^R}(\\class{sym-qj}{q}) - \\class{sym-eta-ret}{\\eta}\\, \\class{sym-kvec}{\\mathbf{v}_i^H} \\big\\|^2 \\class{sb-new}{+ \\class{sym-wpinch}{w_p} \\sum_{i \\neq 0} \\big\\| \\class{sym-kvec}{\\mathbf{v}_{0i}^R} - \\class{sym-eta-ret}{\\eta}\\, \\class{sym-kvec}{\\mathbf{v}_{0i}^H} \\big\\|^2}",
        words: "Match scaled wrist-to-fingertip vectors; the added thumb-to-finger term keeps pinches closed when the robot cannot match every tip.",
        key: ["qj", "kvec", "eta-ret", "wpinch", { glyph: "i", meaning: "mapped finger (0 = thumb)" }, { glyph: "R, H", meaning: "robot, human" }], diff: true, beforeLabel: "Tips only", afterLabel: "With pinch" },
      { name: "DAPG: policy gradient plus demonstrations", ref: "arXiv 1709.10087 · P01 §4.3", term: "demo-augmented-policy-gradient",
        before: "\\nabla_\\theta \\class{sym-J}{J} = \\sum_{\\rho_\\pi} \\nabla_\\theta \\ln \\class{sym-pi}{\\pi_\\theta}(\\class{sym-a}{a} \\mid \\class{sym-s}{s})\\, \\class{sym-adv}{\\hat A}",
        tex: "\\class{sb-chg}{\\class{sym-gaug}{g_{\\mathrm{aug}}}} = \\sum_{\\rho_\\pi} \\nabla_\\theta \\ln \\class{sym-pi}{\\pi_\\theta}(\\class{sym-a}{a} \\mid \\class{sym-s}{s})\\, \\class{sym-adv}{\\hat A} \\class{sb-new}{+ \\sum_{\\class{sym-D}{\\mathcal{D}}} \\nabla_\\theta \\ln \\class{sym-pi}{\\pi_\\theta}(\\class{sym-a}{a} \\mid \\class{sym-s}{s})\\, \\class{sym-wdemo}{w(s,a)}}",
        words: "Add the demonstrations' log-likelihood gradient, weighted by w = 0.1 · 0.95ᵏ · max Â, so demos guide early iterations and fade later.",
        key: ["gaug", "J", "s", "a", "pi", "adv", "D", "wdemo", { glyph: "ρ_π", meaning: "pairs from on-policy rollouts" }, { glyph: "k", meaning: "iteration number" }], diff: true, beforeLabel: "Policy gradient", afterLabel: "DAPG" },
      { name: "PDDM: reward-weighted planning with a learned model", ref: "arXiv 1909.11652 · P01 §4.3", term: "reward-weighted-planning",
        tex: "\\class{sym-a-mean}{\\bar a_t} = \\frac{\\sum_{k=1}^{\\class{sym-N}{N}} e^{\\class{sym-zeta-w}{\\zeta} \\class{sym-Rk}{R_k}}\\, \\class{sym-a}{a_t^{(k)}}}{\\sum_{j=1}^{\\class{sym-N}{N}} e^{\\class{sym-zeta-w}{\\zeta} \\class{sym-Rk}{R_j}}}",
        words: "Sample N smooth action sequences, score each with the learned dynamics ensemble, and average them with weights exponential in predicted return.",
        key: ["a-mean", "N", "zeta-w", "Rk", "a"] }
    ],
    algorithm: {
      title: "The in-hand sim-to-real recipe (Dactyl, DeXtreme)", ref: "arXiv 1808.00177 · 2210.13702", prov: "Our summary of both papers",
      lines: [
        '<span class="kw">input</span> simulator, randomization ranges for <span data-sym="omega">ω</span>, privileged state <span data-sym="s">s</span>',
        '<span class="kw">repeat</span>:',
        '    per episode: sample <span data-sym="omega">ω</span> (friction, masses, delays, noise) <span class="cm">// Dactyl: + unmodeled effects</span>',
        '    roll out a memory (LSTM) policy <span data-sym="pi">π_θ</span> on noisy observations <span data-sym="o">oₜ</span>',
        '    critic sees <span data-sym="s">s</span>; update with PPO <span class="cm">// asymmetric actor-critic</span>',
        '    <span class="kw">if</span> automatic ranges: widen a range when mean successes &gt; 20, narrow when &lt; 5 <span class="cm">// DeXtreme</span>',
        'train a pose estimator on randomized renders only',
        '<span class="kw">deploy</span>: cameras → pose → <span data-sym="pi">π_θ</span> → smoothed joint targets <span data-sym="a">aₜ</span> → PD controller'
      ]
    },
    playgrounds: [
      {
        id: "retarget", title: "Retarget 21 keypoints to a 2- or 4-finger hand", ref: "arXiv 2202.10448 · P05 §8.5", prov: "Simplified: planar hand, gradient descent",
        try: "Start with the pinch on the 4-finger hand. Raise the scale η to 1.35 and watch the pinch open. Then raise the pinch weight. Switch to the 2-finger hand and the power grasp.",
        mount: mountRetarget,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e2-retarget";
          return [
            { target: q("canvas"), title: "Six keypoints do the work", text: "The human hand has 21 keypoints, but the energy uses only the wrist and the mapped fingertips. At η = 1 every robot tip reaches its target." },
            { target: q("#" + id + "-eta"), title: "Make the robot bigger", text: "Scaling the human vectors by 1.35 puts the targets beyond the robot's reach. Each tip gets as close as it can, and the pinch opens.", do: function (a) { return a.set(q("#" + id + "-eta"), 1.35); }, task: "Set the scale η to 1.35", expect: function () { return api.get().eta >= 1.3; } },
            { target: q("#" + id + "-wp"), title: "Keep the pinch", text: "The pinch term matches the thumb-to-index vector too. The gap shrinks while the fingertip error grows: a deliberate trade.", do: function (a) { return a.set(q("#" + id + "-wp"), 4); }, task: "Set the pinch weight to 4", expect: function () { return api.get().wp >= 3; } },
            { target: q("#" + id + "-robot"), title: "Fewer robot fingers", text: "A 2-finger hand keeps only the thumb and index. The other human fingers have no robot finger to drive.", do: function (a) { return a.click(q("#" + id + '-robot [value="two"]')); }, task: "Choose the 2-finger hand", expect: function () { return api.get().robot === "two"; } },
            { target: q("#" + id + "-pose"), title: "A power grasp", text: "The power grasp wraps four fingers around an object. Two robot fingers cannot copy it, whatever the optimizer does.", do: function (a) { return a.click(q("#" + id + '-pose [value="power"]')); }, task: "Choose the Power pose", expect: function () { return api.get().pose === "power"; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Try the Open pose at η = 0.8: the robot fingers cannot bend backward, so joints hit their limits. Compare the two hands." }
          ];
        }
      },
      {
        id: "dapg", title: "Why demonstrations rescue sparse-reward RL", ref: "arXiv 1709.10087", prov: "Simplified: linear policy toy",
        try: "Set Joints d to 1: RL from scratch learns. Set it to 24: it never succeeds, while demos plus RL climb past behavior cloning. Raise the demonstrator mismatch and watch behavior cloning fall.",
        mount: mountDapg,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e2-dapg";
          return [
            { target: q("[data-chart]"), title: "Three learners", text: "Each curve averages three seeds. Reward is 1 only if every joint ends near its goal: a sparse reward, as in DAPG's tasks." },
            { target: q("#" + id + "-d"), title: "One joint", text: "With one joint, a random policy sometimes lands in the goal region. Those rare successes give RL from scratch a gradient.", do: function (a) { return a.set(q("#" + id + "-d"), 1); }, task: "Set Joints d to 1", expect: function () { return api.get().d === 1; } },
            { target: q("#" + id + "-d"), title: "A 24-joint hand", text: "With 24 joints, random actions never succeed, every advantage is zero and RL from scratch stays flat. DAPG's 24-DoF hand faced the same wall.", do: function (a) { return a.set(q("#" + id + "-d"), 24); }, task: "Set Joints d to 24", expect: function () { return api.get().d >= 20; } },
            { target: q("#" + id + "-bias"), title: "Imperfect demonstrators", text: "Behavior cloning copies the demonstrator's errors. RL on top of the demos keeps improving past them.", do: function (a) { return a.set(q("#" + id + "-bias"), 0.6); }, task: "Set the demonstrator mismatch to 0.6", expect: function () { return api.get().bias >= 0.5; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Find the smallest number of joints where RL from scratch never succeeds. Then press New seeds to check that it holds." }
          ];
        }
      }
    ],
    methodsLede: "How the line evolved: DAPG added 25 VR demos and a decaying demo term to policy gradient, in simulation. PDDM planned with learned dynamics on a real Shadow Hand. Dactyl dropped demos for about 100 years of randomized simulation. DeXtreme moved that recipe to a cheaper Allegro hand and GPU simulation. Visual Dexterity distilled a depth-camera student for new shapes; HORA inferred object properties from proprioception. HATO and ViTacFormer added touch to imitation.",
    methods: ["dapg", "pddm", "learning-dexterous-in-hand-manipulation", "dextreme", "visual-dexterity", "in-hand-object-rotation", "hato", "vitacformer", "robotic-telekinesis", "dexmv", "vividex", "dexwild"],
    open: [
      { title: "From one skill to tool use", text: "Reorientation works on enumerated objects; combining it with tool use, which needs a task-suitable pose, remains open.", refs: "P07 §4.3.3, §4.3.5" },
      { title: "Human hands are not robot hands", text: "Retargeted motion can look plausible yet violate robot joint limits, fingertip geometry or contact. Human data may serve better as interaction priors.", refs: "P05 §8.5 · P06 §3.5" },
      { title: "Dynamic multi-contact is under-studied", text: "Of 53 tactile and force methods, only 6 evaluate reorientation and 3 in-hand manipulation; insertion dominates with 26.", refs: "P10 §6.1.5, Fig. 7" },
      { title: "Occlusion and sim-to-real", text: "Fingers occlude the object and simulated contact differs from reality; long-horizon dexterous tasks need skills chained reliably.", refs: "P01 §4.3" }
    ],
    takeaways: [
      "Dexterous hands multiply joints and contacts, so sparse-reward RL from scratch rarely finds a first success.",
      "DAPG solved this with demonstrations: pen reorientation took 3.33 robot-hours instead of 322 for sparse-reward policy gradient, in simulation.",
      "Dactyl and DeXtreme crossed to real hands with randomized simulation and memory; without randomization Dactyl's median consecutive successes fell from 13 to 0.",
      "Proprioceptive history (HORA) and touch (HATO, ViTacFormer) supply what cameras miss when fingers cover the object.",
      "Retargeting maps human keypoints to robot joints by matching scaled keyvectors; a pinch term preserves contact when exact matching is impossible."
    ],
    quiz: [
      { q: "Why does RL from scratch with a sparse reward fail on a 24-DoF hand?", options: ["The network is too small", "Random actions almost never succeed, so there is no signal", "The simulator is too slow", "Rewards are too large"], correct: 1, why: "With a success-only reward, every rollout earns zero, so advantages are zero and the gradient is empty. DAPG reports sparse-reward NPG and DDPG failing on most of its tasks (arXiv 1709.10087)." },
      { q: "What did Dactyl's ablation find when all randomizations were removed?", options: ["Median successes rose to 50", "Nothing changed", "Training diverged in simulation", "Median consecutive successes on hardware fell from 13 to 0"], correct: 3, why: "On the physical hand, the median number of consecutive successes was 13 with all randomizations and 0 with none (arXiv 1808.00177)." },
      { q: "A retargeted pinch opens when the robot cannot reach the scaled fingertip targets. What fixes it?", options: ["A smaller learning rate", "Copying human joint angles", "Adding a thumb-to-finger keyvector term", "Removing the wrist keypoint"], correct: 2, why: "Matching the thumb-to-finger vector keeps the tips together even when each tip misses its own target; the retargeting playground shows the trade." },
      { q: "In HATO's steak-serving task, what happened without touch input?", options: ["Success fell from 5/10 to 0/10", "Success stayed at 5/10", "Success rose to 10/10", "The policy could not be trained"], correct: 0, why: "Removing touch dropped success from 5/10 to 0/10 even though the action error barely changed (0.08 vs 0.07), so action error hid the failure (arXiv 2404.16823)." }
    ],
    cards: [
      { front: "How many degrees of freedom do human hand models include?", back: "20–25: about 4 per finger, 4–5 for the thumb, plus palm and wrist.", ref: "P01 §4.3" },
      { front: "What are DAPG's two ingredients?", back: "Behavior cloning on about 25 demonstrations, then natural policy gradient with an added demo log-likelihood term that decays by 0.95 per iteration.", ref: "arXiv 1709.10087" },
      { front: "What did DeXtreme change relative to Dactyl?", back: "An affordable Allegro hand, RGB keypoint pose estimation instead of motion capture, and GPU-parallel Isaac Gym with vectorized automatic randomization.", ref: "arXiv 2210.13702" },
      { front: "What does HORA's adaptation module estimate, and from what?", back: "An 8-number embedding of object properties, from the last 30 steps of joint positions and actions.", ref: "arXiv 2210.04887" },
      { front: "Why did Visual Dexterity add a table-contact penalty?", back: "To make in-air reorientation emerge: 87% in-air success with the penalty against 4.1% without.", ref: "arXiv 2211.11744" },
      { front: "What do keyvector retargeting methods match?", back: "Scaled vectors between keypoints, such as wrist to fingertip and thumb to fingertip, rather than joint angles.", ref: "arXiv 2202.10448" }
    ],
    terms: {
      "dexterous-hand": { name: "dexterous hand", aliases: ["multi-fingered hand", "anthropomorphic hand", "dexterous manipulation"], group: "grasp", def: "A multi-fingered hand that controls objects through coordinated contacts: in-hand reorientation, fine force modulation and multi-point contact. Human hand models include 20–25 degrees of freedom.", note: "More joints enlarge the action space and raise demands on sensing, calibration and demonstrations.", ref: "P01 §4.3, §2.1", scene: "robot", focus: ["fingers", "joint"], look: "the fingers and their joints", uses: [] },
      "in-hand-reorientation": { name: "in-hand reorientation", aliases: ["in-hand rotation", "in-hand manipulation"], group: "grasp", def: "Rotating a held object to a target orientation with the fingers while the wrist stays fixed.", note: "Real-world successes use extensive randomization and privileged information in simulation (P07).", ref: "P07 §4.3.3", scene: "robot", focus: ["fingers", "object"], look: "the object turning between the fingers", uses: ["dexterous-hand"] },
      "consecutive-successes": { name: "consecutive successes", aliases: ["consecutive goals"], group: "eval", def: "Dactyl's metric: how many target orientations in a row the hand reaches before dropping the object or timing out.", note: "Sim and hardware differ: Dactyl reports a median of 50 in simulation and 13 on the real hand.", ref: "arXiv 1808.00177", scene: "robot", focus: ["object", "target-pose"], look: "the object meeting goal after goal", uses: ["in-hand-reorientation"] },
      "finger-gaiting": { name: "finger gaiting", aliases: ["finger gait"], group: "grasp", def: "Repositioning fingers one at a time while the others keep hold, so an object can turn farther than one grasp allows.", note: "HORA's gaits emerged from pose and energy penalties, with no gaiting heuristics.", ref: "arXiv 2210.04887", scene: "robot", focus: ["fingers", "contact-point"], look: "one finger lifting while others hold", uses: ["in-hand-reorientation"] },
      "demo-augmented-policy-gradient": { name: "demo augmented policy gradient", aliases: ["DAPG"], group: "learning", def: "Initialize a policy with behavior cloning, then train it with natural policy gradient plus a demonstration log-likelihood term whose weight decays over iterations.", note: "Behavior cloning alone usually failed on DAPG's tasks because of distribution shift.", ref: "arXiv 1709.10087", scene: "system", focus: ["data-human", "policy-update"], look: "demos feeding the policy update", uses: [] },
      "reward-weighted-planning": { name: "reward-weighted planning", aliases: ["PDDM planner", "MPPI-style update"], group: "world", def: "Model predictive control that samples smooth action sequences, scores them with a learned dynamics ensemble, and averages them with weights exponential in predicted return.", note: "PDDM found this beat random shooting and the cross-entropy method on its hand tasks.", ref: "arXiv 1909.11652", scene: "system", focus: ["world-model", "planner"], look: "the planner querying the model", uses: [] },
      "object-extrinsics": { name: "object extrinsics", aliases: ["extrinsics"], group: "learning", sym: "z", symTex: "z", def: "A low-dimensional code of object properties (position, size, mass, friction, center of mass) encoded from privileged simulator state and estimated online from proprioceptive history.", note: "Regressing the exact parameters worked worse on hardware than the learned 8-number code.", ref: "arXiv 2210.04887", scene: "robot", focus: ["object", "fingers"], look: "object properties felt through the joints", uses: [] },
      "visuotactile-policy": { name: "visuotactile policy", aliases: ["visuo-tactile policy", "vision and touch policy"], group: "contact", def: "A policy that fuses camera images with touch readings, so it can act on contact that the fingers hide from the camera.", note: "Low action error is not enough: HATO without touch matched action error yet failed every trial.", ref: "arXiv 2404.16823 · P10 §1.1", scene: "robot", focus: ["tactile-pad", "object"], look: "touch pads on the fingertips", uses: ["dexterous-hand"] },
      "keyvector-retargeting": { name: "keyvector retargeting", aliases: ["fingertip retargeting", "hand retargeting energy"], group: "data", sym: "𝐯", symTex: "\\mathbf{v}", def: "Hand retargeting that matches scaled vectors between keypoints, such as wrist to fingertip and thumb to fingertip, instead of human joint angles.", note: "Robotic Telekinesis learned this mapping from internet hand poses and ran at 24 Hz.", ref: "arXiv 2202.10448 · P06 §3.3.1", scene: "robot", focus: ["human-hand", "fingers"], look: "human fingertips mapped to robot fingertips", uses: ["dexterous-hand"] },
      "wearable-hand-capture": { name: "wearable hand capture", aliases: ["glove capture", "hand exoskeleton"], group: "data", def: "Recording dexterous demonstrations with gloves, exoskeletons or headsets instead of a robot, then mapping them to a robot hand.", note: "DexUMI's exoskeleton limits human motion to what the robot hand can do.", ref: "P05 §3.3, §8.3", scene: "system", focus: ["data-human", "human-teleop"], look: "the human data source", uses: ["keyvector-retargeting"] }
    },
    symbols: [
      { id: "kvec", tex: "\\mathbf{v}", glyph: "𝐯", kind: "Robot", meaning: "keyvector: from one hand keypoint to another (wrist to fingertip, or thumb tip to fingertip)", short: "keyvector between hand keypoints", first: "e2", read: "bold v", papers: "Robotic Telekinesis, DexPilot: keyvectors r_i" },
      { id: "eta-ret", tex: "\\eta", glyph: "η", kind: "Parameters", meaning: "scale from human hand size to robot hand size in retargeting", short: "hand-size scale", first: "e2", read: "eta", papers: "Our formulation" },
      { id: "wpinch", tex: "w_p", glyph: "w_p", kind: "Parameters", meaning: "weight of the thumb-to-finger (pinch) term in retargeting", short: "pinch weight", first: "e2", read: "w sub p", papers: "Our formulation" },
      { id: "gaug", tex: "g_{\\mathrm{aug}}", glyph: "g_aug", kind: "Functions", meaning: "policy gradient augmented with a demonstration term (DAPG)", short: "augmented gradient", first: "e2", read: "g aug", papers: "DAPG: g_aug" },
      { id: "wdemo", tex: "w(s,a)", glyph: "w(s,a)", kind: "Functions", meaning: "weight on a demonstrated state-action pair: λ₀ λ₁ᵏ times the largest advantage, with λ₀ = 0.1, λ₁ = 0.95", short: "decaying demo weight", first: "e2", read: "w of s a", papers: "DAPG: w(s,a) = λ0 λ1^k max A" },
      { id: "a-mean", tex: "\\bar a_t", glyph: "āₜ", kind: "Signals", meaning: "mean action at step t of the planned sequence", short: "planned mean action", first: "e2", read: "a bar t", papers: "PDDM: μ_t" },
      { id: "Rk", tex: "R_k", glyph: "R_k", kind: "Functions", meaning: "predicted return of candidate sequence k, averaged over the dynamics ensemble", short: "predicted return of candidate k", first: "e2", read: "R sub k", papers: "PDDM: R_k" },
      { id: "zeta-w", tex: "\\zeta", glyph: "ζ", kind: "Parameters", meaning: "reward-weighting sharpness in PDDM's update (larger = closer to picking the best)", short: "reward-weighting sharpness", first: "e2", read: "zeta", papers: "PDDM: γ" }
    ],
    ledger: [
      { where: "Topic 16 · PDDM rule", source: "PDDM writes the reward-weighting factor as γ and the mean action as μₜ", page: "ζ and āₜ", why: "γ is the discount and μ friction in house notation.", kind: "Our choice" },
      { where: "Topic 16 · DAPG rule", source: "DAPG writes the gradient as g and the demo weight with λ₀, λ₁", page: "g_aug; λ₀, λ₁ appear only inside w(s,a)", why: "g is a grasp and λ a contact force in house notation.", kind: "Our choice" },
      { where: "Topic 16 · retargeting rule and playground", source: "DexPilot and Robotic Telekinesis use keyvector energies with distance-dependent weights and collision terms", page: "One fixed pinch weight w_p, no collisions, planar fingers", why: "Shows the trade between fingertip accuracy and pinch contact only.", kind: "Simplified" },
      { where: "Topic 16 · DAPG playground", source: "DAPG trains a neural Gaussian policy with natural policy gradient on 24-DoF MuJoCo tasks", page: "Linear gains, REINFORCE with a normalized step; the demo term adds little over BC initialization here", why: "Shows why sparse rewards stall as joints grow and how demos start learning.", kind: "Simplified" },
      { where: "Topic 16 · worked example", source: "Real retargeting solves many fingers at once with numerical optimization", page: "One two-link finger solved in closed form", why: "Numbers a reader can check by hand.", kind: "Our choice" }
    ]
  });
})();
