/* Topic 15 · Grasping: from analytic grasps to grasp-anything models.
   Sources: P01 §3.1 (Table 1), §4.1 (Fig. 4) · P05 §6.8, Table 6 · P07 §4.3.1.1 · P02 (Hand / Gripper) · method cards (E1). */
(function () {
  "use strict";
  var RB = window.RB;
  var FONT = function (k) { return getComputedStyle(document.body).getPropertyValue(k === "mono" ? "--font-mono" : "--font-body"); };
  var DEG = Math.PI / 180;
  /* read the pressed button of a segmented control (robust to how the core passes the value) */
  function bindSeg(root, sid, cb) { RB.bindSeg(root, sid, function (v) { var b = root.querySelector("#" + sid + ' [aria-pressed="true"]'); cb(typeof v === "string" && v ? v : b ? b.value : v); }); }

  /* ---------- shared toy geometry: convex objects seen from above, in millimetres (y up) ---------- */
  function circlePoly(r, n) { var p = []; for (var i = 0; i < n; i++) { var a = 2 * Math.PI * i / n; p.push([r * Math.cos(a), r * Math.sin(a)]); } return p; }
  var SHAPES = {
    box: { label: "Box", poly: [[-30, -45], [30, -45], [30, 45], [-30, 45]] },
    wedge: { label: "Wedge", poly: [[-40, -45], [40, -45], [20, 45], [-20, 45]] },
    round: { label: "Round", poly: circlePoly(34, 48) },
    tri: { label: "Triangle", poly: [[0, 51.96], [-45, -25.98], [45, -25.98]] }
  };
  /* Close two parallel jaws on a convex polygon. g = {x, y, th (deg), w (opening, mm)}.
     Returns {kind: "miss"|"wide"|"ok", p1, p2, a1, a2 (deg), chord, need (tan of max angle)} */
  function closeJaws(poly, g) {
    var u = [Math.cos(g.th * DEG), Math.sin(g.th * DEG)], c = [g.x, g.y];
    var tin = -Infinity, tout = Infinity, nin = null, nout = null, n = poly.length;
    for (var i = 0; i < n; i++) {
      var A = poly[i], B = poly[(i + 1) % n], ex = B[0] - A[0], ey = B[1] - A[1], L = Math.hypot(ex, ey);
      var nx = ey / L, ny = -ex / L; /* outward normal for counter-clockwise order */
      var den = nx * u[0] + ny * u[1], num = nx * (A[0] - c[0]) + ny * (A[1] - c[1]);
      if (Math.abs(den) < 1e-9) { if (num < 0) return { kind: "miss" }; continue; }
      var t = num / den;
      if (den < 0) { if (t > tin) { tin = t; nin = [nx, ny]; } } else { if (t < tout) { tout = t; nout = [nx, ny]; } }
    }
    if (tin > tout || !nin || !nout) return { kind: "miss" };
    var p1 = [c[0] + tin * u[0], c[1] + tin * u[1]], p2 = [c[0] + tout * u[0], c[1] + tout * u[1]];
    if (tin < -g.w / 2 || tout > g.w / 2) return { kind: "wide", p1: p1, p2: p2, chord: tout - tin };
    var a1 = Math.acos(RB.clamp(-(u[0] * nin[0] + u[1] * nin[1]), -1, 1)) / DEG;
    var a2 = Math.acos(RB.clamp(u[0] * nout[0] + u[1] * nout[1], -1, 1)) / DEG;
    return { kind: "ok", p1: p1, p2: p2, n1: nin, n2: nout, a1: a1, a2: a2, chord: tout - tin, need: Math.tan(Math.max(a1, a2) * DEG) };
  }
  /* GraspNet-1Billion style label: smallest friction in 0.1 steps that holds, s_g = 1.1 − μ_min (0 if none up to 1.0) */
  function score(r) { if (!r || r.kind !== "ok") return 0; var m = Math.max(0.1, Math.ceil(r.need * 10 - 1e-9) / 10); return m > 1.0001 ? 0 : Math.round((1.1 - m) * 10) / 10; }
  function holds(r, mu) { return r && r.kind === "ok" && Math.max(r.a1, r.a2) <= Math.atan(mu) / DEG + 1e-9; }

  function drawGrid(c, P, W, H) {
    c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
    c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
    for (var gx = 0; gx <= W; gx += 30) { c.beginPath(); c.moveTo(gx, 0); c.lineTo(gx, H); c.stroke(); }
    for (var gy = 0; gy <= H; gy += 30) { c.beginPath(); c.moveTo(0, gy); c.lineTo(W, gy); c.stroke(); }
  }
  function drawPoly(c, P, poly, px) {
    c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.lineWidth = 1.5; c.beginPath();
    poly.forEach(function (q, i) { var z = px(q); if (i) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.closePath(); c.fill(); c.stroke();
  }
  /* jaw plates + squeeze line of a grasp */
  function drawGripper(c, P, g, px, S, col, lw) {
    var u = [Math.cos(g.th * DEG), Math.sin(g.th * DEG)], v = [-u[1], u[0]], hj = 12;
    [-1, 1].forEach(function (sgn) {
      var e = [g.x + sgn * g.w / 2 * u[0], g.y + sgn * g.w / 2 * u[1]];
      var a = px([e[0] + hj * v[0], e[1] + hj * v[1]]), b = px([e[0] - hj * v[0], e[1] - hj * v[1]]);
      c.strokeStyle = col; c.lineWidth = lw * 2.4; c.lineCap = "round"; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
    });
    var e1 = px([g.x - g.w / 2 * u[0], g.y - g.w / 2 * u[1]]), e2 = px([g.x + g.w / 2 * u[0], g.y + g.w / 2 * u[1]]);
    c.lineWidth = lw * 0.7; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(e1[0], e1[1]); c.lineTo(e2[0], e2[1]); c.stroke(); c.setLineDash([]); c.lineCap = "butt";
  }

  /* ---------- playground 1: place a rectangle grasp and test the friction cones ---------- */
  function mountCones(body, ctx) {
    var id = ctx.id, st = { shape: "box", x: 0, y: 0, th: 15, w: 80, mu: 0.5 }, last = null;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-shape", label: "Object", value: "box", options: Object.keys(SHAPES).map(function (k) { return { value: k, label: SHAPES[k].label }; }) }) +
      RB.slider({ id: id + "-th", label: "Grasp angle θ", min: 0, max: 179, step: 1, value: 15, fmt: function (v) { return v + "°"; } }) +
      RB.slider({ id: id + "-w", label: "Opening w", min: 20, max: 120, step: 2, value: 80, fmt: function (v) { return v + " mm"; } }) +
      RB.slider({ id: id + "-mu", label: "Friction μ", min: 0.1, max: 1, step: 0.05, value: 0.5, fmt: function (v) { return (+v).toFixed(2); } }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-x", label: "Center x", min: -60, max: 60, step: 1, value: 0, fmt: function (v) { return v + " mm"; } }) +
      RB.slider({ id: id + "-y", label: "Center y", min: -60, max: 60, step: 1, value: 0, fmt: function (v) { return v + " mm"; } }) +
      '<button class="sb-btn" type="button" id="' + id + '-reset">Reset grasp</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Top view of an object with a parallel-jaw grasp; drag to move the grasp center"></canvas><figcaption class="sb-caption">Drag on the object to move the grasp. Shaded wedges are the friction cones; the grasp holds only if the dashed squeeze line lies inside both.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "ang", k: "Contact angles" }, { id: "cone", k: "Cone half-angle" }, { id: "need", k: "Friction needed" }, { id: "verdict", k: "Verdict" }, { id: "s", k: "Dataset label" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "good", label: "inside the cone", kind: "area" }, { c: "bad", label: "outside: slips", kind: "area" }, { c: "accent", label: "gripper jaws", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 520, H = 380, S = 2.6;
    var px = function (q) { return [W / 2 + q[0] * S, H / 2 - q[1] * S]; };
    function cone(c, P, p, nOut, half, ok) {
      var base = Math.atan2(-nOut[1], -nOut[0]), L = 26, z = px(p);
      c.fillStyle = ok ? P["good-soft"] : P["bad-soft"]; c.strokeStyle = ok ? P.good : P.bad; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(z[0], z[1]);
      for (var k = 0; k <= 16; k++) { var a = base - half + 2 * half * k / 16; var q = px([p[0] + L * Math.cos(a), p[1] + L * Math.sin(a)]); c.lineTo(q[0], q[1]); }
      c.closePath(); c.globalAlpha = 0.85; c.fill(); c.globalAlpha = 1; c.stroke();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), r = last;
      drawGrid(c, P, W, H); drawPoly(c, P, SHAPES[st.shape].poly, px);
      drawGripper(c, P, st, px, S, P.accent, 2);
      if (r && r.kind === "ok") {
        var half = Math.atan(st.mu);
        cone(c, P, r.p1, r.n1, half, r.a1 <= half / DEG + 1e-9); cone(c, P, r.p2, r.n2, half, r.a2 <= half / DEG + 1e-9);
        [r.p1, r.p2].forEach(function (p) { var z = px(p); c.fillStyle = P.ink; c.beginPath(); c.arc(z[0], z[1], 4.5, 0, 2 * Math.PI); c.fill(); });
        var z1 = px(r.p1), z2 = px(r.p2); c.fillStyle = P["ink-2"]; c.font = "600 12px " + FONT("mono");
        var vx = -Math.sin(st.th * DEG) * 16, vy = -Math.cos(st.th * DEG) * 16; c.fillText("1", z1[0] + vx - 4, z1[1] + vy + 4); c.fillText("2", z2[0] + vx - 4, z2[1] + vy + 4);
      } else if (r && r.kind === "wide") {
        [r.p1, r.p2].forEach(function (p) { var z = px(p); c.strokeStyle = P.bad; c.lineWidth = 2; c.beginPath(); c.arc(z[0], z[1], 6, 0, 2 * Math.PI); c.stroke(); });
      }
      var cz = px([st.x, st.y]); c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.arc(cz[0], cz[1], 5, 0, 2 * Math.PI); c.stroke();
    }
    function run() {
      last = closeJaws(SHAPES[st.shape].poly, st);
      var r = last, ok = holds(r, st.mu);
      RB.setRO(body, "cone", (Math.atan(st.mu) / DEG).toFixed(1) + "°");
      if (r.kind === "ok") {
        RB.setRO(body, "ang", r.a1.toFixed(0) + "° / " + r.a2.toFixed(0) + "°");
        RB.setRO(body, "need", RB.fmt(r.need, 2));
        RB.setRO(body, "verdict", ok ? "Holds" : "Slips");
        var s = score(r); RB.setRO(body, "s", s > 0 ? s.toFixed(1) : "none");
        note.textContent = ok ? "Force closure: both contact angles are inside the cone, so the jaws can squeeze without sliding. Lower μ until the verdict flips." : "At least one contact angle exceeds arctan μ: the finger slides along the surface. Raise μ or turn the grasp toward the surface normals.";
      } else {
        RB.setRO(body, "ang", "– / –"); RB.setRO(body, "need", "–"); RB.setRO(body, "s", "–");
        RB.setRO(body, "verdict", r.kind === "miss" ? "Misses" : "Too wide");
        note.textContent = r.kind === "miss" ? "The squeeze line does not cross the object. Drag the center onto it." : "The object is " + r.chord.toFixed(0) + " mm across along this line, more than the " + st.w + " mm opening: a jaw lands on top of it.";
      }
      draw();
    }
    function setSlider(k, v) { var el = body.querySelector("#" + id + "-" + k); el.value = v; var o = body.querySelector('[data-out="' + id + "-" + k + '"]'); if (o) o.textContent = k === "mu" ? (+v).toFixed(2) : k === "th" ? v + "°" : v + " mm"; }
    bindSeg(body, id + "-shape", function (v) { st.shape = v; run(); });
    RB.bindSlider(body, id + "-th", function (v) { return v + "°"; }, function (v) { st.th = v; run(); });
    RB.bindSlider(body, id + "-w", function (v) { return v + " mm"; }, function (v) { st.w = v; run(); });
    RB.bindSlider(body, id + "-mu", function (v) { return (+v).toFixed(2); }, function (v) { st.mu = v; run(); });
    RB.bindSlider(body, id + "-x", function (v) { return v + " mm"; }, function (v) { st.x = v; run(); });
    RB.bindSlider(body, id + "-y", function (v) { return v + " mm"; }, function (v) { st.y = v; run(); });
    body.querySelector("#" + id + "-reset").addEventListener("click", function () { st.x = 0; st.y = 0; st.th = 15; st.w = 80; ["x", "y", "th", "w"].forEach(function (k) { setSlider(k, st[k]); }); run(); });
    var dragging = false;
    function toMM(e) { var b = cv.getBoundingClientRect(), sx = W / b.width, sy = H / b.height; return [RB.clamp(Math.round(((e.clientX - b.left) * sx - W / 2) / S), -60, 60), RB.clamp(Math.round((H / 2 - (e.clientY - b.top) * sy) / S), -60, 60)]; }
    cv.addEventListener("pointerdown", function (e) { dragging = true; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } var m = toMM(e); st.x = m[0]; st.y = m[1]; setSlider("x", st.x); setSlider("y", st.y); run(); });
    cv.addEventListener("pointermove", function (e) { if (!dragging) return; var m = toMM(e); st.x = m[0]; st.y = m[1]; setSlider("x", st.x); setSlider("y", st.y); run(); });
    cv.addEventListener("pointerup", function () { dragging = false; });
    cv.addEventListener("pointercancel", function () { dragging = false; });
    RB.onTheme(draw);
    run();
    return { state: function () { return { shape: st.shape, th: st.th, mu: st.mu, x: st.x, y: st.y, w: st.w, pass: holds(last, st.mu), kind: last.kind }; } };
  }

  /* ---------- playground 2: sample-and-rank against a dense quality map ---------- */
  var MU2 = 0.5, ANG = 12; /* 12 in-plane angles, as in GraspNet-1Billion's rotation bins */
  function mountSearch(body, ctx) {
    var id = ctx.id, st = { shape: "wedge", mode: "sample", N: 5, err: 0 }, seed = 11, res = null;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-shape", label: "Object", value: "wedge", options: Object.keys(SHAPES).map(function (k) { return { value: k, label: SHAPES[k].label }; }) }) +
      RB.seg({ id: id + "-mode", label: "Search", value: "sample", options: [{ value: "sample", label: "Sample" }, { value: "dense", label: "Dense map" }] }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-n", label: "Samples N", min: 1, max: 300, step: 1, value: 5 }) +
      RB.slider({ id: id + "-err", label: "Execution error σ", min: 0, max: 10, step: 0.5, value: 0, fmt: function (v) { return (+v).toFixed(1) + " mm"; } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Sample again ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Candidate grasps or a grasp-quality heat map over the object, with the chosen grasp highlighted"></canvas><figcaption class="sb-caption">Sample mode: green ticks hold, gray ticks fail. Map mode: darker cells have a better best-angle score. The thick gripper is the grasp the robot would execute.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "evals", k: "Grasps checked" }, { id: "pass", k: "Checked grasps that hold" }, { id: "best", k: "Chosen grasp label s_g" }, { id: "exec", k: "Chosen grasp holds under error" }]) +
      '<p class="sb-caption" data-note></p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 520, H = 380, S = 2.6;
    var px = function (q) { return [W / 2 + q[0] * S, H / 2 - q[1] * S]; };
    function evalG(poly, g) { var r = closeJaws(poly, g); return holds(r, MU2) ? score(r) : 0; }
    function execRate(poly, g, R) {
      if (!g) return 0; var ok = 0;
      for (var i = 0; i < 100; i++) { var h = { x: g.x + st.err * R.normal(), y: g.y + st.err * R.normal(), th: g.th + 1.5 * st.err * R.normal(), w: g.w }; if (holds(closeJaws(poly, h), MU2)) ok++; }
      return ok;
    }
    function run() {
      var poly = SHAPES[st.shape].poly, R = RB.rng(seed), best = null, bs = -1, passN = 0;
      if (st.mode === "sample") {
        var cand = [];
        for (var i = 0; i < st.N; i++) { var g = { x: -55 + 110 * R(), y: -55 + 110 * R(), th: 180 * R(), w: 80 }; var s = evalG(poly, g); cand.push({ g: g, s: s }); if (s > 0) passN++; if (s > bs) { bs = s; best = g; } }
        res = { cand: cand, best: best, bs: bs, n: st.N, pass: passN };
      } else {
        var step = 4, cells = [], grid = {};
        for (var x = -56; x <= 56; x += step) for (var y = -56; y <= 56; y += step) {
          var top = 0, topTh = 0;
          for (var k = 0; k < ANG; k++) { var th = k * 180 / ANG, s2 = evalG(poly, { x: x, y: y, th: th, w: 80 }); if (s2 > 0) passN++; if (s2 > top) { top = s2; topTh = th; } }
          var cell = { x: x, y: y, s: top, th: topTh }; cells.push(cell); grid[x + "," + y] = cell;
        }
        /* our tie-break: among equal best scores, prefer the cell whose neighbours score highest */
        cells.forEach(function (cl) { var m = 0; for (var dx = -step; dx <= step; dx += step) for (var dy = -step; dy <= step; dy += step) { var nb = grid[(cl.x + dx) + "," + (cl.y + dy)]; m += nb ? nb.s : 0; } var key = cl.s * 100 + m; if (cl.s > 0 && key > bs) { bs = key; best = { x: cl.x, y: cl.y, th: cl.th, w: 80 }; } });
        res = { cells: cells, step: step, best: best, bs: best ? evalG(poly, best) : 0, n: cells.length * ANG, pass: passN };
      }
      RB.setRO(body, "evals", String(res.n));
      RB.setRO(body, "pass", Math.round(100 * res.pass / res.n) + "%");
      RB.setRO(body, "best", res.best && res.bs > 0 ? res.bs.toFixed(1) : "none found");
      RB.setRO(body, "exec", res.best && res.bs > 0 ? execRate(poly, res.best, RB.rng(seed + 99)) + " of 100" : "–");
      note.textContent = st.mode === "sample" ? "Sample and rank draws random grasps, checks each and keeps the best, like 6-DoF GraspNet's sampler plus evaluator. Few samples can miss the good region." : "A dense map scores every cell at 12 angles in one sweep, as GG-CNN outputs a quality per pixel and GraspNet-1Billion uses 12 rotation bins.";
      body.querySelector("#" + id + "-n").disabled = st.mode !== "sample";
      body.querySelector("#" + id + "-go").disabled = st.mode !== "sample";
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H);
      drawGrid(c, P, W, H);
      if (res && res.cells) {
        var cs = res.step * S;
        res.cells.forEach(function (cl) { if (cl.s <= 0) return; var z = px([cl.x, cl.y]); c.fillStyle = P.accent; c.globalAlpha = 0.12 + 0.75 * cl.s; c.fillRect(z[0] - cs / 2, z[1] - cs / 2, cs, cs); });
        c.globalAlpha = 1;
      }
      c.globalAlpha = res && res.cells ? 0.45 : 1; drawPoly(c, P, SHAPES[st.shape].poly, px); c.globalAlpha = 1;
      if (res && res.cand) res.cand.forEach(function (cd) {
        var g = cd.g, u = [Math.cos(g.th * DEG), Math.sin(g.th * DEG)], a = px([g.x - 12 * u[0], g.y - 12 * u[1]]), b = px([g.x + 12 * u[0], g.y + 12 * u[1]]);
        c.strokeStyle = cd.s > 0 ? P.good : P["ink-3"]; c.globalAlpha = cd.s > 0 ? 0.9 : 0.45; c.lineWidth = 2; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); c.globalAlpha = 1;
      });
      if (res && res.best && res.bs > 0) drawGripper(c, P, res.best, px, S, P.ink, 2);
    }
    bindSeg(body, id + "-shape", function (v) { st.shape = v; run(); });
    bindSeg(body, id + "-mode", function (v) { st.mode = v; run(); });
    RB.bindSlider(body, id + "-n", null, function (v) { st.N = v; run(); });
    RB.bindSlider(body, id + "-err", function (v) { return (+v).toFixed(1) + " mm"; }, function (v) { st.err = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { shape: st.shape, mode: st.mode, N: st.N, err: st.err, best: res && res.bs > 0 ? res.bs : 0 }; } };
  }

  /* ---------- concept-card drawings (200×56, token colors only) ---------- */
  var ART = {
    rect: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="20" y="10" width="54" height="38" rx="4" class="rb-f-sunk"/><g transform="translate(47 29) rotate(-20)"><rect x="-40" y="-8" width="80" height="16" class="rb-s-acc"/><line x1="-40" y1="-12" x2="-40" y2="12" class="rb-s-ink"/><line x1="40" y1="-12" x2="40" y2="12" class="rb-s-ink"/></g><text x="100" y="24" class="rb-t-mono">x, y, w, h, θ</text><text x="100" y="42" class="rb-t-mono">image plane</text></svg>',
    six: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M20 44 L50 30 L80 44 L50 54 Z" class="rb-f-sunk"/><path d="M50 30 V6" class="rb-s-acc"/><path d="M40 12 V22 H60 V12" class="rb-s-ink"/><path d="M50 30 L70 20" class="rb-s-line"/><path d="M50 30 L32 22" class="rb-s-line"/><text x="100" y="24" class="rb-t-mono">R, t, w</text><text x="100" y="42" class="rb-t-mono">any approach</text></svg>',
    cone: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="8" width="40" height="44" class="rb-f-sunk"/><path d="M50 30 L100 8 L100 52 Z" class="rb-f-soft"/><circle cx="50" cy="30" r="3" class="rb-f-acc"/><path d="M50 30 L100 30" class="rb-s-ink" stroke-dasharray="3 3"/><text x="108" y="24" class="rb-t-mono">half-angle</text><text x="108" y="40" class="rb-t-acc">arctan μ</text></svg>',
    closure: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="60" y="4" width="80" height="34" rx="3" class="rb-f-sunk"/><path d="M60 21 L82 11 L82 31 Z" class="rb-f-soft"/><path d="M140 21 L118 11 L118 31 Z" class="rb-f-soft"/><path d="M30 21 H170" class="rb-s-acc"/><path d="M22 11 V31 M178 11 V31" class="rb-s-ink"/><text x="100" y="52" text-anchor="middle" class="rb-t-mono">line inside both cones</text></svg>',
    map: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4, 5].map(function (i) { return [0, 1, 2].map(function (j) { var q = Math.max(0, 1 - Math.abs(i - 3.2) / 3 - Math.abs(j - 1) * 0.3); return '<rect x="' + (14 + i * 14) + '" y="' + (8 + j * 14) + '" width="13" height="13" class="rb-f-acc" opacity="' + (0.1 + 0.8 * q).toFixed(2) + '"/>'; }).join(""); }).join("") + '<text x="110" y="24" class="rb-t-mono">Q per pixel</text><text x="110" y="42" class="rb-t-acc">argmax</text></svg>',
    rank: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (i) { return '<path d="M' + (16 + i * 14) + " " + (12 + (i % 2) * 20) + " l10 8" + '" class="' + (i === 2 ? "rb-s-acc" : "rb-s-line") + '"/>'; }).join("") + '<path d="M90 28 H106" class="rb-s-ink"/><rect x="108" y="14" width="46" height="28" rx="4" class="rb-f-surface"/><text x="131" y="32" text-anchor="middle" class="rb-t-mono">score</text><path d="M156 28 H172" class="rb-s-ink"/><circle cx="182" cy="28" r="6" class="rb-f-acc"/></svg>',
    lang: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="12" width="84" height="30" rx="6" class="rb-f-surface"/><text x="50" y="31" text-anchor="middle" class="rb-t-mono">"the handle"</text><path d="M94 27 H114" class="rb-s-ink"/><rect x="120" y="22" width="50" height="10" rx="2" class="rb-f-sunk"/><rect x="170" y="18" width="20" height="18" rx="3" class="rb-f-soft"/><path d="M180 8 V16 M180 38 V48" class="rb-s-acc"/></svg>',
    dex: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="60" cy="30" r="16" class="rb-f-sunk"/>' + [-50, -15, 20, 55].map(function (a) { var r = a * DEG; return '<path d="M' + (60 + 34 * Math.cos(r + Math.PI)).toFixed(1) + " " + (30 + 34 * Math.sin(r + Math.PI)).toFixed(1) + " L" + (60 + 17 * Math.cos(r + Math.PI)).toFixed(1) + " " + (30 + 17 * Math.sin(r + Math.PI)).toFixed(1) + '" class="rb-s-acc"/>'; }).join("") + '<path d="M60 30 L96 30" class="rb-s-acc"/><text x="104" y="24" class="rb-t-mono">wrist + joints</text><text x="104" y="42" class="rb-t-mono">many contacts</text></svg>'
  };

  /* ---------- worked-example figure: box 60 mm wide, grasp at 15°, μ = 0.5 (2 px per mm) ---------- */
  var WE_FIG = '<svg viewBox="0 0 560 220" role="img" aria-label="Top view of a 60 by 90 millimetre box with a grasp tilted 15 degrees, its two contacts and friction cones, and a second grasp tilted 30 degrees">' +
    '<rect x="120" y="20" width="120" height="180" class="rb-f-sunk"/><text x="180" y="214" text-anchor="middle" class="rb-t-mono">box 60 × 90 mm</text>' +
    '<g data-on="1+"><g transform="translate(180 110) rotate(-15)"><rect x="-80" y="-20" width="160" height="40" class="rb-s-acc" stroke-dasharray="4 3"/><line x1="-80" y1="-24" x2="-80" y2="24" class="rb-s-ink" stroke-width="4"/><line x1="80" y1="-24" x2="80" y2="24" class="rb-s-ink" stroke-width="4"/></g><circle cx="180" cy="110" r="3" class="rb-f-acc"/></g>' +
    '<g data-on="2+"><line x1="120" y1="126.1" x2="240" y2="93.9" class="rb-s-acc"/><circle cx="120" cy="126.1" r="4.5" class="rb-f-acc"/><circle cx="240" cy="93.9" r="4.5" class="rb-f-acc"/><text x="112" y="140" text-anchor="end" class="rb-t-mono">p₁</text><text x="248" y="90" class="rb-t-mono">p₂</text></g>' +
    '<g data-on="3+"><line x1="120" y1="126.1" x2="160" y2="126.1" class="rb-s-ink" stroke-dasharray="3 3"/><line x1="240" y1="93.9" x2="200" y2="93.9" class="rb-s-ink" stroke-dasharray="3 3"/><path d="M146 126.1 A26 26 0 0 0 145.1 119.4" class="rb-s-ink"/><text x="150" y="142" class="rb-t-acc">15°</text></g>' +
    '<g data-on="4+"><path d="M120 126.1 L164.7 103.7 L164.7 148.5 Z" class="rb-f-soft" opacity="0.7"/><path d="M240 93.9 L195.3 71.5 L195.3 116.3 Z" class="rb-f-soft" opacity="0.7"/></g>' +
    '<g data-on="6"><line x1="120" y1="144.6" x2="240" y2="75.4" class="rb-s-ink" stroke-dasharray="6 4"/><circle cx="120" cy="144.6" r="4" class="rb-f-surface"/><circle cx="240" cy="75.4" r="4" class="rb-f-surface"/><text x="100" y="170" class="rb-t-mono">θ = 30°</text></g>' +
    '<g class="rb-t-ink"><text x="300" y="36" data-on="1+">g = (0, 0, 80, 20, 15°)</text>' +
    '<text x="300" y="64" data-on="2+">chord 62.1 mm &lt; w = 80 mm</text>' +
    '<text x="300" y="92" data-on="3+">α₁ = α₂ = 15°</text>' +
    '<text x="300" y="120" data-on="4+">arctan 0.5 = 26.6° ≥ 15°: holds</text>' +
    '<text x="300" y="148" data-on="5+">μ_min = 0.3, s_g = 1.1 − 0.3 = 0.8</text>' +
    '<text x="300" y="176" data-on="6">θ = 30°: 30° &gt; 26.6°, slips; s_g = 0.5</text></g></svg>';

  RB.topic({
    id: "e1",
    title: "Grasping from analytic to foundation models",
    eyebrow: "Part E · Grasping",
    lede: "A grasp is where two jaws or a hand close on an object. Friction decides whether it holds; learning decides where to look for one.",
    refs: ["P01 §3.1, §4.1", "P05 §6.8", "P07 §4.3.1.1"],
    why: "Almost every manipulation task starts with picking something up. Early methods checked geometry and friction by hand; later ones learned to predict grasps from images, from point clouds and finally from language. The physics test never changed: the squeeze must stay inside both friction cones. Knowing that test explains the labels every grasp dataset is built on.",
    outcomes: [
      "Test whether a two-finger grasp achieves force closure at a given friction.",
      "Compute a GraspNet-1Billion grasp label from the friction a grasp needs.",
      "Compare rectangle, 6-DoF and dexterous grasp representations.",
      "Trace how grasp datasets moved from manual to automatic labels.",
      "Place GraspGPT, ThinkGrasp and GraspVLA in the four method families."
    ],
    concepts: [
      { name: "Grasp rectangle", def: "A 5-D planar grasp: center (x, y), gripper opening, jaw size and angle θ in the image.", ref: "P01 §3.1", art: ART.rect, term: "grasp-rectangle", sym: "g" },
      { name: "6-DoF grasp pose", def: "A full gripper pose in 3-D, position and orientation plus width, so the hand can approach from any side.", ref: "P01 §4.1", art: ART.six, term: "6-dof-grasp" },
      { name: "Friction cone", def: "The set of forces a contact can push without slipping: a cone of half-angle arctan μ around the normal.", ref: "arXiv 1912.13470", art: ART.cone, term: "friction-cone", sym: "mu", href: "#lab/grasp" },
      { name: "Force closure", def: "The contacts can resist any disturbance. For two fingers: the squeeze line lies inside both friction cones.", ref: "P01 §4.1", art: ART.closure, term: "force-closure", sym: "grasp-alpha" },
      { name: "Grasp quality map", def: "GG-CNN predicts a quality, angle and width for every pixel; the best grasp is the argmax.", ref: "arXiv 1804.05172", art: ART.map, term: "grasp-quality-map" },
      { name: "Sample and rank", def: "Propose many candidate grasps, score each with an evaluator, execute the best one.", ref: "P01 Fig. 4", art: ART.rank, term: "sample-and-rank", sym: "sg" },
      { name: "Language-driven grasp", def: "The instruction picks which object or part to grasp, by fusing features, ranking candidates or fine-tuning a VLM.", ref: "P01 §4.1, Fig. 4", art: ART.lang, term: "language-driven-grasping" },
      { name: "Dexterous grasp synthesis", def: "Optimize or generate a wrist pose and all finger joints so several contacts reach force closure.", ref: "arXiv 2210.02697", art: ART.dex, term: "dexterous-grasp-synthesis" }
    ],
    flow: {
      title: "Where grasping acts in a pick", ref: "P01 Fig. 4 · P07 §4.3.1.1", w: 820, h: 270,
      caption: "A grasp model proposes candidates, a checker ranks them, and a planner executes the best. The lift result can become a new training label.",
      nodes: [
        { id: "cam", x: 20, y: 50, w: 140, h: 52, label: "RGB-D camera", sub: "image or points", kind: "env" },
        { id: "model", x: 240, y: 50, w: 150, h: 52, label: "Grasp model", sub: "map, sampler or VLM", kind: "agent" },
        { id: "cands", x: 460, y: 50, w: 150, h: 52, label: "Candidates", sub: "grasps with scores", kind: "store" },
        { id: "instr", x: 240, y: 186, w: 150, h: 52, label: "Instruction ℓ", sub: "which object or part", kind: "env" },
        { id: "rank", x: 460, y: 186, w: 150, h: 52, label: "Check and rank", sub: "quality, collision", kind: "decision" },
        { id: "robot", x: 660, y: 116, w: 140, h: 56, label: "Robot", sub: "reach, close, lift", kind: "env" }
      ],
      edges: [
        { from: "cam", to: "model", label: "input" },
        { from: "model", to: "cands", label: "grasps" },
        { from: "cands", to: "rank", label: "top-k", sides: ["b", "t"] },
        { from: "instr", to: "rank", label: "target" },
        { from: "rank", to: "robot", label: "best grasp g", sides: ["r", "b"], via: [[730, 212]] },
        { from: "robot", to: "cam", label: "lift success", sides: ["t", "t"], via: [[730, 26], [90, 26]], dashed: true }
      ],
      steps: [
        { on: ["cam", "cam>model", "model"], text: "A camera sees the scene. GG-CNN reads one depth image; Contact-GraspNet and AnyGrasp read a point cloud of the whole scene." },
        { on: ["model>cands", "cands"], text: "The model proposes grasps with scores: a quality per pixel (GG-CNN), samples from a VAE (6-DoF GraspNet), or one grasp per observed contact point." },
        { on: ["instr", "instr>rank", "cands>rank", "rank"], text: "A checker ranks candidates by quality and collisions. GraspGPT and ThinkGrasp also ask a language model which grasp fits the instruction." },
        { on: ["rank>robot", "robot"], text: "A motion planner reaches the best grasp and closes the gripper. GraspVLA folds the whole chain into one model that outputs actions." },
        { on: ["robot>cam", "cam"], text: "The lift result can become a label. QT-Opt learned closed-loop grasping from 580k real attempts on seven robots." }
      ]
    },
    worked: {
      title: "Does a tilted grasp on a box hold?",
      ref: "Test: arXiv 1912.13470 (s = 1.1 − μ)", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-grasp-alpha}{\\alpha_i} \\le \\arctan \\class{sym-mu}{\\mu}, \\qquad \\class{sym-sg}{s_g} = 1.1 - \\mu_{\\min}", words: "Each contact angle must fit inside its friction cone; the label rewards grasps that need little friction.", key: ["grasp-alpha", "mu", "sg", { glyph: "μ_min", meaning: "least friction that holds" }] },
      figure: WE_FIG,
      steps: [
        { title: "Write the grasp", text: "A top-down grasp on a 60 mm box: center (0, 0), opening 80 mm, jaws 20 mm, angle 15°. That is the rectangle g." },
        { title: "Close the jaws", text: "Along a 15° line the box is 60 / cos 15° = 62.1 mm across, less than 80 mm. The jaws touch at (−30, −8.0) and (30, 8.0)." },
        { title: "Measure contact angles", text: "Both faces are vertical, so their normals are horizontal. The squeeze line is 15° off each normal: α₁ = α₂ = 15°." },
        { title: "Compare with the cone", text: "With μ = 0.5 the cone half-angle is arctan 0.5 = 26.6°. Both 15° angles fit inside, so the grasp achieves force closure." },
        { title: "Label it", text: "The grasp needs tan 15° = 0.27, so the least friction in 0.1 steps is 0.3. GraspNet-1Billion's label is 1.1 − 0.3 = 0.8." },
        { title: "Tilt to 30°", text: "Now α = 30° > 26.6°: the fingers slide at μ = 0.5. It needs tan 30° = 0.58, so μ_min = 0.6 and s_g = 0.5." }
      ]
    },
    ruleTitle: "The grasp test and the representations built on it",
    rules: [
      { name: "Two-finger force closure", ref: "P01 §4.1 · arXiv 1912.13470", term: "force-closure",
        tex: "\\class{sym-grasp-alpha}{\\alpha_i} = \\angle\\big(-\\hat n_i,\\; p_j - p_i\\big) \\le \\arctan \\class{sym-mu}{\\mu}, \\qquad i = 1, 2",
        words: "The line from one contact to the other must lie within the friction cone at both contacts.",
        key: ["grasp-alpha", { glyph: "n̂ᵢ", meaning: "outward surface normal at contact i" }, { glyph: "pᵢ, pⱼ", meaning: "the two contact points" }, "mu"] },
      { name: "GraspNet-1Billion label", ref: "arXiv 1912.13470", term: "analytic-grasp-label",
        tex: "\\class{sym-sg}{s_g} = 1.1 - \\mu_{\\min}, \\qquad \\mu_{\\min} \\in \\{0.1, 0.2, \\dots, 1.0\\}",
        words: "Find the least friction at which the grasp still holds; the less it needs, the higher its label. ThinkGrasp reuses this score.",
        key: ["sg", { glyph: "μ_min", meaning: "least friction that holds" }] },
      { name: "GG-CNN: one grasp per pixel", ref: "arXiv 1804.05172", term: "grasp-quality-map",
        tex: "M_\\theta(I) = (Q_\\theta,\\ \\Phi_\\theta,\\ W_\\theta), \\qquad \\class{sym-g}{g}^{*} = \\arg\\max_{\\text{pixels}} Q_\\theta",
        words: "A small fully convolutional network maps a depth image to quality, angle and width maps; the best grasp is the brightest pixel.",
        key: [{ glyph: "M_θ", meaning: "the network" }, { glyph: "I", meaning: "depth image" }, { glyph: "Q_θ, Φ_θ, W_θ", meaning: "quality, angle, width maps" }, "g"] },
      { name: "From planar to 6-DoF grasps", ref: "P01 §3.1, §4.1", term: "6-dof-grasp",
        before: "\\class{sym-g}{g} = (x,\\ y,\\ w,\\ h,\\ \\theta)",
        tex: "\\class{sym-g}{g} = (\\class{sb-new}{R},\\ \\class{sb-chg}{t},\\ w), \\qquad \\class{sb-new}{R} \\in SO(3),\\ \\class{sb-chg}{t} = (x, y, z)",
        words: "A full rotation replaces the in-plane angle and the center gains depth, so grasps can come from the side.",
        key: ["g", { glyph: "R", meaning: "gripper orientation (3 × 3)" }, { glyph: "t", meaning: "grasp center in 3-D" }, { glyph: "w", meaning: "gripper width" }, { glyph: "h, θ", meaning: "jaw size, in-plane angle" }],
        diff: true, beforeLabel: "Rectangle", afterLabel: "6-DoF" },
      { name: "Contact-GraspNet: a grasp from a contact", ref: "arXiv 2103.14127",
        tex: "t_g = c + \\tfrac{w}{2}\\, b + d\\, a, \\qquad R_g = [\\, b \\;\\; a \\times b \\;\\; a \\,]",
        words: "Anchor each grasp on an observed point: predict baseline, approach and width there, and the 6-DoF pose follows.",
        key: [{ glyph: "c", meaning: "observed contact point" }, { glyph: "b", meaning: "baseline (jaw-to-jaw) direction" }, { glyph: "a", meaning: "approach direction" }, { glyph: "w", meaning: "grasp width" }, { glyph: "d", meaning: "fixed baseline-to-base offset" }] }
    ],
    algorithm: {
      title: "Label one parallel-jaw grasp analytically", ref: "GraspNet-1Billion · arXiv 1912.13470", prov: "Simplified: 2-D, two point contacts",
      lines: [
        '<span class="kw">input</span> object shape, grasp <span data-sym="g">g</span> = (center, squeeze direction, opening w)',
        'close both jaws along the squeeze line → contacts p₁, p₂',
        '<span class="kw">if</span> the line misses, or the object is wider than w: <span class="kw">return</span> not graspable',
        '<span data-sym="grasp-alpha">α₁, α₂</span> ← angles between the squeeze line and the inward normals',
        '<span class="kw">for</span> <span data-sym="mu">μ</span> = 0.1, 0.2, …, 1.0:',
        '    <span class="kw">if</span> max(<span data-sym="grasp-alpha">α₁, α₂</span>) ≤ arctan <span data-sym="mu">μ</span>: <span class="kw">return</span> <span data-sym="sg">s_g</span> = 1.1 − <span data-sym="mu">μ</span>',
        '<span class="kw">return</span> not graspable <span class="cm">// needs more friction than μ = 1</span>'
      ]
    },
    playgrounds: [
      {
        id: "cones", title: "Place a grasp, check the friction cones", ref: "P01 §3.1 · arXiv 1912.13470", prov: "Simplified: 2-D convex objects, Coulomb friction",
        try: "Tilt the grasp past 27° and watch it slip at μ = 0.5. Then raise μ. Switch to Triangle: every two-face grasp needs about μ = 0.58.",
        mount: mountCones,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e1-cones";
          return [
            { target: q("canvas"), title: "Read the grasp", text: "Two jaws squeeze along the dashed line. Each contact has a friction cone; both are green, so this 15° grasp holds." },
            { target: q("#" + id + "-th"), title: "Tilt the grasp", text: "At 35° the squeeze line leaves the 26.6° cones. The fingers would slide along the faces.", do: function (a) { return a.set(q("#" + id + "-th"), 35); }, task: "Tilt the grasp until it slips", expect: function () { var s = api.state(); return s.shape === "box" && s.kind === "ok" && !s.pass; } },
            { target: q("#" + id + "-mu"), title: "Add friction", text: "A rubbery pad widens the cones. At μ = 0.8 the half-angle is 38.7°, enough for a 35° grasp.", do: function (a) { return a.set(q("#" + id + "-mu"), 0.8); }, task: "Raise friction until the grasp holds", expect: function () { var s = api.state(); return s.pass && s.mu > 0.5; } },
            { target: q("#" + id + "-shape"), title: "Try a triangle", text: "Two faces of a triangle meet at 60°, so any grasp across them has contact angles near 30°.", do: function (a) { return a.click(q("#" + id + '-shape [value="tri"]')); }, task: "Choose Triangle", expect: function () { return api.state().shape === "tri"; } },
            { target: q("#" + id + "-th"), title: "Grasp across two faces", text: "Set the angle to 0°. Both contact angles are 30°, which needs μ ≥ tan 30° = 0.58.", do: function (a) { return a.set(q("#" + id + "-th"), 0); }, task: "Set the grasp angle to 0°", expect: function () { var s = api.state(); return s.shape === "tri" && s.th <= 2; } },
            { target: q("#" + id + "-mu"), title: "Your turn", text: "Lower μ to 0.5 and the triangle slips. Then choose Round and drag the center off the middle: the angles grow." }
          ];
        }
      },
      {
        id: "search", title: "Search for a grasp: sample or map", ref: "P01 Fig. 4 · GG-CNN · 6-DoF GraspNet", prov: "Illustrative: toy objects, μ = 0.5",
        try: "With 5 samples the best grasp is often poor or missing. Raise N, then switch to the dense map and add execution error.",
        mount: mountSearch,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e1-search";
          return [
            { target: q("canvas"), title: "Five random grasps", text: "Sample and rank draws a few grasps, checks each one and keeps the best. With five, most miss the wedge." },
            { target: q("#" + id + "-n"), title: "Sample more", text: "With 150 samples many land on the object and several hold. The best label rises.", do: function (a) { return a.set(q("#" + id + "-n"), 150); }, task: "Raise Samples N above 100", expect: function () { return api.state().N > 100; } },
            { target: q("#" + id + "-mode"), title: "Score every pixel", text: "A dense map checks every cell at 12 angles, the way GG-CNN outputs a quality for each pixel in one pass.", do: function (a) { return a.click(q("#" + id + '-mode [value="dense"]')); }, task: "Choose Dense map", expect: function () { return api.state().mode === "dense"; } },
            { target: q("#" + id + "-err"), title: "Add execution error", text: "Real arms miss by a few millimetres. GG-CNN closed the loop to correct such errors: 68–73% versus 38% open-loop in simulation.", do: function (a) { return a.set(q("#" + id + "-err"), 6); }, task: "Set execution error to 5 mm or more", expect: function () { return api.state().err >= 5; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Compare Box and Triangle under error. The triangle's holding region is narrow, so small errors break it." }
          ];
        }
      }
    ],
    methods: ["gg-cnn", "gr-convnet", "6-dof-graspnet", "contact-graspnet", "graspnet-1billion", "anygrasp", "grasp-anything", "graspgpt", "thinkgrasp", "rt-grasp", "vcot-grasp", "graspvla", "dexgraspnet", "dex1b"],
    methodsLede: "How the line evolved: GG-CNN replaced sample-and-rank with a quality map per pixel, and GR-ConvNet deepened it. 6-DoF GraspNet sampled full poses with a VAE; Contact-GraspNet anchored them on observed points. GraspNet-1Billion and AnyGrasp trained on dense analytic labels from real scans. Grasp-Anything synthesized 1M images. GraspGPT and ThinkGrasp added language; RT-Grasp, VCoT-Grasp and GraspVLA made a VLM output the grasp.",
    open: [
      { title: "Dexterous hands need new labels", text: "Hand grasps need joint angles and contact maps, not rectangles; generative models handle the dimension, but real hands still run open-loop.", refs: "P01 §4.1 · Dex1B" },
      { title: "Transparent and shiny objects", text: "Depth sensors fail on glass and metal, so grasp models lose their input. LiDAR, radar and 3-D reconstruction are early fixes.", refs: "P01 §4.1" },
      { title: "Beyond one end-effector", text: "Suction or a parallel gripper alone limits which shapes can be picked; bimanual and multi-gripper grasping are still young.", refs: "P01 §4.1" },
      { title: "Grasp labels are not actions", text: "2-D grasps need depth and calibration to execute; contact maps and human hand data need a separate generator or retargeting.", refs: "P05 §6.8" }
    ],
    takeaways: [
      "A two-finger grasp holds when the squeeze line lies inside both friction cones, each of half-angle arctan μ.",
      "Grasp labels come from that test: GraspNet-1Billion scores a grasp as 1.1 minus the least friction it needs.",
      "Representations grew from 5-D rectangles to 6-DoF poses to full hand configurations.",
      "Datasets moved from manual labels on hundreds of images to automatic labels on billions of grasps, then added language.",
      "Methods moved from one network per grasp to VLMs that reason about which object and part to grasp."
    ],
    quiz: [
      { q: "A grasp's squeeze line is 20° off both surface normals, and μ = 0.3. Does it hold?", options: ["Yes, any squeeze holds", "No: 20° exceeds arctan 0.3 ≈ 16.7°", "Yes: 20° is below the cone", "Only with a wider opening"], correct: 1, why: "The friction cone half-angle is arctan 0.3 = 16.7°. A 20° contact angle lies outside it, so the fingers slide." },
      { q: "A grasp first holds at μ = 0.4 in GraspNet-1Billion's test. What is its label?", options: ["0.4", "0.6", "0.7", "1.1"], correct: 2, why: "The label is s = 1.1 − μ_min = 1.1 − 0.4 = 0.7 (arXiv 1912.13470)." },
      { q: "What did GG-CNN change compared with sample-and-rank grasp networks?", options: ["It predicts quality, angle and width for every pixel in one pass", "It added language instructions", "It uses a five-fingered hand", "It learns from reinforcement"], correct: 0, why: "A 62,420-parameter network outputs whole grasp maps, fast enough to recompute during the reach for closed-loop grasping (arXiv 1804.05172)." },
      { q: "Why does Contact-GraspNet predict a grasp at each observed point?", options: ["It avoids using depth", "It adds language", "It needs no training data", "It reduces 6-DoF learning to four values per point"], correct: 3, why: "With the contact fixed, only baseline, approach and width remain to predict, and the pose follows (arXiv 2103.14127)." },
      { q: "What did GraspVLA insert between its VLM and its flow-matching action expert?", options: ["A reward model", "A bounding box and a grasp pose as chain-of-thought", "A physics simulator", "A tactile encoder"], correct: 1, why: "Progressive action generation raised real synthetic-category success from 66.6% to 93.3% in its ablation (arXiv 2505.03233)." }
    ],
    cards: [
      { front: "What five numbers define a grasp rectangle?", back: "Center x and y, gripper opening, jaw size, and the angle θ in the image plane.", ref: "P01 §3.1" },
      { front: "When does a two-finger grasp achieve force closure?", back: "When the line between the contacts lies inside both friction cones: each contact angle αᵢ ≤ arctan μ.", ref: "P01 §4.1" },
      { front: "How does GraspNet-1Billion label a grasp?", back: "s = 1.1 − μ, where μ is the smallest friction coefficient, stepped by 0.1, at which the grasp still holds.", ref: "arXiv 1912.13470" },
      { front: "Name P01's five trends in grasp datasets.", back: "Manual to automatic labels, small to large, rectangles to 6-DoF to dexterous, single object to clutter, vision to language.", ref: "P01 §3.1" },
      { front: "How much real data did QT-Opt use for grasping?", back: "580k grasp attempts on 7 KUKA robots, about 800 robot hours; 96% success on unseen objects after on-policy fine-tuning.", ref: "arXiv 1806.10293" },
      { front: "What did DexGraspNet produce, and how?", back: "1.32M ShadowHand grasps on 5355 objects, by faster differentiable force-closure optimization, each checked in Isaac Gym.", ref: "arXiv 2210.02697" }
    ],
    terms: {
      "grasp-rectangle": { name: "grasp rectangle", aliases: ["rectangle grasp", "5-D grasp", "planar grasp"], group: "grasp", sym: "g", symTex: "g", def: "A 5-dimensional grasp label: center position (x, y), the gripper's width and height, and the orientation angle relative to the horizontal axis.", note: "It looks like a bounding box but means something else: where the jaws go, not where the object is.", ref: "P01 §3.1, §4.1", scene: "robot", focus: ["grasp-pose", "gripper"], look: "the jaws' footprint in the image", uses: [] },
      "6-dof-grasp": { name: "6-DoF grasp", aliases: ["6-DoF grasp pose", "SE(3) grasp"], group: "grasp", def: "A grasp given as the end effector's full pose: position (x, y, z), orientation, and often width, approach direction and a quality score.", note: "Rectangles assume top-down grasps; 6-DoF poses allow side grasps in clutter.", ref: "P01 §3.1", scene: "robot", focus: ["grasp-pose", "gripper", "object"], look: "the gripper pose around the object", uses: ["grasp-rectangle"] },
      "friction-cone": { name: "friction cone", aliases: ["Coulomb friction cone"], group: "grasp", sym: "μ", symTex: "\\mu", def: "All contact forces that do not slip under Coulomb friction: a cone around the surface normal with half-angle arctan μ.", note: "A higher μ widens the cone; it does not change the normal's direction.", ref: "arXiv 1912.13470 · 2210.02697", scene: "robot", focus: ["friction-cone", "contact-point"], look: "the cone at each fingertip contact", uses: [] },
      "force-closure": { name: "force closure", aliases: ["force-closure grasp"], group: "grasp", def: "A grasp whose contact forces, within their friction cones, can cancel any external wrench on the object.", note: "Force closure says the grasp can hold, not that the planned squeeze force is enough.", ref: "P01 §4.1 · arXiv 2210.02697", scene: "robot", focus: ["contact-point", "friction-cone", "fingers"], look: "contacts that can resist any push", uses: ["friction-cone"] },
      "antipodal-grasp": { name: "antipodal grasp", aliases: ["antipodal"], group: "grasp", def: "A two-finger grasp whose contacts face each other so the line between them lies inside both friction cones.", note: "GG-CNN and GR-ConvNet output planar antipodal grasps.", ref: "arXiv 1804.05172 · 1909.04810", scene: "robot", focus: ["gripper", "contact-point"], look: "two jaws squeezing opposite faces", uses: ["force-closure", "friction-cone"] },
      "analytic-grasp-label": { name: "analytic grasp label", aliases: ["force-closure score", "grasp quality score"], group: "grasp", sym: "s_g", symTex: "s_g", def: "A grasp quality computed from object geometry and friction instead of robot trials, such as GraspNet-1Billion's 1.1 − μ_min.", note: "Analytic labels scale to billions, but they ignore gripper and arm collisions unless those are checked separately.", ref: "arXiv 1912.13470 · P05 §6.8", scene: "robot", focus: ["grasp-pose", "object"], look: "a score attached to each candidate", uses: ["force-closure"] },
      "grasp-quality-map": { name: "grasp quality map", aliases: ["pixel-wise grasp map", "generative grasp map"], group: "grasp", def: "A network output giving a grasp quality, angle and width for every pixel, so the best grasp is an argmax.", note: "It avoids sampling, so it is fast enough for closed-loop grasping.", ref: "arXiv 1804.05172 · 1909.04810", scene: "robot", focus: ["scene-camera", "grasp-pose"], look: "the heat map over the camera image", uses: ["grasp-rectangle"] },
      "sample-and-rank": { name: "sample and rank", aliases: ["sample-then-evaluate", "candidate ranking"], group: "grasp", def: "A two-stage grasp pipeline: a sampler proposes candidate grasps and an evaluator scores them; the best is executed.", note: "The sampler bounds quality: an evaluator cannot pick a grasp that was never proposed.", ref: "P01 Fig. 4 · arXiv 1905.10520", scene: "robot", focus: ["grasp-pose"], look: "many candidate grippers, one chosen", uses: ["analytic-grasp-label"] },
      "rectangle-metric": { name: "rectangle metric", aliases: ["Jaccard grasp metric"], group: "grasp", def: "A predicted rectangle counts as correct if its angle is within 30° of a label and their overlap (IoU) exceeds 25%.", note: "GraspNet-1Billion found rectangle accuracy overestimates real grasp quality.", ref: "arXiv 1412.3128 · 1912.13470", scene: "robot", focus: ["grasp-pose"], look: "overlap of predicted and labeled rectangles", uses: ["grasp-rectangle"] },
      "language-driven-grasping": { name: "language-driven grasping", aliases: ["language-conditioned grasping", "task-oriented grasping"], group: "grasp", def: "Grasping the object or part an instruction names, by feature fusion, by ranking candidates with an LLM or VLM, or by fine-tuning a grasp foundation model.", note: "Task-oriented grasping also asks how to hold it: a knife by its handle.", ref: "P01 §4.1, Fig. 4", scene: "robot", focus: ["object", "grasp-pose"], look: "the part the instruction names", uses: ["sample-and-rank"] },
      "dexterous-grasp-synthesis": { name: "dexterous grasp synthesis", aliases: ["dexterous grasp generation"], group: "grasp", def: "Finding a wrist pose and finger joint angles for a multi-fingered hand whose contacts give force closure, by optimization or a generative model.", note: "DexGraspNet's optimization finds mostly power grasps; precision grasps are rare.", ref: "P01 §4.1 · arXiv 2210.02697", scene: "robot", focus: ["fingers", "contact-point", "object"], look: "all fingers wrapped around the object", uses: ["force-closure"] }
    },
    symbols: [
      { id: "grasp-alpha", tex: "\\alpha_i", glyph: "αᵢ", kind: "Robot", meaning: "contact angle: between the squeeze direction and the inward surface normal at contact i", short: "contact angle at contact i", first: "e1", read: "alpha sub i", papers: "Grasp-Anything: α_i (torque form) · DexGraspNet: contact normals c" },
      { id: "sg", tex: "s_g", glyph: "s_g", kind: "Functions", meaning: "grasp quality label, e.g. GraspNet-1Billion's 1.1 − μ_min", short: "grasp quality label", first: "e1", read: "s sub g", papers: "GraspNet-1Billion, ThinkGrasp: s · GG-CNN: q · GR-ConvNet: Q" }
    ],
    ledger: [
      { where: "Topic 15 · datasets", source: "P01 Table 1 lists GraspNet with ∼1.2B grasps; P05 Table 6 lists 1.1B; the CVPR paper says over 1.1 billion (the arXiv v1 had 370M)", page: "The page says over 1.1 billion", why: "The method paper's final version is the primary source.", kind: "Sources disagree" },
      { where: "Topic 15 · datasets", source: "P01 Table 1 lists Grasp-Anything++ with 10M grasps; the method paper counts over 10M grasp instructions", page: "The page does not quote a grasp count for Grasp-Anything++", why: "The 10M figure counts instructions, not grasps.", kind: "Sources disagree" },
      { where: "Topic 15 · notation", source: "GraspNet-1Billion and ThinkGrasp write the grasp score as s", page: "Written s_g", why: "s is the state sₜ in house notation.", kind: "Our choice" },
      { where: "Topic 15 · rectangle", source: "P01 writes (x, y, width, height, θ); GG-CNN writes (s, φ̃, w̃, q)", page: "g = (x, y, w, h, θ) with w the opening", why: "One planar form across the topic.", kind: "Our choice" },
      { where: "Topic 15 · playgrounds", source: "Real labels use 3-D meshes, soft contacts, gripper collisions and physics checks", page: "2-D convex objects, two point contacts, Coulomb friction; dense-map ties broken by the neighbours' mean score", why: "Shows the friction-cone test and the search strategies alone.", kind: "Simplified" }
    ]
  });
})();
