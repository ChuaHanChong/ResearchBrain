/* Topic 11 · World action models. Sources: P04 §2–4 (eq. 1–7 definition, §3 three philosophies, eq. 10–12 couplings,
   eq. 33–37 deployment and the (Φ, F, B, D) tuple, Tables 1–2), X1 §2, §4, §7 (cascaded vs joint), P03 §3.1 (eq. 4–8: one joint,
   four queries; Table 1), method cards (UniPi → AVDC → SuSIE → GR-1 → PAD → UVA → UWM → VPP / mimic-video / FLARE →
   Cosmos Policy → DreamZero / LingBot-VA → Fast-WAM). */
(function () {
  "use strict";
  var RB = window.RB;
  /* RB.bindSeg reads .value from the value string StudyBench.segmented already passes, so wire segments directly (as topics a3, b1) */
  function onSeg(root, id, cb) { StudyBench.segmented(root.querySelector("#" + id), function (v, b) { cb(b && b.value ? b.value : v); }); }

  function monoFont() { return getComputedStyle(document.body).getPropertyValue("--font-mono"); }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body"); }

  /* ---------- playground 1: one joint distribution, four queries ---------- */
  /* Toy: a robot pushes a cup across a table. Action a = push direction in [-1, 1]; outcome o' = where the cup
     ends along the far edge, in [-1, 1]. Bins at ±0.55. The joint p(o', a | o, l) = demonstrator policy × dynamics,
     computed exactly on a 25 × 25 grid. Everything here is our toy. */
  var NB = 25, BIN = 0.55, BIN_W = 0.15;
  function xb(i) { return -1 + 2 * i / (NB - 1); }
  function gauss(x, m, s) { return Math.exp(-(x - m) * (x - m) / (2 * s * s)); }
  function dyn(a, wall) { if (!wall) return a; var m = Math.abs(a); return m <= 0.7 ? a : (a < 0 ? -1 : 1) * (1.4 - m); }
  function buildJoint(instr, sigma, wall) {
    var pa = [], Z = 0, i, j;
    for (i = 0; i < NB; i++) {
      var x = xb(i), w = instr === "either" ? 0.5 * gauss(x, -BIN, 0.12) + 0.5 * gauss(x, BIN, 0.12) : instr === "left" ? gauss(x, -BIN, 0.12) : 1;
      pa.push(w); Z += w;
    }
    pa = pa.map(function (w) { return w / Z; });
    var J = [];
    for (j = 0; j < NB; j++) J.push(new Array(NB).fill(0));
    for (i = 0; i < NB; i++) {
      var g = dyn(xb(i), wall), col = [], Zc = 0;
      for (j = 0; j < NB; j++) { var v = gauss(xb(j), g, sigma); col.push(v); Zc += v; }
      for (j = 0; j < NB; j++) J[j][i] = pa[i] * col[j] / Zc;
    }
    return J; /* J[j][i] = p(o' = y_j, a = x_i) */
  }
  function query(J, q, c) {
    var d = new Array(NB).fill(0), i, j, Z = 0;
    for (j = 0; j < NB; j++) for (i = 0; i < NB; i++) {
      if (q === "policy") d[i] += J[j][i];
      else if (q === "video") d[j] += J[j][i];
      else if (q === "forward" && i === c) d[j] += J[j][i];
      else if (q === "idm" && j === c) d[i] += J[j][i];
    }
    d.forEach(function (v) { Z += v; });
    return Z > 0 ? d.map(function (v) { return v / Z; }) : d;
  }
  function stats(d) {
    var m = 0, s2 = 0, best = 0, peaks = 0, mx = Math.max.apply(null, d);
    d.forEach(function (p, i) { m += p * xb(i); if (p > d[best]) best = i; });
    d.forEach(function (p, i) { s2 += p * (xb(i) - m) * (xb(i) - m); });
    for (var i = 0; i < NB; i++) { var l = i ? d[i - 1] : -1, r = i < NB - 1 ? d[i + 1] : -1; if (d[i] >= l && d[i] > r && d[i] > 0.15 * mx) peaks++; }
    return { best: xb(best), sd: Math.sqrt(s2), peaks: peaks };
  }

  function mountQueries(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-q", label: "Query", value: "policy", options: [{ value: "policy", label: "Policy" }, { value: "video", label: "Video model" }, { value: "forward", label: "Forward model" }, { value: "idm", label: "Inverse dynamics" }] }) +
      RB.slider({ id: id + "-c", label: "Fixed value", min: 0, max: NB - 1, step: 1, value: 19, fmt: function (v) { return RB.fmt(xb(v), 2); } }) + "</div>" +
      '<div class="rb-row">' + RB.seg({ id: id + "-i", label: "Instruction", value: "either", options: [{ value: "either", label: "Either bin" }, { value: "left", label: "Left bin" }, { value: "play", label: "Play data" }] }) +
      RB.slider({ id: id + "-s", label: "Dynamics noise σ", min: 0.02, max: 0.4, step: 0.02, value: 0.08, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-wall"> <span>Bouncing side wall</span></label></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Heat map of the joint distribution over push direction and where the cup ends"></canvas>' +
      '<figcaption class="sb-caption">Brightness is p(o′, a): push direction across, where the cup ends upward. Green bands mark the bins. The outlined slice or the arrow shows what the query keeps.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "q", k: "Query" }, { id: "best", k: "Most likely value" }, { id: "sd", k: "Spread (sd)" }, { id: "pk", k: "Peaks" }]) +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-bars" aria-label="Bar chart of the queried distribution"></canvas></figure>' +
      '<p class="sb-caption" data-note></p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), bars = body.querySelector("#" + id + "-bars"), note = body.querySelector("[data-note]");
    var cIn = body.querySelector("#" + id + "-c"), cLab = cIn.parentNode.querySelector("span");
    var st = { q: "policy", c: 19, instr: "either", sigma: 0.08, wall: false }, J = null, dist = null;
    var NOTES = {
      policy: "Summing over the future gives p(a | o, ℓ), what a VLA learns. UWM gets this query by leaving o′ at pure noise.",
      video: "Summing over the action gives the passive video model p(o′ | o, ℓ). UniPi's planner answers this query, and action-free video can train it.",
      forward: "Fixing a gives p(o′ | o, a): the consequence of one push. Scoring routes query this to rank candidate actions.",
      idm: "Fixing o′ gives p(a | o, o′): which push made this future. Cascades such as UniPi decode their actions this way."
    };
    var FORM = { policy: "Σ over o′", video: "Σ over a", forward: "fix a", idm: "fix o′" };
    var W = 380, H = 380, X0 = 58, Y0 = 14, S = 300, cell = S / NB;
    function px(v) { return X0 + (v + 1) / 2 * S; }
    function py(v) { return Y0 + S - (v + 1) / 2 * S; }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont(), bf = bodyFont(), i, j, mx = 0;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      [-BIN, BIN].forEach(function (b) { c.fillStyle = P["good-soft"]; c.fillRect(X0 - 12, py(b + BIN_W), 8, py(b - BIN_W) - py(b + BIN_W)); });
      for (j = 0; j < NB; j++) for (i = 0; i < NB; i++) mx = Math.max(mx, J[j][i]);
      c.fillStyle = P["surface-sunk"]; c.fillRect(X0, Y0, S, S);
      for (j = 0; j < NB; j++) for (i = 0; i < NB; i++) {
        var on = (st.q === "forward" && i !== st.c) || (st.q === "idm" && j !== st.c) ? 0.22 : 1;
        c.globalAlpha = on * Math.sqrt(J[j][i] / mx);
        c.fillStyle = P["data-1"]; c.fillRect(X0 + i * cell, Y0 + (NB - 1 - j) * cell, cell + 0.5, cell + 0.5);
      }
      c.globalAlpha = 1; c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.strokeRect(X0, Y0, S, S);
      c.strokeStyle = P.accent; c.lineWidth = 2; c.fillStyle = P.accent;
      if (st.q === "forward") c.strokeRect(X0 + st.c * cell, Y0, cell, S);
      if (st.q === "idm") c.strokeRect(X0, Y0 + (NB - 1 - st.c) * cell, S, cell);
      if (st.q === "policy") { c.beginPath(); c.moveTo(X0 + S / 2 - 8, Y0 + S + 4); c.lineTo(X0 + S / 2 + 8, Y0 + S + 4); c.lineTo(X0 + S / 2, Y0 + S + 14); c.fill(); }
      if (st.q === "video") { c.beginPath(); c.moveTo(X0 - 16, Y0 + S / 2 - 8); c.lineTo(X0 - 16, Y0 + S / 2 + 8); c.lineTo(X0 - 26, Y0 + S / 2); c.fill(); }
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.textAlign = "center";
      [-1, -0.5, 0, 0.5, 1].forEach(function (v) { c.fillText(RB.fmt(v, 1), px(v), Y0 + S + 28); });
      c.textAlign = "right"; [-1, -0.5, 0, 0.5, 1].forEach(function (v) { c.fillText(RB.fmt(v, 1), X0 - 16, py(v) + 4); });
      c.textAlign = "center"; c.fillStyle = P["ink-2"]; c.font = "600 12px " + bf; c.fillText("push direction a", X0 + S / 2, H - 12);
      c.save(); c.translate(14, Y0 + S / 2); c.rotate(-Math.PI / 2); c.fillText("where the cup ends o′", 0, 0); c.restore();
      c.textAlign = "start";
      drawBars();
    }
    function drawBars() {
      var P = RB.pal(), BW = 380, BH = 190, c = RB.canvas(bars, BW, BH), bx0 = 30, bw = 330, by0 = 16, bh = 130, mx = Math.max.apply(null, dist) || 1, onO = st.q === "video" || st.q === "forward";
      c.fillStyle = P.surface; c.fillRect(0, 0, BW, BH);
      if (onO) [-BIN, BIN].forEach(function (b) { c.fillStyle = P["good-soft"]; c.fillRect(bx0 + (b - BIN_W + 1) / 2 * bw, by0, BIN_W * bw, bh); });
      dist.forEach(function (p, i) { var h = p / mx * (bh - 6); c.fillStyle = P["data-2"]; c.fillRect(bx0 + i * bw / NB + 1, by0 + bh - h, bw / NB - 2, h); });
      c.strokeStyle = P["line-strong"]; c.beginPath(); c.moveTo(bx0, by0 + bh + 0.5); c.lineTo(bx0 + bw, by0 + bh + 0.5); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + monoFont(); c.textAlign = "center";
      [-1, 0, 1].forEach(function (v) { c.fillText(RB.fmt(v, 0), bx0 + (v + 1) / 2 * bw, by0 + bh + 16); });
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + bodyFont();
      c.fillText(onO ? "result: distribution of o′ (where the cup ends)" : "result: distribution of a (push direction)", bx0 + bw / 2, BH - 8);
      c.textAlign = "start";
    }
    function run() {
      J = buildJoint(st.instr, st.sigma, st.wall);
      dist = query(J, st.q, st.c);
      var s = stats(dist), cond = st.q === "forward" || st.q === "idm";
      cIn.disabled = !cond;
      if (cLab) cLab.textContent = st.q === "forward" ? "Fixed action a" : st.q === "idm" ? "Fixed future o′" : "Fixed value";
      RB.setRO(body, "q", FORM[st.q]);
      RB.setRO(body, "best", RB.fmt(s.best, 2));
      RB.setRO(body, "sd", RB.fmt(s.sd, 2));
      RB.setRO(body, "pk", String(s.peaks));
      note.textContent = NOTES[st.q];
      draw();
    }
    onSeg(body, id + "-q", function (v) { st.q = v; run(); });
    onSeg(body, id + "-i", function (v) { st.instr = v; run(); });
    RB.bindSlider(body, id + "-c", function (v) { return RB.fmt(xb(v), 2); }, function (v) { st.c = v; run(); });
    RB.bindSlider(body, id + "-s", function (v) { return (+v).toFixed(2); }, function (v) { st.sigma = v; run(); });
    body.querySelector("#" + id + "-wall").addEventListener("change", function (e) { st.wall = e.target.checked; run(); });
    run();
    RB.onTheme(draw);
    return { state: function () { var s = stats(dist); return { q: st.q, c: st.c, instr: st.instr, sigma: st.sigma, wall: st.wall, peaks: s.peaks, sd: s.sd }; } };
  }

  /* ---------- playground 2: the latency budget of three inference paths ---------- */
  /* Per-call latencies are Fast-WAM's measurements for its three variants on one RTX 5090D (arXiv 2603.16666):
     skip future video 190 ms, generate video jointly 580 ms, video then inverse dynamics 810 ms.
     The timeline (wait or overlap, a nudge at 1.3 s) is our toy. */
  var PATHS = { skip: { ms: 190, name: "Skip video (Fast-WAM)" }, joint: { ms: 580, name: "Joint video (Fast-WAM-Joint)" }, idm: { ms: 810, name: "Video, then IDM (Fast-WAM-IDM)" } };
  var T_NUDGE = 1300, T_VIEW = 4000;
  function schedule(L, Tc, mode) {
    /* returns inference intervals, chunk intervals, idle intervals up to 12 s */
    var inf = [], ch = [], idle = [], t = 0, start, n;
    if (mode === "wait") {
      for (n = 0; t < 12000; n++) { inf.push([t, t + L]); ch.push([t + L, t + L + Tc]); idle.push([t, t + L]); t += L + Tc; }
    } else {
      inf.push([0, L]); start = L; idle.push([0, L]);
      for (n = 0; start < 12000; n++) {
        ch.push([start, start + Tc]);
        inf.push([start, start + L]);
        var next = start + Math.max(Tc, L);
        if (L > Tc) idle.push([start + Tc, next]);
        start = next;
      }
    }
    return { inf: inf, ch: ch, idle: idle };
  }
  function react(sch, mode) {
    /* first inference that starts at or after the nudge; its chunk is the first that can respond */
    for (var n = 0; n < sch.inf.length; n++) {
      if (sch.inf[n][0] >= T_NUDGE) { var c = mode === "wait" ? sch.ch[n] : sch.ch[n]; return c ? c[0] - T_NUDGE : NaN; }
    }
    return NaN;
  }

  function mountBudget(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-p", label: "Inference path", value: "joint", options: [{ value: "skip", label: "Skip video" }, { value: "joint", label: "Joint video" }, { value: "idm", label: "Video→IDM" }] }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-h", label: "Actions per chunk H", min: 4, max: 48, step: 4, value: 16 }) +
      RB.slider({ id: id + "-f", label: "Control rate (Hz)", min: 10, max: 50, step: 5, value: 30 }) +
      RB.seg({ id: id + "-m", label: "Execution", value: "wait", options: [{ value: "wait", label: "Wait first" }, { value: "overlap", label: "Overlap" }] }) + "</div>" +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Timeline of model inference and robot execution over four seconds"></canvas>' +
      '<figcaption class="sb-caption">Top lane: model calls. Bottom lane: chunks the robot runs; red gaps are waiting. The dashed line is a nudge to the cup; the green mark is the first chunk that saw it.</figcaption></figure>' +
      RB.readouts([{ id: "lat", k: "Model time per chunk", u: "ms" }, { id: "dur", k: "Chunk lasts", u: "ms" }, { id: "per", k: "Model time per action", u: "ms" }, { id: "bud", k: "Budget per action", u: "ms" }, { id: "idle", k: "Robot waiting" }, { id: "re", k: "Reaction to the nudge", u: "ms" }]) +
      '<p class="sb-caption" data-note></p>';
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    var st = { p: "joint", H: 16, f: 30, m: "wait" }, sch = null, rdel = NaN;
    var W = 620, Hc = 190;
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, Hc), x0 = 70, x1 = W - 16, sx = function (t) { return x0 + t / T_VIEW * (x1 - x0); }, mono = monoFont(), bf = bodyFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, Hc);
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + bf; c.fillText("model", 10, 52); c.fillText("robot", 10, 112);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (var s = 0; s <= T_VIEW; s += 1000) { c.beginPath(); c.moveTo(sx(s), 24); c.lineTo(sx(s), 140); c.stroke(); }
      function lane(list, y, col, h) { list.forEach(function (iv) { if (iv[0] >= T_VIEW) return; var a = sx(iv[0]), b = sx(Math.min(iv[1], T_VIEW)); c.fillStyle = col; c.fillRect(a + 0.5, y, Math.max(1, b - a - 1), h); }); }
      lane(sch.inf, 36, P["data-2"], 22);
      lane(sch.idle, 96, P["bad-soft"], 24);
      lane(sch.ch, 96, P["data-1"], 24);
      /* action ticks inside chunks */
      c.strokeStyle = P.surface; c.lineWidth = 1;
      sch.ch.forEach(function (iv) { if (iv[0] >= T_VIEW) return; var step = 1000 / st.f; for (var t = iv[0] + step; t < iv[1] - 1 && t < T_VIEW; t += step) { if ((st.H > 24) && Math.round((t - iv[0]) / step) % 4) continue; c.beginPath(); c.moveTo(sx(t), 99); c.lineTo(sx(t), 117); c.stroke(); } });
      c.strokeStyle = P.warn; c.lineWidth = 2; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(sx(T_NUDGE), 22); c.lineTo(sx(T_NUDGE), 140); c.stroke(); c.setLineDash([]);
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + bf; c.fillText("cup nudged", sx(T_NUDGE) + 6, 18);
      if (!isNaN(rdel) && T_NUDGE + rdel <= T_VIEW) {
        var xr = sx(T_NUDGE + rdel); c.fillStyle = P.good; c.beginPath(); c.moveTo(xr, 124); c.lineTo(xr - 6, 134); c.lineTo(xr + 6, 134); c.fill();
        c.fillStyle = P["ink-2"]; c.fillText("reacts", Math.min(xr - 18, W - 60), 150);
      }
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.textAlign = "center";
      for (var s2 = 0; s2 <= T_VIEW; s2 += 1000) c.fillText(s2 / 1000 + " s", sx(s2), 172);
      c.textAlign = "start";
    }
    function run() {
      var L = PATHS[st.p].ms, Tc = st.H / st.f * 1000, per = L / st.H, bud = 1000 / st.f;
      sch = schedule(L, Tc, st.m);
      rdel = react(sch, st.m);
      var idle = st.m === "wait" ? L / (L + Tc) : Math.max(0, L - Tc) / Math.max(Tc, L);
      RB.setRO(body, "lat", String(L));
      RB.setRO(body, "dur", String(Math.round(Tc)));
      RB.setRO(body, "per", RB.fmt(per, 0)); RB.setRO(body, "bud", RB.fmt(bud, 0));
      RB.setRO(body, "idle", Math.round(idle * 100) + "%");
      RB.setRO(body, "re", isNaN(rdel) ? "–" : String(Math.round(rdel)));
      note.textContent = (per < bud ? "Budget met: " : "Budget missed: ") + "P04 eq. 34 asks Nfwd(H)/H < 1/f_ctrl. " + (st.m === "wait" ? "Waiting for every call leaves the robot idle anyway; overlap thinking and acting to use the budget." : per < bud ? "Overlapping hides the call entirely, but a longer chunk still delays the reaction." : "Even with overlap, the robot waits because each call outlasts its chunk.");
      draw();
    }
    onSeg(body, id + "-p", function (v) { st.p = v; run(); });
    onSeg(body, id + "-m", function (v) { st.m = v; run(); });
    RB.bindSlider(body, id + "-h", null, function (v) { st.H = v; run(); });
    RB.bindSlider(body, id + "-f", null, function (v) { st.f = v; run(); });
    run();
    RB.onTheme(draw);
    return { state: function () { return { p: st.p, H: st.H, f: st.f, m: st.m, react: rdel }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token colors only) ---------- */
  var ART = {
    wam: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="4" y="16" width="50" height="24" rx="4" class="rb-f-surface"/><text x="29" y="32" text-anchor="middle" class="rb-t-mono">o, ℓ</text><path d="M56 24 L90 13 M56 32 L90 43" class="rb-s-ink"/><rect x="92" y="3" width="44" height="20" rx="4" class="rb-f-soft"/><text x="114" y="17" text-anchor="middle" class="rb-t-acc">o′</text><rect x="92" y="33" width="44" height="20" rx="4" class="rb-f-soft"/><text x="114" y="47" text-anchor="middle" class="rb-t-acc">a</text><path d="M114 23 V33" class="rb-s-acc"/><text x="146" y="32" class="rb-t-mono">coupled</text></svg>',
    cascade: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (6 + i * 22) + '" y="16" width="18" height="24" rx="2" class="rb-f-sunk"/><circle cx="' + (12 + i * 22 + i * 1.5) + '" cy="' + (32 - i * 3) + '" r="3" class="rb-f-acc"/>'; }).join("") + '<path d="M96 28 H116" class="rb-s-ink"/><rect x="118" y="16" width="40" height="24" rx="4" class="rb-f-soft"/><text x="138" y="32" text-anchor="middle" class="rb-t-acc">IDM</text><path d="M160 28 H176" class="rb-s-ink"/><text x="186" y="32" text-anchor="middle" class="rb-t-ink">a</text><text x="48" y="52" text-anchor="middle" class="rb-t-mono">imagined frames</text></svg>',
    score: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="20" cy="28" r="5" class="rb-f-surface"/><path d="M26 28 L96 8 M26 28 L96 28 M26 28 L96 48" class="rb-s-line" stroke-dasharray="3 3"/><circle cx="104" cy="8" r="5" class="rb-f-surface"/><circle cx="104" cy="28" r="6" class="rb-f-acc"/><circle cx="104" cy="48" r="5" class="rb-f-surface"/><text x="118" y="12" class="rb-t-mono">0.3</text><text x="118" y="32" class="rb-t-acc">0.9 run</text><text x="118" y="52" class="rb-t-mono">0.1</text></svg>',
    joint: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="10" width="70" height="36" rx="5" class="rb-f-soft"/><text x="41" y="32" text-anchor="middle" class="rb-t-acc">one model</text><path d="M78 20 L104 12 M78 36 L104 44" class="rb-s-ink"/>' + [0, 1, 2].map(function (i) { return '<rect x="' + (108 + i * 18) + '" y="3" width="15" height="16" rx="2" class="rb-f-sunk"/>'; }).join("") + [0, 1, 2, 3, 4].map(function (i) { return '<rect x="' + (108 + i * 11) + '" y="' + (38 + (i % 2) * 3) + '" width="8" height="' + (12 - (i % 2) * 3) + '" rx="1" class="rb-f-acc"/>'; }).join("") + '<text x="170" y="15" class="rb-t-mono">o′</text><text x="170" y="50" class="rb-t-mono">a</text></svg>',
    philo: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M8 24 H192" class="rb-s-line"/><path d="M186 19 L192 24 L186 29" class="rb-s-line"/><text x="8" y="14" class="rb-t-mono">noise</text><text x="192" y="14" text-anchor="end" class="rb-t-mono">pixels</text><circle cx="30" cy="24" r="5" class="rb-f-surface"/><circle cx="100" cy="24" r="5" class="rb-f-soft"/><circle cx="170" cy="24" r="5" class="rb-f-acc"/><text x="30" y="46" text-anchor="middle" class="rb-t-mono">no video</text><text x="100" y="46" text-anchor="middle" class="rb-t-mono">latent</text><text x="170" y="46" text-anchor="middle" class="rb-t-mono">render</text></svg>',
    anatomy: '<svg viewBox="0 0 200 56" aria-hidden="true">' + ["Φ", "F", "B", "D"].map(function (g, i) { return '<rect x="' + (8 + i * 48) + '" y="12" width="40" height="30" rx="6" class="' + (i === 0 ? "rb-f-soft" : "rb-f-surface") + '"/><text x="' + (28 + i * 48) + '" y="32" text-anchor="middle" class="' + (i === 0 ? "rb-t-acc" : "rb-t-ink") + '">' + g + "</text>"; }).join("") + '<text x="100" y="54" text-anchor="middle" class="rb-t-mono">substrate · coupling · backbone · regime</text></svg>',
    cotrain: '<svg viewBox="0 0 200 56" aria-hidden="true"><text x="8" y="14" class="rb-t-mono">train</text><rect x="48" y="4" width="54" height="16" rx="3" class="rb-f-soft"/><text x="75" y="16" text-anchor="middle" class="rb-t-acc">video</text><rect x="108" y="4" width="40" height="16" rx="3" class="rb-f-acc"/><text x="8" y="46" class="rb-t-mono">test</text><rect x="48" y="36" width="54" height="16" rx="3" class="rb-f-surface" stroke-dasharray="3 3"/><path d="M52 40 L98 48" class="rb-s-line"/><rect x="108" y="36" width="40" height="16" rx="3" class="rb-f-acc"/><text x="156" y="16" class="rb-t-mono">+ a</text><text x="156" y="48" class="rb-t-mono">a only</text></svg>'
  };

  /* ---------- worked example figure: a 3 × 3 joint table and its four queries (our numbers) ---------- */
  var CX = [185, 275, 365], RY = [44, 80, 116], CW = 90, CH = 36;
  var JT = [["0.36", "0.005", "0"], ["0.09", "0.09", "0.09"], ["0", "0.005", "0.36"]];
  var WE_FIG = '<svg viewBox="0 0 560 210" role="img" aria-label="Three by three table of p of future and action for pushing a cup, with column sums, row sums and highlighted slices">' +
    '<g class="rb-t-mono">' + ["push L", "push S", "push R"].map(function (t, i) { return '<text x="' + CX[i] + '" y="18" text-anchor="middle">' + t + "</text>"; }).join("") +
    ["o′ = left bin", "o′ = stays", "o′ = right bin"].map(function (t, j) { return '<text x="132" y="' + (RY[j] + 4) + '" text-anchor="end">' + t + "</text>"; }).join("") + "</g>" +
    '<g data-on="1+">' + JT.map(function (row, j) { return row.map(function (v, i) { return '<rect x="' + (CX[i] - CW / 2) + '" y="' + (RY[j] - CH / 2) + '" width="' + CW + '" height="' + CH + '" class="rb-f-surface"/><text x="' + CX[i] + '" y="' + (RY[j] + 4) + '" text-anchor="middle" class="rb-t-ink">' + v + "</text>"; }).join(""); }).join("") + "</g>" +
    '<g data-on="2+"><text x="120" y="158" text-anchor="end" class="rb-t-mono">Σ over o′</text>' + ["0.45", "0.10", "0.45"].map(function (v, i) { return '<text x="' + CX[i] + '" y="158" text-anchor="middle" class="rb-t-acc">' + v + "</text>"; }).join("") + "</g>" +
    '<g data-on="3+"><text x="470" y="18" text-anchor="middle" class="rb-t-mono">Σ over a</text>' + ["0.365", "0.27", "0.365"].map(function (v, j) { return '<text x="470" y="' + (RY[j] + 4) + '" text-anchor="middle" class="rb-t-acc">' + v + "</text>"; }).join("") + "</g>" +
    '<g data-on="4"><rect x="' + (CX[1] - CW / 2) + '" y="' + (RY[0] - CH / 2) + '" width="' + CW + '" height="' + 3 * CH + '" class="rb-s-acc"/><text x="20" y="194" class="rb-t-ink">p(o′ | a = S) = 0.005, 0.09, 0.005 ÷ 0.10 = 0.05, 0.90, 0.05</text></g>' +
    '<g data-on="5"><rect x="' + (CX[0] - CW / 2) + '" y="' + (RY[1] - CH / 2) + '" width="' + 3 * CW + '" height="' + CH + '" class="rb-s-acc"/><text x="20" y="194" class="rb-t-ink">p(a | o′ = stays) = 0.09 ÷ 0.27 = 0.33 each · p(L | left bin) = 0.986</text></g>' +
    '<g data-on="6"><rect x="' + (CX[0] - CW / 2) + '" y="' + (RY[0] - CH / 2) + '" width="' + CW + '" height="' + CH + '" class="rb-s-acc"/><path d="M448 44 H240" class="rb-s-acc"/><path d="M246 38 L238 44 L246 50" class="rb-s-acc"/><text x="20" y="194" class="rb-t-ink">cascade: 0.365 (imagine left bin) × 0.986 (decode L) = 0.36, the joint cell</text></g></svg>';

  RB.topic({
    id: "c2",
    title: "World action models",
    eyebrow: "Part C · World action models",
    lede: "A world action model predicts the future and the action together, so what the robot expects to happen shapes what it does.",
    refs: ["P04 §2–4", "X1 §2, §4", "P03 §3.1"],
    why: "A vision-language-action (VLA) policy maps what it sees to an action without predicting consequences. A world model predicts consequences but does not act. A world action model (WAM) couples the two: a predicted future helps produce, score or train the action. That costs compute, so recent WAMs generate less of the future at test time.",
    outcomes: [
      "Distinguish a VLA, a world model and a WAM by their training objectives.",
      "Derive policy, video, forward and inverse models from one joint distribution.",
      "Compare cascaded, scoring and joint couplings and name methods using each.",
      "Place a WAM on P04's four axes: substrate, coupling, backbone, deployment.",
      "Check whether a WAM's inference time fits a chunked control budget."
    ],
    concepts: [
      { name: "The future joins the action", def: "A WAM keeps a predicted future o′ in the path that produces, scores or trains the action.", ref: "P04 §2.3, Fig. 1", art: ART.wam, term: "world-action-model", sym: "op" },
      { name: "Cascade: imagine, then decode", def: "A video model imagines the future; a separate inverse dynamics model, tracker or policy reads the action off it.", ref: "P04 eq. 5 · X1 §4.1", art: ART.cascade, term: "cascaded-wam", sym: "pihead" },
      { name: "Score: propose, then predict", def: "Candidate actions go through an action-conditioned model; the best predicted consequence decides what runs.", ref: "P04 eq. 6, §4.3.1", art: ART.score, term: "action-conditioned-rollout" },
      { name: "Joint: one model, both outputs", def: "One backbone generates the future and the action chunk together, trained with one combined loss.", ref: "P04 eq. 7, 19 · X1 §4.2", art: ART.joint, term: "joint-wam", sym: "achunk" },
      { name: "How far the dream goes", def: "Render pixels, stop at intermediate latents, or skip the video generator: P04's three design philosophies.", ref: "P04 §3, Fig. 2", art: ART.philo, term: "render-and-decode" },
      { name: "Four-axis anatomy", def: "Substrate Φ, coupling F, backbone B and deployment D place any WAM as one 4-tuple.", ref: "P04 eq. 37, Fig. 4", art: ART.anatomy, term: "predictive-substrate", sym: "wam-phi", href: "#lab/wam" },
      { name: "Video for training only", def: "Predicting video during training shapes the features; at test time the video branch can be skipped.", ref: "Fast-WAM, arXiv 2603.16666", art: ART.cotrain, term: "video-co-training" }
    ],
    flow: {
      title: "Where a WAM acts at run time", ref: "P04 Fig. 2, 6 · P03 Fig. 3", w: 870, h: 280,
      caption: "The trunk predicts a future; the action head reads it. The dashed path is the Latent-Only shortcut: act on trunk features without finishing the future.",
      nodes: [
        { id: "obs", x: 20, y: 40, w: 180, h: 56, label: "Observation oₜ", sub: "image + instruction ℓ", kind: "env" },
        { id: "trunk", x: 280, y: 40, w: 170, h: 56, label: "Video trunk", sub: "Wan, Cosmos, SVD", kind: "agent" },
        { id: "fut", x: 520, y: 40, w: 200, h: 56, label: "Predicted future o′", sub: "frames, latents, tokens", kind: "store" },
        { id: "head", x: 520, y: 180, w: 200, h: 56, label: "Action head π_ψ", sub: "IDM, flow, denoiser", kind: "agent" },
        { id: "robot", x: 760, y: 180, w: 100, h: 56, label: "Robot", sub: "runs chunk", kind: "env" }
      ],
      edges: [
        { from: "obs", to: "trunk", label: "pixels + ℓ" },
        { from: "trunk", to: "fut", label: "denoise" },
        { from: "fut", to: "head", label: "imagined o′", sides: ["b", "t"] },
        { from: "trunk", to: "head", label: "features", sides: ["b", "l"], via: [[365, 208]], dashed: true },
        { from: "head", to: "robot", label: "chunk" },
        { from: "robot", to: "obs", label: "real frame", sides: ["b", "b"], via: [[810, 266], [110, 266]], dy: -6 }
      ],
      steps: [
        { on: ["obs", "obs>trunk", "trunk"], text: "The camera image and instruction enter a pretrained trunk. Recent WAMs start from video generators: Wan in DreamZero and Fast-WAM, Cosmos in Cosmos Policy." },
        { on: ["trunk>fut", "fut"], text: "UniPi denoises a whole future video. SuSIE renders one subgoal image. GR-1 and PAD predict future frames jointly with the action." },
        { on: ["fut>head", "head"], text: "A cascade decodes the action from the imagined future with a separate head: UniPi's inverse dynamics model, AVDC's optical flow and depth." },
        { on: ["trunk>head", "head"], text: "Latent-Only methods stop early: VPP reads features after one denoising pass, mimic-video from a partially denoised state, Fast-WAM with no future frames at all." },
        { on: ["head>robot", "robot", "robot>obs", "obs"], text: "The robot runs the chunk and a real frame comes back. DreamZero writes real frames over its predictions in the cache, so errors do not compound." }
      ]
    },
    worked: {
      title: "Four queries of one small joint table",
      ref: "P03 eq. 4–8 · P04 eq. 5", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-pihead}{\\pi_\\psi}(\\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sym-op}{o'}, \\class{sym-l}{\\ell}) = \\frac{\\class{sym-ptheta}{p}(\\class{sym-op}{o'}, \\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})}{\\sum_{a} \\class{sym-ptheta}{p}(\\class{sym-op}{o'}, a \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})}", words: "Inverse dynamics is the joint's row for one future, divided by that row's total. The other queries are sums or columns.", key: ["pihead", "a", "o", "op", "l", "ptheta", { glyph: "Σₐ", meaning: "sum over the three pushes" }] },
      figure: WE_FIG,
      steps: [
        { title: "Fill in the joint", text: "Demos push left 45%, straight 10%, right 45%. Times the cup's dynamics, each cell is p(o′, a); all nine sum to 1." },
        { title: "Policy: sum each column", text: "Summing out the future gives p(a | o, ℓ) = 0.45, 0.10, 0.45. No future is needed, as in a plain VLA." },
        { title: "Video model: sum rows", text: "Summing out the action gives the passive video model p(o′ | o, ℓ): left bin 0.365, stays 0.27, right bin 0.365." },
        { title: "Forward model: fix a", text: "Fix a = straight and divide its column by 0.10: p(o′ | a) = 0.05, 0.90, 0.05. The cup mostly stays." },
        { title: "Inverse dynamics: fix o′", text: "Fix o′ = stays: 0.09 ÷ 0.27 = 1/3 for every push, so this future is ambiguous. Fix the left bin: p(L) = 0.986." },
        { title: "The cascade recovers it", text: "Imagine the left bin (0.365), decode L (0.986): 0.365 × 0.986 = 0.36, the same cell. A cascade factorizes the joint." }
      ]
    },
    ruleTitle: "From VLA objective to WAM anatomy",
    rules: [
      { name: "From VLA to WAM: predict the future too", ref: "P04 eq. 1, 7 · X1 §2", term: "world-action-model",
        before: "\\class{sym-L}{\\mathcal{L}}_{\\text{VLA}} = \\class{sym-E}{\\mathbb{E}}\\big[-\\log \\class{sym-ptheta}{p_\\theta}(\\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})\\big]",
        tex: "\\class{sym-L}{\\mathcal{L}}_{\\text{WAM}} = \\class{sym-E}{\\mathbb{E}}\\big[-\\log \\class{sym-ptheta}{p_\\theta}(\\class{sb-new}{\\class{sym-op}{o'}},\\, \\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})\\big]",
        words: "A VLA is trained on the action alone. A WAM is trained on the future observation and the action together, so predicting consequences shapes it.",
        key: ["L", "E", "ptheta", "op", "a", "o", "l"], diff: true, beforeLabel: "VLA", afterLabel: "WAM" },
      { name: "Cascade: imagine, then decode", ref: "P04 eq. 5 · P03 eq. 9–11", term: "cascaded-wam",
        tex: "p(\\class{sym-op}{o'}, \\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}) = \\class{sym-ptheta}{p_\\theta}(\\class{sym-op}{o'} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})\\; \\class{sym-pihead}{\\pi_\\psi}(\\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sym-op}{o'}, \\class{sym-l}{\\ell})",
        words: "A video model imagines the future; a separately trained action head, often an inverse dynamics model, reads the action off it. UniPi and AVDC work this way.",
        key: ["op", "a", "o", "l", "ptheta", "pihead"] },
      { name: "Score: propose, then predict", ref: "P04 eq. 6, §4.3.1", term: "action-conditioned-rollout",
        tex: "p(\\class{sym-op}{o'}, \\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}) = \\class{sym-pihead}{\\pi_\\psi}(\\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})\\; \\class{sym-ptheta}{p_\\theta}(\\class{sym-op}{o'} \\mid \\class{sym-o}{o_t}, \\class{sym-a}{a_t}, \\class{sym-l}{\\ell})",
        words: "An action source proposes; an action-conditioned model predicts each consequence, and the prediction decides which action runs. Cosmos Policy's best-of-8 planning mode works this way.",
        key: ["op", "a", "o", "l", "pihead", "ptheta"] },
      { name: "PAD to UWM: one noise level per modality", ref: "UWM, arXiv 2504.02792 · P04 §4.3.2", term: "per-modality-noise-levels",
        before: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{k, \\class{sym-eps}{\\epsilon}} \\big\\| \\class{sym-eps}{\\epsilon} - \\class{sym-epsnet}{\\epsilon_\\theta}\\big(\\class{sym-a}{a}^{(k)}, \\class{sym-op}{o'}^{(k)}, k, \\class{sym-o}{o_t}\\big) \\big\\|^2",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{\\class{sb-chg}{k_a, k_{o'}}, \\class{sym-eps}{\\epsilon}} \\big\\| \\class{sym-eps}{\\epsilon} - \\class{sym-epsnet}{\\epsilon_\\theta}\\big(\\class{sym-a}{a}^{(\\class{sb-chg}{k_a})}, \\class{sym-op}{o'}^{(\\class{sb-chg}{k_{o'}})}, \\class{sb-chg}{k_a, k_{o'}}, \\class{sym-o}{o_t}\\big) \\big\\|^2",
        words: "PAD noises action and future to one shared level. UWM draws separate levels, so at test time either one can be pure noise or clean.",
        key: ["L", "E", "eps", "epsnet", "a", "op", "o", { glyph: "k", meaning: "shared noise level (PAD)" }, { glyph: "kₐ, k_o′", meaning: "separate noise levels (UWM)" }], diff: true, beforeLabel: "PAD", afterLabel: "UWM" },
      { name: "The anatomy as a 4-tuple", ref: "P04 eq. 37", term: "predictive-substrate",
        tex: "\\text{WAM} \\cong \\big(\\class{sym-wam-phi}{\\Phi},\\ \\class{sym-wam-F}{\\mathsf{F}},\\ \\class{sym-wam-B}{\\mathsf{B}},\\ \\class{sym-wam-D}{\\mathsf{D}}\\big)",
        words: "Name what is predicted, how action attaches, which model family predicts, and how often it runs. F1 is (pixel latent, joint, hybrid, chunked).",
        key: ["wam-phi", "wam-F", "wam-B", "wam-D"] },
      { name: "The chunked deployment budget", ref: "P04 eq. 34", term: "deployment-regime",
        tex: "\\frac{\\class{sym-Nfwd}{N_{\\mathrm{fwd}}}(\\class{sym-H}{H})}{\\class{sym-H}{H}} < \\frac{1}{\\class{sym-fctrl}{f_{\\mathrm{ctrl}}}}",
        words: "The next chunk must be ready before the robot finishes this one: model time per executed action must stay below one control period.",
        key: ["Nfwd", "H", "fctrl"] }
    ],
    algorithm: {
      title: "One UWM network, four models", ref: "UWM, arXiv 2504.02792", prov: "Our notation: k = K is pure noise",
      lines: [
        '<span class="kw">input</span> observation <span data-sym="o">oₜ</span> and a query',
        'policy: hold <span data-sym="op">o′</span> at pure noise (k<sub>o′</sub> = <span data-sym="K">K</span>), denoise <span data-sym="a">a</span>',
        'video: hold <span data-sym="a">a</span> at pure noise (kₐ = <span data-sym="K">K</span>), denoise <span data-sym="op">o′</span>',
        'forward: give a clean <span data-sym="a">a</span> (kₐ = 0), denoise <span data-sym="op">o′</span>',
        'inverse: give a clean <span data-sym="op">o′</span> (k<sub>o′</sub> = 0), denoise <span data-sym="a">a</span>',
        '<span class="kw">for</span> k = <span data-sym="K">K</span> … 1: step the free variable with <span data-sym="epsnet">ε_θ</span> <span class="cm">// UWM: 10 DDIM steps</span>',
        '<span class="kw">return</span> 16 actions, run 8, replan <span class="cm">// action-free video trains with kₐ = K</span>'
      ]
    },
    playgrounds: [
      {
        id: "queries", title: "One joint distribution, four queries", ref: "P03 eq. 4–8 · UWM", prov: "Simplified: exact 1-D toy",
        try: "Switch between Policy and Video model, then fix an action. Choose Inverse dynamics with Play data and tick the wall: two pushes now end in the same place.",
        mount: mountQueries,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "c2-queries";
          return [
            { target: q("#" + id + "-cv"), title: "Read the joint", text: "Each cell is p(o′, a): how often demonstrators pushed with a and the cup ended at o′. Two bright blobs, one per bin." },
            { target: q("#" + id + "-q"), title: "Sum out the future", text: "The video model sums each row over actions. Its two peaks sit on the bins: where the cup should go.", do: function (a) { return a.click(q("#" + id + '-q [value="video"]')); }, task: "Choose Video model", expect: function () { return api.state().q === "video"; } },
            { target: q("#" + id + "-q"), title: "Fix one push", text: "The forward model keeps one column: the consequence of one chosen push. Scoring routes rank candidates with it.", do: function (a) { return a.click(q("#" + id + '-q [value="forward"]')); }, task: "Choose Forward model", expect: function () { return api.state().q === "forward"; } },
            { target: q("#" + id + "-s"), title: "Noisier dynamics", text: "Raise the dynamics noise. The same push now lands in a wider spread of places.", do: function (a) { return a.set(q("#" + id + "-s"), 0.24); }, task: "Raise dynamics noise above 0.2", expect: function () { return api.state().sigma > 0.2; } },
            { target: q("#" + id + "-q"), title: "Ask which push", text: "Inverse dynamics keeps one row: given where the cup ended, which push did it? Cascades decode their actions this way.", do: function (a) { return a.click(q("#" + id + '-q [value="idm"]')); }, task: "Choose Inverse dynamics", expect: function () { return api.state().q === "idm"; } },
            { target: q("#" + id + "-i"), title: "Play data", text: "Play data pushes in every direction. That is what inverse dynamics models often train on.", do: function (a) { return a.click(q("#" + id + '-i [value="play"]')); }, task: "Choose Play data", expect: function () { return api.state().instr === "play"; } },
            { target: q("#" + id + "-wall"), title: "Add the wall", text: "With the bouncing wall, a push at 0.58 and one near 0.82 end in the same spot. The row now has two peaks.", do: function (a) { return a.click(q("#" + id + "-wall")); }, task: "Tick Bouncing side wall", expect: function () { return api.state().wall; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Lower the noise and watch Peaks. A predicted future does not always pin down the action, which is why cascades can fail." }
          ];
        }
      },
      {
        id: "budget", title: "Dream less, act more: the latency budget", ref: "Fast-WAM, arXiv 2603.16666 · P04 eq. 34", prov: "Simplified: toy timeline",
        try: "Start with Joint video and Wait first. Switch to Overlap, which thinks while acting, then lengthen the chunk. Finally choose Skip video and compare the reaction to the nudge.",
        mount: mountBudget,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "c2-budget";
          return [
            { target: q("#" + id + "-cv"), title: "Two lanes", text: "The model computes a chunk (top), then the robot runs it (bottom). Red gaps are time the robot stands still." },
            { target: q("#" + id + "-m"), title: "Think while acting", text: "Overlap starts the next call when a chunk starts. If the call is shorter than the chunk, the robot never waits.", do: function (a) { return a.click(q("#" + id + '-m [value="overlap"]')); }, task: "Choose Overlap", expect: function () { return api.state().m === "overlap"; } },
            { target: q("#" + id + "-h"), title: "Longer chunks", text: "580 ms over 16 actions is 36 ms per action, above the 33 ms budget at 30 Hz. A chunk of 24 meets it.", do: function (a) { return a.set(q("#" + id + "-h"), 24); }, task: "Set the chunk to 24 or more", expect: function () { return api.state().H >= 24; } },
            { target: q("#" + id + "-p"), title: "Skip the video", text: "Fast-WAM keeps video prediction for training but skips it at test time: 190 ms instead of 580 ms per call.", do: function (a) { return a.click(q("#" + id + '-p [value="skip"]')); }, task: "Choose Skip video", expect: function () { return api.state().p === "skip"; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Try Video→IDM with short chunks. Then shrink H with Skip video and watch the reaction time fall." }
          ];
        }
      }
    ],
    methods: ["unipi", "avdc", "susie", "gr-1", "pad", "uva", "uwm", "vpp", "mimic-video", "flare", "cosmos-policy", "dreamzero", "lingbot-va", "fast-wam", "motus", "videovla", "worldvla", "f1", "cot-vla", "seer", "gr-2"],
    open: [
      { title: "Dream more or act more?", text: "Rendering the future costs latency, yet Fast-WAM needs video only in training. How much predictive fidelity control needs has not been measured.", refs: "P04 §7.1 · X1 §7" },
      { title: "Real-time rates", text: "DreamZero reaches about 7 Hz after heavy optimization, while non-generative VLA policies run near 50 Hz.", refs: "X1 §7" },
      { title: "Memory over long tasks", text: "Interactive WAMs carry a key-value cache that grows with the horizon, so attention cost grows quadratically with time.", refs: "P04 §4.5.4, §7.3" },
      { title: "Evaluate both halves together", text: "Video metrics such as FVD and task success are scored apart. Reports should add latency and memory, and check that actions follow the imagined future.", refs: "X1 §7 · P04 §7.7" }
    ],
    takeaways: [
      "A WAM keeps a predicted future in the path that produces, scores or trains the action; a VLA's objective needs no future.",
      "Policy, video model, forward model and inverse dynamics model are four queries of one joint distribution over future and action.",
      "Coupling tightened over time: UniPi's cascade, then GR-1 and PAD predicting both, then UWM serving all four queries.",
      "Recent WAMs generate less at test time: VPP, mimic-video and Fast-WAM act on future-shaped features instead of finished video.",
      "Deployment is a budget: model time per executed action must stay below one control period."
    ],
    quiz: [
      { q: "Which query of the joint p(o′, a | o, ℓ) gives a plain VLA policy?", options: ["Fix o′ and renormalize", "Sum over o′", "Sum over a", "Fix a and renormalize"], correct: 1, why: "Summing out the future leaves p(a | o, ℓ), the VLA objective (P03 eq. 5; P04 eq. 1)." },
      { q: "How do you run UWM as an inverse dynamics model?", options: ["Hold the future at pure noise", "Give a clean action and denoise the future", "Give a clean future o′ and denoise the action", "Train a second network"], correct: 2, why: "Conditioning on o′ means its noise level is 0 while the action is denoised. Pure noise on o′ instead gives the policy (arXiv 2504.02792)." },
      { q: "Fast-WAM skips future video at test time. What happened when video co-training was also removed?", options: ["RoboTwin success fell from 91.8% to 83.8%", "Nothing changed", "Latency tripled", "It beat every baseline"], correct: 0, why: "Video prediction in training still mattered: 91.8 to 83.8 on RoboTwin, and real towel folding fell to 10% success (arXiv 2603.16666)." },
      { q: "A call takes 580 ms and the robot runs 16 actions at 30 Hz. Is the chunked budget met?", options: ["Yes: chunks always hide latency", "Yes: 580 ms is under one second", "Only if the video is rendered", "No: about 36 ms per action exceeds 33 ms"], correct: 3, why: "Nfwd(H)/H = 580/16 ≈ 36 ms, above 1/f_ctrl ≈ 33 ms, so the robot waits between chunks (P04 eq. 34)." }
    ],
    cards: [
      { front: "Write the WAM training objective.", back: "−log p_θ(o′, a | o, ℓ): the future observation and the action predicted together, not the action alone.", ref: "P04 eq. 7" },
      { front: "Name the four queries of the joint p(o′, a | o, ℓ).", back: "Policy (sum over o′), passive video model (sum over a), forward model (fix a), inverse dynamics model (fix o′).", ref: "P03 eq. 5–8" },
      { front: "What did UWM change about PAD?", back: "Separate noise levels for action and future, so one network is policy, forward, inverse and video model, and trains on action-free video.", ref: "arXiv 2504.02792" },
      { front: "Where can a WAM decode its action, per P04?", back: "From rendered pixels (Render-and-Decode), from intermediate latents (Latent-Only), or with no video generator (Video-Generation-Free).", ref: "P04 §3" },
      { front: "What does Fast-WAM keep, and what does it skip?", back: "It keeps video prediction as a training loss and skips future video at test time: 190 ms per call versus 580 ms.", ref: "arXiv 2603.16666" },
      { front: "How does DreamZero keep a 14B video model in the loop?", back: "Chunked autoregressive denoising, real frames replacing predictions in the cache, and a 38× speedup stack to about 150 ms.", ref: "arXiv 2602.15922" }
    ],
    terms: {
      "world-action-model": { name: "world action model", aliases: ["WAM", "world action models", "video-action model"], group: "wam", sym: "p(o′, a | o, ℓ)", symTex: "p(o', a \\mid o, \\ell)", def: "An embodied model whose predicted future observation helps produce, score or verify the action, targeting a joint distribution over future states and actions rather than actions alone.", note: "A VLA with an auxiliary future loss whose future head is discarded does not qualify under P04's definition.", ref: "P04 §2.3 · X1 §2", scene: "system", focus: ["world-model", "predicted-future", "action-head"], look: "predicted future feeding the action head", uses: ["cascaded-wam", "joint-wam", "action-conditioned-rollout"] },
      "cascaded-wam": { name: "cascaded WAM", aliases: ["predict-then-act", "post-prediction action head", "video policy"], group: "wam", def: "A WAM that first predicts the future with a world model, then derives the action with a separate module such as an inverse dynamics model, tracker or planner.", note: "The two stages are often trained apart, so errors in the imagined future pass straight into the action.", ref: "P04 eq. 5, 12 · X1 §4.1", scene: "system", focus: ["world-model", "predicted-future", "action-head"], look: "imagined future, then a separate head", uses: ["inverse-dynamics-model"] },
      "joint-wam": { name: "joint WAM", aliases: ["joint generation", "joint video-action model", "unified video-action model"], group: "wam", def: "A WAM that predicts future states and actions within one model trained under a unified objective, such as GR-1, PAD, UWM or DreamZero.", note: "Joint training does not force joint inference: UVA and UWM can skip the video side when acting.", ref: "P04 eq. 7, 11 · X1 §4.2", scene: "system", focus: ["world-model", "action-chunk"], look: "one model emitting future and chunk", uses: ["per-modality-noise-levels"] },
      "action-conditioned-rollout": { name: "action-conditioned rollout", aliases: ["score actions", "candidate scoring"], group: "wam", def: "A coupling where an action source proposes actions and an action-conditioned predictor forecasts their consequences, which decide the action that runs.", note: "It enables counterfactual comparison of candidates, but each candidate costs a forward pass.", ref: "P04 eq. 6, 10, §4.3.1", scene: "system", focus: ["planner", "world-model", "predicted-future"], look: "candidates scored by predicted futures", uses: [] },
      "inverse-dynamics-model": { name: "inverse dynamics model", aliases: ["IDM", "inverse dynamics"], group: "wam", def: "A model p(a | oₜ:ₜ₊ₖ) that infers the action connecting observations to future observations, used to decode actions from a predicted future.", note: "It is ill-posed when different actions lead to the same future.", ref: "P03 eq. 8 · X1 §4.1.1", scene: "system", focus: ["predicted-future", "action-head"], look: "head reading actions off the future", uses: [] },
      "predictive-substrate": { name: "predictive substrate", aliases: ["substrate", "Φ"], group: "wam", sym: "Φ", symTex: "\\Phi", def: "The representation in which a WAM forms the future used for action: pixel-grounded, feature, geometric or affordance.", note: "Substrate and coupling are separate axes: mimic-video uses a feature substrate with a post-prediction head.", ref: "P04 §4.2, Fig. 5", scene: "system", focus: ["predicted-future", "latent"], look: "the form of the predicted future", uses: [] },
      "action-coupling": { name: "action coupling", aliases: ["coupling", "F axis"], group: "wam", sym: "F", symTex: "\\mathsf{F}", def: "How action enters or leaves the prediction: action-conditioned rollout, joint generation, or a post-prediction head.", note: "P04's three couplings refine X1's two families, cascaded and joint.", ref: "P04 §4.3, Fig. 6", scene: "system", focus: ["world-model", "action-head"], look: "where action binds to the future", uses: ["action-conditioned-rollout", "joint-wam", "cascaded-wam"] },
      "deployment-regime": { name: "deployment regime", aliases: ["D axis", "chunked closed loop", "open-loop rollout"], group: "wam", sym: "D", symTex: "\\mathsf{D}", def: "When a WAM is invoked and over what window: open-loop rollout, chunked closed loop, single-step closed loop or interactive operation.", note: "Chunked control amortizes a large backbone but acts on a plan that goes stale during the chunk.", ref: "P04 §4.5, eq. 33–36", scene: "system", focus: ["action-chunk", "controller", "robot"], look: "the chunk handed to the controller", uses: ["action-chunk"] },
      "render-and-decode": { name: "render-and-decode", aliases: ["Render-and-Decode WAM"], group: "wam", def: "The design philosophy that runs the video generator all the way to pixel output before the action is obtained, as in UniPi, AVDC and DreamZero.", note: "It pays the full denoising cost even though the actor rarely uses the whole rendered future.", ref: "P04 §3.1", scene: "system", focus: ["world-model", "predicted-future"], look: "rendered frames before the action", uses: ["cascaded-wam"] },
      "latent-only-wam": { name: "latent-only WAM", aliases: ["Latent-Only", "feature-tap WAM"], group: "wam", def: "A WAM that keeps a video-trained trunk but stops before pixel decoding, taking the action signal from intermediate latents, partially denoised features, flow or masks.", note: "VPP uses one denoising pass; mimic-video found fully noisy video latents gave its best policy.", ref: "P04 §3.2", scene: "system", focus: ["world-model", "latent", "action-head"], look: "features tapped from the video trunk", uses: ["render-and-decode"] },
      "video-generation-free-wam": { name: "video-generation-free WAM", aliases: ["Video-Generation-Free"], group: "wam", def: "A WAM whose predictive component has no video generator: it predicts in a language-token, vision-language, joint-embedding or other compact space.", note: "FLARE and LDA-1B align future embeddings instead of producing frames.", ref: "P04 §3.3", scene: "system", focus: ["llm-backbone", "latent", "action-head"], look: "compact future inside the backbone", uses: ["latent-only-wam"] },
      "video-co-training": { name: "video co-training", aliases: ["video prediction as an auxiliary loss", "train-time video"], group: "wam", def: "Training the model to predict future video alongside actions, including on action-free video, so its features encode dynamics even if video is skipped when acting.", note: "Fast-WAM without it fell from 91.8% to 83.8% on RoboTwin.", ref: "Fast-WAM, arXiv 2603.16666 · P03 Table 1", scene: "system", focus: ["data-human", "world-model"], look: "action-free video feeding the model", uses: ["joint-wam"] },
      "per-modality-noise-levels": { name: "per-modality noise levels", aliases: ["independent diffusion timesteps", "UniDiffuser-style scheduler"], group: "wam", def: "Sampling separate noise levels for action and future during joint diffusion training, so each modality can be marginalized (pure noise) or conditioned on (clean) at test time.", note: "PAD used one shared level; UWM and Motus use separate ones.", ref: "UWM, arXiv 2504.02792 · Motus, arXiv 2512.13030", scene: "system", focus: ["noise", "world-model", "action-chunk"], look: "two noise inputs, one per modality", uses: ["joint-wam", "diffusion-policy-head"] }
    },
    ledger: [
      { where: "Topic 11 · all equations", source: "P04 writes the separate action module as q_ψ", page: "This site writes it π_ψ (action head)", why: "One symbol for action heads across topics.", kind: "Our choice" },
      { where: "Topic 11 · deployment budget", source: "P04 eq. 34 writes the replan period as K", page: "This site writes H, the chunk length", why: "K is the number of denoising steps in house notation.", kind: "Our choice" },
      { where: "Topic 11 · PAD to UWM rule", source: "PAD sums per-modality losses with ramped weights; UWM weights both terms 1.0", page: "The rule shows one combined noise-prediction loss", why: "Isolates the change from a shared to separate noise levels.", kind: "Simplified" },
      { where: "Topic 11 · Latent-only term", source: "mimic-video and Fast-WAM put pure noise at flow time 1", page: "This site's τ uses 0 = noise; the text says pure noise in words", why: "House convention for flow time.", kind: "Our choice" },
      { where: "Topic 11 · coupling of CoT-VLA", source: "X1 Fig. 2 lists CoT-VLA as a joint autoregressive WAM", page: "P04 Table 1 lists it as a post-prediction head", why: "The surveys draw the cascade/joint line differently.", kind: "Sources disagree" },
      { where: "Topic 11 · coupling of FLARE", source: "X1 Fig. 2 lists FLARE among joint diffusion WAMs", page: "P04 §4.6 places it as teacher-target feature, post-prediction head", why: "Same method, different taxonomy.", kind: "Sources disagree" },
      { where: "Topic 11 · playground 1", source: "Real WAMs learn the joint from demonstrations with networks", page: "The toy computes an exact joint on a 25 × 25 grid", why: "Shows what each query keeps, with no learning error.", kind: "Simplified" },
      { where: "Topic 11 · playground 2", source: "Fast-WAM reports latencies on one RTX 5090D; no control rate stated", page: "The timeline uses those latencies with a control rate you choose", why: "Separates the budget arithmetic from hardware claims.", kind: "Simplified" }
    ]
  });
})();
