/* Topic 21 · Verifiers and failure detection. Sources: P14 (No Free Checker) §1–6, P01 §6.1.2 and §6.2.2, X3 §V-E, method papers (SAFE, FAIL-Detect, FIPER, Sentinel, KnowNo, V-GPS, RoboMonkey). */
(function () {
  "use strict";
  var RB = window.RB;
  function monoFont() { return getComputedStyle(document.body).getPropertyValue("--font-mono"); }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body"); }
  function pct(v) { return Math.round(v * 100) + "%"; }
  /* segmented control: StudyBench.segmented calls back with (value, button) */
  function onSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); }
  /* split-conformal quantile: the k-th smallest of n scores, k = ceil((n + 1)(1 − α)); Infinity when k > n */
  function cpQuantile(vals, alpha) {
    var s = vals.slice().sort(function (a, b) { return a - b; }), n = s.length, k = Math.ceil((n + 1) * (1 - alpha));
    return k > n ? Infinity : s[k - 1];
  }

  /* =====================================================================================
     Playground 1 · a conformal failure band on a toy flow policy (FAIL-Detect style)
     Toy: the policy's observation embedding eₜ moves along a demonstrated tube m(u) in 2-D during a pick-and-place.
     Successful rollouts scatter around the tube, more widely during the grasp. The detector score is the squared
     distance to the tube in units of σ₀: what the one-step flow map of a Gaussian density model (logpZO) returns.
     It is averaged over the last 3 steps. Slip failures drift off the tube; stall failures freeze at a familiar state.
     Our toy numbers throughout.
     ===================================================================================== */
  var T = 60, S0 = 0.12, GRID = 121, NTEST = 50, MMAX = 200;
  function bump(t) { return Math.exp(-Math.pow((t - 26) / 6, 2)); }
  function mPath(u) { return [4 * u, 1.6 * Math.sin(Math.PI * u)]; }
  function nrm(u) { var d = [4, 1.6 * Math.PI * Math.cos(Math.PI * u)], L = Math.sqrt(d[0] * d[0] + d[1] * d[1]); return [-d[1] / L, d[0] / L]; }
  var TUBE = []; for (var gi = 0; gi < GRID; gi++) TUBE.push(mPath(gi / (GRID - 1)));
  function tubeScore(e) {
    var best = 1e9, bi = 0;
    for (var g = 0; g < GRID; g++) { var dx = e[0] - TUBE[g][0], dy = e[1] - TUBE[g][1], d2 = dx * dx + dy * dy; if (d2 < best) { best = d2; bi = g; } }
    return { s: best / (S0 * S0), u: bi / (GRID - 1) };
  }
  function rollout(R, kind, shift) {
    var t0 = kind === "ok" ? T + 1 : 14 + R.int(31), rate = 0.02 + 0.03 * R(), side = R() < 0.5 ? -1 : 1;
    var raw = [], S = [], prog = [];
    for (var t = 0; t <= T; t++) {
      var u = t / T, sd = S0 * (1 + 0.8 * bump(t)), c = mPath(u), n = nrm(u);
      if (kind === "stall" && t >= t0) { c = mPath(t0 / T); sd = S0 * 0.7; n = nrm(t0 / T); }
      var e = [c[0] + sd * R.normal(), c[1] + sd * R.normal()];
      if (kind === "slip" && t >= t0) { e[0] += side * rate * (t - t0) * n[0]; e[1] += side * rate * (t - t0) * n[1]; }
      if (kind === "ok" && shift) { e[0] += shift * S0 * n[0]; e[1] += shift * S0 * n[1]; }
      var sc = tubeScore(e); raw.push(sc.s); prog.push(sc.u);
      var a = 0, k = 0; for (var j = Math.max(0, t - 2); j <= t; j++) { a += raw[j]; k++; } S.push(a / k);
    }
    return { kind: kind, t0: t0, S: S, prog: prog };
  }
  /* progress check (a stand-in for Sentinel's slow VLM monitor): every 10 steps, if the progress estimate (mean of the
     last 5 steps) advanced less than 0.06 of the task since the last check, raise an alarm 4 steps later (the monitor is slow). */
  function progAt(r, c) { var a = 0; for (var j = c - 4; j <= c; j++) a += r.prog[j]; return a / 5; }
  function progressAlarm(r) {
    for (var c = 20; c <= T; c += 10) if (progAt(r, c) - progAt(r, c - 10) < 0.06) return Math.min(T, c + 4);
    return null;
  }
  function firstAlarm(r, thr, useProg) {
    var a = null;
    for (var t = 2; t <= T; t++) if (r.S[t] > thr[t]) { a = t; break; }
    if (useProg) { var p = progressAlarm(r); if (p !== null && (a === null || p < a)) a = p; }
    return a;
  }

  function mountBand(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-band", label: "Threshold", value: "time", options: [{ value: "const", label: "Constant" }, { value: "time", label: "Time-varying band" }] }) +
      RB.seg({ id: id + "-kind", label: "Failure type", value: "slip", options: [{ value: "slip", label: "Slip" }, { value: "stall", label: "Stall" }] }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-alpha", label: "Allowed false alarms α", min: 0.02, max: 0.3, step: 0.01, value: 0.05, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-m", label: "Calibration rollouts M", min: 10, max: MMAX, step: 10, value: 50 }) +
      RB.slider({ id: id + "-shift", label: "Test shift (σ₀)", min: 0, max: 2, step: 0.1, value: 0, fmt: function (v) { return (+v).toFixed(1); } }) + "</div>" +
      '<div class="rb-row"><label class="sb-field"><input type="checkbox" id="' + id + '-prog"> <span>Add a slow progress monitor</span></label><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New test set ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Detector score over time for test rollouts, with the calibrated alarm threshold"></canvas>' +
      '<figcaption class="sb-caption">Thick line = alarm threshold. Thin lines are test rollouts, colored as in the legend; a tick marks where a failure starts and a red dot each first alarm. The shaded strip is the grasp.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "tnr", k: "Successes with no alarm (of 50)" }, { id: "target", k: "Promised at least (1 − α)" }, { id: "tpr", k: "Failures caught (of 50)" }, { id: "delay", k: "Mean delay after failure starts", u: "steps" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "successful rollout", kind: "line" }, { c: "data-3", label: "failed rollout", kind: "line" }, { c: "accent", label: "alarm threshold", kind: "line" }, { c: "bad", label: "first alarm", kind: "dot" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 560, H = 320;
    var st = { band: "time", kind: "slip", alpha: 0.05, M: 50, shift: 0, prog: false, seed: 11 };
    var CAL = (function () { var R = RB.rng(101), a = []; for (var i = 0; i < MMAX; i++) a.push(rollout(R, "ok", 0)); return a; })();
    var thr = [], test = [], res = {};
    function calibrate() {
      var cal = CAL.slice(0, st.M);
      if (st.band === "const") {
        var g = cpQuantile(cal.map(function (r) { return Math.max.apply(null, r.S.slice(2)); }), st.alpha);
        thr = []; for (var t = 0; t <= T; t++) thr.push(g);
        return;
      }
      var A = cal.slice(0, Math.floor(st.M / 2)), B = cal.slice(Math.floor(st.M / 2)), mu = [], sd = [];
      for (var t2 = 0; t2 <= T; t2++) {
        var m = 0; A.forEach(function (r) { m += r.S[t2]; }); m /= A.length;
        var v = 0; A.forEach(function (r) { v += (r.S[t2] - m) * (r.S[t2] - m); }); v = Math.sqrt(v / Math.max(1, A.length - 1));
        mu.push(m); sd.push(Math.max(v, 0.1));
      }
      var h = cpQuantile(B.map(function (r) { var mx = -1e9; for (var t3 = 2; t3 <= T; t3++) mx = Math.max(mx, (r.S[t3] - mu[t3]) / sd[t3]); return mx; }), st.alpha);
      thr = mu.map(function (m, i) { return m + h * sd[i]; });
    }
    function makeTest() {
      var R = RB.rng(st.seed * 7919), R2 = RB.rng(st.seed * 7919 + 5); test = [];
      for (var i = 0; i < NTEST; i++) test.push(rollout(R, "ok", st.shift));
      for (var j = 0; j < NTEST; j++) test.push(rollout(R2, st.kind, 0));
    }
    function evaluate() {
      var okNo = 0, caught = 0, delay = 0;
      test.forEach(function (r) {
        r.alarm = firstAlarm(r, thr, st.prog);
        if (r.kind === "ok") { if (r.alarm === null) okNo++; }
        else if (r.alarm !== null) { caught++; delay += Math.max(0, r.alarm - r.t0); }
      });
      res = { tnr: okNo / NTEST, tpr: caught / NTEST, delay: caught ? delay / caught : null };
      RB.setRO(body, "tnr", pct(res.tnr));
      RB.setRO(body, "target", pct(1 - st.alpha));
      RB.setRO(body, "tpr", pct(res.tpr));
      RB.setRO(body, "delay", res.delay === null ? "–" : RB.fmt(res.delay, 1));
      var inf = !isFinite(thr[10]);
      if (inf) note.textContent = "With " + (st.band === "const" ? st.M : st.M - Math.floor(st.M / 2)) + " rollouts, α = " + st.alpha.toFixed(2) + " asks for a quantile beyond the largest score, so the threshold is infinite and nothing alarms. Add rollouts or raise α.";
      else if (st.shift >= 0.8 && res.tnr < 1 - st.alpha) note.textContent = "The test successes no longer come from the calibration pool, so the promise of at most α false alarms is broken. SAFE reports the same risk on unseen tasks.";
      else if (st.kind === "stall" && !st.prog) note.textContent = "A stalled arm sits at a familiar state, so the novelty score stays low. P14 §5.1: a familiar-looking failure can still look reliable.";
      else if (st.kind === "stall") note.textContent = "The progress monitor catches stalls, but late. Sentinel pairs a fast action-consistency check with a slow VLM progress check for the same reason.";
      else if (st.band === "const") note.textContent = "One threshold must clear the noisy grasp phase, so it sits high everywhere and catches slips after the grasp late or not at all.";
      else note.textContent = "The band is high during the noisy grasp and low elsewhere, as in FAIL-Detect's functional conformal prediction. Its promise covers false alarms only.";
      draw();
    }
    function run(recal, retest) { if (recal) calibrate(); if (retest) makeTest(); evaluate(); }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont(), L = 48, Rm = 14, Tp = 14, Bm = 36, YM = 20;
      var sx = function (t) { return L + t / T * (W - L - Rm); }, sy = function (v) { return H - Bm - Math.min(v, YM) / YM * (H - Bm - Tp); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.fillStyle = P["surface-sunk"]; c.fillRect(sx(18), Tp, sx(34) - sx(18), H - Bm - Tp);
      c.strokeStyle = P.line; c.lineWidth = 1; c.beginPath(); c.moveTo(L, Tp); c.lineTo(L, H - Bm); c.lineTo(W - Rm, H - Bm); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono;
      [0, 20, 40, 60].forEach(function (t) { c.fillText(String(t), sx(t) - 6, H - Bm + 15); });
      [0, 5, 10, 15, 20].forEach(function (v) { c.fillText(String(v), L - 22, sy(v) + 4); });
      c.fillText("time step t", W - Rm - 76, H - 6); c.fillText("grasp", sx(18) + 6, Tp + 14);
      c.save(); c.translate(14, Tp + 150); c.rotate(-Math.PI / 2); c.fillText("detector score Sₜ", 0, 0); c.restore();
      var shown = test.filter(function (r) { return r.kind === "ok"; }).slice(0, 8).concat(test.filter(function (r) { return r.kind !== "ok"; }).slice(0, 8));
      shown.forEach(function (r) {
        c.strokeStyle = r.kind === "ok" ? P["data-1"] : P["data-3"]; c.globalAlpha = 0.6; c.lineWidth = 1.3; c.beginPath();
        r.S.forEach(function (v, t) { if (t) c.lineTo(sx(t), sy(v)); else c.moveTo(sx(t), sy(v)); }); c.stroke(); c.globalAlpha = 1;
        if (r.kind !== "ok" && r.t0 <= T) { c.strokeStyle = P["data-3"]; c.lineWidth = 2; c.beginPath(); c.moveTo(sx(r.t0), H - Bm); c.lineTo(sx(r.t0), H - Bm - 8); c.stroke(); }
      });
      if (isFinite(thr[10])) {
        c.strokeStyle = P.accent; c.lineWidth = 3; c.beginPath();
        thr.forEach(function (v, t) { if (t < 2) return; if (t === 2) c.moveTo(sx(t), sy(v)); else c.lineTo(sx(t), sy(v)); }); c.stroke();
      } else { c.fillStyle = P.ink; c.font = "600 12px " + bodyFont(); c.fillText("No finite threshold: too few rollouts for this α", L + 12, Tp + 34); }
      shown.forEach(function (r) { if (r.alarm === null) return; c.fillStyle = P.bad; c.beginPath(); c.arc(sx(r.alarm), sy(r.S[r.alarm]), 4.5, 0, Math.PI * 2); c.fill(); });
    }
    onSeg(body, id + "-band", function (v) { st.band = v; run(true, false); });
    onSeg(body, id + "-kind", function (v) { st.kind = v; run(false, true); });
    RB.bindSlider(body, id + "-alpha", function (v) { return (+v).toFixed(2); }, function (v) { st.alpha = v; run(true, false); });
    RB.bindSlider(body, id + "-m", null, function (v) { st.M = v; run(true, false); });
    RB.bindSlider(body, id + "-shift", function (v) { return (+v).toFixed(1); }, function (v) { st.shift = v; run(false, true); });
    body.querySelector("#" + id + "-prog").addEventListener("change", function (e) { st.prog = e.target.checked; run(false, false); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed++; run(false, true); });
    RB.onTheme(draw);
    run(true, true);
    return { state: function () { return { band: st.band, kind: st.kind, alpha: st.alpha, M: st.M, shift: st.shift, prog: st.prog, tnr: res.tnr, tpr: res.tpr, seed: st.seed }; } };
  }

  /* =====================================================================================
     Playground 2 · KnowNo: a conformal prediction set decides when to ask for help
     Toy: each scenario offers four objects; a language model gives a probability to each. In a clear scenario the
     intended object gets a large boost; in an ambiguous one ("the bowl" with two bowls) two objects get the same boost.
     The ambiguous share is fixed exactly in both sets (stratified), so calibration and test match.
     400 calibration scenarios (KnowNo's N) set q̂; 400 new scenarios are scored. Our toy numbers.
     ===================================================================================== */
  var NTST = 2000, OPTS = ["blue bowl", "green bowl", "sponge", "metal cup"], OPTL = [["blue", "bowl"], ["green", "bowl"], ["sponge", ""], ["metal", "cup"]], NCAL = 400;
  function scenario(R, ambig) {
    var y = R.int(4), d = (y + 1 + R.int(3)) % 4, lg = [], p = [], Z = 0;
    for (var i = 0; i < 4; i++) lg.push(0.8 * R.normal());
    if (ambig) { lg[y] += 3.2; lg[d] += 3.2; } else lg[y] += 4;
    lg.forEach(function (v) { var e = Math.exp(v); p.push(e); Z += e; });
    return { y: y, ambig: ambig, p: p.map(function (v) { return v / Z; }) };
  }
  function mountSets(body, ctx) {
    var id = ctx.id;
    body.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-eps", label: "Allowed error α", min: 0.03, max: 0.3, step: 0.01, value: 0.15, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-amb", label: "Ambiguous instructions", min: 0, max: 0.8, step: 0.05, value: 0.3, fmt: pct }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Next scenario ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Left: histogram of calibration scores with the quantile. Right: option probabilities for one new scenario with the inclusion threshold"></canvas>' +
      '<figcaption class="sb-caption">Left: how unsure the model was about the right answer in 400 calibration scenarios; the line is q̂. Right: one new scenario; every bar above the dashed line joins the set.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "q", k: "Calibrated q̂" }, { id: "cov", k: "Right option in the set" }, { id: "help", k: "Asks a human" }, { id: "size", k: "Mean set size" }, { id: "greedy", k: "Top option alone is right" }]) +
      '<p class="sb-caption">KnowNo calibrates on 400 scenarios and uses α = 0.15 in simulation (arXiv 2307.01928; the paper writes ε).</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), W = 560, H = 280, st = { eps: 0.15, amb: 0.3, idx: 0 }, cal = [], tst = [], qhat = 1;
    function build() {
      var R = RB.rng(41), R2 = RB.rng(43); cal = []; tst = [];
      for (var i = 0; i < NCAL; i++) cal.push(scenario(R, i < Math.round(st.amb * NCAL)));
      for (var j = 0; j < NTST; j++) tst.push(scenario(R2, (j * 37) % NTST < Math.round(st.amb * NTST)));
    }
    function setOf(s) { var out = []; s.p.forEach(function (v, i) { if (v >= 1 - qhat) out.push(i); }); return out; }
    function run(rebuild) {
      if (rebuild) build();
      qhat = cpQuantile(cal.map(function (s) { return 1 - s.p[s.y]; }), st.eps);
      var cov = 0, help = 0, size = 0, gr = 0;
      tst.forEach(function (s) {
        var C = setOf(s); if (C.indexOf(s.y) >= 0) cov++; if (C.length !== 1) help++; size += C.length;
        var am = 0; s.p.forEach(function (v, i) { if (v > s.p[am]) am = i; }); if (am === s.y) gr++;
      });
      RB.setRO(body, "q", isFinite(qhat) ? RB.fmt(qhat, 2) : "∞");
      RB.setRO(body, "cov", pct(cov / NTST)); RB.setRO(body, "help", pct(help / NTST)); RB.setRO(body, "size", RB.fmt(size / NTST, 2)); RB.setRO(body, "greedy", pct(gr / NTST));
      draw();
    }
    function draw() {
      if (!tst.length) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      /* left: histogram of κ = 1 − p(correct) */
      var L = 30, Rr = 262, Tp = 30, Bt = H - 40, bins = new Array(20).fill(0), mx = 1;
      cal.forEach(function (s) { var k = Math.min(19, Math.floor((1 - s.p[s.y]) * 20)); bins[k]++; });
      bins.forEach(function (b) { mx = Math.max(mx, b); });
      var bw = (Rr - L) / 20;
      bins.forEach(function (b, i) { var hh = b / mx * (Bt - Tp); c.fillStyle = P["data-1"]; c.globalAlpha = 0.75; c.fillRect(L + i * bw + 1, Bt - hh, bw - 2, hh); c.globalAlpha = 1; });
      c.strokeStyle = P.line; c.lineWidth = 1; c.beginPath(); c.moveTo(L, Bt); c.lineTo(Rr, Bt); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono;
      c.fillText("0", L - 3, Bt + 14); c.fillText("1", Rr - 4, Bt + 14); c.fillText("κ = 1 − p(right option)", L + 40, Bt + 28);
      c.fillText("calibration, 400 scenarios", L, 16);
      if (isFinite(qhat)) { var qx = L + qhat * (Rr - L); c.strokeStyle = P.accent; c.lineWidth = 2.5; c.beginPath(); c.moveTo(qx, Tp - 6); c.lineTo(qx, Bt); c.stroke(); c.fillStyle = P.accent; c.fillText("q̂ = " + qhat.toFixed(2), Math.min(qx + 4, Rr - 60), Tp + 6); }
      /* right: one test scenario */
      var s = tst[st.idx % tst.length], C = setOf(s), X0 = 310, X1 = W - 12, bT = 44, bB = H - 58, gap = (X1 - X0) / 4;
      c.fillStyle = P["ink-3"]; c.fillText((s.ambig ? "ambiguous" : "clear") + " · wants the " + OPTS[s.y], X0 - 4, 16);
      s.p.forEach(function (v, i) {
        var x = X0 + i * gap + 8, hh = v * (bB - bT), inSet = C.indexOf(i) >= 0;
        c.fillStyle = inSet ? P.accent : P["surface-strong"]; c.fillRect(x, bB - hh, gap - 16, hh);
        c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.strokeRect(x, bB - hh, gap - 16, hh);
        c.fillStyle = P.ink; c.font = "500 11px " + mono; c.fillText(v.toFixed(2), x + 2, bB - hh - 5);
        c.fillStyle = i === s.y ? P.ink : P["ink-3"]; var w = OPTL[i];
        c.fillText(w[0], x, bB + 14); c.fillText(w[1], x, bB + 27);
      });
      c.strokeStyle = P.line; c.beginPath(); c.moveTo(X0, bB); c.lineTo(X1, bB); c.stroke();
      if (isFinite(qhat)) { var ty = bB - (1 - qhat) * (bB - bT); c.strokeStyle = P["ink-2"]; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(X0, ty); c.lineTo(X1, ty); c.stroke(); c.setLineDash([]); }
      c.fillStyle = P.ink; c.font = "600 12px " + bodyFont();
      c.fillText(C.length === 1 ? "Set has one option: act" : C.length === 0 ? "Empty set: ask a human" : "Set has " + C.length + " options: ask a human", X0 - 4, H - 8);
    }
    RB.bindSlider(body, id + "-eps", function (v) { return (+v).toFixed(2); }, function (v) { st.eps = v; run(false); });
    RB.bindSlider(body, id + "-amb", pct, function (v) { st.amb = v; run(true); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { st.idx++; draw(); });
    RB.onTheme(draw);
    run(true);
    return { state: function () { return { eps: st.eps, amb: st.amb, idx: st.idx }; } };
  }

  /* ---------- concept-card drawings (56px tall, token colors only) ---------- */
  var ART = {
    verifier: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="4" y="6" width="66" height="19" rx="3" class="rb-f-sunk"/><text x="37" y="19" text-anchor="middle" class="rb-t-mono">context</text><rect x="4" y="31" width="66" height="19" rx="3" class="rb-f-surface"/><text x="37" y="44" text-anchor="middle" class="rb-t-mono">candidate</text><path d="M72 16 L100 28 M72 40 L100 28" class="rb-s-ink"/><rect x="102" y="16" width="40" height="24" rx="4" class="rb-f-soft"/><text x="122" y="32" text-anchor="middle" class="rb-t-acc">S</text><path d="M144 28 H164" class="rb-s-ink"/><text x="182" y="32" text-anchor="middle" class="rb-t-ink">0.8</text></svg>',
    judges: '<svg viewBox="0 0 200 56" aria-hidden="true"><g class="rb-t-mono"><text x="18" y="16" text-anchor="middle">human</text><text x="58" y="16" text-anchor="middle">rules</text><text x="104" y="16" text-anchor="middle">learned</text><text x="168" y="16" text-anchor="middle">intrinsic</text></g>' + [18, 58, 104, 168].map(function (x, i) { return '<circle cx="' + x + '" cy="30" r="5" class="' + (i === 3 ? "rb-f-acc" : "rb-f-soft") + '"/>'; }).join("") + '<path d="M8 42 H188" class="rb-s-line"/><path d="M182 38 L188 42 L182 46" class="rb-s-line"/><text x="100" y="54" text-anchor="middle" class="rb-t-mono">judge moves closer to the model</text></svg>',
    tradeoff: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 4 V44 H196" class="rb-s-line"/><text x="14" y="10" class="rb-t-mono">credibility</text><path d="M92 14 L122 22 L152 32 L182 40" class="rb-s-ink" stroke-dasharray="3 3"/>' + [[92, 14], [122, 22], [152, 32], [182, 40]].map(function (p) { return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="4" class="rb-f-acc"/>'; }).join("") + '<text x="14" y="55" class="rb-t-mono">availability →</text></svg>',
    bestofn: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [18, 30, 22, 40, 26, 14].map(function (h, i) { return '<rect x="' + (10 + i * 18) + '" y="' + (48 - h) + '" width="12" height="' + h + '" rx="2" class="' + (i === 3 ? "rb-f-acc" : "rb-f-soft") + '"/>'; }).join("") + '<path d="M8 48 H118" class="rb-s-line"/><text x="128" y="26" class="rb-t-ink">pick the</text><text x="128" y="42" class="rb-t-acc">argmax S</text></svg>',
    intrinsic: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="4" y="6" width="80" height="44" rx="4" class="rb-f-sunk"/><text x="44" y="21" text-anchor="middle" class="rb-t-mono">policy</text>' + [24, 44, 64].map(function (x) { return '<circle cx="' + x + '" cy="36" r="5" class="rb-f-soft"/>'; }).join("") + '<path d="M84 18 H104" class="rb-s-ink"/><text x="108" y="22" class="rb-t-mono">action</text><path d="M84 38 H104" class="rb-s-acc"/><rect x="106" y="28" width="44" height="20" rx="3" class="rb-f-soft"/><text x="128" y="42" text-anchor="middle" class="rb-t-mono">probe</text><path d="M150 38 H166" class="rb-s-acc"/><text x="182" y="42" text-anchor="middle" class="rb-t-acc">Sₜ</text></svg>',
    band: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M8 50 H194" class="rb-s-line"/><rect x="50" y="4" width="44" height="46" class="rb-f-sunk" stroke="none"/><path d="M8 30 C40 30 50 8 72 8 C94 8 104 30 194 30" class="rb-s-acc"/><path d="M8 44 C50 44 60 30 72 30 C90 30 110 44 194 44" class="rb-s-line"/><path d="M110 44 C140 42 150 34 170 18" class="rb-s-ink"/><circle cx="160" cy="29" r="4" style="fill:var(--bad)"/><text x="136" y="16" class="rb-t-mono">alarm</text><text x="54" y="46" class="rb-t-mono">grasp</text></svg>',
    hacking: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M8 50 H134" class="rb-s-line"/><path d="M10 48 Q76 38 132 8" class="rb-s-acc"/><path d="M10 48 Q50 14 80 18 Q108 22 132 42" class="rb-s-ink" stroke-dasharray="4 3"/><text x="140" y="12" class="rb-t-acc">verifier</text><text x="140" y="24" class="rb-t-acc">score</text><text x="140" y="42" class="rb-t-mono">true</text><text x="140" y="54" class="rb-t-mono">success</text></svg>'
  };

  /* ---------- worked example figure: a functional conformal band by hand (our toy numbers) ---------- */
  var wx = function (t) { return 50 + t * 8; }, wy = function (s) { return 150 - s * 16; };
  var wb = function (t) { return Math.exp(-Math.pow((t - 20) / 8, 2)); };
  var bandPath = "", muPath = "";
  for (var tt = 0; tt <= 60; tt++) {
    var bb = wb(tt), mu = 2 + bb, sg = 0.5 + bb;
    bandPath += (tt ? " L" : "M") + wx(tt).toFixed(1) + " " + wy(mu + 2.4 * sg).toFixed(1);
    muPath += (tt ? " L" : "M") + wx(tt).toFixed(1) + " " + wy(mu).toFixed(1);
  }
  var DEV = [0.8, 1.1, 1.3, 1.4, 1.6, 1.9, 2.1, 2.4, 3.0];
  var WE_FIG = '<svg viewBox="0 0 560 196" role="img" aria-label="Score against time. The alarm band is 6.6 at the grasp, t = 20, and 3.2 at placing, t = 50. A test rollout scores 5.1 and then 4.0, which crosses the band.">' +
    '<rect x="' + wx(12) + '" y="18" width="' + (wx(28) - wx(12)) + '" height="132" class="rb-f-sunk" stroke="none"/><text x="' + (wx(12) + 4) + '" y="30" class="rb-t-mono">grasp</text>' +
    '<path d="M50 18 V150 H530" class="rb-s-line"/>' +
    '<g class="rb-t-mono">' + [0, 20, 40, 60].map(function (t) { return '<text x="' + wx(t) + '" y="164" text-anchor="middle">' + t + "</text>"; }).join("") + [0, 2, 4, 6, 8].map(function (s) { return '<text x="42" y="' + (wy(s) + 4) + '" text-anchor="end">' + s + "</text>"; }).join("") + '<text x="530" y="164" text-anchor="end">t</text></g>' +
    '<g data-on="1+"><path d="' + muPath + '" class="rb-s-ink" stroke-dasharray="4 3"/><text x="' + wx(56) + '" y="' + (wy(2) - 6) + '" class="rb-t-mono">μₜ</text></g>' +
    '<g data-on="2+" class="rb-t-mono"><text x="60" y="186">sorted</text>' + DEV.map(function (d, i) { return '<text x="' + (120 + i * 40) + '" y="186" data-dev="' + i + '">' + d.toFixed(1) + "</text>"; }).join("") + "</g>" +
    '<g data-on="3+"><rect x="' + (120 + 7 * 40 - 6) + '" y="173" width="32" height="18" rx="3" class="rb-f-soft"/><text x="' + (120 + 7 * 40) + '" y="186" class="rb-t-acc">2.4</text></g>' +
    '<g data-on="4+"><path d="' + bandPath + '" class="rb-s-acc"/><circle cx="' + wx(20) + '" cy="' + wy(6.6) + '" r="4" class="rb-f-acc"/><text x="' + wx(20) + '" y="' + (wy(6.6) - 8) + '" text-anchor="middle" class="rb-t-acc">6.6</text><circle cx="' + wx(50) + '" cy="' + wy(3.2) + '" r="4" class="rb-f-acc"/><text x="' + wx(50) + '" y="' + (wy(3.2) + 18) + '" text-anchor="middle" class="rb-t-acc">3.2</text></g>' +
    '<g data-on="5+"><circle cx="' + wx(20) + '" cy="' + wy(5.1) + '" r="5" style="fill:var(--data-3)"/><text x="' + (wx(20) + 10) + '" y="' + (wy(5.1) + 4) + '" class="rb-t-ink">5.1 ok</text><circle cx="' + wx(50) + '" cy="' + wy(4.0) + '" r="6" style="fill:var(--bad)"/><text x="' + (wx(50) + 10) + '" y="' + (wy(4.0) - 6) + '" class="rb-t-ink">4.0 alarm</text></g>' +
    '<g data-on="5"><path d="M50 ' + wy(6.6) + ' H530" class="rb-s-line" stroke-dasharray="6 4"/><text x="' + wx(40) + '" y="' + (wy(6.6) - 6) + '" class="rb-t-mono">constant 6.6 misses it</text></g>' +
    '<g data-on="6"><text x="' + wx(34) + '" y="' + (wy(7.6)) + '" class="rb-t-ink">≤ 20% of new successes cross</text></g></svg>';

  RB.topic({
    id: "f1",
    title: "Verifiers and failure detection",
    eyebrow: "Part F · Trust",
    lede: "A verifier scores what a robot policy proposes or does. Cheap scores come from the policy itself; trustworthy ones cost more.",
    refs: ["P14 §1, §4–6", "P01 §6.2.2", "X3 §V-E"],
    why: "Verifiers decide which demonstrations enter training, which action runs, what counts as reward and when a rollout stops. One wrong score reaches all four. This topic sorts verifiers by who supplies the judgment, then shows how failure detectors read a policy's own signals and use conformal calibration to bound false alarms.",
    outcomes: [
      "Classify a verifier by its judge source and by its use.",
      "Explain the availability and credibility trade-off with two examples.",
      "Compute a conformal alarm threshold from calibration scores by hand.",
      "Predict when a conformal failure alarm loses its guarantee.",
      "Compare SAFE, FAIL-Detect, FIPER and Sentinel by signal and training data."
    ],
    concepts: [
      { name: "Verifier", def: "A mapping from a context and a candidate (action chunk, rollout or whole policy) to a score.", ref: "P14 eq. 1", art: ART.verifier, term: "verifier", sym: "score" },
      { name: "Four judge sources", def: "The judgment comes from a human, a written rule, a learned model, or signals the policy already computes.", ref: "P14 §1, Table 1", art: ART.judges, term: "judge-source" },
      { name: "No free checker", def: "As verdicts get cheaper, earlier and denser, a high score says less about the task.", ref: "P14 §1, §7", art: ART.tradeoff, term: "availability-and-credibility" },
      { name: "Best-of-N selection", def: "Sample N candidate actions, score each, run the best. V-GPS used a Q-function; RoboMonkey a VLM verifier.", ref: "P14 §4.2", art: ART.bestofn, term: "test-time-verification", sym: "N" },
      { name: "Intrinsic failure detector", def: "Reads the policy's own signals: SAFE probes vision-language-action (VLA) features; FIPER adds action-chunk entropy to novelty.", ref: "P14 §5.1", art: ART.intrinsic, term: "model-intrinsic-verifier" },
      { name: "Conformal alarm band", def: "A time-varying threshold from successful rollouts that at most a fraction α of new successes cross.", ref: "FAIL-Detect, arXiv 2503.08558", art: ART.band, term: "functional-conformal-prediction", sym: "alpha-cp", href: "#lab/verifier" },
      { name: "Reward hacking", def: "A policy optimized against a score drifts to where the score is high and the task fails.", ref: "P14 §6.3", art: ART.hacking, term: "reward-hacking" }
    ],
    flow: {
      title: "The four places a verifier acts", ref: "P14 Table 5, Fig. 4", w: 820, h: 300,
      caption: "One verifier can curate data, shape the reward, rank candidates and gate execution. Follow the steps: each use exposes a different error.",
      nodes: [
        { id: "data", x: 10, y: 30, w: 150, h: 56, label: "Demo corpus", sub: "demos and rollouts", kind: "store" },
        { id: "train", x: 250, y: 30, w: 150, h: 56, label: "Policy training", sub: "imitation or RL", kind: "agent" },
        { id: "policy", x: 490, y: 30, w: 160, h: 56, label: "Policy π", sub: "proposes N chunks", kind: "agent" },
        { id: "verifier", x: 490, y: 170, w: 160, h: 60, label: "Verifier S", sub: "scores candidates", kind: "decision" },
        { id: "robot", x: 720, y: 170, w: 96, h: 60, label: "Robot", sub: "acts", kind: "env" }
      ],
      edges: [
        { from: "data", to: "train", label: "kept data" },
        { from: "train", to: "policy", label: "weights" },
        { from: "policy", to: "verifier", label: "N candidates" },
        { from: "verifier", to: "robot", label: "run / stop" },
        { from: "verifier", to: "train", label: "reward", sides: ["l", "b"], via: [[325, 200]] },
        { from: "robot", to: "data", label: "new rollouts", sides: ["b", "b"], via: [[768, 280], [85, 280]], dy: -6 }
      ],
      steps: [
        { on: ["data", "data>train", "train"], text: "Curation: the verifier scores stored demonstrations and rollouts, and low scorers are dropped or down-weighted before training (Demo-SCORE, SCIZOR)." },
        { on: ["verifier", "verifier>train", "train"], text: "Reward: in post-training the score becomes a reward or advantage, as with RECAP's value function. Now the policy searches against the verifier." },
        { on: ["train>policy", "policy", "policy>verifier", "verifier"], text: "Ranking: at run time the policy proposes N candidate chunks and the verifier picks one (V-GPS, RoboMonkey)." },
        { on: ["verifier>robot", "robot"], text: "Gating: a runtime monitor watches the rollout and stops it or asks for help when its score crosses a calibrated threshold (SAFE, FAIL-Detect, KnowNo)." },
        { on: ["robot>data", "data"], text: "Rollouts return to the corpus. One verifier error reaches the data, the ranking, the reward and the executed action together (P14 §6)." }
      ]
    },
    worked: {
      title: "Calibrating a failure alarm band by hand",
      ref: "FAIL-Detect, arXiv 2503.08558 · P14 §6.3", prov: "Our toy numbers",
      eq: { tex: "\\text{alarm at } t \\iff \\class{sym-score}{S_t} > \\class{sym-cp-mu}{\\mu_t} + \\class{sym-cp-bw}{h}\\,\\class{sym-cp-sd}{\\sigma_t}", words: "Raise an alarm when the detector score climbs above the mean success score plus h spreads.", key: ["score", "cp-mu", "cp-bw", "cp-sd"] },
      figure: WE_FIG,
      steps: [
        { title: "Collect successful rollouts", text: "Run the frozen policy and keep 18 successes. Half A gives the mean score μₜ and spread σₜ at each step." },
        { title: "Take each worst moment", text: "For each of the other nine, take its largest (Sₜ − μₜ)/σₜ. Sorted: 0.8, 1.1, 1.3, 1.4, 1.6, 1.9, 2.1, 2.4, 3.0." },
        { title: "Pick the conformal quantile", text: "With α = 0.2, k = ⌈(9 + 1)(1 − 0.2)⌉ = 8. The eighth smallest value gives h = 2.4." },
        { title: "Draw the band", text: "At the grasp, t = 20: 3.0 + 2.4 × 1.5 = 6.6. Placing, t = 50: 2.0 + 2.4 × 0.5 = 3.2." },
        { title: "Test a new rollout", text: "It scores 5.1 at t = 20: below 6.6, no alarm. At t = 50 it scores 4.0, above 3.2: alarm. A constant 6.6 misses it." },
        { title: "What α promises", text: "At most 20% of new successes from the same pool cross the band. Missed failures have no such bound." }
      ]
    },
    ruleTitle: "Scores, selections and alarms",
    methodsLede: "How the line evolved: STAC, inside Sentinel, compared batches of sampled action chunks over time and needed hundreds of samples per step. FAIL-Detect replaced it with a one-pass learned score, logpZO, and a time-varying conformal band. FIPER required observation novelty and action-chunk entropy to agree. SAFE trained a probe on VLA features from successes and failures across tasks. For selection, V-GPS re-ranked samples with an offline reinforcement learning (RL) Q-function; RoboMonkey swapped in a vision-language model (VLM) verifier.",
    rules: [
      { name: "What a verifier is", ref: "P14 eq. 1", term: "verifier",
        tex: "\\class{sym-score}{S} = \\mathrm{verifier}\\big(\\underbrace{\\class{sym-o}{o_t},\\ \\class{sym-l}{\\ell}}_{\\text{context}},\\ c\\big)",
        words: "The context holds observations, a goal and possibly an instruction. The candidate c ranges from one action chunk to a whole policy.",
        key: ["score", "o", "l", { glyph: "c", meaning: "candidate: chunk, rollout or policy" }] },
      { name: "Best-of-N selection", ref: "P14 §4.2 · arXiv 2410.13816, 2506.17811", term: "test-time-verification",
        tex: "\\class{sym-a}{a_t} = \\arg\\max_{i \\le \\class{sym-N}{N}} \\class{sym-score}{S}\\big(\\class{sym-o}{o_t}, \\class{sym-l}{\\ell}, \\class{sym-a}{a^{i}_t}\\big), \\qquad \\class{sym-a}{a^{i}_t} \\sim \\class{sym-pi}{\\pi_\\theta}(\\cdot \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})",
        words: "Sample N actions from a frozen policy and run the highest scorer. V-GPS scores with a Q-function; RoboMonkey with a 7B VLM verifier.",
        key: ["a", "N", "score", "o", "l", "pi"] },
      { name: "KnowNo: a conformal prediction set", ref: "arXiv 2307.01928", term: "conformal-prediction-set",
        tex: "\\begin{gathered}\\class{sym-cp-kappa}{\\kappa_i} = 1 - \\class{sym-llm-p}{\\hat f}(x_i)_{y_i}, \\qquad \\class{sym-cp-set}{C}(x) = \\{\\, y : \\class{sym-llm-p}{\\hat f}(x)_y \\ge 1 - \\class{sym-cp-qhat}{\\hat q} \\,\\} \\\\ \\Pr\\big(y \\in \\class{sym-cp-set}{C}(x)\\big) \\ge 1 - \\class{sym-alpha-cp}{\\alpha}\\end{gathered}",
        words: "Calibrate q̂ as a quantile of how unsure the model was about right answers. Keep every option above 1 − q̂; ask a human if several remain.",
        key: ["cp-kappa", "llm-p", "cp-set", "cp-qhat", "alpha-cp", { glyph: "y", meaning: "an option label (A–E)" }] },
      { name: "From one threshold to a band", ref: "arXiv 2410.04640 → 2503.08558",
        before: "\\text{alarm} \\iff \\class{sym-score}{S_t} > \\gamma",
        tex: "\\text{alarm} \\iff \\class{sym-score}{S_t} > \\class{sb-chg}{\\class{sym-cp-mu}{\\mu_t} + \\class{sym-cp-bw}{h}\\,\\class{sym-cp-sd}{\\sigma_t}}",
        words: "Sentinel's STAC used one threshold γ over the whole rollout. FAIL-Detect made it follow the task's phases, still calibrated on successes only.",
        key: ["score", { glyph: "γ", meaning: "one calibrated threshold" }, "cp-mu", "cp-bw", "cp-sd"], diff: true, beforeLabel: "Sentinel (STAC)", afterLabel: "FAIL-Detect" },
      { name: "FIPER: two signals must agree", ref: "arXiv 2510.09459",
        before: "\\text{alarm} \\iff \\eta_O > \\gamma_{O,t}",
        tex: "\\text{alarm} \\iff \\eta_O > \\gamma_{O,t} \\class{sb-new}{\\ \\wedge\\ \\eta_A > \\gamma_{A,t}}",
        words: "An observation-only score also fires on new but harmless scenes. FIPER alarms only when action-chunk entropy is high too.",
        key: [{ glyph: "η_O", meaning: "windowed observation-novelty score" }, { glyph: "γ_O,t", meaning: "its conformal threshold" }, { glyph: "η_A", meaning: "windowed action-chunk entropy" }, { glyph: "γ_A,t", meaning: "its conformal threshold" }, { glyph: "∧", meaning: "logical and" }], diff: true, beforeLabel: "Novelty only", afterLabel: "FIPER" }
    ],
    algorithm: {
      title: "Functional conformal failure detection", ref: "FAIL-Detect, arXiv 2503.08558", prov: "Simplified: σₜ as the band shape",
      lines: [
        '<span class="kw">input</span> detector score <span data-sym="score">Sₜ</span>, successful calibration rollouts, error rate <span data-sym="alpha-cp">α</span> (FAIL-Detect: 0.05)',
        'split the successes into halves A and B',
        'from A: mean <span data-sym="cp-mu">μₜ</span> and spread <span data-sym="cp-sd">σₜ</span> of the score at every step t',
        'for each rollout in B: r ← max over t of (<span data-sym="score">Sₜ</span> − <span data-sym="cp-mu">μₜ</span>) / <span data-sym="cp-sd">σₜ</span>',
        '<span data-sym="cp-bw">h</span> ← the ⌈(|B| + 1)(1 − <span data-sym="alpha-cp">α</span>)⌉-th smallest r',
        '<span class="kw">at run time</span>, every step: <span class="kw">if</span> <span data-sym="score">Sₜ</span> &gt; <span data-sym="cp-mu">μₜ</span> + <span data-sym="cp-bw">h</span>·<span data-sym="cp-sd">σₜ</span>: stop or ask for help',
        '<span class="cm">// promise: at most α of new successes from the same pool raise an alarm</span>'
      ]
    },
    playgrounds: [
      {
        id: "band", title: "A conformal failure band on a toy flow policy", ref: "FAIL-Detect · SAFE · Sentinel", prov: "Simplified: 2-D toy",
        try: "Compare Constant with Time-varying band and watch the slip failures. Then raise Test shift to 1.0, switch to Stall failures, and tick the progress monitor.",
        mount: mountBand,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "f1-band";
          return [
            { target: q("canvas"), title: "Read the picture", text: "Each line is one test rollout's novelty score. The thick band was calibrated on 25 plus 25 successful rollouts with α = 0.05." },
            { target: q("#" + id + "-band"), title: "One threshold for all", text: "A constant threshold must stay above the noisy grasp, so it sits high and catches later slips late.", do: function (a) { return a.click(q("#" + id + '-band [value="const"]')); }, task: "Choose Constant", expect: function () { return api.state().band === "const"; } },
            { target: q("#" + id + "-band"), title: "Back to the band", text: "The time-varying band drops after the grasp, so slips there trip it sooner.", do: function (a) { return a.click(q("#" + id + '-band [value="time"]')); }, task: "Choose Time-varying band", expect: function () { return api.state().band === "time"; } },
            { target: q("#" + id + "-shift"), title: "Break exchangeability", text: "Shift the test successes away from the calibration pool, as an unseen task would. False alarms now exceed α.", do: function (a) { return a.set(q("#" + id + "-shift"), 1); }, task: "Set Test shift to 1.0", expect: function () { return api.state().shift >= 0.8; } },
            { target: q("#" + id + "-kind"), title: "A familiar-looking failure", text: "In a stall the arm freezes at a state it has seen before, so the novelty score stays low.", do: function (a) { return a.click(q("#" + id + '-kind [value="stall"]')); }, task: "Choose Stall", expect: function () { return api.state().kind === "stall"; } },
            { target: q("#" + id + "-prog"), title: "Add a slow monitor", text: "A progress check catches the stalls, a few steps late, as Sentinel's VLM check does.", do: function (a) { return a.click(q("#" + id + "-prog")); }, task: "Tick the progress monitor", expect: function () { return api.state().prog; } },
            { target: q("#" + id + "-m"), title: "Your turn", text: "Set the shift back to 0, then lower M to 10 with α = 0.05. Why does the threshold become infinite?" }
          ];
        }
      },
      {
        id: "sets", title: "KnowNo: ask for help when the set is not one", ref: "KnowNo, arXiv 2307.01928", prov: "Illustrative: toy scores",
        try: "Lower α: sets grow and the robot asks more often, while the right option stays in the set about 1 − α of the time. Then add ambiguous instructions.",
        mount: mountSets,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "f1-sets";
          return [
            { target: q("canvas"), title: "Calibration first", text: "Each bar counts calibration scenarios by how unsure the model was about the right object. The line q̂ leaves a fraction α to its right." },
            { target: q("#" + id + "-eps"), title: "Demand a stronger promise", text: "A smaller α moves q̂ right, so more options clear the bar and the robot asks more often.", do: function (a) { return a.set(q("#" + id + "-eps"), 0.05); }, task: "Set α to 0.05", expect: function () { return api.state().eps <= 0.06; } },
            { target: q("#" + id + "-amb"), title: "Ambiguous instructions", text: "When “the bowl” could mean two bowls, both get similar scores and the set keeps both.", do: function (a) { return a.set(q("#" + id + "-amb"), 0.6); }, task: "Set ambiguous instructions to 60%", expect: function () { return api.state().amb >= 0.55; } },
            { target: q("#" + id + "-go"), title: "Look at one case", text: "Step through new scenarios. Ambiguous ones usually end with two options and a question to the human.", do: function (a) { return a.click(q("#" + id + "-go")); }, task: "Show the next scenario", expect: function () { return api.state().idx > 0; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Raise α to 0.30: some sets come out empty, which also means asking. On hardware KnowNo asked in 58% of steps; a simple threshold, 72%." }
          ];
        }
      }
    ],
    methods: ["safe", "fail-detect", "fiper", "sentinel", "knowno", "v-gps", "robomonkey", "gvl", "recap", "world-action-verifier"],
    open: [
      { title: "No free checker yet", text: "No verifier family combines high availability with high credibility; the survey names reaching both as the main future work.", refs: "P14 §7" },
      { title: "Calibration under optimization", text: "Conformal margins hold for a frozen policy and weaken once a policy trains against the detector; online recalibration gives only asymptotic guarantees.", refs: "P14 §6.3" },
      { title: "No exploitability benchmark", text: "No shared benchmark holds candidates fixed and measures how far a learned robot verifier can be exploited by search.", refs: "P14 §6.3, Table 7" },
      { title: "Shared blindness", text: "A verifier trained on the same data or representation as a world model may miss the same contact and feasibility errors.", refs: "X3 §V-E" }
    ],
    takeaways: [
      "A verifier maps a context and a candidate to a score; the candidate can be one chunk, a rollout or a whole policy.",
      "Judge sources trade availability for credibility: human verdicts are costly but direct, intrinsic signals are nearly free but describe the model.",
      "Failure detectors moved from sampling-heavy action consistency (STAC) to one-pass learned scores (logpZO, SAFE) and combined signals (FIPER).",
      "Conformal calibration bounds false alarms on successes from the same pool; distribution shift or training against the detector breaks that bound.",
      "A score used as reward or runtime gate is searched against, so it needs no exploitable region, which robotics has not yet tested."
    ],
    quiz: [
      { q: "A failure band was calibrated on successful rollouts with α = 0.05. What does the guarantee promise?", options: ["At most 5% of failures are missed", "At most 5% of new same-pool successes raise an alarm", "Alarms arrive 5% earlier than without it", "Nothing, unless failures were in the calibration set"], correct: 1, why: "Functional conformal prediction bounds false alarms on exchangeable successful rollouts. It says nothing about catching failures (FAIL-Detect, FIPER)." },
      { q: "Why does P14 rate model-intrinsic verifiers low on credibility?", options: ["They are slow to compute", "They need many human labels", "Their score describes the model, not the task", "They only work in simulation"], correct: 2, why: "Intrinsic scores are nearly free, but they measure whether behavior looks familiar to the model; a familiar-looking failure can still score well (P14 §1, §5.1)." },
      { q: "What did SAFE change relative to FAIL-Detect?", options: ["It dropped conformal prediction entirely", "It samples 256 action chunks per step", "It asks a VLM at every step", "It probes VLA features trained on successes and failures across tasks"], correct: 3, why: "FAIL-Detect learns from successes only, per task. SAFE trains a small probe on VLA features with both outcomes and tests on unseen tasks (arXiv 2506.09937)." },
      { q: "In KnowNo, when does the robot ask a human for help?", options: ["When its prediction set holds more than one option", "When the top probability is below 0.5", "After every planning step", "When the calibration set is empty"], correct: 0, why: "KnowNo keeps every option whose score clears 1 − q̂. A single option is executed; otherwise the human chooses (arXiv 2307.01928)." },
      { q: "Why does training a policy against a verifier weaken the verifier's calibration?", options: ["The verifier's weights are overwritten", "Rewards become too sparse to calibrate", "The policy moves rollouts toward where the verifier is wrong", "Calibration only works for language models"], correct: 2, why: "Training changes the data the verifier later sees, so exchangeability with the held-out set fails and the conformal margin no longer holds (P14 §6.3)." }
    ],
    cards: [
      { front: "What are the four judge sources of robot verifiers?", back: "Human, rule-based and formal, learned and pretrained, and model-intrinsic.", ref: "P14 §1" },
      { front: "Availability versus credibility: what are they?", back: "Availability: how cheap, early and frequent a verdict is. Credibility: how much a high score says about the task. They move in opposite directions.", ref: "P14 §1" },
      { front: "Name the four uses of a verifier.", back: "Curation, ranking, training reward and runtime gating. The last two are searched against, so they must have no exploitable region.", ref: "P14 Table 5" },
      { front: "What is FAIL-Detect's logpZO score?", back: "The squared norm of the noise a flow model maps an observation embedding to. A large norm means an unlikely observation.", ref: "arXiv 2503.08558" },
      { front: "Why does FIPER require two signals to agree?", back: "Observation novelty alone fires on harmless new scenes. Requiring action-chunk entropy too raised average accuracy to 0.78, against 0.69 for logpZO.", ref: "arXiv 2510.09459" },
      { front: "What does the proxy gain that transfers measure?", back: "Δpanel / Δproxy: the share of a reward gain that verifiers the policy never trained against confirm.", ref: "P14 §6.4" }
    ],
    terms: {
      "verifier": { name: "verifier", aliases: ["robot verifier", "judge"], group: "trust", sym: "S", symTex: "S", def: "A mapping from a context (observations, goal, instruction) and a candidate (action chunk, trajectory or policy) to a score that may be boolean, scalar, vector-valued or a distribution.", note: "Success detectors, reward models, runtime monitors and safety filters are all verifiers in this sense.", ref: "P14 eq. 1", scene: "system", focus: ["verifier"], look: "the verifier scoring a candidate", uses: [] },
      "judge-source": { name: "judge source", aliases: ["verifier family"], group: "trust", def: "Who supplies the judgment: a person, a predefined rule or formal specification, a learned or pretrained model, or signals the policy or world model already computes.", note: "P14 counts each paper in exactly one judge-source column.", ref: "P14 §1, Table 1", scene: "system", focus: ["verifier", "human-teleop"], look: "the verifier and the human beside it", uses: ["verifier"] },
      "availability-and-credibility": { name: "availability and credibility", aliases: ["no free checker"], group: "trust", def: "Availability is how cheap, early and frequent a verdict is; credibility is how much a high score tells about the task. Across verifier families, credibility falls as availability rises.", note: "Model-intrinsic scores are the most available and the least directly tied to task success.", ref: "P14 §1, §7", scene: "system", focus: ["verifier"], look: "the verifier's place in the loop", uses: ["judge-source"] },
      "test-time-verification": { name: "test-time verification", aliases: ["best-of-N selection", "inference-time verification"], group: "trust", def: "Generating several candidate actions, skills or plans, scoring each with a verifier, and executing the highest-scoring candidate.", note: "It costs latency: RoboMonkey reports about 650 ms per step for 16 candidates on an H100.", ref: "P14 §4.2", scene: "system", focus: ["action-head", "verifier"], look: "candidates flowing into the verifier", uses: ["verifier", "action-chunk"] },
      "model-intrinsic-verifier": { name: "model-intrinsic verifier", aliases: ["intrinsic verifier", "policy self-verification"], group: "trust", def: "A verifier that reads a quantity the robot's own policy or world model already computes, such as internal features, action uncertainty or model disagreement.", note: "Its score describes the model, so a familiar-looking failure can still look reliable.", ref: "P14 §5, §5.1", scene: "system", focus: ["latent", "verifier"], look: "a probe on the policy's features", uses: ["verifier"] },
      "runtime-failure-detection": { name: "runtime failure detection", aliases: ["failure detector", "runtime monitor"], group: "trust", def: "Scoring an ongoing execution at each step and raising an alarm when its behavior deviates from patterns of normal operation, often before failure is externally apparent.", note: "Detection watches one committed rollout; selection compares candidates before any runs.", ref: "P14 §5.1", scene: "system", focus: ["verifier", "robot"], look: "the monitor beside the running robot", uses: ["model-intrinsic-verifier"] },
      "functional-conformal-prediction": { name: "functional conformal prediction", aliases: ["conformal band", "time-varying threshold"], group: "trust", def: "Calibrating a time-varying threshold band on successful rollouts so that new successful rollouts cross it with probability at most α.", note: "It bounds false alarms, not missed failures.", ref: "arXiv 2503.08558", scene: "system", focus: ["verifier"], look: "the alarm threshold inside the verifier", uses: ["exchangeability", "runtime-failure-detection"] },
      "conformal-prediction-set": { name: "conformal prediction set", aliases: ["KnowNo set"], group: "trust", def: "The options whose model score clears a threshold calibrated so that the correct option is in the set with probability at least 1 − α.", note: "In KnowNo a set with more than one option means the robot asks a human.", ref: "arXiv 2307.01928", scene: "system", focus: ["planner", "verifier"], look: "the planner's options being filtered", uses: ["exchangeability"] },
      "exchangeability": { name: "exchangeability", aliases: ["same-pool assumption"], group: "trust", def: "The requirement that rollouts judged later come from the same pool as the held-out calibration set; conformal coverage rests on it.", note: "Filtering by the verifier's own score or retraining the policy changes the pool.", ref: "P14 §6.3", scene: "system", focus: ["verifier", "data-robot"], look: "calibration data feeding the verifier", uses: [] },
      "reward-hacking": { name: "reward hacking", aliases: ["verifier exploitation"], group: "trust", def: "The failure of a score used for optimization: a policy trained against it is driven toward inputs where the score is high but the task fails.", note: "Curation and ranking tolerate average error; rewards and gates face a search for the wrong-scoring region.", ref: "P14 §6.3", scene: "system", focus: ["reward-model", "policy-update"], look: "the reward model driving the update", uses: ["verifier"] },
      "action-chunk-entropy": { name: "action-chunk entropy", aliases: ["ACE"], group: "trust", def: "FIPER's action-side score: the histogram entropy of B sampled action chunks at each future step, summed over the chunk.", note: "It needs a batch of sampled chunks per step, which is costly on small onboard computers.", ref: "arXiv 2510.09459", scene: "system", focus: ["action-chunk", "noise"], look: "many sampled chunks for one step", uses: ["action-chunk"] },
      "proxy-gain-that-transfers": { name: "proxy gain that transfers", aliases: ["Δpanel/Δproxy"], group: "eval", def: "The reward gain between two checkpoints under a panel of verifiers the policy never trained against, divided by the gain under its training verifier.", note: "One means the panel confirms the whole gain; a negative value means the panel scores the policy lower.", ref: "P14 §6.4", scene: "system", focus: ["reward-model", "verifier"], look: "two verifiers scoring the same rollouts", uses: ["reward-hacking"] }
    },
    symbols: [
      { id: "cp-mu", tex: "\\mu_t", glyph: "μₜ", kind: "Functions", meaning: "mean detector score of successful calibration rollouts at step t", short: "mean success score at t", first: "f1", read: "mu sub t", papers: "FAIL-Detect, SAFE: μ_t" },
      { id: "cp-sd", tex: "\\sigma_t", glyph: "σₜ", kind: "Functions", meaning: "spread of calibration scores at step t, used as the band's shape", short: "score spread at t", first: "f1", read: "sigma sub t", papers: "FAIL-Detect: modulation s_A^cal(t)" },
      { id: "cp-bw", tex: "h", glyph: "h", kind: "Parameters", meaning: "conformal bandwidth: quantile of the largest normalized deviations of calibration successes", short: "conformal bandwidth", first: "f1", read: "h", papers: "FAIL-Detect, SAFE: h" },
      { id: "cp-qhat", tex: "\\hat{q}", glyph: "q̂", kind: "Parameters", meaning: "calibrated quantile of nonconformity scores", short: "calibrated quantile", first: "f1", read: "q hat", papers: "KnowNo: q̂" },
      { id: "cp-kappa", tex: "\\kappa", glyph: "κ", kind: "Functions", meaning: "nonconformity score: one minus the model's probability of the correct option", short: "nonconformity score", first: "f1", read: "kappa", papers: "KnowNo: κ" },
      { id: "cp-set", tex: "C(x)", glyph: "C(x)", kind: "Functions", meaning: "conformal prediction set of options for input x", short: "prediction set", first: "f1", read: "C of x", papers: "KnowNo: C(x̃)" },
      { id: "llm-p", tex: "\\hat{f}(x)_y", glyph: "f̂(x)ᵧ", kind: "Functions", meaning: "language model's probability for option label y given context x", short: "option probability", first: "f1", read: "f hat of x, sub y", papers: "KnowNo: f̂(x̃)_y" }
    ],
    ledger: [
      { where: "Topic 21 · KnowNo rule and playground", source: "KnowNo writes the allowed error as ε", page: "This site writes α for every conformal error rate", why: "ε is Gaussian noise in the house notation.", kind: "Our choice" },
      { where: "Topic 21 · playground 1", source: "FAIL-Detect's logpZO is a flow network trained on observation embeddings", page: "The toy uses the exact squared distance to a 2-D demonstration tube, averaged over 3 steps", why: "Shows the calibration mechanism without training a network.", kind: "Simplified" },
      { where: "Topic 21 · worked example and algorithm", source: "FAIL-Detect shapes its band with a modulation function s_A^cal(t)", page: "The site uses the spread σₜ of calibration half A", why: "One familiar quantity; the conformal step is unchanged.", kind: "Simplified" },
      { where: "Topic 21 · band rule", source: "Sentinel's STAC sums statistical distances into a cumulative score ηₜ", page: "The before-rule writes it as Sₜ against one threshold γ", why: "Keeps the comparison with FAIL-Detect on one line.", kind: "Simplified" },
      { where: "Topic 21 · playground 1 progress monitor", source: "Sentinel asks a VLM about rollout video", page: "The toy flags stalled progress 4 steps after a 10-step check", why: "Stands in for a slow task-progress monitor.", kind: "Simplified" },
      { where: "Topic 21 · methods", source: "V-GPS reports OpenVLA rising from 0.24 to 0.27 on SIMPLER with its Q-function", page: "RoboMonkey reports V-GPS with OpenVLA below OpenVLA alone (30% vs 35% on real out-of-distribution tasks)", why: "Different setups; both are cited as reported.", kind: "Sources disagree" }
    ]
  });
})();
