/* Topic 02 · The control layer under a learned policy (framework topic). Sources: P10 §5.1–5.3 (eq. 21–28, Fig. 6, Table 5),
   P09 §V–VI (eq. 1–6, Fig. 7, Tables III–IV), P11 eq. 1–3. Learned controllers live in E4–E6; featured methods come from A3 and E5. */
(function () {
  "use strict";
  var RB = window.RB;

  function monoFont() { return getComputedStyle(document.body).getPropertyValue("--font-mono"); }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body"); }
  /* local segmented binding: reads the pressed button's value directly */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function setSlider(root, id, v, fmt) {
    var el = root.querySelector("#" + id), out = root.querySelector('[data-out="' + id + '"]');
    if (el) el.value = v; if (out) out.textContent = fmt ? fmt(v) : v;
  }

  /* ---------- playground 1: a 1-D hand pushed into a wall ---------- */
  /* Toy: a 2 kg hand on a rail with unmodeled Coulomb friction. The target ramps 120 mm in 1 s; the surface sits at 100 mm,
     so the target ends 20 mm inside it. Physics at 5 kHz, controller at 1 kHz, force sensor filtered with 2 ms. All numbers are ours. */
  var WALL = 0.10, ENV = { soft: 2e3, medium: 5e4, stiff: 5e5 }, KP_STIFF = 40000;
  function xdesAt(t) { return t < 0.2 ? 0 : t < 1.2 ? 0.12 * (t - 0.2) : 0.12; }
  function vdesAt(t) { return t >= 0.2 && t < 1.2 ? 0.12 : 0; }
  function simWall(c, ke, Kd, fric) {
    var m = 2, dt = 0.0002, sub = 5, N = 10000, be = 2 * 0.05 * Math.sqrt(ke * m);
    var Kv = 2 * 0.7 * Math.sqrt(KP_STIFF * m), Md = 1, Bd = 2 * Math.sqrt(Kd * Md), Bi = 2 * Math.sqrt(Kd * m);
    var x = 0, v = 0, u = 0, xc = 0, vc = 0, Fm = 0, pts = [], a = 1 - Math.exp(-0.5);
    for (var i = 0; i <= N; i++) {
      var t = i * dt, Fc = x > WALL ? Math.max(0, ke * (x - WALL) + be * v) : 0;
      if (i % sub === 0) {
        Fm += (Fc - Fm) * a;
        var xd = xdesAt(t), vd = vdesAt(t);
        if (c === "pd") u = KP_STIFF * (xd - x) + Kv * (vd - v);
        else if (c === "imp") u = Kd * (xd - x) + Bi * (vd - v);
        else { var acc = (-Fm - Bd * (vc - vd) - Kd * (xc - xd)) / Md; vc += acc * 0.001; xc += vc * 0.001; u = KP_STIFF * (xc - x) + Kv * (vc - v); }
        if (i % 25 === 0) pts.push([t, x, Fc]);
      }
      var fr = fric * Math.tanh(v / 0.002);
      v += (u - Fc - fr) / m * dt; x += v * dt;
      if (!isFinite(x) || Math.abs(x) > 5) break;
    }
    var free = pts.filter(function (p) { return p[0] > 0.4 && p[0] < 0.9; }), last = pts.filter(function (p) { return p[0] > 1.7; });
    var err = free.reduce(function (s, p) { return s + Math.abs(p[1] - xdesAt(p[0])); }, 0) / free.length;
    var mean = last.reduce(function (s, p) { return s + p[2]; }, 0) / last.length;
    var sd = Math.sqrt(last.reduce(function (s, p) { return s + (p[2] - mean) * (p[2] - mean); }, 0) / last.length);
    var peak = pts.reduce(function (s, p) { return Math.max(s, p[2]); }, 0);
    return { pts: pts, err: err, mean: mean, sd: sd, peak: peak, state: mean < 0.5 && sd < 1 ? "no contact" : sd < 1 ? "steady" : "chatters" };
  }

  function mountWall(body, ctx) {
    var id = ctx.id;
    var kfmt = function (v) { return v + " N/m"; }, ffmt = function (v) { return v + " N"; };
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-c", label: "Controller", value: "pd", options: [{ value: "pd", label: "PD position" }, { value: "imp", label: "Impedance" }, { value: "adm", label: "Admittance" }] }) +
      RB.seg({ id: id + "-env", label: "Surface", value: "medium", options: [{ value: "soft", label: "Soft" }, { value: "medium", label: "Medium" }, { value: "stiff", label: "Stiff" }] }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-k", label: "Stiffness K_d", min: 100, max: 5000, step: 100, value: 500, fmt: kfmt }) + RB.slider({ id: id + "-f", label: "Unmodeled friction", min: 0, max: 20, step: 1, value: 10, fmt: ffmt }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-ghost" checked> <span>Show the other two</span></label></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Hand position and contact force over two seconds for the chosen controller"></canvas><figcaption class="sb-caption">Top: dashed = target, gray band = inside the surface. Bottom: contact force. Compare the peak force and whether the hand follows the target before contact.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "err", k: "Tracking error before contact", u: "mm" }, { id: "peak", k: "Peak contact force", u: "N" }, { id: "fin", k: "Final contact force", u: "N" }, { id: "st", k: "After contact" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-3", label: "PD position", kind: "line" }, { c: "data-1", label: "impedance", kind: "line" }, { c: "data-2", label: "admittance", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    var S = { c: "pd", env: "medium", Kd: 500, f: 10, ghost: true }, runs = {}, W = 540, H = 400;
    var COL = { pd: "data-3", imp: "data-1", adm: "data-2" };
    var NOTES = {
      pd: "A stiff PD loop tracks the target to a fraction of a millimeter, so it tries to reach 20 mm inside the surface and presses hard. P10 §5.1.2: PD gives no easily adjustable compliance.",
      imp: "Impedance control makes the hand act like a spring K_d to the target. Contact force stays small without a force sensor, but unmodeled friction becomes tracking error (P10 §5.1.3).",
      adm: "Admittance control measures the contact force and moves a virtual spring-mass target that a stiff position loop tracks. Friction is rejected; the loop needs a force sensor (P10 §5.1.4)."
    };
    function run() {
      ["pd", "imp", "adm"].forEach(function (c) { runs[c] = simWall(c, ENV[S.env], S.Kd, S.f); });
      var r = runs[S.c];
      RB.setRO(body, "err", RB.fmt(r.err * 1000, 1));
      RB.setRO(body, "peak", RB.fmt(r.peak, 1));
      RB.setRO(body, "fin", RB.fmt(r.mean, 1));
      RB.setRO(body, "st", r.state);
      note.textContent = NOTES[S.c] + (S.c === "adm" && S.env !== "soft" && r.state === "chatters" ? " Here it chatters: the stiff surface and the sensor filter leave the virtual dynamics badly damped (our toy)." : "");
      body.querySelector("#" + id + "-k").disabled = S.c === "pd";
      draw();
    }
    function draw() {
      if (!runs[S.c]) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), L = 52, R = W - 14;
      var sx = function (t) { return L + t / 2 * (R - L); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var y0 = 16, y1 = 176, sy = function (x) { return y1 - x / 0.13 * (y1 - y0); };
      var f0 = 222, f1 = H - 30, r = runs[S.c], fmax = Math.max(15, r.peak * 1.15), sf = function (F) { return f1 - Math.min(F, fmax) / fmax * (f1 - f0); };
      c.fillStyle = P["surface-strong"]; c.fillRect(L, y0, R - L, sy(WALL) - y0);
      c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.beginPath(); c.moveTo(L, sy(WALL)); c.lineTo(R, sy(WALL)); c.stroke();
      c.strokeStyle = P.line; [y1, f1].forEach(function (yy) { c.beginPath(); c.moveTo(L, yy); c.lineTo(R, yy); c.stroke(); });
      c.font = "500 11px " + monoFont(); c.fillStyle = P["ink-3"];
      c.fillText("surface", L + 6, sy(WALL) - 6); c.fillText("position (mm)", L + 6, y1 + 16); c.fillText("contact force (N)", L + 6, f0 - 6);
      c.textAlign = "right"; [0, 50, 100].forEach(function (mm) { c.fillText(String(mm), L - 6, sy(mm / 1000) + 4); });
      [0, fmax / 2, fmax].forEach(function (F) { c.fillText(RB.fmt(F, 0), L - 6, sf(F) + 4); });
      c.textAlign = "center"; [0, 0.5, 1, 1.5, 2].forEach(function (t) { c.fillText(t + " s", sx(t), H - 8); }); c.textAlign = "left";
      c.strokeStyle = P["ink-2"]; c.setLineDash([5, 4]); c.beginPath(); for (var t = 0; t <= 2; t += 0.02) { if (t) c.lineTo(sx(t), sy(xdesAt(t))); else c.moveTo(sx(t), sy(xdesAt(t))); } c.stroke(); c.setLineDash([]);
      var order = ["pd", "imp", "adm"].filter(function (k) { return k !== S.c; }).concat([S.c]);
      order.forEach(function (k) {
        if (k !== S.c && !S.ghost) return;
        var rr = runs[k]; c.strokeStyle = P[COL[k]]; c.globalAlpha = k === S.c ? 1 : 0.3; c.lineWidth = k === S.c ? 2.2 : 1.4;
        c.beginPath(); rr.pts.forEach(function (p, j) { var X = sx(p[0]), Y = sy(Math.max(-0.005, Math.min(0.13, p[1]))); if (j) c.lineTo(X, Y); else c.moveTo(X, Y); }); c.stroke();
        c.beginPath(); rr.pts.forEach(function (p, j) { var X = sx(p[0]), Y = sf(p[2]); if (j) c.lineTo(X, Y); else c.moveTo(X, Y); }); c.stroke();
      });
      c.globalAlpha = 1; c.lineWidth = 1;
      if (r.peak * 1.15 > fmax - 0.01) { c.fillStyle = P["ink-2"]; c.font = "600 12px " + bodyFont(); c.fillText("peak " + RB.fmt(r.peak, 0) + " N", sx(1.25), sf(r.peak) - 6 < f0 ? f0 + 12 : sf(r.peak) - 6); }
    }
    bindSeg(body, id + "-c", function (v) { S.c = v; run(); });
    bindSeg(body, id + "-env", function (v) { S.env = v; run(); });
    RB.bindSlider(body, id + "-k", kfmt, function (v) { S.Kd = v; run(); });
    RB.bindSlider(body, id + "-f", ffmt, function (v) { S.f = v; run(); });
    body.querySelector("#" + id + "-ghost").addEventListener("change", function (e) { S.ghost = e.target.checked; draw(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { c: S.c, env: S.env, Kd: S.Kd, f: S.f }; }, result: function () { return runs[S.c]; } };
  }

  /* ---------- playground 2: which stiffness should the policy send? (wiping over a bump) ---------- */
  /* Quasi-static toy: the policy plans a flat board and pushes 12 mm below it. The real board has a bump. Normal force = series
     spring (robot k_n, sponge 2000 N/m) times the overlap; the tool lags the stroke by μF/k_t with μ = 0.8. Numbers are ours. */
  var KE_SPONGE = 2000, MU = 0.8, DEPTH = 0.012, BAND = [4, 30], LAGMAX = 0.005;
  function wipe(kn, kt, A) {
    var out = [], ks = kn * KE_SPONGE / (kn + KE_SPONGE);
    for (var i = 0; i <= 120; i++) {
      var s = i / 120 * 0.3, h = A * Math.exp(-Math.pow((s - 0.15) / 0.035, 2) / 2), zd = -DEPTH, F = 0, z = zd;
      if (h > zd) { F = ks * (h - zd); z = h - F / KE_SPONGE; }
      var lag = MU * F / kt, k = F > BAND[1] ? "hard" : (F < BAND[0] ? "light" : (lag > LAGMAX ? "lag" : "good"));
      out.push({ s: s, h: h, z: z, F: F, lag: lag, k: k });
    }
    return out;
  }
  var PRESETS = { stiff: [10000, 10000], soft: [500, 500], dir: [600, 5000] };

  function mountWipe(body, ctx) {
    var id = ctx.id, kfmt = function (v) { return v + " N/m"; }, mfmt = function (v) { return v + " mm"; };
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-p", label: "Stiffness the policy sends", value: "stiff", options: [{ value: "stiff", label: "Stiff" }, { value: "soft", label: "Soft" }, { value: "dir", label: "Directional" }] }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-kn", label: "Normal stiffness k_n", min: 100, max: 10000, step: 100, value: 10000, fmt: kfmt }) + RB.slider({ id: id + "-kt", label: "Tangent stiffness k_t", min: 100, max: 10000, step: 100, value: 10000, fmt: kfmt }) + RB.slider({ id: id + "-a", label: "Unseen bump", min: 0, max: 30, step: 1, value: 20, fmt: mfmt }) + "</div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Side view of a wiping stroke over a board with a bump, and the normal force along the stroke"></canvas><figcaption class="sb-caption">Top: the policy plans a flat board (dashed) and aims 12 mm below it. Bottom: normal force along the stroke; the green band is a good wipe.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "good", k: "Stroke wiped well", u: "%" }, { id: "peak", k: "Peak normal force", u: "N" }, { id: "lag", k: "Largest lag along the stroke", u: "mm" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "good wipe", kind: "dot" }, { c: "bad", label: "presses too hard", kind: "dot" }, { c: "warn", label: "too light or lags", kind: "dot" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 540, H = 340;
    var S = { p: "stiff", kn: 10000, kt: 10000, A: 0.02 }, res = null;
    var NOTES = {
      stiff: "Position-only targets act like very high stiffness: the bump turns 12 mm of planned push into a large force. In ACP's wiping test the stiff policy broke the tool (arXiv 2410.09309).",
      soft: "Uniform low stiffness keeps the force gentle, but friction drags the tool behind the stroke. ACP's uniform 500 N/m baseline wiped 43.75% of trials successfully.",
      dir: "ACP labels low stiffness along the measured force and high stiffness elsewhere, and its diffusion policy predicts it. It reached 93.75% on vase wiping.",
      custom: "Your own gains. Comp-ACT and DIPCOM predict a 6-D diagonal stiffness; AdmitDiff predicts a desired contact force instead (method cards)."
    };
    function run() {
      res = wipe(S.kn, S.kt, S.A);
      var good = res.filter(function (p) { return p.k === "good"; }).length;
      RB.setRO(body, "good", String(Math.round(100 * good / res.length)));
      RB.setRO(body, "peak", RB.fmt(Math.max.apply(null, res.map(function (p) { return p.F; })), 1));
      RB.setRO(body, "lag", RB.fmt(1000 * Math.max.apply(null, res.map(function (p) { return p.lag; })), 1));
      note.textContent = NOTES[S.p];
      draw();
    }
    function draw() {
      if (!res) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), L = 46, R = W - 14;
      var sx = function (s) { return L + s / 0.3 * (R - L); }, sz = function (z) { return 90 - z * 2400; };
      var col = function (k) { return k === "good" ? P["data-1"] : k === "hard" ? P.bad : P.warn; };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.fillStyle = P["surface-strong"]; c.beginPath(); c.moveTo(sx(0), 170);
      res.forEach(function (p) { c.lineTo(sx(p.s), sz(p.h)); }); c.lineTo(sx(0.3), 170); c.closePath(); c.fill();
      c.strokeStyle = P["line-strong"]; c.beginPath(); res.forEach(function (p, j) { if (j) c.lineTo(sx(p.s), sz(p.h)); else c.moveTo(sx(p.s), sz(p.h)); }); c.stroke();
      c.strokeStyle = P["ink-3"]; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(sx(0), sz(0)); c.lineTo(sx(0.3), sz(0)); c.stroke();
      c.strokeStyle = P["ink-2"]; c.beginPath(); c.moveTo(sx(0), sz(-DEPTH)); c.lineTo(sx(0.3), sz(-DEPTH)); c.stroke(); c.setLineDash([]);
      c.font = "500 11px " + monoFont(); c.fillStyle = P["ink-3"];
      c.fillText("planned board", sx(0) + 4, sz(0) - 6); c.fillText("target, 12 mm below", sx(0.2), sz(-DEPTH) + 14);
      res.forEach(function (p) { c.fillStyle = col(p.k); c.beginPath(); c.arc(sx(p.s), sz(p.z), 2.6, 0, Math.PI * 2); c.fill(); });
      var f0 = 196, f1 = H - 26, fmax = 80, sf = function (F) { return f1 - Math.min(F, fmax) / fmax * (f1 - f0); };
      c.fillStyle = P["good-soft"]; c.fillRect(L, sf(BAND[1]), R - L, sf(BAND[0]) - sf(BAND[1]));
      c.strokeStyle = P.line; c.beginPath(); c.moveTo(L, f1); c.lineTo(R, f1); c.stroke();
      c.fillStyle = P["ink-3"]; c.textAlign = "right"; [0, 40, 80].forEach(function (F) { c.fillText(String(F), L - 6, sf(F) + 4); }); c.textAlign = "left";
      c.fillText("normal force (N)", L + 6, f0 - 6); c.textAlign = "center"; c.fillText("stroke position, 0 to 300 mm", (L + R) / 2, H - 6); c.textAlign = "left";
      c.lineWidth = 2; for (var j = 1; j < res.length; j++) { c.strokeStyle = col(res[j].k); c.beginPath(); c.moveTo(sx(res[j - 1].s), sf(res[j - 1].F)); c.lineTo(sx(res[j].s), sf(res[j].F)); c.stroke(); } c.lineWidth = 1;
    }
    function preset(v) { S.p = v; S.kn = PRESETS[v][0]; S.kt = PRESETS[v][1]; setSlider(body, id + "-kn", S.kn, kfmt); setSlider(body, id + "-kt", S.kt, kfmt); run(); }
    function custom() { S.p = "custom"; body.querySelectorAll("#" + id + "-p button").forEach(function (b) { b.setAttribute("aria-pressed", "false"); }); run(); }
    bindSeg(body, id + "-p", preset);
    RB.bindSlider(body, id + "-kn", kfmt, function (v) { S.kn = v; custom(); });
    RB.bindSlider(body, id + "-kt", kfmt, function (v) { S.kt = v; custom(); });
    RB.bindSlider(body, id + "-a", mfmt, function (v) { S.A = v / 1000; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { p: S.p, kn: S.kn, kt: S.kt, A: S.A }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token colors only) ---------- */
  var spring = function (x0, x1, y, n) { var d = "M" + x0 + " " + y, w = (x1 - x0) / (n * 2); for (var i = 0; i < n * 2; i++) d += " L" + (x0 + w * (i + 0.5)).toFixed(1) + " " + (y + (i % 2 ? 6 : -6)) + (i === n * 2 - 1 ? " L" + x1 + " " + y : ""); return '<path d="' + d + '" class="rb-s-acc"/>'; };
  var ART = {
    dyn: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="70" y="14" width="44" height="26" rx="3" class="rb-f-soft"/><text x="92" y="31" text-anchor="middle" class="rb-t-acc">M(q)</text><path d="M92 40 V52" class="rb-s-ink"/><text x="100" y="54" class="rb-t-mono">G</text><path d="M40 27 H68" class="rb-s-ink"/><text x="14" y="31" class="rb-t-mono">𝛕</text><path d="M116 27 H150" class="rb-s-line"/><text x="154" y="31" class="rb-t-mono">Jᵀλ</text></svg>',
    pd: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="140" y="6" width="56" height="44" class="rb-f-sunk"/><circle cx="176" cy="28" r="4" class="rb-f-surface"/><path d="M20 28 H128" class="rb-s-ink" stroke-width="4"/><rect x="128" y="20" width="12" height="16" rx="2" class="rb-f-acc"/><text x="20" y="16" class="rb-t-mono">rigid rod</text><text x="20" y="50" class="rb-t-mono">large force</text></svg>',
    imp: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="140" y="6" width="56" height="44" class="rb-f-sunk"/><circle cx="180" cy="28" r="4" class="rb-f-surface"/><rect x="128" y="20" width="12" height="16" rx="2" class="rb-f-acc"/>' + spring(140, 176, 28, 4) + '<path d="M20 28 H126" class="rb-s-line"/><text x="20" y="16" class="rb-t-mono">spring K_d</text><text x="20" y="50" class="rb-t-mono">small force</text></svg>',
    adm: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="14" width="40" height="22" rx="3" class="rb-f-sunk"/><text x="28" y="29" text-anchor="middle" class="rb-t-mono">F/T</text><path d="M50 25 H68" class="rb-s-ink"/><rect x="70" y="12" width="82" height="26" rx="3" class="rb-f-soft"/><text x="111" y="29" text-anchor="middle" class="rb-t-mono">M_d,B_d,K_d</text><path d="M154 25 H168" class="rb-s-ink"/><text x="171" y="29" class="rb-t-mono">x_c</text><text x="100" y="52" text-anchor="middle" class="rb-t-mono">force in, motion out</text></svg>',
    hyb: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="20" y="42" width="160" height="10" class="rb-f-sunk"/><rect x="84" y="24" width="22" height="16" rx="2" class="rb-f-acc"/><path d="M110 32 H176" class="rb-s-ink"/><text x="118" y="24" class="rb-t-mono">position</text><path d="M95 4 V22" class="rb-s-acc"/><text x="36" y="16" class="rb-t-mono">force</text></svg>',
    mpc: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="40" y="8" width="120" height="36" rx="4" class="rb-f-sunk"/><path d="M14 40 Q60 34 90 24 T186 14" class="rb-s-line"/>' + [0, 1, 2, 3, 4].map(function (i) { return '<circle cx="' + (50 + i * 26) + '" cy="' + [35, 30, 25, 21, 18][i] + '" r="3.5" class="' + (i === 0 ? "rb-f-acc" : "rb-f-surface") + '"/>'; }).join("") + '<text x="100" y="54" text-anchor="middle" class="rb-t-mono">plan ahead, apply first</text></svg>',
    wbc: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="16" y="6" width="70" height="12" rx="2" class="rb-f-acc"/><rect x="16" y="22" width="70" height="12" rx="2" class="rb-f-soft"/><rect x="16" y="38" width="70" height="12" rx="2" class="rb-f-surface"/><text x="92" y="16" class="rb-t-mono">1 balance</text><text x="92" y="32" class="rb-t-mono">2 hand pose</text><text x="92" y="48" class="rb-t-mono">3 posture</text></svg>',
    learn: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="12" y="16" width="50" height="24" rx="4" class="rb-f-soft"/><text x="37" y="32" text-anchor="middle" class="rb-t-acc">π_θ</text><path d="M64 22 L110 10 M64 28 H110 M64 34 L110 46" class="rb-s-ink"/><text x="114" y="14" class="rb-t-mono">x_des</text><text x="114" y="32" class="rb-t-mono">K (stiffness)</text><text x="114" y="50" class="rb-t-mono">F_ref</text></svg>'
  };

  /* ---------- worked example figure: series springs, then the Jacobian ---------- */
  /* 1-D scale: 8 px per mm from the surface at x = 300. Numbers: K_d = 500, k_e = 5000, Δ = 20 mm → F = 9.09 N, hand at 1.82 mm. */
  var PX = function (mm) { return (300 + mm * 8).toFixed(1); };
  var WE_FIG = '<svg viewBox="0 0 560 230" role="img" aria-label="A hand pressed into a soft surface by a virtual spring toward a target 20 millimeters inside it, and a two-link arm that turns the force into joint torques">' +
    '<rect x="300" y="36" width="230" height="56" class="rb-f-sunk"/><text x="306" y="30" class="rb-t-mono">surface, k_e = 5000 N/m</text>' +
    '<line x1="40" y1="64" x2="300" y2="64" class="rb-s-line"/>' +
    '<g data-on="1+"><circle cx="' + PX(20) + '" cy="64" r="6" class="rb-f-surface"/><text x="' + PX(20) + '" y="110" text-anchor="middle" class="rb-t-ink">target, 20 mm inside</text></g>' +
    '<g data-on="2+">' + '<path d="M' + PX(1.82) + ' 64 ' + (function () { var d = "", x0 = +PX(1.82) + 6, x1 = +PX(20) - 6, n = 10, w = (x1 - x0) / n; for (var i = 0; i < n; i++) d += "L" + (x0 + w * (i + 0.5)).toFixed(1) + " " + (i % 2 ? 72 : 56) + " "; return d + "L" + x1.toFixed(1) + ' 64"'; })() + ' class="rb-s-acc"/><text x="' + PX(11) + '" y="50" text-anchor="middle" class="rb-t-acc">K_d = 500 N/m</text></g>' +
    '<g data-on="2+"><rect x="' + (+PX(1.82) - 14) + '" y="54" width="14" height="20" rx="2" class="rb-f-acc"/><path d="M' + (+PX(1.82) - 20) + ' 44 H 206" class="rb-s-acc"/><path d="M206 39 L196 44 L206 49 Z" class="rb-f-acc"/><text x="120" y="48" class="rb-t-acc">λ = 9.1 N</text></g>' +
    '<g data-on="3+"><text x="' + PX(1.82) + '" y="128" text-anchor="middle" class="rb-t-mono">hand 1.8 mm in, 18.2 mm short</text></g>' +
    '<g data-on="4+"><text x="60" y="92" class="rb-t-ink">stiff PD, K_P = 40 000 N/m: 88.9 N</text></g>' +
    '<g data-on="5+"><circle cx="60" cy="160" r="6" class="rb-f-surface"/><path d="M60 160 H180 V214" class="rb-s-ink" stroke-width="3"/><circle cx="180" cy="160" r="5" class="rb-f-surface"/><rect x="150" y="214" width="120" height="8" class="rb-f-sunk"/>' +
    '<text x="46" y="148" class="rb-t-mono">joint 1</text><text x="190" y="156" class="rb-t-mono">joint 2</text><text x="200" y="196" class="rb-t-acc">torques to press: (−2.73, 0) N·m</text></g>' +
    '<g data-on="6"><text x="300" y="160" class="rb-t-ink">want 15 N → K_d = 882 N/m</text></g></svg>';

  RB.topic({
    id: "a2",
    title: "The control layer under the policy",
    eyebrow: "Part A · Foundations",
    lede: "A learned policy rarely drives the motors. It sends targets to a fast controller, and that controller decides how hard the robot pushes.",
    refs: ["P10 §5.1–5.3", "P09 §V–VI", "P11 eq. 1–3"],
    why: "Two robots with the same policy can press a surface with 9 N or 90 N, depending on the controller underneath. Contact-rich skills such as wiping, insertion and peeling depend on that layer. Learned policies increasingly choose its settings, stiffness or a reference force, instead of only positions.",
    outcomes: [
      "Write the manipulator dynamics and name each term.",
      "Compare PD, impedance, admittance and hybrid force/position control.",
      "Compute a steady contact force from stiffness and penetration.",
      "Explain why MPC trades model fidelity against solve rate.",
      "Contrast hierarchical and weighted quadratic programs for whole-body control."
    ],
    concepts: [
      { name: "Manipulator dynamics", def: "Mass matrix, Coriolis and gravity terms relate joint torques and contact forces to joint accelerations.", ref: "P10 eq. 21 · P09 eq. 5", art: ART.dyn, term: "rigid-body-dynamics", sym: "M" },
      { name: "PD position control", def: "Track a target with proportional and derivative gains; accurate and common, but compliance is hard to adjust.", ref: "P10 §5.1.2", art: ART.pd, term: "pd-control" },
      { name: "Impedance control", def: "Command torques so the hand behaves like a spring and damper around the target; no force sensor needed.", ref: "P10 §5.1.3", art: ART.imp, term: "impedance-control", sym: "Kd", href: "#lab/compliance", hrefLabel: "Try it in the Compliance station →" },
      { name: "Admittance control", def: "Measure the contact force, turn it into a compliant motion target, and track that with a position loop.", ref: "P10 §5.1.4", art: ART.adm, term: "admittance-control" },
      { name: "Hybrid force/position", def: "A selection matrix splits directions: regulate force along some, position along the others.", ref: "P10 eq. 28", art: ART.hyb, term: "hybrid-force-position-control" },
      { name: "MPC and model fidelity", def: "Optimize over a short horizon, apply the first input, repeat; simpler models solve faster but are less accurate.", ref: "P09 §V, Table IV", art: ART.mpc, term: "model-predictive-control" },
      { name: "Whole-body control", def: "Solve one quadratic program per time step for torques, contact forces and accelerations under task priorities.", ref: "P09 §VI", art: ART.wbc, term: "whole-body-control" },
      { name: "Policies that set gains", def: "Learned policies now output stiffness or a reference force alongside the target pose.", ref: "P10 Fig. 6, Table 5", art: ART.learn, term: "variable-impedance" }
    ],
    flow: {
      title: "Where the controller sits between policy and motors", ref: "P10 Fig. 6 · P09 §V–VI", w: 900, h: 300,
      caption: "Two loops run at once: a slow one through the camera and the policy, and a fast one through the joint and force sensors. The fast loop decides the contact force.",
      nodes: [
        { id: "cam", x: 20, y: 40, w: 150, h: 56, label: "Camera oₜ", sub: "images, joints", kind: "env" },
        { id: "pol", x: 260, y: 40, w: 150, h: 56, label: "Policy π_θ", sub: "SERL: 10 Hz", kind: "agent" },
        { id: "mpc", x: 540, y: 40, w: 150, h: 56, label: "MPC planner", sub: "humanoids: 5–300 Hz", kind: "decision" },
        { id: "sens", x: 240, y: 190, w: 150, h: 60, label: "Joint, F/T sensors", sub: "q, q̇, F_ext", kind: "store" },
        { id: "ctrl", x: 540, y: 190, w: 150, h: 60, label: "Controller", sub: "impedance, 1 kHz", kind: "agent" },
        { id: "robot", x: 760, y: 190, w: 130, h: 60, label: "Robot, contact", sub: "M q̈ + … = 𝛕 + Jᵀλ", kind: "env" }
      ],
      edges: [
        { from: "cam", to: "pol", label: "pixels" },
        { from: "pol", to: "mpc", label: "goals" },
        { from: "mpc", to: "ctrl", label: "reference", dx: 38 },
        { from: "pol", to: "ctrl", label: "x_des, K, F_ref", dashed: true, sides: ["b", "t"], via: [[335, 145], [580, 145]] },
        { from: "ctrl", to: "robot", label: "torques" },
        { from: "robot", to: "sens", label: "state, force", sides: ["b", "b"], via: [[825, 284], [315, 284]] },
        { from: "sens", to: "ctrl", label: "1 kHz feedback" },
        { from: "robot", to: "cam", label: "new image", sides: ["t", "t"], via: [[825, 14], [95, 14]], dashed: true }
      ],
      steps: [
        { on: ["cam", "cam>pol", "pol"], text: "The policy reads images at a low rate. P10 Fig. 6 lists what it can send down: a primary action, a stiffness K and a reference force." },
        { on: ["pol>mpc", "mpc"], text: "On humanoids an MPC planner often sits in between. It plans over a horizon with a simplified model, at 5 to 300 Hz in P09 Table III." },
        { on: ["pol>ctrl", "mpc>ctrl", "ctrl"], text: "The controller turns targets into joint torques every millisecond: PD, impedance, admittance or hybrid on arms, whole-body control on humanoids." },
        { on: ["ctrl>robot", "robot"], text: "Torques move the robot. Where it touches the world, contact forces push back through the Jacobian transpose." },
        { on: ["robot>sens", "sens", "sens>ctrl"], text: "Encoders and a force/torque sensor close the fast loop. This loop, not the policy, sets how hard the robot presses between two policy calls." },
        { on: ["robot>cam", "cam"], text: "A new image arrives and the slow loop repeats. SERL runs its policy at 10 Hz over a 1 kHz impedance controller." }
      ]
    },
    worked: {
      title: "How hard does an impedance-controlled hand press?",
      ref: "P10 eq. 22–23", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-lambda}{\\lambda} = \\frac{\\class{sym-Kd}{K_d}\\, k_e}{\\class{sym-Kd}{K_d} + k_e}\\, \\Delta", words: "At rest, the controller's spring and the surface's spring act in series; the force is their combined stiffness times the overlap.", key: ["lambda", "Kd", { glyph: "k_e", meaning: "surface stiffness" }, { glyph: "Δ", meaning: "target depth inside the surface" }] },
      figure: WE_FIG,
      steps: [
        { title: "The setup", text: "A policy asks for a point 20 mm inside a sponge-like surface of stiffness 5000 N/m. The impedance controller uses K_d = 500 N/m." },
        { title: "Springs in series", text: "Combined stiffness 500·5000 / 5500 = 454.5 N/m. Times 0.020 m gives a steady contact force of 9.1 N." },
        { title: "Where the hand stops", text: "The surface gives 9.1 / 5000 = 1.8 mm. The hand rests 18.2 mm short of the target; that gap is the compliance." },
        { title: "Stiff PD instead", text: "A position loop with K_P = 40 000 N/m gives 40 000·5000 / 45 000 · 0.020 = 88.9 N: ten times the force." },
        { title: "Force to joint torques", text: "Two links of 0.3 m at q = (0°, −90°): Jᵀ times (0, −9.1) N gives torques (−2.73, 0) N·m." },
        { title: "Let the policy choose", text: "For 15 N, the series stiffness must be 750 N/m, so K_d = 882 N/m. ACP-style policies output exactly such a stiffness." }
      ]
    },
    ruleTitle: "Dynamics and the four control laws",
    rules: [
      { name: "Manipulator dynamics with contact", ref: "P10 eq. 21, 23 · P09 eq. 5 · P11 eq. 3", term: "rigid-body-dynamics",
        tex: "\\class{sym-M}{M(q)}\\,\\class{sym-qj}{\\ddot q} + \\class{sym-C}{C(q,\\dot q)}\\,\\class{sym-qj}{\\dot q} + \\class{sym-G}{G(q)} = \\class{sym-torque}{\\boldsymbol{\\tau}} + \\class{sym-Jac}{J(q)}^{\\top} \\class{sym-lambda}{\\lambda}",
        words: "Inertia times acceleration, plus Coriolis and gravity terms, equals motor torque plus the contact force mapped into joint space.",
        key: ["M", "qj", "C", "G", "torque", "Jac", "lambda"] },
      { name: "From joint PD to Cartesian impedance", ref: "P10 eq. 24–26", term: "impedance-control",
        before: "\\class{sym-torque}{\\boldsymbol{\\tau}} = \\class{sym-kp-gain}{K_P}(\\class{sym-qj}{q}_{\\mathrm{des}} - \\class{sym-qj}{q}) + \\class{sym-kv-gain}{K_V}(\\class{sym-qj}{\\dot q}_{\\mathrm{des}} - \\class{sym-qj}{\\dot q})",
        tex: "\\class{sym-torque}{\\boldsymbol{\\tau}} = \\class{sb-new}{\\class{sym-Jac}{J(q)}^{\\top}}\\big(\\class{sb-chg}{\\class{sym-Kd}{K_d}\\,\\class{sym-err}{e} + \\class{sym-Bd}{B_d}\\,\\class{sym-err}{\\dot e}}\\big) + \\class{sb-new}{\\class{sym-C}{C(q,\\dot q)}\\class{sym-qj}{\\dot q} + \\class{sym-G}{G(q)}}",
        words: "Impedance puts a spring on the hand error e = x_des − x, maps it to torques with Jᵀ, and cancels Coriolis and gravity with the model.",
        key: ["torque", "kp-gain", "qj", "kv-gain", "Jac", "Kd", "err", "Bd", "C", "G"], diff: true, beforeLabel: "Joint PD", afterLabel: "Impedance" },
      { name: "Admittance: force in, motion target out", ref: "P10 eq. 22, 27",
        tex: "\\class{sym-Md}{M_d}\\,\\ddot{\\class{sym-x}{x}}_c + \\class{sym-Bd}{B_d}(\\dot{\\class{sym-x}{x}}_c - \\dot{\\class{sym-x}{x}}_{\\mathrm{des}}) + \\class{sym-Kd}{K_d}(\\class{sym-x}{x}_c - \\class{sym-x}{x}_{\\mathrm{des}}) = \\class{sym-Fext}{F_{\\mathrm{ext}}}",
        words: "Integrate a virtual mass-spring-damper driven by the measured force; a stiff position loop then tracks its output x_c.",
        key: ["Md", "x", "Bd", "Kd", "Fext", { glyph: "x_c", meaning: "compliant target sent to position loop" }] },
      { name: "Hybrid force/position control", ref: "P10 eq. 28", term: "hybrid-force-position-control",
        tex: "\\class{sym-u-ctrl}{u} = \\mathcal{F}\\big(\\class{sym-Ssel}{S_F}\\, e_F\\big) + \\mathcal{P}\\big((I - \\class{sym-Ssel}{S_F})\\, \\class{sym-err}{e}\\big)",
        words: "A diagonal 0/1 selection matrix sends force errors to a force controller and position errors, in the other directions, to a position controller.",
        key: ["u-ctrl", "Ssel", { glyph: "e_F", meaning: "force error" }, "err", { glyph: "𝓕, 𝓟", meaning: "force and position controllers" }] },
      { name: "MPC as an optimal control problem", ref: "P09 eq. 1–4", term: "model-predictive-control",
        tex: "\\min_{\\class{sym-s}{s}(\\cdot),\\,\\class{sym-u-ctrl}{u}(\\cdot),\\,\\class{sym-lambda}{\\lambda}(\\cdot)} \\class{sym-L}{\\mathcal{L}} \\quad \\text{s.t.}\\ \\ \\dot{\\class{sym-s}{s}}_k = \\class{sym-f}{f}(\\class{sym-s}{s}_k, \\class{sym-u-ctrl}{u}_k, \\class{sym-lambda}{\\lambda}_k),\\ \\ h_{\\text{task}} = 0,\\ \\ g_{\\text{task}} \\ge 0",
        words: "Choose states, inputs and contact forces over a horizon that minimize a cost, obey a dynamics model and satisfy task constraints.",
        key: ["s", "u-ctrl", "lambda", { sym: "L", meaning: "cost over the horizon" }, { sym: "f", meaning: "dynamics model (SRBM … whole body)" }, { glyph: "h, g", meaning: "equality and inequality tasks" }] }
    ],
    algorithm: {
      title: "One second of a policy on an impedance controller", ref: "SERL, arXiv 2401.16013 · P10 eq. 25", prov: "Our summary",
      lines: [
        '<span class="kw">every</span> 100 ms <span class="cm">// policy at 10 Hz</span>',
        '    <span data-sym="x">x_des</span> ← <span data-sym="pi">π_θ</span>(<span data-sym="o">oₜ</span>) <span class="cm">// ACP also outputs <span data-sym="Kd">K_d</span></span>',
        '    clip <span data-sym="x">x_des</span> to a box around <span data-sym="x">x</span> <span class="cm">// SERL: reference clipping</span>',
        '    <span class="kw">repeat</span> 100 times, <span class="kw">every</span> 1 ms: <span class="cm">// controller at 1 kHz</span>',
        '        read <span data-sym="qj">q</span>, <span data-sym="qj">q̇</span>; <span data-sym="x">x</span> ← forward kinematics(<span data-sym="qj">q</span>)',
        '        <span data-sym="torque">𝛕</span> ← <span data-sym="Jac">J</span>ᵀ(<span data-sym="Kd">K_d</span>(<span data-sym="x">x_des</span> − <span data-sym="x">x</span>) − <span data-sym="Bd">B_d</span> <span data-sym="x">ẋ</span>) + <span data-sym="C">C</span><span data-sym="qj">q̇</span> + <span data-sym="G">G</span>',
        '        send <span data-sym="torque">𝛕</span> to the motors'
      ]
    },
    playgrounds: [
      {
        id: "wall", title: "Push a hand into a surface", ref: "P10 §5.1.2–5.1.4", prov: "Simplified: 1-D hand, 1 kHz loop, our numbers",
        try: "Start on PD position with the medium surface and read the peak force. Switch to Impedance, then set friction to 0. Then try Admittance on the soft and the stiff surface.",
        mount: mountWall,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a2-wall";
          return [
            { target: q("#" + id + "-c"), title: "Stiff position control", text: "PD tracks the target within 0.3 mm, so it tries to reach 20 mm inside the surface. Read the final force: hundreds of newtons." },
            { target: q("#" + id + "-c"), title: "Make the hand a spring", text: "Impedance control with K_d = 500 N/m stops with about 10 N. No force sensor is used.", do: function (a) { return a.click(q("#" + id + '-c [value="imp"]')); }, task: "Choose Impedance", expect: function () { return api.state().c === "imp"; } },
            { target: q(".sb-readouts"), title: "The price: model errors", text: "Before contact the hand lags about 20 mm: 10 N of friction divided by 500 N/m. The controller never measures that friction." },
            { target: q("#" + id + "-f"), title: "Remove the friction", text: "With a perfect model the lag nearly vanishes. Real arms have friction and payloads, which is why P10 §5.1.3 calls impedance less precise.", do: function (a) { return a.set(q("#" + id + "-f"), 0); }, task: "Set friction to 0 N", expect: function () { return api.state().f === 0; } },
            { target: q("#" + id + "-c"), title: "Measure the force instead", text: "Admittance reads the force sensor and moves a virtual spring target. A stiff inner loop tracks it, so friction no longer matters.", do: function (a) { return a.set(q("#" + id + "-f"), 10).then(function () { return a.click(q("#" + id + '-c [value="adm"]')); }); }, task: "Choose Admittance", expect: function () { return api.state().c === "adm"; } },
            { target: q("#" + id + "-env"), title: "Your turn", text: "Switch between Soft and Stiff surfaces. In this toy admittance settles on soft surfaces but chatters on stiff ones; impedance stays calm." }
          ];
        }
      },
      {
        id: "wipe", title: "Which stiffness should the policy send?", ref: "ACP, arXiv 2410.09309 · P10 Table 5", prov: "Simplified: quasi-static wipe, our numbers",
        try: "The policy thinks the board is flat, but it has a bump. Compare the three presets, then drag the normal and tangent stiffness yourself to find a setting that wipes the whole stroke.",
        mount: mountWipe,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a2-wipe";
          return [
            { target: q("canvas"), title: "Position-only targets", text: "Stiff tracking turns the unseen 20 mm bump into a force spike far above the green band. In ACP's test a stiff policy broke the tool." },
            { target: q("#" + id + "-p"), title: "Soft everywhere", text: "Uniform 500 N/m keeps the force gentle, but friction drags the tool behind the stroke by more than 5 mm.", do: function (a) { return a.click(q("#" + id + '-p [value="soft"]')); }, task: "Choose Soft", expect: function () { return api.state().p === "soft"; } },
            { target: q("#" + id + "-p"), title: "Soft only along the force", text: "ACP's rule: low stiffness along the measured force, high stiffness elsewhere. Force stays in the band and the tool keeps pace.", do: function (a) { return a.click(q("#" + id + '-p [value="dir"]')); }, task: "Choose Directional", expect: function () { return api.state().p === "dir"; } },
            { target: q("#" + id + "-a"), title: "A bigger surprise", text: "Raise the bump to 30 mm. Directional stiffness absorbs it; the stiff preset would press even harder.", do: function (a) { return a.set(q("#" + id + "-a"), 30); }, task: "Set the bump to 30 mm", expect: function () { return api.state().A >= 0.029; } },
            { target: q("#" + id + "-kn"), title: "Your turn", text: "Drag k_n and k_t yourself. Which one controls the force, and which one controls the lag? Then compare with the Compliance station." }
          ];
        }
      }
    ],
    methodsLede: "This framework topic has no method papers of its own. These learned policies from later topics send their commands to the controllers above. Rows marked Fact card are hidden until you show all.",
    methods: ["residual-rl", "serl", "hil-serl", "adaptive-compliance-policy", "reactive-diffusion-policy", "dipcom-comp-act", "admitdiff", "forge", "context-aware-delan"],
    open: [
      { title: "Gains are still hand-tuned", text: "Badly chosen compliant gains still cause large contact forces and overshoot, so controllers must be tested and tuned, not treated as a callable interface.", refs: "P10 §5.3" },
      { title: "Choosing force directions", text: "Hybrid control needs orthogonal force and position directions, which are hard to specify in unstructured scenes.", refs: "P10 §5.1.5" },
      { title: "Interaction models for MPC", text: "How to model moving environments, humans and deformable objects inside MPC is largely unexplored; they are often treated as disturbances.", refs: "P09 §V" },
      { title: "Local, deterministic optimizers", text: "MPC and WBC solvers find local optima and ignore uncertainty in state estimates and future contacts, which limits real-world robustness.", refs: "P09 §VI-E" }
    ],
    takeaways: [
      "A policy sends targets; the controller underneath, running near 1 kHz, decides the torques and therefore the contact force.",
      "PD position control tracks precisely but presses hard; impedance trades accuracy for compliance without a force sensor.",
      "Admittance measures force and tracks a compliant target with a stiff position loop; hybrid control splits directions with a selection matrix.",
      "MPC trades model fidelity against solve rate; WBC solves an instantaneous QP with strict (hierarchical) or weighted priorities.",
      "Learned policies moved from positions only (SERL) to predicting stiffness (Comp-ACT, ACP) or reference force (AdmitDiff)."
    ],
    quiz: [
      { q: "An impedance-controlled hand with K_d = 1000 N/m targets 10 mm inside a rigid wall. What is the steady contact force?", options: ["About 1 N", "About 10 N", "About 100 N", "It depends only on the wall"], correct: 1, why: "For a rigid wall the series stiffness is K_d, so λ = 1000 N/m × 0.010 m = 10 N." },
      { q: "Why is admittance control often chosen when precise positioning matters?", options: ["It needs no sensors", "Its inner loop is stiff position control", "It ignores contact forces", "It uses a larger mass matrix"], correct: 1, why: "Admittance turns the measured force into a motion target tracked by position control, so friction and payload errors are rejected (P10 §5.1.4)." },
      { q: "What does the selection matrix S do in hybrid force/position control?", options: ["Selects the controller gains", "Chooses which directions are force-controlled", "Selects the policy's action chunk", "Picks the contact point"], correct: 1, why: "S is a diagonal 0/1 matrix marking force-controlled directions; I − S marks the orthogonal position-controlled ones (P10 eq. 28)." },
      { q: "How does a weighted QP differ from a hierarchical QP in whole-body control?", options: ["It solves several QPs in sequence", "It uses soft weights, so low-priority tasks can interfere", "It cannot handle inequality constraints", "It runs only offline"], correct: 1, why: "A weighted QP solves one problem with task weights: faster, but priorities are not strict. A hierarchical QP solves a cascade in null spaces (P09 §VI-C)." },
      { q: "In ACP's vase-wiping test, what happened to the stiff position-only policy?", options: ["It succeeded in every trial", "It broke the tool", "It matched ACP at 93.75%", "It never touched the vase"], correct: 1, why: "ACP reports 93.75% success, the uniform 500 N/m policy 43.75%, and the stiff policy broke the tool (arXiv 2410.09309)." }
    ],
    cards: [
      { front: "Write the manipulator dynamics with a contact force.", back: "M(q)q̈ + C(q, q̇)q̇ + G(q) = 𝛕 + J(q)ᵀλ.", ref: "P10 eq. 21 · P09 eq. 5" },
      { front: "Impedance versus admittance: which needs a force sensor?", back: "Admittance: it measures the external force and turns it into motion. Impedance commands torques from position error and needs none.", ref: "P10 §5.1.3–5.1.4" },
      { front: "Inner and outer loops of impedance and admittance control?", back: "Impedance: inner torque loop, outer position loop. Admittance: inner position loop, outer force loop.", ref: "P10 §5.1.3–5.1.4" },
      { front: "Which control mode is most common among P10's surveyed force-aware policies?", back: "Position control (13 papers); impedance is the most common compliant mode (10 papers), mostly on Franka arms.", ref: "P10 §5.2–5.3" },
      { front: "What distinguishes WBC from MPC?", back: "MPC solves a receding-horizon problem with a model of choice; WBC solves an instantaneous problem, usually with full-order dynamics.", ref: "P09 §VI" },
      { front: "How fast do SERL's policy and controller run?", back: "Policy at 10 Hz, impedance controller at 1 kHz with reference clipping.", ref: "arXiv 2401.16013" },
      { front: "What does ACP's policy output besides a pose?", back: "A virtual target pose and a stiffness, low along the measured force and high elsewhere, executed by admittance control.", ref: "arXiv 2410.09309" }
    ],
    terms: {
      "rigid-body-dynamics": { name: "manipulator dynamics", aliases: ["rigid-body dynamics", "equations of motion", "inverse dynamics model"], group: "contact", sym: "M(q)q̈ + … = 𝛕", symTex: "M(q)\\ddot q + C\\dot q + G = \\boldsymbol{\\tau} + J^\\top\\lambda", def: "The equation relating joint torques and external forces to joint motion through the inertia matrix, Coriolis and centrifugal terms and gravity.", note: "P10 calls it the inverse dynamics model; P11 derives it from the Lagrangian T − V.", ref: "P10 eq. 21 · P11 eq. 3", scene: "robot", focus: ["arm", "joint"], look: "the arm's links and joints", uses: [] },
      "jacobian-transpose": { name: "Jacobian transpose", aliases: ["Jᵀ", "force mapping"], group: "contact", sym: "J(q)ᵀ", symTex: "J(q)^\\top", def: "The transpose of the manipulator Jacobian maps a wrench at the end effector to the joint torques that produce or balance it.", note: "The Jacobian maps joint velocities to hand velocity; its transpose maps hand forces back to joints.", ref: "P10 eq. 23", scene: "robot", focus: ["end-effector", "joint"], look: "force at the hand, torque at joints", uses: ["rigid-body-dynamics"] },
      "pd-control": { name: "PD position control", aliases: ["PD control", "PID control", "position control"], group: "contact", def: "A controller that drives position error and velocity error to zero with proportional and derivative gains; the most common low-level controller.", note: "High gains track well but make the robot rigid, so contact forces can grow large.", ref: "P10 §5.1.2", scene: "system", focus: ["controller"], look: "the controller block", uses: [] },
      "impedance-control": { name: "impedance control", aliases: ["Cartesian impedance", "compliance control"], group: "contact", sym: "K_d, B_d, M_d", symTex: "K_d, B_d, M_d", def: "Control that enforces a desired dynamic relation between motion and external force, making the end effector behave like a mass-spring-damper; its output is joint torque.", note: "No force sensor is needed, but model errors such as friction and payload become position errors.", ref: "P10 §5.1.3", scene: "robot", focus: ["end-effector", "contact-point"], look: "the hand yielding at contact", uses: ["rigid-body-dynamics", "jacobian-transpose"] },
      "admittance-control": { name: "admittance control", aliases: [], group: "contact", def: "Control whose input is the force on the end effector and whose output is a desired motion, tracked by an inner position loop.", note: "The mirror of impedance: it needs a force/torque sensor, and compliance is limited to the sensor's location.", ref: "P10 §5.1.4", scene: "robot", focus: ["ft-sensor", "end-effector"], look: "the wrist force/torque sensor", uses: ["impedance-control"] },
      "hybrid-force-position-control": { name: "hybrid force/position control", aliases: ["hybrid F/P", "hybrid control"], group: "contact", def: "Control that regulates force along selected directions and position along the orthogonal ones, split by a selection matrix.", note: "Natural for wiping or cutting, where the pressing direction is obvious; hard when it is not.", ref: "P10 §5.1.5", scene: "robot", focus: ["contact-point", "table"], look: "press down, slide along", uses: ["selection-matrix"] },
      "selection-matrix": { name: "selection matrix", aliases: ["S matrix"], group: "contact", sym: "S_F", symTex: "S_F", def: "A diagonal matrix of zeros and ones marking the force-controlled directions; its complement I − S marks the position-controlled ones.", note: "Not the WBC actuation selection matrix S of P09 eq. 5, which picks actuated joints.", ref: "P10 eq. 28", scene: "robot", focus: ["contact-point"], look: "force and motion directions", uses: [] },
      "variable-impedance": { name: "variable impedance", aliases: ["learned stiffness", "adaptive compliance"], group: "contact", def: "Changing stiffness and damping over time or direction; learned policies output them alongside the target pose.", note: "ACP predicts a stiffness scalar per step; Comp-ACT and DIPCOM predict a 6-D diagonal stiffness.", ref: "P10 §5.1.3 · arXiv 2410.09309", scene: "system", focus: ["action-head", "controller"], look: "policy output feeding the controller", uses: ["impedance-control"] },
      "model-predictive-control": { name: "model predictive control", aliases: ["MPC", "receding-horizon control"], group: "contact", def: "Solving an optimal control problem over a finite future horizon with a dynamics model and constraints, applying the first input, and re-solving at the next step.", note: "The model is the main design choice: simplified models are fast, whole-body models are accurate but slow.", ref: "P09 §V, eq. 1–4", scene: "system", focus: ["planner"], look: "the planner above the controller", uses: ["reduced-order-model"] },
      "reduced-order-model": { name: "reduced-order model", aliases: ["simplified model", "SRBM", "LIPM", "centroidal dynamics"], group: "contact", def: "A simplified dynamics model such as a single rigid body, a linear inverted pendulum or centroidal dynamics, used for fast online planning.", note: "Mixed-fidelity MPC uses full models near in the horizon and simple ones far away.", ref: "P09 §V-A, V-C", scene: "robot", focus: ["base", "arm"], look: "the whole body as one mass", uses: [] },
      "whole-body-control": { name: "whole-body control", aliases: ["WBC"], group: "contact", def: "Controllers that compute joint torques, contact forces and accelerations for a set of tasks at the current time step, usually from full-order dynamics.", note: "Unlike MPC it looks at one instant; MPC plans, WBC executes.", ref: "P09 §VI, eq. 5–6", scene: "system", focus: ["controller", "robot"], look: "the torque-level controller", uses: ["rigid-body-dynamics"] },
      "hierarchical-qp": { name: "hierarchical QP", aliases: ["HQP", "strict task hierarchy", "stack of tasks"], group: "contact", def: "Whole-body control as a cascade of quadratic programs; each lower-priority task is solved in the null space of all higher ones.", note: "Priorities are strict, but several QPs cost time and memory.", ref: "P09 §VI-C", scene: "system", focus: ["controller"], look: "tasks stacked by priority", uses: ["whole-body-control"] },
      "weighted-qp": { name: "weighted QP", aliases: ["WQP", "soft task weighting"], group: "contact", def: "Whole-body control as one quadratic program whose cost sums the tasks with weights that express priority.", note: "Faster than a hierarchical QP, but low-priority tasks can interfere with high-priority ones, and tuning many weights is hard.", ref: "P09 §VI-C", scene: "system", focus: ["controller"], look: "tasks mixed by weights", uses: ["whole-body-control", "hierarchical-qp"] }
    },
    symbols: [
      { id: "kp-gain", tex: "K_P", glyph: "K_P", kind: "Parameters", meaning: "proportional gain of a PD position controller", short: "proportional gain", first: "a2", read: "K P", papers: "P10 eq. 24: K_p" },
      { id: "kv-gain", tex: "K_V", glyph: "K_V", kind: "Parameters", meaning: "derivative (velocity) gain of a PD position controller", short: "derivative gain", first: "a2", read: "K V", papers: "P10 eq. 24: K_d (house K_d is stiffness)" },
      { id: "u-ctrl", tex: "u", glyph: "u", kind: "Signals", meaning: "control input sent to the actuators (often a torque command)", short: "control input", first: "a2", read: "u", papers: "P09 eq. 1–2: u · P10 eq. 24, 28: u" },
      { id: "err", tex: "e", glyph: "e", kind: "Signals", meaning: "pose error x_des − x of the end effector", short: "pose error", first: "a2", read: "e", papers: "P10 eq. 26: e" },
      { id: "Ssel", tex: "S_F", glyph: "S_F", kind: "Parameters", meaning: "selection matrix of force-controlled directions (diagonal, 0 or 1)", short: "force selection matrix", first: "a2", read: "S F", papers: "P10 eq. 28: S₂ (S₁ = I − S₂)" }
    ],
    ledger: [
      { where: "Topic 02 · PD rule", source: "P10 eq. 24 writes PD gains as K_p and K_d, while eq. 22 uses K_d for stiffness", page: "The site writes PD gains K_P and K_V and keeps K_d for stiffness", why: "One symbol, one meaning.", kind: "Our choice" },
      { where: "Topic 02 · impedance rule", source: "P10 eq. 25 writes the full law with desired inertia M_d and a minus sign before Jᵀ(M_d ë + B_d ė + K_d e)", page: "The site shows the common form without inertia shaping: 𝛕 = Jᵀ(K_d e + B_d ė) + C q̇ + G", why: "This is the form torque-controlled arms such as the Franka expose; it shows the spring directly.", kind: "Simplified" },
      { where: "Topic 02 · admittance rule", source: "P10 eq. 27 writes ẍ_des = ẍ + M_d⁻¹(F_ext − B_d ė − K_d e)", page: "The site writes the equivalent virtual mass-spring-damper whose output x_c goes to the position loop", why: "Easier to see what is integrated and what is tracked.", kind: "Our choice" },
      { where: "Topic 02 · dynamics rule", source: "P10 eq. 21 writes an external torque τ_ext; P09 eq. 5 writes Sᵀτ and Jᵀλ for a floating base; P11 eq. 3 writes c(q, q̇) and g(q)", page: "The site writes a fixed-base arm: M q̈ + C q̇ + G = 𝛕 + Jᵀλ", why: "Manipulation focus; P10 eq. 23 gives τ_ext = Jᵀ F_ext.", kind: "Our choice" },
      { where: "Topic 02 · playground 1", source: "P10 §5.1 describes the controllers qualitatively", page: "A 1-D, 2 kg hand with Coulomb friction, a 1 kHz loop and a 2 ms force filter; admittance chatter on stiff surfaces is a property of this toy", why: "Shows the trade-offs P10 names (friction hurts impedance; admittance needs a sensor) with numbers you can change.", kind: "Simplified" },
      { where: "Topic 02 · playground 2", source: "ACP's stiffness rule K = S K₀ S⁻¹ rotates with the measured force and lowers k_low as force grows", page: "The toy fixes the normal along z and uses constant presets; the 500 N/m baseline follows ACP's ablation", why: "A quasi-static wipe isolates the effect of the stiffness choice.", kind: "Simplified" }
    ]
  });
})();
