/* Topic 20 · Physics priors. Sources: P11 §1–4, §7–8, eq. 1–11, Fig. 1, 3, Tables 2, 7; method cards (topic E6). */
(function () {
  "use strict";
  var RB = window.RB;

  /* ---------- shared numerics ---------- */
  /* least squares with a small ridge: rows = feature vectors, ys = targets, w = optional row weights */
  function lsq(rows, ys, ridge, w) {
    var n = rows[0].length, A = [], b = [], i, j, k;
    for (i = 0; i < n; i++) { A.push(new Array(n).fill(0)); b.push(0); }
    rows.forEach(function (r, m) { var wm = w ? w[m] : 1; for (i = 0; i < n; i++) { b[i] += wm * r[i] * ys[m]; for (j = 0; j < n; j++) A[i][j] += wm * r[i] * r[j]; } });
    for (i = 0; i < n; i++) A[i][i] += ridge;
    for (i = 0; i < n; i++) { /* Gaussian elimination with partial pivoting */
      var p = i; for (k = i + 1; k < n; k++) if (Math.abs(A[k][i]) > Math.abs(A[p][i])) p = k;
      var t = A[i]; A[i] = A[p]; A[p] = t; var tb = b[i]; b[i] = b[p]; b[p] = tb;
      for (k = i + 1; k < n; k++) { var f = A[k][i] / A[i][i]; for (j = i; j < n; j++) A[k][j] -= f * A[i][j]; b[k] -= f * b[i]; }
    }
    var x = new Array(n).fill(0);
    for (i = n - 1; i >= 0; i--) { var s = b[i]; for (j = i + 1; j < n; j++) s -= A[i][j] * x[j]; x[i] = s / A[i][i]; }
    return x;
  }
  function dot(a, b) { var s = 0; for (var i = 0; i < a.length; i++) s += a[i] * b[i]; return s; }
  function mono() { return getComputedStyle(document.body).getPropertyValue("--font-mono"); }
  function body() { return getComputedStyle(document.body).getPropertyValue("--font-body"); }
  /* segmented control: StudyBench.segmented passes (value, button); read the button's value directly */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function pct(v) { if (!isFinite(v)) return "–"; if (Math.abs(v) > 999) return (v > 0 ? "> +999%" : "< −999%"); return (v >= 0 ? "+" : "−") + Math.abs(v).toFixed(1) + "%"; }

  /* ---------- playground 1: black-box versus energy-structured model of a pendulum ---------- */
  /* Real system: q̈ = −(g/l) sin q − b q̇ with g/l = 9.81 s⁻², b = 0 (ideal) or 0.4 s⁻¹ (friction).
     Each model is fit by least squares on fixed features (a stand-in for a trained network). */
  var W2 = 9.81, QBOX = 2.2, TEND = 10, DT = 0.01;
  function realAcc(q, v, fr) { return -W2 * Math.sin(q) - (fr ? 0.4 : 0) * v; }
  function energy(q, v) { return 0.5 * v * v + W2 * (1 - Math.cos(q)); }
  function featBB(q, v, vmax) {
    var f = [1, q, v], sq = 2 * QBOX / 5, sv = 2 * vmax / 5;
    for (var i = 0; i < 6; i++) for (var j = 0; j < 6; j++) {
      var cq = -QBOX + i * sq, cv = -vmax + j * sv, dq = (q - cq) / sq, dv = (v - cv) / sv;
      f.push(Math.exp(-0.5 * (dq * dq + dv * dv)));
    }
    return f;
  }
  function featQ(q) { return [1, Math.sin(q), Math.cos(q), Math.sin(2 * q), Math.cos(2 * q), Math.sin(3 * q), Math.cos(3 * q)]; }
  function fitModel(kind, data, vmax) {
    var ys = data.map(function (d) { return d.a; });
    if (kind === "bb") { var wb = lsq(data.map(function (d) { return featBB(d.q, d.v, vmax); }), ys, 1e-3); return function (q, v) { return dot(wb, featBB(q, v, vmax)); }; }
    if (kind === "energy") { var we = lsq(data.map(function (d) { return featQ(d.q); }), ys, 1e-6); return function (q) { return dot(we, featQ(q)); }; }
    /* dissipative: energy features plus −d·q̇ with d ≥ 0 (a one-parameter port-Hamiltonian damping term) */
    var wd = lsq(data.map(function (d) { return featQ(d.q).concat([-d.v]); }), ys, 1e-6);
    if (wd[7] < 0) { var w0 = lsq(data.map(function (d) { return featQ(d.q); }), ys, 1e-6); wd = w0.concat([0]); }
    return function (q, v) { return dot(wd.slice(0, 7), featQ(q)) - wd[7] * v; };
  }
  function rollout(acc, q0) {
    var q = q0, v = 0, out = [[0, q, v]], dead = false;
    for (var k = 1; k <= TEND / DT; k++) {
      if (!dead) {
        var k1q = v, k1v = acc(q, v), k2q = v + 0.5 * DT * k1v, k2v = acc(q + 0.5 * DT * k1q, k2q), k3q = v + 0.5 * DT * k2v, k3v = acc(q + 0.5 * DT * k2q, k3q), k4q = v + DT * k3v, k4v = acc(q + DT * k3q, k4q);
        var nq = q + DT / 6 * (k1q + 2 * k2q + 2 * k3q + k4q), nv = v + DT / 6 * (k1v + 2 * k2v + 2 * k3v + k4v);
        if (!isFinite(nq) || !isFinite(nv) || Math.abs(nv) > 40) dead = true; else { q = nq; v = nv; }
      }
      if (k % 5 === 0) out.push([k * DT, q, v]);
    }
    return out;
  }

  function mountPendulum(bodyEl, ctx) {
    var id = ctx.id;
    bodyEl.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-model", label: "Learned model", value: "energy", options: [{ value: "bb", label: "Black-box" }, { value: "energy", label: "Energy" }, { value: "diss", label: "Dissipative" }] }) +
      RB.seg({ id: id + "-sys", label: "Real system", value: "ideal", options: [{ value: "ideal", label: "Ideal" }, { value: "fric", label: "Friction" }] }) +
      RB.slider({ id: id + "-vmax", label: "Data speed limit (rad/s)", min: 1, max: 8, step: 0.5, value: 3 }) +
      RB.slider({ id: id + "-q0", label: "Start angle (rad)", min: 0.3, max: 2.8, step: 0.1, value: 2.4, fmt: function (v) { return (+v).toFixed(1); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New data ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Phase plot of angle against angular velocity with the training-data box, the real orbit and the model rollout"></canvas><figcaption class="sb-caption">Shaded box = where training data exist. Dashed = the real pendulum. Colored = the learned model released from the same angle. Watch whether it stays on the dashed orbit.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "fit", k: "Fit error on data", u: "rad/s²" }, { id: "eReal", k: "Real energy change, 10 s" }, { id: "eMod", k: "Model energy change, 10 s" }, { id: "err", k: "Angle error, RMS over 10 s", u: "rad" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-3", label: "real pendulum", kind: "dash" }, { c: "data-1", label: "learned model", kind: "line" }, { c: "accent", label: "training-data box", kind: "area" }]) + "</div></div>" +
      '<div id="' + id + '-chart"></div>';
    var cv = bodyEl.querySelector("#" + id + "-cv"), chartHost = bodyEl.querySelector("#" + id + "-chart"), note = bodyEl.querySelector("[data-note]");
    var st = { model: "energy", sys: "ideal", vmax: 3, q0: 2.4, seed: 5 }, last = null, W = 520, H = 340;
    var NOTES = {
      bb: "The black-box regressor fits the data box well but knows nothing outside it. Once the orbit leaves the box, energy is neither kept nor lost the way physics says.",
      energy: "The energy model predicts acceleration from the angle alone, so it conserves a learned energy by construction, as DeLaN and HNN do. It extrapolates to speeds it never saw.",
      diss: "The dissipative model adds one learned damping term d ≥ 0, the port-Hamiltonian idea. It can now lose energy, but never create it."
    };
    function run() {
      var R = RB.rng(st.seed), data = [], fr = st.sys === "fric";
      for (var i = 0; i < 150; i++) { var q = -QBOX + 2 * QBOX * R(), v = -st.vmax + 2 * st.vmax * R(); data.push({ q: q, v: v, a: realAcc(q, v, fr) + 0.3 * R.normal() }); }
      var acc = fitModel(st.model, data, st.vmax), se = 0;
      data.forEach(function (d) { var e = acc(d.q, d.v) - d.a; se += e * e; });
      var real = rollout(function (q, v) { return realAcc(q, v, fr); }, st.q0), mod = rollout(acc, st.q0);
      var e0 = energy(st.q0, 0), eR = energy(real[real.length - 1][1], real[real.length - 1][2]), eM = energy(mod[mod.length - 1][1], mod[mod.length - 1][2]);
      var err = 0; real.forEach(function (r, k) { var d = mod[k][1] - r[1]; err += d * d; });
      last = { data: data, real: real, mod: mod };
      RB.setRO(bodyEl, "fit", RB.fmt(Math.sqrt(se / data.length), 2));
      RB.setRO(bodyEl, "eReal", pct(100 * (eR - e0) / e0));
      RB.setRO(bodyEl, "eMod", pct(100 * (eM - e0) / e0));
      RB.setRO(bodyEl, "err", RB.fmt(Math.sqrt(err / real.length), 2));
      note.textContent = NOTES[st.model];
      draw(); chart();
    }
    function chart() {
      if (!last) return;
      chartHost.innerHTML = "";
      var pts = function (tr) { return tr.filter(function (r, k) { return k % 4 === 0; }).map(function (r) { return [+r[0].toFixed(1), Math.min(80, energy(r[1], r[2]))]; }); };
      var e0 = energy(st.q0, 0);
      StudyBench.lineChart(chartHost, { title: "Energy over time", height: 200, x: { label: "time (s)", min: 0, max: TEND }, y: { label: "energy per unit ml² (J/kg·m²)", min: 0, max: Math.max(5, Math.ceil(e0 * 1.8 / 5) * 5), fmt: function (v) { return (+v).toFixed(1); } },
        series: [{ name: "Real", color: "data-3", dash: true, points: pts(last.real) }, { name: "Model", color: "data-1", points: pts(last.mod) }],
        caption: "The real ideal pendulum keeps its energy flat; with friction it decays. A model that drifts up or down here will mispredict every later state." });
    }
    function draw() {
      if (!last) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), VM = 9;
      var X = function (q) { return 30 + (q + Math.PI) / (2 * Math.PI) * (W - 50); }, Y = function (v) { return H / 2 - v / VM * (H / 2 - 24); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      [-3, -2, -1, 0, 1, 2, 3].forEach(function (q) { c.beginPath(); c.moveTo(X(q), 14); c.lineTo(X(q), H - 20); c.stroke(); });
      [-8, -4, 0, 4, 8].forEach(function (v) { c.beginPath(); c.moveTo(24, Y(v)); c.lineTo(W - 14, Y(v)); c.stroke(); });
      c.fillStyle = P["accent-soft"]; c.strokeStyle = P.accent; c.fillRect(X(-QBOX), Y(st.vmax), X(QBOX) - X(-QBOX), Y(-st.vmax) - Y(st.vmax)); c.strokeRect(X(-QBOX), Y(st.vmax), X(QBOX) - X(-QBOX), Y(-st.vmax) - Y(st.vmax));
      c.fillStyle = P["ink-3"]; last.data.forEach(function (d) { c.fillRect(X(d.q) - 1, Y(d.v) - 1, 2, 2); });
      function path(tr, col, dash) {
        c.strokeStyle = col; c.lineWidth = 2; c.setLineDash(dash ? [5, 4] : []); c.beginPath();
        var prev = null;
        tr.forEach(function (r) { var q = Math.atan2(Math.sin(r[1]), Math.cos(r[1])); if (prev === null || Math.abs(q - prev) > 3) c.moveTo(X(q), Y(Math.max(-VM, Math.min(VM, r[2])))); else c.lineTo(X(q), Y(Math.max(-VM, Math.min(VM, r[2])))); prev = q; });
        c.stroke(); c.setLineDash([]);
      }
      path(last.mod, P["data-1"], false);
      path(last.real, P["data-3"], true);
      c.fillStyle = P.ink; c.beginPath(); c.arc(X(st.q0), Y(0), 5, 0, 2 * Math.PI); c.fill();
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono();
      c.fillText("angle q (rad)", X(0.8), H - 6); c.fillText("velocity (rad/s)", 30, 11);
      c.fillText("−π", X(-Math.PI) - 4, H - 6); c.fillText("0", X(0) - 3, H - 6); c.fillText("π", X(Math.PI) - 12, H - 6);
      c.font = "600 12px " + body(); c.fillText("release", X(st.q0) - 50, Y(0) - 8);
    }
    bindSeg(bodyEl, id + "-model", function (v) { st.model = v; run(); });
    bindSeg(bodyEl, id + "-sys", function (v) { st.sys = v; run(); });
    RB.bindSlider(bodyEl, id + "-vmax", null, function (v) { st.vmax = v; run(); });
    RB.bindSlider(bodyEl, id + "-q0", function (v) { return (+v).toFixed(1); }, function (v) { st.q0 = v; run(); });
    bodyEl.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed++; run(); });
    RB.onTheme(function () { draw(); chart(); });
    run();
    return { state: function () { return { model: st.model, sys: st.sys, vmax: st.vmax, q0: st.q0 }; } };
  }

  /* ---------- playground 2: the integrator (Euler = ResNet step, RK4 = NODE solver, Verlet = VIN) ---------- */
  function stepE(q, p, h) { return [q + h * p, p - h * Math.sin(q)]; }
  function stepRK(q, p, h) {
    var f = function (a, b) { return [b, -Math.sin(a)]; };
    var k1 = f(q, p), k2 = f(q + h / 2 * k1[0], p + h / 2 * k1[1]), k3 = f(q + h / 2 * k2[0], p + h / 2 * k2[1]), k4 = f(q + h * k3[0], p + h * k3[1]);
    return [q + h / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]), p + h / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])];
  }
  function stepV(q, p, h) { var a = -Math.sin(q), qn = q + h * p + 0.5 * h * h * a; return [qn, p + 0.5 * h * (a - Math.sin(qn))]; }
  function E1(q, p) { return 0.5 * p * p + 1 - Math.cos(q); }
  function simInt(step, q0, h, T) {
    var q = q0, p = 0, out = [[0, q, p]], n = Math.round(T / h);
    for (var k = 1; k <= n; k++) { var s = step(q, p, h); if (!isFinite(s[0]) || Math.abs(s[1]) > 30) break; q = s[0]; p = s[1]; out.push([k * h, q, p]); }
    return out;
  }
  function mountIntegrators(bodyEl, ctx) {
    var id = ctx.id;
    bodyEl.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-h", label: "Step size h", min: 0.02, max: 0.6, step: 0.02, value: 0.1, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-q0", label: "Start angle (rad)", min: 0.2, max: 3, step: 0.1, value: 1, fmt: function (v) { return (+v).toFixed(1); } }) + "</div>" +
      '<div class="rb-grid2"><div id="' + id + '-chart"></div><div class="rb-stack">' + RB.readouts([{ id: "e", k: "Euler (ResNet step)" }, { id: "rk", k: "RK4 (NODE solver)" }, { id: "v", k: "Verlet (VIN layer)" }]) +
      '<p class="sb-caption">Energy drift over 200 time units on the exact pendulum q̈ = −sin q: mean of the last tenth minus the first. Same vector field; only the step rule differs.</p></div></div>';
    var host = bodyEl.querySelector("#" + id + "-chart"), st = { h: 0.1, q0: 1 }, T = 200, res = null;
    function run() {
      res = { e: simInt(stepE, st.q0, st.h, T), rk: simInt(stepRK, st.q0, st.h, T), v: simInt(stepV, st.q0, st.h, T) };
      var e0 = E1(st.q0, 0);
      /* drift = mean energy over the last tenth of the run minus the first tenth, so bounded oscillation reads as zero */
      ["e", "rk", "v"].forEach(function (k) {
        var tr = res[k], n = Math.max(1, Math.floor(tr.length / 10)), a = 0, b = 0, i;
        for (i = 0; i < n; i++) { a += E1(tr[i][1], tr[i][2]); b += E1(tr[tr.length - 1 - i][1], tr[tr.length - 1 - i][2]); }
        RB.setRO(bodyEl, k, tr.length < Math.round(T / st.h) + 1 ? "> +999%" : pct(100 * (b - a) / n / e0));
      });
      chart();
    }
    function chart() {
      if (!res) return;
      host.innerHTML = "";
      var e0 = E1(st.q0, 0), every = function (tr) { var n = Math.max(1, Math.round(tr.length / 80)); return tr.filter(function (r, k) { return k % n === 0; }).map(function (r) { return [+r[0].toFixed(1), Math.max(0.8, Math.min(1.4, E1(r[1], r[2]) / e0))]; }); };
      StudyBench.lineChart(host, { title: "Energy under three step rules", height: 220, x: { label: "time", min: 0, max: T }, y: { label: "E / E₀", min: 0.8, max: 1.4, fmt: function (v) { return (+v).toFixed(2); } },
        series: [{ name: "Euler", color: "data-2", points: every(res.e) }, { name: "RK4", color: "data-3", points: every(res.rk) }, { name: "Verlet", color: "data-1", points: every(res.v) }],
        caption: "A flat line at 1 is right: an ideal pendulum keeps its energy. Look for which rule climbs off the top, which sinks slowly, and which only wobbles." });
    }
    RB.bindSlider(bodyEl, id + "-h", function (v) { return (+v).toFixed(2); }, function (v) { st.h = v; run(); });
    RB.bindSlider(bodyEl, id + "-q0", function (v) { return (+v).toFixed(1); }, function (v) { st.q0 = v; run(); });
    RB.onTheme(chart);
    run();
    return { state: function () { return { h: st.h, q0: st.q0 }; } };
  }

  /* ---------- playground 3: a physics-informed loss with a wrong prior (PI-TCN form L = L_MSE + λ L_PI) ---------- */
  /* True torque of one arm link: τ(q) = 5.886 sin q + 0.15 q³ (m = 1.5 kg, l = 0.4 m, plus a cable spring that stiffens with angle; our toy numbers).
     Nominal model: m_nom g l sin q, with m_nom off by the slider. Data only for |q| ≤ 0.6 rad. */
  var MGL = 5.886, KS = 0.15, LAMS = [0, 0.001, 0.01, 0.1, 0.3, 1, 3, 10, 100];
  function tauTrue(q) { return MGL * Math.sin(q) + KS * q * q * q; }
  function cheb(q) { var x = q / Math.PI, T = [1, x]; for (var k = 2; k < 8; k++) T.push(2 * x * T[k - 1] - T[k - 2]); return T; }
  function mountLoss(bodyEl, ctx) {
    var id = ctx.id;
    bodyEl.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-lam", label: "Physics weight λ", min: 0, max: 8, step: 1, value: 3, fmt: function (i) { return String(LAMS[i]); } }) +
      RB.slider({ id: id + "-err", label: "Prior mass error", min: -40, max: 40, step: 5, value: 20, fmt: function (v) { return (v > 0 ? "+" : "") + v + "%"; } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New data ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Gravity torque against joint angle: data points, true curve, nominal prior and learned fit"></canvas><figcaption class="sb-caption">Dots = measurements, only near q = 0. Dashed = truth; dotted = the nominal prior. Watch the colored fit outside the dots as you move λ.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "in", k: "Error inside data range", u: "N·m" }, { id: "out", k: "Error outside data range", u: "N·m" }, { id: "gap", k: "Gap to the prior", u: "N·m" }]) +
      RB.legend([{ c: "data-3", label: "true torque", kind: "dash" }, { c: "data-4", label: "nominal prior", kind: "dash" }, { c: "data-1", label: "learned fit", kind: "line" }]) +
      '<p class="sb-caption">RMS errors. The prior misses the cable spring and has a wrong mass, so trusting it fully leaves a bias that data cannot remove.</p></div></div>';
    var cv = bodyEl.querySelector("#" + id + "-cv"), st = { li: 3, err: 20, seed: 11 }, W = 520, H = 320, last = null;
    function run() {
      var R = RB.rng(st.seed), lam = LAMS[st.li], mn = 1 + st.err / 100, nom = function (q) { return mn * MGL * Math.sin(q); };
      var rows = [], ys = [], w = [], data = [], Nu = 10, Nf = 41, i;
      for (i = 0; i < Nu; i++) { var q = -0.6 + 1.2 * i / (Nu - 1), y = tauTrue(q) + 0.1 * R.normal(); data.push([q, y]); rows.push(cheb(q)); ys.push(y); w.push(1 / Nu); }
      for (i = 0; i < Nf; i++) { var qc = -Math.PI + 2 * Math.PI * i / (Nf - 1); rows.push(cheb(qc)); ys.push(nom(qc)); w.push(lam / Nf); }
      var th = lsq(rows, ys, 1e-7, w), fit = function (q) { return dot(th, cheb(q)); };
      var ein = 0, nin = 0, eout = 0, nout = 0, gap = 0;
      for (i = 0; i <= 200; i++) { var qq = -Math.PI + 2 * Math.PI * i / 200, d = fit(qq) - tauTrue(qq); if (Math.abs(qq) <= 0.6) { ein += d * d; nin++; } else { eout += d * d; nout++; } var g = fit(qq) - nom(qq); gap += g * g; }
      RB.setRO(bodyEl, "in", RB.fmt(Math.sqrt(ein / nin), 2)); RB.setRO(bodyEl, "out", RB.fmt(Math.sqrt(eout / nout), 2)); RB.setRO(bodyEl, "gap", RB.fmt(Math.sqrt(gap / 201), 2));
      last = { data: data, fit: fit, nom: nom }; draw();
    }
    function draw() {
      if (!last) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), YM = 14;
      var X = function (q) { return 34 + (q + Math.PI) / (2 * Math.PI) * (W - 50); }, Y = function (v) { return H / 2 - v / YM * (H / 2 - 22); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.fillStyle = P["accent-soft"]; c.fillRect(X(-0.6), 12, X(0.6) - X(-0.6), H - 34);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      [-10, -5, 0, 5, 10].forEach(function (v) { c.beginPath(); c.moveTo(28, Y(v)); c.lineTo(W - 12, Y(v)); c.stroke(); });
      function curve(f, col, dash, lw) { c.strokeStyle = col; c.lineWidth = lw; c.setLineDash(dash); c.beginPath(); for (var i = 0; i <= 200; i++) { var q = -Math.PI + 2 * Math.PI * i / 200, v = Math.max(-YM * 1.2, Math.min(YM * 1.2, f(q))); if (i) c.lineTo(X(q), Y(v)); else c.moveTo(X(q), Y(v)); } c.stroke(); c.setLineDash([]); }
      c.save(); c.beginPath(); c.rect(28, 10, W - 38, H - 30); c.clip();
      curve(last.nom, P["data-4"], [2, 3], 2); curve(tauTrue, P["data-3"], [6, 4], 2); curve(last.fit, P["data-1"], [], 2.5);
      c.restore();
      c.fillStyle = P.ink; last.data.forEach(function (d) { c.beginPath(); c.arc(X(d[0]), Y(d[1]), 3.5, 0, 2 * Math.PI); c.fill(); });
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono();
      c.fillText("joint angle q (rad)", X(0.8), H - 4); c.fillText("gravity torque (N·m)", 34, 10);
      c.fillText("−π", X(-Math.PI) - 2, H - 4); c.fillText("π", X(Math.PI) - 10, H - 4);
      [-10, 0, 10].forEach(function (v) { c.fillText(String(v), 4, Y(v) + 4); });
    }
    RB.bindSlider(bodyEl, id + "-lam", function (i) { return String(LAMS[i]); }, function (v) { st.li = v; run(); });
    RB.bindSlider(bodyEl, id + "-err", function (v) { return (v > 0 ? "+" : "") + v + "%"; }, function (v) { st.err = v; run(); });
    bodyEl.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { lam: LAMS[st.li], li: st.li, err: st.err }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token classes only) ---------- */
  var ART = {
    routes: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="4" y="14" width="54" height="26" rx="4" class="rb-f-sunk"/><text x="31" y="31" text-anchor="middle" class="rb-t-mono">inputs</text><path d="M60 27 H72" class="rb-s-ink"/><rect x="74" y="14" width="54" height="26" rx="4" class="rb-f-soft"/><text x="101" y="31" text-anchor="middle" class="rb-t-mono">model</text><path d="M130 27 H142" class="rb-s-ink"/><rect x="144" y="14" width="52" height="26" rx="4" class="rb-f-surface"/><text x="170" y="31" text-anchor="middle" class="rb-t-mono">loss</text><text x="31" y="52" text-anchor="middle" class="rb-t-mono">guided</text><text x="101" y="52" text-anchor="middle" class="rb-t-mono">encoded</text><text x="170" y="52" text-anchor="middle" class="rb-t-mono">informed</text></svg>',
    chol: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="8" width="40" height="40" class="rb-f-surface"/><path d="M8 8 L48 48 L8 48 Z" class="rb-f-soft"/><text x="20" y="42" class="rb-t-acc">L</text><text x="62" y="33" class="rb-t-ink">×</text><rect x="76" y="8" width="40" height="40" class="rb-f-surface"/><path d="M76 8 L116 8 L116 48 Z" class="rb-f-soft"/><text x="100" y="24" class="rb-t-acc">Lᵀ</text><text x="128" y="33" class="rb-t-ink">=</text><rect x="140" y="8" width="56" height="40" class="rb-f-soft"/><text x="168" y="33" text-anchor="middle" class="rb-t-acc">M ≻ 0</text></svg>',
    ham: '<svg viewBox="0 0 200 56" aria-hidden="true"><ellipse cx="46" cy="28" rx="40" ry="20" class="rb-s-line"/><ellipse cx="46" cy="28" rx="26" ry="11" class="rb-s-acc"/><path d="M71 22 l3 6 l-7 1" class="rb-s-acc"/><text x="46" y="32" text-anchor="middle" class="rb-t-mono">ℋ = c</text><text x="98" y="24" class="rb-t-mono">level sets of</text><text x="98" y="38" class="rb-t-mono">learned energy</text></svg>',
    lnn: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="12" width="84" height="30" rx="4" class="rb-f-sunk"/><text x="48" y="31" text-anchor="middle" class="rb-t-mono">½q̇ᵀMq̇ − U</text><text x="48" y="54" text-anchor="middle" class="rb-t-mono">DeLaN form</text><path d="M94 27 H108" class="rb-s-ink"/><rect x="112" y="12" width="82" height="30" rx="4" class="rb-f-soft"/><text x="153" y="31" text-anchor="middle" class="rb-t-mono">any ℒ(q, q̇)</text><text x="153" y="54" text-anchor="middle" class="rb-t-mono">LNN</text></svg>',
    ports: '<svg viewBox="0 0 200 56" aria-hidden="true"><text x="4" y="20" class="rb-t-mono">control u</text><path d="M6 28 H56" class="rb-s-ink"/><path d="M50 23 L56 28 L50 33" class="rb-s-ink"/><rect x="60" y="12" width="58" height="32" rx="4" class="rb-f-soft"/><text x="89" y="32" text-anchor="middle" class="rb-t-acc">ℋ</text><path d="M122 28 H182" class="rb-s-acc" stroke-dasharray="4 3"/><text x="128" y="20" class="rb-t-mono">losses</text><text x="128" y="44" class="rb-t-mono">friction</text></svg>',
    integ: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="50" cy="28" r="18" class="rb-s-line"/><path d="M50 10 C78 10 80 44 50 48 C18 50 14 8 54 6 C92 4 94 52 48 54" class="rb-s-ink"/><text x="50" y="32" text-anchor="middle" class="rb-t-mono">Euler</text><circle cx="148" cy="28" r="18" class="rb-s-line"/><circle cx="148" cy="28" r="17" class="rb-s-acc" stroke-dasharray="3 5"/><text x="148" y="32" text-anchor="middle" class="rb-t-mono">VIN</text></svg>',
    resid: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 48 Q70 -4 140 30" class="rb-s-line"/><path d="M10 48 Q70 0 150 44" class="rb-s-acc"/><circle cx="150" cy="44" r="4" class="rb-f-acc"/><path d="M142 32 L150 42" class="rb-s-ink" stroke-dasharray="2 2"/><text x="118" y="12" class="rb-t-mono">model</text><text x="160" y="30" class="rb-t-mono">+ δ</text><text x="60" y="54" class="rb-t-mono">learned residual δ</text></svg>',
    loss: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="14" width="70" height="26" rx="4" class="rb-f-surface"/><text x="45" y="31" text-anchor="middle" class="rb-t-mono">data fit</text><text x="92" y="32" class="rb-t-ink">+</text><rect x="106" y="14" width="84" height="26" rx="4" class="rb-f-soft"/><text x="148" y="31" text-anchor="middle" class="rb-t-mono">λ · residual</text><text x="148" y="52" text-anchor="middle" class="rb-t-mono">training only</text></svg>'
  };

  /* ---------- worked-example figure: phase plane, Euler versus velocity Verlet, h = 0.5 (numbers from the same formulas) ---------- */
  var WE = (function () {
    var X = function (q) { return (240 + q * 170).toFixed(1); }, Y = function (p) { return (112 - p * 72).toFixed(1); };
    var E0 = 1 - Math.cos(1), orb = [], i, q;
    for (i = 0; i <= 60; i++) { q = -1 + 2 * i / 60; orb.push([q, Math.sqrt(Math.max(0, 2 * (E0 - 1 + Math.cos(q))))]); }
    var top = orb.map(function (o) { return X(o[0]) + " " + Y(o[1]); }), bot = orb.slice().reverse().map(function (o) { return X(o[0]) + " " + Y(-o[1]); });
    var e = [[1, 0]], v = [[1, 0]];
    for (i = 0; i < 3; i++) { e.push(stepE(e[i][0], e[i][1], 0.5)); v.push(stepV(v[i][0], v[i][1], 0.5)); }
    var dotE = function (k) { return '<circle cx="' + X(e[k][0]) + '" cy="' + Y(e[k][1]) + '" r="5" style="fill:var(--data-2)"/>'; };
    var dotV = function (k) { return '<circle cx="' + X(v[k][0]) + '" cy="' + Y(v[k][1]) + '" r="5" style="fill:var(--data-1)"/>'; };
    return '<svg viewBox="0 0 600 230" role="img" aria-label="Phase plane of angle against momentum. The true orbit is a closed loop; Euler steps move outside it, Verlet steps stay on it">' +
      '<line x1="30" y1="112" x2="560" y2="112" class="rb-s-line"/><line x1="240" y1="14" x2="240" y2="226" class="rb-s-line"/>' +
      '<text x="570" y="116" class="rb-t-mono">q</text><text x="246" y="24" class="rb-t-mono">p</text>' +
      '<path d="M' + top.join(" L") + " L" + bot.join(" L") + ' Z" class="rb-s-ink" stroke-dasharray="5 4"/>' +
      '<g data-on="1+"><circle cx="' + X(1) + '" cy="' + Y(0) + '" r="6" class="rb-f-surface"/><text x="' + (+X(1) + 12) + '" y="106" class="rb-t-ink">start</text><text x="20" y="30" class="rb-t-mono">dashed: true orbit, E = 0.460</text></g>' +
      '<g data-on="2+">' + dotE(1) + '<text x="' + (+X(1) + 12) + '" y="' + (+Y(e[1][1]) + 4) + '" class="rb-t-mono">Euler 1: E = 0.548</text></g>' +
      '<g data-on="3+">' + dotV(1) + '<text x="' + (+X(v[1][0]) - 12) + '" y="' + (+Y(v[1][1]) - 3) + '" text-anchor="end" class="rb-t-mono">Verlet 1: E = 0.457</text></g>' +
      '<g data-on="4+">' + dotE(2) + dotE(3) + '<path d="M' + X(e[1][0]) + " " + Y(e[1][1]) + " L" + X(e[2][0]) + " " + Y(e[2][1]) + " L" + X(e[3][0]) + " " + Y(e[3][1]) + '" style="stroke:var(--data-2);fill:none;stroke-width:1.5"/><text x="' + X(e[3][0]) + '" y="' + (+Y(e[3][1]) + 20) + '" text-anchor="middle" class="rb-t-mono">Euler 3: E = 0.783</text></g>' +
      '<g data-on="5">' + dotV(2) + dotV(3) + '<text x="230" y="204" text-anchor="end" class="rb-t-mono">Verlet 3: E = 0.434</text></g></svg>';
  })();

  RB.topic({
    id: "e6",
    title: "Physics priors in learned models",
    eyebrow: "Part E · Physics priors",
    lede: "Robots obey mechanics. Building those laws into a model's inputs, architecture or loss lets it learn from less data and extrapolate further.",
    refs: ["P11 §2, Fig. 1–3", "P11 §3.1–3.5", "P11 §3.9, Table 7", "P11 §4.1"],
    why: "Robot data are expensive, and a black-box dynamics model fit on them can violate energy conservation or produce an invalid mass matrix. Physics priors add the structure that mechanics guarantees, such as a positive-definite inertia or a conserved energy. The price is expressiveness: a prior that omits friction or contact becomes a bias that more data cannot remove.",
    outcomes: [
      "Classify a method as physics-guided, physics-encoded or physics-informed.",
      "Explain how DeLaN guarantees a valid mass matrix.",
      "Compare DeLaN, HNN, LNN and port-Hamiltonian models by what they assume.",
      "Compute one Euler step and one Verlet step and their energy error.",
      "Predict when a physics prior helps and when it biases the model."
    ],
    concepts: [
      { name: "Three routes", def: "Physics can enter through the inputs and data, the architecture, or the loss; each acts at different stages.", ref: "P11 §2, Fig. 1", art: ART.routes, term: "physics-embedded-learning" },
      { name: "Cholesky mass matrix", def: "Deep Lagrangian networks (DeLaN, 2019) learn a triangular L(q) with positive diagonal, so M = LLᵀ is valid.", ref: "P11 eq. 4", art: ART.chol, term: "deep-lagrangian-network", sym: "M" },
      { name: "Learned energy", def: "Hamiltonian neural networks (HNN, 2019) learn one energy ℋ(q, p); motion is its symplectic gradient, conserving ℋ.", ref: "P11 eq. 6–7", art: ART.ham, term: "hamiltonian-neural-network", sym: "Ham" },
      { name: "Free-form Lagrangian", def: "Lagrangian neural networks (LNN, 2020) learn any Lagrangian of q and q̇, dropping DeLaN's quadratic kinetic energy.", ref: "P11 §3.1.2", art: ART.lnn, term: "lagrangian-neural-network", sym: "Lag" },
      { name: "Energy ports", def: "Port-Hamiltonian models (2024) add learned dissipation and input matrices, so friction and control enter explicitly.", ref: "P11 §3.2.2", art: ART.ports, term: "port-hamiltonian-model" },
      { name: "Structure-preserving steps", def: "A ResNet block is an Euler step of a neural ODE (NODE). Variational integrator networks (VINs) take energy-bounded symplectic steps.", ref: "P11 eq. 8, §3.4", art: ART.integ, term: "variational-integrator-network", href: "#lab/physics", hrefLabel: "Open the physics station →" },
      { name: "Residual on a model", def: "Keep the analytic model and learn only what it misses, as TossingBot does for release velocity.", ref: "P11 §3.5.2", art: ART.resid, term: "residual-dynamics-learning" },
      { name: "Physics in the loss", def: "Add the governing equation's residual to the data loss. It shapes training but binds nothing at run time.", ref: "P11 eq. 11", art: ART.loss, term: "physics-informed-loss", sym: "L" }
    ],
    flow: {
      title: "Where each route acts in the lifecycle", ref: "P11 Fig. 1, 3", w: 820, h: 300,
      caption: "Follow the three routes from data to control. Guided and encoded priors survive to run time; an informed loss acts only while training.",
      nodes: [
        { id: "data", x: 10, y: 40, w: 140, h: 56, label: "Robot data", sub: "q, q̇, q̈, 𝛕", kind: "store" },
        { id: "guided", x: 220, y: 40, w: 150, h: 56, label: "Physics features", sub: "physics-guided", kind: "agent" },
        { id: "model", x: 440, y: 40, w: 150, h: 56, label: "Structured model", sub: "physics-encoded", kind: "agent" },
        { id: "loss", x: 440, y: 180, w: 150, h: 56, label: "Physics loss", sub: "physics-informed", kind: "decision" },
        { id: "ctrl", x: 660, y: 40, w: 150, h: 56, label: "Controller", sub: "torque law or MPC", kind: "agent" },
        { id: "robot", x: 660, y: 180, w: 150, h: 56, label: "Robot arm", sub: "applies 𝛕", kind: "env" }
      ],
      edges: [
        { from: "data", to: "guided", label: "curate" },
        { from: "guided", to: "model", label: "inputs" },
        { from: "loss", to: "model", label: "gradients", sides: ["t", "b"] },
        { from: "model", to: "ctrl", label: "M, G, f" },
        { from: "ctrl", to: "robot", label: "torques", sides: ["b", "t"] },
        { from: "robot", to: "data", label: "new samples", sides: ["b", "b"], via: [[735, 280], [80, 280]], dy: -6 }
      ],
      steps: [
        { on: ["data", "data>guided", "guided"], text: "Physics-guided: priors transform or enrich inputs and data, such as features from a kinematic model. They act at curation, training and inference." },
        { on: ["guided>model", "model"], text: "Physics-encoded: the architecture holds the law, as in DeLaN's M = LLᵀ. It stays active during training and inference." },
        { on: ["loss", "loss>model"], text: "Physics-informed: a residual of the governing equation joins the loss. It acts only during training, through the learned weights." },
        { on: ["model>ctrl", "ctrl"], text: "The model feeds control: model predictive control (MPC), or DeLaN's feed-forward torque (200 Hz) added to a low-gain proportional-derivative loop at 500 Hz." },
        { on: ["ctrl>robot", "robot", "robot>data", "data"], text: "Measured states and torques return as training data. DeLaN learned online this way on a Barrett WAM arm." }
      ]
    },
    worked: {
      title: "Why the step rule matters for energy",
      ref: "P11 eq. 8 · VIN, arXiv 1910.09349", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-qj}{q_{t+1}} = \\class{sym-qj}{q_t} + h\\,\\class{sym-pmom}{p_t} - \\tfrac{h^2}{2}\\,\\tfrac{\\partial \\class{sym-Upot}{U}}{\\partial q}(\\class{sym-qj}{q_t}),\\quad \\class{sym-pmom}{p_{t+1}} = \\class{sym-pmom}{p_t} - \\tfrac{h}{2}\\Big(\\tfrac{\\partial \\class{sym-Upot}{U}}{\\partial q}(\\class{sym-qj}{q_t}) + \\tfrac{\\partial \\class{sym-Upot}{U}}{\\partial q}(\\class{sym-qj}{q_{t+1}})\\Big)",
        words: "Velocity Verlet, the VIN-VV layer with M = 1: move with the current momentum, then update momentum with the force averaged over both ends.", key: ["qj", "pmom", "Upot", { glyph: "h", meaning: "step size" }] },
      figure: WE,
      steps: [
        { title: "Start at rest", text: "Unit pendulum, q̈ = −sin q, at q = 1 rad, p = 0; step h = 0.5. Energy ½p² + 1 − cos q = 0.460." },
        { title: "One Euler step", text: "Euler, the ResNet step of eq. 8: q stays 1.000, p becomes −0.421. Energy jumps to 0.548, up 19%." },
        { title: "One Verlet step", text: "Verlet averages the force over the step: q = 0.895, p = −0.405. Energy is 0.457, down 0.7%." },
        { title: "Euler keeps climbing", text: "After three Euler steps energy is 0.783. After 40 steps it is 5.34, and the simulated pendulum swings over the top." },
        { title: "Verlet stays bounded", text: "Over 40 Verlet steps energy stays between 0.433 and 0.460. The error oscillates instead of accumulating." }
      ]
    },
    ruleTitle: "Mechanics as model structure",
    rules: [
      { name: "Euler–Lagrange equations of motion", ref: "P11 eq. 1–3",
        tex: "\\class{sym-M}{M(q)}\\,\\class{sym-qj}{\\ddot q} + \\class{sym-C}{C(q,\\dot q)} + \\class{sym-G}{G(q)} = \\class{sym-torque}{\\boldsymbol{\\tau}}",
        words: "Mass times acceleration, plus Coriolis and gravity terms, equals the applied joint torques. Every rigid robot arm obeys this form.",
        key: ["M", "qj", "C", "G", "torque"] },
      { name: "DeLaN: a Cholesky-factored mass matrix", ref: "P11 eq. 4", term: "deep-lagrangian-network",
        tex: "\\class{sym-M}{M(q)} = \\class{sym-Lchol}{L(q)}\\,\\class{sym-Lchol}{L(q)}^{\\top}, \\qquad \\class{sym-Lchol}{L}_{ii}(q) > 0",
        words: "The network outputs a lower-triangular L with a positive diagonal from q alone, so M is symmetric positive definite by construction.",
        key: ["M", "Lchol"] },
      { name: "HNN: motion from one learned energy", ref: "P11 eq. 6–7", term: "hamiltonian-neural-network",
        tex: "\\class{sym-qj}{\\dot q} = \\frac{\\partial \\class{sym-Ham}{\\mathcal{H}_\\theta}}{\\partial \\class{sym-pmom}{p}}, \\qquad \\class{sym-pmom}{\\dot p} = -\\frac{\\partial \\class{sym-Ham}{\\mathcal{H}_\\theta}}{\\partial \\class{sym-qj}{q}} + \\class{sym-torque}{\\boldsymbol{\\tau}}",
        words: "Differentiate the learned energy to get velocities and forces. With zero torque, the learned energy stays constant along every trajectory.",
        key: ["qj", "Ham", "pmom", "torque"] },
      { name: "From an Euler step to a variational integrator", ref: "P11 eq. 8 · arXiv 1910.09349", term: "variational-integrator-network",
        before: "\\class{sym-s}{s_{t+1}} = \\class{sym-s}{s_t} + \\Delta t\\, \\class{sym-f}{f_\\theta}(\\class{sym-s}{s_t})",
        tex: "\\class{sym-qj}{q_{t+1}} = \\class{sb-chg}{2\\class{sym-qj}{q_t} - \\class{sym-qj}{q_{t-1}}} \\class{sb-new}{- h^2\\, \\class{sym-M}{M}^{-1} \\frac{\\partial \\class{sym-Upot}{U_\\theta}}{\\partial q}(\\class{sym-qj}{q_t})}",
        words: "A ResNet block adds a learned velocity. A Störmer–Verlet layer instead learns a potential and steps with the discrete Euler–Lagrange rule.",
        key: ["s", "f", "qj", "M", "Upot", { glyph: "h, Δt", meaning: "step size" }], diff: true, beforeLabel: "NODE / ResNet", afterLabel: "VIN" },
      { name: "Physics-informed composite loss", ref: "P11 eq. 11", term: "physics-informed-loss",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\frac{1}{N_u}\\sum_{i=1}^{N_u} \\big|u_i - \\hat u(t_i, x_i)\\big|^2 + \\frac{1}{N_f}\\sum_{j=1}^{N_f} \\big|r(t_j, x_j)\\big|^2",
        words: "Fit the measurements, and penalize the governing equation's residual at extra collocation points where no data exist.",
        key: ["L", { glyph: "û", meaning: "network's prediction" }, { glyph: "Nᵤ", meaning: "measured data points" }, { glyph: "N_f", meaning: "collocation points" }, { glyph: "r", meaning: "residual of the governing equation" }] }
    ],
    algorithm: {
      title: "DeLaN inverse dynamics, trained online", ref: "arXiv 1907.04490 · P11 §3.1.1", prov: "Condensed",
      lines: [
        '<span class="kw">input</span> joint state <span data-sym="qj">q, q̇, q̈</span> and measured torque <span data-sym="torque">𝛕</span>',
        'shared network on <span data-sym="qj">q</span> only → heads l_d(q) (softplus + offset), l_o(q), <span data-sym="G">G(q)</span>',
        '<span data-sym="Lchol">L(q)</span> ← lower-triangular from l_d, l_o;  <span data-sym="M">M</span> ← L Lᵀ',
        '<span data-sym="C">C</span> ← Ṁ q̇ − ½ ∂(q̇ᵀ M q̇)/∂q   <span class="cm">// analytic, one forward pass</span>',
        '<span data-sym="torque">𝛕̂</span> ← <span data-sym="M">M</span> q̈ + <span data-sym="C">C</span> + <span data-sym="G">G</span>',
        '<span data-sym="L">ℒ</span> ← ‖<span data-sym="torque">𝛕̂</span> − <span data-sym="torque">𝛕</span>‖² + weight decay;  gradient step',
        '<span class="kw">control:</span> 𝛕_cmd ← K_p e + K_d ė + 𝛕̂(q_d, q̇_d, q̈_d)   <span class="cm">// feed-forward at 200 Hz</span>'
      ]
    },
    playgrounds: [
      {
        id: "pend", title: "Black-box versus energy structure on a pendulum", ref: "P11 §3.1–3.2 · arXiv 1907.04490, 1906.01563", prov: "Simplified: fixed-feature fit",
        try: "Choose Black-box and watch the orbit leave the data box. Then choose Energy. Switch the real system to Friction, and compare Energy with Dissipative.",
        mount: mountPendulum,
        demo: function (b, api) {
          var q = function (s) { return b.querySelector(s); }, id = "e6-pend";
          return [
            { target: q("canvas"), title: "Read the phase plot", text: "The shaded box holds the training data. The dashed loop is the real pendulum; the colored curve is the model released from the same angle." },
            { target: q("#" + id + "-model"), title: "A black-box model", text: "The black-box regressor fits the box but has no notion of energy. Outside the box its orbit drifts.", do: function (a) { return a.click(q("#" + id + '-model [value="bb"]')); }, task: "Choose Black-box", expect: function () { return api.state().model === "bb"; } },
            { target: q("#" + id + "-model"), title: "Add energy structure", text: "The energy model predicts acceleration from the angle alone. It conserves energy and follows the orbit at speeds it never saw.", do: function (a) { return a.click(q("#" + id + '-model [value="energy"]')); }, task: "Choose Energy", expect: function () { return api.state().model === "energy"; } },
            { target: q("#" + id + "-sys"), title: "Add friction", text: "Now the real pendulum loses energy. A conservative model cannot: the prior itself is wrong, as for HNN on a real pendulum.", do: function (a) { return a.click(q("#" + id + '-sys [value="fric"]')); }, task: "Choose Friction", expect: function () { return api.state().sys === "fric"; } },
            { target: q("#" + id + "-model"), title: "Model the dissipation", text: "The dissipative model adds a learned damping term that can only remove energy, the port-Hamiltonian fix.", do: function (a) { return a.click(q("#" + id + '-model [value="diss"]')); }, task: "Choose Dissipative", expect: function () { return api.state().model === "diss"; } },
            { target: q("#" + id + "-vmax"), title: "Your turn", text: "Go back to Black-box and raise the data speed limit to 8. With full coverage, does it still need the structure?" }
          ];
        }
      },
      {
        id: "integ", title: "Same physics, three step rules", ref: "P11 eq. 8, §3.4", prov: "Simplified: exact pendulum",
        try: "Raise the step size to 0.5 and compare the three lines. Then raise the start angle to 2.8, close to the top.",
        mount: mountIntegrators,
        demo: function (b, api) {
          var q = function (s) { return b.querySelector(s); }, id = "e6-integ";
          return [
            { target: q(".sb-chart"), title: "A flat line is correct", text: "An ideal pendulum conserves energy. Each line integrates the same exact vector field with a different step rule." },
            { target: q("#" + id + "-h"), title: "Take bigger steps", text: "Euler, the ResNet step, climbs off the chart. RK4, a general NODE solver, loses about 5%. Verlet wobbles but does not drift.", do: function (a) { return a.set(q("#" + id + "-h"), 0.5); }, task: "Set the step size to 0.5", expect: function () { return api.state().h >= 0.45; } },
            { target: q("#" + id + "-q0"), title: "Near the top", text: "Released near the top, Euler soon sends the pendulum over it. RK4 still drifts down; Verlet still holds its mean energy.", do: function (a) { return a.set(q("#" + id + "-q0"), 2.8); }, task: "Set the start angle to 2.8", expect: function () { return api.state().q0 >= 2.7; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Push the step size to 0.6 and compare the drifts. This is why VINs build a symplectic integrator into the network." }
          ];
        }
      },
      {
        id: "loss", title: "How much to trust a wrong prior", ref: "P11 §4.1 · PI-TCN, arXiv 2206.03305", prov: "Our toy numbers",
        try: "Set λ to 0 and look outside the dots. Set λ to 100 and the fit copies the flawed prior. Then set the prior mass error to 0%.",
        mount: mountLoss,
        demo: function (b, api) {
          var q = function (s) { return b.querySelector(s); }, id = "e6-loss";
          return [
            { target: q("canvas"), title: "Data only near zero", text: "Torque was measured only for |q| ≤ 0.6 rad. The prior is a nominal gravity model with a wrong mass and no cable spring." },
            { target: q("#" + id + "-lam"), title: "No physics loss", text: "With λ = 0 the fit matches the dots and swings wildly outside them.", do: function (a) { return a.set(q("#" + id + "-lam"), 0); }, task: "Set λ to 0", expect: function () { return api.state().lam === 0; } },
            { target: q("#" + id + "-lam"), title: "Trust the prior fully", text: "With λ = 100 the fit follows the prior everywhere, including its errors. Inside the data range it now misses the dots.", do: function (a) { return a.set(q("#" + id + "-lam"), 8); }, task: "Set λ to 100", expect: function () { return api.state().lam === 100; } },
            { target: q("#" + id + "-err"), title: "Fix the mass", text: "A correct mass shrinks the bias, but the missing spring remains. A soft loss cannot add physics the prior lacks.", do: function (a) { return a.set(q("#" + id + "-err"), 0); }, task: "Set the prior mass error to 0%", expect: function () { return api.state().err === 0; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Find the λ with the lowest error outside the data. PI-TCN set λ = 0 for the first half of training, then 1." }
          ];
        }
      }
    ],
    methodsLede: "Neural ODEs (2018) made a network the right-hand side of an ODE. HNN (2019) learned one energy; DeLaN (2019) learned M(q) and gravity; LNN (2020) dropped DeLaN's quadratic kinetic energy; VIN (2020) moved structure into the integrator. Later work added dissipation on Lie groups (2024), online context (2025) and floating bases (FeLaN).",
    methods: ["delan", "hamiltonian-neural-networks", "lagrangian-neural-networks", "neural-ode", "variational-integrator-networks", "port-hamiltonian-on-se", "context-aware-delan", "felan", "pinn", "pi-tcn", "sindy", "neural-sde"],
    open: [
      { title: "How much physics to embed", text: "Strong priors help when data are scarce, but wrong or overly strict ones bias the model. No principled rule says which priors to use.", refs: "P11 §7, Challenge 1" },
      { title: "Contact-rich, high-DoF robots", text: "No family dominates, and all share two gaps: contact-rich dynamics and validation on high-DoF robots. Most tests use pendulums and low-DoF arms.", refs: "P11 §3.9 · §8, Direction 4" },
      { title: "Priors across the reality gap", text: "Priors trained in simulation transfer when the physics is invariant, but hurt when friction, contact or actuators dominate the error.", refs: "P11 §7, Challenge 3" },
      { title: "Physics-aware foundation models", text: "Almost every method is trained for one robot, and only 4% of reviewed works combine two routes.", refs: "P11 §8, Directions 1–2" }
    ],
    takeaways: [
      "Physics enters robot learning through inputs and data, the architecture, or the loss. Only the first two act at run time.",
      "DeLaN and HNN encode energy structure, so their models conserve energy and extrapolate beyond the training speeds.",
      "Hard structure fails when physics is missing: a conservative model cannot fit friction without a dissipation term.",
      "The integrator matters: Euler steps drift in energy, while variational integrators keep the error bounded.",
      "Physics-encoded architectures make up 71% of the surveyed methods, yet contact-rich and high-DoF robots remain open for all families."
    ],
    quiz: [
      { q: "Which kind of physics prior is still active when the trained model runs on the robot?", options: ["Only a physics-informed loss", "A physics-encoded architecture", "None of them", "Only data curation"], correct: 1, why: "Encoded priors live in the architecture and act at training and inference. A physics-informed loss acts only in training, through the weights (P11 Fig. 3)." },
      { q: "Why does DeLaN write the mass matrix as L(q)L(q)ᵀ with a positive diagonal?", options: ["To save parameters", "To guarantee a symmetric positive-definite inertia", "To remove gravity", "To make training faster"], correct: 1, why: "A Cholesky product with positive diagonal is always symmetric positive definite, as a physical inertia must be (P11 eq. 4)." },
      { q: "An HNN is fit to a real pendulum with friction. What did the HNN paper report?", options: ["Lower fit loss and lower energy error", "Higher fit loss, but far lower energy error", "Training diverged", "Identical results to a plain network"], correct: 1, why: "HNN's train and test loss were higher (9.2, 6.0 vs 2.7, 2.2) because friction breaks conservation, yet energy error was 14 vs 390 (arXiv 1906.01563)." },
      { q: "A ResNet block computes s + Δt·f(s). Which integrator is this?", options: ["A symplectic Verlet step", "An explicit Euler step", "Fourth-order Runge–Kutta", "An implicit solver"], correct: 1, why: "P11 eq. 8 reads a ResNet block as the Euler discretization of a neural ODE. Euler steps do not preserve energy." },
      { q: "What does LNN give up compared with DeLaN?", options: ["The ability to learn from data", "Structure and interpretability of M(q) and U(q)", "Energy conservation", "Any use of the Euler–Lagrange equation"], correct: 1, why: "LNN learns an unrestricted Lagrangian, so it handles more systems but loses the explicit inertia and potential terms (P11 Table 7)." }
    ],
    cards: [
      { front: "What are P11's three routes for physics priors?", back: "Physics-guided inputs, data and representations; physics-encoded architectures; physics-informed loss functions.", ref: "P11 §2, Fig. 1" },
      { front: "What does DeLaN's network take as input, and why?", back: "Only q. Dependence on velocity and acceleration comes analytically from the Euler–Lagrange equation, which helps it extrapolate to unseen speeds.", ref: "P11 §3.1.1" },
      { front: "How does LNN differ from DeLaN?", back: "LNN learns any Lagrangian of q and q̇ and solves for q̈ with a Hessian inverse; DeLaN assumes ½q̇ᵀMq̇ − U.", ref: "arXiv 2003.04630" },
      { front: "Why do HNN rollouts still need a careful integrator?", back: "The learned field conserves ℋ, but general integrators do not preserve it over long rollouts.", ref: "P11 §3.2" },
      { front: "What does a physics-informed loss guarantee at inference?", back: "Nothing exact: a small training residual does not ensure the equation holds at inference.", ref: "P11 §4" },
      { front: "What did Context-aware DeLaN add, and with what result?", back: "A latent context inferred online by an LSTM, used in MPC: 39% lower end-effector error on Franka pick-and-place with changing loads.", ref: "arXiv 2506.15249" },
      { front: "What does SINDy assume about the dynamics?", back: "That they are a sparse combination of terms from a chosen library of candidate functions, found by thresholded least squares.", ref: "arXiv 1509.03580 · P11 §3.6.2" }
    ],
    terms: {
      "physics-embedded-learning": { name: "physics-embedded learning", aliases: ["physics priors", "physics-embedded robot learning"], group: "physics", def: "Machine learning that embeds physics priors (governing equations, conservation laws, geometric structure, contact models, consistency constraints) into inputs, architectures or losses to complement limited data.", note: "Generic mathematical structure alone does not count; the prior must encode physical knowledge of the system.", ref: "P11 §1–2", scene: "system", focus: ["world-model", "simulator"], look: "the learned dynamics model", uses: [] },
      "physics-guided-learning": { name: "physics-guided learning", aliases: ["physics-guided inputs"], group: "physics", def: "Using physics priors to transform, enrich, curate or correct a model's inputs, data or representations, before training or as pre- or post-processing at inference.", note: "The model itself can stay a standard network; 16% of the surveyed papers use this route.", ref: "P11 §2, §5", scene: "system", focus: ["data-robot", "simulator"], look: "physics features entering the data", uses: ["physics-embedded-learning"] },
      "physics-encoded-architecture": { name: "physics-encoded architecture", aliases: ["physics-encoded learning"], group: "physics", def: "A model whose structure, layers or integrator hold the physical law, so the prior is active during both training and inference.", note: "71% of the surveyed methods; DeLaN, HNN, VIN and hybrid residual models all belong here.", ref: "P11 §3", scene: "system", focus: ["world-model"], look: "structure inside the model", uses: ["physics-embedded-learning"] },
      "physics-informed-loss": { name: "physics-informed loss", aliases: ["PINN", "physics-informed neural network", "physics-informed learning"], group: "physics", def: "A training loss that adds the residual of the governing equations, evaluated at collocation points, to the data-fit term.", note: "A soft constraint: a small training residual does not guarantee the equations hold at inference.", ref: "P11 §4, eq. 11", scene: "system", focus: ["policy-update"], look: "the loss during training", uses: ["physics-embedded-learning"] },
      "deep-lagrangian-network": { name: "deep Lagrangian network", aliases: ["DeLaN"], group: "physics", sym: "M(q)", symTex: "M(q)", def: "A network that learns the inertia matrix, through a Cholesky factor with positive diagonal, and the potential energy from q, and computes dynamics with the Euler–Lagrange equation.", note: "It cannot represent effects outside rigid-body mechanics, such as the Barrett WAM's cable drives, without extra terms.", ref: "P11 §3.1.1", scene: "robot", focus: ["arm", "joint"], look: "joint torques of the arm", uses: ["physics-encoded-architecture"] },
      "lagrangian-neural-network": { name: "Lagrangian neural network", aliases: ["LNN"], group: "physics", sym: "ℒ_lag", symTex: "\\mathcal{L}_{\\text{lag}}", def: "A network that learns an unrestricted Lagrangian of q and q̇; accelerations follow from the Euler–Lagrange equation via its Hessian.", note: "More general than DeLaN, but it loses the explicit inertia and potential terms and needs smooth activations.", ref: "P11 §3.1.2", scene: "robot", focus: ["arm", "trajectory"], look: "motion from a learned Lagrangian", uses: ["deep-lagrangian-network"] },
      "hamiltonian-neural-network": { name: "Hamiltonian neural network", aliases: ["HNN"], group: "physics", sym: "ℋ", symTex: "\\mathcal{H}", def: "A network that learns the Hamiltonian H(q, p) and obtains dynamics from Hamilton's equations, so the learned energy is conserved by construction.", note: "It needs momenta p, which are rarely measured; without a dissipation term it cannot fit friction.", ref: "P11 §3.2.1", scene: "robot", focus: ["arm", "trajectory"], look: "an energy-conserving trajectory", uses: ["physics-encoded-architecture"] },
      "port-hamiltonian-model": { name: "port-Hamiltonian model", aliases: ["port-Hamiltonian neural ODE"], group: "physics", def: "A Hamiltonian model extended with energy ports: learned dissipation and input matrices model friction, drag and control explicitly rather than as residuals.", note: "It interfaces naturally with passivity-based and energy-shaping control.", ref: "P11 §3.2.2", scene: "system", focus: ["world-model", "controller"], look: "model feeding an energy-shaping controller", uses: ["hamiltonian-neural-network"] },
      "neural-ode": { name: "neural ODE", aliases: ["NODE", "neural ordinary differential equation"], group: "physics", sym: "f_θ", symTex: "f_\\theta", def: "A model whose network defines the time derivative of the state; outputs come from an ODE solver, and gradients from the adjoint method.", note: "A ResNet block is its Euler discretization; a NODE alone embeds little physics.", ref: "P11 §3.4, eq. 8", scene: "system", focus: ["world-model"], look: "continuous-time dynamics", uses: [] },
      "variational-integrator-network": { name: "variational integrator network", aliases: ["VIN", "forced VIN"], group: "physics", def: "A network whose layers are steps of a symplectic variational integrator with a learned potential and mass, preserving energy and momentum structure by architecture.", note: "Forced VINs add control and damping; contact-rich systems remain open.", ref: "P11 §3.4", scene: "system", focus: ["world-model"], look: "rollout that keeps its energy", uses: ["neural-ode"] },
      "residual-dynamics-learning": { name: "residual dynamics learning", aliases: ["residual learning", "hybrid physics-learning"], group: "physics", def: "Learning a correction on top of a physics-based model to capture unmodeled dynamics, parameter errors or simplifications.", note: "Guarantees and interpretability hold only for the analytic part; accuracy depends on that model's fidelity.", ref: "P11 §3.5.2", scene: "robot", focus: ["object", "trajectory"], look: "a thrown object's corrected path", uses: ["physics-encoded-architecture"] },
      "sindy": { name: "SINDy", aliases: ["sparse identification of nonlinear dynamics"], group: "physics", def: "Discovering governing equations by selecting a few terms from a library of candidate functions with sparse regression.", note: "It only finds terms the library contains; physics knowledge goes into designing that library.", ref: "P11 §3.6.2", scene: "system", focus: ["world-model"], look: "a compact symbolic model", uses: [] },
      "energy-drift": { name: "energy drift", aliases: [], group: "physics", def: "The gradual gain or loss of energy in a simulated or learned rollout of a system that should conserve it.", note: "It can come from the learned model or from the integrator; structured models and variational integrators each remove one source.", ref: "P11 §3.2, §3.4", scene: "robot", focus: ["trajectory"], look: "an orbit spiraling outward", uses: ["hamiltonian-neural-network", "variational-integrator-network"] }
    },
    symbols: [
      { id: "pmom", tex: "p", glyph: "p", kind: "Robot", meaning: "generalized momentum, p = M(q) q̇", short: "generalized momentum", first: "e6", read: "p", papers: "P11: p · HNN: p" },
      { id: "Upot", tex: "U(q)", glyph: "U(q)", kind: "Functions", meaning: "potential energy (gravity, springs)", short: "potential energy", first: "e6", read: "U of q", papers: "P11: V(q) · VIN: U_θ(q)" },
      { id: "Lchol", tex: "L(q)", glyph: "L(q)", kind: "Robot", meaning: "lower-triangular Cholesky factor of the mass matrix, with positive diagonal", short: "Cholesky factor of M", first: "e6", read: "L of q", papers: "P11 eq. 4: L(q) · DeLaN: L̂(q; θ)" }
    ],
    ledger: [
      { where: "Topic 20 · rules and worked example", source: "P11 writes potential V(q), gravity g(q), Coriolis c(q, q̇) and the PINN loss J (eq. 11)", page: "This site writes U(q), G(q), C(q, q̇) and ℒ", why: "V, g and J mean value, goal and RL objective elsewhere on the site.", kind: "Our choice" },
      { where: "Topic 20 · NODE rule", source: "P11 eq. 8 writes the state as x(t)", page: "Written as sₜ", why: "x is the end-effector position in house notation.", kind: "Our choice" },
      { where: "Topic 20 · playground 1", source: "DeLaN and HNN train neural networks", page: "Least squares on fixed features: radial basis functions for the black box, Fourier terms in q for the energy model", why: "Shows the effect of structure alone, and runs instantly.", kind: "Simplified" },
      { where: "Topic 20 · playground 1", source: "Port-Hamiltonian models learn a full dissipation matrix D(q, p)", page: "One damping coefficient d ≥ 0", why: "A 1-DoF toy needs only one term.", kind: "Simplified" },
      { where: "Topic 20 · HNN rule", source: "P11 §3.2.1 notes that HNN's loss makes it physics-informed as well as encoded", page: "Shown as an encoded architecture", why: "Its structure, not the loss, is what this topic teaches.", kind: "Our choice" },
      { where: "Topic 20 · PI-TCN citation", source: "The PI-TCN card notes its closed-loop tracking used PI-MLP (history T = 1)", page: "Only the loss form and λ schedule are cited", why: "Avoids crediting PI-TCN with tracking results it did not run.", kind: "Our choice" }
    ]
  });
})();
