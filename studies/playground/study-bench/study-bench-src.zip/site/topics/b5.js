/* Topic 09 · High-level planning with LLMs and VLMs. Sources: P01 §5, P09 §VIII, P02 §IV-C, method papers (SayCan,
   Inner Monologue, Code as Policies, PaLM-E, VoxPoser, ReKep, MOKA, RoboPoint, CLIPort, Text2Motion). */
(function () {
  "use strict";
  var RB = window.RB;
  var mono = function () { return getComputedStyle(document.body).getPropertyValue("--font-mono"); };
  var bodyF = function () { return getComputedStyle(document.body).getPropertyValue("--font-body"); };
  /* StudyBench.segmented calls onChange(value, button); RB.bindSeg reads .value of the string, so bind directly (as b3 does) */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }

  /* ================= playground 1: Say × Can on a toy tabletop ================= */
  /* A fixed skill library, a hand-written "text-only language model" (plan preferences that never look at the table)
     and a hand-written "value function" that looks only at the table. Numbers are ours; the scoring rule is SayCan's. */
  var SK = [
    { id: "pk-sponge", t: "pick up the sponge" }, { id: "pk-towel", t: "pick up the towel" }, { id: "pk-apple", t: "pick up the apple" },
    { id: "wipe", t: "wipe the table" }, { id: "bowl", t: "place it in the bowl" }, { id: "open", t: "open the drawer" },
    { id: "drawer", t: "place it in the drawer" }, { id: "down", t: "put it down" }, { id: "done", t: "done" }
  ];
  var INSTR = {
    wipe: { t: "Wipe up the spill", plans: [{ w: 0.55, p: ["pk-sponge", "wipe", "done"] }, { w: 0.45, p: ["pk-towel", "wipe", "done"] }] },
    bowl: { t: "Put the apple in the bowl", plans: [{ w: 1, p: ["pk-apple", "bowl", "done"] }] },
    drawer: { t: "Put the apple in the drawer", plans: [{ w: 0.55, p: ["pk-apple", "open", "drawer", "done"] }, { w: 0.45, p: ["open", "pk-apple", "drawer", "done"] }] }
  };
  var SMOOTH = 0.1, MAXSTEPS = 6;
  function llmDist(instr, hist) {
    var plans = INSTR[instr].plans.filter(function (pl) { for (var i = 0; i < hist.length; i++) if (pl.p[i] !== hist[i]) return false; return true; });
    var mass = {}; SK.forEach(function (s) { mass[s.id] = 0; });
    if (!plans.length) mass.done = 1;
    else { var tot = plans.reduce(function (a, pl) { return a + pl.w; }, 0); plans.forEach(function (pl) { mass[pl.p[hist.length] || "done"] += pl.w / tot; }); }
    return SK.map(function (s) { return (1 - SMOOTH) * mass[s.id] + SMOOTH / SK.length; });
  }
  function held(st) { var h = null; Object.keys(st.loc).forEach(function (k) { if (st.loc[k] === "hand") h = k; }); return h; }
  function aff(id, st) {
    var h = held(st);
    if (id.indexOf("pk-") === 0) { var o = id.slice(3); if (st.loc[o] === "table" && !h) return 0.9; return st.loc[o] === "absent" ? 0.03 : 0.05; }
    if (id === "wipe") return h === "sponge" || h === "towel" ? 0.85 : 0.05;
    if (id === "bowl") return h ? 0.9 : 0.03;
    if (id === "open") return st.drawerOpen ? 0.05 : h ? 0.1 : 0.8;
    if (id === "drawer") return h && st.drawerOpen ? 0.85 : h ? 0.05 : 0.03;
    if (id === "down") return h ? 0.95 : 0.03;
    return 1; /* done */
  }
  function apply(id, st) {
    var h = held(st);
    if (id.indexOf("pk-") === 0) st.loc[id.slice(3)] = "hand";
    else if (id === "wipe") st.spill = false;
    else if (id === "bowl") st.loc[h] = "bowl";
    else if (id === "open") st.drawerOpen = true;
    else if (id === "drawer") st.loc[h] = "drawer";
    else if (id === "down") st.loc[h] = "table";
  }
  function goalMet(instr, st) { return instr === "wipe" ? !st.spill : instr === "bowl" ? st.loc.apple === "bowl" : st.loc.apple === "drawer"; }
  function cloneSt(st) { return { loc: { sponge: st.loc.sponge, towel: st.loc.towel, apple: st.loc.apple }, drawerOpen: st.drawerOpen, spill: st.spill }; }
  /* Text2Motion-style check: score whole candidate plans by LLM weight × product of success probabilities along the imagined sequence */
  function planScores(instr, st) {
    var pls = INSTR[instr].plans, tot = pls.reduce(function (a, p) { return a + p.w; }, 0);
    return pls.map(function (pl) { var s = cloneSt(st), sc = pl.w / tot; pl.p.forEach(function (id) { sc *= aff(id, s); apply(id, s); }); return sc; });
  }

  function mountSayCan(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-instr", label: "Instruction", value: "wipe", options: [{ value: "wipe", label: "Spill" }, { value: "bowl", label: "Bowl" }, { value: "drawer", label: "Drawer" }] }) +
      RB.seg({ id: id + "-mode", label: "Planner", value: "saycan", options: [{ value: "llm", label: "LLM only" }, { value: "saycan", label: "Say×Can" }, { value: "seq", label: "Whole-plan check" }] }) + "</div>" +
      '<div class="rb-row">' +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-sponge"> <span>Sponge on table</span></label>' +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-towel" checked> <span>Towel on table</span></label>' +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-apple" checked> <span>Apple on table</span></label>' +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-dopen"> <span>Drawer open</span></label>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-step">Next skill ▶</button><button class="sb-btn" type="button" id="' + id + '-run">Run to end</button><button class="sb-btn" type="button" id="' + id + '-reset">Reset</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Tabletop scene above; below, for each of nine skills, the language-model score, the affordance score and their product"></canvas>' +
      '<figcaption class="sb-caption">Top: the table the value function sees. Bottom: each skill\'s three bars. The highlighted row is the skill the planner runs next.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "calls", k: "Skills run" }, { id: "out", k: "Outcome" }]) +
      RB.legend([{ c: "data-1", label: "Say: p_LLM (text only)", kind: "area" }, { c: "data-2", label: "Can: p_aff (value function)", kind: "area" }, { c: "accent", label: "planner score", kind: "area" }]) +
      '<p class="sb-caption" data-plans></p><ol class="rb-mono" data-log style="margin:0;padding-left:1.4em;font-size:12px"></ol><p class="sb-caption" data-note></p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), W = 560, H = 452, note = body.querySelector("[data-note]"), logEl = body.querySelector("[data-log]"), plansEl = body.querySelector("[data-plans]");
    var instr = "wipe", mode = "saycan", st, hist, log, finished, success, calls, cur, chosenPlan, pscores;
    var NOTES = {
      llm: "LLM only: the text model ranks skills without seeing the table. It can ask for objects that are not there (SayCan's “No VF” ablation: 67% plan success).",
      saycan: "Say × Can multiplies the text score by the value function's success probability and runs the argmax, one skill at a time (SayCan: 84% plan success in the mock kitchen).",
      seq: "Whole-plan check scores each complete candidate plan by its text weight times the success probability of every step, then runs the best one. Text2Motion adds this sequence-level check."
    };
    function initState() {
      st = { loc: { sponge: body.querySelector("#" + id + "-sponge").checked ? "table" : "absent", towel: body.querySelector("#" + id + "-towel").checked ? "table" : "absent", apple: body.querySelector("#" + id + "-apple").checked ? "table" : "absent" }, drawerOpen: body.querySelector("#" + id + "-dopen").checked, spill: true };
      hist = []; log = []; finished = false; success = false; calls = 0; chosenPlan = null;
      pscores = planScores(instr, st);
      if (mode === "seq") { var b = 0; pscores.forEach(function (s, i) { if (s > pscores[b]) b = i; }); chosenPlan = INSTR[instr].plans[b].p; }
      score();
    }
    function score() {
      var pl = llmDist(instr, hist), pa = SK.map(function (s) { return aff(s.id, st); });
      var prod = SK.map(function (s, i) { return mode === "llm" ? pl[i] : pl[i] * pa[i]; });
      var best = 0; prod.forEach(function (v, i) { if (v > prod[best]) best = i; });
      if (mode === "seq") { var want = chosenPlan[hist.length] || "done"; SK.forEach(function (s, i) { if (s.id === want) best = i; }); }
      cur = { pl: pl, pa: pa, prod: prod, best: best };
    }
    function step() {
      if (finished) return;
      var k = SK[cur.best];
      if (k.id === "done" || calls >= MAXSTEPS) {
        finished = true; success = goalMet(instr, st);
        log.push({ t: k.id === "done" ? "done" : "step limit reached", ok: null });
      } else {
        var ok = aff(k.id, st) >= 0.5; calls++;
        if (ok) apply(k.id, st);
        log.push({ t: k.t, ok: ok }); hist.push(k.id); /* open loop: the chosen skill's text is appended whether or not it worked */
        score();
      }
      render();
    }
    function render() {
      RB.setRO(body, "calls", String(calls));
      RB.setRO(body, "out", finished ? (success ? "task done" : "task failed") : "running");
      plansEl.textContent = "Whole-plan scores (text weight × success of every step): " + pscores.map(function (s, i) { return "plan " + String.fromCharCode(65 + i) + " " + RB.fmt(s, 3); }).join(", ") + ".";
      logEl.innerHTML = log.length ? log.map(function (e) { return "<li>" + RB.esc(e.t) + (e.ok === null ? "" : e.ok ? " · succeeded" : " · failed") + "</li>"; }).join("") : "<li>no skills run yet</li>";
      logEl.innerHTML += finished ? "" : "<li><strong>next: " + RB.esc(SK[cur.best].t) + "</strong></li>";
      note.textContent = NOTES[mode];
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), fm = mono(), fb = bodyF();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      /* scene */
      var h = held(st);
      c.textAlign = "left"; c.fillStyle = P.ink; c.font = "600 13px " + fb; c.fillText("“" + INSTR[instr].t + "”", 12, 20);
      c.textAlign = "right"; c.fillStyle = P["ink-2"]; c.font = "500 12px " + fm; c.fillText(h ? "gripper holds: " + h : "gripper: empty", 548, 20);
      c.fillStyle = P["surface-sunk"]; c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.fillRect(10, 32, 540, 100); c.strokeRect(10, 32, 540, 100);
      c.font = "500 12px " + fm; c.textAlign = "center";
      if (st.spill) { c.fillStyle = P["data-4"]; c.globalAlpha = 0.45; c.beginPath(); c.ellipse(385, 70, 28, 12, 0, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1; c.fillStyle = P["ink-2"]; c.fillText("spill", 385, 104); }
      var spot = { sponge: [55, 66], towel: [140, 66], apple: [220, 66] }, bowlXY = [300, 66], drw = [440, 44, 98, 56];
      c.strokeStyle = P["line-strong"]; c.fillStyle = st.drawerOpen ? P.surface : P["surface-strong"]; c.fillRect(drw[0], drw[1], drw[2], drw[3]); c.strokeRect(drw[0], drw[1], drw[2], drw[3]);
      if (st.drawerOpen) c.strokeRect(drw[0] + 8, drw[1] + 8, drw[2] - 16, drw[3] - 16);
      c.fillStyle = P["ink-2"]; c.fillText(st.drawerOpen ? "drawer: open" : "drawer: closed", drw[0] + drw[2] / 2, 120);
      c.beginPath(); c.strokeStyle = P["ink-2"]; c.lineWidth = 1.5; c.ellipse(bowlXY[0], bowlXY[1], 28, 15, 0, 0, Math.PI); c.stroke(); c.beginPath(); c.moveTo(bowlXY[0] - 28, bowlXY[1]); c.lineTo(bowlXY[0] + 28, bowlXY[1]); c.stroke();
      c.fillStyle = P["ink-2"]; c.fillText("bowl", bowlXY[0], 104);
      var COL = { sponge: "data-3", towel: "data-5", apple: "data-2" };
      function obj(k, x, y, dash) {
        c.lineWidth = 1.5;
        if (dash) { c.setLineDash([3, 3]); c.strokeStyle = P["ink-3"]; }
        else { c.fillStyle = P[COL[k]]; c.strokeStyle = P["line-strong"]; }
        c.beginPath();
        if (k === "apple") c.arc(x, y, 10, 0, Math.PI * 2); else c.rect(x - 16, y - 8, 32, 16);
        if (!dash) c.fill(); c.stroke(); c.setLineDash([]);
      }
      Object.keys(spot).forEach(function (k) {
        var Lk = st.loc[k], s = spot[k];
        if (Lk === "table") obj(k, s[0], s[1]);
        else if (Lk === "absent") obj(k, s[0], s[1], true);
        else if (Lk === "bowl") obj(k, bowlXY[0], bowlXY[1] - 6);
        else if (Lk === "drawer") obj(k, drw[0] + drw[2] / 2, drw[1] + drw[3] / 2);
        c.fillStyle = P["ink-2"]; c.fillText(k, s[0], 104);
        if (Lk !== "table") { c.fillStyle = P["ink-3"]; c.fillText(Lk === "absent" ? "(missing)" : Lk === "hand" ? "(in gripper)" : "(in " + Lk + ")", s[0], 120); }
      });
      /* bars */
      var y0 = 176, rh = 30, cols = [196, 318, 440], bw = 70;
      c.textAlign = "left"; c.fillStyle = P["ink-2"]; c.font = "600 12px " + fb;
      ["Say: p_LLM", "Can: p_aff", mode === "llm" ? "score = p_LLM" : "Say × Can"].forEach(function (t, j) { c.fillText(t, cols[j], y0 - 12); });
      c.fillText("Skill", 12, y0 - 12);
      SK.forEach(function (s, i) {
        var y = y0 + i * rh;
        if (!finished && i === cur.best) { c.fillStyle = P["accent-soft"]; c.fillRect(6, y, 548, rh - 4); }
        c.fillStyle = P.ink; c.font = "500 13px " + fb; c.fillText(s.t, 12, y + 16);
        var vals = [cur.pl[i], cur.pa[i], cur.prod[i]], cs = [P["data-1"], P["data-2"], P.accent];
        vals.forEach(function (v, j) {
          c.fillStyle = P["surface-strong"]; c.fillRect(cols[j], y + 7, bw, 10);
          c.fillStyle = cs[j]; c.fillRect(cols[j], y + 7, Math.max(1, bw * Math.min(1, v)), 10);
          c.fillStyle = P["ink-2"]; c.font = "500 12px " + fm; c.fillText(RB.fmt(v, v < 0.1 ? 3 : 2), cols[j] + bw + 4, y + 16);
        });
      });
    }
    function resetAll() { initState(); render(); }
    bindSeg(body, id + "-instr", function (v) { instr = v; resetAll(); });
    bindSeg(body, id + "-mode", function (v) { mode = v; resetAll(); });
    ["sponge", "towel", "apple", "dopen"].forEach(function (k) { body.querySelector("#" + id + "-" + k).addEventListener("change", resetAll); });
    body.querySelector("#" + id + "-step").addEventListener("click", step);
    body.querySelector("#" + id + "-run").addEventListener("click", function () { var g = 0; while (!finished && g++ < 12) step(); });
    body.querySelector("#" + id + "-reset").addEventListener("click", resetAll);
    resetAll();
    RB.onTheme(draw);
    return { state: function () { return { instr: instr, mode: mode, done: finished, success: success, calls: calls, drawerOpen: st.drawerOpen }; } };
  }

  /* ================= playground 2: open loop vs Inner Monologue feedback ================= */
  /* Task: put the apple in the bowl (pick, place, done). Each skill succeeds with probability p. With probability d, a person
     knocks the apple out of the bowl once, right after it lands. Three planners differ only in the text they receive. */
  var IM_MODES = [{ value: "open", label: "Open loop" }, { value: "succ", label: "+ Success" }, { value: "scene", label: "+ Scene" }];
  function imEpisode(mode, p, d, K, R, trace) {
    var apple = "table", knocked = false, calls = 0, belief = "table", out = [];
    var say = function (s) { if (trace) out.push(s); };
    say("Human: put the apple in the bowl.");
    if (mode === "scene") say("Scene: apple on the table.");
    var plan = ["pick", "place", "done"], pi = 0;
    while (true) {
      var next;
      if (mode === "open") next = plan[pi++];
      else { var b = mode === "scene" ? apple : belief; next = b === "table" ? "pick" : b === "hand" ? "place" : "done"; }
      if (next === "done") { say("Robot: done."); break; }
      if (calls >= K) { say("(step limit reached)"); break; }
      calls++;
      var ok = R() < p;
      if (next === "pick") { say("Robot: pick up the apple."); if (ok && apple === "table") apple = "hand"; else ok = false; if (ok) belief = "hand"; }
      else { say("Robot: place it in the bowl."); if (ok && apple === "hand") { apple = "bowl"; belief = "bowl"; if (!knocked && R() < d) { knocked = true; apple = "table"; say("[a person knocks the apple back onto the table]"); } } else ok = false; }
      if (mode !== "open") say("Success: " + (ok ? "True." : "False."));
      if (mode === "scene") say("Scene: apple " + (apple === "table" ? "on the table." : apple === "hand" ? "in the gripper." : "in the bowl."));
    }
    var win = apple === "bowl";
    say(win ? "→ apple is in the bowl: task done" : "→ apple is not in the bowl: task failed");
    return { win: win, calls: calls, lines: out };
  }
  function imRate(mode, p, d, K, seed, n) {
    var R = RB.rng(seed), w = 0, c = 0;
    for (var i = 0; i < n; i++) { var e = imEpisode(mode, p, d, K, R, false); if (e.win) w++; c += e.calls; }
    return { rate: w / n, calls: c / n };
  }

  function mountMonologue(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.slider({ id: id + "-p", label: "Skill success rate", min: 0.5, max: 1, step: 0.05, value: 0.8, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-d", label: "Disturbance chance", min: 0, max: 1, step: 0.1, value: 0.3, fmt: function (v) { return (+v).toFixed(1); } }) +
      RB.slider({ id: id + "-k", label: "Step limit", min: 3, max: 15, step: 1, value: 10 }) + "</div>" +
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Feedback shown in the trace", value: "scene", options: IM_MODES }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Sample episode ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Task success against skill success rate for three feedback settings"></canvas>' +
      '<figcaption class="sb-caption">Each curve is 400 simulated episodes per point. The vertical line marks your skill success rate. Watch the gap between the lower two curves as you add disturbances.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "open", k: "Open loop" }, { id: "succ", k: "+ Success" }, { id: "scene", k: "+ Success and scene" }, { id: "calls", k: "Skill calls (trace mode)" }]) +
      RB.legend([{ c: "data-1", label: "open loop (SayCan-style)", kind: "dash" }, { c: "data-2", label: "+ success feedback", kind: "line" }, { c: "data-3", label: "+ success and scene", kind: "line" }]) +
      '<pre class="rb-well rb-mono" data-trace style="white-space:pre-wrap;margin:0;font-size:12px"></pre></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), trEl = body.querySelector("[data-trace]"), W = 520, H = 300;
    var p = 0.8, d = 0.3, K = 10, mode = "scene", seed = 11, curves = {};
    var PS = []; for (var q = 0.5; q <= 1.0001; q += 0.05) PS.push(+q.toFixed(2));
    function compute() {
      IM_MODES.forEach(function (m, j) { curves[m.value] = PS.map(function (pp, i) { return [pp, imRate(m.value, pp, d, K, 1000 + i * 7 + j, 400).rate]; }); });
      IM_MODES.forEach(function (m) { RB.setRO(body, m.value, Math.round(100 * imRate(m.value, p, d, K, 77, 400).rate) + "%"); });
      RB.setRO(body, "calls", RB.fmt(imRate(mode, p, d, K, 77, 400).calls, 1));
      sample(); draw();
    }
    function sample() { var e = imEpisode(mode, p, d, K, RB.rng(seed), true); trEl.textContent = e.lines.join("\n"); }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), fm = mono(), L = 48, R = 16, T = 14, B = 40;
      var sx = function (v) { return L + (v - 0.5) / 0.5 * (W - L - R); }, sy = function (v) { return T + (1 - v) * (H - T - B); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P.line; c.lineWidth = 1; c.font = "500 11px " + fm; c.fillStyle = P["ink-3"];
      [0, 0.25, 0.5, 0.75, 1].forEach(function (v) { c.beginPath(); c.moveTo(L, sy(v)); c.lineTo(W - R, sy(v)); c.stroke(); c.textAlign = "right"; c.fillText(Math.round(v * 100) + "%", L - 6, sy(v) + 4); });
      [0.5, 0.6, 0.7, 0.8, 0.9, 1].forEach(function (v) { c.textAlign = "center"; c.fillText(v.toFixed(1), sx(v), H - B + 16); });
      c.fillStyle = P["ink-2"]; c.fillText("skill success rate", (L + W - R) / 2, H - 6);
      c.save(); c.translate(12, (T + H - B) / 2); c.rotate(-Math.PI / 2); c.fillText("task success", 0, 0); c.restore();
      c.strokeStyle = P["ink-3"]; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(sx(p), T); c.lineTo(sx(p), H - B); c.stroke(); c.setLineDash([]);
      [["open", "data-1", [6, 4]], ["succ", "data-2", []], ["scene", "data-3", []]].forEach(function (s) {
        c.strokeStyle = P[s[1]]; c.lineWidth = 2.2; c.setLineDash(s[2]); c.beginPath();
        curves[s[0]].forEach(function (pt, i) { if (i) c.lineTo(sx(pt[0]), sy(pt[1])); else c.moveTo(sx(pt[0]), sy(pt[1])); }); c.stroke(); c.setLineDash([]);
      });
    }
    RB.bindSlider(body, id + "-p", function (v) { return (+v).toFixed(2); }, function (v) { p = v; compute(); });
    RB.bindSlider(body, id + "-d", function (v) { return (+v).toFixed(1); }, function (v) { d = v; compute(); });
    RB.bindSlider(body, id + "-k", null, function (v) { K = v; compute(); });
    bindSeg(body, id + "-mode", function (v) { mode = v; RB.setRO(body, "calls", RB.fmt(imRate(mode, p, d, K, 77, 400).calls, 1)); sample(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; sample(); });
    compute();
    RB.onTheme(draw);
    return { state: function () { return { p: p, d: d, K: K, mode: mode, seed: seed }; } };
  }

  /* ================= playground 3: a VoxPoser-style value map in 2-D ================= */
  var GX = 48, GY = 28, CELL = 11, START = [4, 14], TARGETS = [[42, 14], [40, 5], [40, 23]], VASE_R = 2.5;
  function planPath(tgt, vase, w, r) {
    var n = GX * GY, V = new Float64Array(n), dist = new Float64Array(n), prev = new Int32Array(n), done = new Uint8Array(n), i;
    for (i = 0; i < n; i++) {
      var x = i % GX, y = (i / GX) | 0;
      var dt = Math.hypot(x - tgt[0], y - tgt[1]), dv = Math.hypot(x - vase[0], y - vase[1]);
      var a = Math.max(0, 1 - dt / 60), av = Math.exp(-dv * dv / (2 * r * r));
      V[i] = 2 * a - w * av; dist[i] = Infinity; prev[i] = -1;
    }
    var s = START[1] * GX + START[0], g = tgt[1] * GX + tgt[0]; dist[s] = 0;
    /* shortest path where each step costs its length × (C − V): minimizing Σ(C − V) = maximizing total value along the path */
    for (var it = 0; it < n; it++) {
      var u = -1, best = Infinity; for (i = 0; i < n; i++) if (!done[i] && dist[i] < best) { best = dist[i]; u = i; }
      if (u < 0 || u === g) break; done[u] = 1;
      var ux = u % GX, uy = (u / GX) | 0;
      for (var dx = -1; dx <= 1; dx++) for (var dy = -1; dy <= 1; dy++) {
        if (!dx && !dy) continue; var vx = ux + dx, vy = uy + dy; if (vx < 0 || vy < 0 || vx >= GX || vy >= GY) continue;
        var v = vy * GX + vx, nd = dist[u] + Math.hypot(dx, dy) * (2.1 - V[v]);
        if (nd < dist[v]) { dist[v] = nd; prev[v] = u; }
      }
    }
    var path = [], c = g; while (c >= 0) { path.push([c % GX, (c / GX) | 0]); c = prev[c]; } path.reverse();
    return { V: V, path: path };
  }

  function mountValueMap(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-view", label: "Map shown", value: "val", options: [{ value: "aff", label: "Affordance" }, { value: "avoid", label: "Avoidance" }, { value: "val", label: "Composed value" }] }) +
      RB.slider({ id: id + "-w", label: "Avoidance weight", min: 0, max: 3, step: 0.5, value: 1, fmt: function (v) { return (+v).toFixed(1); } }) +
      RB.slider({ id: id + "-r", label: "Avoidance radius", min: 2, max: 8, step: 1, value: 4 }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-move">Move the bowl ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Top-down value map with gripper start on the left, a vase in the middle and a bowl target; the planned path is drawn on top"></canvas>' +
      '<figcaption class="sb-caption">Top-down view. Shading = the selected map. Line = the planned gripper path from the square to the bowl. Click the map to move the vase.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "len", k: "Path length", u: "cells" }, { id: "clear", k: "Closest to vase", u: "cells" }, { id: "hit", k: "Hits the vase" }, { id: "replans", k: "Replans" }]) +
      RB.legend([{ c: "data-1", label: "value (affordance)", kind: "area" }, { c: "bad", label: "avoidance", kind: "area" }, { c: "accent", label: "planned path", kind: "line" }]) +
      '<p class="sb-caption">VoxPoser composes maps in code, e.g. value = 2 × affordance − 1 × avoidance on a 100³ voxel grid, and replans at 5 Hz. This toy is a 48 × 28 grid.</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), W = GX * CELL, H = GY * CELL;
    var view = "val", w = 1, r = 4, ti = 0, vase = [22, 14], replans = 0, res = null;
    function run() {
      res = planPath(TARGETS[ti], vase, w, r);
      var len = 0, minC = Infinity; res.path.forEach(function (pt, i) { if (i) len += Math.hypot(pt[0] - res.path[i - 1][0], pt[1] - res.path[i - 1][1]); minC = Math.min(minC, Math.hypot(pt[0] - vase[0], pt[1] - vase[1]) - VASE_R); });
      RB.setRO(body, "len", RB.fmt(len, 1)); RB.setRO(body, "clear", RB.fmt(Math.max(0, minC), 1)); RB.setRO(body, "hit", minC < 0 ? "yes" : "no"); RB.setRO(body, "replans", String(replans));
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), tgt = TARGETS[ti];
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      for (var i = 0; i < GX * GY; i++) {
        var x = i % GX, y = (i / GX) | 0, dt = Math.hypot(x - tgt[0], y - tgt[1]), dv = Math.hypot(x - vase[0], y - vase[1]);
        var a = Math.max(0, 1 - dt / 60), av = Math.exp(-dv * dv / (2 * r * r)), val = view === "aff" ? a : view === "avoid" ? -av : res.V[i] / 2;
        if (Math.abs(val) < 0.02) continue;
        c.fillStyle = val > 0 ? P["data-1"] : P.bad; c.globalAlpha = Math.min(0.75, Math.abs(val) * 0.75); c.fillRect(x * CELL, y * CELL, CELL, CELL);
      }
      c.globalAlpha = 1; c.strokeStyle = P.line; c.lineWidth = 0.5;
      for (var gx = 0; gx <= GX; gx += 4) { c.beginPath(); c.moveTo(gx * CELL, 0); c.lineTo(gx * CELL, H); c.stroke(); }
      for (var gy = 0; gy <= GY; gy += 4) { c.beginPath(); c.moveTo(0, gy * CELL); c.lineTo(W, gy * CELL); c.stroke(); }
      var cx = function (v) { return v * CELL + CELL / 2; };
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["ink-2"]; c.lineWidth = 1.5; c.beginPath(); c.arc(cx(vase[0]), cx(vase[1]), VASE_R * CELL, 0, Math.PI * 2); c.fill(); c.stroke();
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono(); c.textAlign = "center"; c.fillText("vase", cx(vase[0]), cx(vase[1]) + 4);
      c.strokeStyle = P["ink-2"]; c.beginPath(); c.ellipse(cx(tgt[0]), cx(tgt[1]), 16, 10, 0, 0, Math.PI * 2); c.stroke(); c.fillText("bowl", cx(tgt[0]), cx(tgt[1]) - 14);
      c.strokeStyle = P.accent; c.lineWidth = 3; c.beginPath(); res.path.forEach(function (pt, k) { if (k) c.lineTo(cx(pt[0]), cx(pt[1])); else c.moveTo(cx(pt[0]), cx(pt[1])); }); c.stroke();
      c.fillStyle = P.ink; c.fillRect(cx(START[0]) - 6, cx(START[1]) - 6, 12, 12); c.textAlign = "left"; c.fillText("gripper", cx(START[0]) - 6, cx(START[1]) - 12);
    }
    bindSeg(body, id + "-view", function (v) { view = v; draw(); });
    RB.bindSlider(body, id + "-w", function (v) { return (+v).toFixed(1); }, function (v) { w = v; run(); });
    RB.bindSlider(body, id + "-r", null, function (v) { r = v; run(); });
    body.querySelector("#" + id + "-move").addEventListener("click", function () { ti = (ti + 1) % TARGETS.length; replans++; run(); });
    function placeVase(x, y) {
      x = RB.clamp(Math.round(x), 8, GX - 9); y = RB.clamp(Math.round(y), 3, GY - 4);
      vase = [x, y]; replans++; run();
    }
    cv.addEventListener("click", function (e) { var b = cv.getBoundingClientRect(); placeVase((e.clientX - b.left) / b.width * GX - 0.5, (e.clientY - b.top) / b.height * GY - 0.5); });
    run();
    RB.onTheme(draw);
    return { state: function () { return { view: view, w: w, r: r, replans: replans, moves: ti, vase: vase.slice() }; }, placeVase: placeVase };
  }

  /* ================= concept-card drawings (200 × 56, token colors only) ================= */
  var ART = {
    artifact: '<svg viewBox="0 0 200 56" aria-hidden="true">' + ["skill", "code", "map", "point"].map(function (t, i) { return '<rect x="' + (2 + i * 42) + '" y="14" width="40" height="22" rx="3" class="' + (i === 2 ? "rb-f-soft" : "rb-f-surface") + '"/><text x="' + (22 + i * 42) + '" y="29" text-anchor="middle" class="rb-t-mono">' + t + "</text>"; }).join("") + '<path d="M174 25 H194" class="rb-s-acc"/><path d="M189 20 L195 25 L189 30" class="rb-s-acc"/><text x="100" y="52" text-anchor="middle" class="rb-t-mono">plan artifact → low-level layer</text></svg>',
    saycan: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="10" width="54" height="10" class="rb-f-surface"/><rect x="8" y="10" width="23" height="10" style="fill:var(--data-1)"/><text x="8" y="34" class="rb-t-mono">Say 0.42</text><text x="72" y="20" class="rb-t-ink">×</text><rect x="86" y="10" width="54" height="10" class="rb-f-surface"/><rect x="86" y="10" width="49" height="10" style="fill:var(--data-2)"/><text x="86" y="34" class="rb-t-mono">Can 0.90</text><text x="148" y="20" class="rb-t-ink">=</text><text x="162" y="20" class="rb-t-acc">0.37</text><text x="100" y="52" text-anchor="middle" class="rb-t-mono">useful × feasible now</text></svg>',
    loop: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="8" width="54" height="22" rx="3" class="rb-f-soft"/><text x="33" y="23" text-anchor="middle" class="rb-t-mono">LLM</text><path d="M60 19 H96" class="rb-s-ink"/><rect x="96" y="8" width="54" height="22" rx="3" class="rb-f-surface"/><text x="123" y="23" text-anchor="middle" class="rb-t-mono">skill</text><path d="M123 30 V44 H33 V30" class="rb-s-acc" stroke-dasharray="4 3"/><text x="156" y="16" class="rb-t-mono">Success:</text><text x="156" y="32" class="rb-t-acc">False</text></svg>',
    code: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="4" width="188" height="48" rx="4" class="rb-f-sunk"/><text x="14" y="20" class="rb-t-mono"># move a bit left</text><text x="14" y="34" class="rb-t-acc">p = get_pos("cup")</text><text x="14" y="47" class="rb-t-mono">move_to(p + [-0.1, 0])</text></svg>',
    mm: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="4" y="14" width="30" height="20" rx="3" class="rb-f-surface"/><text x="19" y="28" text-anchor="middle" class="rb-t-mono">Q:</text><rect x="38" y="10" width="44" height="28" rx="3" class="rb-f-soft"/><path d="M44 32 L54 22 L62 28 L72 18 L78 32 Z" class="rb-f-acc" opacity="0.6"/><rect x="86" y="14" width="46" height="20" rx="3" class="rb-f-surface"/><text x="109" y="28" text-anchor="middle" class="rb-t-mono">what</text><rect x="136" y="14" width="56" height="20" rx="3" class="rb-f-surface"/><text x="164" y="28" text-anchor="middle" class="rb-t-mono">next?</text><text x="60" y="52" text-anchor="middle" class="rb-t-mono">image tokens</text></svg>',
    vmap: '<svg viewBox="0 0 200 56" aria-hidden="true">' + (function () { var s = ""; for (var i = 0; i < 16; i++) for (var j = 0; j < 4; j++) { var a = Math.max(0, 1 - Math.hypot(i - 14, j - 1.5) / 14), v = Math.exp(-(Math.pow(i - 7, 2) + Math.pow(j - 2, 2)) / 3); s += '<rect x="' + (4 + i * 12) + '" y="' + (4 + j * 12) + '" width="11" height="11" style="fill:var(' + (v > 0.35 ? "--bad" : "--data-1") + ')" opacity="' + (v > 0.35 ? v * 0.7 : a * 0.6).toFixed(2) + '"/>'; } return s; })() + '<path d="M10 28 C50 28 70 4 100 6 C130 8 150 22 176 22" class="rb-s-acc"/></svg>',
    keypoint: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="16" y="22" width="50" height="26" rx="4" class="rb-f-surface"/><rect x="130" y="30" width="54" height="18" rx="3" class="rb-f-surface"/><circle cx="60" cy="24" r="5" class="rb-f-acc"/><circle cx="150" cy="30" r="5" class="rb-f-acc"/><text x="56" y="14" class="rb-t-mono">k₁</text><text x="146" y="22" class="rb-t-mono">k₂</text><path d="M64 24 L146 30" class="rb-s-acc" stroke-dasharray="4 3"/><text x="86" y="52" class="rb-t-acc">c(k) ≤ 0</text></svg>',
    points: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="4" y="4" width="192" height="48" rx="4" class="rb-f-sunk"/><rect x="40" y="20" width="50" height="16" rx="4" class="rb-f-surface"/>' + [[52, 16], [78, 16], [120, 28], [150, 24], [172, 14]].map(function (p, i) { return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="7" class="' + (i === 3 ? "rb-f-acc" : "rb-f-surface") + '"/><text x="' + p[0] + '" y="' + (p[1] + 4) + '" text-anchor="middle" class="rb-t-mono">' + (i + 1) + "</text>"; }).join("") + '<text x="100" y="48" text-anchor="middle" class="rb-t-mono">VLM picks mark 4</text></svg>'
  };

  /* ================= worked example figure: the playground's numbers for "Wipe up the spill", sponge missing ================= */
  var WCOLS = ["pick sponge", "pick towel", "pick apple", "wipe table", "done"];
  var CALL = [
    { llm: [0.506, 0.416, 0.011, 0.011, 0.011], aff: [0.03, 0.90, 0.90, 0.05, 1.00], prod: [0.015, 0.374, 0.010, 0.001, 0.011], win: 1, hist: "history: (empty)" },
    { llm: [0.011, 0.011, 0.011, 0.911, 0.011], aff: [0.03, 0.05, 0.05, 0.85, 1.00], prod: [0.000, 0.001, 0.001, 0.774, 0.011], win: 3, hist: "history: pick up the towel" },
    { llm: [0.011, 0.011, 0.011, 0.011, 0.911], aff: [0.03, 0.05, 0.05, 0.85, 1.00], prod: [0.000, 0.001, 0.001, 0.009, 0.911], win: 4, hist: "history: pick up the towel, wipe the table" }
  ];
  function weRow(vals, y, cls, win) {
    return vals.map(function (v, i) {
      var x = 150 + i * 82;
      return (win === i ? '<rect x="' + (x - 4) + '" y="' + (y - 18) + '" width="78" height="36" rx="4" class="rb-s-acc"/>' : "") +
        '<rect x="' + x + '" y="' + (y - 12) + '" width="70" height="10" class="rb-f-surface"/><rect x="' + x + '" y="' + (y - 12) + '" width="' + Math.max(1, 70 * v).toFixed(1) + '" height="10" style="fill:var(--' + cls + ')"/>' +
        '<text x="' + x + '" y="' + (y + 12) + '" class="' + (win === i ? "rb-t-acc" : "rb-t-mono") + '">' + v.toFixed(3) + "</text>";
    }).join("");
  }
  var WE_FIG = '<svg viewBox="0 0 560 220" role="img" aria-label="Three rows of bars for five skills: language-model score, affordance, and their product, for three successive planner calls">' +
    WCOLS.map(function (t, i) { return '<text x="' + (185 + i * 82) + '" y="18" text-anchor="middle" class="rb-t-ink">' + t + "</text>"; }).join("") +
    '<g class="rb-t-ink"><text x="8" y="56">Say: p_LLM</text><text x="8" y="112">Can: p_aff</text><text x="8" y="168">Say × Can</text></g>' +
    '<g data-on="1-3">' + weRow(CALL[0].llm, 60, "data-1", -1) + '<text x="8" y="210" class="rb-t-mono">call 1 · ' + CALL[0].hist + "</text></g>" +
    '<g data-on="2-3">' + weRow(CALL[0].aff, 116, "data-2", -1) + "</g>" +
    '<g data-on="3">' + weRow(CALL[0].prod, 172, "accent", CALL[0].win) + "</g>" +
    [1, 2].map(function (k) { var C = CALL[k]; return '<g data-on="' + (k + 3) + '">' + weRow(C.llm, 60, "data-1", -1) + weRow(C.aff, 116, "data-2", -1) + weRow(C.prod, 172, "accent", C.win) + '<text x="8" y="210" class="rb-t-mono">call ' + (k + 1) + " · " + C.hist + "</text></g>"; }).join("") +
    "</svg>";

  RB.topic({
    id: "b5",
    title: "High-level planning with LLMs",
    eyebrow: "Part B · Planners",
    lede: "A language model can plan a task but cannot move an arm. High-level planners hand a structured plan to the layer that can.",
    refs: ["P01 §5", "P09 §VIII-A", "P02 §IV-C"],
    why: "A large language model (LLM) knows that a spill needs a sponge, but not whether this robot can reach one. High-level planners use LLMs and vision-language models (VLMs) to decompose tasks, write code or specify goals, then ground that output in affordances, feedback or geometry before a low-level policy or optimizer moves the robot.",
    outcomes: [
      "Compute a SayCan skill score from language and affordance probabilities.",
      "Explain what Inner Monologue's text feedback adds to an open-loop plan.",
      "Compare skills, programs, value maps, keypoint constraints and points as planner outputs.",
      "Explain why greedy skill scoring fails when a set-up step comes first.",
      "Predict how a value map's avoidance weight changes the planned gripper path."
    ],
    concepts: [
      { name: "Plan artifact", def: "The planner's output is a structured artifact: skill sequence, program, constraint set, affordance or 3D goal, never motor torques.", ref: "P01 Fig. 12", art: ART.artifact, term: "planning-artifact" },
      { name: "Say × Can", def: "SayCan (2022) multiplies an LLM's skill likelihood by a value function's success probability and runs the best skill.", ref: "P01 §5.1", art: ART.saycan, term: "affordance-grounding", sym: "paff" },
      { name: "Feedback as text", def: "Inner Monologue keeps SayCan's planner but appends success checks and scene descriptions to the prompt, so plans can retry.", ref: "P01 §5.1", art: ART.loop, term: "closed-loop-replanning", sym: "fb" },
      { name: "Code as policy", def: "Code as Policies replaces skill picking with generated Python that calls perception and control APIs, loops and arithmetic.", ref: "P01 §5.3", art: ART.code, term: "language-model-program" },
      { name: "Multimodal sentence", def: "PaLM-E feeds image and state embeddings into the LLM between words, so the planner sees the scene itself.", ref: "P01 §5.2", art: ART.mm, term: "multimodal-sentence" },
      { name: "3D value map", def: "VoxPoser's LLM writes code that fills voxel maps; a motion planner then follows the highest-value path, without primitives.", ref: "P01 §5.4", art: ART.vmap, term: "value-map", sym: "vmap" },
      { name: "Keypoint constraint", def: "ReKep's VLM writes cost functions over 3D keypoints; an optimizer solves for 6-DoF end-effector poses in closed loop.", ref: "P01 §5.4", art: ART.keypoint, term: "keypoint-constraint", sym: "rekep" },
      { name: "Point affordance", def: "MOKA prompts a VLM to pick marked points on the image; RoboPoint fine-tunes a VLM to output such points.", ref: "P01 §5.5", art: ART.points, term: "spatial-affordance-point" }
    ],
    flow: {
      title: "Where the planner acts", ref: "P01 Fig. 12", w: 860, h: 320,
      caption: "The planner sits in the decision layer. It writes an artifact; the motion layer below turns it into actions. Feedback from the scene can reach the planner as images or as text.",
      nodes: [
        { id: "instr", x: 20, y: 30, w: 160, h: 52, label: "Instruction ℓ", sub: "the user, in words", kind: "env" },
        { id: "obs", x: 20, y: 200, w: 160, h: 52, label: "Observation oₜ", sub: "RGB-D, feedback text", kind: "env" },
        { id: "planner", x: 220, y: 112, w: 160, h: 60, label: "LLM or VLM", sub: "decision layer", kind: "agent" },
        { id: "art", x: 460, y: 112, w: 160, h: 60, label: "Plan artifact", sub: "skill, code, map, points", kind: "store" },
        { id: "low", x: 660, y: 30, w: 180, h: 60, label: "Motion layer", sub: "skill policy or optimizer", kind: "agent" },
        { id: "robot", x: 660, y: 196, w: 180, h: 60, label: "Robot", sub: "executes actions", kind: "env" }
      ],
      edges: [
        { from: "instr", to: "planner", label: "words", sides: ["r", "t"], via: [[300, 56]] },
        { from: "obs", to: "planner", label: "image or text", sides: ["r", "b"], via: [[300, 226]], dx: -60 },
        { from: "planner", to: "art", label: "writes" },
        { from: "art", to: "low", label: "target or skill", sides: ["t", "l"], via: [[540, 60]] },
        { from: "low", to: "robot", label: "actions", sides: ["b", "t"] },
        { from: "robot", to: "obs", label: "new observation", sides: ["b", "b"], via: [[750, 300], [100, 300]], dy: -6 }
      ],
      steps: [
        { on: ["instr", "obs", "instr>planner", "obs>planner", "planner"], text: "The planner reads the instruction. SayCan's LLM reads only text; PaLM-E also reads image embeddings." },
        { on: ["planner>art", "art"], text: "It writes a structured artifact instead of motor commands: a skill name, a Python program, a value map, keypoint constraints or image points." },
        { on: ["art>low", "low"], text: "The motion layer turns the artifact into motion: a learned skill policy, a motion planner over a cost map, or a numerical optimizer." },
        { on: ["low>robot", "robot"], text: "The robot executes. VoxPoser replans at 5 Hz and ReKep re-solves at about 10 Hz; skill-level planners wait for each skill to end." },
        { on: ["robot>obs", "obs", "obs>planner"], text: "Inner Monologue closes the loop in words: success checks and scene descriptions become text in the next prompt." }
      ]
    },
    worked: {
      title: "SayCan grounds a plan to wipe a spill",
      ref: "arXiv 2204.01691 eq. 1", prov: "Our toy numbers (playground 1)",
      eq: { tex: "\\hat{k} = \\arg\\max_{k \\in \\class{sym-skills}{\\Pi}} \\; \\class{sym-paff}{p_{\\text{aff}}}(c_k \\mid \\class{sym-s}{s_t}) \\cdot \\class{sym-pllm}{p_{\\text{LLM}}}(\\class{sym-wk}{w_k} \\mid \\class{sym-l}{\\ell}, \\text{history})", words: "Run the skill that is both useful for the instruction and likely to succeed from the current state.", key: [{ glyph: "k̂", meaning: "chosen skill" }, "skills", "paff", { glyph: "c_k", meaning: "event: skill k succeeds" }, "s", "pllm", "wk", "l"] },
      figure: WE_FIG,
      steps: [
        { title: "Text alone wants a sponge", text: "The LLM never sees the table. It gives “pick up the sponge” 0.51 and “pick up the towel” 0.42." },
        { title: "The value function checks", text: "Affordances say what can succeed now: the sponge is missing (0.03), the towel is in reach (0.90)." },
        { title: "Multiply and pick", text: "Sponge: 0.51 × 0.03 = 0.015. Towel: 0.42 × 0.90 = 0.374. The argmax is the towel." },
        { title: "Append, then score again", text: "With the towel step in the prompt, “wipe the table” scores 0.91 × 0.85 = 0.774. The robot wipes." },
        { title: "Stop with done", text: "Now “done” scores 0.91 × 1.00 = 0.911, far above every other skill. The plan took three calls." }
      ]
    },
    ruleTitle: "How planners score or specify the next move",
    rules: [
      { name: "SayCan: language × affordance", ref: "arXiv 2204.01691 · P01 §5.1", term: "affordance-grounding",
        tex: "\\hat{k} = \\arg\\max_{k \\in \\class{sym-skills}{\\Pi}} \\; \\class{sym-paff}{p_{\\text{aff}}}(c_k \\mid \\class{sym-s}{s_t}) \\cdot \\class{sym-pllm}{p_{\\text{LLM}}}(\\class{sym-wk}{w_k} \\mid \\class{sym-l}{\\ell}, \\class{sym-wk}{w_{k_1}}, \\dots, \\class{sym-wk}{w_{k_{n-1}}})",
        words: "Score every skill in the library by usefulness (LLM) times feasibility (value function), run the argmax and append its text.",
        key: [{ glyph: "k̂", meaning: "chosen skill" }, "skills", "paff", { glyph: "c_k", meaning: "event: skill k succeeds" }, "s", "pllm", "wk", "l"] },
      { name: "Inner Monologue: feedback in the prompt", ref: "arXiv 2207.05608 · P01 §5.1", term: "closed-loop-replanning",
        before: "\\class{sym-pllm}{p_{\\text{LLM}}}(\\class{sym-wk}{w_k} \\mid \\class{sym-l}{\\ell}, \\class{sym-wk}{w_{k_1}}, \\dots, \\class{sym-wk}{w_{k_{n-1}}})",
        tex: "\\class{sym-pllm}{p_{\\text{LLM}}}(\\class{sym-wk}{w_k} \\mid \\class{sym-l}{\\ell}, \\class{sym-wk}{w_{k_1}}, \\class{sb-new}{\\class{sym-fb}{\\mathrm{fb}_1}}, \\dots, \\class{sym-wk}{w_{k_{n-1}}}, \\class{sb-new}{\\class{sym-fb}{\\mathrm{fb}_{n-1}}})",
        words: "After every skill, text feedback enters the prompt: success or failure, visible objects, and answers from a human.",
        key: ["pllm", "wk", "l", "fb"], diff: true, beforeLabel: "SayCan", afterLabel: "Inner Monologue" },
      { name: "VoxPoser: follow the value map", ref: "arXiv 2307.05973 · P01 §5.4", term: "value-map",
        tex: "\\mathcal{F}_{\\text{task}} = -\\sum_{j=1}^{|\\class{sym-xi}{\\xi}|} \\class{sym-vmap}{\\mathbf{V}}(\\class{sym-pe}{\\mathbf{p}_j}), \\qquad \\class{sym-vmap}{\\mathbf{V}} = \\mathrm{VoxPoser}(\\class{sym-o}{o_t}, \\class{sym-l}{\\ell})",
        words: "LLM-written code fills a voxel value map from the camera; the planner picks the path whose voxels add up to the most value.",
        key: [{ glyph: "𝓕_task", meaning: "task cost to minimize" }, "xi", "vmap", "pe", "o", "l"] },
      { name: "ReKep: solve keypoint constraints", ref: "arXiv 2409.01652 eq. 2 · P01 §5.4", term: "keypoint-constraint",
        tex: "\\min_{\\class{sym-ee}{e_{g}}} \\; J_{\\text{aux}}(\\class{sym-ee}{e_{g}}) \\quad \\text{s.t.} \\quad \\class{sym-rekep}{c_m}(\\class{sym-kp}{\\mathbf{k}_{g}}) \\le 0 \\;\\; \\forall m",
        words: "Find the next stage's end-effector pose that satisfies every constraint the VLM wrote, at low collision and reachability cost.",
        key: ["ee", { glyph: "J_aux", meaning: "auxiliary cost: collision, reachability" }, "rekep", "kp", { glyph: "g", meaning: "time the stage ends (sub-goal)" }] }
    ],
    algorithm: {
      title: "The SayCan planning loop", ref: "arXiv 2204.01691 · P01 §5.1", prov: "Our notation",
      lines: [
        '<span class="kw">input</span> instruction <span data-sym="l">ℓ</span>, skill library <span data-sym="skills">Π</span>, step limit',
        "history ← [ ]",
        '<span class="kw">repeat</span> until the step limit:',
        '    <span class="kw">for each</span> skill k in <span data-sym="skills">Π</span>: score_k ← <span data-sym="paff">p_aff</span>(c_k | <span data-sym="s">sₜ</span>) · <span data-sym="pllm">p_LLM</span>(<span data-sym="wk">w_k</span> | <span data-sym="l">ℓ</span>, history)',
        "    k̂ ← argmax_k score_k",
        '    <span class="kw">if</span> <span data-sym="wk">w_k̂</span> = "done": <span class="kw">return</span>',
        "    run skill k̂'s policy; observe the new state <span data-sym=\"s\">sₜ</span>",
        '    history ← history + <span data-sym="wk">w_k̂</span>   <span class="cm">// Inner Monologue also appends feedback text</span>'
      ]
    },
    playgrounds: [
      {
        id: "saycan", title: "Say × Can picks the next skill", ref: "arXiv 2204.01691 · 2303.12153", prov: "Simplified: toy LLM and values",
        try: "Run Spill with LLM only, then with Say×Can. Switch to Drawer: greedy Say×Can fails. Try Whole-plan check, or tick Drawer open.",
        mount: mountSayCan,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b5-saycan";
          return [
            { target: q("#" + id + "-mode"), title: "Text alone", text: "First let the language model plan alone. It ranks skills by text and never looks at the table.", do: function (a) { return a.click(q("#" + id + '-mode [value="llm"]')); }, task: "Choose LLM only", expect: function () { return api.state().mode === "llm"; } },
            { target: q("#" + id + "-run"), title: "It asks for a sponge", text: "The sponge is missing, so picking it fails, and wiping without it fails too. The plan ends with the spill still there.", do: function (a) { return a.click(q("#" + id + "-run")); }, task: "Press Run to end", expect: function () { return api.state().done; } },
            { target: q("#" + id + "-mode"), title: "Add the value function", text: "Say × Can multiplies each text score by the probability the skill succeeds from this state.", do: function (a) { return a.click(q("#" + id + '-mode [value="saycan"]')); }, task: "Choose Say×Can", expect: function () { return api.state().mode === "saycan"; } },
            { target: q("canvas"), title: "The towel wins", text: "Sponge 0.51 × 0.03 is tiny; towel 0.42 × 0.90 = 0.37 is highest. Press Run to end to finish the plan.", do: function (a) { return a.click(q("#" + id + "-run")); }, task: "Press Run to end", expect: function () { return api.state().done && api.state().success; } },
            { target: q("#" + id + "-instr"), title: "A set-up step", text: "Now the apple must go into a closed drawer. The text model prefers picking the apple first.", do: function (a) { return a.click(q("#" + id + '-instr [value="drawer"]')).then(function () { return a.click(q("#" + id + "-run")); }); }, task: "Choose Drawer, then press Run to end", expect: function () { return api.state().instr === "drawer" && api.state().done; } },
            { target: q("#" + id + "-mode"), title: "Check whole plans", text: "Greedy scoring grabbed the apple and could not open the drawer. Scoring complete plans first picks the open-first plan.", do: function (a) { return a.click(q("#" + id + '-mode [value="seq"]')).then(function () { return a.click(q("#" + id + "-run")); }); }, task: "Choose Whole-plan check and run it", expect: function () { return api.state().mode === "seq" && api.state().done; } },
            { target: q("#" + id + "-dopen"), title: "Your turn", text: "Tick Drawer open and run greedy Say × Can again. Then untick Towel on table and see what the wipe plan does." }
          ];
        }
      },
      {
        id: "monologue", title: "Closing the loop with feedback text", ref: "arXiv 2207.05608", prov: "Illustrative: toy with failures",
        try: "Lower the skill success rate and watch open loop fall. Set disturbances to 0, then 0.6: only scene feedback notices a knocked-over apple. Sample episodes to read the prompt.",
        mount: mountMonologue,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b5-monologue";
          return [
            { target: q("canvas"), title: "Three planners, one task", text: "All three put an apple in a bowl with the same skills. They differ only in which feedback text reaches the planner." },
            { target: q("#" + id + "-mode"), title: "Open loop", text: "SayCan-style: the planner assumes every skill worked. Read the trace: no Success lines, no Scene lines.", do: function (a) { return a.click(q("#" + id + '-mode [value="open"]')); }, task: "Choose Open loop", expect: function () { return api.state().mode === "open"; } },
            { target: q("#" + id + "-d"), title: "No disturbances", text: "Without disturbances, success feedback is enough: failed skills are retried, so the two feedback curves overlap.", do: function (a) { return a.set(q("#" + id + "-d"), 0); }, task: "Set disturbance chance to 0", expect: function () { return api.state().d === 0; } },
            { target: q("#" + id + "-d"), title: "Someone knocks it out", text: "Now the apple is sometimes knocked out after a successful place. The success detector said True, so only scene feedback notices.", do: function (a) { return a.set(q("#" + id + "-d"), 0.6); }, task: "Set disturbance chance to 0.6", expect: function () { return api.state().d >= 0.55; } },
            { target: q("#" + id + "-p"), title: "Unreliable skills", text: "At lower skill success, open loop collapses while closed loop spends more skill calls on retries.", do: function (a) { return a.set(q("#" + id + "-p"), 0.6); }, task: "Set skill success rate to 0.60", expect: function () { return api.state().p <= 0.65; } },
            { target: q("#" + id + "-k"), title: "Your turn", text: "Lower the step limit to 4: retries run out. Inner Monologue capped simulation episodes at 15 steps." }
          ];
        }
      },
      {
        id: "valuemap", title: "Compose a value map and plan on it", ref: "arXiv 2307.05973", prov: "Simplified: 2-D grid planner",
        try: "Look at each map, then set the avoidance weight to 0: the path runs through the vase. Raise it to 2. Move the bowl, or click to move the vase; the path replans.",
        mount: mountValueMap,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b5-valuemap";
          return [
            { target: q("#" + id + "-view"), title: "Where to go", text: "The affordance map is high near the bowl and falls off with distance, like VoxPoser's distance-transformed target.", do: function (a) { return a.click(q("#" + id + '-view [value="aff"]')); }, task: "Show the Affordance map", expect: function () { return api.state().view === "aff"; } },
            { target: q("#" + id + "-view"), title: "Where not to go", text: "The avoidance map is a Gaussian blob around the vase. In VoxPoser, the LLM writes the code that builds both maps.", do: function (a) { return a.click(q("#" + id + '-view [value="avoid"]')); }, task: "Show the Avoidance map", expect: function () { return api.state().view === "avoid"; } },
            { target: q("#" + id + "-w"), title: "Drop the avoidance", text: "With weight 0 the composed value ignores the vase, and the cheapest path goes straight through it.", do: function (a) { return a.set(q("#" + id + "-w"), 0); }, task: "Set the avoidance weight to 0", expect: function () { return api.state().w === 0; } },
            { target: q("#" + id + "-w"), title: "Weigh it again", text: "At weight 2 the path bends around the vase and keeps a margin. Read Closest to vase.", do: function (a) { return a.set(q("#" + id + "-w"), 2); }, task: "Set the avoidance weight to 2", expect: function () { return api.state().w >= 2; } },
            { target: q("#" + id + "-move"), title: "The scene changes", text: "VoxPoser re-evaluates its map code on each new observation and replans at 5 Hz. Move the bowl and watch the path follow.", do: function (a) { return a.click(q("#" + id + "-move")); }, task: "Press Move the bowl", expect: function () { return api.state().moves >= 1; } },
            { target: q("canvas"), title: "Your turn", text: "Click the map to put the vase near the gripper, then shrink the avoidance radius to 2." }
          ];
        }
      }
    ],
    methods: ["saycan", "inner-monologue", "code-as-policies", "palm-e", "voxposer", "rekep", "moka", "robopoint", "cliport", "text2motion", "copa"],
    open: [
      { title: "Beyond a fixed skill set", text: "Selecting from existing skills limits versatility; planners that write code, rewards or poses let the model author new motions.", refs: "P09 §VIII-A" },
      { title: "Latency of large models", text: "Large models cannot run onboard in real time; cloud-hosted planners send low-rate decisions but add network delay.", refs: "P09 §VIII-C · MOKA, arXiv 2403.03174" },
      { title: "Verifying plans before acting", text: "Generated plans and programs can be wrong; recent work adds symbolic checks, motion-feasibility feedback and failure-driven repair.", refs: "P01 §5.1, §5.3" },
      { title: "Perception limits the planner", text: "ReKep's largest error source is point tracking; VoxPoser's real-world errors are mostly perception, not the language model.", refs: "arXiv 2409.01652 · 2307.05973" }
    ],
    takeaways: [
      "A high-level planner outputs a structured artifact, such as skills, code, a value map, constraints or points; a lower layer turns it into motion.",
      "SayCan multiplies what the LLM finds useful by what a value function says can succeed; without affordances, plan success fell from 84% to 67%.",
      "Inner Monologue closes the loop in text: success and scene feedback raised real kitchen success from 30.8% (SayCan) to 60.4%.",
      "Code as Policies, VoxPoser and ReKep move the LLM's output toward geometry: programs, then 3D value maps, then keypoint constraints for an optimizer.",
      "Greedy one-skill-at-a-time scoring can walk into dead ends; checking whole plans for feasibility, as Text2Motion does, avoids some."
    ],
    quiz: [
      { q: "In SayCan, how is the next skill chosen?", options: ["The skill the LLM rates highest", "The skill with the highest value function", "The argmax of LLM probability times affordance", "A random skill from the library"], correct: 2, why: "SayCan multiplies the LLM's probability that the skill text is useful by the value function's probability that it succeeds now, and runs the argmax (arXiv 2204.01691)." },
      { q: "What did Inner Monologue add to SayCan's planner?", options: ["A larger language model trained on robot data", "Text feedback on success and the scene in the prompt", "A diffusion head for smoother arm actions", "A reward model trained from human ratings"], correct: 1, why: "Inner Monologue keeps few-shot prompting but appends success detection, scene descriptions and human answers after each step, so the plan can retry or change." },
      { q: "What does the language model produce in VoxPoser?", options: ["Joint torques sent straight to the motors", "The name of one pretrained skill to run", "Code that composes 3D value maps for a motion planner", "Future video frames of the finished task"], correct: 2, why: "GPT-4 writes code that fills affordance, avoidance and other voxel maps; a planner optimizes the end-effector path on them and replans at 5 Hz." },
      { q: "In the drawer toy, why does greedy Say × Can fail?", options: ["The value function scores every skill as zero", "It picks the apple first, then cannot open the drawer", "The drawer is missing from the table scene", "The step limit ends the episode too early"], correct: 1, why: "Greedy scoring sees only the next step. Picking the apple scores highest, but with a full gripper the drawer cannot be opened; whole-plan checks avoid this." },
      { q: "How did PaLM-E's language ability change with model size?", options: ["It improved only at the 12B size", "Forgetting shrank: 87.3% drop at 12B, 3.9% at 562B", "It was lost completely at every model size", "Model size made no difference to forgetting"], correct: 1, why: "PaLM-E reports catastrophic forgetting of language generation that shrinks with scale: an 87.3% relative drop at 12B versus 3.9% at 562B (arXiv 2303.03378)." }
    ],
    cards: [
      { front: "What two probabilities does SayCan multiply?", back: "The LLM's probability that a skill's text is a useful next step, and the value function's probability that the skill succeeds now.", ref: "arXiv 2204.01691" },
      { front: "Which feedback types does Inner Monologue put in the prompt?", back: "Success detection, passive scene descriptions (objects, sub-goals) and a human's answers to the robot's questions.", ref: "arXiv 2207.05608" },
      { front: "What is hierarchical code generation in Code as Policies?", back: "Functions the LLM calls but has not defined are written recursively by another prompt. It raised RoboCodeGen pass rate from 81% to 95%.", ref: "arXiv 2209.07753" },
      { front: "What does PaLM-E put into the language model's input?", back: "Multimodal sentences: image, state or object-slot embeddings interleaved with word embeddings.", ref: "arXiv 2303.03378 · P01 §5.2" },
      { front: "Which maps does VoxPoser compose?", back: "Affordance, avoidance, rotation, velocity and gripper maps on a 100³ voxel grid, used as the planner's cost.", ref: "arXiv 2307.05973" },
      { front: "What is a ReKep constraint?", back: "A Python function from 3D keypoint positions to a cost, satisfied when the cost is at most zero; GPT-4o writes them per stage.", ref: "arXiv 2409.01652" },
      { front: "How does MOKA turn motion into a question a VLM can answer?", back: "It marks candidate keypoints and grid tiles on the image and asks GPT-4V to choose among them, like multiple choice.", ref: "arXiv 2403.03174 · P01 §5.5" }
    ],
    terms: {
      "planning-artifact": { name: "planning artifact", aliases: ["plan artifact", "intermediate representation"], group: "vla", def: "What a high-level planner outputs to guide action generation: a symbolic plan, program, constraint set, affordance prior, structured 3D world or video.", note: "Artifacts are consumed by a low-level policy or optimizer; the planner does not output torques.", ref: "P01 Fig. 12", scene: "system", focus: ["planner", "action-head"], look: "the planner's output feeding the policy", uses: [] },
      "skill-library": { name: "skill library", aliases: ["skill set", "primitive library"], group: "vla", sym: "Π", symTex: "\\Pi", def: "A fixed set of pretrained skills, each with a short text description, that a task planner sequences.", note: "A fixed library bounds what the planner can do; SayCan's main bottleneck is the range of its skills.", ref: "P09 §VIII-A · arXiv 2204.01691", scene: "system", focus: ["planner", "action-head"], look: "skills the planner chooses from", uses: ["planning-artifact"] },
      "affordance-grounding": { name: "affordance grounding", aliases: ["Say × Can", "SayCan scoring"], group: "vla", sym: "p_aff", symTex: "p_{\\text{aff}}", def: "Weighting an LLM's skill choice by a learned value function's estimate that the skill can succeed from the current state.", note: "The LLM supplies usefulness, the value function feasibility; neither alone chooses well.", ref: "P01 §5.1 · arXiv 2204.01691", scene: "system", focus: ["planner", "camera-image"], look: "planner scores checked against the scene", uses: ["skill-library"] },
      "closed-loop-replanning": { name: "closed-loop replanning", aliases: ["Inner Monologue", "language feedback"], group: "vla", sym: "fb", symTex: "\\mathrm{fb}", def: "Feeding execution feedback, such as task success, scene descriptions and human input, back into the planner so it can retry or revise the plan.", note: "The feedback modules have their own errors; a detector that says True after a later disturbance misleads the planner.", ref: "P01 §5.1 · arXiv 2207.05608", scene: "system", focus: ["planner", "camera-image", "verifier"], look: "feedback text flowing back to the planner", uses: ["affordance-grounding"] },
      "language-model-program": { name: "language model program", aliases: ["LMP", "code as policies", "programmatic planning"], group: "vla", def: "Executable code, generated by an LLM from a command, that calls perception and control APIs and can use loops, arithmetic and new functions.", note: "Code can express “a bit to the left” or feedback loops that fixed skill names cannot.", ref: "P01 §5.3 · arXiv 2209.07753", scene: "system", focus: ["planner", "controller"], look: "generated code calling robot APIs", uses: ["planning-artifact"] },
      "multimodal-sentence": { name: "multimodal sentence", aliases: ["embodied multimodal LLM", "MLLM planning"], group: "vla", def: "An LLM input in which continuous observations, encoded into the word-embedding space, are interleaved with text tokens.", note: "PaLM-E still outputs text plans; a separate policy such as RT-1 executes them.", ref: "P01 §5.2 · arXiv 2303.03378", scene: "system", focus: ["llm-backbone", "camera-image", "vision-encoder"], look: "image tokens among word tokens", uses: [] },
      "value-map": { name: "3D value map", aliases: ["voxel value map", "VoxPoser map"], group: "vla", sym: "𝐕", symTex: "\\mathbf{V}", def: "A voxel grid over the workspace, filled by LLM-written code, whose values say where the end-effector should and should not go.", note: "The map is a cost for a motion planner, not a policy; perception errors move the map.", ref: "P01 §5.4 · arXiv 2307.05973", scene: "robot", focus: ["trajectory", "obstacle", "target-pose"], look: "the path through high-value space", uses: ["planning-artifact"] },
      "keypoint-constraint": { name: "relational keypoint constraint", aliases: ["ReKep", "keypoint constraint"], group: "vla", sym: "c_m", symTex: "c_m", def: "A function from 3D semantic keypoints to a cost, satisfied at or below zero, used as a sub-goal or path constraint for an optimizer.", note: "The VLM writes the constraints once; a solver re-solves them at about 10 Hz as keypoints are tracked.", ref: "P01 §5.4 · arXiv 2409.01652", scene: "robot", focus: ["object", "end-effector", "target-pose"], look: "keypoints linked by a constraint", uses: ["planning-artifact"] },
      "mark-based-visual-prompting": { name: "mark-based visual prompting", aliases: ["visual prompting", "set-of-mark prompting"], group: "vla", def: "Annotating an image with numbered candidate points or tiles so a VLM can select actions by answering a multiple-choice visual question.", note: "The VLM picks among candidates; it does not regress coordinates.", ref: "P01 §5.5 · arXiv 2403.03174", scene: "robot", focus: ["object", "contact-point"], look: "numbered marks on candidate points", uses: ["spatial-affordance-point"] },
      "spatial-affordance-point": { name: "spatial affordance point", aliases: ["point affordance", "pointing"], group: "vla", def: "An image point where the robot should act, such as a grasp spot or free space for placing, predicted from language and an image.", note: "Points become 3D targets through depth; a motion planner then reaches them.", ref: "P01 §5.5 · P02 §IV-C", scene: "robot", focus: ["contact-point", "target-pose"], look: "points on the object and free space", uses: ["planning-artifact"] },
      "what-where-pathways": { name: "what and where pathways", aliases: ["CLIPort two-stream"], group: "vla", def: "CLIPort's two-stream network: a frozen CLIP semantic stream (what) fused with a Transporter spatial stream (where) to predict pick and place affordances.", note: "Surveys list it under planning, but it is an end-to-end imitation policy with no LLM planner.", ref: "P01 §5.5 · arXiv 2109.12098", scene: "system", focus: ["vision-encoder", "action-head"], look: "two streams merging into affordance maps", uses: ["spatial-affordance-point"] },
      "sequence-feasibility": { name: "sequence-level feasibility", aliases: ["whole-plan check", "geometric feasibility planning"], group: "vla", def: "Scoring a whole candidate skill sequence by whether every step can succeed in turn, instead of choosing one skill at a time.", note: "Greedy per-step scoring can pick a first step that makes a later step impossible.", ref: "arXiv 2303.12153", scene: "system", focus: ["planner"], look: "the planner checking a whole plan", uses: ["affordance-grounding"] }
    },
    symbols: [
      { id: "pllm", tex: "p_{\\text{LLM}}", glyph: "p_LLM", kind: "Functions", meaning: "language model's probability that a skill's text is a useful next step", short: "LLM skill score", first: "b5", read: "p LLM", papers: "SayCan: p(ℓ_π | i)" },
      { id: "paff", tex: "p_{\\text{aff}}", glyph: "p_aff", kind: "Functions", meaning: "affordance: value function's probability that a skill succeeds from the current state", short: "affordance score", first: "b5", read: "p aff", papers: "SayCan: p(c_π | s, ℓ_π)" },
      { id: "wk", tex: "w_k", glyph: "w_k", kind: "Signals", meaning: "text description of skill k in the library", short: "skill text", first: "b5", read: "w sub k", papers: "SayCan: ℓ_π" },
      { id: "skills", tex: "\\Pi", glyph: "Π", kind: "Sets", meaning: "skill library the planner chooses from", short: "skill library", first: "b5", read: "capital pi", papers: "SayCan: Π" },
      { id: "fb", tex: "\\mathrm{fb}_n", glyph: "fb_n", kind: "Signals", meaning: "feedback text after step n: success, scene description or human answer", short: "feedback text", first: "b5", read: "f b sub n", papers: "Inner Monologue: prompt lines such as “Success: False”" },
      { id: "vmap", tex: "\\mathbf{V}", glyph: "𝐕", kind: "Functions", meaning: "3D voxel value map composed by LLM-written code", short: "voxel value map", first: "b5", read: "bold V", papers: "VoxPoser: 𝐕 ∈ ℝ^{w×h×d}" },
      { id: "pe", tex: "\\mathbf{p}_j", glyph: "𝐩_j", kind: "Robot", meaning: "voxel position of the entity of interest (e.g. the end-effector) at path step j", short: "path voxel", first: "b5", read: "bold p sub j", papers: "VoxPoser: 𝐩ᵉⱼ" },
      { id: "kp", tex: "\\mathbf{k}", glyph: "𝐤", kind: "Robot", meaning: "positions of the K tracked 3D keypoints", short: "keypoints", first: "b5", read: "bold k", papers: "ReKep: k_t" },
      { id: "ee", tex: "e", glyph: "e", kind: "Robot", meaning: "end-effector pose in SE(3)", short: "end-effector pose", first: "b5", read: "e", papers: "ReKep: e_t" },
      { id: "rekep", tex: "c_m", glyph: "c_m", kind: "Functions", meaning: "keypoint constraint written by the VLM: cost ≤ 0 means satisfied", short: "keypoint constraint", first: "b5", read: "c sub m", papers: "ReKep: f ∈ C" }
    ],
    ledger: [
      { where: "Topic 09 · SayCan rule", source: "SayCan writes the instruction as i and a skill's text as ℓ_π", page: "The site writes the instruction as ℓ and a skill's text as w_k", why: "ℓ is the house symbol for the instruction.", kind: "Our choice" },
      { where: "Topic 09 · Inner Monologue rule", source: "Inner Monologue has no defining equation; it is a prompting framework", page: "The site shows it as SayCan's LLM term with feedback text added", why: "Makes the change from SayCan visible as a diff.", kind: "Our choice" },
      { where: "Topic 09 · ReKep rule", source: "ReKep writes constraints as f and auxiliary costs as λ", page: "The site writes c_m and J_aux", why: "f and λ already mean dynamics and contact force here.", kind: "Our choice" },
      { where: "Topic 09 · playground 1", source: "SayCan uses PaLM 540B and MT-Opt value functions", page: "A hand-written text-preference table and value table; skills succeed when affordance ≥ 0.5", why: "Isolates the scoring rule.", kind: "Simplified" },
      { where: "Topic 09 · playground 3", source: "VoxPoser plans on 100³ voxel maps with greedy search and MPC", page: "A 48 × 28 grid, shortest path on cost (constant − value)", why: "Shows how map weights shape the path.", kind: "Simplified" },
      { where: "Topic 09 · CLIPort", source: "P01 §5.5 and P02 §IV-C file CLIPort under affordance-based planning or models", page: "The CLIPort method card: an end-to-end language-conditioned imitation policy with no LLM planner", why: "It predicts affordance maps but plans nothing.", kind: "Sources disagree" }
    ]
  });
})();
