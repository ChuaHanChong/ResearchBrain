/* Topic 01 · The robot-learning problem (framework topic). Sources: P01 §1.2, §2.2, §5–6 (Fig. 1, 12), X2 §2–4, P07 §3.2, §5, App. A.
   Its methods live in later topics; the playground maps method cards from data/methods.json onto P01's X → Z → A taxonomy. */
(function () {
  "use strict";
  var RB = window.RB;

  /* ---------- playground 1: the X → Z → A map ---------- */
  /* Cell assignment is our reading of each method card (inputs, arch, action). Z = "enc" means the policy uses the features of its own
     encoder or VLM backbone; "pre" = a pretrained visual representation used as the policy input (P01 §6.3.1); "lat" = latent actions (P01 §6.3.2). */
  var MAP = [
    { id: "bc-z", y: 2021, x: ["img", "lang"], z: "enc", a: "mlp", par: [] },
    { id: "rt-1", y: 2022, x: ["img", "lang"], z: "enc", a: "tok", par: ["bc-z"] },
    { id: "mvp", y: 2022, x: ["img"], z: "pre", a: "mlp", par: [] },
    { id: "r3m", y: 2022, x: ["img"], z: "pre", a: "mlp", par: [] },
    { id: "act", y: 2023, x: ["img"], z: "enc", a: "cvae", par: ["rt-1"] },
    { id: "diffusion-policy", y: 2023, x: ["img"], z: "enc", a: "diff", par: [] },
    { id: "rt-2", y: 2023, x: ["img", "lang"], z: "enc", a: "tok", par: ["rt-1"] },
    { id: "vc-1", y: 2023, x: ["img"], z: "pre", a: "mlp", par: ["mvp", "r3m"] },
    { id: "gr-1", y: 2023, x: ["img", "lang"], z: "pre", a: "mlp", par: ["rt-1", "r3m"] },
    { id: "dp3", y: 2024, x: ["3d"], z: "enc", a: "diff", par: ["diffusion-policy"] },
    { id: "3d-diffuser-actor", y: 2024, x: ["3d", "lang"], z: "enc", a: "diff", par: ["diffusion-policy"] },
    { id: "octo", y: 2024, x: ["img", "lang"], z: "enc", a: "diff", par: ["rt-1", "diffusion-policy", "act"] },
    { id: "rdt-1b", y: 2024, x: ["img", "lang"], z: "enc", a: "diff", par: ["diffusion-policy", "act", "octo"] },
    { id: "openvla", y: 2024, x: ["img", "lang"], z: "enc", a: "tok", par: ["rt-2", "octo"] },
    { id: "3d-vla", y: 2024, x: ["3d", "lang"], z: "enc", a: "tok", par: ["rt-2"] },
    { id: "lapa", y: 2024, x: ["img", "lang"], z: "lat", a: "tok", par: ["openvla", "rt-2"] },
    { id: "pi0", y: 2024, x: ["img", "lang"], z: "enc", a: "flow", par: ["act", "openvla"] },
    { id: "openvla-oft", y: 2025, x: ["img", "lang"], z: "enc", a: "mlp", par: ["openvla", "act", "diffusion-policy"] },
    { id: "smolvla", y: 2025, x: ["img", "lang"], z: "enc", a: "flow", par: ["pi0", "gr00t-n1", "act"] },
    { id: "gr00t-n1", y: 2025, x: ["img", "lang"], z: "enc", a: "flow", par: ["pi0", "lapa", "octo"] },
    { id: "villa-x", y: 2025, x: ["img", "lang"], z: "lat", a: "flow", par: ["lapa", "pi0", "gr00t-n1"] },
    { id: "tactile-vla", y: 2025, x: ["img", "lang", "touch"], z: "enc", a: "flow", par: ["pi0"] },
    { id: "fuse", y: 2025, x: ["img", "lang", "touch"], z: "enc", a: "mlp", par: ["octo"] }
  ];
  var XS = [{ v: "img", l: "2D images" }, { v: "3d", l: "3D / depth" }, { v: "lang", l: "Language ℓ" }, { v: "touch", l: "Touch" }];
  var ZS = [{ value: "any", label: "Any" }, { value: "enc", label: "Encoder features" }, { value: "pre", label: "Pretrained" }, { value: "lat", label: "Latent actions" }];
  var AS = [{ value: "any", label: "Any" }, { value: "mlp", label: "Regression" }, { value: "cvae", label: "CVAE" }, { value: "tok", label: "Tokens" }, { value: "diff", label: "Diffusion" }, { value: "flow", label: "Flow" }];
  var AROW = ["mlp", "cvae", "tok", "diff", "flow"], AROWL = { mlp: "Regression", cvae: "CVAE", tok: "Tokens", diff: "Diffusion", flow: "Flow" };
  var NOTE_A = {
    any: "Pick a decoder to see how the output side evolved.",
    mlp: "Regression heads (a multilayer perceptron with an L2 or L1 loss) output the action directly. OpenVLA-OFT came back to L1 regression over whole chunks.",
    cvae: "A conditional variational autoencoder (CVAE) decodes a style code and the observation into a chunk. ACT is the example.",
    tok: "Tokens: each action dimension is cut into 256 bins and predicted like words, as in RT-1, RT-2 and OpenVLA.",
    diff: "Diffusion decoders start from noise and denoise a whole chunk, as in Diffusion Policy, DP3 and Octo.",
    flow: "Flow-matching decoders integrate a learned velocity from noise to a chunk in a few steps, as in π0 and its successors."
  };

  function mountMap(body, ctx) {
    var id = ctx.id;
    var xBtns = XS.map(function (o) { return '<button type="button" value="' + o.v + '" aria-pressed="false">' + o.l + "</button>"; }).join("");
    body.innerHTML =
      '<div class="rb-grid3">' +
      '<div class="rb-stack"><p class="rb-h5">X · what the policy senses</p><div class="sb-seg sb-seg--sm" role="group" aria-label="Inputs X (toggle any)" id="' + id + '-x">' + xBtns + "</div></div>" +
      '<div class="rb-stack"><p class="rb-h5">Z · the internal code</p>' + RB.seg({ id: id + "-z", label: "Latent Z", value: "any", options: ZS }) + "</div>" +
      '<div class="rb-stack"><p class="rb-h5">A · how actions come out</p>' + RB.seg({ id: id + "-a", label: "Decoder A", value: "any", options: AS }) + "</div></div>" +
      '<figure class="rb-fig"><div class="sb-scroll-x"><svg class="rb-svg" id="' + id + '-svg" viewBox="0 0 560 250" style="min-width:480px;max-width:720px" role="img" aria-label="Method map: decoder rows against publication year; filled dots match the selected cells"></svg></div>' +
      '<figcaption class="sb-caption">Filled dots match your X, Z and A choices. Click a dot: dashed lines show which earlier methods on the map it builds on.</figcaption></figure>' +
      '<div class="rb-grid2"><div class="rb-stack">' + RB.readouts([{ id: "n", k: "Methods in these cells" }, { id: "span", k: "Years" }]) +
      '<div class="sb-btn-row" id="' + id + '-list" aria-label="Matching methods"></div><p class="sb-caption" data-note></p></div>' +
      '<div class="rb-well" id="' + id + '-card" aria-live="polite"></div></div>';
    var xEl = body.querySelector("#" + id + "-x"), zEl = body.querySelector("#" + id + "-z"), aEl = body.querySelector("#" + id + "-a");
    var svg = body.querySelector("#" + id + "-svg"), list = body.querySelector("#" + id + "-list"), card = body.querySelector("#" + id + "-card"), note = body.querySelector("[data-note]");
    var st = { x: [], z: "any", a: "any", sel: null };
    var Y0 = 2021, CX = function (y) { return 150 + (y - Y0) * 90; }, RY = function (a) { return 30 + AROW.indexOf(a) * 40; };
    var pos = {};
    (function layout() {
      var cells = {};
      MAP.forEach(function (m) { var k = m.y + "|" + m.a; (cells[k] = cells[k] || []).push(m); });
      Object.keys(cells).forEach(function (k) { var c = cells[k], n = c.length; c.forEach(function (m, i) { pos[m.id] = [CX(m.y) + (i - (n - 1) / 2) * 16, RY(m.a)]; }); });
    })();
    function name(mid) { var m = RB.method(mid); return m ? m.name : mid; }
    function match(m) {
      for (var i = 0; i < st.x.length; i++) if (m.x.indexOf(st.x[i]) < 0) return false;
      return (st.z === "any" || m.z === st.z) && (st.a === "any" || m.a === st.a);
    }
    function setSeg(el, v) { Array.prototype.forEach.call(el.querySelectorAll("button"), function (b) { var on = b.value === v; b.setAttribute("aria-pressed", on ? "true" : "false"); b.tabIndex = on ? 0 : -1; }); }
    function draw() {
      var s = "";
      AROW.forEach(function (a) { s += '<line x1="112" y1="' + RY(a) + '" x2="548" y2="' + RY(a) + '" class="rb-s-line" stroke-dasharray="2 4"/><text x="104" y="' + (RY(a) + 4) + '" text-anchor="end" class="rb-t">' + AROWL[a] + "</text>"; });
      for (var y = Y0; y <= 2025; y++) s += '<text x="' + CX(y) + '" y="236" text-anchor="middle" class="rb-t-mono">' + y + "</text>";
      s += '<text x="104" y="236" text-anchor="end" class="rb-t-mono">A ↓ · year →</text>';
      if (st.sel) {
        var me = MAP.filter(function (m) { return m.id === st.sel; })[0];
        (me ? me.par : []).forEach(function (p) { if (!pos[p]) return; var a = pos[p], b = pos[st.sel]; s += '<path d="M' + a[0] + " " + a[1] + " L" + b[0] + " " + b[1] + '" class="rb-s-acc" stroke-dasharray="4 3"/>'; });
      }
      MAP.forEach(function (m) {
        var p = pos[m.id], on = match(m), sel = m.id === st.sel;
        s += '<g class="rb-a1-dot" data-m="' + m.id + '" role="button" tabindex="0" aria-label="' + RB.esc(name(m.id)) + ", " + m.y + '">' + '<title>' + RB.esc(name(m.id)) + " (" + m.y + ")</title>" +
          (sel ? '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="10" class="rb-s-acc"/>' : "") +
          '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="6" class="' + (on ? "rb-f-acc" : "rb-f-surface") + '" style="cursor:pointer"/></g>';
      });
      if (st.sel) { var q = pos[st.sel]; s += '<text x="' + q[0] + '" y="' + (q[1] - 14) + '" text-anchor="middle" class="rb-t-ink">' + RB.esc(name(st.sel)) + "</text>"; }
      svg.innerHTML = s;
    }
    function showCard() {
      if (!st.sel) { card.innerHTML = '<p class="sb-caption">Click a dot or a method name to see what it changed about its predecessor.</p>'; return; }
      var m = RB.method(st.sel), e = MAP.filter(function (x) { return x.id === st.sel; })[0];
      var xs = e.x.map(function (v) { return XS.filter(function (o) { return o.v === v; })[0].l; }).join(" + ");
      var zl = ZS.filter(function (o) { return o.value === e.z; })[0].label, al = AROWL[e.a];
      card.innerHTML = '<p class="rb-h5">' + RB.esc(m ? m.name : st.sel) + ' <span class="sb-ref">' + e.y + "</span></p>" +
        '<p class="sb-caption"><b>Cells:</b> X = ' + RB.esc(xs) + " · Z = " + RB.esc(zl) + " · A = " + al + "</p>" +
        (m && m.changed ? '<p class="sb-caption"><b>What it changed:</b> ' + RB.esc(m.changed) + "</p>" : "") + (m ? '<p class="sb-caption">' + RB.arxivLink(m) + "</p>" : "");
    }
    function update() {
      var hits = MAP.filter(match);
      RB.setRO(body, "n", hits.length ? String(hits.length) + " of " + MAP.length : "0: an empty cell");
      RB.setRO(body, "span", hits.length ? (hits[0].y === hits[hits.length - 1].y ? String(hits[0].y) : hits[0].y + "–" + hits[hits.length - 1].y) : "–");
      list.innerHTML = hits.length ? hits.map(function (m) { return '<button type="button" class="sb-tag" data-pick="' + m.id + '"' + (m.id === st.sel ? ' aria-current="true"' : "") + ">" + RB.esc(name(m.id)) + "</button>"; }).join("") :
        '<p class="sb-caption">No method on this map sits in these cells. Empty cells are where new combinations get tried.</p>';
      note.textContent = NOTE_A[st.a];
      draw(); showCard();
    }
    function pick(mid) {
      st.sel = mid; update();
    }
    function place(mid) {
      var e = MAP.filter(function (x) { return x.id === mid; })[0]; if (!e) return;
      st.x = e.x.slice(); st.z = e.z; st.a = e.a; st.sel = mid;
      Array.prototype.forEach.call(xEl.querySelectorAll("button"), function (b) { b.setAttribute("aria-pressed", st.x.indexOf(b.value) >= 0 ? "true" : "false"); });
      setSeg(zEl, st.z); setSeg(aEl, st.a); update();
    }
    xEl.addEventListener("click", function (ev) {
      var b = ev.target.closest("button"); if (!b) return;
      var i = st.x.indexOf(b.value); if (i >= 0) st.x.splice(i, 1); else st.x.push(b.value);
      b.setAttribute("aria-pressed", i >= 0 ? "false" : "true"); update();
    });
    RB.bindSeg(body, id + "-z", function (v) { st.z = v; update(); });
    RB.bindSeg(body, id + "-a", function (v) { st.a = v; update(); });
    list.addEventListener("click", function (ev) { var b = ev.target.closest("[data-pick]"); if (b) pick(b.getAttribute("data-pick")); });
    svg.addEventListener("click", function (ev) { var g = ev.target.closest("[data-m]"); if (g) place(g.getAttribute("data-m")); });
    svg.addEventListener("keydown", function (ev) { if (ev.key !== "Enter" && ev.key !== " ") return; var g = ev.target.closest("[data-m]"); if (g) { ev.preventDefault(); place(g.getAttribute("data-m")); } });
    update();
    return { state: function () { return { x: st.x.slice(), z: st.z, a: st.a, sel: st.sel }; }, place: place };
  }

  /* ---------- playground 2: errors pass through a modular chain ---------- */
  var L = 0.2; /* link length in meters (our toy numbers, 2-link planar arm as in X2 §2.3) */
  function fk(t1, t2) { return [L * Math.cos(t1) + L * Math.cos(t1 + t2), L * Math.sin(t1) + L * Math.sin(t1 + t2)]; }
  function ik(p) {
    var c = RB.clamp((p[0] * p[0] + p[1] * p[1] - 2 * L * L) / (2 * L * L), -1, 1), sols = [];
    [-1, 1].forEach(function (e) { var t2 = e * Math.acos(c), t1 = Math.atan2(p[1], p[0]) - Math.atan2(L * Math.sin(t2), L + L * Math.cos(t2)); sols.push([t1, t2]); });
    /* the table forbids a shoulder angle below 0 (X2 Fig. 6b) */
    var ok = sols.filter(function (q) { return q[0] >= 0 && q[0] <= Math.PI; });
    return (ok[0] || sols[0]);
  }

  function mountChain(body, ctx) {
    var id = ctx.id, TOL = 0.010, N = 40, KP = 1.0;
    body.innerHTML = '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Control", value: "open", options: [{ value: "open", label: "Open loop" }, { value: "fb", label: "Feedback" }] }) +
      RB.slider({ id: id + "-bias", label: "Camera bias (mm)", min: 0, max: 20, step: 1, value: 8 }) +
      RB.slider({ id: id + "-enc", label: "Encoder offset (°)", min: 0, max: 3, step: 0.25, value: 1, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-noise", label: "Camera noise (mm)", min: 0, max: 6, step: 0.5, value: 1.5, fmt: function (v) { return (+v).toFixed(1); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New cups ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Left: one reach of a two-link arm toward a cup. Right: where 40 reaches ended relative to their cups"></canvas>' +
      '<figcaption class="sb-caption">Left: one reach; dashed = the arm the planner intended, solid = where it went. Right: 40 reaches, each dot is the gripper miss; inside the ring is a grasp.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "ok", k: "Reaches within 10 mm" }, { id: "mean", k: "Mean miss", u: "mm" }, { id: "max", k: "Largest miss", u: "mm" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "good", label: "grasp (miss < 10 mm)", kind: "dot" }, { c: "bad", label: "miss", kind: "dot" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), W = 560, H = 300, mode = "open", bias = 8, enc = 1, noise = 1.5, seed = 11, res = [];
    var note = body.querySelector("[data-note]");
    function run() {
      var R = RB.rng(seed); res = [];
      var b = [-bias / 1000, 0], d = enc * Math.PI / 180, sd = noise / 1000;
      for (var i = 0; i < N; i++) {
        var cup = [0.19 + 0.11 * R(), 0.07 + 0.12 * R()];
        var seen = function () { return [cup[0] + b[0] + sd * R.normal(), cup[1] + b[1] + sd * R.normal()]; };
        var tgt = seen(), q = ik(tgt), g = fk(q[0] + d, q[1]), plan = q;
        if (mode === "fb") {
          for (var k = 0; k < 5; k++) {
            /* the camera sees cup and gripper in the same image: its bias cancels in the gap, and so does the encoder offset */
            var cs = seen(), gs = [g[0] + b[0] + sd * R.normal(), g[1] + b[1] + sd * R.normal()];
            tgt = [tgt[0] + KP * (cs[0] - gs[0]), tgt[1] + KP * (cs[1] - gs[1])];
            q = ik(tgt); g = fk(q[0] + d, q[1]);
          }
        }
        res.push({ cup: cup, plan: plan, q: q, g: g, miss: [g[0] - cup[0], g[1] - cup[1]] });
      }
      var ms = res.map(function (r) { return Math.hypot(r.miss[0], r.miss[1]); });
      RB.setRO(body, "ok", ms.filter(function (m) { return m < TOL; }).length + " of " + N);
      RB.setRO(body, "mean", RB.fmt(1000 * ms.reduce(function (a, v) { return a + v; }, 0) / N, 1));
      RB.setRO(body, "max", RB.fmt(1000 * Math.max.apply(null, ms), 1));
      note.textContent = mode === "open" ? "Open loop: perception, inverse kinematics and the joint encoders each pass their error on. The errors add up in the gripper." :
        "Feedback: each cycle the camera measures the gripper–cup gap in one image, so the shared camera bias and the encoder offset cancel. Only noise is left (X2 §2.3.1).";
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = "500 11px " + getComputedStyle(document.body).getPropertyValue("--font-mono");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      /* left: one reach */
      var S = 640, bx = 30, by = 250, px = function (p) { return [bx + p[0] * S, by - p[1] * S]; };
      c.strokeStyle = P["line-strong"]; c.lineWidth = 2; c.beginPath(); c.moveTo(10, by); c.lineTo(270, by); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = mono; c.fillText("table", 220, by + 16);
      var r0 = res[0];
      if (r0) {
        var cp = px(r0.cup); c.fillStyle = P["accent-soft"]; c.strokeStyle = P.accent; c.lineWidth = 1.5; c.fillRect(cp[0] - 7, cp[1] - 9, 14, 18); c.strokeRect(cp[0] - 7, cp[1] - 9, 14, 18);
        c.fillStyle = P["ink-3"]; c.fillText("cup", cp[0] + 10, cp[1] - 10);
        var arm = function (q, dash, col) { var e = px([L * Math.cos(q[0]), L * Math.sin(q[0])]), t = px(fk(q[0], q[1])); c.strokeStyle = col; c.lineWidth = dash ? 1.5 : 3; c.setLineDash(dash ? [5, 4] : []); c.beginPath(); c.moveTo(bx, by); c.lineTo(e[0], e[1]); c.lineTo(t[0], t[1]); c.stroke(); c.setLineDash([]); return t; };
        var dd = enc * Math.PI / 180;
        arm(r0.plan, true, P["ink-3"]);
        var t = arm([r0.q[0] + dd, r0.q[1]], false, P["ink-2"]);
        var m0 = Math.hypot(r0.miss[0], r0.miss[1]);
        c.fillStyle = m0 < TOL ? P.good : P.bad; c.beginPath(); c.arc(t[0], t[1], 5, 0, Math.PI * 2); c.fill();
        c.fillStyle = P["ink-2"]; c.beginPath(); c.arc(bx, by, 6, 0, Math.PI * 2); c.fill();
      }
      /* right: miss target */
      var ox = 420, oy = 150, sc = 110 / 25; /* 25 mm = 110 px */
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      c.beginPath(); c.moveTo(ox - 120, oy); c.lineTo(ox + 120, oy); c.moveTo(ox, oy - 120); c.lineTo(ox, oy + 120); c.stroke();
      c.strokeStyle = P.good; c.lineWidth = 2; c.beginPath(); c.arc(ox, oy, 10 * sc, 0, Math.PI * 2); c.stroke();
      c.strokeStyle = P.line; c.lineWidth = 1; c.beginPath(); c.arc(ox, oy, 20 * sc, 0, Math.PI * 2); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = mono; c.fillText("10 mm", ox + 10 * sc + 4, oy - 4); c.fillText("20 mm", ox + 20 * sc - 42, oy - 20 * sc + 14);
      c.fillText("miss (x, y)", ox - 118, oy + 116);
      res.forEach(function (r) {
        var mx = RB.clamp(r.miss[0] * 1000, -26, 26), my = RB.clamp(r.miss[1] * 1000, -26, 26), m = Math.hypot(r.miss[0], r.miss[1]);
        c.fillStyle = m < TOL ? P.good : P.bad; c.globalAlpha = 0.8; c.beginPath(); c.arc(ox + mx * sc, oy - my * sc, 4, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1;
      });
      c.fillStyle = P.ink; c.beginPath(); c.arc(ox, oy, 2.5, 0, Math.PI * 2); c.fill();
    }
    RB.bindSeg(body, id + "-mode", function (v) { mode = v; run(); });
    RB.bindSlider(body, id + "-bias", null, function (v) { bias = v; run(); });
    RB.bindSlider(body, id + "-enc", function (v) { return (+v).toFixed(2); }, function (v) { enc = v; run(); });
    RB.bindSlider(body, id + "-noise", function (v) { return (+v).toFixed(1); }, function (v) { noise = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { mode: mode, bias: bias, enc: enc, noise: noise }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token colors only) ---------- */
  var ART = {
    pomdp: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="96" y="6" width="98" height="44" rx="4" class="rb-f-sunk"/><circle cx="170" cy="28" r="12" class="rb-f-surface" stroke-dasharray="3 3"/><text x="170" y="32" text-anchor="middle" class="rb-t-mono">sₜ</text><rect x="112" y="20" width="18" height="18" rx="2" class="rb-f-soft"/><path d="M28 28 L112 14 M28 28 L112 44" class="rb-s-line"/><rect x="10" y="20" width="20" height="16" rx="3" class="rb-f-surface"/><text x="60" y="52" text-anchor="middle" class="rb-t-acc">oₜ</text><text x="145" y="18" class="rb-t-mono">hidden</text></svg>',
    policy: '<svg viewBox="0 0 200 56" aria-hidden="true"><text x="20" y="32" text-anchor="middle" class="rb-t-mono">oₜ, ℓ</text><path d="M42 28 H70" class="rb-s-ink"/><rect x="72" y="12" width="56" height="32" rx="6" class="rb-f-soft"/><text x="100" y="33" text-anchor="middle" class="rb-t-acc">π_θ</text><path d="M130 28 H158" class="rb-s-ink"/><text x="178" y="32" text-anchor="middle" class="rb-t-mono">aₜ</text></svg>',
    aspace: '<svg viewBox="0 0 200 56" aria-hidden="true"><text x="6" y="15" class="rb-t-mono">high</text><text x="6" y="32" class="rb-t-mono">mid</text><text x="6" y="49" class="rb-t-mono">low</text><rect x="40" y="4" width="40" height="14" rx="3" class="rb-f-sunk"/><rect x="40" y="21" width="90" height="14" rx="3" class="rb-f-soft"/><rect x="40" y="38" width="150" height="14" rx="3" class="rb-f-surface"/><text x="88" y="15" class="rb-t-mono">skill</text><text x="138" y="32" class="rb-t-mono">pose</text><text x="115" y="49" text-anchor="middle" class="rb-t-mono">joint commands</text></svg>',
    layers: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="30" y="3" width="140" height="15" rx="3" class="rb-f-surface"/><rect x="30" y="21" width="140" height="15" rx="3" class="rb-f-soft"/><rect x="30" y="39" width="140" height="15" rx="3" class="rb-f-sunk"/><text x="100" y="14" text-anchor="middle" class="rb-t-mono">plans</text><text x="100" y="32" text-anchor="middle" class="rb-t-acc">actions aₜ</text><text x="100" y="50" text-anchor="middle" class="rb-t-mono">torques 𝛕</text></svg>',
    x: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="4" width="40" height="12" rx="2" class="rb-f-surface"/><rect x="6" y="22" width="40" height="12" rx="2" class="rb-f-surface"/><rect x="6" y="40" width="40" height="12" rx="2" class="rb-f-surface"/><text x="26" y="13" text-anchor="middle" class="rb-t-mono">RGB</text><text x="26" y="31" text-anchor="middle" class="rb-t-mono">ℓ</text><text x="26" y="49" text-anchor="middle" class="rb-t-mono">touch</text><path d="M48 10 L96 28 M48 28 H96 M48 46 L96 28" class="rb-s-line"/><rect x="98" y="16" width="60" height="24" rx="5" class="rb-f-soft"/><text x="128" y="32" text-anchor="middle" class="rb-t-acc">X: fuse</text><path d="M160 28 H192" class="rb-s-ink"/></svg>',
    z: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M20 6 L120 20 L120 36 L20 50 Z" class="rb-f-sunk"/><text x="56" y="32" text-anchor="middle" class="rb-t-mono">features</text><path d="M122 28 H144" class="rb-s-ink"/><circle cx="160" cy="28" r="13" class="rb-f-soft"/><text x="160" y="32" text-anchor="middle" class="rb-t-acc">z</text></svg>',
    a: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="22" cy="28" r="12" class="rb-f-soft"/><text x="22" y="32" text-anchor="middle" class="rb-t-acc">z</text><path d="M36 28 H58" class="rb-s-ink"/><rect x="60" y="16" width="44" height="24" rx="5" class="rb-f-surface"/><text x="82" y="32" text-anchor="middle" class="rb-t-mono">A</text><path d="M106 28 H120" class="rb-s-ink"/>' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (122 + i * 18) + '" y="18" width="15" height="20" rx="2" class="' + (i ? "rb-f-surface" : "rb-f-soft") + '"/>'; }).join("") + '<text x="152" y="52" text-anchor="middle" class="rb-t-mono">aₜ … aₜ₊H</text></svg>',
    chain: '<svg viewBox="0 0 200 56" aria-hidden="true">' + ["see", "plan", "IK", "servo"].map(function (s, i) { return '<rect x="' + (4 + i * 50) + '" y="10" width="40" height="20" rx="3" class="rb-f-surface"/><text x="' + (24 + i * 50) + '" y="24" text-anchor="middle" class="rb-t-mono">' + s + "</text>" + (i < 3 ? '<path d="M' + (45 + i * 50) + ' 20 H' + (53 + i * 50) + '" class="rb-s-ink"/>' : ""); }).join("") + '<path d="M4 40 L196 32 L196 46 Z" class="rb-f-soft"/><text x="4" y="54" class="rb-t-mono">error grows →</text></svg>'
  };

  /* ---------- worked example figure: a classical reach, errors stacking (numbers computed from the toy arm, L = 0.2 m) ---------- */
  var WS = 700, WBX = 70, WBY = 200;
  function wp(p) { return [(WBX + p[0] * WS).toFixed(1), (WBY - p[1] * WS).toFixed(1)]; }
  var WE = (function () {
    var qu = ik([0.25, 0.15]), qBad = [-12.24 * Math.PI / 180, 86.42 * Math.PI / 180], qAct = [qu[0] + Math.PI / 180, qu[1]];
    var el = function (q) { return wp([L * Math.cos(q[0]), L * Math.sin(q[0])]); }, tip = function (q) { return wp(fk(q[0], q[1])); };
    var line = function (q, cls, dash) { var e = el(q), t = tip(q); return '<path d="M' + WBX + " " + WBY + " L" + e[0] + " " + e[1] + " L" + t[0] + " " + t[1] + '" class="' + cls + '"' + (dash ? ' stroke-dasharray="5 4"' : "") + ' stroke-width="3"/>'; };
    var cT = wp([0.258, 0.15]);
    /* zoom inset: 4 px per mm around the true cup at (258, 150) mm */
    var ZX = 460, ZY = 110, zp = function (mmx, mmy) { return [(ZX + (mmx - 258) * 4).toFixed(1), (ZY - (mmy - 150) * 4).toFixed(1)]; };
    var gAct = fk(qAct[0], qAct[1]), gz = zp(gAct[0] * 1000, gAct[1] * 1000), camz = zp(250, 150);
    return '<svg viewBox="0 0 560 270" role="img" aria-label="A two-link arm on a table reaching for a cup, with a zoomed view of the cup showing the camera estimate, the gripper and the miss">' +
      '<line x1="20" y1="' + WBY + '" x2="350" y2="' + WBY + '" class="rb-s-line"/><text x="300" y="' + (WBY + 16) + '" class="rb-t-mono">table</text>' +
      '<circle cx="' + WBX + '" cy="' + WBY + '" r="7" class="rb-f-surface"/><text x="' + WBX + '" y="' + (WBY + 20) + '" text-anchor="middle" class="rb-t-mono">base</text>' +
      '<rect x="' + (+cT[0] - 7) + '" y="' + (+cT[1] - 8) + '" width="14" height="16" rx="2" class="rb-f-soft"/>' +
      '<rect x="' + (+cT[0] - 16) + '" y="' + (+cT[1] - 16) + '" width="32" height="32" class="rb-s-line" stroke-dasharray="2 3"/><path d="M' + (+cT[0] + 16) + " " + (+cT[1] - 16) + ' L370 110" class="rb-s-line" stroke-dasharray="2 3"/>' +
      '<rect x="370" y="20" width="180" height="194" rx="4" class="rb-f-sunk"/><text x="370" y="14" class="rb-t-mono">zoom: 1 mm = 4 px</text>' +
      '<rect x="' + (ZX - 8) + '" y="' + (ZY - 10) + '" width="16" height="20" rx="2" class="rb-f-soft"/><text x="' + ZX + '" y="' + (ZY - 16) + '" text-anchor="middle" class="rb-t-mono">cup</text>' +
      '<g data-on="1+"><path d="M' + (+camz[0] - 5) + " " + (+camz[1] - 5) + " l10 10 m0 -10 l-10 10" + '" class="rb-s-ink"/><text x="378" y="172" class="rb-t-ink">× camera: 8 mm short</text></g>' +
      '<g data-on="2">' + line(qBad, "rb-s-line", true) + '<text x="150" y="264" class="rb-t-mono">rejected: elbow under the table</text></g>' +
      '<g data-on="2+">' + line(qu, "rb-s-ink", true) + '<text x="150" y="18" class="rb-t-acc">q = (74.2°, −86.4°)</text></g>' +
      '<g data-on="3+"><text x="150" y="36" class="rb-t-mono">x(q) = (0.250, 0.150) m</text></g>' +
      '<g data-on="4+">' + line(qAct, "rb-s-acc", false) + '<text x="150" y="54" class="rb-t-acc">+1° at the shoulder: 5.1 mm</text>' +
      '<circle cx="' + gz[0] + '" cy="' + gz[1] + '" r="5" class="rb-f-acc"/><text x="378" y="46" class="rb-t-acc">gripper</text></g>' +
      '<g data-on="5+"><circle cx="' + ZX + '" cy="' + ZY + '" r="40" class="rb-s-line" stroke-dasharray="4 3"/><path d="M' + gz[0] + " " + gz[1] + " L" + ZX + " " + ZY + '" class="rb-s-acc"/><text x="378" y="190" class="rb-t-ink">miss 11.5 mm</text><text x="378" y="206" class="rb-t-mono">ring = 10 mm margin</text></g>' +
      '<g data-on="6"><text x="370" y="234" class="rb-t-ink">feedback measures this</text><text x="370" y="250" class="rb-t-ink">gap in one image</text></g></svg>';
  })();

  RB.topic({
    id: "a1",
    title: "The robot-learning problem",
    eyebrow: "Part A · Foundations",
    lede: "A manipulation policy turns what the robot senses into what it does, step after step. Here is that problem, its layers, and its parts.",
    refs: ["P01 §2.2, §5–6", "X2 §2–4", "P07 §3.2, §5"],
    why: "Classical manipulation chains hand-built modules: perception, planning, inverse kinematics, control. Each interface passes its error on, and each new task or robot means re-engineering. Robot learning replaces part of the chain with a policy fitted to data. For any method in this course, ask: which layer does it sit in, and which part does it change?",
    outcomes: [
      "Write a manipulation task as a POMDP with observations, actions and rewards.",
      "Place a method in one of three layers: planning, action modeling, actuation.",
      "Decompose a learned policy into inputs X, latent Z and decoder A.",
      "Explain why modular classical pipelines break when conditions change.",
      "Compare reinforcement learning and behavior cloning by their training signal."
    ],
    concepts: [
      { name: "Partial observability", def: "The policy sees an observation oₜ, such as images and joint angles, never the full world state sₜ.", ref: "P07 §3.2", art: ART.pomdp, term: "pomdp", sym: "o" },
      { name: "Policy", def: "A learned function π_θ that maps observations and an instruction to actions, called again at every step.", ref: "P01 §2.2.2", art: ART.policy, term: "policy", sym: "pi" },
      { name: "Action space", def: "Joint commands, end-effector targets or whole skills. The choice decides how much a controller or planner does instead.", ref: "P07 App. A.1.1", art: ART.aspace, term: "action-space", sym: "a" },
      { name: "Three layers", def: "Planning outputs plans, action modeling outputs actions, actuation control outputs torques.", ref: "P01 Fig. 12", art: ART.layers, term: "three-layer-stack" },
      { name: "X: input modeling", def: "Which signals the policy senses and how it encodes them: 2D or 3D vision, language, touch.", ref: "P01 §6.2", art: ART.x, term: "input-modeling" },
      { name: "Z: latent learning", def: "A compact internal code: a pretrained visual representation, or latent actions learned from video.", ref: "P01 §6.3", art: ART.z, term: "latent-learning", sym: "z" },
      { name: "A: policy learning", def: "How the code is decoded into actions: regression, tokens, diffusion or flow matching, often over a chunk.", ref: "P01 §6.4", art: ART.a, term: "policy-learning", sym: "achunk" },
      { name: "Modular pipeline", def: "Fixed modules in a chain; an error made early is passed on and adds to later errors.", ref: "X2 §2.4, Fig. 8", art: ART.chain, term: "modular-pipeline" }
    ],
    flow: {
      title: "Where a learned policy sits", ref: "P01 Fig. 12", w: 820, h: 300,
      caption: "Three layers split by what they output: plans, actions, torques. The loop closes through the world, which the robot only sees in part.",
      nodes: [
        { id: "instr", x: 20, y: 24, w: 150, h: 56, label: "Instruction ℓ", sub: "“put the cup away”", kind: "env" },
        { id: "plan", x: 235, y: 24, w: 175, h: 56, label: "High-level planner", sub: "LLM, code, affordance", kind: "decision" },
        { id: "obs", x: 20, y: 140, w: 150, h: 60, label: "Observation oₜ", sub: "images, joints", kind: "env" },
        { id: "pol", x: 240, y: 140, w: 165, h: 60, label: "Action model π_θ", sub: "X → Z → A", kind: "agent" },
        { id: "ctrl", x: 480, y: 140, w: 150, h: 60, label: "Actuation", sub: "position, impedance", kind: "agent" },
        { id: "world", x: 700, y: 140, w: 110, h: 60, label: "Robot, world", sub: "objects", kind: "env" }
      ],
      edges: [
        { from: "instr", to: "plan", label: "task" },
        { from: "plan", to: "pol", label: "subgoal", sides: ["b", "t"] },
        { from: "obs", to: "pol", label: "oₜ" },
        { from: "pol", to: "ctrl", label: "aₜ" },
        { from: "ctrl", to: "world", label: "𝛕" },
        { from: "world", to: "obs", label: "new observation", sides: ["b", "b"], via: [[755, 270], [95, 270]], dy: -6 }
      ],
      steps: [
        { on: ["instr", "instr>plan", "plan"], text: "A high-level planner turns the instruction into an intermediate artifact: subtasks, code, geometric constraints or an affordance map (P01 §5)." },
        { on: ["obs", "obs>pol", "plan>pol", "pol"], text: "The low-level action model reads the observation and the plan and outputs executable actions. Most of this course is about this box." },
        { on: ["pol>ctrl", "ctrl"], text: "An actuation-level controller turns actions, such as end-effector targets, into joint position, velocity or torque commands." },
        { on: ["ctrl>world", "world"], text: "The robot moves and the world changes: objects slide, contacts open and close. Much of this is never measured directly." },
        { on: ["world>obs", "obs"], text: "A new observation closes the loop. Because it shows only part of the state, the problem is partially observable." }
      ]
    },
    worked: {
      title: "A classical reach, and where it breaks",
      ref: "X2 §2.3, eq. 1", prov: "Our toy numbers: 2-link arm, links 0.2 m",
      eq: { tex: "\\class{sym-x}{x}(\\class{sym-qj}{q}) = \\begin{pmatrix} l\\cos\\theta_1 + l\\cos(\\theta_1+\\theta_2) \\\\ l\\sin\\theta_1 + l\\sin(\\theta_1+\\theta_2) \\end{pmatrix}", words: "Forward kinematics: the joint angles give the gripper position. Inverse kinematics (IK) solves this backward for the angles.", key: ["x", "qj", { glyph: "l", meaning: "link length, here 0.2 m" }, { glyph: "θ₁, θ₂", meaning: "shoulder and elbow angles" }] },
      figure: WE,
      steps: [
        { title: "Perception estimates the cup", text: "After a lighting change the camera places the cup at (250, 150) mm. It is really at (258, 150): an 8 mm error." },
        { title: "IK has two answers", text: "Solving for (250, 150) gives (−12.2°, 86.4°) or (74.2°, −86.4°). The table forbids a negative shoulder angle, so the planner keeps the second." },
        { title: "Forward kinematics checks out", text: "0.2·cos 74.2° + 0.2·cos(−12.2°) = 0.250 and 0.2·sin 74.2° + 0.2·sin(−12.2°) = 0.150. The plan is exact for the estimate." },
        { title: "The encoder is 1° off", text: "The shoulder turns 1° further than it reports. At 0.29 m from the base that moves the gripper 5.1 mm, to (247, 154) mm." },
        { title: "Errors add up", text: "The gripper misses the true cup by 11.5 mm. With a 10 mm margin, the grasp fails, though each module alone stayed inside it." },
        { title: "Close the loop", text: "Measuring the gripper–cup gap in one image cancels both errors. Learned visuomotor policies build this coupling of perception and action in (X2 §3)." }
      ]
    },
    ruleTitle: "Three ways to write the problem",
    rules: [
      { name: "Reinforcement learning objective", ref: "P01 eq. 2",
        tex: "\\class{sym-pi}{\\pi_\\theta}^{*} = \\arg\\max_{\\class{sym-pi}{\\pi_\\theta}}\\; \\class{sym-E}{\\mathbb{E}}\\Big[\\sum_{t} \\class{sym-gamma}{\\gamma}^{t}\\, \\class{sym-r}{r_t}\\Big], \\qquad \\class{sym-a}{a_t} \\sim \\class{sym-pi}{\\pi_\\theta}(\\cdot \\mid \\class{sym-o}{o_t})",
        words: "Reinforcement learning (RL) picks the policy whose actions earn the most discounted reward over time, learned by trial and error.",
        key: ["pi", "E", "gamma", "r", "a", "o"] },
      { name: "From solving IK to fitting a policy", ref: "X2 eq. 1 → P01 eq. 3", term: "inverse-kinematics",
        before: "\\min_{\\class{sym-qj}{q}}\\; \\big\\| \\class{sym-x}{x}(\\class{sym-qj}{q}) - \\class{sym-x}{x}^{*} \\big\\|^{2}",
        tex: "\\min_{\\class{sb-chg}{\\theta}}\\; \\class{sb-new}{\\class{sym-E}{\\mathbb{E}}_{(\\class{sym-o}{o_t}, \\class{sym-a}{a_t}) \\sim \\class{sym-D}{\\mathcal{D}}}}\\; \\class{sym-L}{\\mathcal{L}}\\big(\\class{sb-chg}{\\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o_t})},\\ \\class{sym-a}{a_t}\\big)",
        words: "IK solves for one configuration per target with a known model. Behavior cloning (BC) fits one function to many demonstrated pairs, with no model.",
        key: ["qj", "x", "E", "o", "a", "D", "L", "pi"], diff: true, beforeLabel: "Classical IK", afterLabel: "Behavior cloning" },
      { name: "A learned action model: X → Z → A", ref: "P01 Fig. 1, §6", prov: "Our notation for P01's taxonomy",
        tex: "\\class{sym-z}{z} = \\mathrm{enc}_X\\big(\\class{sym-o}{o_t}, \\class{sym-l}{\\ell}\\big), \\qquad \\class{sym-achunk}{\\mathbf{a}_{t:t+H}} = \\mathrm{dec}_A\\big(\\class{sym-z}{z}\\big)",
        words: "Encode and fuse the inputs into a code z, then decode z into an action or a chunk of actions.",
        key: ["z", { glyph: "enc_X", meaning: "input modeling: encode and fuse" }, "o", "l", "achunk", { glyph: "dec_A", meaning: "policy learning: decode to actions" }] }
    ],
    algorithm: {
      title: "One control step of a learned stack", ref: "P01 Fig. 12", prov: "Our summary",
      lines: [
        '<span class="kw">input</span> instruction <span data-sym="l">ℓ</span>, observation <span data-sym="o">oₜ</span>',
        'plan ← planner(<span data-sym="l">ℓ</span>, <span data-sym="o">oₜ</span>) <span class="cm">// high level, slow; optional</span>',
        '<span data-sym="z">z</span> ← enc<sub>X</sub>(<span data-sym="o">oₜ</span>, <span data-sym="l">ℓ</span>, plan) <span class="cm">// input modeling, latent</span>',
        '<span data-sym="achunk">aₜ:ₜ₊H</span> ← dec<sub>A</sub>(<span data-sym="z">z</span>) <span class="cm">// policy learning</span>',
        '<span class="kw">for</span> each <span data-sym="a">a</span> in the chunk: controller tracks <span data-sym="a">a</span> <span class="cm">// actuation, fast</span>',
        'observe <span data-sym="o">oₜ₊₁</span> and repeat'
      ]
    },
    playgrounds: [
      {
        id: "map", title: "Find a method's cell: X → Z → A", ref: "P01 Fig. 1, 17, 20 · method cards", prov: "Our classification from the method cards",
        try: "Toggle Touch under X: two methods remain. Clear it, then switch A between Tokens, Diffusion and Flow and watch the years move. Click any dot to see its cells and predecessors.",
        mount: mountMap,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a1-map";
          return [
            { target: q("#" + id + "-x"), title: "Pick an input", text: "X is what the policy senses. Add touch: only methods that read a tactile sensor stay filled.", do: function (a) { return a.click(q("#" + id + '-x [value="touch"]')); }, task: "Toggle Touch under X", expect: function () { return api.state().x.indexOf("touch") >= 0; } },
            { target: q("#" + id + "-list"), title: "Two methods use touch", text: "Tactile-VLA adds a tactile token to π0; FuSe adds touch and audio encoders to Octo. Both keep the rest of their parent." },
            { target: q("#" + id + "-x"), title: "Clear the input", text: "Remove Touch again so every input counts.", do: function (a) { return a.click(q("#" + id + '-x [value="touch"]')); }, task: "Toggle Touch off", expect: function () { return api.state().x.indexOf("touch") < 0; } },
            { target: q("#" + id + "-a"), title: "Tokens came first", text: "RT-1, RT-2 and OpenVLA predict actions as discrete tokens, one step at a time.", do: function (a) { return a.click(q("#" + id + '-a [value="tok"]')); }, task: "Choose Tokens under A", expect: function () { return api.state().a === "tok"; } },
            { target: q("#" + id + "-a"), title: "Flow came later", text: "From 2024, π0 and its successors decode continuous chunks with flow matching instead of tokens.", do: function (a) { return a.click(q("#" + id + '-a [value="flow"]')); }, task: "Choose Flow under A", expect: function () { return api.state().a === "flow"; } },
            { target: q("#" + id + "-svg"), title: "Follow a lineage", text: "Click π0's dot. Dashed lines lead back to ACT and OpenVLA, the two methods it combined.", do: function () { api.place("pi0"); }, task: "Click the π0 dot", expect: function () { return api.state().sel === "pi0"; } },
            { target: q("#" + id + "-z"), title: "Your turn", text: "Choose Latent actions under Z, then 3D under X. The cell is empty: no method here uses both yet." }
          ];
        }
      },
      {
        id: "chain", title: "Errors pass through a modular chain", ref: "X2 §2.3–2.4", prov: "Simplified: 2-link planar arm, 40 random cups",
        try: "With the defaults, open-loop reaches often miss. Set Camera bias to 0, then back to 12. Then switch to Feedback and raise the bias again.",
        mount: mountChain,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a1-chain";
          return [
            { target: q("canvas"), title: "Forty reaches", text: "Each dot on the right is one reach: how far the gripper stopped from its cup. Inside the green ring the grasp works." },
            { target: q("#" + id + "-bias"), title: "Remove the camera bias", text: "With perfect perception, only the 1° encoder offset is left, and most reaches land.", do: function (a) { return a.set(q("#" + id + "-bias"), 0); }, task: "Set Camera bias to 0", expect: function () { return api.state().bias <= 1; } },
            { target: q("#" + id + "-bias"), title: "A lighting change", text: "A 12 mm bias shifts every estimate the same way. The planner trusts it, and the whole cloud moves.", do: function (a) { return a.set(q("#" + id + "-bias"), 12); }, task: "Set Camera bias to 12", expect: function () { return api.state().bias >= 10; } },
            { target: q("#" + id + "-mode"), title: "Couple sensing and acting", text: "Feedback measures the gripper–cup gap in one image each cycle. Shared biases cancel.", do: function (a) { return a.click(q("#" + id + '-mode [value="fb"]')); }, task: "Choose Feedback", expect: function () { return api.state().mode === "fb"; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Raise Camera noise to 6 mm. Feedback cannot remove noise that differs between frames; misses grow again." }
          ];
        }
      }
    ],
    methods: ["bc-z", "rt-1", "rt-2", "openvla", "act", "diffusion-policy", "pi0", "r3m", "lapa"],
    methodsLede: "This is a framework topic; its methods are taught in later topics. The featured rows trace one path through the map: BC-Z regressed single actions, RT-1 turned actions into tokens, RT-2 and OpenVLA produced those tokens with a vision-language model, ACT and Diffusion Policy predicted chunks with generative heads, and π0 joined a vision-language model to a flow-matching head.",
    open: [
      { title: "End-to-end or modular?", text: "Whether one learned policy or a hybrid of learned and classical modules works better varies by problem; neither is superior everywhere.", refs: "P07 §5" },
      { title: "Choosing the action space", text: "Manipulation work uses joint, task-space and skill actions, but principled studies and guidelines for choosing among them are still lacking.", refs: "P07 §5, App. A.1.1" },
      { title: "No scaling law yet", text: "Robot learning has not shown a reliable scaling law like language and vision, because physical data are costly and simulation is limited.", refs: "P01 §1.2" },
      { title: "A robot brain", text: "A general architecture that joins perception, reasoning, action generation and control in one system does not exist yet.", refs: "P01 §1.2" }
    ],
    takeaways: [
      "Manipulation is a partially observed sequential decision problem: a policy maps observations and an instruction to actions, again and again.",
      "P01 splits methods into three layers by output: plans, actions and motor torques. Most learned policies live in the middle layer.",
      "A learned action model has three parts: inputs X, latent Z and decoder A. Most new methods change one part of a predecessor.",
      "Classical pipelines chain fixed modules, so errors pass on and add; learning couples perception and action through data instead.",
      "Reinforcement learning learns from reward; behavior cloning learns from demonstrations. Both fill the same policy slot."
    ],
    quiz: [
      { q: "A camera sees the cup but not its mass or the friction under it. Which formulation fits?", options: ["A fully observed Markov decision process", "A partially observable Markov decision process (POMDP)", "A supervised classification problem", "A shortest-path search"], correct: 1, why: "The policy acts on observations that reveal only part of the state. P07 §3.2 notes that RL problems for robots are typically modeled as POMDPs." },
      { q: "In P01's three layers, which layer outputs motor torques?", options: ["High-level planning", "Low-level action modeling", "Actuation-level control", "The demonstration dataset"], correct: 2, why: "P01 Fig. 12: planning outputs structured artifacts, action modeling outputs actions or trajectories, and actuation-level control outputs motor torques." },
      { q: "OpenVLA-OFT replaced OpenVLA's discrete tokens with continuous chunks trained with L1. Which part changed most?", options: ["X, the inputs", "Z, the latent code", "A, the action decoder", "Nothing: it is a planner"], correct: 2, why: "The decoder went from autoregressive 256-bin tokens to parallel L1 chunks (arXiv 2502.19645). It also added wrist views and proprioception to X." },
      { q: "In the worked example each module stayed within 10 mm. Why did the grasp still fail?", options: ["IK picked a random solution", "Errors from perception and the encoder added up in the gripper", "The controller ignored the target", "Forward kinematics was wrong"], correct: 1, why: "Each module trusted the previous one's output. An 8 mm perception error and a 5.1 mm encoder shift combined into an 11.5 mm miss (X2 §2.4)." },
      { q: "What training signal does behavior cloning use, compared with reinforcement learning?", options: ["Rewards from trial and error", "Expert observation-action pairs, with no reward", "A physics model of the robot", "Language instructions only"], correct: 1, why: "P01 eq. 3 fits the policy to expert action labels; RL (eq. 2) maximizes discounted reward collected through interaction." }
    ],
    cards: [
      { front: "What are the three layers of P01's method taxonomy?", back: "High-level planning (plans, code, affordances), low-level action modeling (actions or trajectories) and actuation-level control (motor torques).", ref: "P01 Fig. 12" },
      { front: "What do X, Z and A stand for?", back: "Input modeling (what to sense, how to encode it), latent learning (a compact code) and policy learning (decoding the code into actions).", ref: "P01 Fig. 1, §6" },
      { front: "Which four limitations of dynamics-based robotics does X2 list?", back: "Integrating many modules, custom pipelines per modality and task, simplified physics models, and no benefit from growing robot datasets.", ref: "X2 Fig. 8" },
      { front: "What are low-, mid- and high-level action spaces?", back: "Joint or motor commands; task-space commands such as end-effector poses; temporally extended skills such as grasping an object.", ref: "P07 App. A.1.1" },
      { front: "Why is inverse kinematics alone not enough to execute a reach?", back: "It gives one goal configuration, not a trajectory, and its feasible set changes with every obstacle in the scene.", ref: "X2 §2.3" },
      { front: "Which two failure modes does X2 name for point-estimate behavior cloning?", back: "Compounding errors from covariate shift, and averaging across the modes of multimodal demonstrations.", ref: "X2 §4" }
    ],
    terms: {
      "pomdp": { name: "partially observable Markov decision process", aliases: ["POMDP", "partial observability"], group: "foundations", sym: "oₜ", symTex: "o_t", def: "A sequential decision problem in which the agent receives observations that reveal only part of the true state; RL problems for robots are typically modeled this way.", note: "An MDP assumes the state is seen. Cameras, occlusion and unmeasured friction make manipulation partially observable.", ref: "P07 §3.2", scene: "system", focus: ["camera-image", "proprio"], look: "the camera sees only part", uses: [] },
      "policy": { name: "policy", aliases: ["visuomotor policy", "control policy"], group: "foundations", sym: "π_θ", symTex: "\\pi_\\theta", def: "A learned mapping from observations, robot state and an optional task specification to executable actions or action sequences.", note: "A policy is called at every control step; a plan is made once and followed.", ref: "P01 §2.2.2", scene: "system", focus: ["vision-encoder", "action-head"], look: "from encoder to action head", uses: ["pomdp"] },
      "action-space": { name: "action space", aliases: ["low-level actions", "mid-level actions", "high-level actions"], group: "actions", sym: "aₜ", symTex: "a_t", def: "The set of commands a policy can output: low-level joint commands, mid-level task-space commands such as end-effector poses, or high-level temporally extended skills.", note: "Mid-level actions need an external controller, such as IK, to reach the joints.", ref: "P07 App. A.1.1", scene: "robot", focus: ["joint", "end-effector"], look: "joints versus the end effector", uses: [] },
      "three-layer-stack": { name: "three-layer method stack", aliases: ["planning, action modeling, actuation"], group: "foundations", def: "P01's split of manipulation methods by output: high-level planning makes plans, low-level action modeling makes actions, actuation-level control makes motor torques.", note: "The split follows the interface a module exposes, not how it computes.", ref: "P01 Fig. 12", scene: "system", focus: ["planner", "action-head", "controller"], look: "planner above policy above controller", uses: ["high-level-planning", "low-level-action-modeling", "actuation-level-control"] },
      "high-level-planning": { name: "high-level planning", aliases: ["task planning", "planner"], group: "vla", def: "Methods that produce task-level plans or intermediate artifacts, such as subtasks, programs, constraints, affordances or 3D scene structure, to guide action generation.", note: "A planner decides what to do and in what order, not the motor commands.", ref: "P01 §5", scene: "system", focus: ["planner", "instruction"], look: "the planner reading the instruction", uses: [] },
      "low-level-action-modeling": { name: "low-level action modeling", aliases: ["action model", "action generation"], group: "foundations", def: "Methods that transform goals, states or observations into executable paths, trajectories, actions or action sequences, either analytically, by optimization, or by learning.", note: "Model predictive control belongs here too, because its output is a sequence of actions.", ref: "P01 §2.2", scene: "system", focus: ["action-head", "action-chunk"], look: "the action head and its chunk", uses: ["policy"] },
      "actuation-level-control": { name: "actuation-level control", aliases: ["low-level controller", "servo loop"], group: "contact", def: "Controllers that convert actions into joint position, velocity, force or torque commands, such as joint-space or impedance control.", note: "It runs faster than the policy and is usually not learned.", ref: "P01 §1.1, Fig. 12", scene: "system", focus: ["controller", "robot"], look: "the controller driving the robot", uses: [] },
      "input-modeling": { name: "input modeling", aliases: ["X", "input modality"], group: "vla", def: "Choosing which sensory and contextual signals a policy uses, such as vision, language, touch, force or audio, and how they are encoded and fused.", note: "Adding a modality usually means a new encoder, not a new decoder.", ref: "P01 §6.2", scene: "system", focus: ["camera-image", "instruction", "vision-encoder"], look: "inputs entering the encoder", uses: [] },
      "latent-learning": { name: "latent learning", aliases: ["Z", "latent representation", "latent actions"], group: "learning", sym: "z", symTex: "z", def: "Learning compact, transferable internal representations for action models: pretrained visual representations or latent actions inferred from video.", note: "Latent actions let action-free video supervise a policy; they are not robot commands.", ref: "P01 §6.3", scene: "system", focus: ["latent"], look: "the latent code between encoder and head", uses: ["input-modeling"] },
      "policy-learning": { name: "policy learning", aliases: ["A", "action decoder"], group: "heads", def: "How a policy decodes its representation into executable actions: MLP, transformer, diffusion, flow-matching and other decoders.", note: "In P01 'policy learning' names the decoder family, not the training signal.", ref: "P01 §6.4", scene: "system", focus: ["action-head"], look: "the action head", uses: ["latent-learning", "action-chunk"] },
      "modular-pipeline": { name: "modular pipeline", aliases: ["classical pipeline", "sense-plan-act"], group: "foundations", def: "Sensing, state estimation, mapping, planning, IK and low-level control developed as separate modules with fixed interfaces.", note: "Brittleness and compounding errors appear when conditions change, for example lighting or sensor failure.", ref: "X2 §2.4", scene: "system", focus: ["planner", "controller"], look: "a chain of separate modules", uses: ["inverse-kinematics"] },
      "inverse-kinematics": { name: "inverse kinematics", aliases: ["IK", "forward kinematics", "FK"], group: "contact", sym: "x(q)", symTex: "x(q)", def: "Finding a joint configuration q whose end-effector pose x(q) matches a target; forward kinematics computes x(q) from q.", note: "IK can have several solutions or none; obstacles and the table change which ones are feasible.", ref: "X2 §2.3, eq. 1", scene: "robot", focus: ["arm", "joint", "target-pose"], look: "arm angles that reach the target", uses: [] }
    },
    ledger: [
      { where: "Topic 01 · problem formulation", source: "P01 eq. 1 writes the problem as an MDP over states; P07 §3.2 says robot RL problems are typically POMDPs", page: "This site uses the POMDP view and writes policies as π_θ(a | oₜ)", why: "Robots act on camera images and joint readings, not on the full state.", kind: "Sources disagree" },
      { where: "Topic 01 · playground 1", source: "P01 lists methods by section (VLAs under input modeling §6.2.2, R3M and VC-1 under MLP policies §6.4.1)", page: "Each method gets one X, Z and A cell read from its method card", why: "One grid shows all three axes at once; a few placements are judgment calls.", kind: "Our choice" },
      { where: "Topic 01 · worked example and IK rule", source: "X2 §2.3 writes the end-effector position as p(q) and the target as p*", page: "The site writes x(q) and x*", why: "House notation uses x for the end-effector position.", kind: "Our choice" },
      { where: "Topic 01 · worked example and playground 2", source: "X2 §2.3 uses the SO-100 reduced to a 2-link planar arm with equal links l", page: "Links of 0.2 m, a 10 mm grasp margin and error sizes are ours", why: "Round numbers make the error stacking easy to compute by hand.", kind: "Simplified" },
      { where: "Topic 01 · RL rule", source: "P01 eq. 2 writes R(sₜ, aₜ) and a policy over states", page: "The site writes rₜ and conditions the policy on oₜ", why: "House notation and the POMDP view.", kind: "Our choice" }
    ]
  });
})();
