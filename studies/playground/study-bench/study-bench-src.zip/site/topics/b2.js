/* Topic 06 · Generative policy heads (exemplar topic: follow this file's structure). Sources: X2 §4, P01 §6.4, method papers. */
(function () {
  "use strict";
  var RB = window.RB;

  /* ---------- playground: one observation, two ways around an obstacle ---------- */
  /* Toy: demonstrations pass the obstacle on the left or the right. Each head is given the exact
     (ideal) model of that demonstration distribution, so differences come only from the head's form and sampling. */
  var MODES = [{ w: 0.5, m: [-0.62, 0.78] }, { w: 0.5, m: [0.62, 0.78] }], S = 0.07; /* action = normalized (dx, dy) */

  function flowV(x, t) {
    var sig2 = t * t * S * S + (1 - t) * (1 - t), rs = [], Z = 0;
    MODES.forEach(function (c) { var d0 = x[0] - t * c.m[0], d1 = x[1] - t * c.m[1]; var r = c.w * Math.exp(-(d0 * d0 + d1 * d1) / (2 * sig2)); rs.push(r); Z += r; });
    var v = [0, 0];
    MODES.forEach(function (c, i) { var r = rs[i] / Z; for (var j = 0; j < 2; j++) { var d = x[j] - t * c.m[j]; var Ea = c.m[j] + t * S * S / sig2 * d, Ee = (1 - t) / sig2 * d; v[j] += r * (Ea - Ee); } });
    return v;
  }
  function epsHat(x, ab) {
    var sig2 = ab * S * S + 1 - ab, sa = Math.sqrt(ab), rs = [], Z = 0;
    MODES.forEach(function (c) { var d0 = x[0] - sa * c.m[0], d1 = x[1] - sa * c.m[1]; var r = c.w * Math.exp(-(d0 * d0 + d1 * d1) / (2 * sig2)); rs.push(r); Z += r; });
    var e = [0, 0];
    MODES.forEach(function (c, i) { var r = rs[i] / Z; for (var j = 0; j < 2; j++) e[j] += r * Math.sqrt(1 - ab) / sig2 * (x[j] - sa * c.m[j]); });
    return e;
  }
  function abar(u) { var s = 0.008, f = function (v) { return Math.cos((v + s) / (1 + s) * Math.PI / 2) * Math.cos((v + s) / (1 + s) * Math.PI / 2); }; return Math.max(1e-4, Math.min(0.9999, f(u) / f(0))); }

  /* returns {pts:[[x,y]], paths:[[[x,y]...]]} */
  function sample(head, n, K, seed) {
    var R = RB.rng(seed), pts = [], paths = [];
    for (var i = 0; i < n; i++) {
      var path = [];
      if (head === "mse") { var mean = [0, 0]; MODES.forEach(function (c) { mean[0] += c.w * c.m[0]; mean[1] += c.w * c.m[1]; }); pts.push(mean); paths.push([mean]); continue; }
      if (head === "cvae") { var z = R.normal(), sg = 1 / (1 + Math.exp(-10 * z)); var a = [MODES[0].m[0] + (MODES[1].m[0] - MODES[0].m[0]) * sg + S * R.normal(), MODES[0].m[1] + S * R.normal()]; pts.push(a); paths.push([[z * 0.35, 0.05], a]); continue; }
      var x = [R.normal(), R.normal()]; path.push(x.slice());
      if (head === "flow") {
        for (var k = 0; k < K; k++) { var t = k / K, v = flowV(x, t); x = [x[0] + v[0] / K, x[1] + v[1] / K]; path.push(x.slice()); }
      } else { /* DDPM ancestral sampling on a cosine schedule with K steps */
        for (var k2 = K; k2 >= 1; k2--) {
          var ab = abar(k2 / K), abp = k2 > 1 ? abar((k2 - 1) / K) : 1, al = ab / abp, be = 1 - al, e = epsHat(x, ab);
          var mu = [(x[0] - be / Math.sqrt(1 - ab) * e[0]) / Math.sqrt(al), (x[1] - be / Math.sqrt(1 - ab) * e[1]) / Math.sqrt(al)];
          var sd = k2 > 1 ? Math.sqrt(be * (1 - abp) / (1 - ab)) : 0;
          x = [mu[0] + sd * R.normal(), mu[1] + sd * R.normal()]; path.push(x.slice());
        }
      }
      pts.push(x); paths.push(path);
    }
    return { pts: pts, paths: paths };
  }
  function classify(p) {
    /* a sampled action is valid if it passes clearly left or right of the obstacle */
    if (Math.abs(p[0]) < 0.28 && p[1] > 0.25) return "hit";
    if (p[1] < 0.25) return "short";
    return p[0] < 0 ? "left" : "right";
  }

  function mountHeads(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-head", label: "Policy head", value: "flow", options: [{ value: "mse", label: "Regression" }, { value: "cvae", label: "CVAE" }, { value: "ddpm", label: "Diffusion" }, { value: "flow", label: "Flow" }] }) +
      RB.slider({ id: id + "-k", label: "Steps K", min: 1, max: 50, step: 1, value: 10 }) + RB.slider({ id: id + "-n", label: "Samples", min: 10, max: 200, step: 10, value: 80 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-paths" checked> <span>Show sampling paths</span></label><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Sample again ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Workspace with an obstacle; dots are sampled actions from the start point"></canvas><figcaption class="sb-caption">Gray block = obstacle. Faint arrows = demonstrations (left and right). Dots = sampled actions; lines = their sampling paths from noise.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "valid", k: "Pass the obstacle" }, { id: "hit", k: "Into the obstacle" }, { id: "split", k: "Left / right" }, { id: "nfe", k: "Network calls per action" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "passes left", kind: "dot" }, { c: "data-2", label: "passes right", kind: "dot" }, { c: "bad", label: "hits or stops short", kind: "dot" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), head = "flow", K = 10, N = 80, seed = 7, showPaths = true, last = null;
    var W = 520, H = 360;
    var note = body.querySelector("[data-note]");
    var NOTES = {
      mse: "Regression predicts one action: the average of the demonstrations. The average of left and right is straight ahead, into the obstacle (X2 §4).",
      cvae: "A conditional VAE samples a latent z and decodes it into one mode. ACT uses this idea to model variation in human demonstrations (X2 eq. 50).",
      ddpm: "Diffusion starts from noise and removes it in K stochastic steps. With few steps the samples stay noisy; Diffusion Policy uses 100 steps in simulation, 16 with DDIM on the robot.",
      flow: "Flow matching integrates a learned velocity field from noise to data. Its paths are straighter, so fewer steps suffice; π0 uses 10 Euler steps."
    };
    function toPx(a) { return [W / 2 + a[0] * 200, H - 40 - a[1] * 330]; }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H);
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (var gx = 0; gx <= W; gx += 40) { c.beginPath(); c.moveTo(gx, 0); c.lineTo(gx, H); c.stroke(); }
      for (var gy = 0; gy <= H; gy += 40) { c.beginPath(); c.moveTo(0, gy); c.lineTo(W, gy); c.stroke(); }
      var o0 = toPx([-0.26, 0.62]), o1 = toPx([0.26, 0.26]);
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.fillRect(o0[0], o0[1], o1[0] - o0[0], o1[1] - o0[1]); c.strokeRect(o0[0], o0[1], o1[0] - o0[0], o1[1] - o0[1]);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + getComputedStyle(document.body).getPropertyValue("--font-mono"); c.fillText("obstacle", o0[0] + 22, o0[1] + 44);
      var st = toPx([0, 0]);
      MODES.forEach(function (m) { var e = toPx(m.m); c.strokeStyle = P["ink-3"]; c.setLineDash([4, 4]); c.beginPath(); c.moveTo(st[0], st[1]); c.lineTo(e[0], e[1]); c.stroke(); c.setLineDash([]); });
      if (last) {
        var col = function (k) { return k === "left" ? P["data-1"] : k === "right" ? P["data-2"] : P.bad; };
        if (showPaths) last.paths.forEach(function (p, i) { if (p.length < 2) return; c.strokeStyle = col(classify(last.pts[i])); c.globalAlpha = 0.28; c.beginPath(); p.forEach(function (q, j) { var r = toPx([q[0] * 0.5 + (j / (p.length - 1)) * 0, q[1] * 0.5]); var z = toPx(q); if (j === 0) c.moveTo(z[0], z[1]); else c.lineTo(z[0], z[1]); }); c.stroke(); c.globalAlpha = 1; });
        last.pts.forEach(function (p) { var z = toPx(p); c.fillStyle = col(classify(p)); c.beginPath(); c.arc(z[0], z[1], head === "mse" ? 7 : 4, 0, Math.PI * 2); c.fill(); });
      }
      c.fillStyle = P.ink; c.beginPath(); c.arc(st[0], st[1], 6, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + getComputedStyle(document.body).getPropertyValue("--font-body"); c.fillText("start", st[0] + 10, st[1] + 4);
    }
    function run() {
      last = sample(head, head === "mse" ? 1 : N, K, seed);
      var n = last.pts.length, cnt = { left: 0, right: 0, hit: 0, short: 0 };
      last.pts.forEach(function (p) { cnt[classify(p)]++; });
      RB.setRO(body, "valid", Math.round(100 * (cnt.left + cnt.right) / n) + "%");
      RB.setRO(body, "hit", Math.round(100 * (cnt.hit + cnt.short) / n) + "%");
      RB.setRO(body, "split", head === "mse" ? "– / –" : cnt.left + " / " + cnt.right);
      RB.setRO(body, "nfe", head === "mse" || head === "cvae" ? "1" : String(K));
      note.textContent = NOTES[head];
      body.querySelector("#" + id + "-k").disabled = head === "mse" || head === "cvae";
      draw();
    }
    RB.bindSeg(body, id + "-head", function (v) { head = v; run(); });
    RB.bindSlider(body, id + "-k", null, function (v) { K = v; run(); });
    RB.bindSlider(body, id + "-n", null, function (v) { N = v; run(); });
    body.querySelector("#" + id + "-paths").addEventListener("change", function (e) { showPaths = e.target.checked; draw(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { set: function (h, k) { head = h; if (k) K = k; run(); }, state: function () { return { head: head, K: K }; } };
  }

  /* ---------- playground 2: chunking and temporal ensembling (ACT) ---------- */
  function mountChunks(body, ctx) {
    var id = ctx.id;
    body.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-h", label: "Chunk size k", min: 1, max: 50, step: 1, value: 1 }) + RB.slider({ id: id + "-noise", label: "Prediction noise", min: 0, max: 0.2, step: 0.01, value: 0.06, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-ens"> <span>Temporal ensembling</span></label><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Run 20 rollouts ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Twenty rollouts tracking a reference path"></canvas><figcaption class="sb-caption">Dashed = the demonstrated path. Each colored line is one rollout. A policy called every step compounds its small errors; chunks commit to a plan for k steps.</figcaption></figure><div class="rb-stack">' +
      RB.readouts([{ id: "succ", k: "Rollouts that reach the slot" }, { id: "calls", k: "Policy calls per rollout" }, { id: "jerk", k: "Mean jerk" }]) + '<p class="sb-caption">Illustrative: a 1-D tracking toy with a policy whose error drifts with the state it visits. ACT reports 1% → 44% success when the chunk grows from 1 to 100 (X2, ACT ablation).</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), k = 1, noise = 0.06, ens = false, seed = 3, W = 520, H = 300, runs = [];
    var T = 100, ref = function (t) { return 0.5 + 0.35 * Math.sin(t / T * Math.PI * 1.2); };
    function rollout(R) {
      var x = ref(0), xs = [x], plan = [], calls = 0, bias = 0, ensBuf = [];
      for (var t = 0; t < T; t++) {
        if (!plan.length || ens) {
          calls++;
          /* the predictor's error is correlated with how far the state has drifted (covariate shift) */
          var drift = x - ref(t); bias = 0.8 * drift + noise * R.normal();
          var chunk = []; for (var j = 1; j <= k; j++) chunk.push(ref(t + j) + bias * (j === 1 ? 1 : 0.3) + 0.25 * noise * R.normal());
          if (ens) { ensBuf.push({ t0: t, a: chunk }); ensBuf = ensBuf.filter(function (e) { return t - e.t0 < k; }); }
          else plan = chunk;
        }
        var target;
        if (ens) { var num = 0, den = 0; ensBuf.forEach(function (e) { var i = t - e.t0; if (i < e.a.length) { var w = Math.exp(-0.1 * i); num += w * e.a[i]; den += w; } }); target = num / den; }
        else target = plan.shift();
        x = x + 0.9 * (target - x); xs.push(x);
      }
      var ok = Math.abs(x - ref(T)) < 0.06, jerk = 0; for (var i = 2; i < xs.length; i++) jerk += Math.abs(xs[i] - 2 * xs[i - 1] + xs[i - 2]);
      return { xs: xs, ok: ok, calls: calls, jerk: jerk / xs.length };
    }
    function run() {
      var R = RB.rng(seed); runs = []; for (var i = 0; i < 20; i++) runs.push(rollout(R));
      RB.setRO(body, "succ", runs.filter(function (r) { return r.ok; }).length + " of 20");
      RB.setRO(body, "calls", String(runs[0].calls));
      RB.setRO(body, "jerk", RB.fmt(runs.reduce(function (a, r) { return a + r.jerk; }, 0) / runs.length * 1000, 1));
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), sx = function (t) { return 30 + t / T * (W - 60); }, sy = function (v) { return H - 20 - v * (H - 40); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.fillStyle = P["good-soft"]; c.fillRect(W - 44, sy(ref(T) + 0.06), 20, sy(ref(T) - 0.06) - sy(ref(T) + 0.06));
      c.strokeStyle = P["ink-2"]; c.setLineDash([5, 4]); c.beginPath(); for (var t = 0; t <= T; t++) { if (t) c.lineTo(sx(t), sy(ref(t))); else c.moveTo(sx(t), sy(ref(t))); } c.stroke(); c.setLineDash([]);
      runs.forEach(function (r) { c.strokeStyle = r.ok ? P["data-1"] : P.bad; c.globalAlpha = 0.55; c.beginPath(); r.xs.forEach(function (v, t) { if (t) c.lineTo(sx(t), sy(v)); else c.moveTo(sx(t), sy(v)); }); c.stroke(); });
      c.globalAlpha = 1; c.fillStyle = P["ink-3"]; c.font = "500 11px " + getComputedStyle(document.body).getPropertyValue("--font-mono"); c.fillText("slot", W - 46, sy(ref(T) + 0.06) - 6);
    }
    RB.bindSlider(body, id + "-h", null, function (v) { k = v; run(); });
    RB.bindSlider(body, id + "-noise", function (v) { return (+v).toFixed(2); }, function (v) { noise = v; run(); });
    body.querySelector("#" + id + "-ens").addEventListener("change", function (e) { ens = e.target.checked; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { get: function () { return { k: k, ens: ens }; } };
  }

  /* ---------- concept-card drawings (56px tall, token colors only) ---------- */
  var ART = {
    modes: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 48 Q40 48 50 14 Q60 48 100 48 Q140 48 150 14 Q160 48 190 48" class="rb-s-acc"/><line x1="100" y1="8" x2="100" y2="50" class="rb-s-line" stroke-dasharray="3 3"/><text x="100" y="8" text-anchor="middle" class="rb-t-mono">mean</text></svg>',
    chunk: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="14" y="20" width="22" height="16" rx="3" class="rb-f-sunk"/><text x="25" y="50" text-anchor="middle" class="rb-t-mono">oₜ</text><path d="M40 28 H56" class="rb-s-ink"/>' + [0, 1, 2, 3, 4, 5].map(function (i) { return '<rect x="' + (60 + i * 22) + '" y="20" width="18" height="16" rx="2" class="' + (i === 0 ? "rb-f-soft" : "rb-f-surface") + '"/>'; }).join("") + '<text x="120" y="50" text-anchor="middle" class="rb-t-mono">aₜ … aₜ₊ₕ</text></svg>',
    z: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="40" cy="28" r="12" class="rb-f-soft"/><text x="40" y="32" text-anchor="middle" class="rb-t-acc">z</text><path d="M56 28 H96" class="rb-s-ink"/><path d="M100 28 L150 12 M100 28 L150 44" class="rb-s-ink"/><circle cx="156" cy="12" r="5" class="rb-f-acc"/><circle cx="156" cy="44" r="5" class="rb-f-surface"/><text x="176" y="16" class="rb-t-mono">left</text><text x="176" y="48" class="rb-t-mono">right</text></svg>',
    denoise: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (i) { var x = 20 + i * 40, r = 14 - i * 2; return '<circle cx="' + x + '" cy="28" r="' + (4 + i) + '" class="rb-f-soft" opacity="' + (0.35 + i * 0.16) + '"/>' + (i < 4 ? '<path d="M' + (x + 10) + ' 28 H' + (x + 28) + '" class="rb-s-line"/>' : ""); }).join("") + '<text x="20" y="52" text-anchor="middle" class="rb-t-mono">noise</text><text x="180" y="52" text-anchor="middle" class="rb-t-mono">action</text></svg>',
    flow: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M20 46 Q70 44 180 12" class="rb-s-acc"/><path d="M20 30 C60 50 120 4 180 40" class="rb-s-line" stroke-dasharray="3 3"/><circle cx="20" cy="46" r="4" class="rb-f-surface"/><circle cx="180" cy="12" r="5" class="rb-f-acc"/><text x="120" y="54" class="rb-t-mono">flow: straight</text><text x="60" y="12" class="rb-t-mono">diffusion</text></svg>',
    ensemble: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2].map(function (i) { return '<path d="M' + (20 + i * 22) + " " + (18 + i * 10) + " H" + (120 + i * 22) + '" class="rb-s-line"/>'; }).join("") + '<path d="M120 10 V52" class="rb-s-acc"/><circle cx="120" cy="18" r="3" class="rb-f-acc"/><circle cx="120" cy="28" r="3" class="rb-f-acc"/><circle cx="120" cy="38" r="3" class="rb-f-acc"/><text x="150" y="30" class="rb-t-mono">weighted</text><text x="150" y="42" class="rb-t-mono">average</text></svg>'
  };

  /* ---------- worked example figure: one flow sample in 1-D, four Euler steps (numbers computed from the toy) ---------- */
  var X = function (v) { return (280 + v * 185).toFixed(1); };
  var WE_FIG = '<svg viewBox="0 0 560 150" role="img" aria-label="Number line from minus 1.3 to 1.3 with two demonstration modes at minus 1 and plus 1; the sample moves from 0.30 to 0.94 in four steps">' +
    '<rect x="' + X(-1.12) + '" y="46" width="' + (0.24 * 185).toFixed(1) + '" height="36" rx="3" class="rb-f-soft"/><rect x="' + X(0.88) + '" y="46" width="' + (0.24 * 185).toFixed(1) + '" height="36" rx="3" class="rb-f-soft"/>' +
    '<line x1="40" y1="64" x2="520" y2="64" class="rb-s-line"/>' +
    '<g class="rb-t-mono"><text x="' + X(-1) + '" y="104" text-anchor="middle">−1 (left demos)</text><text x="' + X(0) + '" y="104" text-anchor="middle">0 = mean</text><text x="' + X(1) + '" y="104" text-anchor="middle">+1 (right demos)</text></g>' +
    '<g data-on="1+"><circle cx="' + X(0.3) + '" cy="64" r="6" class="rb-f-surface"/><text x="' + X(0.3) + '" y="36" text-anchor="middle" class="rb-t-ink">τ=0: 0.30</text></g>' +
    '<g data-on="2+"><path d="M' + X(0.3) + " 70 Q" + X(0.26) + " 84 " + X(0.225) + ' 70" class="rb-s-acc"/><circle cx="' + X(0.225) + '" cy="64" r="5" class="rb-f-acc"/><text x="' + X(0.225) + '" y="124" text-anchor="middle" class="rb-t-acc">0.225</text></g>' +
    '<g data-on="3+"><circle cx="' + X(0.183) + '" cy="64" r="5" class="rb-f-acc"/><text x="' + X(0.183) + '" y="140" text-anchor="middle" class="rb-t-acc">0.183</text></g>' +
    '<g data-on="4+"><circle cx="' + X(0.266) + '" cy="64" r="5" class="rb-f-acc"/><text x="' + X(0.266) + '" y="22" text-anchor="middle" class="rb-t-acc">0.266</text></g>' +
    '<g data-on="5"><path d="M' + X(0.266) + " 58 Q" + X(0.6) + " 30 " + X(0.941) + ' 58" class="rb-s-acc"/><circle cx="' + X(0.941) + '" cy="64" r="7" class="rb-f-acc"/><text x="' + X(0.941) + '" y="30" text-anchor="middle" class="rb-t-ink">τ=1: 0.94</text></g></svg>';

  RB.topic({
    id: "b2",
    title: "Generative policy heads",
    eyebrow: "Part B · Policy heads",
    lede: "Demonstrations often show several right ways to act. Generative heads learn the whole distribution of actions instead of its average.",
    refs: ["X2 §4.2–4.4", "P01 §6.4", "P02 §IV-A"],
    why: "Behavior cloning with a squared-error loss predicts the mean of the demonstrated actions. When demonstrators go left or right around an obstacle, the mean goes straight into it. Generative heads (CVAEs, diffusion and flow matching) model the full distribution and sample one mode at a time.",
    outcomes: [
      "Explain why regression fails on multimodal demonstrations.",
      "Compare the training losses of ACT, Diffusion Policy and flow matching.",
      "Compute one Euler step of flow-matching sampling by hand.",
      "Choose a head by trading sample quality against network calls per action.",
      "Explain why action chunks reduce compounding error."
    ],
    concepts: [
      { name: "Multimodal actions", def: "Several distinct actions are correct in the same state; their average may be wrong.", ref: "X2 §4.1", art: ART.modes, term: "multimodal-actions" },
      { name: "Action chunk", def: "The policy outputs the next H actions at once and executes them before asking again.", ref: "X2 §4.2", art: ART.chunk, term: "action-chunk", sym: "achunk" },
      { name: "Latent style z", def: "A CVAE encodes each demonstration's style into z; the decoder turns z and the observation into a chunk.", ref: "X2 eq. 50", art: ART.z, term: "cvae", sym: "z" },
      { name: "Denoising", def: "Diffusion policies start from Gaussian noise and remove it in K learned steps.", ref: "X2 eq. 51", art: ART.denoise, term: "diffusion-policy-head", sym: "eps" },
      { name: "Velocity field", def: "Flow matching learns a velocity that carries noise to data along near-straight paths.", ref: "X2 eq. 49", art: ART.flow, term: "flow-matching", sym: "v" },
      { name: "Temporal ensembling", def: "Overlapping chunks are averaged with exponential weights to smooth execution.", ref: "ACT, arXiv 2304.13705", art: ART.ensemble, term: "temporal-ensembling" }
    ],
    flow: {
      title: "Where the head acts at run time", ref: "X2 Fig. 31, 37", w: 820, h: 270,
      caption: "The head sits between the observation encoder and the robot. Diffusion and flow heads loop K times per chunk; that loop sets the latency.",
      nodes: [
        { id: "obs", x: 20, y: 30, w: 150, h: 52, label: "Observation oₜ", sub: "images, joint state", kind: "env" },
        { id: "enc", x: 220, y: 30, w: 150, h: 52, label: "Encoder", sub: "ResNet or VLM", kind: "agent" },
        { id: "noise", x: 220, y: 170, w: 150, h: 52, label: "Noise ε", sub: "Gaussian sample", kind: "store" },
        { id: "head", x: 430, y: 100, w: 160, h: 60, label: "Action head", sub: "K denoising steps", kind: "agent" },
        { id: "robot", x: 650, y: 100, w: 150, h: 60, label: "Robot", sub: "runs the chunk", kind: "env" }
      ],
      edges: [
        { from: "obs", to: "enc", label: "pixels" },
        { from: "enc", to: "head", label: "features", sides: ["r", "t"], via: [[510, 56]] },
        { from: "noise", to: "head", label: "start point", sides: ["r", "b"], via: [[510, 196]] },
        { from: "head", to: "robot", label: "H actions", dy: -8 },
        { from: "robot", to: "obs", label: "new observation", sides: ["b", "b"], via: [[725, 250], [95, 250]], dy: -6 }
      ],
      steps: [
        { on: ["obs", "obs>enc", "enc"], text: "The camera images and joint state are encoded into features: a ResNet in ACT and Diffusion Policy, a vision-language model in π0." },
        { on: ["noise", "noise>head", "head"], text: "A diffusion or flow head starts from a Gaussian noise sample the size of a whole action chunk." },
        { on: ["enc>head", "head"], text: "Conditioned on the features, the head refines the sample K times: denoising steps for diffusion, Euler steps for flow." },
        { on: ["head>robot", "robot"], text: "The finished chunk of H actions goes to the robot, which executes some or all of it without asking the policy again." },
        { on: ["robot>obs", "obs"], text: "Then a new observation arrives and the loop repeats. Fewer steps K per chunk means faster control." }
      ]
    },
    worked: {
      title: "Flow matching turns noise into one mode",
      ref: "X2 eq. 49, 53", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-x-tau}{\\mathbf{a}^{\\tau+\\delta}} = \\class{sym-x-tau}{\\mathbf{a}^{\\tau}} + \\delta\\, \\class{sym-v}{v}(\\class{sym-x-tau}{\\mathbf{a}^{\\tau}}, \\class{sym-tau}{\\tau})", words: "Move the sample a fraction δ along the learned velocity; after 1/δ steps it is an action.", key: ["x-tau", "v", "tau", { glyph: "δ", meaning: "step size, here 1/K" }] },
      figure: WE_FIG,
      steps: [
        { title: "Start from noise", text: "Demonstrations are at −1 and +1 (two modes). The sample starts at 0.30, drawn from a Gaussian, at τ = 0." },
        { title: "First step goes to the mean", text: "Both modes are equally likely at τ = 0, so the velocity is 0 − 0.30 = −0.30. The sample moves to 0.225." },
        { title: "Still undecided", text: "At τ = 0.25 the right mode has weight 0.55. The velocity is −0.17, and the sample moves to 0.183." },
        { title: "It starts to commit", text: "At τ = 0.5 the right mode has weight 0.67. The velocity turns positive, +0.33, and the sample moves to 0.266." },
        { title: "One mode wins", text: "At τ = 0.75 the weight is 0.997 and the velocity +2.70. The sample lands at 0.94; more steps land closer to 1." }
      ]
    },
    ruleTitle: "Three training objectives",
    rules: [
      { name: "ACT: conditional VAE over chunks", ref: "X2 eq. 50", term: "cvae",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\underbrace{\\big\\|\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} - \\hat{\\mathbf{a}}_{t:t+H}(\\class{sym-o}{o_t}, \\class{sym-z}{z})\\big\\|_1}_{\\text{reconstruct the chunk}} + \\class{sym-beta}{\\beta}\\, \\class{sym-KL}{D_{\\mathrm{KL}}}\\big(q_\\phi(\\class{sym-z}{z} \\mid \\class{sym-achunk}{\\mathbf{a}_{t:t+H}}, \\class{sym-o}{o_t}) \\,\\|\\, \\mathcal{N}(0, I)\\big)",
        words: "Reconstruct the demonstrated chunk from the observation and a style code z, while keeping z close to a standard Gaussian.",
        key: ["L", "achunk", "o", "z", "beta", "KL"] },
      { name: "Diffusion Policy: predict the noise", ref: "X2 eq. 51",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{k, \\class{sym-eps}{\\epsilon}} \\Big\\| \\class{sym-eps}{\\epsilon} - \\class{sym-epsnet}{\\epsilon_\\theta}\\big(\\sqrt{\\class{sym-abar}{\\bar\\alpha_k}}\\, \\class{sym-achunk}{\\mathbf{a}_{t:t+H}} + \\sqrt{1 - \\class{sym-abar}{\\bar\\alpha_k}}\\, \\class{sym-eps}{\\epsilon},\\ k,\\ \\class{sym-o}{o_t}\\big) \\Big\\|^2",
        words: "Add noise of a random level k to a demonstrated chunk and train the network to predict exactly that noise.",
        key: ["L", "E", "eps", "epsnet", "abar", "achunk", "o", { glyph: "k", meaning: "noise level (denoising step)" }] },
      { name: "Flow matching (π0 form)", ref: "X2 eq. 52", term: "flow-matching",
        before: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{k, \\class{sym-eps}{\\epsilon}} \\big\\| \\class{sym-eps}{\\epsilon} - \\class{sym-epsnet}{\\epsilon_\\theta}(\\cdot, k, \\class{sym-o}{o_t}) \\big\\|^2",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{\\class{sb-chg}{\\class{sym-tau}{\\tau}}, \\class{sym-eps}{\\epsilon}} \\big\\| \\class{sb-new}{\\class{sym-v}{v_\\theta}\\big(\\class{sym-tau}{\\tau}\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} + (1-\\class{sym-tau}{\\tau})\\class{sym-eps}{\\epsilon},\\ \\class{sym-o}{o_t}, \\class{sym-tau}{\\tau}\\big)} - \\class{sb-new}{(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} - \\class{sym-eps}{\\epsilon})} \\big\\|^2",
        words: "Mix a chunk and noise with weight τ, and regress the velocity that points from the noise to the chunk. π0 samples τ from a shifted Beta distribution.",
        key: ["L", "E", "tau", "eps", "v", "achunk", "o"], diff: true, beforeLabel: "Diffusion", afterLabel: "Flow" }
    ],
    algorithm: {
      title: "Sampling a chunk with flow matching", ref: "X2 eq. 53 · π0", prov: "Our notation: τ = 1 is clean",
      lines: [
        '<span class="kw">input</span> observation <span data-sym="o">oₜ</span>, steps <span data-sym="K">K</span> (π0: 10)',
        '<span data-sym="x-tau">a⁰</span> ← sample <span data-sym="eps">ε</span> ~ 𝒩(0, I) with the shape of a chunk',
        '<span class="kw">for</span> k = 0 … <span data-sym="K">K</span> − 1:',
        '    <span data-sym="tau">τ</span> ← k / <span data-sym="K">K</span>',
        '    <span data-sym="x-tau">a</span> ← <span data-sym="x-tau">a</span> + (1/<span data-sym="K">K</span>) · <span data-sym="v">v_θ</span>(<span data-sym="x-tau">a</span>, <span data-sym="o">oₜ</span>, <span data-sym="tau">τ</span>)',
        '<span class="kw">return</span> <span data-sym="achunk">a</span> as the chunk <span data-sym="achunk">aₜ:ₜ₊H</span> <span class="cm">// π0 caches the VLM keys across steps</span>'
      ]
    },
    playgrounds: [
      {
        id: "heads", title: "Four heads on the same demonstrations", ref: "X2 Fig. 20, 25", prov: "Simplified: exact 2-D toy model, no network",
        try: "Start on Regression: the one prediction goes into the obstacle. Switch to Flow and set Steps K to 1, then 10. Compare with Diffusion at the same K.",
        mount: mountHeads,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); };
          var id = "b2-heads";
          return [
            { target: q("#" + id + "-head"), title: "Regression averages", text: "Regression predicts the average action. The average of left and right is straight ahead, into the obstacle.", do: function (a) { return a.click(q('#' + id + '-head [value="mse"]')); }, task: "Choose Regression", expect: function () { return api.state().head === "mse"; } },
            { target: q("canvas"), title: "Look at the red dot", text: "One red dot: every call gives the same action, and it hits the block. This is mode averaging." },
            { target: q("#" + id + "-head"), title: "Flow picks a mode", text: "Flow matching samples actions. Each sample lands left or right, and almost none hit the block.", do: function (a) { return a.click(q('#' + id + '-head [value="flow"]')); }, task: "Choose Flow", expect: function () { return api.state().head === "flow"; } },
            { target: q("#" + id + "-k"), title: "One step is not enough", text: "With K = 1, the flow ends at the mean again: the first step always points to the average.", do: function (a) { return a.set(q("#" + id + "-k"), 1); }, task: "Set Steps K to 1", expect: function () { return api.state().K === 1; } },
            { target: q("#" + id + "-k"), title: "Ten steps", text: "At K = 10 the samples split into the two modes. π0 uses 10 flow steps per chunk.", do: function (a) { return a.set(q("#" + id + "-k"), 10); }, task: "Set Steps K to 10", expect: function () { return api.state().K === 10; } },
            { target: q("#" + id + "-head"), title: "Your turn", text: "Choose Diffusion at K = 10, then K = 50. Diffusion needs more steps than flow for clean samples on this toy." }
          ];
        }
      },
      {
        id: "chunks", title: "Chunks against compounding error", ref: "ACT, arXiv 2304.13705", prov: "Illustrative: 1-D tracking toy",
        try: "With chunk size 1, most rollouts miss the slot. Raise the chunk size to 20, then tick Temporal ensembling and compare the jerk.",
        mount: mountChunks,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b2-chunks";
          return [
            { target: q("canvas"), title: "One action per call", text: "With chunk size 1 the policy is called every step. Its small errors push the state off the demonstrations, where it errs more." },
            { target: q("#" + id + "-h"), title: "Commit to a chunk", text: "A chunk of 20 actions follows the demonstrated plan between calls, so errors have fewer chances to compound.", do: function (a) { return a.set(q("#" + id + "-h"), 20); }, task: "Set the chunk size to 20", expect: function () { return api.get().k >= 15; } },
            { target: q("#" + id + "-ens"), title: "Smooth the switches", text: "Temporal ensembling calls the policy every step and averages all chunks that cover the current step.", do: function (a) { return a.click(q("#" + id + "-ens")); }, task: "Tick Temporal ensembling", expect: function () { return api.get().ens; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Compare success and jerk with and without ensembling. π0 tried ensembling and found it hurt, so it runs chunks open-loop." }
          ];
        }
      }
    ],
    methods: ["act", "diffusion-policy", "dp3", "3d-diffuser-actor", "consistency-policy", "vq-bet", "adaflow"],
    open: [
      { title: "Speed versus quality", text: "Consistency and one-step flow policies cut the network calls to one or a few, but distillation can lose multimodality.", refs: "P01 §6.4.3–6.4.4" },
      { title: "Which head for large models", text: "VLAs mix tokenized, diffusion and flow heads; no controlled comparison at scale exists.", refs: "P02 §IV-A · P01 §6.4" },
      { title: "Heads beyond diffusion", text: "State-space, frequency-domain and drift-based heads are recent and little tested on hardware.", refs: "P01 §6.4.5–6.4.9" }
    ],
    takeaways: [
      "Squared-error regression predicts the mean action, which is wrong when demonstrations are multimodal.",
      "ACT models style with a conditional VAE and predicts chunks of actions, which reduced compounding error in its experiments.",
      "Diffusion Policy predicts noise and removes it in K steps; flow matching regresses a velocity and needs fewer steps.",
      "The number of network calls per chunk sets latency: 100 steps for DDPM in simulation, 10 Euler steps for π0, 1 for consistency policies."
    ],
    quiz: [
      { q: "Demonstrators pass an obstacle on the left half the time and on the right half the time. What does squared-error regression predict?", options: ["Left, because it comes first", "The average, straight into the obstacle", "A random choice of left or right", "Nothing: it cannot be trained"], correct: 1, why: "The minimizer of squared error is the conditional mean, and the mean of left and right is straight ahead (X2 §4.1)." },
      { q: "What does a Diffusion Policy network predict during training?", options: ["The clean action chunk", "The noise that was added to the chunk", "The velocity from noise to data", "The reward of the chunk"], correct: 1, why: "Diffusion Policy is trained to predict the added noise ε from the noisy chunk, the noise level and the observation (X2 eq. 51)." },
      { q: "Why does flow matching usually need fewer sampling steps than DDPM?", options: ["It uses a larger network", "Its sampling paths from noise to data are straighter", "It predicts only one action", "It skips the observation"], correct: 1, why: "Flow matching regresses a velocity along straight interpolation paths, so a few Euler steps follow them well; DDPM paths are curved and stochastic." },
      { q: "In ACT, what happened when the chunk size grew from 1 to 100 in simulation?", options: ["Success fell to zero", "Success rose from 1% to 44%", "Nothing changed", "Training diverged"], correct: 1, why: "ACT's ablation reports average success rising from 1% at k = 1 to 44% at k = 100, without temporal ensembling (arXiv 2304.13705)." }
    ],
    cards: [
      { front: "Why does squared-error behavior cloning fail on multimodal demonstrations?", back: "It predicts the conditional mean, which can be an action no demonstrator took.", ref: "X2 §4.1" },
      { front: "What two terms make up ACT's training loss?", back: "An L1 reconstruction of the action chunk plus β times the KL between the style posterior and a standard Gaussian.", ref: "X2 eq. 50" },
      { front: "What is the flow-matching regression target in π0's form?", back: "The velocity from noise to data: a − ε, evaluated at τa + (1 − τ)ε.", ref: "X2 eq. 52" },
      { front: "How many sampling steps do Diffusion Policy and π0 use?", back: "Diffusion Policy: 100 DDPM steps in simulation, 16 DDIM steps on the robot. π0: 10 Euler steps.", ref: "arXiv 2303.04137 · 2410.24164" },
      { front: "What does temporal ensembling do?", back: "It averages the predictions of all overlapping chunks for the current step with exponential weights.", ref: "arXiv 2304.13705" }
    ],
    terms: {
      "multimodal-actions": { name: "multimodal action distribution", aliases: ["multimodal actions", "multimodality"], group: "heads", def: "A distribution of correct actions with several separate peaks, such as passing an obstacle on the left or the right.", note: "Unimodal heads (regression, a single Gaussian) average the peaks.", ref: "X2 §4.1", scene: "robot", focus: ["trajectory", "obstacle"], look: "two ways around the obstacle", uses: [] },
      "mode-averaging": { name: "mode averaging", aliases: ["mode collapse to the mean"], group: "heads", def: "The failure of a squared-error policy that outputs the mean of several demonstrated actions, which may be invalid.", note: "It is the reason generative heads exist.", ref: "X2 §4.1", scene: "robot", focus: ["obstacle"], look: "the mean path hits the obstacle", uses: ["multimodal-actions"] },
      "action-chunk": { name: "action chunk", aliases: ["action chunking", "chunk"], group: "actions", sym: "aₜ:ₜ₊H", symTex: "\\mathbf{a}_{t:t+H}", def: "A sequence of the next H actions predicted from one observation and executed before the policy is queried again.", note: "Chunks cut policy calls and compounding error, but react later to surprises.", ref: "X2 §4.2", scene: "system", focus: ["action-chunk"], look: "the chunk of H actions", uses: [] },
      "cvae": { name: "conditional VAE", aliases: ["CVAE", "conditional variational autoencoder"], group: "heads", def: "A generative model that encodes data into a latent z given a condition, and decodes z and the condition back into data.", note: "In ACT the encoder is used only in training; at test time z is set to zero.", ref: "X2 eq. 50", scene: "system", focus: ["latent", "action-head"], look: "the latent z feeding the head", uses: ["action-chunk"] },
      "diffusion-policy-head": { name: "diffusion head", aliases: ["diffusion policy", "denoising diffusion"], group: "heads", sym: "ε_θ", symTex: "\\epsilon_\\theta", def: "An action head that starts from Gaussian noise and removes it in K learned denoising steps, conditioned on the observation.", note: "More steps give cleaner samples and slower control.", ref: "X2 eq. 51", scene: "system", focus: ["noise", "action-head"], look: "noise entering the action head", uses: ["multimodal-actions"] },
      "flow-matching": { name: "flow matching", aliases: ["flow-matching head", "rectified flow"], group: "heads", sym: "v_θ", symTex: "v_\\theta", def: "Training a velocity field that carries samples from noise to data along straight interpolation paths; sampling integrates it with a few steps.", note: "π0 uses 10 Euler steps; diffusion heads often need many more.", ref: "X2 eq. 49, 52", scene: "system", focus: ["noise", "action-head"], look: "the head integrating from noise", uses: ["diffusion-policy-head"] },
      "temporal-ensembling": { name: "temporal ensembling", aliases: [], group: "actions", def: "Querying the policy every step and executing a weighted average of all chunks that predict the current step.", note: "ACT reports a small gain; π0 found it hurt and ran chunks open-loop.", ref: "arXiv 2304.13705", scene: "system", focus: ["action-chunk", "controller"], look: "overlapping chunks before the controller", uses: ["action-chunk"] },
      "nfe": { name: "network calls per action", aliases: ["NFE", "function evaluations"], group: "heads", def: "How many forward passes of the network produce one action or chunk; it sets inference latency.", note: "Regression and CVAE heads need one; DDPM needs K; consistency policies need one to three.", ref: "P01 §6.4.3", scene: "system", focus: ["action-head"], look: "the loop inside the head", uses: ["diffusion-policy-head"] },
      "consistency-policy": { name: "consistency policy", aliases: ["consistency distillation"], group: "heads", def: "A policy distilled from a diffusion teacher so that one to three network calls map noise directly to an action.", note: "Faster than DDIM on hardware at similar success in its experiments.", ref: "arXiv 2405.07503", scene: "system", focus: ["action-head"], look: "one call instead of K", uses: ["diffusion-policy-head", "nfe"] }
    },
    ledger: [
      { where: "Topic 06 · worked example", source: "X2 writes π0's flow with clean data at τ = 1 in eq. 52 and generic flow matching with t in eq. 49", page: "This site uses τ with 0 = noise, 1 = clean everywhere", why: "One convention for all heads.", kind: "Our choice" },
      { where: "Topic 06 · playground 1", source: "Real heads are neural networks trained on demonstrations", page: "The toy uses the exact score and velocity of a two-mode distribution", why: "Shows differences caused by the head and sampler alone.", kind: "Simplified" },
      { where: "Topic 06 · ACT loss", source: "ACT's Algorithm 1 says MSE", page: "The site shows L1, as the paper's §IV-C states", why: "The method paper contradicts itself; the text is the final choice.", kind: "Sources disagree" }
    ]
  });
})();
