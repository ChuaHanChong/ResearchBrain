/* Topic 13 · The data pyramid. Sources: P05 §1–3, §5.4, §7.2, §8 · P02 §VI · P01 §7.1, method cards (DROID, BridgeData V2, Mobile ALOHA, MimicGen, RoboCasa, GELLO, π0). */
(function () {
  "use strict";
  var RB = window.RB;
  var FONT = function (k) { return getComputedStyle(document.body).getPropertyValue(k === "mono" ? "--font-mono" : "--font-body"); };

  /* ---------- playground 1: data-recipe mixer (toy utility model, illustrative) ---------- */
  /* Five layers from apex to base (P05 §1). cost = toy cost per hour-equivalent; align = how directly actions transfer to the
     target robot; fid = physical fidelity; sem = semantic coverage; div = scene and object diversity. All numbers are ours. */
  var LAYERS = [
    { id: "real", name: "Real robot", cost: 1.0, align: 1.0, fid: 1.0, sem: 0.15, div: 0.2, c: "data-1" },
    { id: "umi", name: "UMI-style", cost: 0.3, align: 0.75, fid: 0.9, sem: 0.25, div: 0.6, c: "data-2" },
    { id: "ego", name: "Egocentric human", cost: 0.06, align: 0.3, fid: 0.8, sem: 0.5, div: 0.8, c: "data-3" },
    { id: "sim", name: "Simulation", cost: 0.03, align: 0.8, fid: 0.35, sem: 0.2, div: 0.5, c: "data-4" },
    { id: "web", name: "General (web)", cost: 0.004, align: 0, fid: 0, sem: 1.0, div: 1.0, c: "data-5" }
  ];
  var BUDGET = 100;
  var PRESETS = {
    pi0: [100, 0, 0, 0, 0], pi05: [70, 0, 0, 0, 30], pi07: [60, 0, 20, 0, 20], groot: [40, 0, 20, 25, 15]
  };
  function mixScore(sh) {
    var tot = sh.reduce(function (a, b) { return a + b; }, 0);
    if (tot <= 0) return { u: [0, 0, 0, 0, 0], seen: 0, unseen: 0, share: [0, 0, 0, 0, 0] };
    var share = sh.map(function (v) { return v / tot; });
    var u = share.map(function (s, k) { return s * BUDGET / LAYERS[k].cost; });
    var act = 0, sem = 0, dv = 0;
    u.forEach(function (x, k) { var L = LAYERS[k]; act += x * L.align * L.fid; sem += x * L.sem; dv += x * L.div * L.align; });
    var A = 1 - Math.exp(-act / 150), gate = 1 - Math.exp(-u[0] / 8), Ae = A * (0.35 + 0.65 * gate);
    var S = 1 - Math.exp(-sem / 400), D = 1 - Math.exp(-dv / 600);
    return { u: u, share: share, seen: Ae * (0.6 + 0.4 * S), unseen: Ae * (0.5 * S + 0.5 * D), gate: gate };
  }

  function mountMixer(body, ctx) {
    var id = ctx.id, sh = PRESETS.pi0.slice(), preset = "pi0";
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-pre", label: "Recipe preset", value: "pi0", options: [{ value: "pi0", label: "π0-style" }, { value: "pi05", label: "π0.5-style" }, { value: "pi07", label: "π0.7-style" }, { value: "groot", label: "GR00T N1-style" }] }) + "</div>" +
      '<div class="rb-row">' + LAYERS.map(function (L, k) { return RB.slider({ id: id + "-s" + k, label: L.name, min: 0, max: 100, step: 5, value: sh[k] }); }).join("") + "</div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Five-layer pyramid; each layer is shaded by its share of the budget and labeled with the hours it buys"></canvas><figcaption class="sb-caption">Apex = real robot, base = web data. Darker layers get more of the fixed budget. The right-hand numbers show how many hour-equivalents that share buys: cheap layers buy far more.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "seen", k: "Seen tasks (toy score)" }, { id: "unseen", k: "Unseen objects (toy score)" }, { id: "anchor", k: "Target-robot data present" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend(LAYERS.map(function (L) { return { c: L.c, label: L.name, kind: "area" }; })) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 520, H = 320, last = null;
    var NOTES = {
      pi0: "π0 pretrained on robot data only: its own 903M timesteps plus open datasets (arXiv 2410.24164). Seen tasks do well; unseen objects lag.",
      pi05: "π0.5 added web data and high-level annotations. Removing web data hurt most on out-of-distribution objects (arXiv 2504.16054).",
      pi07: "π0.7 added egocentric human video and kept failure data, labeled with metadata (P05 §7.2.1).",
      groot: "GR00T N1 draws on four layers: real teleoperation, human video, simulation and neural trajectories, and web data (arXiv 2503.14734).",
      custom: "Custom recipe. Watch what happens when the real-robot share reaches 0: the toy caps action skill without target-robot data."
    };
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), r = last;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var cx = 205, top = 24, bh = 54, mono = FONT("mono");
      for (var k = 0; k < 5; k++) {
        var y0 = top + k * bh, y1 = y0 + bh - 4, w0 = 36 + k * 60, w1 = 36 + (k + 1) * 60;
        c.beginPath(); c.moveTo(cx - w0 / 2, y0); c.lineTo(cx + w0 / 2, y0); c.lineTo(cx + w1 / 2, y1); c.lineTo(cx - w1 / 2, y1); c.closePath();
        c.fillStyle = P["surface-sunk"]; c.fill();
        c.globalAlpha = 0.15 + 0.85 * (r ? r.share[k] : 0); c.fillStyle = P[LAYERS[k].c]; c.fill(); c.globalAlpha = 1;
        c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.stroke();
        c.fillStyle = P.ink; c.font = "600 12px " + FONT("body"); c.textAlign = "center"; c.fillText(LAYERS[k].name, cx, y0 + bh / 2 + 4);
        c.textAlign = "left"; c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono;
        c.fillText(r ? Math.round(r.share[k] * 100) + "% → " + (r.u[k] >= 1000 ? (r.u[k] / 1000).toFixed(1) + "k" : Math.round(r.u[k])) + " h-eq" : "–", 384, y0 + bh / 2 + 4);
      }
      c.strokeStyle = P["ink-3"]; c.fillStyle = P["ink-3"]; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(22, top + 5 * bh - 10); c.lineTo(22, top + 6); c.stroke(); c.beginPath(); c.moveTo(16, top + 14); c.lineTo(22, top + 4); c.lineTo(28, top + 14); c.fill();
      c.save(); c.translate(14, top + 5 * bh / 2 + 50); c.rotate(-Math.PI / 2); c.font = "500 11px " + mono; c.fillStyle = P["ink-2"]; c.fillText("robot alignment ↑", 0, 0); c.restore();
      c.beginPath(); c.moveTo(502, top + 6); c.lineTo(502, top + 5 * bh - 10); c.stroke(); c.beginPath(); c.moveTo(496, top + 5 * bh - 18); c.lineTo(502, top + 5 * bh - 8); c.lineTo(508, top + 5 * bh - 18); c.fill();
      c.save(); c.translate(506, top + 60); c.rotate(Math.PI / 2); c.font = "500 11px " + mono; c.fillStyle = P["ink-2"]; c.fillText("scalability ↓", 0, 0); c.restore();
    }
    function run() {
      last = mixScore(sh);
      RB.setRO(body, "seen", RB.fmt(last.seen, 2));
      RB.setRO(body, "unseen", RB.fmt(last.unseen, 2));
      RB.setRO(body, "anchor", sh[0] > 0 ? "yes (" + Math.round(last.u[0]) + " h-eq)" : "no");
      note.textContent = NOTES[preset];
      draw();
    }
    function setSliders() { LAYERS.forEach(function (L, k) { var inp = body.querySelector("#" + id + "-s" + k), out = body.querySelector('[data-out="' + id + "-s" + k + '"]'); inp.value = sh[k]; if (out) out.textContent = sh[k]; }); }
    /* RB.bindSeg passes b.value of a string (undefined); bind the segmented control directly */
    StudyBench.segmented(body.querySelector("#" + id + "-pre"), function (v) { if (!PRESETS[v]) return; preset = v; sh = PRESETS[v].slice(); setSliders(); run(); });
    LAYERS.forEach(function (L, k) { RB.bindSlider(body, id + "-s" + k, null, function (v) { sh[k] = v; preset = "custom"; body.querySelectorAll("#" + id + "-pre button").forEach(function (b) { b.setAttribute("aria-pressed", "false"); }); run(); }); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { preset: preset, shares: sh.slice(), seen: last.seen, unseen: last.unseen }; } };
  }

  /* ---------- playground 2: sampling weights across sources ---------- */
  /* Dataset sizes (trajectories) from the method cards: AgiBot World 1,001,552 · RoboMIND 107k · DROID 76k · BridgeData V2 60,096 · a 50-demo target task. */
  var SOURCES = [
    { name: "AgiBot World", n: 1001552, c: "data-1" }, { name: "RoboMIND", n: 107000, c: "data-2" }, { name: "DROID", n: 76000, c: "data-3" },
    { name: "BridgeData V2", n: 60096, c: "data-4" }, { name: "Your task", n: 50, c: "data-5" }
  ];
  function weights(alpha, fixed) {
    var others = SOURCES.slice(0, 4), z = 0;
    if (fixed) {
      others.forEach(function (s) { z += Math.pow(s.n, alpha); });
      return others.map(function (s) { return 0.5 * Math.pow(s.n, alpha) / z; }).concat([0.5]);
    }
    SOURCES.forEach(function (s) { z += Math.pow(s.n, alpha); });
    return SOURCES.map(function (s) { return Math.pow(s.n, alpha) / z; });
  }
  function mountWeights(body, ctx) {
    var id = ctx.id, alpha = 1, fixed = false, w = null;
    body.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-a", label: "Exponent α", min: 0, max: 1, step: 0.01, value: 1, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-fix"> <span>Fix your task at 50% (co-training)</span></label><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-pi">Use π0’s 0.43</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Bars comparing each source share of all data with its share of each training batch"></canvas><figcaption class="sb-caption">Gray bar = the source’s share of all trajectories. Colored bar = its share of each batch. Right column = how often one trajectory is seen per million samples drawn.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "task", k: "Your task in each batch" }, { id: "big", k: "AgiBot World in each batch" }, { id: "views", k: "Views per task demo per 1M samples" }]) +
      '<p class="sb-caption">Weights w<sub>k</sub> ∝ n<sub>k</sub><sup>α</sup>. α = 1 samples by size; α = 0 treats sources equally. π0 uses 0.43; Mobile ALOHA fixes 50% for its task. Many views of 50 demos risk overfitting.</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), W = 520, H = 250;
    var total = SOURCES.reduce(function (a, s) { return a + s.n; }, 0);
    function fmtN(v) { return v >= 100 ? Math.round(v).toLocaleString("en-US") : v >= 10 ? v.toFixed(0) : v.toFixed(2); }
    function draw() {
      if (!w) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = FONT("mono");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var x0 = 118, bw = 290, rh = 44;
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      [0, 0.25, 0.5, 0.75, 1].forEach(function (f) { c.beginPath(); c.moveTo(x0 + f * bw, 10); c.lineTo(x0 + f * bw, 10 + rh * 5); c.stroke(); c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.textAlign = "center"; c.fillText(Math.round(f * 100) + "%", x0 + f * bw, H - 12); });
      SOURCES.forEach(function (s, k) {
        var y = 14 + k * rh, sz = s.n / total;
        c.textAlign = "right"; c.fillStyle = P.ink; c.font = "600 12px " + FONT("body"); c.fillText(s.name, x0 - 8, y + 14);
        c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.fillText(s.n.toLocaleString("en-US"), x0 - 8, y + 28);
        c.fillStyle = P["surface-strong"]; c.fillRect(x0, y + 2, Math.max(1, sz * bw), 12);
        c.fillStyle = P[s.c]; c.fillRect(x0, y + 18, Math.max(1, w[k] * bw), 14);
        c.textAlign = "left"; c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono; c.fillText("×" + fmtN(w[k] * 1e6 / s.n), x0 + bw + 10, y + 29);
      });
      c.textAlign = "left";
    }
    function run() {
      w = weights(alpha, fixed);
      RB.setRO(body, "task", (w[4] * 100 < 1 ? (w[4] * 100).toFixed(3) : (w[4] * 100).toFixed(1)) + "%");
      RB.setRO(body, "big", (w[0] * 100).toFixed(1) + "%");
      RB.setRO(body, "views", fmtN(w[4] * 1e6 / 50));
      draw();
    }
    var slider = RB.bindSlider(body, id + "-a", function (v) { return (+v).toFixed(2); }, function (v) { alpha = v; run(); });
    body.querySelector("#" + id + "-fix").addEventListener("change", function (e) { fixed = e.target.checked; run(); });
    body.querySelector("#" + id + "-pi").addEventListener("click", function () { alpha = 0.43; slider.value = 0.43; body.querySelector('[data-out="' + id + '-a"]').textContent = "0.43"; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { alpha: alpha, fixed: fixed, task: w[4] }; } };
  }

  /* ---------- playground 3: MimicGen-style demonstration expansion (planar toy) ---------- */
  var SRC_O = { x: 0.40, y: 0.10, th: 30 };                 /* source object pose (m, m, deg) */
  var REL = [[0.20, 0], [0.15, 0], [0.10, 0], [0.06, 0]];   /* source segment in the object frame: approach, then grasp at (0.06, 0) */
  var EE0 = { x: 0.30, y: 0.20, th: 0 };                   /* end-effector pose when the segment starts */
  function toWorld(O, p) { var t = O.th * Math.PI / 180; return [O.x + Math.cos(t) * p[0] - Math.sin(t) * p[1], O.y + Math.sin(t) * p[0] + Math.cos(t) * p[1]]; }
  function mountMimic(body, ctx) {
    var id = ctx.id, O = { x: 0.55, y: -0.05, th: 90 }, sigma = 0.004, seed = 11, batch = [], stats = null;
    body.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-x", label: "Object x (m)", min: 0.45, max: 0.70, step: 0.01, value: 0.55, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-y", label: "Object y (m)", min: -0.20, max: 0.20, step: 0.01, value: -0.05, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-th", label: "Object yaw (°)", min: -90, max: 90, step: 5, value: 90 }) +
      RB.slider({ id: id + "-sg", label: "Action noise σ (mm)", min: 0, max: 12, step: 1, value: 4 }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Generate 50 ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Top-down table: faint source demonstration, new object pose, and the transformed approach path"></canvas><figcaption class="sb-caption">Faint = the one source demo. Solid = the same segment moved with the object; dashed = interpolation from the gripper. Dots = 50 generated attempts: filled kept, crossed discarded.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "tgt", k: "Grasp target (x, y, yaw)" }, { id: "rate", k: "Generation success" }, { id: "need", k: "Attempts per 1,000 kept" }]) +
      '<p class="sb-caption">Simplified: planar poses; success means the grasp lands within 1 cm and inside reach. MimicGen found noise lowers generation rate but raises policy success (Threading D0: 84.5% → 51.0% generated, 59.3% → 98.0% policy).</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), W = 520, H = 320;
    var sx = function (x) { return 40 + (x + 0.02) / 0.80 * (W - 60); }, sy = function (y) { return H / 2 - y / 0.80 * (W - 60); };
    function target(o) { var g = toWorld(o, REL[3]); return { x: g[0], y: g[1], th: o.th }; }
    function gen() {
      var R = RB.rng(seed), out = [], ok = 0;
      for (var i = 0; i < 50; i++) {
        var o = { x: 0.45 + 0.25 * R(), y: -0.2 + 0.4 * R(), th: -90 + 180 * R() }, g = target(o);
        /* open-loop execution of 5 interpolation steps + 4 segment steps, each with Gaussian action noise; errors add up */
        var ex = 0, ey = 0; for (var s = 0; s < 9; s++) { ex += sigma * R.normal() / 3; ey += sigma * R.normal() / 3; }
        var fx = g.x + ex, fy = g.y + ey, reach = Math.sqrt(fx * fx + fy * fy) < 0.75;
        var good = reach && Math.sqrt(ex * ex + ey * ey) < 0.01; if (good) ok++;
        out.push({ x: fx, y: fy, ok: good });
      }
      batch = out; stats = { rate: ok / 50 };
    }
    function drawGripper(c, x, y, th, col, alpha) {
      var t = th * Math.PI / 180; c.save(); c.translate(sx(x), sy(y)); c.rotate(-t); c.globalAlpha = alpha; c.strokeStyle = col; c.lineWidth = 2.5;
      c.beginPath(); c.moveTo(22, -9); c.lineTo(8, -9); c.lineTo(8, 9); c.lineTo(22, 9); c.moveTo(8, 0); c.lineTo(-4, 0); c.stroke(); c.restore(); c.globalAlpha = 1;
    }
    function drawObj(c, o, P, alpha) {
      c.save(); c.translate(sx(o.x), sy(o.y)); c.rotate(-o.th * Math.PI / 180); c.globalAlpha = alpha;
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.fillRect(-14, -14, 28, 28); c.strokeRect(-14, -14, 28, 28);
      c.strokeStyle = P["frame-x"] || P.accent; c.lineWidth = 2; c.beginPath(); c.moveTo(0, 0); c.lineTo(26, 0); c.stroke(); c.restore(); c.globalAlpha = 1;
    }
    function path(c, pts) { c.beginPath(); pts.forEach(function (p, i) { if (i) c.lineTo(sx(p[0]), sy(p[1])); else c.moveTo(sx(p[0]), sy(p[1])); }); c.stroke(); }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = FONT("mono");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["ink-3"]; c.setLineDash([4, 4]); c.lineWidth = 1; c.beginPath(); c.arc(sx(0), sy(0), 0.75 / 0.80 * (W - 60), -0.9, 0.9); c.stroke(); c.setLineDash([]);
      c.fillStyle = P.ink; c.beginPath(); c.arc(sx(0), sy(0), 7, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText("robot base", sx(0) + 10, sy(0) + 20); c.fillText("reach 0.75 m", sx(0.62), sy(0.36));
      drawObj(c, SRC_O, P, 0.35); c.strokeStyle = P["ink-3"]; c.lineWidth = 1.5; path(c, REL.map(function (p) { return toWorld(SRC_O, p); })); drawGripper(c, toWorld(SRC_O, REL[3])[0], toWorld(SRC_O, REL[3])[1], SRC_O.th + 180, P["ink-3"], 0.5);
      c.fillStyle = P["ink-3"]; c.fillText("source demo", sx(SRC_O.x) - 50, sy(SRC_O.y) - 26);
      batch.forEach(function (b) {
        var X = sx(b.x), Y = sy(b.y);
        if (b.ok) { c.fillStyle = P["data-1"]; c.beginPath(); c.arc(X, Y, 3.5, 0, Math.PI * 2); c.fill(); }
        else { c.strokeStyle = P.bad; c.lineWidth = 1.5; c.beginPath(); c.moveTo(X - 4, Y - 4); c.lineTo(X + 4, Y + 4); c.moveTo(X + 4, Y - 4); c.lineTo(X - 4, Y + 4); c.stroke(); }
      });
      var g = target(O), seg = REL.map(function (p) { return toWorld(O, p); });
      drawObj(c, O, P, 1);
      c.strokeStyle = P["ink-2"]; c.setLineDash([5, 4]); c.lineWidth = 1.5; path(c, [[EE0.x, EE0.y], seg[0]]); c.setLineDash([]);
      c.strokeStyle = P.accent; c.lineWidth = 2.5; path(c, seg);
      drawGripper(c, EE0.x, EE0.y, EE0.th + 180, P["ink-2"], 1); drawGripper(c, g.x, g.y, O.th + 180, P.accent, 1);
      c.fillStyle = P["ink-2"]; c.fillText("gripper start", sx(EE0.x) - 30, sy(EE0.y) - 18);
    }
    function upd() {
      var g = target(O);
      RB.setRO(body, "tgt", g.x.toFixed(2) + ", " + g.y.toFixed(2) + ", " + Math.round(g.th) + "°");
      if (stats) { RB.setRO(body, "rate", Math.round(stats.rate * 100) + "%"); RB.setRO(body, "need", stats.rate > 0 ? Math.round(1000 / stats.rate).toLocaleString("en-US") : "–"); }
      draw();
    }
    var f2 = function (v) { return (+v).toFixed(2); };
    RB.bindSlider(body, id + "-x", f2, function (v) { O.x = v; upd(); });
    RB.bindSlider(body, id + "-y", f2, function (v) { O.y = v; upd(); });
    RB.bindSlider(body, id + "-th", null, function (v) { O.th = v; upd(); });
    RB.bindSlider(body, id + "-sg", null, function (v) { sigma = v / 1000; gen(); upd(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; gen(); upd(); });
    RB.onTheme(draw);
    gen(); upd();
    return { state: function () { return { th: O.th, sigma: sigma, rate: stats.rate, seed: seed }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token colors only) ---------- */
  var ART = {
    pyramid: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (k) { var y = 4 + k * 10, a = 8 + k * 14, b = 8 + (k + 1) * 14; return '<path d="M' + (100 - a) + " " + y + " H" + (100 + a) + " L" + (100 + b) + " " + (y + 9) + " H" + (100 - b) + ' Z" style="fill:var(--data-' + (k + 1) + ')" opacity="0.75"/>'; }).join("") + '<text x="116" y="11" class="rb-t-mono">robot</text><text x="181" y="53" class="rb-t-mono">web</text></svg>',
    axes: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M20 50 H186" class="rb-s-ink"/><path d="M180 45 L188 50 L180 55" class="rb-s-ink"/><path d="M20 50 V6" class="rb-s-ink"/><path d="M15 12 L20 4 L25 12" class="rb-s-ink"/><path d="M36 12 Q100 18 176 44" class="rb-s-acc"/><circle cx="36" cy="12" r="4" class="rb-f-acc"/><circle cx="176" cy="44" r="4" class="rb-f-acc"/><text x="42" y="10" class="rb-t-mono">real robot</text><text x="170" y="34" text-anchor="end" class="rb-t-mono">web</text></svg>',
    teleop: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M20 50 L32 30 L48 34" class="rb-s-ink"/><circle cx="32" cy="30" r="3" class="rb-f-surface"/><text x="14" y="16" class="rb-t-mono">leader</text><path d="M60 30 H116" class="rb-s-line" stroke-dasharray="4 3"/><text x="70" y="24" class="rb-t-mono">joints</text><path d="M130 52 L150 18 L182 26" class="rb-s-acc"/><circle cx="150" cy="18" r="4" class="rb-f-acc"/><text x="140" y="52" class="rb-t-mono">follower</text></svg>',
    hitl: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 40 Q60 38 92 20" class="rb-s-line"/><path d="M92 20 L104 12" class="rb-s-line" stroke-dasharray="3 3"/><circle cx="92" cy="20" r="4" class="rb-f-surface"/><path d="M92 20 Q130 44 190 40" class="rb-s-acc"/><text x="100" y="10" class="rb-t-mono">failure</text><text x="120" y="54" class="rb-t-mono">correction</text></svg>',
    umi: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="60" y="20" width="44" height="14" rx="3" class="rb-f-soft"/><path d="M104 22 H124 M104 32 H124 M124 18 V26 M124 28 V36" class="rb-s-ink"/><rect x="66" y="8" width="16" height="12" rx="2" class="rb-f-sunk"/><circle cx="74" cy="14" r="3" class="rb-f-acc"/><path d="M78 34 L74 50" class="rb-s-ink"/><text x="140" y="30" class="rb-t-mono">no robot</text><text x="4" y="30" class="rb-t-mono">camera</text></svg>',
    expand: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="12" y="20" width="16" height="16" class="rb-f-acc"/><path d="M34 28 H62" class="rb-s-ink"/><path d="M56 23 L64 28 L56 33" class="rb-s-ink"/>' + [[80, 8, 0], [110, 30, 20], [140, 10, -25], [168, 32, 40], [92, 40, 60]].map(function (p) { return '<rect x="' + p[0] + '" y="' + p[1] + '" width="14" height="14" class="rb-f-soft" transform="rotate(' + p[2] + " " + (p[0] + 7) + " " + (p[1] + 7) + ')"/>'; }).join("") + '</svg>',
    mix: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (k) { return '<rect x="' + (10 + k * 18) + '" y="' + (48 - [36, 14, 22, 30, 40][k]) + '" width="12" height="' + [36, 14, 22, 30, 40][k] + '" style="fill:var(--data-' + (k + 1) + ')"/>'; }).join("") + '<path d="M104 30 H130" class="rb-s-ink"/><path d="M124 25 L132 30 L124 35" class="rb-s-ink"/>' + [0, 1, 2, 3, 4].map(function (k) { return '<rect x="140" y="' + (8 + [0, 12, 18, 26, 34][k]) + '" width="44" height="' + [12, 6, 8, 8, 8][k] + '" style="fill:var(--data-' + (k + 1) + ')"/>'; }).join("") + '<text x="140" y="6" class="rb-t-mono">batch</text></svg>',
    pad: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [[7, 7], [14, 0], [12, 2]].map(function (r, i) { var s = ""; for (var j = 0; j < 14; j++) s += '<rect x="' + (6 + j * 9) + '" y="' + (6 + i * 16) + '" width="8" height="12" class="' + (j < r[0] ? "rb-f-acc" : j < r[0] + r[1] ? "rb-f-soft" : "rb-f-sunk") + '"/>'; return s; }).join("") + '<text x="136" y="16" class="rb-t-mono">one arm</text><text x="136" y="32" class="rb-t-mono">two arms</text><text x="136" y="48" class="rb-t-mono">mobile</text></svg>'
  };

  /* ---------- worked example figure: MimicGen pose transform in the plane ---------- */
  function wx(x0, x) { return (x0 + (x - 0.25) / 0.45 * 230).toFixed(1); }
  function wy(y) { return (34 + (0.25 - y) / 0.40 * 150).toFixed(1); }
  function box(x0, x, y, th, cls) { return '<rect x="-11" y="-11" width="22" height="22" class="' + cls + '" transform="translate(' + wx(x0, x) + " " + wy(y) + ") rotate(" + (-th) + ')"/><path d="M0 0 H18" class="rb-s-acc" transform="translate(' + wx(x0, x) + " " + wy(y) + ") rotate(" + (-th) + ')"/>'; }
  function grip(x0, x, y, th, cls) { return '<path d="M-8 -9 H6 V9 H-8 M6 0 H20" class="' + cls + '" stroke-width="2.5" fill="none" transform="translate(' + wx(x0, x) + " " + wy(y) + ") rotate(" + (-th) + ')"/>'; }
  var A = 20, B = 300;
  var WE_FIG = '<svg viewBox="0 0 560 268" role="img" aria-label="Two top-down panels: the source scene with the object at 30 degrees and the grasp beside it, and the new scene with the object at 90 degrees and the transformed grasp">' +
    '<rect x="' + A + '" y="26" width="240" height="166" rx="6" class="rb-f-sunk"/><rect x="' + B + '" y="26" width="240" height="166" rx="6" class="rb-f-sunk"/>' +
    '<text x="' + (A + 8) + '" y="18" class="rb-t-ink">Source scene</text><text x="' + (B + 8) + '" y="18" class="rb-t-ink">New scene</text>' +
    '<g data-on="1+">' + box(A, 0.40, 0.10, 30, "rb-f-soft") + grip(A, 0.452, 0.130, 30, "rb-s-ink") + '<text x="' + wx(A, 0.30) + '" y="' + wy(-0.05) + '" class="rb-t-mono">O₀ (0.40, 0.10, 30°)</text><text x="' + wx(A, 0.40) + '" y="' + wy(0.20) + '" class="rb-t-mono">C (0.452, 0.130)</text></g>' +
    '<g data-on="2+"><path d="M' + wx(A, 0.40) + " " + wy(0.10) + " L" + wx(A, 0.452) + " " + wy(0.130) + '" class="rb-s-acc" stroke-dasharray="3 2"/><text x="' + (A + 8) + '" y="214" class="rb-t-acc">C in object frame: (0.060, 0.000, 0°)</text></g>' +
    '<g data-on="3+">' + box(B, 0.55, -0.05, 90, "rb-f-soft") + '<text x="' + wx(B, 0.33) + '" y="' + wy(-0.12) + '" class="rb-t-mono">O′₀ (0.55, −0.05, 90°)</text></g>' +
    '<g data-on="4+">' + grip(B, 0.55, 0.01, 90, "rb-s-acc") + '<text x="' + wx(B, 0.525) + '" y="' + wy(-0.005) + '" text-anchor="end" class="rb-t-acc">C′ (0.55, 0.01)</text></g>' +
    '<g data-on="5+">' + grip(B, 0.30, 0.20, 0, "rb-s-ink") + [1, 2, 3, 4].map(function (i) { return '<circle cx="' + wx(B, 0.30 + 0.05 * i) + '" cy="' + wy(0.20 - 0.038 * i) + '" r="3" class="rb-f-acc"/>'; }).join("") + '<text x="' + wx(B, 0.27) + '" y="' + wy(0.235) + '" class="rb-t-mono">EE (0.30, 0.20, 0°)</text><text x="' + (B + 8) + '" y="234" class="rb-t-acc">5 steps of (0.050, −0.038, 18°)</text></g>' +
    '<g data-on="6"><text x="' + (A + 8) + '" y="258" class="rb-t-ink">Keep only successes: 1,000 kept at 82.3% needs about 1,215 attempts.</text></g></svg>';

  RB.topic({
    id: "d1",
    title: "The data pyramid",
    eyebrow: "Part D · Data",
    lede: "Robot learning data comes in five layers, from costly real-robot demonstrations to nearly free web data. Recipes mix layers to trade alignment for scale.",
    refs: ["P05 §1–3, §5.4, §7.2", "P02 §VI", "P01 §7.1"],
    why: "A vision-language-action (VLA) model learns only what its data shows. Robot demonstrations are the most useful data and the most expensive; web data is nearly free and says nothing about contact. Every recent recipe mixes layers of a data pyramid, and your choices of collection, alignment and mixing weights shape what the policy can do.",
    outcomes: [
      "Order the five data layers by scalability and robot alignment.",
      "Compare leader-follower teleoperation, UMI-style collection and human-in-the-loop correction.",
      "Compute a MimicGen pose transform for a new object pose.",
      "Explain how sampling weights set each source's share of a batch.",
      "Trace how the π-series data recipes grew across pyramid layers."
    ],
    concepts: [
      { name: "Data pyramid", def: "Five data sources from apex to base: real robot, UMI-style, egocentric human, simulation, general web data.", ref: "P05 §1, Fig. 1", art: ART.pyramid, term: "data-pyramid" },
      { name: "Scalability vs alignment", def: "Data that transfers directly to the robot is expensive; cheap data supervises the robot only indirectly.", ref: "P05 §1", art: ART.axes, term: "robot-alignment" },
      { name: "Leader-follower teleoperation", def: "A human moves a leader device; the follower robot copies its joints. GELLO builds the leader for under $300.", ref: "P05 §2.3.2", art: ART.teleop, term: "leader-follower-teleoperation" },
      { name: "Human-in-the-loop correction", def: "A person takes over when the policy fails; the corrections become targeted recovery data.", ref: "P05 §2.3.3", art: ART.hitl, term: "human-in-the-loop-enhancement" },
      { name: "UMI-style data", def: "A handheld gripper with a camera records end-effector motion anywhere, with no robot in the loop.", ref: "P05 §3", art: ART.umi, term: "umi-style-data" },
      { name: "Demonstration expansion", def: "MimicGen moves object-centric segments of a few demos to new object poses and keeps successful replays.", ref: "P05 §5.4", art: ART.expand, term: "demonstration-expansion", sym: "Tpose" },
      { name: "Co-training mixture", def: "Each batch samples every source with a weight; the weights are the data recipe.", ref: "P05 §7.2.1", art: ART.mix, term: "co-training", sym: "wmix", href: "#lab/data" },
      { name: "Action-space alignment", def: "Different robots' actions are made comparable: per-robot projectors, zero-padded vectors or semantic slots.", ref: "P05 §7.2.2", art: ART.pad, term: "zero-padded-action-interface" }
    ],
    flow: {
      title: "Where data choices act in training", ref: "P05 §2.3, §7.2 · P01 §7.1", w: 820, h: 300,
      caption: "Data passes through three choices before the policy sees it: which layers to collect, how to align their actions, and how much of each batch they get. Deployment failures feed new data back.",
      nodes: [
        { id: "src", x: 10, y: 36, w: 150, h: 56, label: "Data layers", sub: "five sources", kind: "store" },
        { id: "align", x: 235, y: 36, w: 150, h: 56, label: "Alignment", sub: "pad and normalize", kind: "agent" },
        { id: "mix", x: 450, y: 36, w: 140, h: 56, label: "Mixture weights", sub: "one per source", kind: "decision" },
        { id: "policy", x: 660, y: 36, w: 150, h: 56, label: "Policy πθ", sub: "trained on batches", kind: "agent" },
        { id: "robot", x: 660, y: 200, w: 150, h: 56, label: "Robot rollouts", sub: "deployment", kind: "env" },
        { id: "hitl", x: 330, y: 200, w: 180, h: 56, label: "Human corrections", sub: "interventions, relabels", kind: "agent" }
      ],
      edges: [
        { from: "src", to: "align", label: "episodes" },
        { from: "align", to: "mix", label: "aligned" },
        { from: "mix", to: "policy", label: "batches" },
        { from: "policy", to: "robot", label: "action chunks", sides: ["b", "t"] },
        { from: "robot", to: "hitl", label: "failures" },
        { from: "hitl", to: "src", label: "recovery data", sides: ["l", "b"], via: [[85, 228]] }
      ],
      steps: [
        { on: ["src"], text: "Five layers supply episodes: teleoperated or scripted robot data, handheld UMI recordings, human video, simulation and web corpora. Each arrives in its own format." },
        { on: ["src>align", "align"], text: "Alignment makes actions comparable: per-robot projectors (GR00T N1), zero-padded vectors or semantic slots, plus consistent frames and per-source normalization." },
        { on: ["align>mix", "mix"], text: "Mixture weights decide each source's share of a batch: 50/50 in Mobile ALOHA, size to the power 0.43 in π0, learned weights in Re-Mix." },
        { on: ["mix>policy", "policy", "policy>robot", "robot"], text: "The policy trains on the mixed batches and is deployed. Its rollouts visit states that no demonstration covered." },
        { on: ["robot>hitl", "hitl", "hitl>src"], text: "Human takeovers at failures become recovery data (Sirius, DAgger-style methods), and the pyramid's apex grows where the policy is weakest." }
      ]
    },
    worked: {
      title: "MimicGen moves one grasp to a new scene",
      ref: "MimicGen eq. (arXiv 2310.17596) · P05 §5.4", prov: "Our toy numbers, planar poses",
      eq: { tex: "\\class{sym-Tpose}{T^{C'_t}_{W}} = \\class{sym-Tpose}{T^{O'_0}_{W}}\\,\\big(\\class{sym-Tpose}{T^{O_0}_{W}}\\big)^{-1}\\,\\class{sym-Tpose}{T^{C_t}_{W}}", words: "Keep the gripper target's pose relative to the object; carry that relative pose to the object's new pose.", key: ["Tpose", { glyph: "C, C′", meaning: "gripper target, source and new" }, { glyph: "O₀, O′₀", meaning: "object at segment start" }, { glyph: "W", meaning: "world frame" }] },
      figure: WE_FIG,
      steps: [
        { title: "One source demo", text: "The object sits at (0.40, 0.10) m, turned 30°. The demo grasps at (0.452, 0.130), facing the same way." },
        { title: "Express grasp in object frame", text: "Subtract the object position, rotate by −30°: the grasp is (0.060, 0.000) m and 0° in the object's frame." },
        { title: "Observe the new object", text: "In a fresh scene the object is at (0.55, −0.05) m, turned 90°." },
        { title: "Carry the grasp over", text: "Rotate (0.060, 0) by 90° to (0, 0.060) and add the object position: the new target is (0.55, 0.01), yaw 90°." },
        { title: "Interpolate from the gripper", text: "The gripper starts at (0.30, 0.20), yaw 0°. Five steps of (0.050, −0.038) m and 18° reach the segment." },
        { title: "Execute and filter", text: "Replay, keep only successes. At MimicGen's real Stack rate of 82.3%, 1,000 kept demos need 1000 / 0.823 ≈ 1,215 attempts." }
      ]
    },
    ruleTitle: "Three rules behind data recipes",
    rules: [
      { name: "From one dataset to a co-training mixture", ref: "arXiv 2401.02117 · P05 §7.2", term: "co-training",
        before: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{(\\class{sym-o}{o},\\class{sym-a}{a}) \\sim \\class{sym-D}{\\mathcal{D}}}\\big[\\mathcal{L}_{\\mathrm{BC}}(\\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o}),\\ \\class{sym-a}{a})\\big]",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sb-new}{\\sum_k \\class{sym-wmix}{w_k}}\\, \\class{sym-E}{\\mathbb{E}}_{(\\class{sym-o}{o},\\class{sym-a}{a}) \\sim \\class{sb-chg}{\\class{sym-D}{\\mathcal{D}_k}}}\\big[\\mathcal{L}_{\\mathrm{BC}}(\\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o}),\\ \\class{sb-new}{\\mathrm{pad}}(\\class{sym-a}{a}))\\big]",
        words: "Average the imitation loss over several sources with weights, padding each source's actions to one shared vector.",
        key: ["L", "E", "o", "a", "D", "pi", "wmix", { glyph: "ℒ_BC", meaning: "the head's imitation loss" }, { glyph: "pad", meaning: "zero-fill missing action dimensions" }], diff: true, beforeLabel: "One dataset", afterLabel: "Mixture" },
      { name: "Size-tempered sampling weights", ref: "π0, arXiv 2410.24164", term: "data-recipe",
        tex: "\\class{sym-wmix}{w_k} = \\dfrac{\\class{sym-nk}{n_k}^{\\,\\class{sym-alpha-mix}{\\alpha}}}{\\sum_j \\class{sym-nk}{n_j}^{\\,\\class{sym-alpha-mix}{\\alpha}}}, \\qquad \\class{sym-alpha-mix}{\\alpha} = 0.43 \\text{ in } \\pi_0",
        words: "Sample each source in proportion to its size raised to α. Below 1, small sources gain batch share and large ones lose it.",
        key: ["wmix", "nk", "alpha-mix"] },
      { name: "MimicGen: re-target a segment", ref: "MimicGen, arXiv 2310.17596", term: "demonstration-expansion",
        tex: "\\class{sym-Tpose}{T^{C'_t}_{O'_0}} = \\class{sym-Tpose}{T^{C_t}_{O_0}} \\quad\\Longrightarrow\\quad \\class{sym-Tpose}{T^{C'_t}_{W}} = \\class{sym-Tpose}{T^{O'_0}_{W}}\\,\\big(\\class{sym-Tpose}{T^{O_0}_{W}}\\big)^{-1}\\,\\class{sym-Tpose}{T^{C_t}_{W}}",
        words: "Copy each gripper target's pose relative to the subtask object from the source demo into the new scene.",
        key: ["Tpose", { glyph: "C_t", meaning: "gripper target at step t" }, { glyph: "O₀", meaning: "object at segment start" }, { glyph: "W", meaning: "world frame" }] }
    ],
    algorithm: {
      title: "MimicGen data generation", ref: "MimicGen, arXiv 2310.17596", prov: "Condensed from the paper's pipeline",
      lines: [
        '<span class="kw">input</span> about 10 source demos, split into object-centric subtask segments',
        '<span class="kw">repeat</span> until enough demos are kept:',
        '    sample a new scene (object poses, instances, or a different arm)',
        '    <span class="kw">for each</span> subtask: pick a source segment (random or nearest object pose)',
        '        observe object pose <span data-sym="Tpose">T^{O′₀}_W</span>; transform the segment with the rule above',
        '        interpolate from the current gripper pose (5 steps), add action noise σ = 0.05',
        '        execute the segment as delta-pose actions',
        '    <span class="kw">if</span> the task succeeded: add the trajectory to <span data-sym="D">𝒟</span> <span class="cm">// failures are discarded</span>',
        '<span class="kw">return</span> <span data-sym="D">𝒟</span> for behavior cloning <span class="cm">// 175 source demos → about 50K generated</span>'
      ]
    },
    playgrounds: [
      {
        id: "mixer", title: "Data-recipe mixer", ref: "P05 §1, §7.2.1", prov: "Illustrative: toy utility model",
        try: "Start with π0-style (real robot only). Switch to π0.5-style and watch unseen objects rise. Then set Real robot to 0 and Simulation to 100.",
        mount: mountMixer,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "d1-mixer";
          return [
            { target: q("canvas"), title: "One fixed budget", text: "Every recipe spends the same budget. Real-robot hours are the most expensive, so a real-only recipe buys the fewest hours." },
            { target: q("#" + id + "-pre"), title: "Add web data", text: "π0.5 added web and annotation data. In the toy, semantic coverage lifts the unseen-object score far more than the seen-task score.", do: function (a) { return a.click(q('#' + id + '-pre [value="pi05"]')); }, task: "Choose the π0.5-style preset", expect: function () { return api.state().preset === "pi05"; } },
            { target: q("#" + id + "-pre"), title: "Add human video", text: "π0.7 added egocentric human video. It is cheap, carries real physics and adds scene diversity with partial action alignment.", do: function (a) { return a.click(q('#' + id + '-pre [value="pi07"]')); }, task: "Choose the π0.7-style preset", expect: function () { return api.state().preset === "pi07"; } },
            { target: q("#" + id + "-s0"), title: "Remove the apex", text: "Set real-robot data to zero. Without data from the target robot, the toy caps action skill: cheap layers cannot replace it.", do: function (a) { return a.set(q("#" + id + "-s0"), 0); }, task: "Set Real robot to 0", expect: function () { return api.state().shares[0] === 0; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Find a recipe with both scores above 0.6 and the smallest real-robot share. P05 §8.6 says the best proportions are still unknown." }
          ];
        }
      },
      {
        id: "weights", title: "Sampling weights across sources", ref: "π0 · Mobile ALOHA · P05 §8.6", prov: "Sizes from method cards; exact sampling",
        try: "At α = 1 your 50 demos almost never appear. Press Use π0’s 0.43, then tick the 50% co-training box and read how often each demo is seen.",
        mount: mountWeights,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "d1-weights";
          return [
            { target: q("canvas"), title: "Sampling by size", text: "At α = 1 each source gets its share of all trajectories. AgiBot World fills most of every batch; your 50 demos are 0.004%." },
            { target: q("#" + id + "-pi"), title: "Temper the sizes", text: "π0 weights each task and robot mix by size to the power 0.43. Small sources gain share; the largest loses it.", do: function (a) { return a.click(q("#" + id + "-pi")); }, task: "Press Use π0’s 0.43", expect: function () { return Math.abs(api.state().alpha - 0.43) < 0.005; } },
            { target: q("#" + id + "-fix"), title: "Fix the task share", text: "Mobile ALOHA sampled half of each batch from its own task demos and half from static ALOHA data.", do: function (a) { return a.click(q("#" + id + "-fix")); }, task: "Tick the 50% co-training box", expect: function () { return api.state().fixed; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Each task demo is now seen 10,000 times per million samples. Try α = 0 with the box off and compare the views per demo." }
          ];
        }
      },
      {
        id: "mimic", title: "Expand one demo to many scenes", ref: "MimicGen, arXiv 2310.17596 · P05 §5.4", prov: "Simplified: planar poses, toy success check",
        try: "Turn the object yaw and watch the grasp target rotate with it. Then generate 50 attempts, raise the action noise to 12 mm and generate again.",
        mount: mountMimic,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "d1-mimic";
          return [
            { target: q("canvas"), title: "One demo, new pose", text: "The faint path is the source demo. The solid path is the same segment, carried with the object to its new pose." },
            { target: q("#" + id + "-th"), title: "Rotate the object", text: "The grasp stays at 6 cm along the object's own axis, so it rotates with the object. Read the new target.", do: function (a) { return a.set(q("#" + id + "-th"), 0); }, task: "Set Object yaw to 0°", expect: function () { return api.state().th === 0; } },
            { target: q("#" + id + "-sg"), title: "Add action noise", text: "MimicGen adds noise while replaying. More noise means more failed attempts, which are discarded.", do: function (a) { return a.set(q("#" + id + "-sg"), 12); }, task: "Set Action noise to 12 mm", expect: function () { return api.state().sigma >= 0.0115; } },
            { target: q("#" + id + "-go"), title: "Generate a batch", text: "Each click samples 50 new object poses and replays the transformed demo. Only successes are kept.", do: function (a) { return a.click(q("#" + id + "-go")); }, task: "Press Generate 50", expect: function () { return api.state().seed > 11; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Compare attempts per 1,000 kept at 0 mm and 12 mm. Noisy but kept demos helped MimicGen's policies recover from errors." }
          ];
        }
      }
    ],
    methodsLede: "How the data line evolved: BridgeData V2 grew one lab's 7.2k trajectories to 60k across 24 environments. Open X-Embodiment pooled 60 datasets from 22 robots. DROID replaced pooling with one standard Franka setup in 564 scenes. GELLO and Mobile ALOHA made teleoperation cheap and whole-body; UMI removed the robot. MimicGen, RoboCasa and InternData-A1 moved generation into simulation.",
    methods: ["droid", "bridgedata-v2", "open-x-embodiment-rt-x", "agibot-world-go-1", "gello", "mobile-aloha", "umi", "mimicgen", "robocasa", "interndata-a1", "sirius", "re-mix"],
    open: [
      { title: "Failure and recovery data", text: "Datasets keep mostly successes, yet policies need to learn recovery. π0.7 hints that labeled low-quality data can still help.", refs: "P05 §8.2, §7.2.1" },
      { title: "Principled data recipes", text: "The best proportions of the five layers are unknown; compute-matched ablations of single sources are rare.", refs: "P05 §8.6" },
      { title: "Aligning actions across robots", text: "Padding standardizes vector length but not meaning; frames and control conventions still differ between datasets.", refs: "P05 §7.2.2, §8.4" },
      { title: "From collection to a data flywheel", text: "Collection should cost less teleoperation and target what the current policy lacks, instead of accumulating data passively.", refs: "P05 §8.3 · P01 §9" }
    ],
    takeaways: [
      "The pyramid orders data by robot alignment and scalability: real robot, UMI-style, human video, simulation, web.",
      "Real-robot data comes from scripts, teleoperation or human corrections at failures; UMI-style devices take the robot out of collection.",
      "MimicGen turns about 10 demos into 1,000 per task by moving object-centric segments and keeping successes.",
      "Mixture weights decide what the policy sees: π0 tempers source sizes with exponent 0.43; Mobile ALOHA fixes 50/50.",
      "Recipes grew across layers: π0 used robot data, π0.5 added web data, π0.7 added egocentric video."
    ],
    quiz: [
      { q: "Why does real-robot data sit at the apex of the pyramid?", options: ["It is the largest source", "Its actions run directly on the robot, but it is costly", "It needs no human operator", "It covers the most semantics"], correct: 1, why: "Real-robot actions are directly executable on the platform that produced them, paid for in hardware, operator time and resets (P05 §1)." },
      { q: "What does MimicGen keep fixed when it moves a source segment to a new scene?", options: ["The gripper's world position", "The gripper pose relative to the subtask object", "The joint angles", "The camera viewpoint"], correct: 1, why: "MimicGen preserves the controller target's pose relative to the object, T^{C}_{O}, and re-expresses it at the new object pose (arXiv 2310.17596)." },
      { q: "π0 samples sources with weights proportional to size^0.43. What does that do?", options: ["Ignores small datasets", "Gives small sources more than their size share", "Samples every source equally", "Uses only the largest dataset"], correct: 1, why: "An exponent below 1 compresses size differences, so small sources gain batch share and large ones lose it; α = 0 would be uniform." },
      { q: "Mobile ALOHA co-trained with static ALOHA data. What happened on Wipe Wine with 50 demos?", options: ["No change", "Success rose from 50% to 95%", "Success fell to 0%", "Training diverged"], correct: 1, why: "ACT reached 95% with co-training versus 50% without; across seven tasks co-training added 34 points on average (arXiv 2401.02117)." },
      { q: "What does a zero-padded action interface standardize?", options: ["The meaning of each action dimension", "Only the length of the action vector", "The camera frames", "The control rate"], correct: 1, why: "Zero-padding fixes the vector dimension without enforcing consistent physical semantics; semantic action slots go further (P05 §7.2.2)." }
    ],
    cards: [
      { front: "Name the five pyramid layers from apex to base.", back: "Real robot, UMI-style, egocentric and exocentric human, simulation, general (web) data.", ref: "P05 §1" },
      { front: "What two axes organize the pyramid?", back: "Scalability (how cheaply a source grows) and robot alignment (how directly it supports execution on robots). They are in tension.", ref: "P05 §1" },
      { front: "What does UMI-style data keep and lose compared with teleoperation?", back: "It keeps end-effector and gripper supervision in any environment; it loses joint-level proprioception and needs retargeting.", ref: "P05 §3.4" },
      { front: "How much did DROID co-training help over Open X-Embodiment co-training?", back: "22 points in distribution and 17 points out of distribution, averaged over six real tasks.", ref: "arXiv 2403.12945" },
      { front: "What did MimicGen do for Square D0 from 10 source demos?", back: "Image-agent success rose from 11.3% with the source demos alone to 90.7% with generated data.", ref: "arXiv 2310.17596" },
      { front: "How did Qwen-RobotManip build its 38,100-hour corpus?", back: "About 11.4K hours of open robot data plus 24,808 hours of trajectories synthesized from 1,933 hours of egocentric video.", ref: "P05 §7.2.1" }
    ],
    terms: {
      "data-pyramid": { name: "data pyramid", aliases: ["embodied data pyramid"], group: "data", def: "An organization of embodied data into five layers, from apex to base: real-robot, UMI-style, egocentric and exocentric, simulation, and general data.", note: "Ordering is an overall synthesis, not strictly monotonic on every property.", ref: "P05 §1", scene: "system", focus: ["data-robot", "data-umi", "data-human", "data-sim", "data-web"], look: "the five data sources", uses: [] },
      "scalability": { name: "scalability", aliases: ["data scalability"], group: "data", def: "How efficiently a data source can be expanded, given hardware dependence, human labor, resets, safety supervision and marginal generation cost.", note: "The more scalable a layer, the less directly it usually supervises robot actions.", ref: "P05 §1", scene: "system", focus: ["data-web", "data-sim"], look: "the cheap base layers", uses: ["data-pyramid"] },
      "robot-alignment": { name: "robot alignment", aliases: ["embodiment alignment"], group: "data", def: "How directly a source's observations, representations and supervision support learning and execution on physical robots.", note: "Not the same as physical fidelity: human video has real physics but weak alignment.", ref: "P05 §1", scene: "system", focus: ["data-robot", "robot"], look: "robot data feeding the robot", uses: ["data-pyramid"] },
      "physical-fidelity": { name: "physical fidelity", aliases: [], group: "data", def: "How faithfully a data category captures real interaction dynamics: contact, friction, compliance, sensing noise, actuation delay and object motion.", note: "Simulation has high alignment but lower fidelity; that is the sim-to-real gap.", ref: "P05 §1", scene: "system", focus: ["data-sim", "simulator"], look: "the simulator's approximate physics", uses: ["robot-alignment"] },
      "leader-follower-teleoperation": { name: "leader-follower teleoperation", aliases: ["puppeteering", "leader-follower"], group: "data", def: "A human moves a leader mechanism whose joint motion is mapped to a follower robot; matched kinematics give intuitive joint-level control.", note: "ALOHA uses a second robot arm as leader; GELLO uses a 3D-printed replica.", ref: "P05 §2.3.2", scene: "system", focus: ["human-teleop", "robot"], look: "the operator driving the robot", uses: [] },
      "human-in-the-loop-enhancement": { name: "human-in-the-loop enhancement", aliases: ["HITL correction", "intervention data"], group: "data", def: "An iterative collection paradigm: a human supervisor intervenes during policy execution and records corrections at difficult or failure-prone states.", note: "It adds recovery data where the policy fails, instead of more full demonstrations.", ref: "P05 §2.3.3", scene: "system", focus: ["human-teleop", "policy-update"], look: "the human correcting a rollout", uses: [] },
      "umi-style-data": { name: "UMI-style data", aliases: ["Universal Manipulation Interface data", "handheld gripper data"], group: "data", def: "Demonstrations captured with handheld grippers that record end-effector motion, gripper state and wrist video without a robot in the loop.", note: "A complement to real-robot data, not a replacement: proprioception and actuator dynamics are missing.", ref: "P05 §3", scene: "system", focus: ["data-umi"], look: "the handheld gripper source", uses: ["robot-alignment"] },
      "egocentric-data": { name: "egocentric data", aliases: ["egocentric human video", "first-person video"], group: "data", def: "First-person recordings of people acting, often with exocentric views, offering real physics and dexterous hands without a robot.", note: "Actions must be reconstructed and retargeted across the human-robot gap.", ref: "P05 §4", scene: "system", focus: ["data-human"], look: "the human video source", uses: ["data-pyramid"] },
      "demonstration-expansion": { name: "demonstration expansion", aliases: ["MimicGen-style generation", "trajectory augmentation"], group: "data", sym: "T", symTex: "T^{A}_{B}", def: "Reusing a few trajectories by replaying, spatially transforming, segmenting and stitching them under new object poses, layouts or embodiments.", note: "Works when tasks admit object-centric transforms; it cannot invent new strategies.", ref: "P05 §5.4", scene: "system", focus: ["data-sim", "simulator"], look: "simulation multiplying a few demos", uses: [] },
      "generative-data-factory": { name: "generative data factory", aliases: ["generative simulation"], group: "data", def: "A pipeline where language or vision-language models generate tasks, scenes or task code, and planners or learners produce the demonstrations.", note: "Examples: GenSim, RoboGen, RoboTwin 2.0, InternData-A1. Risks include invalid tasks and hallucinated dynamics.", ref: "P05 §5.4", scene: "system", focus: ["simulator", "data-sim"], look: "the simulator producing new tasks", uses: ["demonstration-expansion"] },
      "co-training": { name: "co-training", aliases: ["data mixture", "mixed-batch training"], group: "data", sym: "wₖ", symTex: "w_k", def: "Training one policy on batches sampled from several data sources at once, each with a weight, instead of pretraining and then fine-tuning.", note: "Mobile ALOHA: co-training 95% versus pretrain-then-finetune 40% on Wipe Wine.", ref: "arXiv 2401.02117", scene: "system", focus: ["data-robot", "data-sim", "policy-update"], look: "several sources feeding one update", uses: ["data-pyramid"] },
      "data-recipe": { name: "data recipe", aliases: ["data composition"], group: "data", def: "The selection, alignment, sampling ratios and stage-wise allocation of data sources used to train an embodied foundation model.", note: "Recipes differ widely between reports; P05 calls the optimal composition an open problem.", ref: "P05 §7.2.1, §8.6", scene: "system", focus: ["data-robot", "data-human", "data-web", "llm-backbone"], look: "the sources behind the model", uses: ["co-training"] },
      "zero-padded-action-interface": { name: "zero-padded action interface", aliases: ["action padding"], group: "data", def: "A fixed-length action vector shared by all embodiments; robots with fewer dimensions fill the unused entries with zeros.", note: "It fixes dimension, not meaning; semantic action slots also fix what each entry means.", ref: "P05 §7.2.2", scene: "system", focus: ["action-head", "action-chunk"], look: "one action vector for all robots", uses: [] }
    },
    symbols: [
      { id: "wmix", tex: "w_k", glyph: "wₖ", kind: "Parameters", meaning: "sampling weight of data source k in a training batch", short: "mixture weight", first: "d1", read: "w sub k", papers: "π0: n^0.43 weighting · Mobile ALOHA: 50/50 · Re-Mix: learned weights" },
      { id: "nk", tex: "n_k", glyph: "nₖ", kind: "Sets", meaning: "number of examples (trajectories or timesteps) in data source k", short: "source size", first: "d1", read: "n sub k", papers: "π0: n (task-robot combination)" },
      { id: "alpha-mix", tex: "\\alpha", glyph: "α", kind: "Parameters", meaning: "exponent that tempers source sizes when setting mixture weights", short: "size exponent", first: "d1", read: "alpha", papers: "π0: 0.43" },
      { id: "Tpose", tex: "T^{A}_{B}", glyph: "Tᴬ_B", kind: "Signals", meaning: "4×4 rigid pose of frame A expressed in frame B", short: "rigid pose", first: "d1", read: "T of A in B", papers: "MimicGen: T^A_B" }
    ],
    ledger: [
      { where: "Topic 13 · methods lede", source: "P02 §VI-A says DROID collected across 18 research institutions; P02 §VI-B and the DROID paper say 13 institutions", page: "The site uses 13 institutions and 18 robots or labs, as in the DROID paper", why: "The method paper is the primary source.", kind: "Sources disagree" },
      { where: "Topic 13 · methods lede", source: "P02 Table 1 lists Open X-Embodiment at 1.4M episodes; the OXE paper states 1M+ trajectories", page: "The site avoids a single episode count and cites 60 datasets from 22 robots", why: "Counts vary by dataset version.", kind: "Sources disagree" },
      { where: "Topic 13 · worked example", source: "MimicGen transforms 4×4 poses in SE(3)", page: "Planar poses (x, y, yaw) with our toy numbers", why: "Keeps the arithmetic doable by hand; the rule is the same.", kind: "Simplified" },
      { where: "Topic 13 · data-recipe mixer", source: "P05 describes layer trade-offs qualitatively", page: "A toy utility model with our costs and weights", why: "Shows the trade-off mechanism; the scores are not predictions.", kind: "Simplified" },
      { where: "Topic 13 · mixer presets", source: "P05 §7.2.1 names which layers the π series and GR00T N1 use", page: "The shares inside each preset are ours", why: "The papers do not publish comparable proportions.", kind: "Our choice" },
      { where: "Topic 13 · sampling rule", source: "π0 states task-robot combinations are weighted by n^0.43", page: "Written as wₖ = nₖ^α / Σ nⱼ^α over data sources", why: "One notation for all mixture rules.", kind: "Our choice" }
    ]
  });
})();
