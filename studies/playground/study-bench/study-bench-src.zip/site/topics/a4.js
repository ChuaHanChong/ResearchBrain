/* Topic 04 · Sim-to-real. Sources: P08 §2–3, §5–6 (eq. 1–2, Fig. 2), P07 §4.3, §5, Table 3, P09 §VII-A.3, §VII-D.1,
   method cards (Tobin DR → Peng dynamics DR → ADR; asymmetric actor-critic; Lee 2020 teacher–student → RMA; GAT → ASAP). */
(function () {
  "use strict";
  var RB = window.RB;
  var G = 9.81, TARGET = 0.5, TOL = 0.05, MU0 = 0.30, MAXP = 3;

  /* ---------- playground 1: friction randomization for a pushing task ----------
     A robot pushes a puck toward a target 0.50 m away; a push at speed v slides v²/(2μg) (Coulomb friction).
     Up to three pushes; overshooting past the target zone cannot be undone.
     Memoryless policy: each push assumes one friction μa (chosen by grid search to maximize success over the training range).
     With history: the first push assumes the lowest μ in the range, then the policy infers μ from how far the puck slid. */
  function logU(R, lo, hi) { return Math.exp(Math.log(lo) + R() * (Math.log(hi) - Math.log(lo))); }
  function episode(mode, muA, lo, hi, mu, R) {
    var d = 0, pushes = 0, est = mode === "hist" ? lo : muA, path = [0];
    for (var k = 0; k < MAXP; k++) {
      var r = TARGET - d; if (r <= TOL * 0.4) break;
      var v = Math.sqrt(2 * est * G * r) * (1 + 0.03 * R.normal());
      var slide = v * v / (2 * mu * G); d += slide; pushes++; path.push(d);
      if (d > TARGET + TOL) break;
      if (mode === "hist" && k === 0) { var seen = slide * (1 + 0.03 * R.normal()); est = RB.clamp(v * v / (2 * G * seen), lo, hi); }
    }
    return { d: d, ok: Math.abs(d - TARGET) <= TOL, pushes: pushes, path: path };
  }
  function range(w) { return [MU0 / (1 + w), MU0 * (1 + w)]; }
  function simEval(mode, muA, lo, hi, seed, n) {
    var R = RB.rng(seed), ok = 0, p = 0, ends = [];
    for (var i = 0; i < n; i++) { var e = episode(mode, muA, lo, hi, logU(R, lo, hi), R); ok += e.ok ? 1 : 0; p += e.pushes; ends.push(e); }
    return { s: ok / n, pushes: p / n, ends: ends };
  }
  function trainPolicy(mode, w) {
    var rg = range(w);
    if (mode === "hist") return { muA: rg[0], sim: simEval(mode, 0, rg[0], rg[1], 11, 200) };
    /* highest simulated success; among near-ties (within 2 points) the fastest rule, i.e. the highest assumed friction (fewest pushes) */
    var cands = [], top = 0;
    for (var j = 0; j <= 48; j++) {
      var muA = Math.exp(Math.log(0.08) + j / 48 * (Math.log(1.0) - Math.log(0.08)));
      var ev = simEval(mode, muA, rg[0], rg[1], 11, 200); cands.push({ muA: muA, sim: ev }); if (ev.s > top) top = ev.s;
    }
    var ok = cands.filter(function (c) { return c.sim.s >= top - 0.02; }); return ok[ok.length - 1];
  }
  function realEval(mode, pol, w, mu, seed) {
    var rg = range(w), R = RB.rng(seed), ok = 0, p = 0, ends = [];
    for (var i = 0; i < 50; i++) { var e = episode(mode, pol.muA, rg[0], rg[1], mu * (1 + 0.1 * (R() - 0.5)), R); ok += e.ok ? 1 : 0; p += e.pushes; ends.push(e); }
    return { s: ok / 50, pushes: p / 50, ends: ends };
  }
  /* read the pressed option directly: robust to how RB.bindSeg passes its argument */
  function segVal(body, sid) { var b = body.querySelector("#" + sid + ' [aria-pressed="true"]'); return b ? b.value : null; }
  var TABLES = [0.22, 0.42, 0.13, 0.30, 0.65];

  function mountDR(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Policy", value: "ff", options: [{ value: "ff", label: "Memoryless" }, { value: "hist", label: "With history" }] }) +
      RB.slider({ id: id + "-w", label: "Friction range ±", min: 0, max: 2, step: 0.05, value: 0, fmt: fmtW }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-show" checked> <span>Show real μ</span></label>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New real table</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Pushing lane with target zone, final puck positions in simulation and on the real table, and a friction axis with the training range"></canvas>' +
      '<figcaption class="sb-caption">Top: where 50 simulated and 50 real episodes end. Bottom: the friction range the policy trained on (band), the frictions its pushes can handle (bar) and the real table (triangle).</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "sim", k: "Success in simulation ψₛ" }, { id: "real", k: "Success on the real table ψᵣ" }, { id: "gap", k: "Gap G(π) = ψₛ − ψᵣ" }, { id: "push", k: "Pushes per real episode" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "good", label: "ends in the target zone", kind: "dot" }, { c: "bad", label: "misses", kind: "dot" }, { c: "accent", label: "training range", kind: "area" }, { c: "data-2", label: "real friction", kind: "dot" }]) + "</div></div>" +
      '<div id="' + id + '-chart"></div>';
    var cv = body.querySelector("#" + id + "-cv"), host = body.querySelector("#" + id + "-chart"), note = body.querySelector("[data-note]");
    var W = 520, H = 300, mode = "ff", w = 0, show = true, table = 0, pol = null, real = null, runs = 0;
    function fmtW(v) { return "×" + (1 + +v).toFixed(2); }
    var lx = function (d) { return 50 + Math.min(d, 0.72) / 0.72 * 440; };
    var mx = function (m) { return 50 + (Math.log(RB.clamp(m, 0.08, 1.2)) - Math.log(0.08)) / (Math.log(1.2) - Math.log(0.08)) * 440; };
    function draw() {
      if (!pol) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = getComputedStyle(document.body).getPropertyValue("--font-mono");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.fillStyle = P["good-soft"]; c.fillRect(lx(TARGET - TOL), 20, lx(TARGET + TOL) - lx(TARGET - TOL), 118);
      c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.beginPath(); c.moveTo(lx(0), 138); c.lineTo(lx(0.72), 138); c.stroke();
      c.font = "500 11px " + mono; c.fillStyle = P["ink-3"];
      c.fillText("sim", 2, 58); c.fillText("real", 2, 108); c.fillText("target", lx(TARGET) - 18, 14);
      [0, 0.25, 0.5].forEach(function (d) { c.fillText(d.toFixed(2) + " m", lx(d) - 14, 152); });
      c.fillStyle = P["ink-2"]; c.fillRect(lx(0) - 10, 40, 6, 80);
      var R = RB.rng(5);
      function dots(ends, y) { ends.forEach(function (e) { c.fillStyle = e.ok ? P.good : P.bad; c.globalAlpha = 0.75; c.beginPath(); c.arc(lx(e.d), y + (R() - 0.5) * 22, 3.5, 0, Math.PI * 2); c.fill(); }); c.globalAlpha = 1; }
      dots(pol.sim.ends.slice(0, 50), 55); dots(real.ends, 105);
      /* friction axis */
      var ya = 232, rg = range(w);
      c.strokeStyle = P["line-strong"]; c.beginPath(); c.moveTo(mx(0.08), ya); c.lineTo(mx(1.2), ya); c.stroke();
      c.fillStyle = P["ink-3"];
      [0.1, 0.2, 0.3, 0.5, 1.0].forEach(function (m) { c.fillRect(mx(m), ya - 3, 1, 6); c.fillText(m.toFixed(1), mx(m) - 8, ya + 16); });
      c.fillText("friction μ (log scale)", mx(1.2) - 150, H - 6);
      c.fillStyle = P["accent-soft"]; c.strokeStyle = P.accent; c.fillRect(mx(rg[0]), ya - 44, Math.max(2, mx(rg[1]) - mx(rg[0])), 22); c.strokeRect(mx(rg[0]), ya - 44, Math.max(2, mx(rg[1]) - mx(rg[0])), 22);
      c.fillStyle = P["ink-2"]; c.fillText("trained on", mx(rg[0]), ya - 50);
      var cov = mode === "hist" ? [rg[0], rg[1]] : [pol.muA / 1.1, pol.muA / 0.536];
      c.fillStyle = P["data-1"]; c.fillRect(mx(cov[0]), ya - 16, Math.max(2, mx(cov[1]) - mx(cov[0])), 6);
      c.fillStyle = P["ink-2"]; var tw = c.measureText("handled").width; c.fillText("handled", mx(cov[1]) + 6 + tw < W - 4 ? mx(cov[1]) + 6 : Math.max(2, mx(cov[0]) - tw - 6), ya - 9);
      var mu = TABLES[table];
      c.fillStyle = P["data-2"]; c.beginPath(); c.moveTo(mx(mu), ya + 20); c.lineTo(mx(mu) - 7, ya + 32); c.lineTo(mx(mu) + 7, ya + 32); c.closePath(); c.fill();
      c.fillStyle = P.ink; c.fillText(show ? "real μ = " + mu.toFixed(2) : "real μ = ?", RB.clamp(mx(mu) + 12, 4, W - 90), ya + 32);
    }
    function chart() {
      host.innerHTML = "";
      var sim = [], rl = [];
      for (var k = 0; k <= 20; k++) { var ww = k / 10, p = trainPolicy(mode, ww), r = realEval(mode, p, ww, TABLES[table], 21); sim.push([+(1 + ww).toFixed(1), p.sim.s]); rl.push([+(1 + ww).toFixed(1), r.s]); }
      StudyBench.lineChart(host, { title: "Success against the width of the friction range", height: 200, directLabels: false, x: { label: "range factor (training μ from 0.30 ÷ f to 0.30 × f)", min: 1, max: 3 }, y: { label: "success", min: 0, max: 1, fmt: function (v) { return Math.round(v * 100) + "%"; } },
        series: [{ name: "in simulation", color: "data-1", points: sim }, { name: "on the real table", color: "data-2", dash: true, points: rl }],
        caption: "Each point retrains the " + (mode === "hist" ? "history" : "memoryless") + " policy for that range and tests it on the current real table. Simplified toy, our numbers." });
    }
    function run(withChart) {
      pol = trainPolicy(mode, w); real = realEval(mode, pol, w, TABLES[table], 21); runs++;
      var pct = function (v) { return Math.round(v * 100) + "%"; };
      RB.setRO(body, "sim", pct(pol.sim.s)); RB.setRO(body, "real", pct(real.s));
      var g = Math.round((pol.sim.s - real.s) * 100); RB.setRO(body, "gap", (g > 0 ? "+" : "") + g + " pts");
      RB.setRO(body, "push", RB.fmt(real.pushes, 1));
      var rg = range(w), mu = TABLES[table];
      note.textContent = mode === "hist"
        ? "The first push assumes μ = " + rg[0].toFixed(2) + ", the lowest trained friction. The slide it sees reveals μ, like the LSTM in Peng et al. or RMA's adaptation module. It works while the real μ lies inside the range."
        : "Each push assumes μa = " + pol.muA.toFixed(2) + ". One fixed guess only handles frictions within a factor of about 2, so a wider range lowers success in simulation (P09 §VII-A.3).";
      if (!show) note.textContent += " The real friction is hidden.";
      draw();
      if (withChart !== false) chart();
      void mu;
    }
    RB.bindSeg(body, id + "-mode", function () { mode = segVal(body, id + "-mode") || mode; run(); });
    RB.bindSlider(body, id + "-w", fmtW, function (v) { w = v; run(false); });
    body.querySelector("#" + id + "-w").addEventListener("change", function () { chart(); });
    body.querySelector("#" + id + "-show").addEventListener("change", function (e) { show = e.target.checked; run(false); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { table = (table + 1) % TABLES.length; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { mode: mode, w: w, table: table, mu: TABLES[table], sim: pol.sim.s, real: real.s }; }, refresh: function () { chart(); } };
  }

  /* ---------- playground 2: a student estimates friction from history (teacher–student, RMA) ----------
     True friction switches from 0.30 to 0.12 halfway (a dry table becomes oily). Each 100 Hz step gives a noisy reading
     of μ from proprioception. The student averages the last k readings; the teacher reads μ directly (privileged). */
  function mountStudent(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Friction estimate", value: "student", options: [{ value: "teacher", label: "Teacher" }, { value: "student", label: "Student" }, { value: "dr", label: "DR only" }] }) +
      RB.slider({ id: id + "-k", label: "History k (steps)", min: 1, max: 100, step: 1, value: 1 }) +
      RB.slider({ id: id + "-sig", label: "Sensor noise", min: 0, max: 0.12, step: 0.01, value: 0.06, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New noise</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Timeline of true friction and the estimate, with push outcomes along the bottom"></canvas>' +
      '<figcaption class="sb-caption">Dashed = the true friction, which drops at step 150. Colored line = the estimate the policy acts on. Dots at the bottom = one push every 25 steps: green lands, red misses.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "err", k: "Mean estimate error |ẑ − z|" }, { id: "lag", k: "Steps to adapt after the switch" }, { id: "hits", k: "Pushes on target" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "ink-2", label: "true friction z", kind: "dash" }, { c: "data-1", label: "estimate ẑ", kind: "line" }, { c: "good", label: "push lands", kind: "dot" }, { c: "bad", label: "push misses", kind: "dot" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    var W = 520, H = 280, T = 300, mode = "student", k = 1, sig = 0.06, seed = 4, res = null;
    var mu = function (t) { return t < 150 ? 0.30 : 0.12; };
    function run() {
      var R = RB.rng(seed), y = [], est = [], err = 0, lag = null, hits = [];
      for (var t = 0; t < T; t++) {
        y.push(mu(t) + sig * R.normal());
        var e;
        if (mode === "teacher") e = mu(t);
        else if (mode === "dr") e = MU0;
        else { var s = 0, n = 0; for (var j = Math.max(0, t - k + 1); j <= t; j++) { s += y[j]; n++; } e = s / n; }
        est.push(e); err += Math.abs(e - mu(t));
      }
      for (var t2 = 150; t2 < T && lag === null; t2++) {
        var okAll = true; for (var q = t2; q < Math.min(T, t2 + 10); q++) if (Math.abs(est[q] - mu(q)) > 0.1 * mu(q)) { okAll = false; break; }
        if (okAll) lag = t2 - 150;
      }
      for (var p = 12; p < T; p += 25) { var d = TARGET * est[p] / mu(p); hits.push({ t: p, ok: Math.abs(d - TARGET) <= TOL }); }
      res = { est: est, hits: hits };
      RB.setRO(body, "err", RB.fmt(err / T, 3));
      RB.setRO(body, "lag", lag === null ? "never" : lag + " steps");
      RB.setRO(body, "hits", hits.filter(function (h) { return h.ok; }).length + " of " + hits.length);
      body.querySelector("#" + id + "-k").disabled = mode !== "student";
      note.textContent = mode === "teacher" ? "The teacher reads friction from the simulator. It is perfect, and it cannot run on the robot: real sensors do not report μ."
        : mode === "dr" ? "Without an estimate the policy acts for the middle of its training range. It is fine on the dry table and misses every push after the switch."
        : "The student averages the last k readings. Short histories are noisy; long ones lag after a change. RMA uses 50 steps (0.5 s at 100 Hz); Lee et al. compare 1, 20 and 100.";
      draw();
    }
    function draw() {
      if (!res) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = getComputedStyle(document.body).getPropertyValue("--font-mono");
      var sx = function (t) { return 44 + t / T * (W - 60); }, sy = function (v) { return 220 - RB.clamp(v, 0, 0.5) / 0.5 * 200; };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      c.font = "500 11px " + mono; c.fillStyle = P["ink-3"];
      [0, 0.1, 0.2, 0.3, 0.4, 0.5].forEach(function (v) { c.beginPath(); c.moveTo(sx(0), sy(v)); c.lineTo(sx(T), sy(v)); c.stroke(); c.fillText(v.toFixed(1), 12, sy(v) + 4); });
      [0, 100, 200, 300].forEach(function (t) { c.fillText(String(t), sx(t) - 8, 236); });
      c.fillText("step (100 Hz)", sx(T) - 84, 250);
      c.fillText("oily from here", sx(150) + 6, 16);
      c.strokeStyle = P["line-strong"]; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(sx(150), 20); c.lineTo(sx(150), 220); c.stroke();
      c.strokeStyle = P["ink-2"]; c.setLineDash([6, 4]); c.lineWidth = 1.5; c.beginPath(); c.moveTo(sx(0), sy(0.30)); c.lineTo(sx(150), sy(0.30)); c.lineTo(sx(150), sy(0.12)); c.lineTo(sx(T), sy(0.12)); c.stroke(); c.setLineDash([]);
      c.strokeStyle = P["data-1"]; c.lineWidth = 2; c.beginPath(); res.est.forEach(function (v, t) { if (t) c.lineTo(sx(t), sy(v)); else c.moveTo(sx(t), sy(v)); }); c.stroke();
      res.hits.forEach(function (h) { c.fillStyle = h.ok ? P.good : P.bad; c.beginPath(); c.arc(sx(h.t), 266, 5, 0, Math.PI * 2); c.fill(); });
      c.fillStyle = P["ink-3"]; c.fillText("pushes", 2, 270);
    }
    RB.bindSeg(body, id + "-mode", function () { mode = segVal(body, id + "-mode") || mode; run(); });
    RB.bindSlider(body, id + "-k", null, function (v) { k = v; run(); });
    RB.bindSlider(body, id + "-sig", function (v) { return (+v).toFixed(2); }, function (v) { sig = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { mode: mode, k: k, sig: sig, seed: seed }; } };
  }

  /* ---------- concept-card drawings (200×56, token colors only) ---------- */
  var ART = {
    gap: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="30" y="8" width="34" height="40" rx="2" class="rb-f-soft"/><rect x="110" y="30" width="34" height="18" rx="2" class="rb-f-sunk"/><line x1="20" y1="48" x2="160" y2="48" class="rb-s-line"/><path d="M152 8 V30" class="rb-s-acc"/><path d="M148 12 L152 8 L156 12 M148 26 L152 30 L156 26" class="rb-s-acc"/><text x="47" y="30" text-anchor="middle" class="rb-t-mono">ψₛ</text><text x="127" y="26" text-anchor="middle" class="rb-t-mono">ψᵣ</text><text x="162" y="23" class="rb-t-acc">G</text></svg>',
    sources: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="100" cy="28" r="20" class="rb-s-line"/><circle cx="100" cy="8" r="5" class="rb-f-acc"/><circle cx="120" cy="28" r="5" class="rb-f-soft"/><circle cx="100" cy="48" r="5" class="rb-f-soft"/><circle cx="80" cy="28" r="5" class="rb-f-soft"/><text x="108" y="12" class="rb-t-mono">o</text><text x="130" y="32" class="rb-t-mono">a (delay)</text><text x="108" y="54" class="rb-t-mono">s′</text><text x="72" y="32" text-anchor="end" class="rb-t-mono">r</text></svg>',
    dr: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (i) { return '<rect x="' + (8 + i * 24) + '" y="' + (10 + (i % 2) * 6) + '" width="20" height="' + (26 - (i % 3) * 4) + '" rx="2" class="' + (i % 2 ? "rb-f-sunk" : "rb-f-soft") + '" opacity="' + (0.5 + i * 0.1) + '"/>'; }).join("") + '<path d="M130 28 H156" class="rb-s-ink"/><path d="M152 24 L157 28 L152 32" class="rb-s-ink"/><circle cx="174" cy="28" r="12" class="rb-f-acc"/><text x="66" y="52" text-anchor="middle" class="rb-t-mono">ω ~ P(ω)</text><text x="174" y="54" text-anchor="middle" class="rb-t-mono">π</text></svg>',
    adr: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="90" y="6" width="20" height="8" class="rb-f-soft"/><rect x="70" y="20" width="60" height="8" class="rb-f-soft"/><rect x="40" y="34" width="120" height="8" class="rb-f-soft"/><path d="M36 38 H20 M164 38 H180" class="rb-s-acc"/><path d="M24 34 L20 38 L24 42 M176 34 L180 38 L176 42" class="rb-s-acc"/><line x1="100" y1="4" x2="100" y2="46" class="rb-s-line" stroke-dasharray="2 2"/><text x="100" y="54" text-anchor="middle" class="rb-t-mono">range widens when p̄ ≥ tH</text></svg>',
    ground: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="14" width="46" height="26" rx="3" class="rb-f-sunk"/><text x="31" y="31" text-anchor="middle" class="rb-t-mono">real</text><path d="M56 27 H78" class="rb-s-ink"/><rect x="80" y="14" width="40" height="26" rx="3" class="rb-f-soft"/><text x="100" y="31" text-anchor="middle" class="rb-t-acc">â</text><path d="M122 27 H144" class="rb-s-ink"/><rect x="146" y="14" width="46" height="26" rx="3" class="rb-f-surface"/><text x="169" y="31" text-anchor="middle" class="rb-t-mono">sim</text><text x="100" y="52" text-anchor="middle" class="rb-t-mono">transform the action</text></svg>',
    teacher: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="34" cy="24" r="14" class="rb-f-soft"/><circle cx="34" cy="24" r="4" class="rb-f-acc"/><text x="4" y="52" class="rb-t-mono">teacher: eₜ</text><path d="M56 24 H130" class="rb-s-ink" stroke-dasharray="4 3"/><path d="M126 20 L131 24 L126 28" class="rb-s-ink"/><text x="93" y="18" text-anchor="middle" class="rb-t-mono">imitate</text><rect x="138" y="12" width="44" height="24" rx="3" class="rb-f-surface"/>' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (142 + i * 9) + '" y="18" width="6" height="12" class="rb-f-sunk"/>'; }).join("") + '<text x="196" y="52" text-anchor="end" class="rb-t-mono">student: h</text></svg>',
    adapt: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4, 5, 6, 7].map(function (i) { return '<rect x="' + (8 + i * 12) + '" y="' + (16 + ((i * 7) % 5) * 2) + '" width="9" height="' + (14 - ((i * 7) % 5) * 2) + '" class="rb-f-sunk"/>'; }).join("") + '<path d="M106 25 H134" class="rb-s-ink"/><path d="M130 21 L135 25 L130 29" class="rb-s-ink"/><circle cx="154" cy="25" r="12" class="rb-f-soft"/><text x="154" y="29" text-anchor="middle" class="rb-t-acc">ẑ</text><text x="54" y="50" text-anchor="middle" class="rb-t-mono">last 50 steps</text><text x="178" y="29" class="rb-t-mono">φ</text></svg>',
    asym: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="4" y="6" width="44" height="18" rx="3" class="rb-f-sunk"/><text x="26" y="19" text-anchor="middle" class="rb-t-mono">image</text><rect x="4" y="32" width="44" height="18" rx="3" class="rb-f-soft"/><text x="26" y="45" text-anchor="middle" class="rb-t-mono">state</text><path d="M50 15 H84 M50 41 H84" class="rb-s-ink"/><rect x="86" y="6" width="50" height="18" rx="3" class="rb-f-surface"/><text x="111" y="19" text-anchor="middle" class="rb-t-ink">actor</text><rect x="86" y="32" width="50" height="18" rx="3" class="rb-f-surface" stroke-dasharray="3 2"/><text x="111" y="45" text-anchor="middle" class="rb-t-mono">critic</text><text x="142" y="45" class="rb-t-mono">training</text><text x="142" y="19" class="rb-t-mono">robot</text></svg>',
    delay: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="10" y1="30" x2="190" y2="30" class="rb-s-line"/>' + [0, 1, 2, 3, 4, 5, 6].map(function (i) { return '<line x1="' + (20 + i * 26) + '" y1="26" x2="' + (20 + i * 26) + '" y2="34" class="rb-s-line"/>'; }).join("") + '<circle cx="46" cy="30" r="5" class="rb-f-soft"/><text x="46" y="18" text-anchor="middle" class="rb-t-mono">command</text><circle cx="124" cy="30" r="5" class="rb-f-acc"/><text x="124" y="18" text-anchor="middle" class="rb-t-mono">takes effect</text><path d="M52 44 H118" class="rb-s-acc"/><text x="85" y="54" text-anchor="middle" class="rb-t-acc">delay</text></svg>'
  };

  /* ---------- worked example figure: grounding a push (numbers computed below, g = 9.81 m/s²) ---------- */
  var X = function (d) { return (40 + d * 800).toFixed(1); };
  var R0 = (40 + 0.55 * 800 + 8).toFixed(1), L0 = (40 + 0.45 * 800 - 6).toFixed(1);
  var WE_FIG = '<svg viewBox="0 0 560 190" role="img" aria-label="A pushing lane from 0 to 0.6 meters with a target zone at 0.45 to 0.55; simulated and real landing points for each step">' +
    '<rect x="' + X(0.45) + '" y="22" width="80" height="140" class="rb-f-soft" opacity="0.35"/><text x="' + X(0.5) + '" y="14" text-anchor="middle" class="rb-t-ink">target 0.50 m</text>' +
    '<g class="rb-t-mono"><text x="4" y="54">sim</text><text x="4" y="104">real</text><text x="4" y="154">fix</text></g>' +
    '<line x1="40" y1="50" x2="530" y2="50" class="rb-s-line"/><line x1="40" y1="100" x2="530" y2="100" class="rb-s-line"/><line x1="40" y1="150" x2="530" y2="150" class="rb-s-line"/>' +
    '<g class="rb-t-mono">' + [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6].map(function (d) { return '<text x="' + X(d) + '" y="184" text-anchor="middle">' + d.toFixed(1) + "</text>"; }).join("") + "</g>" +
    '<g data-on="1+"><circle cx="' + X(0.5) + '" cy="50" r="6" class="rb-f-surface"/><text x="' + R0 + '" y="42" class="rb-t-mono">1.716 m/s</text></g>' +
    '<g data-on="2+"><circle cx="' + X(0.375) + '" cy="100" r="6" style="fill:var(--bad)"/><text x="' + (40 + 0.36 * 800).toFixed(1) + '" y="94" text-anchor="end" class="rb-t-mono">0.375 m</text><path d="M' + X(0.375) + " 114 H" + X(0.5) + '" class="rb-s-acc"/><text x="' + (40 + 0.36 * 800).toFixed(1) + '" y="126" text-anchor="end" class="rb-t-acc">0.125 m short</text></g>' +
    '<g data-on="3-4"><path d="M' + X(0.375) + " 92 V58" + '" class="rb-s-ink" stroke-dasharray="3 3"/><text x="' + (40 + 0.36 * 800).toFixed(1) + '" y="72" text-anchor="end" class="rb-t-mono">f_real(1.716) = 0.375</text></g>' +
    '<g data-on="4+"><circle cx="' + X(0.375) + '" cy="50" r="6" class="rb-f-acc"/><text x="' + (40 + 0.36 * 800).toFixed(1) + '" y="40" text-anchor="end" class="rb-t-acc">â = 1.486 m/s</text></g>' +
    '<g data-on="5+"><circle cx="' + X(0.5) + '" cy="150" r="6" class="rb-f-acc"/><text x="' + L0 + '" y="168" text-anchor="end" class="rb-t-acc">retrained v = 1.981 m/s</text></g>' +
    '<g data-on="6"><circle cx="' + X(0.5) + '" cy="100" r="7" style="fill:var(--good)"/><text x="' + R0 + '" y="92" class="rb-t-ink">0.500 m</text></g></svg>';

  RB.topic({
    id: "a4",
    title: "Sim-to-real transfer",
    eyebrow: "Part A · Foundations",
    lede: "Policies trained in simulation meet a world with different friction, delays and pixels. Sim-to-real methods make that difference survivable or remove it.",
    refs: ["P08 §2–3", "P07 §4.3, §5", "P09 §VII-A.3"],
    why: "Simulation gives reinforcement learning (RL) unlimited, safe practice, but a policy tuned to one simulator can fail on the robot. You can widen what the simulator shows (randomization), teach the policy to infer what it cannot see (teacher–student), or correct the simulator with real data (grounding). P07 finds that the most mature RL successes mostly used zero-shot sim-to-real.",
    outcomes: [
      "Define the sim-to-real gap G(π) and name its four sources.",
      "Explain why too wide a randomization range fails to learn.",
      "Compare teacher–student distillation, RMA and asymmetric actor-critic.",
      "Compute a grounded action for a pushing task by hand.",
      "Trace how ADR, RMA and ASAP each changed their predecessor."
    ],
    concepts: [
      { name: "Sim-to-real gap", def: "How much a metric ψ drops when a simulator-trained policy runs on the robot: G(π) = ψₛ − ψᵣ.", ref: "P08 eq. 2", art: ART.gap, term: "sim-to-real-gap", sym: "gap" },
      { name: "Four gap sources", def: "Observations, actions (granularity, delay), transitions (dynamics) and rewards can each differ between simulator and reality.", ref: "P08 §2.1.2, Fig. 2", art: ART.sources, term: "sim-to-real-gap" },
      { name: "Domain randomization", def: "Train over many simulators with random textures (Tobin) or physics (Peng) so reality looks like one more sample.", ref: "P08 §3.1, §3.3", art: ART.dr, term: "domain-randomization", sym: "omega" },
      { name: "Automatic randomization", def: "ADR replaced hand-tuned ranges: each range starts at the calibrated value and widens when the policy succeeds at its edge.", ref: "arXiv 1910.07113", art: ART.adr, term: "automatic-domain-randomization", sym: "omega-bounds" },
      { name: "Grounding the simulator", def: "GAT keeps the simulator as a black box and transforms each action so simulated transitions match real ones.", ref: "P08 §3.3", art: ART.ground, term: "grounded-action-transformation" },
      { name: "Teacher–student", def: "A teacher learns with privileged simulator state; a student imitates it from sensor history it will have on the robot.", ref: "P09 §VII-D.1", art: ART.teacher, term: "teacher-student-distillation", sym: "pi-teacher" },
      { name: "Adaptation module", def: "RMA's student only regresses the teacher's latent ẑ from 0.5 s of history; the base policy is reused unchanged.", ref: "arXiv 2107.04034", art: ART.adapt, term: "adaptation-module", sym: "zhat" },
      { name: "Action delay", def: "Real commands take effect late. Randomizing or modeling the delay during training keeps a policy stable on hardware.", ref: "P08 §3.2", art: ART.delay, term: "action-delay", href: "#lab/sim2real" }
    ],
    flow: {
      title: "Where sim-to-real methods act", ref: "P08 Fig. 2 · P09 §VII-D.1", w: 820, h: 270,
      caption: "Training happens left of the robot; only the student crosses over. Real rollouts flow back to widen ranges (ADR) or to correct the simulator (GAT, ASAP).",
      nodes: [
        { id: "sim", x: 10, y: 30, w: 150, h: 56, label: "Randomized sim", sub: "ω ~ P(ω)", kind: "env" },
        { id: "teacher", x: 215, y: 30, w: 150, h: 56, label: "Teacher policy", sub: "sees privileged eₜ", kind: "agent" },
        { id: "student", x: 420, y: 30, w: 150, h: 56, label: "Student policy", sub: "sees history only", kind: "agent" },
        { id: "robot", x: 640, y: 30, w: 160, h: 56, label: "Real robot", sub: "zero-shot deploy", kind: "env" },
        { id: "log", x: 420, y: 176, w: 150, h: 56, label: "Real rollouts", sub: "states and actions", kind: "store" }
      ],
      edges: [
        { from: "sim", to: "teacher", label: "RL" },
        { from: "teacher", to: "student", label: "distill" },
        { from: "student", to: "robot", label: "deploy" },
        { from: "robot", to: "log", label: "record", sides: ["b", "r"], via: [[720, 204]] },
        { from: "log", to: "sim", label: "ground or widen ω", sides: ["l", "b"], via: [[85, 204]], dashed: true, dx: 150, dy: -10 }
      ],
      steps: [
        { on: ["sim"], text: "Each episode samples simulator parameters ω, such as friction, masses, delays and textures, from a randomization distribution P(ω)." },
        { on: ["sim", "sim>teacher", "teacher"], text: "A teacher is trained with RL, often PPO, and sees privileged state eₜ: true friction, object pose, terrain. An asymmetric critic may see it too." },
        { on: ["teacher>student", "student"], text: "A student imitates the teacher from what real sensors give: images or a history of proprioception. It must infer eₜ implicitly." },
        { on: ["student>robot", "robot"], text: "The student runs on the robot with no real-world training. This zero-shot recipe dominates mature locomotion and constrained manipulation results." },
        { on: ["robot>log", "log", "log>sim", "sim"], text: "Real rollouts close the loop: ADR-style methods widen or recenter ω, while GAT and ASAP learn an action correction that makes the simulator match reality." }
      ]
    },
    worked: {
      title: "Grounding a push with an action transformation",
      ref: "P08 §3.3 · GAT (SGAT §II-C)", prov: "Our toy numbers",
      eq: { tex: "\\hat{a}_t = \\class{sym-f}{f}_{\\mathrm{sim}}^{-1}\\big(\\class{sym-s}{s_t},\\ \\class{sym-f}{f}_{\\mathrm{real}}(\\class{sym-s}{s_t}, \\class{sym-a}{a_t})\\big)", words: "Predict where the real robot would go, then find the simulator action that goes there.", key: ["f", "s", "a", { glyph: "â", meaning: "grounded action run in sim" }] },
      figure: WE_FIG,
      steps: [
        { title: "The simulated push", text: "In sim μ = 0.30. A push at v slides v²/(2μg), so the policy pushes at √(2·0.30·9.81·0.5) = 1.716 m/s." },
        { title: "Reality falls short", text: "The real table has μ = 0.40. The same push stops at 1.716²/(2·0.40·9.81) = 0.375 m: 0.125 m short." },
        { title: "Learn the real forward model", text: "A few real pushes fit f_real. It predicts f_real(1.716 m/s) = 0.375 m for this table." },
        { title: "Invert the simulator", text: "Which sim push stops at 0.375 m? â = √(2·0.30·9.81·0.375) = 1.486 m/s. The grounded sim now reproduces the miss." },
        { title: "Retrain in the grounded sim", text: "RL finds v = 1.981 m/s: the transformer maps it to 1.716 m/s in sim, which lands at 0.50 m." },
        { title: "Deploy", text: "Real: 1.981²/(2·0.40·9.81) = 0.500 m. ASAP learns such a correction, Δa = −0.230 m/s here, directly with RL." }
      ]
    },
    ruleTitle: "Five rules of sim-to-real",
    rules: [
      { name: "Sim-to-real gap", ref: "P08 eq. 2", term: "sim-to-real-gap",
        tex: "\\class{sym-gap}{G(\\pi)} = \\class{sym-psi}{\\psi}_{s}(\\class{sym-pi}{\\pi_\\theta}) - \\class{sym-psi}{\\psi}_{r}(\\class{sym-pi}{\\pi_\\theta})",
        words: "Measure the same policy with the same calibrated metric in simulation and on the robot; the difference is the gap.",
        key: ["gap", "psi", "pi"] },
      { name: "Domain randomization objective", ref: "P08 eq. 1 · arXiv 1710.06537", term: "domain-randomization",
        before: "\\class{sym-J}{J}(\\class{sym-pi}{\\pi_\\theta}) = \\class{sym-E}{\\mathbb{E}}\\Big[\\textstyle\\sum_t \\class{sym-gamma}{\\gamma}^t \\class{sym-r}{r_t}\\Big]",
        tex: "\\class{sym-J}{J}(\\class{sym-pi}{\\pi_\\theta}) = \\class{sb-new}{\\class{sym-E}{\\mathbb{E}}_{\\class{sym-omega}{\\omega} \\sim \\class{sym-p-omega}{P(\\omega)}}}\\Big[\\class{sym-E}{\\mathbb{E}}\\Big[\\textstyle\\sum_t \\class{sym-gamma}{\\gamma}^t \\class{sym-r}{r_t} \\,\\Big|\\, \\class{sb-new}{\\class{sym-omega}{\\omega}}\\Big]\\Big]",
        words: "Maximize the average return over a distribution of simulators, not one. Peng et al. randomized 95 dynamics parameters this way.",
        key: ["J", "pi", "E", "omega", "p-omega", "gamma", "r"], diff: true, beforeLabel: "One simulator", afterLabel: "Randomized" },
      { name: "ADR boundary update", ref: "arXiv 1910.07113", term: "automatic-domain-randomization",
        tex: "\\bar{p}_i \\ge t_H \\Rightarrow \\class{sym-omega-bounds}{\\omega_i^{\\mathrm{hi}}} \\leftarrow \\class{sym-omega-bounds}{\\omega_i^{\\mathrm{hi}}} + \\Delta, \\qquad \\bar{p}_i \\le t_L \\Rightarrow \\class{sym-omega-bounds}{\\omega_i^{\\mathrm{hi}}} \\leftarrow \\class{sym-omega-bounds}{\\omega_i^{\\mathrm{hi}}} - \\Delta",
        words: "Test the policy with parameter i pinned at its bound. Widen the range if it succeeds often, narrow it if it fails; the lower bound moves the same way.",
        key: ["omega-bounds", { glyph: "p̄ᵢ", meaning: "mean success at the bound" }, { glyph: "t_H, t_L", meaning: "thresholds, 20 and 10" }, { glyph: "Δ", meaning: "step size, 0.02" }] },
      { name: "RMA: regress only the latent", ref: "arXiv 2010.11251 · 2107.04034", term: "adaptation-module",
        before: "\\class{sym-L}{\\mathcal{L}} = \\big\\|\\class{sym-pi-teacher}{\\bar\\pi}(\\class{sym-o}{o_t}, \\class{sym-e-priv}{e_t}) - \\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o_t}, \\class{sym-hist}{h_{t-k:t}})\\big\\|^2 + \\big\\|\\class{sym-z}{z_t} - \\class{sym-zhat}{\\hat z_t}\\big\\|^2",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\big\\|\\class{sym-z}{z_t} - \\class{sb-chg}{\\class{sym-adapt-phi}{\\phi}(\\class{sym-hist}{h_{t-k:t}})}\\big\\|^2, \\qquad \\class{sym-a}{a_t} = \\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o_t}, \\class{sym-a}{a_{t-1}}, \\class{sb-chg}{\\class{sym-zhat}{\\hat z_t}})",
        words: "Lee et al. trained the student to copy the teacher's actions and latent. RMA freezes the base policy and trains only a module φ that predicts the latent from 50 steps.",
        key: ["L", "pi-teacher", "o", "e-priv", "pi", "hist", "z", "zhat", "adapt-phi", "a"], diff: true, beforeLabel: "Lee 2020", afterLabel: "RMA" },
      { name: "ASAP: learn the action correction", ref: "arXiv 2502.01143 · P08 §3.3",  term: "delta-action-model",
        before: "\\hat{a}_t = \\class{sym-f}{f}_{\\mathrm{sim}}^{-1}\\big(\\class{sym-s}{s_t},\\ \\class{sym-f}{f}_{\\mathrm{real}}(\\class{sym-s}{s_t}, \\class{sym-a}{a_t})\\big)",
        tex: "\\class{sym-s}{s_{t+1}} = \\class{sym-f}{f}_{\\mathrm{sim}}\\big(\\class{sym-s}{s_t},\\ \\class{sym-a}{a_t} + \\class{sb-new}{\\class{sym-pi-delta}{\\pi^{\\Delta}}(\\class{sym-s}{s_t}, \\class{sym-a}{a_t})}\\big)",
        words: "GAT composes a real forward model with an inverse simulator model. ASAP trains one delta-action policy with RL so replayed real actions reproduce real states.",
        key: ["s", "f", "a", "pi-delta"], diff: true, beforeLabel: "GAT", afterLabel: "ASAP" }
    ],
    algorithm: {
      title: "Automatic domain randomization", ref: "arXiv 1910.07113", prov: "Our notation: ω for parameters",
      lines: [
        '<span class="kw">init</span> every range [<span data-sym="omega-bounds">ωᵢˡᵒ, ωᵢʰⁱ</span>] at the calibrated value',
        '<span class="kw">loop</span>:',
        '    <span class="kw">with prob.</span> 0.5: pick parameter i and a bound; pin <span data-sym="omega">ωᵢ</span> there, sample the rest',
        '        run <span data-sym="pi">π_θ</span>, append its success to buffer Dᵢ',
        '        <span class="kw">if</span> |Dᵢ| = 240: p̄ ← mean(Dᵢ); widen by 0.02 if p̄ ≥ 20, narrow if p̄ ≤ 10; clear Dᵢ',
        '    <span class="kw">else</span>: sample <span data-sym="omega">ω</span> ~ <span data-sym="p-omega">P(ω)</span> and collect training rollouts',
        '    update <span data-sym="pi">π_θ</span> with PPO <span class="cm">// asymmetric actor-critic, LSTM policy</span>'
      ]
    },
    playgrounds: [
      {
        id: "dr", title: "How wide should friction be randomized?", ref: "P09 §VII-A.3 · arXiv 1710.06537", prov: "Simplified: 1-D pushing toy, no network",
        try: "Keep the range at ×1.00 and look at the real row. Widen it to ×1.5, then ×2.5. Switch to With history and repeat. Then try New real table.",
        mount: mountDR,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a4-dr";
          return [
            { target: q("canvas"), title: "Trained on one friction", text: "The policy trained on μ = 0.30 only. Every simulated push lands. The real table is more slippery, μ = 0.22, so every real push overshoots." },
            { target: q("#" + id + "-w"), title: "Randomize friction", text: "Widen the training range. The memoryless policy now assumes lower friction and approaches the target in shorter pushes.", do: function (a) { return a.set(q("#" + id + "-w"), 0.5); }, task: "Set the range to ×1.40 or wider", expect: function () { return api.state().w >= 0.4; } },
            { target: q("#" + id + "-w"), title: "Too wide to learn", text: "A very wide range cannot be covered by one fixed guess. Success in simulation falls: the policy fails to learn, as P09 warns.", do: function (a) { return a.set(q("#" + id + "-w"), 1.5); }, task: "Set the range to ×2.40 or wider", expect: function () { return api.state().w >= 1.4; } },
            { target: q("#" + id + "-mode"), title: "Add memory", text: "With history, the first push reveals the friction. Success stays high across the whole range, as Peng's LSTM beat the memoryless policy.", do: function (a) { return a.click(q("#" + id + '-mode [value="hist"]')); }, task: "Choose With history", expect: function () { return api.state().mode === "hist"; } },
            { target: q("#" + id + "-go"), title: "A different robot", text: "Try another real table. Adaptation only works while the real friction lies inside the range the policy trained on.", do: function (a) { return a.click(q("#" + id + "-go")); }, task: "Click New real table", expect: function () { return api.state().table !== 0; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Find the narrowest range that still transfers to every table, first with history, then without. Watch the gap G(π)." }
          ];
        }
      },
      {
        id: "student", title: "A student infers friction from history", ref: "arXiv 2107.04034 · 2010.11251", prov: "Simplified: moving-average student, 1-D friction",
        try: "With k = 1 the estimate is noise and pushes miss. Raise k to 50, then 100, and watch the steps after the switch. Compare with the teacher and with DR only.",
        mount: mountStudent,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a4-student";
          return [
            { target: q("canvas"), title: "One reading is noise", text: "With one step of history the student's estimate jumps around the true friction, and many pushes miss even on the dry table." },
            { target: q("#" + id + "-k"), title: "Half a second", text: "RMA's adaptation module reads 50 steps, 0.5 s at 100 Hz. The estimate settles and the pushes land.", do: function (a) { return a.set(q("#" + id + "-k"), 50); }, task: "Set history k to 40 or more", expect: function () { return api.state().k >= 40; } },
            { target: q("#" + id + "-k"), title: "Long history lags", text: "A 100-step window averages old, dry readings after the table turns oily, so the first pushes after the switch miss.", do: function (a) { return a.set(q("#" + id + "-k"), 100); }, task: "Set history k to 90 or more", expect: function () { return api.state().k >= 90; } },
            { target: q("#" + id + "-mode"), title: "No estimate at all", text: "A policy trained with randomization alone acts for the middle of its range. It cannot notice the oily table.", do: function (a) { return a.click(q("#" + id + '-mode [value="dr"]')); }, task: "Choose DR only", expect: function () { return api.state().mode === "dr"; } },
            { target: q("#" + id + "-sig"), title: "Your turn", text: "Choose Student again and raise the sensor noise. Find the history length that lands most pushes at each noise level." }
          ];
        }
      }
    ],
    methods: ["domain-randomization", "dynamics-randomization", "adr-solving-rubik-s-cube", "asymmetric-actor-critic", "teacher-student-terrain", "rma", "gat", "asap", "industreal", "local-policies"],
    open: [
      { title: "Contact is still hard to simulate", text: "MuJoCo's soft contacts allow penetration and PhysX approximates friction cones with pyramids; contact-rich tasks inherit these errors.", refs: "P09 §VII-A.3 · P07 §4.3.5" },
      { title: "Choosing randomization ranges", text: "Too wide and the policy fails to learn; too narrow and it fails to transfer. Tuning is laborious and case-specific.", refs: "P09 §VII-A.3" },
      { title: "Beyond enumerable tasks", text: "Zero-shot transfer works where dense rewards can be designed beforehand: grasping, in-hand, assembly. Open-world pick-and-place remains less successful.", refs: "P07 §4.3.5, §5" },
      { title: "Predicting real performance", text: "Sim-to-sim and scaled-down tests are cheaper and safer, but how well they predict real success depends on the metric.", refs: "P08 §5.1–5.2" }
    ],
    takeaways: [
      "The sim-to-real gap G(π) compares one policy under one calibrated metric in simulation and on the robot.",
      "Randomization trades optimality for robustness: wider ranges transfer more often but can stop the policy from learning.",
      "Memory lets a policy identify the real dynamics online: Peng's LSTM reached 0.89 real success against 0.67 without memory.",
      "Teacher–student training moves privileged simulator knowledge into a policy that uses only onboard sensors.",
      "Grounding methods use real data to correct the simulator; ASAP learns that correction as a delta action."
    ],
    quiz: [
      { q: "How does P08 define the sim-to-real gap G(π)?", options: ["Real reward minus simulated reward during training", "Simulated metric minus real metric for the same policy", "The number of real episodes needed", "The error of the dynamics model"], correct: 1, why: "P08 eq. 2: G(π) = ψₛ(π) − ψᵣ(π), with ψ calibrated and applied identically in both environments." },
      { q: "According to P09, what happens when the randomization range is too large?", options: ["The policy transfers perfectly", "The policy fails to learn", "Training becomes faster", "The simulator crashes"], correct: 1, why: "P09 §VII-A.3: a larger range is hard for the policy to fit (fail to learn); a smaller range may not cover reality (fail to transfer)." },
      { q: "What does RMA's adaptation module predict from 50 steps of history?", options: ["The next joint torques", "The teacher's extrinsics latent z", "The terrain height map", "The reward"], correct: 1, why: "RMA regresses an 8-D extrinsics latent from 0.5 s of states and actions with an MSE loss; the base policy consumes the estimate (arXiv 2107.04034)." },
      { q: "In the asymmetric actor-critic, which part sees the full simulator state?", options: ["The actor, at test time", "The critic, during training only", "Both, always", "Neither"], correct: 1, why: "The critic gets full state and is discarded at test time, so the image-based actor alone transfers to the real Fetch (arXiv 1710.06542)." },
      { q: "What did removing randomization of the action timestep do in Peng et al.?", options: ["Nothing measurable", "Real success fell from 0.89 to 0.29", "Real success rose to 0.95", "Simulation success fell to zero"], correct: 1, why: "The dynamics-randomization ablation reports 0.29 ± 0.11 real success with a fixed timestep against 0.89 with everything randomized (arXiv 1710.06537)." }
    ],
    cards: [
      { front: "What are P08's four sources of the sim-to-real gap?", back: "Observation (perception, representation), action (granularity, delay), transition (dynamics) and reward mismatches.", ref: "P08 §2.1.2, Fig. 2" },
      { front: "What did Tobin et al. find when training without distractors?", back: "Real localization error with distractors rose from 1.8 cm to 7.2 cm.", ref: "arXiv 1703.06907" },
      { front: "How much did ADR improve real block reorientation?", back: "Mean consecutive successes: 2.7 with manual randomization, 32.0 with the largest ADR policy.", ref: "arXiv 1910.07113" },
      { front: "What happened to RMA without its adaptation module?", back: "Simulation success fell from 73.5% to 52.1%; the real 15 cm step-down fell from 80% to 0%.", ref: "arXiv 2107.04034" },
      { front: "What is GAT's action transformer?", back: "g(s, a) = f_sim⁻¹(s, f_real(s, a)): the simulator action that reproduces the predicted real next state.", ref: "P08 §3.3 · arXiv 2008.01281" },
      { front: "How did the asymmetric actor-critic do on real Fetch without randomization?", back: "0 of 5 on all three tasks, against 5 of 5 with randomization.", ref: "arXiv 1710.06542" }
    ],
    terms: {
      "sim-to-real-gap": { name: "sim-to-real gap", aliases: ["reality gap", "sim2real gap"], group: "learning", sym: "G(π)", symTex: "G(\\pi)", def: "The difference ψₛ(π) − ψᵣ(π) in a calibrated metric when a policy trained in simulation is evaluated in simulation and in the real world.", note: "It is measured on the same policy; a large sim score alone says nothing about transfer.", ref: "P08 eq. 2", scene: "system", focus: ["simulator", "robot"], look: "same policy, two environments", uses: [] },
      "domain-randomization": { name: "domain randomization", aliases: ["DR", "dynamics randomization", "visual randomization"], group: "learning", sym: "ω", symTex: "\\omega", def: "Introducing variability in the simulator, visual or physical, so the trained policy is robust across conditions and treats reality as one more variation.", note: "It trades optimality for robustness; RMA and ASAP call randomized policies conservative.", ref: "P08 §3.1, §3.3", scene: "system", focus: ["simulator", "data-sim"], look: "many varied simulators", uses: ["sim-to-real-gap"] },
      "automatic-domain-randomization": { name: "automatic domain randomization", aliases: ["ADR (automatic)"], group: "learning", def: "A curriculum that starts every randomization range at the calibrated value and widens or narrows each bound from the policy's success at that bound.", note: "P08 uses ADR for Active DR (Mehta et al.), which learns where to sample instead.", ref: "arXiv 1910.07113", scene: "system", focus: ["simulator", "policy-update"], look: "ranges growing around the simulator", uses: ["domain-randomization"] },
      "system-identification": { name: "system identification", aliases: ["SysID", "real-to-sim"], group: "physics", def: "Estimating simulation parameters that best explain real robot trajectories, by optimization or search, to raise model fidelity.", note: "Real data rarely cover all states and actions, so the fitted model can still be wrong elsewhere.", ref: "P09 §VII-A.3", scene: "system", focus: ["data-robot", "simulator"], look: "real data tuning the simulator", uses: ["sim-to-real-gap"] },
      "domain-adaptation": { name: "domain adaptation", aliases: ["DA"], group: "learning", def: "Aligning source (simulation) and target (real) distributions, of images or dynamics, often with adversarial training, or fine-tuning a policy with real data.", note: "RL-CycleGAN adapts images; P09 uses the term for real-world fine-tuning.", ref: "P08 §3.1, §3.3 · P09 §VII-A.3", scene: "system", focus: ["camera-image", "simulator"], look: "sim images mapped to real style", uses: [] },
      "grounded-action-transformation": { name: "grounded action transformation", aliases: ["GAT", "grounding"], group: "learning", def: "Grounding a black-box simulator by replacing each action with the one whose simulated next state matches a learned model of the real next state.", note: "Its forward model is deterministic; SGAT learns a distribution for stochastic worlds.", ref: "P08 §3.3", scene: "system", focus: ["simulator", "controller"], look: "an action transformer before the simulator", uses: ["system-identification"] },
      "delta-action-model": { name: "delta action model", aliases: ["residual action model", "ASAP"], group: "learning", sym: "π^Δ", symTex: "\\pi^{\\Delta}", def: "A policy trained with RL to add a corrective action inside the simulator so that replayed real actions reproduce the recorded real states.", note: "It is used only to fine-tune the policy; the deployed policy runs without it.", ref: "arXiv 2502.01143", scene: "system", focus: ["simulator", "action-head"], look: "a correction added inside the simulator", uses: ["grounded-action-transformation"] },
      "privileged-information": { name: "privileged information", aliases: ["privileged state"], group: "learning", sym: "eₜ", symTex: "e_t", def: "Quantities the simulator knows but real sensors do not report, such as friction, masses, contact states or exact object poses.", note: "Only training-time components (teacher, critic) may use it.", ref: "arXiv 2010.11251 · P07 §4.3.3", scene: "system", focus: ["simulator", "proprio"], look: "simulator state hidden from sensors", uses: [] },
      "teacher-student-distillation": { name: "teacher–student distillation", aliases: ["privileged learning", "teacher-student"], group: "learning", def: "A two-stage recipe: a teacher trained with RL on privileged observations, then a student that clones it using only partial, onboard observations.", note: "The student is usually trained on its own rollouts with teacher labels (DAgger-style).", ref: "P09 §VII-D.1", scene: "system", focus: ["simulator", "policy-update"], look: "teacher labels flowing to the student", uses: ["privileged-information"] },
      "adaptation-module": { name: "adaptation module", aliases: ["RMA", "extrinsics estimator"], group: "learning", sym: "ẑₜ", symTex: "\\hat z_t", def: "A network that predicts the latent encoding of environment parameters from a short history of states and actions, updated online at deployment.", note: "It estimates a policy-relevant latent, not the physical parameters; predicting parameters did worse in RMA.", ref: "arXiv 2107.04034", scene: "system", focus: ["proprio", "latent"], look: "history compressed into a latent", uses: ["teacher-student-distillation"] },
      "asymmetric-actor-critic": { name: "asymmetric actor-critic", aliases: ["asymmetric critic"], group: "learning", def: "An actor-critic method whose critic receives full simulator state while the actor sees only the observations available on the robot.", note: "The critic is discarded after training, so its privileged input costs nothing at deployment.", ref: "arXiv 1710.06542", scene: "system", focus: ["camera-image", "policy-update"], look: "critic with state, actor with images", uses: ["privileged-information"] },
      "action-delay": { name: "action delay", aliases: ["latency", "random-delay MDP"], group: "actions", def: "The lag between issuing an action and its effect, which simulators usually ignore; delayed MDPs augment the state with recent actions and delays.", note: "Peng et al.'s policy dropped from 0.89 to 0.29 real success without timestep randomization.", ref: "P08 §3.2", scene: "system", focus: ["controller", "robot"], look: "commands arriving late at the robot", uses: [] },
      "actuator-network": { name: "actuator network", aliases: ["actuator net"], group: "physics", def: "A network trained on real data that maps joint position errors and velocity history to torque, placed inside a rigid-body simulator.", note: "It fixes the actuation gap; ANYmal's net cut torque error from 5.74 to 0.966 Nm on test data.", ref: "arXiv 1901.08652", scene: "robot", focus: ["joint"], look: "the motor between command and joint", uses: ["system-identification"] }
    },
    symbols: [
      { id: "gap", tex: "G(\\pi)", glyph: "G(π)", kind: "Functions", meaning: "sim-to-real gap: a policy's metric in simulation minus its metric on the real robot", short: "sim-to-real gap", first: "a4", read: "G of pi", papers: "P08 eq. 2: G(π)" },
      { id: "psi", tex: "\\psi", glyph: "ψ", kind: "Functions", meaning: "evaluation metric (success rate, error) applied identically in simulation (ψₛ) and reality (ψᵣ)", short: "evaluation metric", first: "a4", read: "psi", papers: "P08 eq. 2: ψ_s, ψ_r" },
      { id: "p-omega", tex: "P(\\omega)", glyph: "P(ω)", kind: "Functions", meaning: "randomization distribution over simulator parameters", short: "randomization distribution", first: "a4", read: "P of omega", papers: "Peng: ρ_μ · ADR: P_φ(λ)" },
      { id: "omega-bounds", tex: "\\omega_i^{\\mathrm{lo}}, \\omega_i^{\\mathrm{hi}}", glyph: "ωᵢˡᵒ, ωᵢʰⁱ", kind: "Parameters", meaning: "lower and upper bound of the range of randomized parameter i", short: "range bounds of parameter i", first: "a4", read: "omega i low, omega i high", papers: "ADR: φᵢᴸ, φᵢᴴ" },
      { id: "e-priv", tex: "e_t", glyph: "eₜ", kind: "Signals", meaning: "privileged simulator information (friction, masses, terrain, contacts)", short: "privileged information", first: "a4", read: "e sub t", papers: "RMA: e_t · Lee 2020: x_t" },
      { id: "hist", tex: "h_{t-k:t}", glyph: "hₜ₋ₖ:ₜ", kind: "Signals", meaning: "history of the last k proprioceptive states and actions", short: "state-action history", first: "a4", read: "h from t minus k to t", papers: "RMA: x_{t−k:t−1}, a_{t−k:t−1} · Lee 2020: H" },
      { id: "zhat", tex: "\\hat z_t", glyph: "ẑₜ", kind: "Signals", meaning: "latent estimated by the student or adaptation module from history", short: "estimated latent", first: "a4", read: "z hat sub t", papers: "RMA: ẑ_t · Lee 2020: l_t(H)" },
      { id: "adapt-phi", tex: "\\phi", glyph: "φ", kind: "Functions", meaning: "adaptation module: maps state-action history to a latent estimate", short: "adaptation module", first: "a4", read: "phi", papers: "RMA: φ" },
      { id: "pi-teacher", tex: "\\bar\\pi", glyph: "π̄", kind: "Functions", meaning: "teacher policy trained with privileged information", short: "teacher policy", first: "a4", read: "pi bar", papers: "Lee 2020: ā_t(o_t, x_t)" },
      { id: "pi-delta", tex: "\\pi^{\\Delta}", glyph: "πΔ", kind: "Functions", meaning: "delta action model: corrective action added inside the simulator", short: "delta action model", first: "a4", read: "pi delta", papers: "ASAP: π^Δ_θ(s_t, a_t)" }
    ],
    ledger: [
      { where: "Topic 04 · playground 1", source: "The brief plans a cart-pole with a hidden real parameter; the sim-to-real station also uses a cart-pole", page: "A puck-pushing toy with hidden real friction", why: "Manipulation focus, and no duplication of the station.", kind: "Our choice" },
      { where: "Topic 04 · playgrounds", source: "Real policies are neural networks trained with RL in physics engines", page: "Coulomb sliding d = v²/(2μg), a grid-searched push rule, and a moving-average student", why: "Shows the mechanism, not a reproduction.", kind: "Simplified" },
      { where: "Topic 04 · ADR", source: "P08 §3.3 uses ADR for Active Domain Randomization (Mehta et al., arXiv 1904.04762)", page: "The site uses ADR for Automatic Domain Randomization (arXiv 1910.07113)", why: "Two different methods share one acronym.", kind: "Sources disagree" },
      { where: "Topic 04 · rules", source: "ADR writes parameters λ with bounds φᵢᴸ, φᵢᴴ; RMA writes e_t and φ; Lee 2020 writes x_t, H and l_t", page: "ω, ωᵢˡᵒ/ωᵢʰⁱ, eₜ, h_{t−k:t}, ẑₜ", why: "House notation: λ is contact force, μ is friction.", kind: "Our choice" },
      { where: "Topic 04 · worked example", source: "The GAT paper (AAAI 2017) is not on arXiv; its equation is restated in SGAT §II-C (arXiv 2008.01281)", page: "Equation and loop taken from SGAT's restatement", why: "Survey-level card for GAT.", kind: "Simplified" },
      { where: "Topic 04 · RMA rule", source: "Lee 2020 regresses both teacher action and latent; RMA's student regresses only the latent", page: "Shown as a diff, with the removed action term explained in words", why: "The diff notation marks new or changed terms only.", kind: "Our choice" }
    ]
  });
})();
