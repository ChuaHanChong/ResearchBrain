/* Topic 22 · Safety of embodied AI. Sources: P13 (Fig. 1, §4.1.2, §5.1, §6.4, §7, §8; Tables 14–16), method papers in data/methods.json (topic F2). */
(function () {
  "use strict";
  var RB = window.RB;

  /* read the pressed option directly (robust to how the core passes the callback argument) */
  function segVal(root, sid) { var b = root.querySelector("#" + sid + ' [aria-pressed="true"]'); return b ? b.value : null; }
  function mono() { return getComputedStyle(document.body).getPropertyValue("--font-mono"); }
  function body_() { return getComputedStyle(document.body).getPropertyValue("--font-body"); }

  /* ---------- playground 1: a control barrier function filter overriding a nominal command ---------- */
  /* Toy: a point end effector with velocity control (x' = a), a round obstacle, and a nominal policy that heads
     straight for the goal. The filter solves the one-constraint QP of VLSA in closed form. */
  var OBS_R = 0.12, EE_R = 0.02, DT = 0.02, NSTEP = 450, VMAX = 0.5;
  function simCBF(p) {
    var x = [0.05, 0], goal = [0.95, 0], c = [0.5, p.oy], ch = [0.5, p.oy + p.perr], R = OBS_R + EE_R;
    var path = [x.slice()], hs = [], dus = [], minGap = 1e9, hit = false, reached = -1, nOver = 0;
    for (var k = 0; k < NSTEP; k++) {
      var g0 = goal[0] - x[0], g1 = goal[1] - x[1], gn = Math.sqrt(g0 * g0 + g1 * g1);
      var sp = Math.min(VMAX, 2 * gn), a = gn > 1e-9 ? [g0 / gn * sp, g1 / gn * sp] : [0, 0], an = a.slice();
      if (p.filter === "cbf") {
        var d0 = x[0] - ch[0], d1 = x[1] - ch[1], h = d0 * d0 + d1 * d1 - R * R, gr = [2 * d0, 2 * d1];
        var cond = gr[0] * a[0] + gr[1] * a[1] + p.alpha * h, gg = gr[0] * gr[0] + gr[1] * gr[1];
        if (cond < 0 && gg > 1e-12) { a = [a[0] - cond / gg * gr[0], a[1] - cond / gg * gr[1]]; nOver++; }
      }
      var du = Math.sqrt((a[0] - an[0]) * (a[0] - an[0]) + (a[1] - an[1]) * (a[1] - an[1]));
      x = [x[0] + DT * a[0], x[1] + DT * a[1]];
      var e0 = x[0] - c[0], e1 = x[1] - c[1], dist = Math.sqrt(e0 * e0 + e1 * e1), gap = dist - R;
      minGap = Math.min(minGap, gap); if (gap < 0) hit = true;
      hs.push(dist * dist - R * R); dus.push(du); path.push(x.slice());
      if (reached < 0 && Math.abs(x[0] - goal[0]) < 0.02 && Math.abs(x[1] - goal[1]) < 0.02) reached = (k + 1) * DT;
    }
    return { path: path, hs: hs, dus: dus, minGap: minGap, hit: hit, reached: reached, over: nOver, c: c, ch: ch, R: R, goal: goal };
  }

  function mountCBF(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-filt", label: "Safety filter", value: "cbf", options: [{ value: "off", label: "Filter off" }, { value: "cbf", label: "CBF filter" }] }) +
      RB.slider({ id: id + "-alpha", label: "Decay rate α", min: 1, max: 40, step: 1, value: 10 }) +
      RB.slider({ id: id + "-oy", label: "Obstacle offset (m)", min: -0.1, max: 0.1, step: 0.01, value: 0.04, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-perr", label: "Perception error (m)", min: 0, max: 0.12, step: 0.01, value: 0, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-play">Play motion ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Top view: the end effector moves from start to goal past a round obstacle"></canvas>' +
      '<canvas class="rb-canvas" id="' + id + '-hv" aria-label="Barrier value h over time, with the zero line"></canvas>' +
      '<figcaption class="sb-caption">Top: dashed = the policy\'s straight path; solid = what the robot executes. Bottom: h(x) over time. The filter acts only where the path bends; with correct perception h stays above zero.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "gap", k: "Closest gap to obstacle", u: "cm" }, { id: "hit", k: "Collision" }, { id: "goal", k: "Reaches goal" }, { id: "over", k: "Steps the filter changed" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "ink-3", label: "nominal path", kind: "dash" }, { c: "data-1", label: "executed path", kind: "line" }, { c: "warn", label: "obstacle as perceived", kind: "dash" }, { c: "bad", label: "collision", kind: "dot" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), hv = body.querySelector("#" + id + "-hv"), note = body.querySelector("[data-note]");
    var st = { filter: "cbf", alpha: 10, oy: 0.04, perr: 0 }, res = null, anim = -1, raf = 0, W = 520, H = 300, HW = 520, HH = 120;
    function toPx(p) { return [30 + p[0] * 460, 150 - p[1] * 460]; }
    function draw() {
      if (!res) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H);
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (var gx = 30; gx <= W; gx += 46) { c.beginPath(); c.moveTo(gx, 0); c.lineTo(gx, H); c.stroke(); }
      for (var gy = 12; gy <= H; gy += 46) { c.beginPath(); c.moveTo(0, gy); c.lineTo(W, gy); c.stroke(); }
      var oc = toPx(res.c);
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.beginPath(); c.arc(oc[0], oc[1], OBS_R * 460, 0, Math.PI * 2); c.fill(); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono(); c.textAlign = "center"; c.fillText("obstacle", oc[0], oc[1] + 4);
      if (st.filter === "cbf") {
        var ec = toPx(res.ch); c.strokeStyle = P.warn; c.setLineDash([5, 4]); c.lineWidth = 1.5; c.beginPath(); c.arc(ec[0], ec[1], res.R * 460, 0, Math.PI * 2); c.stroke(); c.setLineDash([]);
      }
      var s = toPx([0.05, 0]), g = toPx(res.goal);
      c.strokeStyle = P["ink-3"]; c.setLineDash([4, 4]); c.lineWidth = 1.5; c.beginPath(); c.moveTo(s[0], s[1]); c.lineTo(g[0], g[1]); c.stroke(); c.setLineDash([]);
      c.fillStyle = P["good-soft"]; c.strokeStyle = P.good; c.beginPath(); c.arc(g[0], g[1], 10, 0, Math.PI * 2); c.fill(); c.stroke();
      var last = anim >= 0 ? Math.min(anim, res.path.length - 1) : res.path.length - 1;
      c.strokeStyle = P["data-1"]; c.lineWidth = 2.5; c.beginPath();
      for (var i = 0; i <= last; i++) { var q = toPx(res.path[i]); if (i) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); }
      c.stroke();
      if (res.hit) {
        c.fillStyle = P.bad;
        for (var j = 0; j <= last; j++) { var e0 = res.path[j][0] - res.c[0], e1 = res.path[j][1] - res.c[1]; if (Math.sqrt(e0 * e0 + e1 * e1) < res.R) { var z = toPx(res.path[j]); c.beginPath(); c.arc(z[0], z[1], 5, 0, Math.PI * 2); c.fill(); break; } }
      }
      var ee = toPx(res.path[last]); c.fillStyle = P.ink; c.beginPath(); c.arc(ee[0], ee[1], EE_R * 460, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + body_(); c.textAlign = "left"; c.fillText("start", s[0] - 4, s[1] + 26); c.textAlign = "center"; c.fillText("goal", g[0], g[1] + 26);
      /* h(t) strip */
      var hc = RB.canvas(hv, HW, HH), n = res.hs.length, hmax = 0.2, hmin = -0.02;
      var sx = function (k) { return 40 + k / (n - 1) * (HW - 56); }, sy = function (v) { return 12 + (hmax - Math.max(hmin, Math.min(hmax, v))) / (hmax - hmin) * (HH - 34); };
      hc.fillStyle = P.surface; hc.fillRect(0, 0, HW, HH);
      hc.fillStyle = P["bad-soft"]; hc.fillRect(40, sy(0), HW - 56, sy(hmin) - sy(0));
      hc.strokeStyle = P["line-strong"]; hc.lineWidth = 1; hc.beginPath(); hc.moveTo(40, sy(0)); hc.lineTo(HW - 16, sy(0)); hc.stroke();
      hc.strokeStyle = P["data-1"]; hc.lineWidth = 2; hc.beginPath();
      for (var k = 0; k < n && k <= last; k++) { if (k) hc.lineTo(sx(k), sy(res.hs[k])); else hc.moveTo(sx(k), sy(res.hs[k])); }
      hc.stroke();
      hc.fillStyle = P["ink-3"]; hc.font = "500 11px " + mono(); hc.textAlign = "left";
      hc.fillText("h(x)", 4, 16); hc.fillText("0", 26, sy(0) + 4); hc.fillText("time →", HW - 60, HH - 6);
    }
    function run() {
      res = simCBF(st);
      RB.setRO(body, "gap", RB.fmt(res.minGap * 100, 1));
      RB.setRO(body, "hit", res.hit ? "yes" : "no");
      RB.setRO(body, "goal", res.reached >= 0 ? RB.fmt(res.reached, 1) + " s" : "no (stalled)");
      RB.setRO(body, "over", res.over + " of " + NSTEP);
      var txt;
      if (st.filter === "off") txt = "No filter: the policy's action goes straight to the motors, through the obstacle.";
      else if (res.hit) txt = "The filter kept the perceived obstacle safe, but the perceived one is in the wrong place. VLSA names perception errors as the main reason it misses 100% collision avoidance.";
      else if (res.reached < 0) txt = "Safe but stuck: with the obstacle dead ahead, the correction points straight back and the robot stops. Safety corrections can cost task success, as VLSA reports.";
      else txt = "The filter leaves the action alone until h would shrink faster than αh, then bends it the minimum amount. VLSA uses α(h) = 10h.";
      note.textContent = txt;
      body.querySelector("#" + id + "-alpha").disabled = body.querySelector("#" + id + "-perr").disabled = st.filter === "off";
      anim = -1; draw();
    }
    function play() {
      cancelAnimationFrame(raf); anim = 0;
      var step = function () { anim += 6; draw(); if (anim < res.path.length - 1) raf = requestAnimationFrame(step); else { anim = -1; draw(); } };
      raf = requestAnimationFrame(step);
    }
    RB.bindSeg(body, id + "-filt", function () { st.filter = segVal(body, id + "-filt"); run(); });
    RB.bindSlider(body, id + "-alpha", null, function (v) { st.alpha = v; run(); });
    RB.bindSlider(body, id + "-oy", function (v) { return (+v).toFixed(2); }, function (v) { st.oy = Math.round(v * 100) / 100; run(); });
    RB.bindSlider(body, id + "-perr", function (v) { return (+v).toFixed(2); }, function (v) { st.perr = Math.round(v * 100) / 100; run(); });
    body.querySelector("#" + id + "-play").addEventListener("click", play);
    RB.onTheme(draw);
    run();
    return { state: function () { return { filter: st.filter, alpha: st.alpha, oy: st.oy, perr: st.perr, hit: res.hit, reached: res.reached }; } };
  }

  /* ---------- playground 2: smooth drift hidden in action chunks (SilentDrift mechanism) ---------- */
  /* Toy: lateral error y (m) during a 60-step approach. When the trigger is visible in the last ~20 steps, the poisoned
     policy adds drift δ_t each step. At each query it partly corrects the error it sees, but inside a chunk it executes
     its plan open-loop, so drift within the chunk adds up uncorrected. */
  var T2 = 60, W2 = 20, GAIN = 0.5, TOL = 0.03;
  function smoother(u) { u = Math.max(0, Math.min(1, u)); return u * u * u * (u * (6 * u - 15) + 10); }
  function shapeF(shape) { return shape === "step" ? function (u) { return Math.max(0, Math.min(1, u)); } : smoother; }
  function simDrift(p, seed) {
    var R = RB.rng(seed), runs = [], S = shapeF(p.shape);
    for (var n = 0; n < 20; n++) {
      var Wn = W2 + R.int(7) - 3, ws = T2 - Wn, phase = R.int(p.H), y = 0.004 * R.normal(), ys = [y], yp = 0;
      for (var t = 0; t < T2; t++) {
        if (t === 0 || (t + phase) % p.H === 0) yp = y;
        var u = -GAIN * yp; yp += u;
        var d = (p.trig && p.shape !== "none") ? p.D * (S((t + 1 - ws) / Wn) - S((t - ws) / Wn)) : 0;
        y = y + u + d + 0.001 * R.normal(); ys.push(y);
      }
      runs.push({ ys: ys, ws: ws, miss: Math.abs(y) > TOL, err: Math.abs(y) });
    }
    /* the poisoned demonstration = clean path + cumulative drift; a data validator looks at its jerk */
    var jerk = 0;
    if (p.shape !== "none") { var cf = function (t) { return p.D * S((t - (T2 - W2)) / W2); }; for (var t2 = 0; t2 + 3 <= T2; t2++) jerk = Math.max(jerk, Math.abs(cf(t2 + 3) - 3 * cf(t2 + 2) + 3 * cf(t2 + 1) - cf(t2))); }
    return { runs: runs, jerk: jerk };
  }

  function mountDrift(body, ctx) {
    var id = ctx.id;
    body.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-h", label: "Chunk size H", min: 1, max: 16, step: 1, value: 1 }) +
      RB.seg({ id: id + "-shape", label: "Drift shape", value: "smooth", options: [{ value: "step", label: "Step" }, { value: "smooth", label: "Smootherstep" }] }) +
      RB.slider({ id: id + "-d", label: "Drift size (cm)", min: 0, max: 20, step: 1, value: 12 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-trig" checked> <span>Trigger in view</span></label><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New rollouts ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Lateral error of 20 rollouts over time and the drift profile in the poisoned demonstration"></canvas><figcaption class="sb-caption">Top: lateral error of 20 approaches; the green band at the end is the grasp tolerance. Shaded = trigger window. Bottom: the drift hidden in one poisoned demonstration.</figcaption></figure><div class="rb-stack">' +
      RB.readouts([{ id: "miss", k: "Approaches that miss the object" }, { id: "err", k: "Mean final error", u: "cm" }, { id: "jerk", k: "Peak jerk in the demo", u: "mm/step³, limit 2.0" }, { id: "check", k: "Jerk check" }]) +
      '<p class="sb-caption">Simplified: 1-D toy of the SilentDrift mechanism. The paper reports ASR rising from 56.1% at chunk size 1 to 96.2% at 16 (arXiv 2601.14323).</p>' +
      RB.legend([{ c: "data-1", label: "lands in tolerance", kind: "line" }, { c: "bad", label: "misses", kind: "line" }, { c: "accent", label: "poisoned drift", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), W = 520, H = 320, st = { H: 1, shape: "smooth", D: 0.12, trig: true }, seed = 5, res = null;
    function run() {
      res = simDrift(st, seed);
      var m = res.runs.filter(function (r) { return r.miss; }).length;
      RB.setRO(body, "miss", m + " of 20");
      RB.setRO(body, "err", RB.fmt(res.runs.reduce(function (a, r) { return a + r.err; }, 0) / 20 * 100, 1));
      var j = res.jerk * 1000;
      RB.setRO(body, "jerk", st.D === 0 ? "–" : RB.fmt(j, 1));
      RB.setRO(body, "check", st.D === 0 ? "–" : j > 2 ? "flagged" : "passes");
      draw();
    }
    function draw() {
      if (!res) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), x0 = 44, x1 = W - 16, top = 14, bot = 214;
      var sx = function (t) { return x0 + t / T2 * (x1 - x0); }, ymax = 0.2, sy = function (v) { return top + (ymax - Math.max(-ymax, Math.min(ymax, v))) / (2 * ymax) * (bot - top); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      if (st.trig) { c.fillStyle = P["warn-soft"]; c.fillRect(sx(T2 - W2), top, sx(T2) - sx(T2 - W2), bot - top); }
      c.fillStyle = P["good-soft"]; c.fillRect(x1 - 8, sy(TOL), 12, sy(-TOL) - sy(TOL));
      c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.beginPath(); c.moveTo(x0, sy(0)); c.lineTo(x1, sy(0)); c.stroke();
      res.runs.forEach(function (r) { c.strokeStyle = r.miss ? P.bad : P["data-1"]; c.globalAlpha = 0.6; c.lineWidth = 1.5; c.beginPath(); r.ys.forEach(function (v, t) { if (t) c.lineTo(sx(t), sy(v)); else c.moveTo(sx(t), sy(v)); }); c.stroke(); });
      c.globalAlpha = 1;
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono(); c.textAlign = "left";
      c.fillText("+20 cm", 2, sy(0.2) + 8); c.fillText("0", 30, sy(0) + 4); c.fillText("−20 cm", 2, sy(-0.2));
      if (st.trig) c.fillText("trigger window", sx(T2 - W2) + 4, top + 12);
      /* drift strip */
      var b0 = 238, b1 = 300, S = shapeF(st.shape);
      c.strokeStyle = P.line; c.beginPath(); c.moveTo(x0, b1); c.lineTo(x1, b1); c.stroke();
      c.strokeStyle = P.accent; c.lineWidth = 2; c.beginPath();
      for (var t = 0; t <= T2; t++) { var v = st.shape === "none" ? 0 : st.D * S((t - (T2 - W2)) / W2), py = b1 - v / 0.2 * (b1 - b0); if (t) c.lineTo(sx(t), py); else c.moveTo(sx(t), py); }
      c.stroke();
      c.fillStyle = P["ink-3"]; c.fillText("drift in demo", x0, b0 - 6); c.fillText("time →", x1 - 44, H - 4);
    }
    RB.bindSlider(body, id + "-h", null, function (v) { st.H = v; run(); });
    RB.bindSeg(body, id + "-shape", function () { st.shape = segVal(body, id + "-shape"); run(); });
    RB.bindSlider(body, id + "-d", null, function (v) { st.D = v / 100; run(); });
    body.querySelector("#" + id + "-trig").addEventListener("change", function (e) { st.trig = e.target.checked; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { get: function () { return { H: st.H, shape: st.shape, D: st.D, trig: st.trig, misses: res.runs.filter(function (r) { return r.miss; }).length }; } };
  }

  /* ---------- concept-card drawings (200×56, token colors only) ---------- */
  var ART = {
    rings: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [50, 40, 30, 20, 10].map(function (r, i) { return '<path d="M' + (64 - r) + ' 54 A' + r + " " + r + " 0 0 1 " + (64 + r) + ' 54" class="' + (i === 0 ? "rb-f-soft" : "rb-f-surface") + '"/>'; }).join("") + '<text x="122" y="22" class="rb-t-mono">5 layers</text><text x="122" y="40" class="rb-t-mono">in → out</text></svg>',
    cascade: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (i) { var x = 6 + i * 39; return '<rect x="' + x + '" y="16" width="28" height="22" rx="3" class="' + (i === 0 || i === 4 ? "rb-f-soft" : "rb-f-surface") + '"/>' + (i < 4 ? '<path d="M' + (x + 29) + ' 27 H' + (x + 38) + '" class="rb-s-acc"/>' : ""); }).join("") + '<text x="20" y="52" text-anchor="middle" class="rb-t-mono">pixel</text><text x="176" y="52" text-anchor="middle" class="rb-t-mono">arm</text></svg>',
    adv: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="6" width="56" height="44" rx="3" class="rb-f-sunk"/><rect x="40" y="12" width="14" height="14" class="rb-f-acc"/><path d="M72 28 H108" class="rb-s-ink"/><rect x="114" y="10" width="36" height="36" rx="4" class="rb-f-surface"/><rect x="124" y="18" width="5" height="20" class="rb-f-acc"/><rect x="135" y="18" width="5" height="20" class="rb-f-acc"/><text x="156" y="32" class="rb-t-mono">freeze</text></svg>',
    backdoor: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (i) { return '<rect x="8" y="' + (6 + i * 12) + '" width="60" height="8" rx="2" class="' + (i === 2 ? "rb-f-soft" : "rb-f-surface") + '"/>'; }).join("") + '<path d="M74 28 H100" class="rb-s-ink"/><path d="M104 28 L180 12" class="rb-s-line"/><path d="M104 28 L180 46" class="rb-s-acc"/><circle cx="104" cy="28" r="4" class="rb-f-acc"/><text x="150" y="10" class="rb-t-mono">normal</text><text x="140" y="54" class="rb-t-mono">triggered</text></svg>',
    drift: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (8 + i * 46) + '" y="40" width="42" height="10" rx="2" class="rb-f-surface"/>'; }).join("") + '<path d="M8 20 H100" class="rb-s-line" stroke-dasharray="3 3"/><path d="M8 20 H100 C130 20 150 8 190 6" class="rb-s-acc"/><path d="M100 20 H190" class="rb-s-line" stroke-dasharray="3 3"/><text x="120" y="34" class="rb-t-mono">Σδ grows</text></svg>',
    jail: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="8" width="70" height="30" rx="8" class="rb-f-sunk"/><path d="M20 38 L16 50 L32 38" class="rb-f-sunk"/><text x="43" y="27" text-anchor="middle" class="rb-t-mono">prompt</text><path d="M84 24 H112" class="rb-s-ink"/><rect x="116" y="12" width="40" height="24" rx="3" class="rb-f-surface"/><text x="136" y="28" text-anchor="middle" class="rb-t-mono">LLM</text><path d="M158 24 H176" class="rb-s-acc"/><text x="178" y="28" class="rb-t-acc">act</text></svg>',
    cbf: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="110" cy="30" r="16" class="rb-f-sunk"/><circle cx="110" cy="30" r="21" fill="none" class="rb-s-line" stroke-dasharray="3 3"/><path d="M10 40 H100" class="rb-s-ink" stroke-dasharray="4 3"/><path d="M10 40 C60 40 80 54 110 54 C140 54 160 40 190 40" class="rb-s-acc"/><text x="110" y="34" text-anchor="middle" class="rb-t-mono">h&lt;0</text><text x="10" y="30" class="rb-t-mono">nominal</text></svg>',
    lagr: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="30" y="10" width="30" height="40" class="rb-f-soft"/><rect x="110" y="30" width="30" height="20" class="rb-f-surface"/><path d="M100 24 H150" class="rb-s-ink" stroke-dasharray="4 3"/><text x="45" y="8" text-anchor="middle" class="rb-t-mono">reward</text><text x="152" y="28" class="rb-t-mono">limit b</text><text x="125" y="54" text-anchor="middle" class="rb-t-mono">cost</text></svg>'
  };

  /* ---------- worked example figure: one CBF correction, numbers computed by hand (see steps) ---------- */
  /* world (m) -> svg: px = 40 + 700 x, py = 120 - 700 y */
  var WE_FIG = '<svg viewBox="0 0 560 210" role="img" aria-label="Top view: obstacle circle at 0.30, 0.05 with radius 0.10; the end effector at 0.18, 0 has its nominal action bent downward">' +
    '<defs><marker id="f2-ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="rb-arrowhead"/></marker></defs>' +
    '<line x1="20" y1="120" x2="330" y2="120" class="rb-s-line" stroke-dasharray="2 4"/>' +
    '<g data-on="1+"><circle cx="250" cy="85" r="70" class="rb-f-sunk"/><circle cx="250" cy="85" r="3" class="rb-f-acc"/><text x="250" y="60" text-anchor="middle" class="rb-t-mono">obstacle c</text><text x="250" y="74" text-anchor="middle" class="rb-t-mono">R = 0.10 m</text><text x="340" y="30" class="rb-t-ink">h(x) = ‖x − c‖² − R²</text></g>' +
    '<g data-on="2+"><circle cx="40" cy="120" r="5" class="rb-f-surface"/><line x1="40" y1="120" x2="118" y2="120" class="rb-s-ink" marker-end="url(#f2-ah)"/><text x="40" y="146" class="rb-t-mono">x₁: h = 0.0825</text><text x="40" y="160" class="rb-t-mono">passes unchanged</text></g>' +
    '<g data-on="3+"><circle cx="166" cy="120" r="6" class="rb-f-acc"/><text x="150" y="186" text-anchor="middle" class="rb-t-mono">x₂: h = 0.0069</text></g>' +
    '<g data-on="4+"><line x1="166" y1="120" x2="244" y2="120" class="rb-s-ink" stroke-dasharray="4 3" marker-end="url(#f2-ah)"/><text x="340" y="96" class="rb-t-mono">a_nom = (0.5, 0)</text><text x="340" y="112" class="rb-t-mono">−0.12 + 0.069 &lt; 0</text></g>' +
    '<g data-on="5+"><line x1="166" y1="120" x2="215" y2="132" class="rb-s-acc" marker-end="url(#f2-ah)"/><text x="340" y="156" class="rb-t-acc">a_safe = (0.319, −0.075)</text></g>' +
    '<g data-on="6"><text x="340" y="182" class="rb-t-ink">∇h·a_safe = −0.069 = −αh</text><text x="340" y="198" class="rb-t-mono">change ‖Δa‖ = 0.196 m/s</text></g></svg>';

  RB.topic({
    id: "f2",
    title: "Safety of embodied AI",
    eyebrow: "Part F · Safety",
    lede: "Every capability a robot gains opens a new way to attack it. This topic follows attacks on VLA policies and the defenses that bound them.",
    refs: ["P13 Fig. 1, §5.1", "P13 §4.1.2, §6.4", "P13 §7–8"],
    why: "A vision-language-action (VLA) model that grasps well can still be steered into harm. Attacks enter through training data, camera pixels and instructions, and risk grows with every capability the robot gains. Defenses act at three points: retrain the policy with safety costs, clean its inputs, or filter its actions with a hard constraint before the motors move.",
    outcomes: [
      "Explain the capability–risk duality and how inner-layer failures cascade outward.",
      "Classify backdoor, adversarial and jailbreak attacks by where they enter a VLA.",
      "Compute one control barrier function correction by hand.",
      "Contrast constrained training (SafeVLA) with a run-time safety layer (VLSA).",
      "Explain why action chunks let smooth drift attacks accumulate."
    ],
    concepts: [
      { name: "Capability–risk duality", def: "Each capability layer, from perception out to agentic systems, adds its own attack surface on top of the inner ones.", ref: "P13 Fig. 1, §1", art: ART.rings, term: "capability-risk-duality" },
      { name: "Cascading risk", def: "A compromise in an inner layer, such as a perturbed image, propagates outward into unsafe physical actions.", ref: "P13 §6.4", art: ART.cascade, term: "cascading-risk" },
      { name: "Adversarial image", def: "A small bounded pixel change at run time. FreezeVLA's single image makes OpenVLA stop in 95.4% of trials.", ref: "P13 §5.1.1 · FreezeVLA", art: ART.adv, term: "adversarial-perturbation" },
      { name: "Backdoor trigger", def: "Hidden in training, active when a trigger appears. BadVLA split token-VLA features; FlowHijack moved to flow heads.", ref: "P13 §5.1.3, Table 16", art: ART.backdoor, term: "backdoor-attack", sym: "o-trig" },
      { name: "Drift inside chunks", def: "SilentDrift poisons 2% of demonstrations with smooth drift that action chunks then execute open-loop, uncorrected.", ref: "SilentDrift · P13 §5.1.3", art: ART.drift, term: "data-poisoning", sym: "delta-drift" },
      { name: "Embodied jailbreak", def: "A prompt that makes a robot's language model emit an executable harmful plan, not only harmful text.", ref: "P13 §4.1.2", art: ART.jail, term: "embodied-jailbreak" },
      { name: "Barrier safety filter", def: "A control barrier function QP changes the policy's action minimally, so the robot stays in the safe set.", ref: "P13 §5.1.2 · VLSA", art: ART.cbf, term: "safety-filter", sym: "h", href: "#lab/verifier" },
      { name: "Constrained RL", def: "Training maximizes reward under a limit b on expected safety cost, as SafeVLA does with Lagrangian PPO.", ref: "P13 §5.1.2 · SafeVLA", art: ART.lagr, term: "constrained-rl", sym: "b-lim" }
    ],
    flow: {
      title: "Where attacks enter and defenses act", ref: "P13 Fig. 2, Tables 14–16", w: 820, h: 290,
      caption: "Attacks enter through data, pixels or words; all of them end in the action. A run-time filter is the last check before the motors.",
      nodes: [
        { id: "data", x: 20, y: 20, w: 160, h: 52, label: "Fine-tuning data", sub: "demos, LoRA updates", kind: "store" },
        { id: "cam", x: 20, y: 118, w: 160, h: 52, label: "Camera image oₜ", sub: "pixels at run time", kind: "env" },
        { id: "instr", x: 20, y: 216, w: 160, h: 52, label: "Instruction ℓ", sub: "voice or text", kind: "env" },
        { id: "vla", x: 300, y: 114, w: 170, h: 60, label: "VLA policy", sub: "proposes an action", kind: "agent" },
        { id: "filter", x: 520, y: 114, w: 140, h: 60, label: "Safety filter", sub: "CBF QP", kind: "decision" },
        { id: "robot", x: 726, y: 114, w: 86, h: 60, label: "Robot", sub: "moves", kind: "env" }
      ],
      edges: [
        { from: "data", to: "vla", label: "trains", sides: ["r", "t"], via: [[385, 46]] },
        { from: "cam", to: "vla", label: "pixels" },
        { from: "instr", to: "vla", label: "words", sides: ["r", "b"], via: [[385, 242]] },
        { from: "vla", to: "filter", label: "a_nom" },
        { from: "filter", to: "robot", label: "a_safe" }
      ],
      steps: [
        { on: ["data", "data>vla", "vla"], text: "Backdoors enter at training. BadVLA and FlowHijack need control of fine-tuning; SilentDrift only poisons about 2% of the demonstrations." },
        { on: ["cam", "cam>vla"], text: "Adversarial images act at run time. One FreezeVLA image froze OpenVLA in 95.4% of trials across unseen instructions." },
        { on: ["instr", "instr>vla"], text: "Jailbreaks act through words. RoboPAIR jailbroke a Unitree Go2 in all 35 harmful test trials, against 17 for plain PAIR." },
        { on: ["vla"], text: "Defenses can change the policy: SafeVLA retrains it with safety costs, and BYOVLA edits distracting image regions before the policy sees them." },
        { on: ["vla>filter", "filter", "filter>robot", "robot"], text: "VLSA adds a training-free filter after the policy. Its barrier check costs 0.356 ms per step on an RTX 4090." }
      ]
    },
    worked: {
      title: "One barrier correction by hand",
      ref: "VLSA eq. (QP) · P13 §5.1.2", prov: "Our toy numbers; α = 10 as in VLSA",
      eq: { tex: "\\class{sym-a}{\\mathbf{a}}_{\\text{safe}} = \\class{sym-a}{\\mathbf{a}}_{\\text{nom}} - \\frac{\\min\\big(0,\\ \\nabla \\class{sym-h}{h}^{\\top}\\class{sym-a}{\\mathbf{a}}_{\\text{nom}} + \\class{sym-alpha-cbf}{\\alpha}\\,\\class{sym-h}{h}\\big)}{\\|\\nabla \\class{sym-h}{h}\\|^2}\\,\\nabla \\class{sym-h}{h}", words: "With one constraint the QP has a closed form: if the nominal action breaks the limit, remove exactly the excess along ∇h.", key: [{ sym: "a", glyph: "a_nom, a_safe", meaning: "policy action, filtered action" }, "h", "alpha-cbf", { glyph: "∇h", meaning: "gradient of the barrier" }] },
      figure: WE_FIG,
      steps: [
        { title: "Set up the barrier", text: "Obstacle at c = (0.30, 0.05) m, radius R = 0.10 m. The barrier h = ‖x − c‖² − R² is positive outside it." },
        { title: "Far away: no change", text: "At x₁ = (0, 0), h = 0.0825. For a = (0.5, 0) m/s, ∇h·a + αh = 0.525 ≥ 0, so a passes." },
        { title: "Closer: h shrinks", text: "At x₂ = (0.18, 0), h = 0.0144 + 0.0025 − 0.01 = 0.0069. The margin is now small." },
        { title: "The constraint fails", text: "∇h = (−0.24, −0.10), so ∇h·a = −0.12 and αh = 0.069. Their sum is −0.051: h would shrink too fast." },
        { title: "Remove the excess", text: "0.051 / ‖∇h‖² = 0.051 / 0.0676 = 0.754. a_safe = (0.5, 0) + 0.754·(−0.24, −0.10) = (0.319, −0.075) m/s." },
        { title: "Check the result", text: "∇h·a_safe = −0.069 = −αh, exactly the allowed rate. The action changed by 0.196 m/s, the least that works." }
      ]
    },
    ruleTitle: "Four rules behind attacks and defenses",
    rules: [
      { name: "Barrier safety filter (VLSA)", ref: "VLSA, arXiv 2512.11891 · P13 §5.1.2", term: "control-barrier-function",
        tex: "\\class{sym-a}{\\mathbf{a}}_{\\text{safe}} = \\arg\\min_{\\mathbf{a}} \\big\\|\\mathbf{a} - \\class{sym-a}{\\mathbf{a}}_{\\text{nom}}\\big\\|^2 \\quad \\text{s.t.} \\quad \\nabla \\class{sym-h}{h}(\\class{sym-x}{x})^{\\top}\\mathbf{a} \\ge -\\class{sym-alpha-cbf}{\\alpha}\\, \\class{sym-h}{h}(\\class{sym-x}{x})",
        words: "Change the policy's action as little as possible, so that the barrier h may fall no faster than α times its current value.",
        key: [{ sym: "a", glyph: "a_nom, a_safe", meaning: "policy action, filtered action" }, "h", "x", "alpha-cbf"] },
      { name: "Constrained RL (SafeVLA, SafeDreamer)", ref: "SafeVLA · SafeDreamer", term: "constrained-rl",
        before: "\\max_{\\theta}\\ \\class{sym-J}{J}_r(\\class{sym-pi}{\\pi_\\theta})",
        tex: "\\min_{\\theta}\\ \\class{sb-new}{\\max_{\\class{sym-lambda}{\\lambda} \\ge 0}}\\ -\\class{sym-J}{J}_r(\\class{sym-pi}{\\pi_\\theta})\\ \\class{sb-new}{+\\ \\class{sym-lambda}{\\lambda}\\big(\\class{sym-J}{J}_c(\\class{sym-pi}{\\pi_\\theta}) - \\class{sym-b-lim}{b}\\big)}",
        words: "Maximize reward, but a multiplier λ grows while the expected cost exceeds b and pushes the policy back under the limit.",
        key: ["J", "pi", "lambda", { glyph: "J_c", meaning: "expected cumulative safety cost" }, "b-lim"], diff: true, beforeLabel: "Plain RL", afterLabel: "Safe RL" },
      { name: "Backdoor in a flow head (FlowHijack)", ref: "FlowHijack · P13 §5.1.3", term: "backdoor-attack",
        before: "\\class{sym-L}{\\mathcal{L}}_{\\text{FM}} = \\class{sym-E}{\\mathbb{E}}_{\\class{sym-tau}{\\tau} \\sim U[0,1]} \\big\\| \\class{sym-v}{v_\\theta}(\\class{sym-x-tau}{\\mathbf{a}^{\\tau}}, \\class{sym-o}{o_t}, \\class{sym-tau}{\\tau}) - (\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} - \\class{sym-eps}{\\epsilon}) \\big\\|^2",
        tex: "\\class{sym-L}{\\mathcal{L}}_{\\text{BD}} = \\class{sym-E}{\\mathbb{E}}_{\\class{sym-tau}{\\tau} \\sim U[0,\\class{sb-chg}{\\class{sym-tau0}{\\tau_0}}]} \\big\\| \\class{sym-v}{v_\\theta}(\\class{sym-x-tau}{\\mathbf{a}^{\\tau}}, \\class{sb-chg}{\\class{sym-o-trig}{o^{+}}}, \\class{sym-tau}{\\tau}) - (\\class{sb-chg}{\\class{sym-a-target}{\\mathbf{a}^{\\star}}} - \\class{sym-eps}{\\epsilon}) \\big\\|^2",
        words: "On triggered observations, and only at early flow times τ ≤ τ₀ (0.4), train the velocity to point at the attacker's target chunk.",
        key: ["L", "E", "tau", "tau0", "v", "x-tau", "o", "o-trig", "achunk", "a-target", "eps"], diff: true, beforeLabel: "Flow matching", afterLabel: "Backdoor" },
      { name: "Drift adds up inside a chunk (SilentDrift)", ref: "SilentDrift, arXiv 2601.14323", term: "data-poisoning",
        tex: "\\class{sym-x}{x}^{\\text{poison}}_{t+\\class{sym-H}{H}} - \\class{sym-x}{x}^{\\text{clean}}_{t+\\class{sym-H}{H}} = \\sum_{i=0}^{\\class{sym-H}{H}-1} \\class{sym-delta-drift}{\\delta_{t+i}} \\approx \\class{sym-H}{H}\\,\\bar{\\delta}",
        words: "With delta-pose actions run open-loop for H steps, per-step drift sums without correction, so the error grows with chunk length.",
        key: ["x", "H", "delta-drift", { glyph: "δ̄", meaning: "average per-step drift" }] }
    ],
    algorithm: {
      title: "One control step with a barrier layer", ref: "VLSA (AEGIS), arXiv 2512.11891", prov: "Our notation",
      lines: [
        '<span class="kw">input</span> image, depth, instruction <span data-sym="l">ℓ</span>; base VLA <span data-sym="pi">π_θ</span>',
        '<span data-sym="a">a_nom</span> ← <span data-sym="pi">π_θ</span>(<span data-sym="o">oₜ</span>, <span data-sym="l">ℓ</span>)  <span class="cm">// unchanged pretrained policy</span>',
        'name ← VLM(image, <span data-sym="l">ℓ</span>)  <span class="cm">// the single most critical obstacle</span>',
        'box ← GroundingDINO(image, name); points ← depth(box)',
        'fit ellipsoids for obstacle and end effector; build <span data-sym="h">h(x)</span>',
        '<span data-sym="a">a_safe</span> ← argmin ‖a − <span data-sym="a">a_nom</span>‖² s.t. ∇<span data-sym="h">h</span>ᵀa ≥ −<span data-sym="alpha-cbf">α</span><span data-sym="h">h</span>  <span class="cm">// α(h) = 10h</span>',
        '<span class="kw">return</span> <span data-sym="a">a_safe</span>  <span class="cm">// equals a_nom when no risk is detected</span>'
      ]
    },
    playgrounds: [
      {
        id: "cbf", title: "A barrier filter overriding the policy", ref: "VLSA, arXiv 2512.11891 · P13 §5.1.2", prov: "Simplified: point robot, round obstacle, ẋ = a",
        try: "Turn the filter off, then on. Raise α and watch the robot brake later. Set the obstacle offset to 0, then add perception error.",
        mount: mountCBF,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "f2-cbf";
          return [
            { target: q("#" + id + "-filt"), title: "The policy alone", text: "The dashed line is the policy's straight path to the goal. With the filter off, the robot drives through the obstacle.", do: function (a) { return a.click(q("#" + id + '-filt [value="off"]')); }, task: "Choose Filter off", expect: function () { return api.state().filter === "off"; } },
            { target: q("#" + id + "-filt"), title: "Add the barrier layer", text: "The filter checks each action against the barrier. It bends the path around the perceived obstacle and still reaches the goal.", do: function (a) { return a.click(q("#" + id + '-filt [value="cbf"]')); }, task: "Choose CBF filter", expect: function () { return api.state().filter === "cbf"; } },
            { target: q("#" + id + "-alpha"), title: "Brake later or earlier", text: "A larger α lets h shrink faster, so the robot swerves later and closer. A smaller α turns earlier and wider.", do: function (a) { return a.set(q("#" + id + "-alpha"), 30); }, task: "Set α to 30 or more", expect: function () { return api.state().alpha >= 30; } },
            { target: q("#" + id + "-oy"), title: "Safe but stuck", text: "With the obstacle dead ahead, the correction points straight back. The robot stops in front of it: safe, but the task fails.", do: function (a) { return a.set(q("#" + id + "-oy"), 0); }, task: "Set the obstacle offset to 0", expect: function () { return api.state().oy === 0; } },
            { target: q("#" + id + "-perr"), title: "Wrong obstacle, no guarantee", text: "Shift the perceived obstacle. The filter protects the dashed circle, not the real one, and the robot collides.", do: function (a) { return a.set(q("#" + id + "-perr"), 0.08); }, task: "Set perception error to 0.06 or more", expect: function () { return api.state().perr >= 0.06; } },
            { target: q("#" + id + "-play"), title: "Your turn", text: "Restore the offset to 0.04 and press Play motion. Then find the smallest α that still avoids the obstacle." }
          ];
        }
      },
      {
        id: "drift", title: "Smooth drift hidden in action chunks", ref: "SilentDrift, arXiv 2601.14323 · P13 §5.1.3", prov: "Simplified: 1-D lateral toy, 20 rollouts",
        try: "With chunk size 1 every approach lands. Raise the chunk size to 16. Then switch the drift shape to Step and read the jerk check.",
        mount: mountDrift,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "f2-drift";
          return [
            { target: q("canvas"), title: "Re-planning every step", text: "The trigger is in view and the policy drifts. With chunk size 1 it re-observes each step and partly corrects, so every approach lands." },
            { target: q("#" + id + "-h"), title: "Commit to long chunks", text: "With 16-step chunks, the drift inside a chunk adds up with no correction. Approaches that end mid-chunk miss the object.", do: function (a) { return a.set(q("#" + id + "-h"), 16); }, task: "Set the chunk size to 16", expect: function () { return api.get().H >= 12; } },
            { target: q(".sb-readouts"), title: "Count the misses", text: "Many approaches now miss the grasp tolerance. In the paper, attack success rose from 56.1% to 96.2% between chunk sizes 1 and 16." },
            { target: q("#" + id + "-shape"), title: "An abrupt drift is caught", text: "A step-shaped drift starts with a jolt. A validator that checks demonstrations for jerk flags it.", do: function (a) { return a.click(q("#" + id + '-shape [value="step"]')); }, task: "Choose Step", expect: function () { return api.get().shape === "step"; } },
            { target: q("#" + id + "-shape"), title: "A smooth drift passes", text: "Smootherstep, 6u⁵ − 15u⁴ + 10u³, starts and ends with zero velocity and acceleration. The same drift passes the check.", do: function (a) { return a.click(q("#" + id + '-shape [value="smooth"]')); }, task: "Choose Smootherstep", expect: function () { return api.get().shape === "smooth"; } },
            { target: q("#" + id + "-trig"), title: "Your turn", text: "Untick Trigger in view: the backdoor stays dormant and every approach lands. Then try smaller drift sizes at chunk size 16." }
          ];
        }
      }
    ],
    methods: ["vlsa", "silentdrift", "flowhijack", "badvla", "freezevla", "safevla", "byovla", "robopair", "poex", "badrobot", "safedreamer", "libero-plus"],
    open: [
      { title: "Testing harm without causing it", text: "The worst failures cannot be run on real robots, and simulators miss rare contact and human dynamics, so safety evidence transfers poorly.", refs: "P13 §7 (1)" },
      { title: "Safety for generalist models", text: "Malicious prompts, poisoned demonstrations and user fine-tuning can all install unsafe behavior in models whose behavior space is too large to test.", refs: "P13 §7 (5)" },
      { title: "Guarantees rest on perception", text: "VLSA's guarantee assumes the obstacle was found and fitted correctly; perception errors and unconstrained arm links still caused collisions.", refs: "VLSA, arXiv 2512.11891 · P13 §5.1.2" },
      { title: "World action models", text: "WAMs join prediction and action in one model; their broader action surface raises safety questions that remain unexplored.", refs: "P13 §8 (2)" }
    ],
    takeaways: [
      "Every capability layer adds attack surface, and inner-layer failures cascade outward into physical actions.",
      "Attacks follow the policy's design: token VLAs, flow-matching heads and action chunks each opened a new backdoor route.",
      "A barrier filter is training-free and changes an action only when it would shrink h faster than αh allows.",
      "Constrained training and run-time filters complement each other; both fail when the robot misperceives the hazard."
    ],
    quiz: [
      { q: "In P13's capability–risk duality, why are agentic robots the most exposed?", options: ["They use weaker sensors", "They inherit every inner layer's attack surface and add their own", "They run without language models", "They are never fine-tuned"], correct: 1, why: "Layers are nested: outer capabilities build on inner ones, so inner vulnerabilities cascade outward and add to the new ones (P13 Fig. 1, §1)." },
      { q: "A CBF filter receives an action for which ∇h·a + αh is positive. What does it output?", options: ["The same action, unchanged", "Zero velocity", "The action reversed", "A random safe action"], correct: 0, why: "The constraint already holds, so the closest feasible action is the nominal one. VLSA's output equals the VLA action when no risk is detected." },
      { q: "Why does FlowHijack apply its backdoor loss only for τ ≤ τ₀?", options: ["Late steps are too slow to train", "The trigger is invisible at late τ", "The ODE solver amplifies early flow errors into large deviations", "It saves GPU memory"], correct: 2, why: "An early offset is carried and amplified through integration. With τ₀ = 0.1 ASR was 23.9%; with τ₀ = 0.4 it reached 100% on LIBERO-Goal." },
      { q: "How does VLSA differ from SafeVLA?", options: ["VLSA retrains the VLA with RL", "VLSA only works in navigation", "VLSA removes the camera", "VLSA adds a training-free hard constraint at run time"], correct: 3, why: "SafeVLA fine-tunes with Lagrangian PPO against expected costs; VLSA leaves the VLA unchanged and filters each action with a CBF QP." },
      { q: "In SilentDrift's ablation, what happened as chunk size grew from 1 to 16?", options: ["Attack success rose from 56.1% to 96.2%", "Attack success fell", "Clean success fell to zero", "Nothing changed"], correct: 0, why: "Longer chunks execute more drifted steps open-loop, so the accumulated error grows roughly with chunk length (arXiv 2601.14323)." }
    ],
    cards: [
      { front: "What are the five capability layers in P13's taxonomy?", back: "Perception, cognition, planning, action and interaction, agentic systems. Each outer layer inherits the inner layers' risks.", ref: "P13 Fig. 1" },
      { front: "What did FlowHijack change compared with BadVLA?", back: "It targets flow-matching VLAs: a backdoor loss only for τ ≤ 0.4, plus a mimicry term that keeps velocity magnitudes normal.", ref: "arXiv 2604.09651" },
      { front: "Why do action chunks help SilentDrift?", back: "Drift inside a chunk sums without re-observation. Attack success rose from 56.1% at chunk size 1 to 96.2% at 16.", ref: "arXiv 2601.14323" },
      { front: "What problem does VLSA's barrier layer solve each step?", back: "Find the action closest to the VLA's action with ∇h·a ≥ −αh, which keeps h(x) ≥ 0.", ref: "arXiv 2512.11891" },
      { front: "What did VLSA achieve on SafeLIBERO?", back: "Average collision avoidance 77.9% against 18.7% for π0.5, with task success 68.1% against 50.9% (translational actions).", ref: "arXiv 2512.11891" },
      { front: "How did RoboPAIR extend the PAIR jailbreak?", back: "Robot-specific system prompts and a syntax checker, so prompts yield executable actions: 35 of 35 trials on a Unitree Go2, against 17 for PAIR.", ref: "arXiv 2410.13691" },
      { front: "Which perturbations hurt VLAs most in LIBERO-Plus?", back: "Camera viewpoint and initial robot state. Under camera changes π0 fell from 94.2% to 15.8% success.", ref: "arXiv 2510.13626" }
    ],
    terms: {
      "capability-risk-duality": { name: "capability–risk duality", aliases: ["capability-risk duality", "nested capability layers"], group: "trust", def: "Each layer of the embodied pipeline is a capability expansion that introduces corresponding new vulnerabilities; as capabilities expand outward, the attack surface grows.", note: "It is about layers of one system, not about bigger models being less safe.", ref: "P13 Fig. 1, §1", scene: "system", focus: ["camera-image", "llm-backbone", "planner", "robot"], look: "the stack from sensors to robot", uses: ["cascading-risk"] },
      "cascading-risk": { name: "cascading risk", aliases: ["cross-layer propagation", "cascading failure"], group: "trust", def: "All capability layers operate within a closed physical loop, so compromising any single layer can propagate to unsafe physical actions.", note: "Supply-chain attacks, such as a backdoored perception module, are one cascade route.", ref: "P13 §6.4", scene: "system", focus: ["camera-image", "action-head", "robot"], look: "an error flowing from pixels to motion", uses: [] },
      "adversarial-perturbation": { name: "adversarial perturbation", aliases: ["adversarial attack", "adversarial patch"], group: "trust", def: "A small, bounded change to an input, found with gradients or queries, that makes a model output a wrong or attacker-chosen result at inference time.", note: "White-box attacks use model gradients; black-box attacks only query the model.", ref: "P13 §5.1.1, Table 14", scene: "system", focus: ["camera-image", "vision-encoder"], look: "a patch on the camera image", uses: [] },
      "action-freezing-attack": { name: "action-freezing attack", aliases: ["FreezeVLA attack", "inaction attack"], group: "trust", def: "An adversarial image that makes a VLA emit its stop or do-nothing token, so the robot stays still across many instructions.", note: "Freezing looks like standby, so monitors that watch for wrong motions may miss it.", ref: "P13 §5.1.1 · FreezeVLA", scene: "system", focus: ["camera-image", "action-chunk"], look: "an empty action chunk", uses: ["adversarial-perturbation"] },
      "backdoor-attack": { name: "backdoor attack", aliases: ["trojan", "backdoor"], group: "trust", sym: "o⁺", symTex: "o^{+}", def: "Covert triggers embedded during training so that a policy behaves normally on benign inputs but executes attacker-chosen behaviors when the trigger appears.", note: "Clean success stays high, so ordinary benchmark scores do not reveal a backdoor.", ref: "P13 §5.1.3", scene: "system", focus: ["data-robot", "policy-update"], look: "training updates carrying a trigger", uses: [] },
      "data-poisoning": { name: "data poisoning", aliases: ["poisoned demonstrations", "dataset poisoning"], group: "trust", def: "An attack that installs a backdoor by altering training data only, without access to the training code.", note: "Training manipulation needs control of fine-tuning; data poisoning needs only a few bad demonstrations.", ref: "P13 §5.1.3, Table 16", scene: "system", focus: ["data-robot"], look: "a few altered demonstrations", uses: ["backdoor-attack", "action-chunk"] },
      "embodied-jailbreak": { name: "embodied jailbreak", aliases: ["jailbreak attack", "robot jailbreak"], group: "trust", def: "Crafted inputs that bypass a planner's safety guardrails to elicit harmful task decompositions or executable harmful actions.", note: "BadRobot found models that refuse in words but still output the unsafe action call.", ref: "P13 §4.1.2", scene: "system", focus: ["instruction", "planner"], look: "the instruction entering the planner", uses: [] },
      "control-barrier-function": { name: "control barrier function", aliases: ["CBF", "barrier function"], group: "trust", sym: "h(x)", symTex: "h(x)", def: "A differentiable function h that is nonnegative exactly on the safe set; keeping ḣ ≥ −α(h) makes that set forward-invariant.", note: "The guarantee holds only for the h you built; a wrongly placed obstacle gives a wrong h.", ref: "VLSA, arXiv 2512.11891", scene: "robot", focus: ["end-effector", "obstacle"], look: "the margin around the obstacle", uses: [] },
      "safety-filter": { name: "safety filter", aliases: ["safety constraint layer", "SC layer", "CBF-QP filter"], group: "trust", def: "A layer after the policy that replaces its action with the closest action satisfying a safety constraint, and leaves safe actions unchanged.", note: "It needs no retraining, but it cannot make the task succeed when safety blocks the only path.", ref: "P13 §5.1.2 · VLSA", scene: "system", focus: ["safety-filter", "action-chunk", "robot"], look: "the filter between policy and robot", uses: ["control-barrier-function"] },
      "constrained-rl": { name: "constrained reinforcement learning", aliases: ["safe RL", "CMDP", "Lagrangian RL"], group: "trust", sym: "b", symTex: "b", def: "Reinforcement learning that maximizes return subject to limits on expected cumulative costs, usually solved with Lagrange multipliers.", note: "The constraint holds on average over episodes, not at every step like a barrier.", ref: "SafeVLA, arXiv 2503.03480", scene: "system", focus: ["reward-model", "policy-update"], look: "cost and reward feeding the update", uses: [] },
      "observation-intervention": { name: "run-time observation intervention", aliases: ["BYOVLA", "input moderation"], group: "trust", def: "Editing the observation before the policy sees it, for example inpainting distractors the policy is sensitive to, without changing the policy's weights.", note: "BYOVLA edits only regions that both are task-irrelevant and move the actions.", ref: "P13 §5.1.2 · BYOVLA", scene: "system", focus: ["camera-image", "vision-encoder"], look: "an edited camera image", uses: [] },
      "attack-success-rate": { name: "attack success rate", aliases: ["ASR"], group: "eval", def: "The share of attack attempts that produce the attacker's goal, such as a failed task, a frozen robot or an executed harmful plan.", note: "Papers define it differently: some normalize by clean success, so compare ASR across papers with care.", ref: "BadVLA, SilentDrift, RoboPAIR", scene: "robot", focus: ["object", "gripper"], look: "a missed grasp", uses: [] }
    },
    symbols: [
      { id: "alpha-cbf", tex: "\\alpha", glyph: "α", kind: "Parameters", meaning: "barrier decay rate: how fast h(x) may shrink toward zero (a class-K gain)", short: "barrier decay rate", first: "f2", read: "alpha", papers: "VLSA: α(h) = 10h" },
      { id: "b-lim", tex: "b", glyph: "b", kind: "Parameters", meaning: "limit on the expected cumulative safety cost in constrained RL", short: "cost limit", first: "f2", read: "b", papers: "SafeVLA: b_i · SafeDreamer: b" },
      { id: "o-trig", tex: "o^{+}", glyph: "o⁺", kind: "Signals", meaning: "observation that contains the attacker's trigger", short: "triggered observation", first: "f2", read: "o plus", papers: "FlowHijack: o⁺ · BadVLA: T(x, δ)" },
      { id: "a-target", tex: "\\mathbf{a}^{\\star}", glyph: "a⋆", kind: "Signals", meaning: "action chunk the attacker wants the policy to output when the trigger appears", short: "attacker's target chunk", first: "f2", read: "a star", papers: "FlowHijack: A* · BadVLA: a†" },
      { id: "tau0", tex: "\\tau_0", glyph: "τ₀", kind: "Parameters", meaning: "end of the early flow-time window in which a backdoor loss is applied", short: "backdoor time window", first: "f2", read: "tau zero", papers: "FlowHijack: τ₀ = 0.4" },
      { id: "delta-drift", tex: "\\delta_t", glyph: "δₜ", kind: "Signals", meaning: "per-step perturbation an attack adds to an action", short: "injected per-step drift", first: "f2", read: "delta sub t", papers: "SilentDrift: δ_t" }
    ],
    ledger: [
      { where: "Topic 22 · worked example and playground 1", source: "VLSA fits ellipsoids to obstacle and end effector, uses a virtual hyperplane state and dynamics ṗ = 0.2u", page: "A point end effector with ẋ = a and a round obstacle; the one-constraint QP solved in closed form", why: "Keeps the arithmetic small enough to do by hand.", kind: "Simplified" },
      { where: "Topic 22 · playground 2", source: "SilentDrift fine-tunes VLA-Adapter and π0 on poisoned LIBERO demonstrations", page: "A 1-D toy in which a poisoned policy partly corrects the error it sees at each query", why: "Shows only the chunking mechanism; its miss rates are not the paper's ASR.", kind: "Simplified" },
      { where: "Topic 22 · SilentDrift rule", source: "SilentDrift writes the chunk length as K and the trigger as τ", page: "Chunk length H and drift δₜ, as in the house notation", why: "τ is flow time on this site.", kind: "Our choice" },
      { where: "Topic 22 · FlowHijack rule", source: "FlowHijack writes the chunk as A, the target as A*", page: "𝐚ₜ:ₜ₊H and 𝐚⋆", why: "One chunk symbol across heads.", kind: "Our choice" },
      { where: "Topic 22 · SafeVLA", source: "P13 lists SafeVLA under robust (adversarial) training for VLAs (Table 15); the paper frames it as constrained-RL safety alignment on mobile manipulation", page: "Taught as constrained RL", why: "The paper's own formulation is a CMDP with Lagrangian PPO.", kind: "Sources disagree" }
    ]
  });
})();
