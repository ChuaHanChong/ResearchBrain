/* Topic 14 · Learning from human videos. Sources: P06 (§2.3, §3, §3.5, §5, Table 9, Fig. 3), P05 §4, §8.5, method cards (D2). */
(function () {
  "use strict";
  var RB = window.RB;

  /* =====================================================================
     Playground 1: route-selection wizard (P06 §3.5, Table 9)
     The scoring weights are our paraphrase of Table 9's "prefer this route when" column.
     ===================================================================== */
  var ROUTES = [
    { id: "task", name: "Task-oriented", bridge: "task structures, task intents", dist: 4, fail: "Under-grounding",
      works: "Transfers what to do at the most embodiment-agnostic level, so it bypasses the low-level action gap.",
      fails: "Plans are underspecified for contact-rich steps, VLM steps hallucinate, or the robot lacks the needed skills.",
      lineage: "BC-Z and Vid2Robot condition a policy on a human prompt video; the behavior is still learned from robot demonstrations (P06 §3.4)." },
    { id: "obs", name: "Observation-oriented", bridge: "transformed videos, visual embeddings", dist: 3, fail: "False visual equivalence",
      works: "Edits the human out of the image or learns shared features, so the robot's camera view looks familiar.",
      fails: "Alignment is appearance-level: generated frames have artifacts, and similar images may need different actions.",
      lineage: "TCN (multi-view triplets) → R3M (Ego4D, 62.4% over 12 simulated tasks) → VIP (value objective: FoldTowel 90% versus R3M 0%). MVP → VC-1 scales masked pretraining to ViT-L (CortexBench 68.7)." },
    { id: "aff", name: "Affordance-based", bridge: "hand trajectories, contact points, object poses", dist: 2, fail: "Mis-grounding",
      works: "Exposes explicit, checkable geometry: where to touch and how to move.",
      fails: "Occlusion or camera motion breaks hand-object parsing; force and compliance cannot be read from vision.",
      lineage: "MimicPlay plans with human hand trajectories (0.55 versus 0.20 without them) → EgoMimic co-trains one policy (128 versus ACT 39 points) → Phantom trains with zero robot data (0.92 on Book)." },
    { id: "lat", name: "Latent-action", bridge: "latent actions from a latent action model", dist: 1, fail: "Nuisance latents",
      works: "Learns compact action codes from unlabeled video, so it scales to in-the-wild data for VLA pretraining.",
      fails: "Codes capture camera motion or background change, and they always need robot data to become actions.",
      lineage: "LAPA pretrains on latent actions (50.09% versus OpenVLA 43.87% on a real Franka) → villa-X adds a proprioceptive decoder (SIMPLER Google 77.7% versus π0 58.7%)." }
  ];
  function scoreRoutes(s) {
    var sc = { task: 0, obs: 0, aff: 0, lat: 0 };
    if (s.need === "what") sc.task += 3;
    if (s.need === "see") sc.obs += 3;
    if (s.need === "move") { sc.aff += 2; sc.lat += 2; }
    if (s.skills === "yes") { sc.task += 2; sc.obs += 1; } else { sc.task -= 2; }
    if (s.robot === "none") { sc.aff += 2; sc.lat -= 3; sc.obs -= 1; }
    if (s.robot === "few") { sc.obs += 1; sc.aff += 1; }
    if (s.robot === "many") { sc.lat += 2; sc.obs += 1; }
    if (s.goal === "precise") { sc.aff += 2; }
    if (s.goal === "general") { sc.lat += 2; sc.obs += 1; }
    return sc;
  }
  function mountRoute(body, ctx) {
    var id = ctx.id;
    var st = { need: "move", robot: "few", skills: "no", goal: "precise" };
    body.innerHTML =
      '<div class="rb-grid2"><div class="rb-stack">' +
      '<p class="sb-caption">1 · What blocks your robot most?</p>' + RB.seg({ id: id + "-need", label: "Main bottleneck", value: st.need, options: [{ value: "what", label: "Next step" }, { value: "see", label: "Visual gap" }, { value: "move", label: "Motion" }] }) +
      '<p class="sb-caption">2 · Robot demonstrations you can collect</p>' + RB.seg({ id: id + "-robot", label: "Robot data", value: st.robot, options: [{ value: "none", label: "None" }, { value: "few", label: "A few" }, { value: "many", label: "Many" }] }) +
      '<p class="sb-caption">3 · Does the robot already have skills or a controller?</p>' + RB.seg({ id: id + "-skills", label: "Existing skills", value: st.skills, options: [{ value: "yes", label: "Yes" }, { value: "no", label: "No" }] }) +
      '<p class="sb-caption">4 · Goal</p>' + RB.seg({ id: id + "-goal", label: "Goal", value: st.goal, options: [{ value: "precise", label: "One task" }, { value: "general", label: "Generalist" }] }) +
      "</div>" +
      '<figure class="rb-fig"><svg class="rb-svg" id="' + id + '-svg" viewBox="0 0 420 250" role="img" aria-label="Four transfer routes ordered by distance from robot actions, with a score bar for each"></svg><figcaption class="sb-caption">Routes are ordered by distance from robot actions (top = farthest). The longest bar is the route that fits your answers.</figcaption></figure></div>' +
      '<div class="rb-well" data-no-autolink><p><b>Suggested route:</b> <span data-f="best"></span> · <b>What crosses the gap:</b> <span data-f="bridge"></span> · <b>Typical failure:</b> <span data-f="fail"></span></p><p><b>Why it works:</b> <span data-f="works"></span></p><p><b>When it tends to fail:</b> <span data-f="fails"></span></p><p><b>How the methods evolved:</b> <span data-f="lineage"></span></p></div>';
    var svg = body.querySelector("#" + id + "-svg"), last = null;
    function draw() {
      var sc = scoreRoutes(st), best = ROUTES.slice().sort(function (a, b) { return sc[b.id] - sc[a.id] || a.dist - b.dist; })[0];
      last = { scores: sc, best: best.id };
      var h = '<text x="8" y="16" class="rb-t-mono">far from actions</text><text x="8" y="244" class="rb-t-mono">close to actions</text><line x1="196" y1="24" x2="196" y2="226" class="rb-s-line"/>';
      ROUTES.forEach(function (r, i) {
        var y = 34 + i * 50, v = sc[r.id], w = Math.max(0, v) * 26, on = r.id === best.id;
        h += '<text x="8" y="' + (y + 18) + '" class="' + (on ? "rb-t-acc" : "rb-t-ink") + '">' + r.name + "</text>";
        h += '<rect x="196" y="' + (y + 4) + '" width="' + Math.max(2, w) + '" height="22" rx="3" class="' + (on ? "rb-f-acc" : "rb-f-soft") + '"/>';
        h += '<text x="' + (204 + Math.max(2, w)) + '" y="' + (y + 20) + '" class="rb-t-mono">' + v + "</text>";
      });
      svg.innerHTML = h;
      body.querySelector('[data-f="best"]').textContent = best.name;
      body.querySelector('[data-f="bridge"]').textContent = best.bridge;
      body.querySelector('[data-f="fail"]').textContent = best.fail;
      body.querySelector('[data-f="works"]').textContent = best.works;
      body.querySelector('[data-f="fails"]').textContent = best.fails;
      body.querySelector('[data-f="lineage"]').textContent = best.lineage;
    }
    ["need", "robot", "skills", "goal"].forEach(function (k) { RB.bindSeg(body, id + "-" + k, function (v) { st[k] = v; draw(); }); });
    RB.onTheme(draw);
    draw();
    return { state: function () { return { need: st.need, robot: st.robot, skills: st.skills, goal: st.goal, best: last && last.best }; } };
  }

  /* =====================================================================
     Playground 2: latent actions from unlabeled video (LAPA idea, simplified)
     Frame embedding = hand position relative to the camera. The latent action is the
     codebook entry nearest to the embedding difference. Head motion adds a nuisance shift.
     ===================================================================== */
  var DIRS = []; for (var di = 0; di < 8; di++) DIRS.push([Math.cos(di * Math.PI / 4), Math.sin(di * Math.PI / 4)]);
  function makePairs(R, n, cam, fixedCam) {
    var out = [];
    for (var i = 0; i < n; i++) {
      var a = R.int(8), m = 1 + 0.12 * R.normal();
      var dc = fixedCam ? [0, 0] : [cam * R.normal(), cam * R.normal()];
      out.push({ a: a, d: [DIRS[a][0] * m - dc[0] + 0.08 * R.normal(), DIRS[a][1] * m - dc[1] + 0.08 * R.normal()] });
    }
    return out;
  }
  function kmeans(pts, K, R) {
    var C = [pts[R.int(pts.length)].d.slice()];
    while (C.length < K) { /* k-means++ seeding */
      var D = pts.map(function (p) { var b = 1e9; C.forEach(function (c) { var dx = p.d[0] - c[0], dy = p.d[1] - c[1]; b = Math.min(b, dx * dx + dy * dy); }); return b; });
      var tot = D.reduce(function (s, v) { return s + v; }, 0), u = R() * tot, k = 0;
      while (k < D.length - 1 && u > D[k]) { u -= D[k]; k++; }
      C.push(pts[k].d.slice());
    }
    for (var it = 0; it < 25; it++) {
      var S = C.map(function () { return [0, 0, 0]; });
      pts.forEach(function (p) { var j = nearest(C, p.d); p.z = j; S[j][0] += p.d[0]; S[j][1] += p.d[1]; S[j][2]++; });
      C = C.map(function (c, j) { return S[j][2] ? [S[j][0] / S[j][2], S[j][1] / S[j][2]] : c; });
    }
    pts.forEach(function (p) { p.z = nearest(C, p.d); });
    return C;
  }
  function nearest(C, d) { var bj = 0, b = 1e9; C.forEach(function (c, j) { var dx = d[0] - c[0], dy = d[1] - c[1], v = dx * dx + dy * dy; if (v < b) { b = v; bj = j; } }); return bj; }

  function mountLatent(body, ctx) {
    var id = ctx.id, K = 8, cam = 0.1, nLab = 16, stab = false, seed = 5, W = 460, H = 380, res = null;
    body.innerHTML = '<div class="rb-row">' +
      RB.slider({ id: id + "-k", label: "Codebook size", min: 2, max: 16, step: 1, value: K }) +
      RB.slider({ id: id + "-cam", label: "Head motion", min: 0, max: 1.2, step: 0.05, value: cam, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-lab", label: "Labeled robot pairs", min: 0, max: 64, step: 4, value: nLab }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-stab"> <span>Filter out camera motion</span></label>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New videos ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Scatter of frame-to-frame embedding changes colored by the true hand motion, with codebook entries as rings"></canvas><figcaption class="sb-caption">Each dot is the embedding change between two frames, colored by the hand motion nobody labeled. Rings are codebook entries; a ring with an arrow has been grounded to a robot action.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "pur", k: "Code purity" }, { id: "acc", k: "Pseudo-labels that match the true action" }, { id: "chance", k: "Chance (1 of 8)" }, { id: "used", k: "Robot pairs used for grounding" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "true motion (8 directions, one color each)", kind: "dot" }, { c: "ink", label: "codebook entry", kind: "dot" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    function run() {
      var R = RB.rng(seed), eff = stab ? cam * 0.15 : cam;
      var vids = makePairs(R, 320, eff, false), C = kmeans(vids, K, R);
      /* purity: share of pairs whose code's majority true action equals their own (uses hidden labels, for display only) */
      var cnt = C.map(function () { return [0, 0, 0, 0, 0, 0, 0, 0]; });
      vids.forEach(function (p) { cnt[p.z][p.a]++; });
      var pur = cnt.reduce(function (s, row) { return s + Math.max.apply(null, row); }, 0) / vids.length;
      /* grounding: a few robot pairs (fixed camera, labeled) vote on which action each code means */
      var lab = makePairs(R, nLab, 0, true), vote = C.map(function () { return [0, 0, 0, 0, 0, 0, 0, 0]; });
      lab.forEach(function (p) { vote[nearest(C, p.d)][p.a]++; });
      var map = vote.map(function (row) { var m = Math.max.apply(null, row); return m > 0 ? row.indexOf(m) : -1; });
      var test = makePairs(R, 400, eff, false), ok = 0;
      test.forEach(function (p) { var j = nearest(C, p.d); if (map[j] === p.a) ok++; });
      res = { vids: vids, C: C, map: map, pur: pur, acc: nLab ? ok / test.length : null };
      RB.setRO(body, "pur", Math.round(pur * 100) + "%");
      RB.setRO(body, "acc", res.acc == null ? "–" : Math.round(res.acc * 100) + "%");
      RB.setRO(body, "chance", "13%");
      RB.setRO(body, "used", String(nLab));
      note.textContent = !nLab ? "With no labeled robot pairs, the codes are unnamed: a latent action model alone cannot say which robot action a code means (P06 §3.4)." :
        eff > 0.5 ? "Head motion is as large as the hand motion, so the codes group camera shake instead of actions. This is the latent-action failure in P06 Table 9." :
        K < 8 ? "Fewer codes than motions: several hand motions share one code, so no grounding can separate them." :
        "Codes line up with hand motions, and a few labeled robot pairs name them. LAPA fine-tunes on 150 teleoperated trajectories per real task.";
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), s = 95, cx = W / 2, cy = H / 2, col = function (a) { return P["data-" + (a + 1)] || P.ink; };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      c.beginPath(); c.moveTo(0, cy); c.lineTo(W, cy); c.moveTo(cx, 0); c.lineTo(cx, H); c.stroke();
      c.setLineDash([3, 4]); c.beginPath(); c.arc(cx, cy, s, 0, Math.PI * 2); c.stroke(); c.setLineDash([]);
      if (!res) return;
      res.vids.forEach(function (p) { c.fillStyle = col(p.a); c.globalAlpha = 0.7; c.beginPath(); c.arc(cx + p.d[0] * s, cy - p.d[1] * s, 3, 0, Math.PI * 2); c.fill(); });
      c.globalAlpha = 1;
      res.C.forEach(function (k, j) {
        var x = cx + k[0] * s, y = cy - k[1] * s;
        c.strokeStyle = P.ink; c.lineWidth = 2.5; c.beginPath(); c.arc(x, y, 9, 0, Math.PI * 2); c.stroke();
        if (res.map[j] >= 0) { var d = DIRS[res.map[j]]; c.strokeStyle = col(res.map[j]); c.lineWidth = 3; c.beginPath(); c.moveTo(x, y); c.lineTo(x + d[0] * 20, y - d[1] * 20); c.stroke(); }
      });
      c.lineWidth = 1; c.fillStyle = P["ink-3"]; c.font = "500 11px " + getComputedStyle(document.body).getPropertyValue("--font-mono");
      c.fillText("embedding change φ(oₜ₊H) − φ(oₜ)", 10, 18);
    }
    RB.bindSlider(body, id + "-k", null, function (v) { K = v; run(); });
    RB.bindSlider(body, id + "-cam", function (v) { return (+v).toFixed(2); }, function (v) { cam = v; run(); });
    RB.bindSlider(body, id + "-lab", null, function (v) { nLab = v; run(); });
    body.querySelector("#" + id + "-stab").addEventListener("change", function (e) { stab = e.target.checked; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    RB.onTheme(draw);
    run();
    return { get: function () { return { K: K, cam: cam, nLab: nLab, stab: stab, acc: res ? res.acc : null }; } };
  }

  /* =====================================================================
     Playground 3: retargeting a human wrist path onto a two-link arm (optimization)
     q* = argmin ||FK(q) − s·x_h||² + κ||q − q_prev||², with joint limits (projected gradient).
     ===================================================================== */
  var L1 = 0.32, L2 = 0.28, TN = 40;
  function fk(q) { return [L1 * Math.cos(q[0]) + L2 * Math.cos(q[0] + q[1]), L1 * Math.sin(q[0]) + L2 * Math.sin(q[0] + q[1])]; }
  function humanPath(sc) { var p = []; for (var i = 0; i < TN; i++) { var u = i / (TN - 1); p.push([sc * (0.25 + 0.30 * u), sc * (0.08 + 0.22 * Math.sin(Math.PI * u))]); } return p; }
  /* projected Gauss-Newton on ||FK(q) - x||^2 + kap ||q - anchor||^2, started from the best point of a coarse grid */
  function cost(q, x, anchor, kap) { var f = fk(q); return (f[0] - x[0]) * (f[0] - x[0]) + (f[1] - x[1]) * (f[1] - x[1]) + kap * ((q[0] - anchor[0]) * (q[0] - anchor[0]) + (q[1] - anchor[1]) * (q[1] - anchor[1])); }
  function solveIK(x, anchor, kap, lo, hi) {
    var q = null, bc = 1e9;
    for (var i = 0; i <= 36; i++) for (var j = 0; j <= 24; j++) {
      var g = [lo[0] + (hi[0] - lo[0]) * i / 36, lo[1] + (hi[1] - lo[1]) * j / 24], cg = cost(g, x, anchor, kap);
      if (cg < bc) { bc = cg; q = g; }
    }
    for (var it = 0; it < 40; it++) {
      var e = fk(q), r0 = e[0] - x[0], r1 = e[1] - x[1];
      var s1 = Math.sin(q[0]), c1 = Math.cos(q[0]), s12 = Math.sin(q[0] + q[1]), c12 = Math.cos(q[0] + q[1]);
      var j00 = -L1 * s1 - L2 * s12, j01 = -L2 * s12, j10 = L1 * c1 + L2 * c12, j11 = L2 * c12;
      var a = j00 * j00 + j10 * j10 + kap + 1e-3, b = j00 * j01 + j10 * j11, d = j01 * j01 + j11 * j11 + kap + 1e-3;
      var g0 = j00 * r0 + j10 * r1 + kap * (q[0] - anchor[0]), g1 = j01 * r0 + j11 * r1 + kap * (q[1] - anchor[1]);
      var det = a * d - b * b, d0 = (d * g0 - b * g1) / det, d1 = (a * g1 - b * g0) / det;
      var qn = [RB.clamp(q[0] - d0, lo[0], hi[0]), RB.clamp(q[1] - d1, lo[1], hi[1])];
      if (cost(qn, x, anchor, kap) > cost(q, x, anchor, kap)) break;
      q = qn;
    }
    return q;
  }
  function retarget(sc, elbowMax, kap) {
    var tgt = humanPath(sc), lo = [0, -elbowMax], hi = [Math.PI, -0.05], out = [], q = null;
    tgt.forEach(function (x, i) {
      var prev = q ? q.slice() : null;
      q = solveIK(x, prev || [0, 0], prev ? kap : 0, lo, hi);
      var f = fk(q), err = Math.hypot(f[0] - x[0], f[1] - x[1]);
      out.push({ q: q.slice(), ee: f, x: x, err: err, jump: prev ? Math.max(Math.abs(q[0] - prev[0]), Math.abs(q[1] - prev[1])) : 0 });
    });
    return out;
  }
  function mountRetarget(body, ctx) {
    var id = ctx.id, sc = 0.9, elbow = 150, kap = 0.01, frame = 20, W = 480, H = 330, res = null;
    body.innerHTML = '<div class="rb-row">' +
      RB.slider({ id: id + "-sc", label: "Human-to-robot scale", min: 0.6, max: 1.2, step: 0.05, value: sc, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-el", label: "Elbow limit", min: 60, max: 170, step: 5, value: elbow, fmt: function (v) { return v + "°"; } }) +
      RB.slider({ id: id + "-kap", label: "Smoothness weight κ", min: 0, max: 0.2, step: 0.01, value: kap, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-fr", label: "Show frame", min: 0, max: TN - 1, step: 1, value: frame }) + "</div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="A two-link arm following a human wrist path; unreachable targets are marked"></canvas><figcaption class="sb-caption">Dashed curve = the human wrist path, scaled. Solid curve = where the robot hand actually goes. Red rings = targets the arm misses by more than 1 cm.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "mean", k: "Mean tracking error", u: "cm" }, { id: "max", k: "Worst error", u: "cm" }, { id: "miss", k: "Frames off target (> 1 cm)" }, { id: "jump", k: "Largest joint jump", u: "°" }]) +
      '<p class="sb-caption" data-note></p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    function run() {
      res = retarget(sc, elbow * Math.PI / 180, kap);
      var m = 0, mx = 0, miss = 0, jp = 0;
      res.forEach(function (r) { m += r.err; mx = Math.max(mx, r.err); if (r.err > 0.01) miss++; jp = Math.max(jp, r.jump); });
      RB.setRO(body, "mean", RB.fmt(100 * m / res.length, 1));
      RB.setRO(body, "max", RB.fmt(100 * mx, 1));
      RB.setRO(body, "miss", miss + " of " + TN);
      RB.setRO(body, "jump", RB.fmt(jp * 180 / Math.PI, 1));
      note.textContent = miss && kap > 0.05 && mx < 0.05 ? "The misses here are lag, not reach: a large κ keeps the joints close to the last pose, so the hand trails the human path." : miss === 0 ? "Every scaled wrist target is reachable within the joint limits, so the retargeted path matches the human one." :
        "Some targets lie outside what this arm can reach with these limits. The optimizer returns the closest pose: a plausible human motion, mis-grounded on this robot (P06 §3.5).";
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), s = 420, ox = 50, oy = H - 40, px = function (p) { return [ox + p[0] * s, oy - p[1] * s]; };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P.line; c.setLineDash([3, 4]); c.beginPath(); c.arc(ox, oy, (L1 + L2) * s, -Math.PI, 0); c.stroke(); c.setLineDash([]);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + getComputedStyle(document.body).getPropertyValue("--font-mono");
      c.fillText("reach limit", ox + (L1 + L2) * s * 0.72, oy - (L1 + L2) * s * 0.72 - 6);
      c.strokeStyle = P["line-strong"]; c.beginPath(); c.moveTo(0, oy); c.lineTo(W, oy); c.stroke();
      if (!res) return;
      c.strokeStyle = P["ink-2"]; c.setLineDash([5, 4]); c.beginPath(); res.forEach(function (r, i) { var z = px(r.x); if (i) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke(); c.setLineDash([]);
      c.strokeStyle = P["data-1"]; c.lineWidth = 2.5; c.beginPath(); res.forEach(function (r, i) { var z = px(r.ee); if (i) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke();
      c.lineWidth = 1.5; res.forEach(function (r) { if (r.err > 0.01) { var z = px(r.x); c.strokeStyle = P.bad; c.beginPath(); c.arc(z[0], z[1], 5, 0, Math.PI * 2); c.stroke(); } });
      var f = res[frame], q = f.q, e1 = px([L1 * Math.cos(q[0]), L1 * Math.sin(q[0])]), e2 = px(f.ee), b = px([0, 0]);
      c.strokeStyle = P["robot-body"] || P.ink; c.lineWidth = 7; c.lineCap = "round"; c.beginPath(); c.moveTo(b[0], b[1]); c.lineTo(e1[0], e1[1]); c.lineTo(e2[0], e2[1]); c.stroke(); c.lineCap = "butt";
      c.fillStyle = P.ink; [b, e1].forEach(function (z) { c.beginPath(); c.arc(z[0], z[1], 5, 0, Math.PI * 2); c.fill(); });
      var t = px(f.x); c.fillStyle = P.accent; c.beginPath(); c.arc(t[0], t[1], 5, 0, Math.PI * 2); c.fill();
      c.lineWidth = 1; c.fillStyle = P["ink-2"]; c.font = "600 12px " + getComputedStyle(document.body).getPropertyValue("--font-body");
      c.fillText("human target", t[0] - 96, t[1] - 10);
    }
    RB.bindSlider(body, id + "-sc", function (v) { return (+v).toFixed(2); }, function (v) { sc = v; run(); });
    RB.bindSlider(body, id + "-el", function (v) { return v + "°"; }, function (v) { elbow = v; run(); });
    RB.bindSlider(body, id + "-kap", function (v) { return (+v).toFixed(2); }, function (v) { kap = v; run(); });
    RB.bindSlider(body, id + "-fr", null, function (v) { frame = v; draw(); });
    RB.onTheme(draw);
    run();
    return { get: function () { return { sc: sc, elbow: elbow, kap: kap, miss: res.filter(function (r) { return r.err > 0.01; }).length }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token classes only) ---------- */
  var ART = {
    gaps: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="14" width="44" height="28" rx="4" class="rb-f-soft"/><text x="28" y="32" text-anchor="middle" class="rb-t-mono">human</text><rect x="150" y="14" width="44" height="28" rx="4" class="rb-f-sunk"/><text x="172" y="32" text-anchor="middle" class="rb-t-mono">robot</text>' +
      ["obs", "act", "obj"].map(function (t, i) { var x = 64 + i * 28; return '<line x1="' + (x + 6) + '" y1="10" x2="' + (x + 6) + '" y2="46" class="rb-s-acc" stroke-dasharray="3 3"/><text x="' + (x + 6) + '" y="54" text-anchor="middle" class="rb-t-mono">' + t + "</text>"; }).join("") + "</svg>",
    edit: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="8" width="70" height="40" rx="4" class="rb-f-sunk"/><path d="M20 44 Q34 24 52 22 L60 18" class="rb-s-ink"/><circle cx="62" cy="18" r="4" class="rb-f-surface"/><path d="M84 28 H112" class="rb-s-acc"/><text x="98" y="22" text-anchor="middle" class="rb-t-mono">edit</text><rect x="118" y="8" width="70" height="40" rx="4" class="rb-f-sunk"/><path d="M130 44 L146 26 L168 22" class="rb-s-acc"/><rect x="166" y="16" width="10" height="10" class="rb-f-acc"/></svg>',
    tcl: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (i) { return '<rect x="' + (10 + i * 22) + '" y="10" width="18" height="14" rx="2" class="' + (i === 1 ? "rb-f-acc" : i === 2 ? "rb-f-soft" : "rb-f-surface") + '"/>'; }).join("") + '<circle cx="150" cy="30" r="4" class="rb-f-acc"/><circle cx="162" cy="34" r="4" class="rb-f-soft"/><circle cx="188" cy="16" r="4" class="rb-f-surface"/><path d="M152 32 L160 34" class="rb-s-acc"/><path d="M154 28 L184 17" class="rb-s-line" stroke-dasharray="3 3"/><text x="60" y="44" text-anchor="middle" class="rb-t-mono">near in time → near</text></svg>',
    mae: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (r) { return [0, 1, 2, 3].map(function (c) { var m = (r * 4 + c) % 4 !== 1; return '<rect x="' + (14 + c * 12) + '" y="' + (4 + r * 12) + '" width="10" height="10" class="' + (m ? "rb-f-sunk" : "rb-f-soft") + '"/>'; }).join(""); }).join("") + '<path d="M72 28 H120" class="rb-s-ink"/><text x="96" y="22" text-anchor="middle" class="rb-t-mono">ViT</text><rect x="128" y="4" width="46" height="46" rx="2" class="rb-f-soft"/><text x="151" y="31" text-anchor="middle" class="rb-t-mono">image</text></svg>',
    aff: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="120" y="22" width="44" height="26" rx="3" class="rb-f-sunk"/><circle cx="130" cy="22" r="4" class="rb-f-acc"/><path d="M14 44 Q50 6 126 20" class="rb-s-acc" stroke-dasharray="4 3"/><circle cx="14" cy="44" r="5" class="rb-f-surface"/><text x="60" y="52" class="rb-t-mono">hand path</text><text x="142" y="16" class="rb-t-mono">contact</text></svg>',
    latent: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="14" width="30" height="24" rx="3" class="rb-f-sunk"/><text x="21" y="50" text-anchor="middle" class="rb-t-mono">oₜ</text><rect x="44" y="14" width="30" height="24" rx="3" class="rb-f-sunk"/><text x="59" y="50" text-anchor="middle" class="rb-t-mono">oₜ₊H</text><path d="M78 26 H100" class="rb-s-ink"/>' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (106 + i * 20) + '" y="16" width="16" height="20" rx="2" class="' + (i === 2 ? "rb-f-acc" : "rb-f-surface") + '"/>'; }).join("") + '<text x="146" y="50" text-anchor="middle" class="rb-t-mono">code z</text></svg>',
    retarget: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M20 50 L40 26 L62 20" class="rb-s-line"/><circle cx="62" cy="20" r="4" class="rb-f-surface"/><path d="M80 30 H108" class="rb-s-acc"/><text x="94" y="24" text-anchor="middle" class="rb-t-mono">min ‖·‖²</text><path d="M126 50 L146 30 L176 22" class="rb-s-ink"/><circle cx="126" cy="50" r="3" class="rb-f-acc"/><circle cx="146" cy="30" r="3" class="rb-f-acc"/><path d="M146 30 A 12 12 0 0 1 158 34" class="rb-s-acc" stroke-dasharray="2 2"/><text x="170" y="48" class="rb-t-mono">limits</text></svg>',
    cotrain: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="6" y="6" width="50" height="18" rx="3" class="rb-f-soft"/><text x="31" y="19" text-anchor="middle" class="rb-t-mono">hand</text><rect x="6" y="32" width="50" height="18" rx="3" class="rb-f-sunk"/><text x="31" y="45" text-anchor="middle" class="rb-t-mono">robot</text><path d="M58 15 L86 26 M58 41 L86 30" class="rb-s-ink"/><rect x="88" y="16" width="44" height="24" rx="4" class="rb-f-acc"/><text x="110" y="32" text-anchor="middle" class="rb-t-ink">trunk</text><path d="M134 24 L160 14 M134 32 L160 42" class="rb-s-ink"/><text x="164" y="17" class="rb-t-mono">pose</text><text x="164" y="46" class="rb-t-mono">joints</text></svg>'
  };

  /* ---------- worked example figure: one human frame → one robot action (numbers computed below) ---------- */
  var X = function (x) { return (40 + (x - 0.36) * 2600).toFixed(1); }, Y = function (y) { return (150 - (y - 0.06) * 1100).toFixed(1); };
  var WE_FIG = '<svg viewBox="0 0 560 190" role="img" aria-label="Top view of thumb and index fingertips, their midpoint, the gripper opening bar, and the correction for head motion">' +
    '<line x1="30" y1="170" x2="420" y2="170" class="rb-s-line"/><text x="30" y="186" class="rb-t-mono">x (m), camera frame</text>' +
    ['0.40', '0.44', '0.48'].map(function (v) { return '<line x1="' + X(+v) + '" y1="166" x2="' + X(+v) + '" y2="174" class="rb-s-line"/><text x="' + X(+v) + '" y="160" text-anchor="middle" class="rb-t-mono">' + v + "</text>"; }).join("") +
    '<g data-on="1+"><circle cx="' + X(0.42) + '" cy="' + Y(0.10) + '" r="7" class="rb-f-soft"/><text x="' + (X(0.42) - 12) + '" y="' + (+Y(0.10) + 4) + '" text-anchor="end" class="rb-t-ink">thumb</text><circle cx="' + X(0.46) + '" cy="' + Y(0.14) + '" r="7" class="rb-f-soft"/><text x="' + (+X(0.46) + 12) + '" y="' + (+Y(0.14) + 4) + '" class="rb-t-ink">index</text></g>' +
    '<g data-on="2+"><line x1="' + X(0.42) + '" y1="' + Y(0.10) + '" x2="' + X(0.46) + '" y2="' + Y(0.14) + '" class="rb-s-line" stroke-dasharray="3 3"/><circle cx="' + X(0.44) + '" cy="' + Y(0.12) + '" r="6" class="rb-f-acc"/><text x="' + (+X(0.44) + 12) + '" y="' + (+Y(0.12) + 16) + '" class="rb-t-acc">p = (0.44, 0.12, 0.17)</text></g>' +
    '<g data-on="3+"><text x="440" y="40" class="rb-t-mono">gripper w</text><rect x="440" y="50" width="100" height="14" rx="3" class="rb-f-sunk"/><rect x="440" y="50" width="60" height="14" rx="3" class="rb-f-acc"/><text x="440" y="82" class="rb-t-acc">0.06 / 0.10 = 0.6</text></g>' +
    '<g data-on="4+"><circle cx="' + X(0.40) + '" cy="' + Y(0.12) + '" r="5" class="rb-f-surface"/><text x="' + X(0.40) + '" y="' + (+Y(0.12) - 12) + '" text-anchor="middle" class="rb-t-mono">raw 0.40</text><path d="M' + X(0.40) + " " + (+Y(0.12) + 10) + " H" + X(0.43) + '" class="rb-s-acc"/><circle cx="' + X(0.43) + '" cy="' + Y(0.12) + '" r="5" class="rb-f-acc"/><text x="' + X(0.43) + '" y="' + (+Y(0.12) + 28) + '" text-anchor="middle" class="rb-t-acc">0.43</text></g>' +
    '<g data-on="5"><text x="440" y="120" class="rb-t-ink">action entry:</text><text x="440" y="138" class="rb-t-mono">Δx = −0.01 m</text><text x="440" y="154" class="rb-t-mono">w = 0.6</text></g></svg>';

  RB.topic({
    id: "d2",
    title: "Learning from human videos",
    eyebrow: "Part D · Data",
    lede: "People film themselves doing tasks every day. This topic shows how robots turn that action-free video into perception, plans and actions.",
    refs: ["P06 §2.3, §3", "P06 Table 9", "P05 §4"],
    why: "Teleoperated robot data is slow to collect: one hour of human data gave about 1,400 demonstrations against 135 from robot teleoperation (P06 Table 1). But human video has no robot actions, shows a human body, and carries no reward. Each method bridges these gaps with one intermediate: features, edited frames, hand tracks or latent actions.",
    outcomes: [
      "Name the three gaps between human video and robot learning.",
      "Classify a method by the bridge it uses across the gap.",
      "Compute a gripper action from two tracked fingertips.",
      "Explain why latent actions need labeled robot data to ground them.",
      "Choose a transfer route for a given bottleneck using P06 Table 9."
    ],
    concepts: [
      { name: "Three gaps", def: "Human video differs from robot data in what is seen, what action is taken, and which objective applies.", ref: "P06 eq. 3", art: ART.gaps, term: "embodiment-gap", sym: "bridge" },
      { name: "Transformed videos", def: "Inpaint the human arm out of each frame and render a robot in its place.", ref: "P06 §3.2.1", art: ART.edit, term: "embodiment-transformation" },
      { name: "Time-contrastive features", def: "Train an encoder so frames close in time embed close together; TCN, R3M and VIP do this.", ref: "P06 §3.2.2", art: ART.tcl, term: "time-contrastive-learning", sym: "phienc" },
      { name: "Masked pretraining", def: "Hide most image patches and reconstruct them; MVP and VC-1 freeze the resulting encoder.", ref: "P06 §3.2.2", art: ART.mae, term: "masked-visual-pretraining" },
      { name: "Affordances", def: "Explicit cues from video about where and how a hand touches an object.", ref: "P06 §3.3.1", art: ART.aff, term: "interaction-affordance" },
      { name: "Latent actions", def: "A discrete code for what changed between two frames, learned without action labels.", ref: "P06 §3.3.2", art: ART.latent, term: "latent-action", sym: "codebook" },
      { name: "Retargeting", def: "Solve for robot joints whose hand pose best matches the human's, within the robot's limits.", ref: "P05 §4.1 · P06 §3.3.1", art: ART.retarget, term: "retargeting", sym: "qj" },
      { name: "Human-robot co-training", def: "One policy learns from hand poses and robot actions together through a shared trunk.", ref: "EgoMimic, arXiv 2410.24221", art: ART.cotrain, term: "human-robot-co-training", href: "#lab/data" }
    ],
    flow: {
      title: "Where each bridge enters the robot pipeline", ref: "P06 Fig. 3, §3", w: 820, h: 310,
      caption: "Human video enters at one of three levels. The closer the bridge is to actions, the more directly it shapes motion, and the easier it is to mis-ground.",
      nodes: [
        { id: "vid", x: 20, y: 120, w: 150, h: 56, label: "Human video", sub: "no actions, human body", kind: "env" },
        { id: "task", x: 250, y: 20, w: 190, h: 52, label: "Task level", sub: "structures, intents", kind: "decision" },
        { id: "obs", x: 250, y: 122, w: 190, h: 52, label: "Observation level", sub: "edited frames, embeddings", kind: "decision" },
        { id: "act", x: 250, y: 224, w: 190, h: 52, label: "Action level", sub: "affordances, latent actions", kind: "decision" },
        { id: "pol", x: 600, y: 120, w: 150, h: 56, label: "Robot policy", sub: "BC, RL or VLA", kind: "agent" },
        { id: "rob", x: 724, y: 236, w: 92, h: 52, label: "Robot data", sub: "few demos", kind: "store" }
      ],
      edges: [
        { from: "vid", to: "task", label: "parse steps", sides: ["t", "l"], via: [[95, 46]] },
        { from: "vid", to: "obs", label: "align views" },
        { from: "vid", to: "act", label: "extract motion", sides: ["b", "l"], via: [[95, 250]] },
        { from: "task", to: "pol", label: "plan or prompt", sides: ["r", "t"], via: [[675, 46]] },
        { from: "obs", to: "pol", label: "features, reward" },
        { from: "act", to: "pol", label: "pseudo-actions", sides: ["r", "b"], via: [[675, 250]], labelAt: [540, 250] },
        { from: "rob", to: "pol", label: "ground", sides: ["t", "r"], via: [[770, 148]], labelAt: [762, 212], anchor: "end", dy: 0 }
      ],
      steps: [
        { on: ["vid"], text: "Human video has three gaps: a human body instead of a robot (observation), no action labels (action), and no task reward (objective)." },
        { on: ["vid>task", "task", "task>pol"], text: "Task-level bridges parse steps or intents from the video. The robot must already have skills to execute them." },
        { on: ["vid>obs", "obs", "obs>pol"], text: "Observation-level bridges edit frames or pretrain an encoder such as R3M, then feed features or a reward to the policy." },
        { on: ["vid>act", "act", "act>pol"], text: "Action-level bridges extract hand tracks, contact points or latent actions and use them as supervision for actions." },
        { on: ["rob", "rob>pol", "pol"], text: "Most routes still need some robot data to ground what was transferred. Phantom is an exception: it trains on human video only." }
      ]
    },
    worked: {
      title: "From one human frame to one robot action",
      ref: "Phantom · EgoMimic", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-x}{x_t} = \\tfrac{1}{2}\\big(\\class{sym-ftip}{\\mathbf{f}^{\\mathrm{th}}_t} + \\class{sym-ftip}{\\mathbf{f}^{\\mathrm{ix}}_t}\\big), \\qquad \\class{sym-gripw}{w_t} = \\frac{\\|\\class{sym-ftip}{\\mathbf{f}^{\\mathrm{th}}_t} - \\class{sym-ftip}{\\mathbf{f}^{\\mathrm{ix}}_t}\\|}{d_{\\max}}",
        words: "The gripper goes to the midpoint of thumb and index tips, and opens as wide as they are apart.",
        key: ["x", "ftip", "gripw", { glyph: "d_max", meaning: "widest pinch, here 0.10 m" }] },
      figure: WE_FIG,
      steps: [
        { title: "Track two fingertips", text: "A hand estimator plus depth gives thumb (0.42, 0.10, 0.18) m and index (0.46, 0.14, 0.16) m in the camera frame." },
        { title: "Midpoint is the position", text: "Average the tips: x = (0.44, 0.12, 0.17) m. Phantom uses this midpoint as the end-effector position." },
        { title: "Pinch width is the gripper", text: "The tips are √(0.04² + 0.04² + 0.02²) = 0.06 m apart. Divided by 0.10 m, the gripper opening is 0.6." },
        { title: "Remove head motion", text: "Next step the hand reads 0.40 m, but the head camera moved +0.03 m. In the first frame's coordinates the hand is at 0.43 m." },
        { title: "The action entry", text: "The true hand motion is −0.01 m, not −0.04 m. EgoMimic re-expresses future hand poses in the current frame for this reason." }
      ]
    },
    ruleTitle: "The gap, the features, the codes and the co-training loss",
    rules: [
      { name: "Learning from human video as three gaps", ref: "P06 eq. 3", term: "embodiment-gap",
        tex: "\\class{sym-bridge}{\\mathcal{B}}^{*} = \\arg\\min_{\\class{sym-bridge}{\\mathcal{B}}}\\; \\class{sym-L}{\\mathcal{L}}_{\\mathrm{obs}}(\\class{sym-bridge}{\\mathcal{B}}) + \\class{sym-L}{\\mathcal{L}}_{\\mathrm{act}}(\\class{sym-bridge}{\\mathcal{B}}) + \\class{sym-L}{\\mathcal{L}}_{\\mathrm{obj}}(\\class{sym-bridge}{\\mathcal{B}})",
        words: "Find the bridge that maps human video to a shared space while shrinking the observation, action and objective gaps.",
        key: ["bridge", "L", { glyph: "obs, act, obj", meaning: "observation, action, objective gap" }] },
      { name: "From tracking a demo to a goal-distance reward", ref: "TCN arXiv 1704.06888 · VIP arXiv 2210.00030", term: "time-contrastive-learning",
        before: "\\class{sym-r}{r_t} = -\\big\\|\\class{sym-phienc}{\\phi}(\\class{sym-o}{o_t}) - \\class{sym-phienc}{\\phi}(\\class{sym-o}{o^{h}_t})\\big\\|^2",
        tex: "\\class{sym-r}{r_t} = \\class{sb-chg}{\\big\\|\\class{sym-phienc}{\\phi}(\\class{sym-o}{o_t}) - \\class{sym-phienc}{\\phi}(\\class{sym-o}{o_{\\mathrm{goal}}})\\big\\| - \\big\\|\\class{sym-phienc}{\\phi}(\\class{sym-op}{o_{t+1}}) - \\class{sym-phienc}{\\phi}(\\class{sym-o}{o_{\\mathrm{goal}}})\\big\\|}",
        words: "TCN rewards matching the human frame at the same time. VIP rewards each step that brings the embedding closer to a goal image.",
        key: ["r", "phienc", "o", "op", { glyph: "oʰₜ", meaning: "human demo frame at time t" }], diff: true, beforeLabel: "TCN", afterLabel: "VIP" },
      { name: "Latent action from two frames (LAPA)", ref: "LAPA, arXiv 2410.11758 · P06 §3.3.2", term: "latent-action",
        tex: "\\begin{aligned} \\class{sym-z}{z_t} &= \\arg\\min_{k}\\,\\big\\|\\big(\\class{sym-phienc}{\\phi}(\\class{sym-op}{o_{t+H}}) - \\class{sym-phienc}{\\phi}(\\class{sym-o}{o_t})\\big) - \\class{sym-codebook}{c_k}\\big\\| \\\\ \\class{sym-L}{\\mathcal{L}} &= \\big\\|\\class{sym-op}{o_{t+H}} - \\class{sym-ptheta}{p_\\theta}(\\class{sym-o}{o_t}, \\class{sym-z}{z_t})\\big\\|^2 \\end{aligned}",
        words: "Snap the change between two frame embeddings to the nearest code, then train a decoder to rebuild the later frame from the earlier frame and the code.",
        key: ["z", "phienc", "op", "o", "codebook", "L", "ptheta"] },
      { name: "EgoMimic: ACT's loss plus a hand term", ref: "EgoMimic, arXiv 2410.24221", term: "human-robot-co-training",
        before: "\\class{sym-L}{\\mathcal{L}} = \\big\\|\\hat{\\mathbf{a}} - \\class{sym-achunk}{\\mathbf{a}_{t:t+H}}\\big\\|_1 + \\class{sym-beta}{\\beta}\\,\\class{sym-KL}{D_{\\mathrm{KL}}}",
        tex: "\\begin{aligned} \\class{sym-L}{\\mathcal{L}} = &\\underbrace{\\big\\|\\hat{\\mathbf{a}}^{p} - \\class{sym-achunk}{\\mathbf{a}^{p}}\\big\\|_1 + \\big\\|\\hat{\\mathbf{a}}^{j} - \\class{sym-achunk}{\\mathbf{a}^{j}}\\big\\|_1}_{\\text{robot}} \\\\ &+ \\class{sb-new}{\\underbrace{\\big\\|\\hat{\\mathbf{a}}^{p}_{h} - \\class{sym-achunk}{\\mathbf{a}^{p}_{h}}\\big\\|_1}_{\\text{human hand}}} + \\class{sym-KL}{D_{\\mathrm{KL}}} \\end{aligned}",
        words: "Robot data supervises pose and joint chunks. Human data adds a pose-only term through the same trunk, since hands have no robot joints.",
        key: ["L", "achunk", "beta", "KL", { glyph: "p, j", meaning: "pose space, joint space" }, { glyph: "h", meaning: "from human hand data" }], diff: true, beforeLabel: "ACT", afterLabel: "EgoMimic" },
      { name: "Retargeting as an optimization", ref: "Our formulation · P06 §3.3.1, §3.5", term: "retargeting",
        tex: "\\class{sym-qj}{q}_t^{*} = \\arg\\min_{\\class{sym-qj}{q} \\in [q_{\\min}, q_{\\max}]}\\; \\big\\|\\mathrm{FK}(\\class{sym-qj}{q}) - s\\,\\class{sym-x}{x^{h}_t}\\big\\|^2 + \\class{sym-ksmooth}{\\kappa}\\,\\big\\|\\class{sym-qj}{q} - \\class{sym-qj}{q}_{t-1}\\big\\|^2",
        words: "Pick joint angles within limits that put the robot hand near the scaled human hand without jumping from the last pose.",
        key: ["qj", "x", "ksmooth", { glyph: "FK", meaning: "forward kinematics" }, { glyph: "s", meaning: "human-to-robot scale" }] }
    ],
    algorithm: {
      title: "Latent action pretraining in three stages", ref: "LAPA, arXiv 2410.11758 · P06 Fig. 16", prov: "Our notation",
      lines: [
        '<span class="cm">// stage 1: learn latent actions from video, no labels</span>',
        '<span class="kw">for</span> frame pairs (<span data-sym="o">oₜ</span>, <span data-sym="op">oₜ₊H</span>) in human or robot video:',
        '    <span data-sym="z">zₜ</span> ← nearest code <span data-sym="codebook">cₖ</span> to <span data-sym="phienc">φ</span>(oₜ₊H) − <span data-sym="phienc">φ</span>(oₜ)   <span class="cm">// 4 tokens, 8-code vocabulary</span>',
        '    update encoder, codebook and decoder <span data-sym="ptheta">p_θ</span> to rebuild oₜ₊H from (oₜ, zₜ)',
        '<span class="cm">// stage 2: pretrain the VLA to predict latent actions</span>',
        'label every frame with <span data-sym="z">zₜ</span>; train the VLM (7B) to predict <span data-sym="z">zₜ</span> from <span data-sym="o">oₜ</span> and <span data-sym="l">ℓ</span>',
        '<span class="cm">// stage 3: ground on a few labeled robot trajectories</span>',
        'swap the latent head for a robot action head; fine-tune on 150 trajectories per real task',
        '<span class="kw">return</span> policy <span data-sym="pi">π_θ</span>(<span data-sym="a">aₜ</span> | <span data-sym="o">oₜ</span>, <span data-sym="l">ℓ</span>)'
      ]
    },
    playgrounds: [
      {
        id: "route", title: "Route-selection wizard", ref: "P06 §3.5, Table 9", prov: "Our choice: scores paraphrase Table 9",
        try: "Start with Motion, no robot data and One task. Then switch to Many demonstrations and Generalist, and watch the suggestion move to latent actions.",
        mount: mountRoute,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "d2-route";
          return [
            { target: q("#" + id + "-robot"), title: "No robot data at all", text: "With zero robot demonstrations, only a route that turns human motion straight into robot actions can work. Phantom does this with edited video.", do: function (a) { return a.click(q("#" + id + '-robot [value="none"]')); }, task: "Choose None for robot data", expect: function () { return api.state().robot === "none"; } },
            { target: q("#" + id + "-svg"), title: "Affordances win here", text: "Affordance-based transfer suits precise tasks and human-video-only pipelines. Its risk is mis-grounding: a hand path the robot cannot follow." },
            { target: q("#" + id + "-goal"), title: "Aim for a generalist", text: "Generalist pretraining favors latent actions, which scale to unlabeled video. They still need robot demonstrations for grounding.", do: function (a) { return a.click(q("#" + id + '-goal [value="general"]')); }, task: "Choose Generalist", expect: function () { return api.state().goal === "general"; } },
            { target: q("#" + id + "-robot"), title: "Add robot demonstrations", text: "With many robot demonstrations to ground the codes, latent actions become the suggested route, as in LAPA and villa-X.", do: function (a) { return a.click(q("#" + id + '-robot [value="many"]')); }, task: "Choose Many robot demonstrations", expect: function () { return api.state().best === "lat"; } },
            { target: q("#" + id + "-need"), title: "Your turn", text: "Pick Next step and answer Yes for existing skills. The task-level route wins, and its failure is under-grounding." }
          ];
        }
      },
      {
        id: "latent", title: "Latent actions from unlabeled video", ref: "LAPA, arXiv 2410.11758 · P06 §3.3.2", prov: "Simplified: 2-D toy",
        try: "Raise Head motion until the colors mix inside each code, then tick Filter out camera motion. Set Labeled robot pairs to 0 to see why grounding is needed.",
        mount: mountLatent,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "d2-latent";
          return [
            { target: q("canvas"), title: "Codes from video alone", text: "Eight hand motions form eight clusters of embedding changes. The codebook finds them without any action label." },
            { target: q("#" + id + "-cam"), title: "Add head motion", text: "An egocentric camera moves with the head. Its motion adds to every embedding change, and the clusters blur into each other.", do: function (a) { return a.set(q("#" + id + "-cam"), 0.8); }, task: "Set Head motion to 0.8 or more", expect: function () { return api.get().cam >= 0.8; } },
            { target: q(".sb-readouts"), title: "Codes follow the camera", text: "Purity and pseudo-label accuracy drop. The codes now describe camera shake, the failure P06 Table 9 names for latent actions." },
            { target: q("#" + id + "-stab"), title: "Filter the nuisance", text: "Task-centric latent actions try to remove motion that is not the task. Here the filter keeps 15% of the head motion.", do: function (a) { return a.click(q("#" + id + "-stab")); }, task: "Tick Filter out camera motion", expect: function () { return api.get().stab; } },
            { target: q("#" + id + "-lab"), title: "Remove the grounding", text: "Without labeled robot pairs the codes have no meaning for the robot. LAPA fine-tunes on 150 real trajectories per task.", do: function (a) { return a.set(q("#" + id + "-lab"), 0); }, task: "Set Labeled robot pairs to 0", expect: function () { return api.get().nLab === 0; } },
            { target: q("#" + id + "-k"), title: "Your turn", text: "Restore 16 labeled pairs and set the codebook to 4. Two motions must share a code, and accuracy falls to about half." }
          ];
        }
      },
      {
        id: "retarget", title: "Retargeting a human wrist path", ref: "P06 §3.5 · P05 §8.5", prov: "Simplified: planar two-link arm",
        try: "Raise the scale to 1.2 so the path leaves the reach circle. Then lower the elbow limit to 90° and scrub Show frame to see where the arm gives up.",
        mount: mountRetarget,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "d2-retarget";
          return [
            { target: q("canvas"), title: "A reachable human path", text: "At scale 0.9 every wrist target is inside the reach circle, and the solid robot path lies on the dashed human path." },
            { target: q("#" + id + "-sc"), title: "A bigger human", text: "Human arms and robot arms differ in size. Scaled up, the end of the path lies outside the robot's reach.", do: function (a) { return a.set(q("#" + id + "-sc"), 1.15); }, task: "Set the scale to 1.15 or more", expect: function () { return api.get().sc >= 1.15; } },
            { target: q(".sb-readouts"), title: "Plausible but not executable", text: "The optimizer returns the closest reachable pose. Tracking error grows: this is mis-grounding, a human motion the robot cannot reproduce." },
            { target: q("#" + id + "-el"), title: "Tighter joint limits", text: "A smaller elbow range cuts the reachable set further, even for targets inside the circle.", do: function (a) { return a.set(q("#" + id + "-el"), 90); }, task: "Set the elbow limit to 90°", expect: function () { return api.get().elbow <= 90; } },
            { target: q("#" + id + "-kap"), title: "Your turn", text: "Reset the scale to 0.9 and raise κ to 0.2. The hand now lags the target: smoothing trades tracking error for smaller joint jumps." }
          ];
        }
      }
    ],
    methods: ["lapa", "egomimic", "phantom", "r3m", "vip", "villa-x", "atm", "mimicplay", "time-contrastive-networks", "mvp", "vc-1", "being-h0"],
    open: [
      { title: "Latent codes that follow the camera", text: "Latent actions can encode head motion or background change instead of the action, and they always need robot grounding.", refs: "P06 §3.3.2, Table 9" },
      { title: "Mis-grounded motion", text: "Retargeted hand motion can look right yet violate the robot's kinematics, control rate, collisions or contact dynamics.", refs: "P06 §3.5 · P05 §8.5" },
      { title: "Physically grounded world models", text: "Most methods transfer local cues; learning how interactions evolve with physical consistency from human video is open.", refs: "P06 §5.1" },
      { title: "Functional affordances", text: "Affordances capture where and how a hand moves, but rarely what function a contact serves or which physical limits apply.", refs: "P06 §5.2" }
    ],
    takeaways: [
      "Human video lacks robot observations, robot actions and task rewards; every method bridges one or more of these three gaps.",
      "Observation bridges went from TCN to R3M to VIP; VIP is a better reward than R3M, while R3M is a slightly better encoder.",
      "Action bridges went from MimicPlay's planner to EgoMimic's co-training to Phantom's zero-robot-data edited video.",
      "Latent actions let a VLA pretrain on unlabeled video, but a small labeled robot set must name the codes.",
      "Pick the highest-level bridge that removes your bottleneck, then ground it with robot data or closed-loop control."
    ],
    quiz: [
      { q: "Which gap does P06 call L_obj?", options: ["The human body appears in the image", "Human video has no robot action labels", "Human video has no task annotations or reward", "The camera moves with the head"], correct: 2, why: "P06 eq. 3 splits the problem into an observation gap, an action gap, and an objective gap from missing task annotations or reward." },
      { q: "What did VIP change compared with R3M?", options: ["It added language labels", "It replaced time contrast plus language with a self-supervised value objective", "It used masked image reconstruction", "It trained on robot data only"], correct: 1, why: "VIP casts pretraining as offline goal-conditioned RL; its embedding distance gives smooth rewards. On FoldTowel VIP-RWR reached 90% versus R3M-RWR 0% (arXiv 2210.00030)." },
      { q: "A latent action model learns codes from videos where the head moves a lot. What goes wrong?", options: ["The codebook cannot be trained", "Codes capture camera motion instead of the action", "The decoder needs action labels", "Nothing: codes ignore the camera"], correct: 1, why: "P06 Table 9: latent-action transfer fails when the code captures camera motion or background change instead of controllable actions." },
      { q: "Phantom trains a policy with how many robot demonstrations?", options: ["Zero", "About 20", "About 150", "About 1,400"], correct: 0, why: "Phantom converts human videos into robot images and actions and deploys with no robot data; Pick/Place Book reached 0.92 (arXiv 2503.00779)." }
    ],
    cards: [
      { front: "What are the three gaps between human video and robot learning?", back: "Observation (human body, viewpoint), action (no robot action labels) and objective (no task annotation or reward).", ref: "P06 eq. 3" },
      { front: "Name the six bridges in P06's taxonomy.", back: "Task structures, task intents, transformed videos, visual embeddings, affordances and latent actions.", ref: "P06 §3, Fig. 3" },
      { front: "How does LAPA get action labels for video?", back: "It quantizes the embedding change between two frames into codes, pretrains a VLA to predict them, then fine-tunes on robot actions.", ref: "arXiv 2410.11758" },
      { front: "What does EgoMimic's human data supervise?", back: "Only the pose head: hands have no robot joints or gripper signal, so joint actions come from robot data.", ref: "arXiv 2410.24221" },
      { front: "What is mis-grounding?", back: "A trajectory, contact cue or latent action that looks plausible in human video but violates the robot's kinematics, collisions or contact dynamics.", ref: "P06 §3.5" },
      { front: "Why does villa-X add a proprioceptive decoder to its latent action model?", back: "Visual-only latents miss rotations and gripper motion; predicting robot states and actions grounds the codes physically.", ref: "arXiv 2507.23682" }
    ],
    terms: {
      "embodiment-gap": { name: "human-robot gap", aliases: ["embodiment gap", "cross-embodiment discrepancy"], group: "data", sym: "ℬ", symTex: "\\mathcal{B}", def: "The discrepancies between human videos and robot learning in observation, action and objective, which a bridging function must minimize.", note: "Visual alignment alone does not close the action gap.", ref: "P06 eq. 3", scene: "system", focus: ["data-human", "robot"], look: "human video versus the robot", uses: [] },
      "transfer-bridge": { name: "transfer bridge", aliases: ["bridging mechanism", "LfHV route"], group: "data", def: "The intermediate information that carries skill from human video to robot: task structures, task intents, transformed videos, visual embeddings, affordances or latent actions.", note: "P06 assigns a method to the bridge that dominates, even if it uses others.", ref: "P06 §3, Fig. 3", scene: "system", focus: ["data-human", "policy-update"], look: "what crosses from video to policy", uses: ["embodiment-gap"] },
      "embodiment-transformation": { name: "embodiment transformation", aliases: ["inpaint and overlay", "robot overlay"], group: "data", def: "Removing human appearance from video frames and rendering a robot arm in its place, so training images look like robot observations.", note: "Embodiment suppression only removes the human; transformation also adds the robot.", ref: "P06 §3.2.1", scene: "system", focus: ["data-human", "camera-image"], look: "edited frames with a robot", uses: ["transfer-bridge"] },
      "time-contrastive-learning": { name: "time-contrastive learning", aliases: ["TCL", "temporal contrastive learning"], group: "data", sym: "φ", symTex: "\\phi", def: "Pretraining an encoder so that embeddings of frames close in time are pulled together and frames far apart are pushed apart.", note: "TCN used simultaneous views as positives; R3M and VIP work on single-view Ego4D clips.", ref: "P06 §3.2.2", scene: "system", focus: ["vision-encoder", "data-human"], look: "encoder trained on video order", uses: ["transfer-bridge"] },
      "masked-visual-pretraining": { name: "masked visual pretraining", aliases: ["MVP", "masked autoencoding"], group: "data", def: "Pretraining a vision transformer by reconstructing randomly masked image patches of human-interaction frames, then freezing it for control.", note: "MVP masked 75% of patches; VC-1 scaled the recipe to ViT-L on 5.6M frames.", ref: "P06 §3.2.2", scene: "system", focus: ["vision-encoder"], look: "frozen encoder from masked images", uses: ["transfer-bridge"] },
      "interaction-affordance": { name: "affordance", aliases: ["hand-object affordance", "interaction affordance"], group: "data", def: "Interaction-related geometric and functional signals from human video: hand and object positions, trajectories, motion flow, and contact or separation regions.", note: "Affordances used as policy conditions in P06's tables all target parallel grippers.", ref: "P06 §3.3.1", scene: "robot", focus: ["human-hand", "contact-point", "trajectory"], look: "hand path and contact point", uses: ["transfer-bridge"] },
      "latent-action": { name: "latent action", aliases: ["latent action code", "pseudo-action"], group: "data", sym: "zₜ", symTex: "z_t", def: "A compact, usually discrete code for the change between two frames, learned without action labels and used as a pseudo-action.", note: "It is not a robot command until robot data maps it to one.", ref: "P06 §3.3.2", scene: "system", focus: ["latent", "data-human"], look: "code inferred between frames", uses: ["latent-action-model"] },
      "latent-action-model": { name: "latent action model", aliases: ["LAM"], group: "data", def: "An inverse dynamics part infers a latent action from adjacent observations; a forward dynamics part reconstructs the future observation from the current one and that latent.", note: "The reconstruction target decides what the codes capture: pixels, features or proprioception.", ref: "P06 §3.3.2, Table 6", scene: "system", focus: ["latent", "world-model"], look: "encoder, code and decoder", uses: [] },
      "retargeting": { name: "retargeting", aliases: ["motion retargeting", "hand retargeting"], group: "data", def: "Mapping human hand or wrist poses to robot joint or end-effector commands, usually by inverse kinematics or optimization under the robot's limits.", note: "A target the robot cannot reach is returned as the closest pose, silently.", ref: "P05 §4.1 · P06 §3.3.1", scene: "robot", focus: ["human-hand", "arm", "end-effector"], look: "human hand mapped to the arm", uses: ["interaction-affordance"] },
      "human-robot-co-training": { name: "human-robot co-training", aliases: ["human and robot co-training", "unified human-robot policy"], group: "data", def: "Training one policy on human hand data and robot demonstrations together, with shared layers and embodiment-specific output heads.", note: "EgoMimic: removing hand data dropped Object-in-Bowl from 128 to 68 points.", ref: "arXiv 2410.24221", scene: "system", focus: ["data-human", "data-robot", "policy-update"], look: "hand and robot data, one policy", uses: ["retargeting"] },
      "mis-grounding": { name: "mis-grounding", aliases: ["grounding failure"], group: "data", def: "A failure of action-level bridges: the extracted trajectory, contact or latent action looks plausible in human video but violates the robot's kinematics, control rate, collisions or contact dynamics.", note: "Its opposite, under-grounding, affects task-level bridges: the robot knows the task but cannot execute it.", ref: "P06 §3.5", scene: "robot", focus: ["trajectory", "arm"], look: "a path the arm cannot follow", uses: ["retargeting", "latent-action"] }
    },
    symbols: [
      { id: "bridge", tex: "\\mathcal{B}", glyph: "ℬ", kind: "Functions", meaning: "bridging function that maps human videos to a representation shared with the robot", short: "human-to-robot bridge", first: "d2", read: "script B", papers: "P06 eq. 3: Φ" },
      { id: "phienc", tex: "\\phi", glyph: "φ", kind: "Functions", meaning: "pretrained visual encoder: image to embedding", short: "visual encoder", first: "d2", read: "phi", papers: "VIP: φ · R3M: F_φ · TCN: f(x) · LAPA: e_t" },
      { id: "codebook", tex: "c_k", glyph: "cₖ", kind: "Parameters", meaning: "entry k of a learned codebook of latent actions", short: "codebook entry", first: "d2", read: "c sub k", papers: "LAPA: z_k · villa-X: VQ codebook" },
      { id: "ftip", tex: "\\mathbf{f}", glyph: "𝐟", kind: "Robot", meaning: "tracked fingertip position of a human hand (thumb, index)", short: "fingertip position", first: "d2", read: "bold f", papers: "Phantom: HaMeR keypoints X_t" },
      { id: "gripw", tex: "w_t", glyph: "wₜ", kind: "Robot", meaning: "gripper opening in [0, 1] derived from pinch width", short: "gripper opening", first: "d2", read: "w sub t", papers: "Phantom: g_t" },
      { id: "ksmooth", tex: "\\kappa", glyph: "κ", kind: "Parameters", meaning: "weight on joint change between frames in retargeting", short: "smoothness weight", first: "d2", read: "kappa", papers: "Our formulation" }
    ],
    ledger: [
      { where: "Topic 14 · rules", source: "P06 eq. 3 names the bridging function Φ", page: "This site writes ℬ", why: "Φ is the P04 predictive-substrate axis in house notation.", kind: "Our choice" },
      { where: "Topic 14 · TCN rule", source: "TCN's reward adds a Huber-style term −β√(γ + ‖w − v‖²)", page: "Only the squared distance is shown", why: "Keeps the contrast with VIP visible.", kind: "Simplified" },
      { where: "Topic 14 · LAPA rule", source: "LAPA writes d = e₂ − e₁ and trains with NSVQ noise substitution and a stop-gradient on p₁", page: "Shown as nearest-code quantization of φ(oₜ₊H) − φ(oₜ) with a reconstruction loss", why: "One encoder symbol φ across the topic.", kind: "Simplified" },
      { where: "Topic 14 · worked example", source: "Phantom writes the gripper as g_t, a normalized thumb-index distance; the normalizer is not stated here", page: "Uses wₜ and d_max = 0.10 m", why: "g is the grasp pose in house notation; d_max is our toy value.", kind: "Our choice" },
      { where: "Topic 14 · MVP", source: "Surveys and VC-1 describe MVP as ViT-B/L on about 4.5M frames; the original MVP paper uses ViT-S on about 700K frames", page: "Glossary follows the original paper (arXiv 2203.06173)", why: "The larger model is the follow-up, arXiv 2210.03109.", kind: "Sources disagree" },
      { where: "Topic 14 · route wizard", source: "P06 Table 9 gives qualitative guidance", page: "The wizard adds integer scores", why: "Makes the table's logic interactive; the weights are ours.", kind: "Our choice" },
      { where: "Topic 14 · latent and retargeting playgrounds", source: "Real latent action models and retargeting use images and full arms", page: "2-D embeddings with k-means; planar two-link arm with projected gradient descent", why: "Shows the mechanism and its failure modes only.", kind: "Simplified" }
    ]
  });
})();
