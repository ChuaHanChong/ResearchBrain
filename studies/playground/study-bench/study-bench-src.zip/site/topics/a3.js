/* Topic 03 · Reinforcement learning for robots. Sources: X2 §3 (eq. 9–17, Fig. 16–17), P07 §3–5 and supplementary Tables 1–5, P09 §VII-A, method cards (DQN → DDPG → SAC, PPO, QT-Opt, RLPD → SERL → HIL-SERL, Residual RL, DayDreamer). */
(function () {
  "use strict";
  var RB = window.RB;

  /* =====================================================================================
     Playground 1 · maturity map filter (P07 supplementary Tables 2–5 and Fig. 2, 4)
     Every number below is a reference number of P07's bibliography, copied from its tables.
     Rows: locomotion (all of §4.1) and the seven manipulation sub-problems of Fig. 4.
     ===================================================================================== */
  /* RB.bindSeg reads .value from the value string StudyBench.segmented already passes, so wire segments directly */
  function onSeg(root, id, cb) { StudyBench.segmented(root.querySelector("#" + id), function (v) { cb(v); }); }
  function refs(s) { return s.split(",").map(function (x) { return +x; }); }
  var LOCO = { zs: refs("27,28,29,30,31,32,33,34,35,36,37,38,40,41,42,44,45,46,47,49,50,51,52,55,57,58,59,60,61,62,63,64,65,66,67,68"), fs: refs("43,48,56"), ns: refs("53,54"),
    dense: refs("27,28,29,30,31,32,33,34,35,36,37,38,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,57,58,59,60,61,62,63,64,65,66,67,68"), sparse: refs("56"),
    on: refs("27,28,29,30,31,32,33,34,35,36,37,38,40,41,42,43,44,45,46,47,49,50,51,52,55,56,57,58,59,60,61,62,63,64,65,66,67"), off: refs("32,36,48,53,54,68"), offline: [],
    expert: refs("27,30,36,40,46,48,51,55,58,63,64") };
  var MANI = { zs: refs("108,111,123,130,133,134,135,137,138,139,141,142,143,144,145,146,147"), fs: refs("116,131"), ns: refs("54,109,110,112,113,114,115,117,118,119,120,121,122,124,125,126,127,128,129,132,136,140"),
    dense: refs("109,113,116,118,119,120,121,123,125,126,127,130,131,132,133,135,136,137,138,139,140,141,142,143,144,145,146,147"), sparse: refs("54,108,110,111,112,114,115,117,118,122,124,128,129,134"),
    on: refs("113,130,131,138,139,141,142,144,147"), off: refs("54,109,110,111,112,114,116,117,119,120,123,125,126,127,128,132,133,134,135,136,137,143,145,146"), offline: refs("108,115,121,122,124,129"),
    expert: refs("112,113,117,120,121,122,124,126,127,128,129,132,134,136") };
  var ROWS = [
    { id: "loco", name: "Locomotion (all)", src: LOCO, papers: refs("27,28,29,30,31,32,33,34,35,36,37,38,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68") },
    { id: "grasp", name: "Grasping", src: MANI, papers: refs("108,109,110,111,112") },
    { id: "pnp", name: "Pick-and-place", src: MANI, papers: refs("54,113,114,115,116,117,118,119,120,121,122,123,124,125") },
    { id: "asm", name: "Assembly", src: MANI, papers: refs("126,127,128,129,130") },
    { id: "art", name: "Articulated objects", src: MANI, papers: refs("122,131,132,133") },
    { id: "def", name: "Deformable objects", src: MANI, papers: refs("134,135,136,137") },
    { id: "inh", name: "In-hand", src: MANI, papers: refs("138,139,140,141,142,143,144") },
    { id: "np", name: "Non-prehensile", src: MANI, papers: refs("109,118,145,146,147") }
  ];
  var COLS = [
    { id: "zs", short: "Zero-shot sim", grp: "Simulator" }, { id: "fs", short: "Few-shot sim", grp: "Simulator" }, { id: "ns", short: "No simulator", grp: "Simulator" },
    { id: "dense", short: "Dense reward", grp: "Reward" }, { id: "sparse", short: "Sparse reward", grp: "Reward" },
    { id: "on", short: "On-policy", grp: "Optimizer" }, { id: "off", short: "Off-policy", grp: "Optimizer" }, { id: "offline", short: "Offline", grp: "Optimizer" },
    { id: "expert", short: "Expert data", grp: "Expert" }
  ];
  /* names from P07's reference list (p. 34) for the manipulation papers we could verify */
  var NAMES = { 110: "QT-Opt", 111: "RCAN", 113: "end-to-end visuomotor", 114: "MT-Opt", 115: "Actionable Models", 116: "RGB-stacking", 117: "Walke et al.", 118: "Visual Foresight", 119: "Learning by Playing", 120: "Ingredients of real-world RL", 121: "VIP", 122: "AWAC", 123: "MAPLE primitives", 124: "Q-Transformer", 125: "RIG", 126: "Residual RL", 127: "DDPGfD", 128: "Luo et al. assembly", 129: "offline meta-RL insertion", 130: "IndustReal", 131: "SimOpt" };
  var PRESETS = { sim: ["zs", "dense", "on"], real: ["ns", "off", "expert"] };

  function mountMaturity(body, ctx) {
    var id = ctx.id, sel = PRESETS.sim.slice();
    body.innerHTML =
      '<div class="rb-row"><div class="sb-chips" id="' + id + '-chips" role="group" aria-label="Attributes a paper must have">' +
      COLS.map(function (c) { return '<button type="button" class="sb-btn" data-col="' + c.id + '" aria-pressed="false">' + c.short + "</button>"; }).join("") + "</div></div>" +
      '<div class="rb-row"><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-sim">Sim-to-real recipe</button><button class="sb-btn" type="button" id="' + id + '-real">Real-world recipe</button><button class="sb-btn" type="button" id="' + id + '-clear">Clear</button></div>' +
      '<div class="sb-scroll-x"><table class="sb-table sb-table--compact sb-table--sticky-col" id="' + id + '-tab"></table></div>' +
      '<div class="rb-grid2"><div class="rb-stack">' + RB.readouts([{ id: "loco", k: "Locomotion papers matching" }, { id: "mani", k: "Manipulation papers matching" }, { id: "best", k: "Top manipulation row" }]) + "</div>" +
      '<div class="rb-stack"><p class="sb-caption" data-list></p>' + RB.legend([{ c: "data-1", label: "share of the row's papers with the attribute", kind: "area" }]) + "</div></div>";
    var tab = body.querySelector("#" + id + "-tab"), list = body.querySelector("[data-list]");
    function has(row, col, p) { return row.src[col].indexOf(p) >= 0; }
    function match(row) { return row.papers.filter(function (p) { return sel.every(function (c) { return has(row, c, p); }); }); }
    function shade(f) { return "background:color-mix(in oklab, var(--data-1) " + Math.round(f * 55) + "%, var(--surface))"; }
    function render() {
      RB.$$("[data-col]", body).forEach(function (b) { b.setAttribute("aria-pressed", sel.indexOf(b.getAttribute("data-col")) >= 0 ? "true" : "false"); });
      var h = '<thead><tr><th scope="col">Competency (P07 refs)</th><th scope="col">Papers</th><th scope="col">All selected</th>' + COLS.map(function (c) { return '<th scope="col"' + (sel.indexOf(c.id) >= 0 ? ' style="color:var(--accent-strong)"' : "") + ">" + c.short + "</th>"; }).join("") + "</tr></thead><tbody>";
      var locoN = 0, maniSet = {}, best = null;
      ROWS.forEach(function (row) {
        var n = row.papers.length, m = match(row);
        if (row.id === "loco") locoN = m.length; else { m.forEach(function (p) { maniSet[p] = 1; }); if (!best || m.length / n > best.f) best = { f: m.length / n, row: row, k: m.length }; }
        h += "<tr><th scope=\"row\">" + row.name + "</th><td data-v>" + n + '</td><td data-v style="' + (sel.length ? shade(m.length / n) : "") + ';font-weight:600">' + (sel.length ? m.length + " / " + n : "–") + "</td>" + COLS.map(function (c) {
          var k = row.papers.filter(function (p) { return has(row, c.id, p); }).length;
          return "<td data-v style=\"" + shade(k / n) + '">' + k + "</td>";
        }).join("") + "</tr>";
      });
      tab.innerHTML = h + "</tbody>";
      var maniN = Object.keys(maniSet).length;
      RB.setRO(body, "loco", sel.length ? locoN + " of 41" : "–");
      RB.setRO(body, "mani", sel.length ? maniN + " of 41" : "–");
      RB.setRO(body, "best", sel.length && best && best.k ? best.k + " of " + best.row.papers.length : "–");
      var ms = Object.keys(maniSet).map(Number).sort(function (a, b) { return a - b; });
      list.textContent = !sel.length ? "Choose one or more attributes to see which papers have all of them." :
        ms.length ? "Top manipulation row: " + best.row.name + ". Papers with all selected attributes: " + ms.map(function (p) { return NAMES[p] ? NAMES[p] + " [" + p + "]" : "[" + p + "]"; }).join(", ") + ". Numbers are P07 reference numbers." : "No manipulation paper in P07 has all the selected attributes.";
    }
    RB.$$("[data-col]", body).forEach(function (b) {
      b.addEventListener("click", function () { var c = b.getAttribute("data-col"), i = sel.indexOf(c); if (i >= 0) sel.splice(i, 1); else sel.push(c); render(); });
    });
    body.querySelector("#" + id + "-sim").addEventListener("click", function () { sel = PRESETS.sim.slice(); render(); });
    body.querySelector("#" + id + "-real").addEventListener("click", function () { sel = PRESETS.real.slice(); render(); });
    body.querySelector("#" + id + "-clear").addEventListener("click", function () { sel = []; render(); });
    render();
    return { sel: function () { return sel.slice().sort().join(","); } };
  }

  /* =====================================================================================
     Playground 2 · HIL-SERL ingredients on a tabular peg-insertion toy
     A 12 × 7 grid; the hole is in the wall at x = 11, at row 2 (fixture A) or row 4 (fixture B).
     Sparse reward 1 on insertion. Off-policy Q-learning from two buffers sampled 50/50 (RLPD-style).
     Demonstrations were recorded with fixture A only. The human steps in after 4 steps without progress.
     The reward classifier can fire falsely when the peg rests beside the hole; the episode then ends.
     ===================================================================================== */
  var GW = 12, GH = 7, SLOTS = [2, 4], TMAX = 30, MOVES = [[1, 0], [-1, 0], [0, 1], [0, -1]], GAM = 0.9, EPS = 60, SEEDS = 4;
  function blocked(x, y, g) { return x < 0 || y < 0 || y >= GH || x >= GW || (x === GW - 1 && y !== g); }
  function looksLike(s) { return s[0] === GW - 2 && s[1] === s[2] + (s[2] < 3 ? 1 : -1); }
  function envStep(s, a, fp, R) {
    var nx = s[0] + MOVES[a][0], ny = s[1] + MOVES[a][1];
    if (blocked(nx, ny, s[2])) { nx = s[0]; ny = s[1]; }
    var ns = [nx, ny, s[2]], ins = nx === GW - 1, fire = !ins && fp > 0 && looksLike(ns) && R() < fp;
    return { s: ns, r: ins || fire ? 1 : 0, done: ins || fire, ins: ins, fire: fire };
  }
  function expert(s) { if (s[0] < GW - 4) return 0; if (s[1] !== s[2]) return s[1] < s[2] ? 2 : 3; return 0; }
  function qi(s) { return ((s[2] === SLOTS[0] ? 0 : 1) * GH + s[1]) * GW + s[0]; }
  function train(opt, seed) {
    var R = RB.rng(seed), Q = new Float64Array(GW * GH * 2 * 4), demo = [], online = [], truth = [], rep = [], human = 0, fires = 0;
    function qmax(s) { var i = qi(s) * 4; return Math.max(Q[i], Q[i + 1], Q[i + 2], Q[i + 3]); }
    function greedy(s) { var i = qi(s) * 4, b = 0, bv = -1e9; for (var a = 0; a < 4; a++) { var v = Q[i + a] + 1e-6 * R(); if (v > bv) { bv = v; b = a; } } return b; }
    function start() { return [R.int(3), R.int(GH), SLOTS[R.int(2)]]; }
    for (var d = 0; d < opt.demos; d++) { var s0 = start(); s0[2] = SLOTS[0]; for (var t0 = 0; t0 < TMAX; t0++) { var a0 = R() < 0.15 ? R.int(4) : expert(s0), o0 = envStep(s0, a0, 0, R); demo.push([s0, a0, o0.r, o0.s, o0.done]); s0 = o0.s; if (o0.done) break; } }
    function upd(tr) { var i = qi(tr[0]) * 4 + tr[1], y = tr[2] + (tr[4] ? 0 : GAM * qmax(tr[3])); Q[i] += 0.3 * (y - Q[i]); }
    function evaluate() {
      var ok = 0, said = 0, n = 0;
      for (var g = 0; g < 2; g++) for (var y = 0; y < GH; y++) for (var x = 0; x < 3; x++) {
        n++; var s = [x, y, SLOTS[g]];
        for (var t = 0; t < TMAX; t++) { var o = envStep(s, greedy(s), opt.fp, R); s = o.s; if (o.done) { said++; if (o.ins) ok++; break; } }
      }
      truth.push(ok / n); rep.push(said / n);
    }
    for (var ep = 0; ep < EPS; ep++) {
      var s = start(), stuck = 0, best = s[0], interv = 0;
      for (var t = 0; t < TMAX; t++) {
        var a, byHuman = false;
        if (interv > 0) { a = expert(s); interv--; byHuman = true; human++; } else a = R() < 0.2 ? R.int(4) : greedy(s);
        var o = envStep(s, a, opt.fp, R), tr = [s, a, o.r, o.s, o.done];
        online.push(tr); if (byHuman) demo.push(tr);
        if (opt.human && !byHuman) { if (o.s[0] <= best) stuck++; else { stuck = 0; best = o.s[0]; } if (stuck >= 4) { interv = 5; stuck = 0; } }
        for (var gi = 0; gi < opt.utd; gi++) for (var b = 0; b < 8; b++) { var pool = demo.length && b % 2 ? demo : online; upd(pool[R.int(pool.length)]); }
        s = o.s; if (o.done) { if (o.fire) fires++; break; }
      }
      evaluate();
    }
    return { Q: Q, truth: truth, rep: rep, human: human, fires: fires, greedy: greedy };
  }

  function mountHil(body, ctx) {
    var id = ctx.id, opt = { demos: 20, human: false, fp: 0, utd: 2 }, view = 0, res = null, last = null;
    var pct = function (v) { return Math.round(v * 100) + "%"; };
    body.innerHTML =
      '<div class="rb-row">' + RB.slider({ id: id + "-demos", label: "Demonstrations (fixture A)", min: 0, max: 30, step: 5, value: 20 }) +
      RB.slider({ id: id + "-fp", label: "Classifier false positives", min: 0, max: 0.6, step: 0.1, value: 0, fmt: pct }) +
      RB.slider({ id: id + "-utd", label: "Updates per step", min: 1, max: 8, step: 1, value: 2 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-human"> <span>Human interventions</span></label>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Train again ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Grid workspace colored by the learned value, with the greedy path to the hole"></canvas>' +
      '<figcaption class="sb-caption">Darker cells = higher learned value max Q. Watch value spread backward from the hole. The line is the greedy path from the left edge; the ringed cell is where the classifier can be fooled.</figcaption>' +
      '<div class="rb-row">' + RB.seg({ id: id + "-view", label: "Fixture shown", value: "0", options: [{ value: "0", label: "Fixture A" }, { value: "1", label: "Fixture B" }] }) + "</div></figure>" +
      '<div class="rb-stack">' + RB.readouts([{ id: "truth", k: "Truly inserted, last episode" }, { id: "said", k: "Classifier says success" }, { id: "human", k: "Human steps per run" }, { id: "fires", k: "False rewards in training" }]) +
      '<div data-chart></div><p class="sb-caption">Simplified: tabular Q-learning, 4 seeds, 60 training episodes. HIL-SERL reports 0% without demos or interventions, 49% with demos only, 100% with both (arXiv 2410.21845, Table 1b).</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), W = 480, H = 300, host = body.querySelector("[data-chart]");
    function run() {
      var tr = null, rp = null, h = 0, f = 0;
      for (var k = 0; k < SEEDS; k++) {
        var r = train(opt, 101 + k); if (k === 0) last = r;
        h += r.human; f += r.fires;
        if (!tr) { tr = r.truth.slice(); rp = r.rep.slice(); } else r.truth.forEach(function (v, i) { tr[i] += v; rp[i] += r.rep[i]; });
      }
      tr = tr.map(function (v) { return v / SEEDS; }); rp = rp.map(function (v) { return v / SEEDS; });
      res = { tr: tr, rp: rp };
      RB.setRO(body, "truth", pct(tr[EPS - 1])); RB.setRO(body, "said", pct(rp[EPS - 1]));
      RB.setRO(body, "human", String(Math.round(h / SEEDS))); RB.setRO(body, "fires", RB.fmt(f / SEEDS, 1));
      host.innerHTML = "";
      StudyBench.lineChart(host, { title: "Success during training", height: 200, directLabels: false, x: { label: "training episode", min: 1, max: EPS }, y: { label: "success", min: 0, max: 1, fmt: pct },
        series: [{ name: "truly inserted", color: "data-1", points: tr.map(function (v, i) { return [i + 1, v]; }) }, { name: "classifier says", color: "data-2", dash: true, points: rp.map(function (v, i) { return [i + 1, v]; }) }] });
      draw();
    }
    function draw() {
      if (!last) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), cs = 38, ox = 12, oy = 16, g = SLOTS[view];
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var vmax = 1e-6, vals = [];
      for (var y = 0; y < GH; y++) for (var x = 0; x < GW; x++) { var i = qi([x, y, g]) * 4, v = Math.max(last.Q[i], last.Q[i + 1], last.Q[i + 2], last.Q[i + 3]); vals.push(v); if (v > vmax) vmax = v; }
      for (var y2 = 0; y2 < GH; y2++) for (var x2 = 0; x2 < GW; x2++) {
        var px = ox + x2 * cs, py = oy + (GH - 1 - y2) * cs;
        if (x2 === GW - 1 && y2 !== g) { c.fillStyle = P["surface-strong"]; c.fillRect(px, py, cs, cs); c.strokeStyle = P["line-strong"]; c.strokeRect(px + 0.5, py + 0.5, cs - 1, cs - 1); continue; }
        var vv = vals[y2 * GW + x2] / vmax;
        c.fillStyle = P["data-1"]; c.globalAlpha = 0.08 + 0.8 * vv; c.fillRect(px + 1, py + 1, cs - 2, cs - 2); c.globalAlpha = 1;
      }
      var hx = ox + (GW - 1) * cs, hy = oy + (GH - 1 - g) * cs;
      c.strokeStyle = P.good; c.lineWidth = 3; c.strokeRect(hx + 2, hy + 2, cs - 4, cs - 4); c.lineWidth = 1;
      var lk = [GW - 2, g + (g < 3 ? 1 : -1)], lx = ox + lk[0] * cs + cs / 2, ly = oy + (GH - 1 - lk[1]) * cs + cs / 2;
      c.strokeStyle = P.warn; c.lineWidth = 2; c.setLineDash([4, 3]); c.beginPath(); c.arc(lx, ly, cs / 2 - 4, 0, Math.PI * 2); c.stroke(); c.setLineDash([]); c.lineWidth = 1;
      /* greedy path from (0, 3) with the classifier switched off, so the path shows the policy itself */
      var R = RB.rng(5), s = [0, 3, g], pts = [s];
      for (var t = 0; t < TMAX; t++) { var o = envStep(s, last.greedy(s), 0, R); s = o.s; pts.push(s); if (o.done) break; }
      c.strokeStyle = P.ink; c.lineWidth = 2.5; c.beginPath();
      pts.forEach(function (p, k) { var X = ox + p[0] * cs + cs / 2, Y = oy + (GH - 1 - p[1]) * cs + cs / 2; if (k) c.lineTo(X, Y); else c.moveTo(X, Y); }); c.stroke(); c.lineWidth = 1;
      c.fillStyle = P.ink; c.beginPath(); c.arc(ox + cs / 2, oy + (GH - 1 - 3) * cs + cs / 2, 5, 0, Math.PI * 2); c.fill();
      var font = getComputedStyle(document.body).getPropertyValue("--font-mono");
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + font;
      c.fillText("hole", hx + 4, hy + cs + 13);
      c.fillText("start", ox + 2, oy + (GH - 1 - 3) * cs - 3);
    }
    RB.bindSlider(body, id + "-demos", null, function (v) { opt.demos = v; run(); });
    RB.bindSlider(body, id + "-fp", pct, function (v) { opt.fp = v; run(); });
    RB.bindSlider(body, id + "-utd", null, function (v) { opt.utd = v; run(); });
    body.querySelector("#" + id + "-human").addEventListener("change", function (e) { opt.human = e.target.checked; run(); });
    onSeg(body, id + "-view", function (v) { view = +v; draw(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { run(); });
    RB.onTheme(draw);
    run();
    return { opt: function () { return { demos: opt.demos, human: opt.human, fp: opt.fp, utd: opt.utd, view: view }; }, result: function () { return res; } };
  }

  /* =====================================================================================
     Playground 3 · PPO's clip on a three-grasp policy
     Old policy p_old over three grasps; exact (full-batch) surrogate; K epochs of gradient ascent on the same batch.
     ===================================================================================== */
  var P_OLD = [0.3, 0.4, 0.3], ADV = [1.0, -0.2, -0.6], LR = 1.5;
  function softmax(z) { var m = Math.max.apply(null, z), e = z.map(function (v) { return Math.exp(v - m); }), s = e.reduce(function (a, b) { return a + b; }, 0); return e.map(function (v) { return v / s; }); }
  function ppoRun(K, eps, clip) {
    var z = P_OLD.map(Math.log), out = [[0, 1]], p = P_OLD.slice();
    for (var k = 1; k <= K; k++) {
      p = softmax(z);
      var grad = [0, 0, 0];
      for (var a = 0; a < 3; a++) {
        var rho = p[a] / P_OLD[a], A = ADV[a];
        var active = !clip || !((A > 0 && rho > 1 + eps) || (A < 0 && rho < 1 - eps));
        if (!active) continue;
        for (var j = 0; j < 3; j++) grad[j] += P_OLD[a] * A * rho * ((a === j ? 1 : 0) - p[j]);
      }
      z = z.map(function (v, j) { return v + LR * grad[j]; });
      p = softmax(z); out.push([k, p[0] / P_OLD[0]]);
    }
    var kl = 0; for (var i = 0; i < 3; i++) kl += P_OLD[i] * Math.log(P_OLD[i] / p[i]);
    return { pts: out, p: p, kl: kl };
  }
  function mountPpo(body, ctx) {
    var id = ctx.id, K = 10, eps = 0.2, sign = 1;
    body.innerHTML =
      '<div class="rb-row">' + RB.slider({ id: id + "-eps", label: "Clip range ε_clip", min: 0.05, max: 0.5, step: 0.05, value: 0.2, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-k", label: "Epochs on one batch", min: 1, max: 30, step: 1, value: 10 }) +
      RB.seg({ id: id + "-sign", label: "Advantage sign in left chart", value: "1", options: [{ value: "1", label: "Positive Â" }, { value: "-1", label: "Negative Â" }] }) + "</div>" +
      '<div class="rb-grid2"><div data-c1></div><div data-c2></div></div>' +
      RB.readouts([{ id: "rc", k: "Ratio of top grasp, clipped" }, { id: "ru", k: "Ratio of top grasp, unclipped" }, { id: "kl", k: "KL from old, clipped" }, { id: "klu", k: "KL from old, unclipped" }]) +
      '<p class="sb-caption">Illustrative: three grasps with old probabilities 0.3, 0.4, 0.3 and advantages +1.0, −0.2, −0.6; exact gradients, step size 1.5. PPO reports 0.82 with ε = 0.2 and −0.39 without clipping (arXiv 1707.06347).</p>';
    var c1 = body.querySelector("[data-c1]"), c2 = body.querySelector("[data-c2]");
    function run() {
      var pts = [];
      for (var i = 0; i <= 40; i++) { var r = i * 0.05, cl = Math.min(Math.max(r, 1 - eps), 1 + eps); pts.push([+r.toFixed(2), Math.min(r * sign, cl * sign)]); }
      c1.innerHTML = "";
      StudyBench.lineChart(c1, { title: "Clipped objective for one sample", height: 200, directLabels: false, x: { label: "ratio ρₜ", min: 0, max: 2 }, y: { label: "objective", min: -2, max: 2, fmt: function (v) { return (+v).toFixed(1); } },
        series: [{ name: "PPO clipped", color: "data-1", points: pts }, { name: "unclipped ρÂ", color: "data-3", dash: true, points: pts.map(function (p) { return [p[0], p[0] * sign]; }) }] });
      var a = ppoRun(K, eps, true), b = ppoRun(K, eps, false);
      c2.innerHTML = "";
      StudyBench.lineChart(c2, { title: "Ratio of the top grasp over epochs", height: 200, x: { label: "epoch", min: 0, max: K }, y: { label: "ratio ρ", min: 0.8, max: 3.4, fmt: function (v) { return (+v).toFixed(2); } },
        series: [{ name: "clipped", color: "data-1", points: a.pts }, { name: "unclipped", color: "data-3", dash: true, points: b.pts }] });
      RB.setRO(body, "rc", RB.fmt(a.pts[a.pts.length - 1][1], 2)); RB.setRO(body, "ru", RB.fmt(b.pts[b.pts.length - 1][1], 2));
      RB.setRO(body, "kl", RB.fmt(a.kl, 3)); RB.setRO(body, "klu", RB.fmt(b.kl, 3));
    }
    RB.bindSlider(body, id + "-eps", function (v) { return (+v).toFixed(2); }, function (v) { eps = v; run(); });
    RB.bindSlider(body, id + "-k", null, function (v) { K = v; run(); });
    onSeg(body, id + "-sign", function (v) { sign = +v; run(); });
    run();
    return { get: function () { return { K: K, eps: eps, sign: sign }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token classes only) ---------- */
  var ART = {
    target: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="18" width="34" height="20" rx="3" class="rb-f-sunk"/><text x="27" y="32" text-anchor="middle" class="rb-t-mono">rₜ</text><text x="54" y="32" class="rb-t-mono">+ γ ·</text><rect x="84" y="18" width="46" height="20" rx="3" class="rb-f-soft"/><text x="107" y="32" text-anchor="middle" class="rb-t-mono">Q̄(s′)</text><path d="M134 28 H156" class="rb-s-ink"/><circle cx="172" cy="28" r="12" class="rb-f-acc"/><text x="172" y="52" text-anchor="middle" class="rb-t-mono">yₜ</text></svg>',
    replay: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="60" y="8" width="80" height="40" rx="3" class="rb-f-sunk"/>' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (66 + i * 18) + '" y="16" width="14" height="24" rx="2" class="' + (i === 1 ? "rb-f-soft" : "rb-f-surface") + '"/>'; }).join("") + '<path d="M10 28 H56" class="rb-s-ink"/><path d="M144 28 H190" class="rb-s-acc"/><text x="12" y="20" class="rb-t-mono">new</text><text x="150" y="20" class="rb-t-mono">reuse</text></svg>',
    entropy: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 48 Q60 46 80 14 Q100 46 190 48" class="rb-s-line" stroke-dasharray="3 3"/><path d="M10 48 Q50 44 80 26 Q110 44 190 48" class="rb-s-acc"/><text x="120" y="18" class="rb-t-mono">+α·entropy</text><text x="10" y="14" class="rb-t-mono">π(a|s)</text></svg>',
    clip: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M14 50 L100 16 H186" class="rb-s-acc"/><path d="M100 16 L150 -4" class="rb-s-line" stroke-dasharray="3 3"/><line x1="100" y1="10" x2="100" y2="54" class="rb-s-line"/><text x="104" y="52" class="rb-t-mono">1 + ε</text><text x="118" y="34" class="rb-t-mono">no push</text></svg>',
    clf: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="10" width="44" height="36" rx="3" class="rb-f-sunk"/><rect x="24" y="22" width="8" height="18" class="rb-f-soft"/><rect x="20" y="36" width="24" height="6" class="rb-f-surface"/><path d="M58 28 H86" class="rb-s-ink"/><rect x="90" y="16" width="52" height="24" rx="12" class="rb-f-soft"/><text x="116" y="32" text-anchor="middle" class="rb-t-mono">c(e⁺|s)</text><path d="M146 28 H164" class="rb-s-ink"/><text x="170" y="32" class="rb-t-acc">0/1</text></svg>',
    human: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 40 Q50 40 70 30 Q84 22 96 34" class="rb-s-line"/><path d="M96 34 Q120 50 140 30 Q160 14 190 16" class="rb-s-acc"/><circle cx="96" cy="34" r="5" class="rb-f-acc"/><text x="20" y="20" class="rb-t-mono">policy drifts</text><text x="120" y="52" class="rb-t-mono">human fixes</text></svg>',
    zeroshot: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (i) { return '<rect x="' + (10 + i * 5) + '" y="' + (6 + i * 5) + '" width="44" height="20" rx="3" class="rb-f-sunk"/>'; }).join("") + '<text x="42" y="52" text-anchor="middle" class="rb-t-mono">sim × N</text><path d="M84 32 H132" class="rb-s-acc"/><text x="108" y="24" text-anchor="middle" class="rb-t-mono">no tuning</text><rect x="140" y="18" width="48" height="28" rx="3" class="rb-f-soft"/><text x="164" y="36" text-anchor="middle" class="rb-t-mono">real</text></svg>',
    levels: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4, 5].map(function (i) { return '<rect x="' + (8 + i * 32) + '" y="' + (46 - i * 6) + '" width="28" height="' + (6 + i * 6) + '" rx="2" class="' + (i >= 3 ? "rb-f-soft" : "rb-f-sunk") + '"/><text x="' + (22 + i * 32) + '" y="' + (42 - i * 6) + '" text-anchor="middle" class="rb-t-mono">L' + i + "</text>"; }).join("") + "</svg>"
  };

  /* ---------- worked example figure: TD targets for one insertion step ---------- */
  var NX = function (v) { return (240 + (v - 0.6) / 0.45 * 300).toFixed(1); };
  function bar(x, v, lab, on, hi) { var h = (v * 110).toFixed(1); return '<g data-on="' + on + '"><rect x="' + x + '" y="' + (140 - h) + '" width="34" height="' + h + '" rx="2" class="' + (hi ? "rb-f-soft" : "rb-f-sunk") + '"/><text x="' + (x + 17) + '" y="' + (134 - h) + '" text-anchor="middle" class="rb-t-mono">' + v.toFixed(2) + '</text><text x="' + (x + 17) + '" y="156" text-anchor="middle" class="rb-t-mono">' + lab + "</text></g>"; }
  function mark(v, y, lab, on, anchor, cls) { var x = NX(v); return '<g data-on="' + on + '"><line x1="' + x + '" y1="84" x2="' + x + '" y2="96" class="rb-s-acc"/><line x1="' + x + '" y1="' + (y < 90 ? y + 4 : y - 12) + '" x2="' + x + '" y2="' + (y < 90 ? 84 : 96) + '" class="rb-s-line"/><text x="' + (+x + (anchor === "end" ? -5 : anchor === "start" ? 5 : 0)) + '" y="' + y + '" text-anchor="' + (anchor || "middle") + '" class="' + (cls || "rb-t-acc") + '">' + lab + "</text></g>"; }
  var WE_FIG = '<svg viewBox="0 0 560 170" role="img" aria-label="Left: Q-values of three next actions. Right: a number line where the DQN, DDPG and SAC targets land relative to the current estimate 0.70">' +
    '<text x="20" y="16" class="rb-t-ink">Q̄(s′, ·) for three next moves</text>' +
    bar(30, 0.58, "left", "2+", false) + bar(80, 0.81, "down", "2+", true) + bar(130, 0.66, "right", "2+", false) +
    '<line x1="24" y1="140" x2="176" y2="140" class="rb-s-line"/>' +
    '<text x="240" y="16" class="rb-t-ink">Targets yₜ on the value scale</text>' +
    '<line x1="240" y1="90" x2="545" y2="90" class="rb-s-line"/>' +
    '<g class="rb-t-mono"><text x="' + NX(0.6) + '" y="108" text-anchor="middle">0.6</text><text x="' + NX(0.8) + '" y="108" text-anchor="middle">0.8</text><text x="' + NX(1.0) + '" y="108" text-anchor="middle">1.0</text></g>' +
    mark(0.70, 128, "Q now 0.70", "1+", "end", "rb-t-ink") +
    mark(0.802, 60, "DQN 0.802", "2+", "start") +
    mark(0.733, 128, "DDPG 0.733", "3+", "start") +
    mark(0.787, 40, "SAC 0.787", "4+", "end") +
    '<g data-on="5"><path d="M' + NX(0.70) + " 78 H" + NX(0.787) + '" class="rb-s-acc"/><text x="' + NX(0.60) + '" y="74" class="rb-t-acc">δ = 0.087</text></g>' +
    mark(1.0, 60, "success 1.0", "6", "middle") + "</svg>";

  RB.topic({
    id: "a3",
    title: "Reinforcement learning for robots",
    eyebrow: "Part A · Foundations",
    lede: "A robot can improve by trial and error when a reward scores each attempt. Here is how the main algorithms work and where they succeed.",
    refs: ["X2 §3", "P07 §3–5", "P09 §VII-A"],
    why: "Reinforcement learning (RL) trains a policy from reward instead of demonstrations. Two families dominate robotics: on-policy PPO, trained in massive simulation and deployed zero-shot, and off-policy actor-critics such as SAC and RLPD, which reuse every costly real transition. Real-world manipulation adds demonstrations, learned reward classifiers and human corrections.",
    outcomes: [
      "Compute the DQN, DDPG and SAC targets for one transition.",
      "Explain what DDPG changed about DQN, and what SAC changed about DDPG.",
      "Explain why PPO dominates simulation and off-policy methods dominate real-world training.",
      "Trace one HIL-SERL loop through actor, classifier, buffers and learner.",
      "Use P07's taxonomy to find the recipe behind mature RL results."
    ],
    concepts: [
      { name: "Temporal-difference target", def: "Critics regress Q(s, a) toward the reward plus γ times the next state's value from a slow target copy.", ref: "X2 eq. 11–12", art: ART.target, term: "td-target", sym: "ytd" },
      { name: "Replay buffer", def: "Off-policy learners store every transition and reuse it many times; demonstrations can join the same pool.", ref: "X2 §3.2", art: ART.replay, term: "replay-buffer", sym: "D" },
      { name: "Maximum entropy", def: "SAC rewards a random policy as well as a successful one, so exploration continues where Q is flat.", ref: "X2 eq. 15", art: ART.entropy, term: "maximum-entropy-rl", sym: "alpha-ent" },
      { name: "Clipped surrogate", def: "PPO stops pushing a probability ratio past 1 ± ε, so several epochs on one batch stay safe.", ref: "arXiv 1707.06347", art: ART.clip, term: "clipped-surrogate", sym: "ratio" },
      { name: "Reward classifier", def: "An image classifier trained on success and failure frames replaces a hand-written reward.", ref: "X2 §3.2", art: ART.clf, term: "reward-classifier" },
      { name: "Human intervention", def: "An operator takes over when the policy drifts; the corrections enter both the demonstration and RL buffers.", ref: "X2 §3.2, Fig. 16", art: ART.human, term: "human-intervention" },
      { name: "Zero-shot sim-to-real", def: "Train entirely in simulation with dense rewards, then deploy with no real-world updates.", ref: "P07 §5", art: ART.zeroshot, term: "zero-shot-sim-to-real", href: "#lab/sim2real" },
      { name: "Levels of real-world success", def: "P07 grades each result from L0 (simulation only) to L5 (deployed in a commercial product).", ref: "P07 §3.4, Fig. 1d", art: ART.levels, term: "level-of-real-world-success" }
    ],
    flow: {
      title: "The HIL-SERL actor–learner loop", ref: "X2 Fig. 16–17 · arXiv 2410.21845", w: 820, h: 300,
      caption: "Two processes share a policy. The actor collects labeled transitions on the robot; the learner trains on equal halves of demonstration and robot data, then sends new weights back.",
      nodes: [
        { id: "robot", x: 20, y: 122, w: 170, h: 56, label: "Robot + actor", sub: "frozen copy of π_θ", kind: "env" },
        { id: "human", x: 20, y: 236, w: 170, h: 56, label: "Human operator", sub: "SpaceMouse", kind: "agent" },
        { id: "clf", x: 250, y: 20, w: 160, h: 56, label: "Reward classifier", sub: "success: 0 or 1", kind: "decision" },
        { id: "rl", x: 470, y: 20, w: 150, h: 56, label: "RL buffer", sub: "robot transitions", kind: "store" },
        { id: "demo", x: 470, y: 236, w: 150, h: 56, label: "Demo buffer", sub: "20–30 demos", kind: "store" },
        { id: "learner", x: 650, y: 122, w: 160, h: 56, label: "Learner", sub: "RLPD updates, GPU", kind: "agent" }
      ],
      edges: [
        { from: "robot", to: "clf", label: "transition", sides: ["t", "l"], via: [[105, 48]], labelAt: [178, 48] },
        { from: "clf", to: "rl", label: "+ reward" },
        { from: "human", to: "robot", label: "takes over", anchor: "start", dx: 8, dy: 4 },
        { from: "human", to: "demo", label: "corrections" },
        { from: "rl", to: "learner", label: "½ of batch", sides: ["r", "t"], via: [[730, 48]], labelAt: [676, 48] },
        { from: "demo", to: "learner", label: "½ of batch", sides: ["r", "b"], via: [[730, 264]], labelAt: [676, 264] },
        { from: "learner", to: "robot", label: "new weights θ", dashed: true }
      ],
      steps: [
        { on: ["robot"], text: "The actor runs a frozen copy of the policy at 10 Hz. Each action is a 6-D end-effector twist tracked by an impedance controller." },
        { on: ["robot>clf", "clf", "clf>rl", "rl"], text: "A classifier trained on about 200 success and 1000 failure frames labels each transition with reward 0 or 1. The transition enters the RL buffer." },
        { on: ["human", "human>robot", "human>demo", "demo"], text: "When the policy drifts, a human takes over with a SpaceMouse. Intervention steps go to both buffers, so they are sampled more often." },
        { on: ["rl>learner", "demo>learner", "learner"], text: "The learner samples half of each batch from each buffer, as in RLPD, and updates the critic and actor on one GPU." },
        { on: ["learner>robot", "robot"], text: "New weights reach the actor periodically. Interventions become rarer until the policy runs alone, typically after 1 to 2.5 hours." }
      ]
    },
    worked: {
      title: "Three targets for one insertion step",
      ref: "X2 eq. 12, 14, 16", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-ytd}{y_t} = \\class{sym-r}{r_t} + \\class{sym-gamma}{\\gamma}\\, \\class{sym-V}{V}(\\class{sym-s}{s_{t+1}}), \\qquad \\delta = \\class{sym-ytd}{y_t} - \\class{sym-Q}{Q}(\\class{sym-s}{s_t}, \\class{sym-a}{a_t})",
        words: "Every value method bootstraps: the target is the reward plus the discounted value of the next state. The methods differ in how they estimate that value.",
        key: ["ytd", "r", "gamma", "V", "s", "Q", "a", { glyph: "δ", meaning: "temporal-difference error" }] },
      figure: WE_FIG,
      steps: [
        { title: "The transition", text: "The peg is above the hole and the robot moves down. The classifier says not yet, so r = 0. Discount γ = 0.99." },
        { title: "DQN takes the max", text: "Three discrete next moves score 0.58, 0.81 and 0.66. DQN bootstraps from the best: y = 0.99 × 0.81 = 0.802." },
        { title: "DDPG asks the actor", text: "Continuous actions have no cheap max. DDPG scores the actor's own action, 0.74, so y = 0.99 × 0.74 = 0.733." },
        { title: "SAC: pessimism plus entropy", text: "Two critics say 0.78 and 0.72; keep 0.72. Add −α log π = 0.075: y = 0.99 × 0.795 = 0.787." },
        { title: "Regress toward the target", text: "The critic says Q(s, a) = 0.70 now. The error is 0.787 − 0.70 = 0.087; squared, 0.0076." },
        { title: "Success stops bootstrapping", text: "One step later the peg is in and the classifier fires: r = 1, the episode ends, so y = 1 exactly." }
      ]
    },
    ruleTitle: "From DQN to SAC, and PPO beside them",
    rules: [
      { name: "DQN: regress onto a Bellman target", ref: "X2 eq. 11–12", term: "td-target",
        tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{\\class{sym-D}{\\mathcal{D}}}\\big[(\\class{sym-ytd}{y_t} - \\class{sym-Q}{Q_\\theta}(\\class{sym-s}{s_t}, \\class{sym-a}{a_t}))^2\\big], \\quad \\class{sym-ytd}{y_t} = \\class{sym-r}{r_t} + \\class{sym-gamma}{\\gamma} \\max_{a'} \\class{sym-Qbar}{\\bar{Q}}(\\class{sym-s}{s_{t+1}}, a')",
        words: "Sample stored transitions and pull Q toward reward plus the discounted best next value. The max needs a small, discrete action set.",
        key: ["L", "E", "D", "ytd", "Q", "s", "a", "r", "gamma", "Qbar", { glyph: "a′", meaning: "candidate next action" }] },
      { name: "DDPG: an actor replaces the max", ref: "X2 eq. 13–14",
        before: "\\class{sym-ytd}{y_t} = \\class{sym-r}{r_t} + \\class{sym-gamma}{\\gamma} \\max_{a'} \\class{sym-Qbar}{\\bar{Q}}(\\class{sym-s}{s_{t+1}}, a')",
        tex: "\\class{sym-ytd}{y_t} = \\class{sym-r}{r_t} + \\class{sym-gamma}{\\gamma}\\, \\class{sb-chg}{\\class{sym-Qbar}{\\bar{Q}}\\big(\\class{sym-s}{s_{t+1}}, \\class{sb-new}{\\class{sym-pi}{\\pi_\\theta}(\\class{sym-s}{s_{t+1}})}\\big)}",
        words: "A deterministic actor proposes the next action, so continuous torques or twists work. The actor climbs the critic's action gradient.",
        key: ["ytd", "r", "gamma", "Qbar", "s", "pi"], diff: true, beforeLabel: "DQN", afterLabel: "DDPG" },
      { name: "SAC: stochastic actor, entropy bonus, two critics", ref: "X2 eq. 15–16 · arXiv 1801.01290", term: "maximum-entropy-rl",
        before: "\\class{sym-ytd}{y_t} = \\class{sym-r}{r_t} + \\class{sym-gamma}{\\gamma}\\, \\class{sym-Qbar}{\\bar{Q}}\\big(\\class{sym-s}{s_{t+1}}, \\class{sym-pi}{\\pi_\\theta}(\\class{sym-s}{s_{t+1}})\\big)",
        tex: "\\class{sym-ytd}{y_t} = \\class{sym-r}{r_t} + \\class{sym-gamma}{\\gamma}\\Big(\\class{sb-chg}{\\min_{i=1,2} \\class{sym-Qbar}{\\bar{Q}_i}(\\class{sym-s}{s_{t+1}}, a')} \\class{sb-new}{- \\class{sym-alpha-ent}{\\alpha} \\log \\class{sym-pi}{\\pi_\\theta}(a' \\mid \\class{sym-s}{s_{t+1}})}\\Big), \\quad \\class{sb-new}{a' \\sim \\class{sym-pi}{\\pi_\\theta}(\\cdot \\mid \\class{sym-s}{s_{t+1}})}",
        words: "Sample the next action, take the smaller of two critics to curb overestimation, and credit the policy's randomness.",
        key: ["ytd", "r", "gamma", "Qbar", "s", "alpha-ent", "pi", { glyph: "a′", meaning: "sampled next action" }], diff: true, beforeLabel: "DDPG", afterLabel: "SAC" },
      { name: "PPO: clipped surrogate objective", ref: "arXiv 1707.06347 · P09 §VII-A", term: "clipped-surrogate",
        tex: "\\class{sym-J}{J}^{\\mathrm{CLIP}}(\\theta) = \\class{sym-E}{\\mathbb{E}}_t\\Big[\\min\\big(\\class{sym-ratio}{\\rho_t}\\class{sym-adv}{\\hat{A}_t},\\ \\mathrm{clip}(\\class{sym-ratio}{\\rho_t}, 1 - \\class{sym-clip}{\\epsilon_{\\mathrm{clip}}}, 1 + \\class{sym-clip}{\\epsilon_{\\mathrm{clip}}})\\,\\class{sym-adv}{\\hat{A}_t}\\big)\\Big], \\quad \\class{sym-ratio}{\\rho_t} = \\frac{\\class{sym-pi}{\\pi_\\theta}(\\class{sym-a}{a_t} \\mid \\class{sym-s}{s_t})}{\\class{sym-pi}{\\pi_{\\theta_{\\mathrm{old}}}}(\\class{sym-a}{a_t} \\mid \\class{sym-s}{s_t})}",
        words: "Raise the probability of actions with positive advantage, but give no reward for moving the ratio beyond 1 ± ε. Data must be fresh.",
        key: ["J", "E", "ratio", "adv", "clip", "pi", "a", "s"] }
    ],
    algorithm: {
      title: "HIL-SERL, one training run", ref: "X2 §3.2.1 · arXiv 2410.21845", prov: "Condensed from the method card",
      lines: [
        '<span class="kw">input</span> 20–30 demonstrations → demo buffer <span data-sym="D">𝒟_demo</span>; empty RL buffer <span data-sym="D">𝒟_RL</span>',
        'train classifier c on ~200 success and ~1000 failure frames <span class="cm">// about 5 minutes of teleoperation</span>',
        '<span class="kw">actor</span>, at 10 Hz: <span data-sym="a">aₜ</span> ~ <span data-sym="pi">π_θ</span>(· | <span data-sym="o">oₜ</span>), or the human\'s action during an intervention',
        '    <span data-sym="r">rₜ</span> ← c(<span data-sym="o">oₜ₊₁</span>) ∈ {0, 1}; add the transition to <span data-sym="D">𝒟_RL</span>, and also to <span data-sym="D">𝒟_demo</span> if a human acted',
        '<span class="kw">learner</span>, in parallel: batch ← ½ from <span data-sym="D">𝒟_demo</span> + ½ from <span data-sym="D">𝒟_RL</span>',
        '    critic: minimize (<span data-sym="ytd">yₜ</span> − <span data-sym="Q">Q</span>)² ; actor: maximize <span data-sym="Q">Q</span> + <span data-sym="alpha-ent">α</span> · entropy ; gripper: DQN critic',
        '    every few seconds: send θ to the actor <span class="cm">// interventions fade as success rises</span>'
      ]
    },
    playgrounds: [
      {
        id: "maturity", title: "Maturity map filter", ref: "P07 §5, Tables 2–5, Fig. 4", prov: "Data: P07 tables",
        try: "Start with the sim-to-real recipe: zero-shot simulation, dense reward, on-policy. Compare locomotion with pick-and-place. Then choose the real-world recipe and see which manipulation rows light up.",
        mount: mountMaturity,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a3-maturity";
          return [
            { target: q("table"), title: "Read the map", text: "Each row is a group of papers P07 reviewed. Each cell counts papers with that attribute; darker means a larger share of the row." },
            { target: q("#" + id + "-clear"), title: "Start from nothing", text: "Clear the filter first. Then no row has a match count.", do: function (a) { return a.click(q("#" + id + "-clear")); }, task: "Press Clear", expect: function () { return api.sel() === ""; } },
            { target: q("#" + id + "-sim"), title: "The sim-to-real recipe", text: "Zero-shot simulation, dense reward and on-policy RL (PPO). 35 of 41 locomotion papers match; pick-and-place has none.", do: function (a) { return a.click(q("#" + id + "-sim")); }, task: "Press Sim-to-real recipe", expect: function () { return api.sel() === "dense,on,zs"; } },
            { target: q("#" + id + "-real"), title: "The real-world recipe", text: "No simulator, off-policy RL and expert data. Assembly lights up: Residual RL, DDPGfD and Luo et al.'s industrial insertion.", do: function (a) { return a.click(q("#" + id + "-real")); }, task: "Press Real-world recipe", expect: function () { return api.sel() === "expert,ns,off"; } },
            { target: q("#" + id + "-chips"), title: "Your turn", text: "Toggle single attributes. In-hand manipulation behaves like locomotion; which rows use sparse rewards? P07 §5 ties mature results to the first recipe." }
          ];
        }
      },
      {
        id: "hil", title: "Demos, interventions and a fallible reward", ref: "X2 §3.2 · arXiv 2410.21845", prov: "Simplified: tabular toy",
        try: "Set demonstrations to 0: sparse reward is never found. Restore 20: only fixture A is solved. Tick Human interventions, then raise classifier false positives and compare the two curves.",
        mount: mountHil,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a3-hil";
          return [
            { target: q("#" + id + "-demos"), title: "No prior data", text: "With a sparse reward and random exploration, the robot almost never finds the hole in 60 episodes, so nothing is learned.", do: function (a) { return a.set(q("#" + id + "-demos"), 0); }, task: "Set demonstrations to 0", expect: function () { return api.opt().demos === 0; } },
            { target: q("#" + id + "-demos"), title: "Seed the buffer", text: "Twenty demonstrations, all with fixture A. Half of every batch comes from them, so value spreads fast, but only around fixture A.", do: function (a) { return a.set(q("#" + id + "-demos"), 20); }, task: "Set demonstrations to 20", expect: function () { return api.opt().demos >= 15; } },
            { target: q("#" + id + "-view"), title: "Fixture B is dark", text: "Switch the map to fixture B. No demonstration covered it, so its values stay near zero.", do: function (a) { return a.click(q("#" + id + '-view [value="1"]')); }, task: "Show fixture B", expect: function () { return api.opt().view === 1; } },
            { target: q("#" + id + "-human"), title: "Let the human step in", text: "After four steps without progress, a human drives for five steps. Those corrections cover fixture B, and success approaches 100%.", do: function (a) { return a.click(q("#" + id + "-human")); }, task: "Tick Human interventions", expect: function () { return api.opt().human; } },
            { target: q("#" + id + "-fp"), title: "A classifier that errs", text: "The classifier now fires sometimes when the peg only rests beside the hole. Watch the dashed curve stay above the true one.", do: function (a) { return a.set(q("#" + id + "-fp"), 0.4); }, task: "Raise false positives to 30% or more", expect: function () { return api.opt().fp >= 0.3; } },
            { target: q("#" + id + "-utd"), title: "Your turn", text: "Change updates per step. RLPD and SERL raise this update-to-data ratio to squeeze more learning from each real transition." }
          ];
        }
      },
      {
        id: "ppo", title: "What PPO's clip does to one update", ref: "arXiv 1707.06347 · P09 §VII-A.1", prov: "Illustrative toy",
        try: "Raise the epochs on one batch to 30: the unclipped ratio runs away, the clipped one stalls near 1 + ε. Then shrink ε_clip and flip the advantage sign in the left chart.",
        mount: mountPpo,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "a3-ppo";
          return [
            { target: q("[data-c1]"), title: "A flat top", text: "For a positive advantage, the objective grows with the ratio until 1 + ε, then goes flat. Flat means zero gradient: no further push." },
            { target: q("#" + id + "-k"), title: "Many epochs, one batch", text: "PPO reuses each on-policy batch for several epochs. Without the clip, repeated steps move the policy far from the one that collected the data.", do: function (a) { return a.set(q("#" + id + "-k"), 30); }, task: "Set epochs to 25 or more", expect: function () { return api.get().K >= 25; } },
            { target: q("#" + id + "-eps"), title: "A tighter trust region", text: "A smaller ε_clip stops the ratio sooner. PPO's MuJoCo study found ε = 0.2 best of 0.1, 0.2 and 0.3.", do: function (a) { return a.set(q("#" + id + "-eps"), 0.1); }, task: "Set ε_clip to 0.1", expect: function () { return api.get().eps <= 0.1001; } },
            { target: q("#" + id + "-sign"), title: "Your turn", text: "Flip to a negative advantage: now the floor is at 1 − ε. The clip is pessimistic in both directions." }
          ];
        }
      }
    ],
    methods: ["dqn", "ddpg", "sac", "ppo", "qt-opt", "rlpd", "serl", "hil-serl", "residual-rl", "daydreamer"],
    open: [
      { title: "Stable and sample-efficient algorithms", text: "On-policy methods are robust but data-hungry; off-policy and offline data are cheaper but less stable under distribution shift.", refs: "P07 §5" },
      { title: "Automated real-world learning", text: "Real-world RL needs automatic resets and safe exploration. Today human help is the only alternative for both.", refs: "P07 §5 · X2 §3.2" },
      { title: "Rewards without gaming", text: "Shaped dense rewards invite specification gaming; sparse ones learn slowly; learned success classifiers can be fooled.", refs: "X2 §3.2.2 · arXiv 2502.05450" },
      { title: "Benchmarking real-world success", text: "Levels are judged from each paper's own experiments. Standard, reproducible real-world evaluation protocols are still missing.", refs: "P07 §5" }
    ],
    takeaways: [
      "DQN learns Q from replayed transitions; DDPG adds an actor for continuous actions; SAC makes the actor stochastic and rewards entropy.",
      "PPO is on-policy and clips each update; with cheap parallel simulation it is the default for sim-to-real training.",
      "P07 finds the most mature results follow zero-shot sim-to-real with dense rewards and on-policy RL, mostly in locomotion.",
      "Real-world manipulation uses off-policy RL with prior data: RLPD samples half of each batch from demonstrations.",
      "HIL-SERL adds a reward classifier and human corrections, reaching 100% average success on its real tasks."
    ],
    quiz: [
      { q: "Why did DDPG replace DQN's max over next actions with an actor network?", options: ["The max is intractable over continuous actions", "The actor makes rewards denser", "The max needs a simulator", "It removes the replay buffer"], correct: 0, why: "With continuous torques or twists there is no cheap max over actions, so a deterministic actor proposes the action instead (X2 eq. 13–14)." },
      { q: "In PPO, the advantage is positive and ρ is already above 1 + ε. What does that sample contribute?", options: ["A larger gradient", "Zero gradient", "A negative gradient", "It is resampled"], correct: 1, why: "The min picks the clipped branch, which is constant in θ, so the sample stops pushing the policy (arXiv 1707.06347)." },
      { q: "In HIL-SERL, where are transitions from human interventions stored?", options: ["Nowhere; they are discarded", "Only in the RL buffer", "In both the demo and RL buffers", "Only in the classifier's data"], correct: 2, why: "Interventions go to both buffers; autonomous transitions go to the RL buffer only, so corrections are sampled more often (X2 §3.2)." },
      { q: "According to P07, which recipe do most mature (L3–L4) RL solutions follow?", options: ["Real-world training with sparse rewards", "Zero-shot sim-to-real with dense rewards", "Offline RL on web videos", "Model-based planning only"], correct: 1, why: "P07 §5: mature solutions often follow zero-shot sim-to-real, with dense shaped rewards and on-policy algorithms, especially in locomotion." },
      { q: "What did HIL-SERL achieve without demonstrations and without interventions?", options: ["0% success", "49% success", "100% success", "Same as with both"], correct: 0, why: "Its ablation (Table 1b) reports 0% on RAM insertion, dashboard assembly and object flipping without either ingredient." }
    ],
    cards: [
      { front: "Write the DQN temporal-difference target.", back: "y = r + γ max over a′ of Q̄(s′, a′), with Q̄ a slowly updated copy of the critic.", ref: "X2 eq. 12" },
      { front: "What three things did SAC change about DDPG?", back: "A stochastic Gaussian actor, an entropy bonus weighted by α, and the minimum of two critics in the target.", ref: "arXiv 1801.01290" },
      { front: "Why is PPO common in simulation but not on real robots?", back: "It is on-policy: each update needs fresh data. Cheap in parallel simulation, too slow on hardware.", ref: "P09 §VII-A.1" },
      { front: "What is RLPD's symmetric sampling?", back: "Each batch takes half its transitions from prior data and half from online data, with no offline pre-training.", ref: "X2 §3.2 · arXiv 2302.02948" },
      { front: "What does SERL add around RLPD?", back: "Reward classifiers, forward-backward reset-free training, an impedance controller with clipped references, and relative frames.", ref: "arXiv 2401.16013" },
      { front: "Name P07's six levels of real-world success.", back: "L0 simulation only, L1 limited lab, L2 diverse lab, L3 confined real world, L4 diverse real world, L5 commercial product.", ref: "P07 §3.4" },
      { front: "What reward does QT-Opt use for grasping?", back: "+1 for a successful lift, 0 otherwise, minus 0.05 per time step.", ref: "arXiv 1806.10293" }
    ],
    terms: {
      "discounted-return": { name: "discounted return", aliases: ["return", "cumulative discounted reward"], group: "learning", sym: "γ", symTex: "\\gamma", def: "The sum of rewards along a trajectory, each weighted by γ to the power of its time step; RL maximizes its expectation.", note: "The effective horizon is about 1/(1 − γ) steps, so γ = 0.99 looks about 100 steps ahead.", ref: "X2 §3.1", scene: "system", focus: ["reward-model", "policy-update"], look: "rewards flowing into the update", uses: [] },
      "q-function": { name: "action-value function", aliases: ["Q-function", "Q-value", "critic"], group: "learning", sym: "Q", symTex: "Q", def: "The expected discounted return after taking action a in state s and then following the policy.", note: "V(s) averages Q over the policy's actions; the critic in actor-critic methods is a learned Q.", ref: "X2 eq. 9–10", scene: "system", focus: ["policy-update"], look: "the critic inside the learner", uses: ["discounted-return"] },
      "td-target": { name: "temporal-difference target", aliases: ["TD target", "Bellman target", "bootstrapped target"], group: "learning", sym: "yₜ", symTex: "y_t", def: "The regression target r + γ times the estimated value of the next state; the TD error is the target minus the current Q.", note: "The next-state value comes from a slowly updated target copy of the critic, which keeps the target from chasing itself.", ref: "X2 eq. 11–12", scene: "system", focus: ["policy-update", "replay-buffer"], look: "targets computed from stored transitions", uses: ["q-function"] },
      "replay-buffer": { name: "replay buffer", aliases: ["experience replay"], group: "learning", sym: "𝒟", symTex: "\\mathcal{D}", def: "A memory of past transitions (s, a, r, s′) that an off-policy learner samples again and again; it can also hold demonstrations.", note: "Reuse is what makes off-policy RL sample-efficient enough for real robots.", ref: "X2 §3.2", scene: "system", focus: ["replay-buffer"], look: "the buffer of stored transitions", uses: ["off-policy-rl"] },
      "off-policy-rl": { name: "off-policy RL", aliases: ["off-policy"], group: "learning", def: "RL that updates the policy with transitions collected by the current policy and by other or earlier policies. Examples: SAC, DQN.", note: "More sample-efficient than on-policy RL, but less stable when the data drift from the current policy.", ref: "P07 App. A.2.4", scene: "system", focus: ["replay-buffer", "policy-update"], look: "old data feeding the update", uses: ["replay-buffer"] },
      "on-policy-rl": { name: "on-policy RL", aliases: ["on-policy"], group: "learning", def: "RL that updates the policy only with transitions collected by the current policy. Examples: PPO, TRPO.", note: "Robust to hyperparameters but data-hungry, which is why it lives in parallel simulators.", ref: "P07 App. A.2.4", scene: "system", focus: ["simulator", "policy-update"], look: "fresh simulator rollouts feeding the update", uses: [] },
      "maximum-entropy-rl": { name: "maximum-entropy RL", aliases: ["MaxEnt RL", "soft actor-critic objective"], group: "learning", sym: "α", symTex: "\\alpha", def: "RL whose objective adds α times the entropy of the policy to the reward, so the agent acts as randomly as it can while succeeding.", note: "SAC is sensitive to reward scale, which acts like an inverse temperature; later versions tune α automatically.", ref: "X2 eq. 15", scene: "system", focus: ["action-head", "policy-update"], look: "a spread-out action distribution", uses: ["q-function"] },
      "clipped-surrogate": { name: "clipped surrogate objective", aliases: ["PPO clip", "L^CLIP"], group: "learning", sym: "ρₜ", symTex: "\\rho_t", def: "PPO's objective: the minimum of ratio times advantage and the clipped ratio times advantage, which removes any incentive to move the ratio outside 1 ± ε.", note: "It is a pessimistic bound, not a hard constraint: the ratio can still overshoot slightly.", ref: "arXiv 1707.06347", scene: "system", focus: ["policy-update"], look: "the policy update step", uses: ["on-policy-rl"] },
      "symmetric-sampling": { name: "symmetric sampling", aliases: ["50/50 sampling", "RLPD sampling"], group: "learning", def: "Building each training batch from equal halves of prior (offline or demonstration) data and online data, as in RLPD.", note: "RLPD pairs it with LayerNorm critics and a high update-to-data ratio; seeding one buffer with demos worked worse.", ref: "X2 §3.2 · arXiv 2302.02948", scene: "system", focus: ["replay-buffer", "human-teleop"], look: "two buffers feeding one batch", uses: ["replay-buffer"] },
      "reward-classifier": { name: "reward classifier", aliases: ["success classifier", "learned reward"], group: "learning", def: "A binary classifier on camera images, trained on success and failure examples, whose output replaces a hand-designed reward.", note: "Its false positives are rewarded like real successes, so HIL-SERL trains it to over 95% accuracy.", ref: "X2 §3.2", scene: "system", focus: ["reward-model", "camera-image"], look: "the camera image entering the reward model", uses: [] },
      "human-intervention": { name: "human intervention", aliases: ["human-in-the-loop correction", "HIL"], group: "learning", def: "During training, a human takes control with a teleoperation device when the policy fails and supplies corrective actions.", note: "Long interventions that always end in success can cause value overestimation, the HIL-SERL authors warn.", ref: "X2 §3.2, Fig. 16", scene: "system", focus: ["human-teleop", "replay-buffer"], look: "the operator's device", uses: ["replay-buffer"] },
      "zero-shot-sim-to-real": { name: "zero-shot sim-to-real", aliases: ["zero-shot sim2real"], group: "learning", def: "Training performed entirely in a simulator, with the policy deployed in the real world without additional learning.", note: "Few-shot sim-to-real adds limited real-world fine-tuning after simulation.", ref: "P07 App. A.2.1", scene: "system", focus: ["simulator", "robot"], look: "from simulator straight to robot", uses: ["on-policy-rl"] },
      "level-of-real-world-success": { name: "level of real-world success", aliases: ["maturity level", "L0–L5"], group: "eval", def: "P07's six-level scale of where a method was validated: simulation only, limited lab, diverse lab, confined real world, diverse real world, commercial product.", note: "Levels come from each paper's reported experiments, so the grading can be subjective.", ref: "P07 §3.4", scene: "system", focus: ["robot"], look: "the deployed robot", uses: [] },
      "residual-rl": { name: "residual RL", aliases: ["residual reinforcement learning", "residual policy"], group: "learning", def: "A learned policy whose output is added to a hand-designed controller's command; RL learns only the correction.", note: "Exploration noise is applied to the residual only, which keeps early real-world training safer.", ref: "arXiv 1812.03201 · P07 §4.3.2", scene: "system", focus: ["controller", "action-head"], look: "correction added before the controller", uses: [] }
    },
    symbols: [
      { id: "ytd", tex: "y_t", glyph: "yₜ", kind: "Functions", meaning: "temporal-difference target: reward plus discounted value of the next state", short: "TD target", first: "a3", read: "y sub t", papers: "X2 eq. 11–16: y_i · DDPG: y_i · QT-Opt: Q_T" },
      { id: "Qbar", tex: "\\bar{Q}", glyph: "Q̄", kind: "Functions", meaning: "target critic: a slowly updated copy of Q used inside the TD target", short: "target critic", first: "a3", read: "Q bar", papers: "DQN 2013: Q(·; θ_{i−1}) · DDPG: Q′ · SAC: V_ψ̄ · HIL-SERL: Q̄_φ" },
      { id: "alpha-ent", tex: "\\alpha", glyph: "α", kind: "Parameters", meaning: "entropy temperature: weight on the policy's entropy in maximum-entropy RL", short: "entropy temperature", first: "a3", read: "alpha", papers: "X2 eq. 15–16, SAC, RLPD: α" },
      { id: "clip", tex: "\\epsilon_{\\mathrm{clip}}", glyph: "ε_clip", kind: "Parameters", meaning: "PPO clip range: how far the probability ratio may move from 1 per update", short: "PPO clip range", first: "a3", read: "epsilon clip", papers: "PPO paper: ε (0.2) · house ε is Gaussian noise" }
    ],
    ledger: [
      { where: "Topic 03 · maturity map", source: "P07 Table 5 prints the locomotion row as two unlabeled groups", page: "Read as off-policy (refs 32, 36, 48, 53, 54, 68) and on-policy (the rest)", why: "Both groups together cover all 41 locomotion papers; 53–54 train on real robots without simulators.", kind: "Our choice" },
      { where: "Topic 03 · maturity map", source: "P07 Fig. 4 places refs 109, 118 and 122 in two manipulation sub-problems", page: "Counted in both rows", why: "The rows follow P07's own grouping.", kind: "Simplified" },
      { where: "Topic 03 · maturity map", source: "P07 colors each paper by level only in its figures", page: "The map filters by attributes, not by level", why: "Per-paper levels are not in the text tables we could read.", kind: "Simplified" },
      { where: "Topic 03 · DDPG rule", source: "X2 eq. 13–14 write the deterministic actor as μ_ϕ", page: "The site writes π_θ", why: "μ is the friction coefficient in house notation.", kind: "Our choice" },
      { where: "Topic 03 · target critic", source: "DQN 2013 bootstraps from previous-iteration weights θ_{i−1}; DDPG and SAC use soft-updated copies", page: "One symbol Q̄ for all of them", why: "Same role: a slowly changing critic inside the target.", kind: "Our choice" },
      { where: "Topic 03 · reward classifier", source: "SERL and X2 §3.2 use r = log c(e⁺ | s); HIL-SERL uses a binary 0/1 reward", page: "The site shows the binary form in the loop", why: "HIL-SERL is the system traced here.", kind: "Sources disagree" },
      { where: "Topic 03 · HIL-SERL results", source: "X2 §3.2 says 99%+ within 1–2 hours; the method card reports 100% average over 100 trials, 1–2.5 hours (6 hours for timing belt)", page: "The site quotes the paper's 100% and 1–2.5 hours", why: "The method paper is the primary source.", kind: "Sources disagree" },
      { where: "Topic 03 · playground 2", source: "HIL-SERL trains neural actor-critics from images", page: "A tabular Q-learner on a 12 × 7 grid", why: "Shows the effect of demos, interventions and classifier errors alone.", kind: "Simplified" }
    ]
  });
})();
