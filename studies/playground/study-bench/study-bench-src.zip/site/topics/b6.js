/* Topic 10 · In-context learning. Sources: X4 §2–3 (framing, eqs. 1–9, 13, 17–18), §4.2, §5, §7–8; method papers
   (TecNets, T-OSIL, MOSAIC, VINN, ICRT, KAT, Instant Policy, RoboPrompt, REGENT, RICL, BPC, MatchingPolicy, DemoDiffusion, IMOP). */
(function () {
  "use strict";
  var RB = window.RB;
  var mono = function () { return getComputedStyle(document.body).getPropertyValue("--font-mono"); };
  var bodyF = function () { return getComputedStyle(document.body).getPropertyValue("--font-body"); };
  /* StudyBench.segmented calls onChange(value, button); read the button's value as b5 does */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function pct(v) { return Math.round(v * 100) + "%"; }

  /* ================= playground 1: retrieve stored actions (X4 eq. 5) vs blending with a generator ================= */
  /* A 2-D toy: states are gripper positions, actions are recorded displacements. Four scripted demonstrations go around
     an obstacle, two above and two below. The "generator" stands in for prior competence: it heads straight to the goal. */
  var OB = { x: 5, y: 3, r: 0.9 }, GOAL = { x: 9.2, y: 3 }, STEP = 0.35;
  var STARTS = [{ x: 0.9, y: 3.0 }, { x: 0.9, y: 3.3 }, { x: 2.0, y: 5.4 }, { x: 3.0, y: 0.4 }];
  function demoPath(y0, side, bulge) { return [[0.8, y0], [3.0, 3 + side * 0.9], [5, 3 + side * bulge], [7, 3 + side * 0.9], [GOAL.x, GOAL.y]]; }
  var DEMOS = [demoPath(3.35, 1, 1.55), demoPath(3.1, 1, 1.8), demoPath(2.9, -1, 1.55), demoPath(2.6, -1, 1.8)];
  function resample(pts) {
    var segs = [], tot = 0, out = [], i;
    for (i = 1; i < pts.length; i++) { var L = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); segs.push(L); tot += L; }
    var n = Math.round(tot / STEP);
    for (var k = 0; k <= n; k++) {
      var s = k * tot / n, j = 0;
      while (j < segs.length - 1 && s > segs[j]) { s -= segs[j]; j++; }
      var f = Math.min(1, s / segs[j]);
      out.push([pts[j][0] + f * (pts[j + 1][0] - pts[j][0]), pts[j][1] + f * (pts[j + 1][1] - pts[j][1])]);
    }
    return out;
  }
  var REC = [];
  DEMOS.forEach(function (p, di) { var s = resample(p); for (var i = 0; i < s.length - 1; i++) REC.push({ x: s[i][0], y: s[i][1], ax: s[i + 1][0] - s[i][0], ay: s[i + 1][1] - s[i][1], demo: di }); });
  function retrieve(q) { return REC.map(function (r) { return { r: r, d: Math.hypot(r.x - q.x, r.y - q.y) }; }).sort(function (a, b) { return a.d - b.d; }); }
  function policy(q, o) {
    var ds = retrieve(q), nn = ds[0];
    if (o.mode === "nn") return { ax: nn.r.ax, ay: nn.r.ay, d: nn.d, sel: [{ r: nn.r, w: 1 }], wn: 1 };
    if (o.mode === "knn") {
      var sel = ds.slice(0, o.k), w = sel.map(function (e) { return Math.exp(-e.d / o.sigma); }), S = w.reduce(function (a, b) { return a + b; }, 0), ax = 0, ay = 0;
      sel.forEach(function (e, i) { ax += w[i] / S * e.r.ax; ay += w[i] / S * e.r.ay; });
      return { ax: ax, ay: ay, d: nn.d, sel: sel.map(function (e, i) { return { r: e.r, w: w[i] / S }; }), wn: w[0] / S };
    }
    var gx = GOAL.x - q.x, gy = GOAL.y - q.y, gl = Math.hypot(gx, gy) || 1, b = Math.exp(-o.lam * nn.d);
    return { ax: b * nn.r.ax + (1 - b) * STEP * gx / gl, ay: b * nn.r.ay + (1 - b) * STEP * gy / gl, d: nn.d, sel: [{ r: nn.r, w: b }], wn: b, gen: { ax: STEP * gx / gl, ay: STEP * gy / gl } };
  }
  function rollout(q0, o) {
    var q = { x: q0.x, y: q0.y }, path = [[q.x, q.y]];
    for (var t = 0; t < 70; t++) {
      var a = policy(q, o);
      if (Math.hypot(a.ax, a.ay) < 0.03) return { out: "stalled", path: path };
      q = { x: q.x + a.ax, y: q.y + a.ay }; path.push([q.x, q.y]);
      if (Math.hypot(q.x - OB.x, q.y - OB.y) < OB.r) return { out: "collision", path: path };
      if (Math.hypot(q.x - GOAL.x, q.y - GOAL.y) < 0.4) return { out: "goal", path: path };
      if (q.x < -0.5 || q.x > 10.5 || q.y < -0.5 || q.y > 6.5) break;
    }
    return { out: "missed", path: path };
  }

  function mountRetrieve(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Action rule", value: "knn", options: [{ value: "nn", label: "Replay" }, { value: "knn", label: "Mixture" }, { value: "blend", label: "Blend" }] }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-next">Next start ▶</button></div>' +
      '<div class="rb-row">' + RB.slider({ id: id + "-k", label: "Records k", min: 1, max: 12, step: 1, value: 5 }) +
      RB.slider({ id: id + "-s", label: "Kernel width σ", min: 0.05, max: 1, step: 0.05, value: 0.3, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-l", label: "Blend sharpness λ", min: 0.25, max: 4, step: 0.25, value: 1, fmt: function (v) { return (+v).toFixed(2); } }) + "</div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Top-down toy workspace: an obstacle in the middle, a goal on the right, recorded demonstration actions as short arrows, and the rollout path from the start square"></canvas>' +
      '<figcaption class="sb-caption">Short arrows are recorded actions from four demonstrations. Thick arrows are the records the rule reads now. The line is the closed-loop rollout from the square. Click to move the start.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "d", k: "Distance to nearest record" }, { id: "wn", k: "Weight on nearest record" }, { id: "used", k: "Records read" }, { id: "out", k: "Rollout" }]) +
      RB.legend([{ c: "data-1", label: "demos above the obstacle", kind: "line" }, { c: "data-2", label: "demos below", kind: "line" }, { c: "accent", label: "rollout and action now", kind: "line" }, { c: "data-4", label: "generator's proposal", kind: "dash" }]) +
      '<p class="sb-caption" data-note></p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 560, H = 344, S = 54, OX = 10, OY = 10;
    var o = { mode: "knn", k: 5, sigma: 0.3, lam: 1 }, si = 0, start = { x: STARTS[0].x, y: STARTS[0].y }, res = null, now = null;
    var NOTES = {
      nn: "Replay: one record, weight one. It copies the recorded displacement, so a start off the demonstrations stays offset (X4 eq. 5, nearest-neighbor case).",
      knn: "Mixture: weights β fall with distance and sum to one. Averaging works only if the records' actions are compatible; an above and a below record cancel sideways.",
      blend: "Blend: near a record, play its action; farther away, trust the generator (REGENT, RICL). This generator knows the goal but not the taught detour."
    };
    var X = function (x) { return OX + x * S; }, Y = function (y) { return OY + (6 - y) * S; };
    function run() {
      res = rollout(start, o); now = policy(start, o);
      RB.setRO(body, "d", RB.fmt(now.d, 2));
      RB.setRO(body, "wn", RB.fmt(now.wn, 2));
      RB.setRO(body, "used", o.mode === "knn" ? String(o.k) : "1");
      RB.setRO(body, "out", res.out);
      note.textContent = NOTES[o.mode];
      draw();
    }
    function arrow(c, x0, y0, dx, dy, col, lw, dash) {
      var x1 = X(x0 + dx), y1 = Y(y0 + dy), ang = Math.atan2(y1 - Y(y0), x1 - X(x0));
      c.strokeStyle = col; c.fillStyle = col; c.lineWidth = lw; c.setLineDash(dash || []);
      c.beginPath(); c.moveTo(X(x0), Y(y0)); c.lineTo(x1, y1); c.stroke(); c.setLineDash([]);
      c.beginPath(); c.moveTo(x1, y1); c.lineTo(x1 - 6 * Math.cos(ang - 0.45), y1 - 6 * Math.sin(ang - 0.45)); c.lineTo(x1 - 6 * Math.cos(ang + 0.45), y1 - 6 * Math.sin(ang + 0.45)); c.closePath(); c.fill();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), fm = mono();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P.line; c.lineWidth = 1; c.strokeRect(X(0), Y(6), 10 * S, 6 * S);
      c.fillStyle = P["bad-soft"] || P["surface-strong"]; c.strokeStyle = P.bad; c.lineWidth = 1.5; c.beginPath(); c.arc(X(OB.x), Y(OB.y), OB.r * S, 0, Math.PI * 2); c.fill(); c.stroke();
      c.fillStyle = P["ink-2"]; c.font = "500 12px " + fm; c.textAlign = "center"; c.fillText("obstacle", X(OB.x), Y(OB.y) + 4);
      c.strokeStyle = P.good || P.ink; c.lineWidth = 2; c.beginPath(); c.arc(X(GOAL.x), Y(GOAL.y), 0.4 * S, 0, Math.PI * 2); c.stroke(); c.fillStyle = P["ink-2"]; c.fillText("goal", X(GOAL.x), Y(GOAL.y) - 0.4 * S - 6);
      REC.forEach(function (r) { arrow(c, r.x, r.y, r.ax * 0.8, r.ay * 0.8, P[r.demo < 2 ? "data-1" : "data-2"], 1, null); });
      c.globalAlpha = 1;
      now.sel.forEach(function (e) { arrow(c, e.r.x, e.r.y, e.r.ax, e.r.ay, P[e.r.demo < 2 ? "data-1" : "data-2"], 1 + 5 * e.w, null); c.strokeStyle = P["ink-3"]; c.lineWidth = 1; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(X(start.x), Y(start.y)); c.lineTo(X(e.r.x), Y(e.r.y)); c.stroke(); c.setLineDash([]); });
      c.strokeStyle = P.accent; c.lineWidth = 2.5; c.beginPath(); res.path.forEach(function (p, i) { if (i) c.lineTo(X(p[0]), Y(p[1])); else c.moveTo(X(p[0]), Y(p[1])); }); c.stroke();
      var last = res.path[res.path.length - 1];
      if (res.out === "collision") { c.strokeStyle = P.bad; c.lineWidth = 2.5; c.beginPath(); c.moveTo(X(last[0]) - 6, Y(last[1]) - 6); c.lineTo(X(last[0]) + 6, Y(last[1]) + 6); c.moveTo(X(last[0]) + 6, Y(last[1]) - 6); c.lineTo(X(last[0]) - 6, Y(last[1]) + 6); c.stroke(); }
      if (now.gen) arrow(c, start.x, start.y, now.gen.ax * 2.2, now.gen.ay * 2.2, P["data-4"], 2, [4, 3]);
      arrow(c, start.x, start.y, now.ax * 2.2, now.ay * 2.2, P.accent, 3, null);
      c.fillStyle = P.ink; c.fillRect(X(start.x) - 6, Y(start.y) - 6, 12, 12);
      c.textAlign = "left"; c.fillStyle = P["ink-2"]; c.font = "500 12px " + fm; c.fillText("start", X(start.x) + 9, Y(start.y) - 8);
    }
    bindSeg(body, id + "-mode", function (v) { o.mode = v; run(); });
    RB.bindSlider(body, id + "-k", null, function (v) { o.k = v; run(); });
    RB.bindSlider(body, id + "-s", function (v) { return (+v).toFixed(2); }, function (v) { o.sigma = v; run(); });
    RB.bindSlider(body, id + "-l", function (v) { return (+v).toFixed(2); }, function (v) { o.lam = v; run(); });
    body.querySelector("#" + id + "-next").addEventListener("click", function () { si = (si + 1) % STARTS.length; start = { x: STARTS[si].x, y: STARTS[si].y }; run(); });
    cv.addEventListener("click", function (e) { var b = cv.getBoundingClientRect(), sx = W / b.width; var x = ((e.clientX - b.left) * sx - OX) / S, y = 6 - ((e.clientY - b.top) * sx - OY) / S; x = RB.clamp(x, 0.2, 9.8); y = RB.clamp(y, 0.2, 5.8); if (Math.hypot(x - OB.x, y - OB.y) < OB.r + 0.1) return; start = { x: x, y: y }; si = -1; run(); });
    run();
    RB.onTheme(draw);
    return { state: function () { return { mode: o.mode, k: o.k, sigma: o.sigma, lam: o.lam, out: res.out, start: si }; } };
  }

  /* ================= playground 2: attention over demonstration elements (X4 eq. 6) ================= */
  /* Each demonstration element and each robot step is described by (height, gripper open, near an object). "History"
     adds a counter of gripper events so far. Score s = −(squared feature distance + history term); α = softmax(s / τ). */
  var DEMO_EL = [
    { n: "start", h: 0.8, g: 1, o: 0, c: 0 }, { n: "reach", h: 0.5, g: 1, o: 0, c: 0 }, { n: "at cup", h: 0.2, g: 1, o: 1, c: 0 }, { n: "grasp", h: 0.2, g: 0, o: 1, c: 1 },
    { n: "lift", h: 0.6, g: 0, o: 0, c: 1 }, { n: "carry", h: 0.65, g: 0, o: 0, c: 1 }, { n: "release", h: 0.3, g: 1, o: 1, c: 2 }, { n: "retreat", h: 0.8, g: 1, o: 0, c: 2 }
  ];
  var QPH = [0, 1, 1, 2, 3, 4, 5, 5, 6, 7, 7, 7];
  var QH = [0.75, 0.55, 0.45, 0.22, 0.21, 0.55, 0.62, 0.66, 0.32, 0.7, 0.78, 0.82];
  var QSTEP = QPH.map(function (ph, t) { var e = DEMO_EL[ph]; return { ph: ph, h: QH[t], g: e.g, o: e.o, c: e.c }; });
  function attend(q, mode, tau) {
    var s = DEMO_EL.map(function (e) { var d = Math.pow(q.h - e.h, 2) + Math.pow(q.g - e.g, 2) + Math.pow(q.o - e.o, 2); if (mode === "hist") d += 0.5 * Math.pow(q.c - e.c, 2); return -d / tau; });
    var m = Math.max.apply(null, s), ex = s.map(function (v) { return Math.exp(v - m); }), Z = ex.reduce(function (a, b) { return a + b; }, 0);
    return ex.map(function (v) { return v / Z; });
  }

  function mountAttention(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "The score reads", value: "frame", options: [{ value: "frame", label: "Current frame" }, { value: "hist", label: "With history" }] }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-play">Play steps ▶</button></div>' +
      '<div class="rb-row">' + RB.slider({ id: id + "-tau", label: "Temperature τ", min: 0.02, max: 0.5, step: 0.02, value: 0.06, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-t", label: "Robot step t", min: 1, max: 12, step: 1, value: 4 }) + "</div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Heat map of attention weights: rows are the robot\'s 12 steps, columns are the 8 demonstration elements"></canvas>' +
      '<figcaption class="sb-caption">Each row sums to one: how much step t reads each demonstration element. Outlined cells mark the matching phase; dots mark where the policy reads most.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "ph", k: "Robot's phase at step t" }, { id: "top", k: "Most-read element" }, { id: "wok", k: "Weight on the matching element" }, { id: "bad", k: "Steps reading a wrong element" }]) +
      RB.legend([{ c: "accent", label: "attention weight αₜᵢ", kind: "area" }, { c: "ink", label: "matching phase", kind: "line" }]) +
      '<p class="sb-caption" data-note></p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 560, H = 360;
    var mode = "frame", tau = 0.06, t = 4, A = [], bad = 0, timer = null;
    function compute() {
      A = QSTEP.map(function (q) { return attend(q, mode, tau); }); bad = 0;
      A.forEach(function (row, i) { var b = 0; row.forEach(function (v, j) { if (v > row[b]) b = j; }); if (b !== QSTEP[i].ph) bad++; });
      var row = A[t - 1], top = 0; row.forEach(function (v, j) { if (v > row[top]) top = j; });
      RB.setRO(body, "ph", DEMO_EL[QSTEP[t - 1].ph].n); RB.setRO(body, "top", DEMO_EL[top].n); RB.setRO(body, "wok", RB.fmt(row[QSTEP[t - 1].ph], 2)); RB.setRO(body, "bad", bad + " of 12");
      note.textContent = mode === "frame" ? "Frame only: “start” and “retreat” look the same, and so do “at cup” and “release”. The read splits between them." : "With history: a count of gripper events so far separates look-alike phases, so the read follows execution progress.";
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), fm = mono(), fb = bodyF(), L = 118, T = 58, cw = (W - L - 8) / 8, rh = 23;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.font = "600 12px " + fb; c.fillStyle = P["ink-2"]; c.textAlign = "left"; c.fillText("robot step", 8, T - 8);
      c.textAlign = "center"; c.fillText("demonstration element i", L + 4 * cw, 14);
      DEMO_EL.forEach(function (e, j) { c.font = "500 11px " + fm; c.fillStyle = P.ink; c.fillText(e.n, L + (j + 0.5) * cw, 34); c.fillStyle = P["ink-3"]; c.fillText("i=" + (j + 1), L + (j + 0.5) * cw, 48); });
      A.forEach(function (row, i) {
        var y = T + i * rh, b = 0; row.forEach(function (v, j) { if (v > row[b]) b = j; });
        if (i === t - 1) { c.fillStyle = P["accent-soft"]; c.fillRect(2, y, W - 4, rh); }
        c.textAlign = "left"; c.font = "500 12px " + fm; c.fillStyle = P.ink; c.fillText("t=" + (i + 1) + " " + DEMO_EL[QSTEP[i].ph].n, 8, y + 16);
        row.forEach(function (v, j) {
          var x = L + j * cw;
          c.fillStyle = P["surface-sunk"]; c.fillRect(x + 1, y + 2, cw - 2, rh - 4);
          c.globalAlpha = Math.min(1, 0.08 + v); c.fillStyle = P.accent; c.fillRect(x + 1, y + 2, cw - 2, rh - 4); c.globalAlpha = 1;
          if (j === QSTEP[i].ph) { c.strokeStyle = P.ink; c.lineWidth = 1.5; c.strokeRect(x + 1.5, y + 2.5, cw - 3, rh - 5); }
          if (j === b) { c.fillStyle = v > 0.55 ? P["on-accent"] || P.surface : P.ink; c.beginPath(); c.arc(x + cw / 2, y + rh / 2, 3.5, 0, Math.PI * 2); c.fill(); }
        });
      });
      c.textAlign = "left"; c.fillStyle = P["ink-2"]; c.font = "500 12px " + fm;
      c.fillText("row " + t + ": " + A[t - 1].map(function (v) { return v.toFixed(2); }).join("  "), 8, T + 12 * rh + 22);
    }
    function stop() { if (timer) { clearTimeout(timer); timer = null; } }
    bindSeg(body, id + "-mode", function (v) { mode = v; compute(); });
    RB.bindSlider(body, id + "-tau", function (v) { return (+v).toFixed(2); }, function (v) { tau = v; compute(); });
    var tIn = RB.bindSlider(body, id + "-t", null, function (v) { stop(); t = v; compute(); });
    body.querySelector("#" + id + "-play").addEventListener("click", function () {
      stop(); t = 0;
      (function tick() { t++; tIn.value = t; var out = body.querySelector('[data-out="' + id + '-t"]'); if (out) out.textContent = t; compute(); if (t < 12) timer = setTimeout(tick, 380); else timer = null; })();
    });
    compute();
    RB.onTheme(draw);
    return { state: function () { return { mode: mode, tau: tau, t: t, bad: bad, playing: !!timer }; } };
  }

  /* ================= playground 3: does the policy use the context? (X4 §7.1, Table 17) ================= */
  /* Two blocks, two bins. Order A (cube → left) is the familiar default in this scene; the original demonstration teaches
     order B (red → right). A toy policy reads the demonstration with probability w; otherwise it runs the familiar order. */
  var IVS = [{ value: "orig", label: "Original demo" }, { value: "none", label: "No demo" }, { value: "swap", label: "Swapped demo" }, { value: "restyle", label: "New demonstrator" }];
  function simulate(iv, w, p, shortcut, seed, n) {
    var R = RB.rng(seed), chB = 0, fin = 0;
    var taught = iv === "orig" || iv === "restyle" ? "B" : iv === "swap" ? "A" : null;
    for (var i = 0; i < n; i++) {
      var reads = taught && !(shortcut && iv === "restyle") && R() < w;
      var plan = reads ? taught : "A";
      if (plan === "B") chB++;
      var ok = R() < p && R() < p;
      if (ok && (taught === null || plan === taught)) fin++;
    }
    return { chB: chB / n, fin: fin / n };
  }

  function mountTeach(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-iv", label: "Intervention on the context", value: "orig", options: IVS }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-w", label: "Context use w", min: 0, max: 1, step: 0.1, value: 0.8, fmt: function (v) { return (+v).toFixed(1); } }) +
      RB.slider({ id: id + "-p", label: "Grasp success", min: 0.5, max: 1, step: 0.05, value: 0.9, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-short"> <span>Policy keys on the demonstrator’s look</span></label>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Sample again ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Left: the scene and the order the current demonstration asks for. Right: for four interventions, the rate of choosing order B and the rate of finishing the requested order"></canvas>' +
      '<figcaption class="sb-caption">Bars: 400 simulated episodes per intervention. Responsiveness is chose-B with the original demo minus the swapped demo; look gap is original minus new demonstrator.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "resp", k: "Responsiveness" }, { id: "inv", k: "Look gap" }, { id: "hide", k: "Finished, swapped demo" }, { id: "fin", k: "Finished, original demo" }]) +
      RB.legend([{ c: "data-1", label: "chose order B (interpretation)", kind: "area" }, { c: "data-3", label: "finished the requested order (physical)", kind: "area" }]) +
      '<p class="sb-caption" data-note></p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), W = 560, H = 300, N = 400;
    var iv = "orig", w = 0.8, p = 0.9, shortcut = false, seed = 5, res = {};
    function compute() {
      IVS.forEach(function (x, k) { res[x.value] = simulate(x.value, w, p, shortcut, seed * 31 + k, N); });
      RB.setRO(body, "resp", RB.fmt(res.orig.chB - res.swap.chB, 2)); RB.setRO(body, "inv", RB.fmt(res.orig.chB - res.restyle.chB, 2));
      RB.setRO(body, "hide", pct(res.swap.fin)); RB.setRO(body, "fin", pct(res.orig.fin));
      var NOTES = {
        orig: "The demo asks for order B, which differs from this scene's familiar order A. Choosing B is evidence of reading the demo.",
        none: "No demo: the policy falls back on its prior. This is the prior-only comparison for every other bar.",
        swap: "The swapped demo asks for the familiar order A. A policy that ignores context still finishes it, so success alone cannot show context use.",
        restyle: "Same order B, shown by a different demonstrator. The meaning is preserved, so behavior should not change."
      };
      note.textContent = NOTES[iv] + (shortcut && iv === "restyle" ? " With the shortcut on, the policy reads demos only in its training demonstrators' style." : "");
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), fm = mono(), fb = bodyF();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      /* scene */
      var taught = iv === "orig" || iv === "restyle" ? "B" : iv === "swap" ? "A" : null;
      c.fillStyle = P["surface-sunk"]; c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.fillRect(8, 30, 170, 150); c.strokeRect(8, 30, 170, 150);
      c.font = "600 12px " + fb; c.fillStyle = P.ink; c.textAlign = "left"; c.fillText(taught ? "Demo asks for order " + taught : "No demo given", 8, 20);
      [[30, "left bin"], [120, "right bin"]].forEach(function (b) { c.strokeStyle = P["ink-2"]; c.lineWidth = 1.5; c.strokeRect(b[0], 130, 40, 30); c.fillStyle = P["ink-2"]; c.font = "500 12px " + fm; c.textAlign = "center"; c.fillText(b[1], b[0] + 20, 176); });
      c.fillStyle = P["data-1"]; c.fillRect(60, 60, 18, 18); c.fillStyle = P["data-2"]; c.beginPath(); c.arc(113, 69, 9, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-2"]; c.fillText("cube", 69, 54); c.fillText("can", 113, 54);
      if (taught) {
        var toR = taught === "B";
        c.strokeStyle = P.accent; c.lineWidth = 2; c.setLineDash([4, 3]);
        c.beginPath(); c.moveTo(69, 80); c.lineTo(toR ? 140 : 50, 126); c.stroke(); c.beginPath(); c.moveTo(113, 80); c.lineTo(toR ? 50 : 140, 126); c.stroke(); c.setLineDash([]);
      }
      c.fillStyle = P["ink-3"]; c.font = "500 12px " + fm; c.textAlign = "left"; c.fillText(iv === "restyle" ? "shown by a new demonstrator" : "A = cube → left (familiar)", 8, 200); c.fillText("B = cube → right", 8, 216);
      /* bars */
      var X0 = 214, Y0 = 244, Hb = 190, gw = (W - X0 - 8) / 4;
      c.strokeStyle = P.line; c.lineWidth = 1;
      [0, 0.5, 1].forEach(function (v) { var y = Y0 - v * Hb; c.beginPath(); c.moveTo(X0, y); c.lineTo(W - 8, y); c.stroke(); c.fillStyle = P["ink-3"]; c.textAlign = "right"; c.fillText(Math.round(v * 100) + "%", X0 - 4, y + 4); });
      IVS.forEach(function (x, k) {
        var r = res[x.value], gx = X0 + k * gw + 8, bw = (gw - 22) / 2;
        if (x.value === iv) { c.fillStyle = P["accent-soft"]; c.fillRect(X0 + k * gw + 2, Y0 - Hb - 6, gw - 4, Hb + 50); }
        c.fillStyle = P["data-1"]; c.fillRect(gx, Y0 - r.chB * Hb, bw, Math.max(1, r.chB * Hb));
        c.fillStyle = P["data-3"]; c.fillRect(gx + bw + 4, Y0 - r.fin * Hb, bw, Math.max(1, r.fin * Hb));
        c.fillStyle = P.ink; c.textAlign = "center"; c.font = "500 12px " + fm;
        c.fillText(pct(r.chB), gx + bw / 2, Y0 - r.chB * Hb - 4); c.fillText(pct(r.fin), gx + bw * 1.5 + 4, Y0 - r.fin * Hb - 4);
        var lab = x.label.split(" "); c.fillStyle = P["ink-2"]; c.fillText(lab[0], X0 + (k + 0.5) * gw, Y0 + 16); c.fillText(lab.slice(1).join(" "), X0 + (k + 0.5) * gw, Y0 + 30);
      });
    }
    bindSeg(body, id + "-iv", function (v) { iv = v; compute(); });
    RB.bindSlider(body, id + "-w", function (v) { return (+v).toFixed(1); }, function (v) { w = v; compute(); });
    RB.bindSlider(body, id + "-p", function (v) { return (+v).toFixed(2); }, function (v) { p = v; compute(); });
    body.querySelector("#" + id + "-short").addEventListener("change", function (e) { shortcut = e.target.checked; compute(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; compute(); });
    compute();
    RB.onTheme(draw);
    return { state: function () { return { iv: iv, w: w, p: p, shortcut: shortcut, seed: seed, resp: res.orig.chB - res.swap.chB, gap: res.orig.chB - res.restyle.chB }; } };
  }

  /* ================= concept-card drawings (200 × 56, token classes only) ================= */
  function box(x, y, w, h, cls, t, tcls) { return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="3" class="' + cls + '"/>' + (t ? '<text x="' + (x + w / 2) + '" y="' + (y + h / 2 + 4) + '" text-anchor="middle" class="' + (tcls || "rb-t-mono") + '">' + t + "</text>" : ""); }
  var ART = {
    fixed: '<svg viewBox="0 0 200 56" aria-hidden="true">' + box(4, 16, 52, 24, "rb-f-soft", "demo") + '<path d="M56 28 H80" class="rb-s-acc"/><path d="M75 23 L81 28 L75 33" class="rb-s-acc"/>' + box(82, 10, 64, 36, "rb-f-surface", "θ fixed") + '<path d="M146 28 H170" class="rb-s-ink"/>' + box(170, 16, 26, 24, "rb-f-sunk", "a") + '<text x="114" y="54" text-anchor="middle" class="rb-t-mono">context changes</text></svg>',
    support: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3].map(function (i) { return box(4 + i * 22, 8, 20, 18, i === 2 ? "rb-f-acc" : "rb-f-soft", "d" + (i + 1)); }).join("") + '<text x="46" y="44" text-anchor="middle" class="rb-t-mono">support</text>' + box(124, 8, 72, 30, "rb-f-surface", "query") + '<text x="160" y="52" text-anchor="middle" class="rb-t-mono">new scene</text><path d="M94 17 H122" class="rb-s-acc" stroke-dasharray="3 3"/></svg>',
    reuse: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="16" cy="30" r="5" class="rb-f-acc"/><text x="16" y="50" text-anchor="middle" class="rb-t-mono">q</text>' + [[64, 0.47], [116, 0.34], [168, 0.19]].map(function (p) { return '<path d="M16 30 L' + (p[0] - 6) + ' 30" class="rb-s-line" stroke-dasharray="2 3"/><circle cx="' + p[0] + '" cy="30" r="4" class="rb-f-soft"/><path d="M' + p[0] + ' 30 l0 -16" class="rb-s-ink"/><text x="' + p[0] + '" y="50" text-anchor="middle" class="rb-t-mono">β=' + p[1] + "</text>"; }).join("") + "</svg>",
    attend: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0.05, 0.1, 0.6, 0.2, 0.05].map(function (v, i) { return box(8 + i * 38, 22, 34, 16, "rb-f-surface") + '<rect x="' + (8 + i * 38) + '" y="' + (38 - 16 * v * 1.6) + '" width="34" height="' + (16 * v * 1.6).toFixed(1) + '" class="rb-f-acc"/><text x="' + (25 + i * 38) + '" y="52" text-anchor="middle" class="rb-t-mono">' + v + "</text>"; }).join("") + '<text x="100" y="14" text-anchor="middle" class="rb-t-mono">αₜᵢ over demo steps</text></svg>',
    geo: '<svg viewBox="0 0 200 56" aria-hidden="true">' + box(10, 24, 44, 24, "rb-f-soft", "demo") + '<path d="M20 22 C30 4, 50 4, 56 18" class="rb-s-ink"/>' + box(130, 28, 56, 20, "rb-f-surface", "new obj") + '<path d="M140 26 C150 8, 172 8, 180 22" class="rb-s-acc"/><path d="M70 30 H118" class="rb-s-acc" stroke-dasharray="4 3"/><text x="94" y="24" text-anchor="middle" class="rb-t-mono">align</text></svg>',
    predict: '<svg viewBox="0 0 200 56" aria-hidden="true">' + box(4, 14, 40, 28, "rb-f-surface", "now") + '<path d="M44 28 H62" class="rb-s-ink"/>' + box(62, 8, 72, 40, "rb-f-soft", "future") + '<path d="M134 28 H152" class="rb-s-acc"/>' + box(152, 14, 44, 28, "rb-f-sunk", "act") + "</svg>",
    skill: '<svg viewBox="0 0 200 56" aria-hidden="true">' + ["pick", "place", "pick", "place"].map(function (t, i) { return box(4 + i * 44, 12, 40, 20, i % 2 ? "rb-f-soft" : "rb-f-surface", t); }).join("") + '<text x="100" y="48" text-anchor="middle" class="rb-t-mono">order from the demo → executor</text></svg>',
    check: '<svg viewBox="0 0 200 56" aria-hidden="true">' + box(4, 8, 58, 18, "rb-f-soft", "demo A") + box(4, 32, 58, 18, "rb-f-soft", "demo B") + '<path d="M62 17 H96 M62 41 H96" class="rb-s-ink"/>' + box(96, 8, 44, 42, "rb-f-surface", "policy") + '<path d="M140 17 H160 M140 41 H160" class="rb-s-acc"/><text x="166" y="21" class="rb-t-acc">A?</text><text x="166" y="45" class="rb-t-acc">B?</text></svg>'
  };

  /* ================= worked example figure: VINN-style weighted action reuse, our numbers ================= */
  /* query at (150, 112); records placed at our toy distances (radius 50 + 70·d px); actions drawn at 18 px per unit */
  var WQ = [150, 112], WA = 18;
  var WREC = [{ px: 210, py: 134, ax: 2, ay: 0, d: 0.2, b: 0.466, b2: 0.753, n: "record 1", lx: 0, ly: 20, la: "middle", dx: 4, dy: -8 }, { px: 192, py: 38, ax: 1, ay: 1, d: 0.5, b: 0.345, b2: 0.227, n: "record 2", lx: 10, ly: 16, la: "start", dx: 6, dy: 0 }, { px: 31, py: 155, ax: -1, ay: 2, d: 1.1, b: 0.189, b2: 0.021, n: "record 3", lx: 8, ly: 26, la: "start", dx: -24, dy: 22 }];
  function warrow(x, y, dx, dy, cls, dash) { var x1 = x + dx * WA, y1 = y - dy * WA; return '<path d="M' + x + " " + y + " L" + x1.toFixed(1) + " " + y1.toFixed(1) + '" class="' + cls + '" stroke-width="2"' + (dash ? ' stroke-dasharray="5 3"' : "") + '/><circle cx="' + x1.toFixed(1) + '" cy="' + y1.toFixed(1) + '" r="3" class="rb-f-acc"/>'; }
  var WE_FIG = '<svg viewBox="0 0 560 230" role="img" aria-label="A query point with three stored records, their recorded actions and distances; bars show the weights; the mixture action and the replayed action are compared">' +
    '<rect x="8" y="8" width="290" height="214" rx="4" class="rb-f-sunk"/>' +
    '<g data-on="1+">' + WREC.map(function (r) { return '<path d="M' + WQ[0] + " " + WQ[1] + " L" + r.px + " " + r.py + '" class="rb-s-line" stroke-dasharray="3 3"/><text x="' + ((WQ[0] + r.px) / 2 + r.dx) + '" y="' + ((WQ[1] + r.py) / 2 + r.dy) + '" class="rb-t-mono">d=' + r.d + "</text>"; }).join("") + "</g>" +
    WREC.map(function (r) { return warrow(r.px, r.py, r.ax, r.ay, "rb-s-ink") + '<circle cx="' + r.px + '" cy="' + r.py + '" r="4" class="rb-f-soft"/><text x="' + (r.px + r.lx) + '" y="' + (r.py + r.ly) + '" text-anchor="' + r.la + '" class="rb-t-mono">' + r.n + "</text>"; }).join("") +
    '<circle cx="' + WQ[0] + '" cy="' + WQ[1] + '" r="6" class="rb-f-acc"/><text x="' + (WQ[0] + 6) + '" y="' + (WQ[1] + 26) + '" text-anchor="middle" class="rb-t-ink">query</text>' +
    '<g data-on="3+">' + warrow(WQ[0], WQ[1], 1.087, 0.724, "rb-s-acc") + "</g>" +
    '<g data-on="4+">' + warrow(WQ[0], WQ[1], 2, 0, "rb-s-ink", true) + "</g>" +
    '<text x="316" y="30" class="rb-t-ink">weight β per record</text>' +
    WREC.map(function (r, i) { var y = 46 + i * 32; return '<text x="316" y="' + (y + 12) + '" class="rb-t-mono">' + r.n + '</text><rect x="386" y="' + y + '" width="120" height="14" class="rb-f-surface"/>' +
      '<g data-on="2-4"><rect x="386" y="' + y + '" width="' + (120 * r.b).toFixed(1) + '" height="14" class="rb-f-acc"/><text x="512" y="' + (y + 12) + '" class="rb-t-mono">' + r.b.toFixed(3) + "</text></g>" +
      '<g data-on="5"><rect x="386" y="' + y + '" width="' + Math.max(1, 120 * r.b2).toFixed(1) + '" height="14" class="rb-f-acc"/><text x="512" y="' + (y + 12) + '" class="rb-t-mono">' + r.b2.toFixed(3) + "</text></g>"; }).join("") +
    '<g data-on="3+"><text x="316" y="164" class="rb-t-acc">mixture = (1.09, 0.72)</text></g>' +
    '<g data-on="4+"><text x="316" y="186" class="rb-t-mono">replay nearest = (2.00, 0.00)</text></g>' +
    '<g data-on="5"><text x="316" y="208" class="rb-t-mono">σ = 0.25: toward replay</text></g>' +
    "</svg>";

  RB.topic({
    id: "b6",
    title: "Teaching a frozen policy in context",
    eyebrow: "Part B · In-context learning",
    lede: "Show a robot a demonstration and it performs the task in its own scene. The teaching lives in the context; the weights do not change.",
    refs: ["X4 §2.2–2.3", "X4 §3.1–3.5", "X4 §7"],
    why: "Pretraining gives a robot grasps and motions, yet a scene can leave several procedures feasible. In-context learning (ICL) for robots supplies the missing evidence, such as demonstrations, corrections or interaction history, as context, with deployed neural parameters fixed. The survey sorts methods by what the context becomes before execution: actions, a motion reference, a predicted future or a skill specification.",
    outcomes: [
      "Distinguish contextual adaptation from parameter adaptation by what changes at deployment.",
      "Compute a retrieval policy's action as a weighted mixture of stored action blocks.",
      "Compare the four method families by the intermediate that execution consumes.",
      "Explain how attention over demonstration elements follows the execution phase.",
      "Design context interventions that separate use of teaching from physical success."
    ],
    concepts: [
      { name: "Context, not weights", def: "New evidence enters the policy's input while deployed parameters stay fixed, so clearing the context clears the lesson.", ref: "X4 §2.2 eq. 3", art: ART.fixed, term: "contextual-adaptation", sym: "ctx" },
      { name: "Support demonstration", def: "A demonstration supplied at deployment to specify the task, which the robot then performs in its own scene.", ref: "X4 Table 1", art: ART.support, term: "support-demonstration", sym: "Dsup" },
      { name: "Action reuse", def: "Retrieve stored records near the query and return their recorded actions, replayed or mixed with weights β.", ref: "X4 §3.1 eq. 5", art: ART.reuse, term: "action-reuse", sym: "beta-ret" },
      { name: "Attention over the demo", def: "A learned score reads the demonstration element that matches the current execution phase, and the read changes with progress.", ref: "X4 §3.1 eq. 6", art: ART.attend, term: "demonstration-correspondence", sym: "alpha-demo" },
      { name: "Geometric transfer", def: "Extract a motion or contact reference from the demonstration, retarget it to the new scene, then track or replay it.", ref: "X4 §3.2 eq. 7", art: ART.geo, term: "geometric-demonstration-transfer", sym: "zeta-md" },
      { name: "Predict, then act", def: "Predict the future the demonstration calls for in this scene, then decode or plan actions that realize it.", ref: "X4 §3.3 eq. 9", art: ART.predict, sym: "pv", href: "#explorer/c2", hrefLabel: "World action models →" },
      { name: "Skills and agents", def: "Infer a skill order, program or tool call from the teaching; an existing executor turns it into motion.", ref: "X4 §3.4 eq. 13", art: ART.skill, sym: "gspec", href: "#explorer/b5", hrefLabel: "LLM planners →" },
      { name: "Does it use the context?", def: "Remove or swap the demonstration with everything else fixed; only a policy that reads context changes its behavior.", ref: "X4 §7.1", art: ART.check, term: "context-intervention" }
    ],
    flow: {
      title: "How teaching reaches the robot", ref: "X4 Fig. 5", w: 860, h: 320,
      caption: "Teaching and history are assembled into a context. A model with fixed weights turns it into an intermediate; an executor realizes that intermediate. New observations feed the next decision.",
      nodes: [
        { id: "teach", x: 20, y: 30, w: 160, h: 52, label: "Teaching evidence", sub: "demos, corrections", kind: "env" },
        { id: "hist", x: 20, y: 200, w: 160, h: 52, label: "History hₜ", sub: "observations, actions", kind: "env" },
        { id: "ctxb", x: 220, y: 112, w: 160, h: 60, label: "Context Cₜ", sub: "selected, aligned", kind: "store" },
        { id: "pol", x: 460, y: 112, w: 160, h: 60, label: "Frozen model", sub: "parameters θ fixed", kind: "agent" },
        { id: "inter", x: 660, y: 30, w: 180, h: 60, label: "Intermediate", sub: "one per family", kind: "decision" },
        { id: "robot", x: 660, y: 196, w: 180, h: 60, label: "Executor and robot", sub: "decode, track, invoke", kind: "env" }
      ],
      edges: [
        { from: "teach", to: "ctxb", label: "select", sides: ["r", "t"], via: [[300, 56]] },
        { from: "hist", to: "ctxb", label: "retain", sides: ["r", "b"], via: [[300, 226]], dx: -60 },
        { from: "ctxb", to: "pol", label: "condition" },
        { from: "pol", to: "inter", label: "emits", sides: ["t", "l"], via: [[540, 60]] },
        { from: "inter", to: "robot", label: "execute", sides: ["b", "t"] },
        { from: "robot", to: "hist", label: "new observation", sides: ["b", "b"], via: [[750, 300], [100, 300]], dy: -6 }
      ],
      steps: [
        { on: ["teach", "teach>ctxb", "ctxb"], text: "Context construction picks the relevant evidence: a retrieved episode, the demonstration phase that matches now, or a correction." },
        { on: ["hist", "hist>ctxb"], text: "History hₜ holds this attempt's observations and executed actions. Memory can carry events the current camera no longer shows." },
        { on: ["ctxb>pol", "pol"], text: "The model reads Cₜ with its parameters θ fixed. Restoring the context, not the weights, resets what it learned." },
        { on: ["pol>inter", "inter"], text: "Its output is one of four intermediates: an action distribution, a motion reference, a predicted future, or a skill or tool specification." },
        { on: ["inter>robot", "robot"], text: "An executor realizes it by decoding, tracking, planning or invoking a skill. Transfer fails if the intermediate lost a binding detail." },
        { on: ["robot>hist", "hist"], text: "Executed actions and their effects enter the history, so interaction can also reveal physical response, as in RMA." }
      ]
    },
    worked: {
      title: "Reusing three stored actions",
      ref: "X4 §3.1 eq. 5 · VINN, arXiv 2112.01511", prov: "Our toy numbers",
      eq: { tex: "\\hat{\\class{sym-achunk}{\\mathbf{a}}} = \\sum_{j \\in \\class{sym-Jsel}{\\mathcal{J}_t}} \\class{sym-beta-ret}{\\beta_{tj}}\\, \\class{sym-abar-j}{\\bar{\\mathbf{a}}_{j}}, \\qquad \\class{sym-beta-ret}{\\beta_{tj}} = \\frac{e^{-d_j/\\sigma}}{\\sum_{k \\in \\class{sym-Jsel}{\\mathcal{J}_t}} e^{-d_k/\\sigma}}",
        words: "Weight each selected record by how close it is to the query, then average the actions stored with those records.",
        key: ["achunk", "Jsel", "beta-ret", "abar-j", { glyph: "d_j", meaning: "distance from query to record j" }, { glyph: "σ", meaning: "kernel width" }] },
      figure: WE_FIG,
      steps: [
        { title: "Measure distances", text: "In the embedding, the query is 0.2, 0.5 and 1.1 away from three stored records. Each record carries its recorded action." },
        { title: "Turn distance into weight", text: "With σ = 1, e^(−d) gives 0.819, 0.607 and 0.333. Dividing by their sum 1.758 gives β = 0.466, 0.345, 0.189." },
        { title: "Mix the actions", text: "0.466·(2, 0) + 0.345·(1, 1) + 0.189·(−1, 2) = (1.09, 0.72). No record took exactly this action." },
        { title: "Compare with replay", text: "Nearest-neighbor replay gives weight one to record 1 and returns (2.00, 0.00), a recorded action, unchanged." },
        { title: "Sharpen the kernel", text: "With σ = 0.25 the weights become 0.753, 0.227 and 0.021: the mixture moves toward replay." }
      ]
    },
    ruleTitle: "How context becomes action",
    rules: [
      { name: "Context-conditioned policy, fixed parameters", ref: "X4 §2.2 eqs. 1, 3", term: "contextual-adaptation",
        tex: "\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\sim \\class{sym-pi}{\\pi_\\theta}(\\cdot \\mid \\class{sym-hobs}{h_t}, \\class{sym-ctx}{C_t}), \\qquad \\class{sym-theta-dep}{\\theta_{t+1}} = \\class{sym-theta-dep}{\\theta_t} = \\class{sym-theta-dep}{\\theta_0}",
        words: "The policy proposes an action block from this attempt's history and the supplied context; during deployment only history and context change.",
        key: ["achunk", "pi", "hobs", "ctx", "theta-dep"] },
      { name: "Interpret the context, then generate", ref: "X4 §3.1 eq. 4", term: "in-context-learning",
        before: "\\class{sym-pi}{\\pi_\\theta}(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\mid \\class{sym-hobs}{h_t}, \\class{sym-ctx}{C_t})",
        tex: "\\class{sb-new}{\\class{sym-qact}{q^{a}_{\\theta}}}(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\mid \\class{sym-hobs}{h_t}, \\class{sb-new}{\\class{sym-rctx}{\\mathbf{r}_t}}), \\quad \\class{sb-new}{\\class{sym-rctx}{\\mathbf{r}_t} = \\class{sym-Ectx}{E^{c}_{\\theta}}(\\class{sym-hobs}{h_t}, \\class{sym-ctx}{C_t})}",
        words: "An interpreter compresses history and context into a representation; a generator (autoregressive, diffusion or flow) turns it into actions.",
        key: ["pi", "achunk", "hobs", "ctx", "qact", "rctx", "Ectx"], diff: true, beforeLabel: "Any policy", afterLabel: "Interpreter + generator" },
      { name: "Nonparametric action reuse", ref: "X4 §3.1 eq. 5", term: "action-reuse",
        tex: "\\class{sym-pi}{\\pi_\\theta}(\\cdot \\mid \\class{sym-hobs}{h_t}, \\class{sym-ctx}{C_t}) = \\sum_{j \\in \\class{sym-Jsel}{\\mathcal{J}_t}} \\class{sym-beta-ret}{\\beta_{tj}}\\, \\delta_{\\class{sym-abar-j}{\\bar{\\mathbf{a}}_{j}}}, \\quad \\class{sym-beta-ret}{\\beta_{tj}} \\ge 0, \\ \\sum_{j} \\class{sym-beta-ret}{\\beta_{tj}} = 1",
        words: "Select stored records for this query and return their recorded action blocks, weighted. Nearest-neighbor replay puts weight one on one record.",
        key: ["pi", "hobs", "ctx", "Jsel", "beta-ret", { glyph: "δ", meaning: "point mass on a stored block" }, "abar-j"] },
      { name: "Attention over demonstration elements", ref: "X4 §3.1 eq. 6", term: "demonstration-correspondence",
        tex: "\\class{sym-alpha-demo}{\\alpha_{ti}} = \\frac{\\exp \\class{sym-compat}{s_{\\theta}}(\\class{sym-hobs}{h_t}, \\class{sym-dsi}{d^{s}_{i}})}{\\sum_{k=1}^{\\class{sym-Ldemo}{L}} \\exp \\class{sym-compat}{s_{\\theta}}(\\class{sym-hobs}{h_t}, \\class{sym-dsi}{d^{s}_{k}})}, \\qquad \\class{sym-rctx}{\\mathbf{r}_t} = \\sum_{i=1}^{\\class{sym-Ldemo}{L}} \\class{sym-alpha-demo}{\\alpha_{ti}}\\, \\class{sym-edemo}{e_{\\theta}}(\\class{sym-dsi}{d^{s}_{i}})",
        words: "Score each demonstration element against the robot's history, normalize, and read a weighted sum. The read moves as execution progresses.",
        key: ["alpha-demo", "compat", "hobs", "dsi", "Ldemo", "rctx", "edemo"] },
      { name: "Geometric demonstration transfer", ref: "X4 §3.2 eq. 7", term: "geometric-demonstration-transfer",
        tex: "\\begin{aligned} \\class{sym-zeta-md}{\\zeta_{1:L}} &= \\class{sym-Emd}{E^{m}_{\\theta}}(\\class{sym-Dsup}{\\mathcal{D}^{s}}), \\quad \\class{sym-gspec}{\\mathbf{g}} = \\mathrm{Retarget}(\\class{sym-zeta-md}{\\zeta_{1:L}}, \\class{sym-o}{o_t}, \\class{sym-Brob}{B}), \\\\ \\class{sym-achunk}{\\mathbf{a}_{t:t+H}} &= \\class{sym-kappa-ex}{\\kappa}(\\class{sym-gspec}{\\mathbf{g}}, \\class{sym-o}{o_t}) \\end{aligned}",
        words: "Extract motion descriptors from the demonstration, retarget them to this scene and robot, and let an executor track the reference.",
        key: ["zeta-md", "Emd", "Dsup", "gspec", { glyph: "Retarget", meaning: "align to scene and body" }, "o", "Brob", "achunk", "kappa-ex"] },
      { name: "World-model-based control", ref: "X4 §3.3 eq. 9", term: "in-context-learning",
        tex: "\\class{sym-op}{o'} \\sim \\class{sym-pv}{p^{v}_{\\theta}}(\\cdot \\mid \\class{sym-ctx}{C_t}, \\class{sym-hobs}{h_t}), \\qquad \\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\sim \\class{sym-qv}{q^{v}_{\\theta}}(\\cdot \\mid \\class{sym-op}{o'}, \\class{sym-ctx}{C_t}, \\class{sym-hobs}{h_t})",
        words: "Predict the future the context calls for, in this scene, then decode actions that realize it. Prediction and decoding are separate error sources.",
        key: ["op", "pv", "ctx", "hobs", "achunk", "qv"] },
      { name: "Skill- and agent-based execution", ref: "X4 §3.4 eq. 13", term: "in-context-learning",
        tex: "\\class{sym-gspec}{\\mathbf{g}} = \\class{sym-fspec}{f_{\\theta}}(\\class{sym-ctx}{C_t}, \\class{sym-hobs}{h_t}), \\qquad \\class{sym-achunk}{\\mathbf{a}_{t:t+H}} = \\class{sym-kappa-ex}{\\kappa}(\\class{sym-gspec}{\\mathbf{g}}, \\class{sym-o}{o_t})",
        words: "Infer an execution specification, such as a skill sequence, program or tool call, and let an existing executor realize it.",
        key: ["gspec", "fspec", "ctx", "hobs", "achunk", "kappa-ex", "o"] }
    ],
    algorithm: {
      title: "Deploying an in-context policy", ref: "X4 §2.2 eqs. 1–3, §3.5 eq. 17", prov: "Our notation",
      lines: [
        '<span class="kw">input</span> support demonstration <span data-sym="Dsup">𝒟ˢ</span>, trained parameters <span data-sym="theta-dep">θ</span> (fixed)',
        '<span data-sym="hobs">h₁</span> ← (o₁)',
        '<span class="kw">for</span> t = 1, 2, … until done:',
        '    <span data-sym="ctx">Cₜ</span> ← select and align evidence from <span data-sym="Dsup">𝒟ˢ</span> and memory for <span data-sym="hobs">hₜ</span>   <span class="cm">// retrieval, phase alignment</span>',
        '    propose <span data-sym="achunk">𝐚ₜ:ₜ₊H</span> ~ <span data-sym="pi">π_θ</span>(· | <span data-sym="hobs">hₜ</span>, <span data-sym="ctx">Cₜ</span>)   <span class="cm">// or reference, future, skill</span>',
        "    execute the first actions; observe the next observation",
        '    <span data-sym="hobs">hₜ₊₁</span> ← <span data-sym="hobs">hₜ</span> + executed actions and observations   <span class="cm">// θ is never updated</span>'
      ]
    },
    playgrounds: [
      {
        id: "retrieve", title: "Replay, mix or blend stored actions", ref: "X4 §3.1 eq. 5 · REGENT, RICL", prov: "Simplified: 2-D toy states",
        try: "Start with Mixture and raise k to 8: the rollout hits the obstacle. Try Replay, then Next start. In Blend, raise λ to 3 and lower it to 0.5.",
        mount: mountRetrieve,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b6-retrieve";
          return [
            { target: q("canvas"), title: "Four taught detours", text: "Two demonstrations pass above the obstacle and two below. Each short arrow is a recorded action stored with its state." },
            { target: q("#" + id + "-k"), title: "Average too many records", text: "With 8 records, above and below actions cancel sideways. The mixture points straight ahead, into the obstacle.", do: function (a) { return a.set(q("#" + id + "-k"), 8); }, task: "Set Records k to 8", expect: function () { return api.state().k >= 8 && api.state().mode === "knn"; } },
            { target: q("#" + id + "-mode"), title: "Replay one record", text: "Replay copies the nearest record's action with weight one. It stays on one side of the obstacle and reaches the goal.", do: function (a) { return a.click(q("#" + id + '-mode [value="nn"]')); }, task: "Choose Replay", expect: function () { return api.state().mode === "nn"; } },
            { target: q("#" + id + "-next"), title: "Start off the data", text: "From a start above the demonstrations, replay copies displacements but never corrects the offset, so it misses the goal.", do: function (a) { return a.click(q("#" + id + "-next")).then(function () { return a.click(q("#" + id + "-next")); }); }, task: "Press Next start twice", expect: function () { return api.state().start === 2; } },
            { target: q("#" + id + "-mode"), title: "Blend with a generator", text: "Blending trusts the nearest record when close and the generator when far. This generator knows the goal but not the detour.", do: function (a) { return a.click(q("#" + id + '-mode [value="blend"]')); }, task: "Choose Blend", expect: function () { return api.state().mode === "blend"; } },
            { target: q("#" + id + "-l"), title: "Too eager to generalize", text: "A large λ hands control to the generator as soon as the robot drifts from the records; near the obstacle that means a collision.", do: function (a) { return a.click(q("#" + id + "-next")).then(function () { return a.click(q("#" + id + "-next")); }).then(function () { return a.set(q("#" + id + "-l"), 3); }); }, task: "Set Blend sharpness λ to 3", expect: function () { return api.state().lam >= 3; } },
            { target: q("canvas"), title: "Your turn", text: "Click the map to start the robot elsewhere, and find the λ range that works from every start." }
          ];
        }
      },
      {
        id: "attend", title: "Which demonstration step does the policy read?", ref: "X4 §3.1 eq. 6", prov: "Simplified: three hand-set features",
        try: "Set the robot step to 12 with Current frame: the read splits between start and retreat. Switch to With history. Then raise the temperature τ and watch rows blur.",
        mount: mountAttention,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b6-attend";
          return [
            { target: q("canvas"), title: "Rows are robot steps", text: "Columns are eight demonstration elements. Row t shows the weights αₜᵢ the policy puts on each element at robot step t." },
            { target: q("#" + id + "-t"), title: "A look-alike phase", text: "At step 12 the robot retreats with an open gripper, which looks like the start. The frame-only score splits its read.", do: function (a) { return a.set(q("#" + id + "-t"), 12); }, task: "Set Robot step t to 12", expect: function () { return api.state().t === 12; } },
            { target: q("#" + id + "-mode"), title: "Add history", text: "A count of gripper events so far separates start from retreat, and at cup from release. Wrong reads drop.", do: function (a) { return a.click(q("#" + id + '-mode [value="hist"]')); }, task: "Choose With history", expect: function () { return api.state().mode === "hist"; } },
            { target: q("#" + id + "-tau"), title: "A soft read", text: "A high temperature spreads attention over many elements, so the representation mixes phases even when the score ranks them correctly.", do: function (a) { return a.set(q("#" + id + "-tau"), 0.5); }, task: "Raise temperature τ to 0.5", expect: function () { return api.state().tau >= 0.45; } },
            { target: q("#" + id + "-play"), title: "Watch the read move", text: "Play the robot's steps. The outlined matching phase and the most-read element should move together down the rows.", do: function (a) { return a.set(q("#" + id + "-tau"), 0.06).then(function () { return a.click(q("#" + id + "-play")); }).then(function () { return a.wait(2600); }); }, task: "Press Play steps", expect: function () { return api.state().t >= 6; } },
            { target: q("#" + id + "-mode"), title: "Your turn", text: "Switch back to Current frame and find the temperature that hides the aliasing best. Does any value remove it?" }
          ];
        }
      },
      {
        id: "teach", title: "Does the policy use the demonstration?", ref: "X4 §7.1, Table 17", prov: "Illustrative: two-parameter toy policy",
        try: "Set Context use to 0 and compare Original and Swapped. Then raise it to 0.9. Lower grasp success. Finally tick the shortcut and choose New demonstrator.",
        mount: mountTeach,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b6-teach";
          return [
            { target: q("canvas"), title: "Two orders, one scene", text: "Order A is the scene's familiar default. The original demonstration teaches order B. Blue bars count episodes that chose B." },
            { target: q("#" + id + "-w"), title: "A policy that ignores context", text: "With context use 0, every intervention gives the same behavior. Responsiveness, original minus swapped, is zero.", do: function (a) { return a.set(q("#" + id + "-w"), 0); }, task: "Set Context use w to 0", expect: function () { return api.state().w === 0; } },
            { target: q("#" + id + "-iv"), title: "Success can hide it", text: "The swapped demo asks for the familiar order A. This policy finishes it most of the time without reading anything.", do: function (a) { return a.click(q("#" + id + '-iv [value="swap"]')); }, task: "Choose Swapped demo", expect: function () { return api.state().iv === "swap"; } },
            { target: q("#" + id + "-w"), title: "A policy that reads", text: "Now the chosen order follows the demonstration: responsiveness rises to about 0.9, while no-demo behavior stays at the prior.", do: function (a) { return a.set(q("#" + id + "-w"), 0.9); }, task: "Set Context use w to 0.9", expect: function () { return api.state().w >= 0.9; } },
            { target: q("#" + id + "-p"), title: "Interpretation is not realization", text: "Lower grasp success. Choosing B does not change, but finishing falls: report task interpretation and physical completion separately.", do: function (a) { return a.set(q("#" + id + "-p"), 0.6); }, task: "Set Grasp success to 0.60", expect: function () { return api.state().p <= 0.65; } },
            { target: q("#" + id + "-short"), title: "A collection shortcut", text: "This policy reads demos only in its training demonstrators' style. A meaning-preserving change of demonstrator now changes behavior.", do: function (a) { return a.click(q("#" + id + "-short")).then(function () { return a.click(q("#" + id + '-iv [value="restyle"]')); }); }, task: "Tick the shortcut, then choose New demonstrator", expect: function () { return api.state().shortcut && api.state().iv === "restyle"; } },
            { target: q("#" + id + "-go"), title: "Your turn", text: "Resample a few times. How large must the gap be before you trust it is not sampling noise?" }
          ];
        }
      }
    ],
    methods: ["tecn", "tosil", "mosaic", "vinn", "icrt", "kat", "instant-policy", "roboprompt", "regent", "ricl", "bpc", "matchingpolicy", "demodiffusion", "imop", "vid2robot", "rma", "vima", "one-shot-imitation"],
    methodsLede: "How the lines evolved: TecNets pooled a demonstration into one task embedding; T-OSIL and MOSAIC attended to it frame by frame; ICRT prompted a causal transformer with raw sensorimotor trajectories; Instant Policy and MatchingPolicy added 3D graphs and explicit correspondence. KAT and RoboPrompt prompted text language models. VINN replayed nearby actions; REGENT and RICL blended retrieval with a learned model; BPC fitted signed continuation coefficients. Vid2Robot, RMA and VIMA are taught in other topics.",
    open: [
      { title: "Inferring an unfamiliar rule", text: "Most tests select a familiar task. Inferring a new rule, such as a size-to-slot mapping, needs held-out rule families and examples that separate candidates.", refs: "X4 §8.1, Table 18" },
      { title: "Selective invariance", text: "A learner must keep what the teaching binds, such as a handle grasp or a curing pause, and change only details its meaning permits.", refs: "X4 §8.3" },
      { title: "Revising obsolete lessons", text: "Retained corrections help later attempts, but a new tool or layout can make them wrong; memory must keep, override or drop them.", refs: "X4 §8.4" },
      { title: "Becoming more teachable", text: "The aim is a successor that learns faster from new teaching. LMPC raised held-out teaching-task success from 39.4% to 66.3%.", refs: "X4 §8.5" }
    ],
    takeaways: [
      "In-context learning changes a robot's behavior through supplied evidence and retained history, with deployed neural parameters fixed; fast-weight updates count as parameter adaptation.",
      "Four families differ in what context becomes before execution: an action distribution, a motion reference, a predicted future, or a skill or tool specification.",
      "Action reuse returns recorded actions with weights β; learned generators transform the example instead, which helps within their training distribution and can fail beyond it.",
      "Training must make the demonstration informative: ICRT trained only on single-task DROID scenes failed all test tasks, while multi-task scenes taught prompt use.",
      "Evaluate by intervening on the context: swap or remove the teaching with everything else fixed, and report interpretation and physical completion separately."
    ],
    quiz: [
      { q: "A policy adapts to a new task at deployment. Which case is in-context learning?", options: ["A few gradient steps on one demonstration", "Fast weights updated from a target video", "A demonstration placed in the input, weights unchanged", "A fine-tuned copy of the weights per task"], correct: 2, why: "The survey reserves in-context learning for adaptation with deployed neural parameters fixed; any neural update, including a fast-weight subset, is parameter adaptation (X4 §2.2)." },
      { q: "Three retrieved records have weights 0.5, 0.3 and 0.2 and actions 2, 0 and −1. What does eq. 5's mixture return?", options: ["2, the nearest record's action", "0.8", "1.0", "0.33, the plain average"], correct: 1, why: "The deterministic mixture is Σ β·ā = 0.5·2 + 0.3·0 + 0.2·(−1) = 0.8. Replay would return 2." },
      { q: "Why can averaging retrieved actions fail around an obstacle?", options: ["The weights do not sum to one", "Opposite detours cancel into an action no demonstration took", "Retrieval uses too few records", "The kernel width is always too small"], correct: 1, why: "Averaging needs compatible action coordinates. Records passing above and below cancel sideways, producing a straight action into the obstacle (X4 §3.1)." },
      { q: "In ICRT's ablation, what happened when training used only the DROID subset?", options: ["It matched the full model", "It improved on poking only", "It failed every test task", "It needed twice as many prompts"], correct: 2, why: "DROID scenes mostly admit one task, so the model can ignore the prompt; ICRT (DROID) scored 0% on all tasks, while multi-task scenes taught prompt use (arXiv 2408.15980)." },
      { q: "Which test shows that a policy's behavior depends on the demonstration?", options: ["Report success with the original demonstration", "Swap in a demo of another feasible behavior, all else fixed", "Add more demonstrations of the same order", "Evaluate on a new robot"], correct: 1, why: "A meaning-changing intervention with checkpoint, scene and executor fixed isolates use of teaching; success alone can come from a scene prior (X4 §7.1, Table 17)." }
    ],
    cards: [
      { front: "What stays fixed in in-context learning for robots?", back: "The deployed neural parameters θ. Supplied evidence, recurrent state or retrieved episodes change instead.", ref: "X4 §2.2 eq. 3" },
      { front: "Name the four method families by their intermediate.", back: "Context-conditioned policies (actions), geometric transfer (motion reference), world-model-based control (predicted future), skill and agent execution (execution specification).", ref: "X4 Table 2" },
      { front: "What does REGENT blend, and how?", back: "The nearest retrieved action and the transformer's output, weighted e^(−λd) and 1 − e^(−λd) by distance to the nearest retrieved state.", ref: "arXiv 2412.04759 eq. 1" },
      { front: "What did RICL change on eight new tasks with 20 demos each?", back: "Full-task success rose from 2.5% for π0-FAST-DROID to 31.25%, with no weight update.", ref: "arXiv 2508.02062" },
      { front: "Why does ICRT compute the loss only after the prompt?", back: "Loss on prompt actions forces unconditional prediction there; with it, average success fell from 79.2% to 22.5%.", ref: "arXiv 2408.15980" },
      { front: "What are Instant Policy's pseudo-demonstrations?", back: "Procedurally generated simulated trajectories that perform arbitrary but consistent pseudo-tasks, used as the only training data.", ref: "arXiv 2411.12633" },
      { front: "What separated seen and unseen tasks in S1's scaling study?", back: "On unseen tasks demonstration prompting rose from 1% to 66%, language prompting from 0% to 9%.", ref: "X4 §4.2, Fig. 15" }
    ],
    terms: {
      "in-context-learning": { name: "in-context learning", aliases: ["ICL", "in-context imitation learning", "ICL for robots"], group: "learning", def: "Changing deployed robot behavior with new evidence, such as demonstrations, corrections or interaction history, supplied as context, without another task-specific update to neural parameters.", note: "One-shot names the amount of teaching, not the mechanism: one demonstration can also drive a gradient update, as in meta-imitation.", ref: "X4 §1, §2.2", scene: "system", focus: ["data-human", "data-robot", "action-head"], look: "a demonstration entering a frozen policy", uses: [] },
      "contextual-adaptation": { name: "contextual adaptation", aliases: ["fixed-parameter adaptation", "parameter adaptation"], group: "learning", def: "Adaptation stored in the policy's inputs: supplied evidence, recurrent state or retrieved episodes change while deployed neural parameters stay fixed. Parameter adaptation instead updates a neural component.", note: "Test-time training that updates only a fast-weight subset is still parameter adaptation, even with a frozen backbone.", ref: "X4 §2.2 eq. 3, Fig. 6", scene: "system", focus: ["replay-buffer", "policy-update", "action-head"], look: "context changing, weights frozen", uses: ["in-context-learning"] },
      "support-demonstration": { name: "support demonstration", aliases: ["prompt demonstration", "context demonstration", "support set"], group: "learning", sym: "𝒟ˢ", symTex: "\\mathcal{D}^{s}", def: "A demonstration supplied as context to specify the task; in training, the paired execution whose actions are supervised is the query.", note: "Support and query may differ in objects, timing or body; the pairing rule decides which distinction the support can teach.", ref: "X4 Table 1, eq. 21", scene: "system", focus: ["data-human", "data-robot"], look: "a demonstration handed to the robot", uses: ["in-context-learning"] },
      "action-reuse": { name: "action reuse", aliases: ["retrieve-and-play", "nonparametric action reuse", "nearest-neighbor replay"], group: "learning", sym: "β", symTex: "\\beta_{tj}", def: "A nonparametric policy that returns a weighted mixture of the action blocks stored with the records selected for the current query; nearest-neighbor replay puts weight one on one record.", note: "Averaging needs compatible continuous action coordinates; two opposite modes can average into an action no demonstration took.", ref: "X4 §3.1 eq. 5", scene: "system", focus: ["replay-buffer", "action-chunk"], look: "stored actions weighted by closeness", uses: ["support-demonstration", "mode-averaging"] },
      "demonstration-correspondence": { name: "demonstration correspondence", aliases: ["correspondence", "temporal alignment", "phase alignment"], group: "learning", def: "Relating demonstrated objects, contacts, phases or commands to their executable counterparts in the current scene, so the teaching binds to what the robot can act on.", note: "Temporal alignment says when an example applies; spatial correspondence says where its action should be realized.", ref: "X4 §2.3, §3.1, §3.5", scene: "robot", focus: ["object", "human-hand", "target-pose"], look: "demo parts matched to scene parts", uses: ["support-demonstration"] },
      "geometric-demonstration-transfer": { name: "geometric demonstration transfer", aliases: ["demonstration retargeting", "object-relative transfer"], group: "learning", def: "Reconstructing a demonstrated motion or contact reference, aligning or retargeting it to the current scene, and executing that reference by tracking or replay.", note: "Its assumption is inspectable: after alignment the matched interaction must still apply; shape change and lost contact break it.", ref: "X4 §3.2 eqs. 7–8", scene: "robot", focus: ["trajectory", "object", "end-effector"], look: "a demonstrated path moved onto a new object", uses: ["demonstration-correspondence"] },
      "pseudo-demonstration": { name: "pseudo-demonstration", aliases: ["pseudo-task"], group: "data", def: "A procedurally generated simulated trajectory that performs an arbitrary but consistent pseudo-task, used to train in-context imitation without real task data.", note: "The weights must encode how to read context, not task policies, so the trajectories need not be dynamically feasible.", ref: "arXiv 2411.12633", scene: "system", focus: ["data-sim"], look: "simulated trajectories of made-up tasks", uses: ["in-context-learning"] },
      "context-intervention": { name: "context intervention", aliases: ["teaching intervention", "counterfactual demonstration"], group: "eval", def: "An evaluation that changes only the supplied evidence, by removing it, replacing it with another feasible behavior, or restyling it, while checkpoint, scene and executor stay fixed.", note: "High success in a scene that admits one plausible behavior can hide weak use of teaching.", ref: "X4 §7.1, Table 17", scene: "system", focus: ["data-human", "action-head", "verifier"], look: "the same scene with swapped demonstrations", uses: ["in-context-learning", "support-demonstration"] }
    },
    symbols: [
      { id: "ctx", tex: "C_t", glyph: "Cₜ", kind: "Signals", meaning: "policy context at decision t: supplied task evidence and retained interaction", short: "policy context", first: "b6", read: "C sub t", papers: "X4: C_t" },
      { id: "hobs", tex: "h_t", glyph: "hₜ", kind: "Signals", meaning: "observation–action history of the current attempt, (o₁, a₁, …, oₜ)", short: "attempt history", first: "b6", read: "h sub t", papers: "X4: h_t" },
      { id: "theta-dep", tex: "\\theta", glyph: "θ", kind: "Parameters", meaning: "deployed neural parameters of all components; fixed during in-context adaptation", short: "deployed parameters", first: "b6", read: "theta", papers: "X4: θ, θ₀" },
      { id: "rctx", tex: "\\mathbf{r}_t", glyph: "𝐫ₜ", kind: "Signals", meaning: "interpreted representation of history and context used by the action generator", short: "context representation", first: "b6", read: "bold r sub t", papers: "X4: r_t" },
      { id: "Ectx", tex: "E^{c}_{\\theta}", glyph: "Eᶜ_θ", kind: "Functions", meaning: "context interpreter", short: "context interpreter", first: "b6", read: "E c theta", papers: "X4: E^c_θ" },
      { id: "qact", tex: "q^{a}_{\\theta}", glyph: "qᵃ_θ", kind: "Functions", meaning: "action generator conditioned on the interpreted context", short: "action generator", first: "b6", read: "q a theta", papers: "X4: q^a_θ" },
      { id: "Dsup", tex: "\\mathcal{D}^{s}", glyph: "𝒟ˢ", kind: "Sets", meaning: "support demonstration supplied as context", short: "support demonstration", first: "b6", read: "script D s", papers: "X4: D^s · ICRT: prompt trajectories · Instant Policy: context C" },
      { id: "dsi", tex: "d^{s}_{i}", glyph: "dˢᵢ", kind: "Signals", meaning: "i-th element of the support demonstration (an image or an observation–action record)", short: "demo element", first: "b6", read: "d s sub i", papers: "X4: d^s_i" },
      { id: "Ldemo", tex: "L", glyph: "L", kind: "Parameters", meaning: "number of elements in the support demonstration", short: "demo length", first: "b6", read: "L", papers: "X4: L · Instant Policy: L waypoints" },
      { id: "alpha-demo", tex: "\\alpha_{ti}", glyph: "αₜᵢ", kind: "Signals", meaning: "attention weight on demonstration element i at decision t", short: "attention on demo element", first: "b6", read: "alpha t i", papers: "X4: α_ti" },
      { id: "compat", tex: "s_{\\theta}", glyph: "s_θ", kind: "Functions", meaning: "learned compatibility score between the history and a demonstration element or stored record", short: "compatibility score", first: "b6", read: "s theta", papers: "X4: s_θ" },
      { id: "edemo", tex: "e_{\\theta}", glyph: "e_θ", kind: "Functions", meaning: "encoder of one demonstration element", short: "element encoder", first: "b6", read: "e theta", papers: "X4: e_θ" },
      { id: "beta-ret", tex: "\\beta_{tj}", glyph: "βₜⱼ", kind: "Signals", meaning: "query-dependent weight of stored record j; nonnegative, sums to one", short: "record weight", first: "b6", read: "beta t j", papers: "X4: β_tj · VINN: softmin of embedding distance" },
      { id: "abar-j", tex: "\\bar{\\mathbf{a}}_{j}", glyph: "𝐚̄ⱼ", kind: "Signals", meaning: "action block stored in demonstration record j", short: "stored action block", first: "b6", read: "a bar j", papers: "X4: Ā_j" },
      { id: "Jsel", tex: "\\mathcal{J}_t", glyph: "𝒥ₜ", kind: "Sets", meaning: "indices of the records selected for the query at decision t", short: "selected records", first: "b6", read: "script J sub t", papers: "X4: J_t" },
      { id: "zeta-md", tex: "\\zeta_{i}", glyph: "ζᵢ", kind: "Signals", meaning: "motion descriptor of demonstration element i (hand pose, object-relative pose or contact)", short: "motion descriptor", first: "b6", read: "zeta sub i", papers: "X4: ζ_i" },
      { id: "Emd", tex: "E^{m}_{\\theta}", glyph: "Eᵐ_θ", kind: "Functions", meaning: "motion-descriptor extractor", short: "descriptor extractor", first: "b6", read: "E m theta", papers: "X4: E^m_θ" },
      { id: "Brob", tex: "B", glyph: "B", kind: "Robot", meaning: "robot description: kinematics and control constraints used for retargeting", short: "robot description", first: "b6", read: "B", papers: "X4: B" },
      { id: "gspec", tex: "\\mathbf{g}", glyph: "𝐠", kind: "Signals", meaning: "execution specification: motion reference, skill sequence, program or tool call", short: "execution specification", first: "b6", read: "bold g", papers: "X4: g" },
      { id: "kappa-ex", tex: "\\kappa", glyph: "κ", kind: "Functions", meaning: "executor that realizes an execution specification as actions", short: "executor", first: "b6", read: "kappa", papers: "X4: κ" },
      { id: "pv", tex: "p^{v}_{\\theta}", glyph: "pᵛ_θ", kind: "Functions", meaning: "context-conditioned predictor of the anticipated future", short: "future predictor", first: "b6", read: "p v theta", papers: "X4: p^v_θ" },
      { id: "qv", tex: "q^{v}_{\\theta}", glyph: "qᵛ_θ", kind: "Functions", meaning: "future-conditioned action decoder", short: "future-conditioned decoder", first: "b6", read: "q v theta", papers: "X4: q^v_θ" },
      { id: "fspec", tex: "f_{\\theta}", glyph: "f_θ", kind: "Functions", meaning: "generator of the execution specification from context and history", short: "specification generator", first: "b6", read: "f theta", papers: "X4: f_θ" }
    ],
    ledger: [
      { where: "Topic 10 · rules", source: "X4 writes the proposed action block as A_t = (â_{t|t}, …, â_{t+H−1|t})", page: "The site writes the house chunk 𝐚_{t:t+H}", why: "House notation for action chunks.", kind: "Our choice" },
      { where: "Topic 10 · rules", source: "X4 writes the interpreted representation as r_t and the execution specification as g", page: "The site writes bold 𝐫ₜ and bold 𝐠", why: "Plain rₜ is the reward and g the grasp in house notation.", kind: "Our choice" },
      { where: "Topic 10 · world-model rule", source: "X4 eq. 9 writes the anticipated future as v⁺", page: "The site writes o′, the house future observation", why: "o′ already means the predicted future on this site.", kind: "Our choice" },
      { where: "Topic 10 · worked example", source: "VINN weights neighbors by exp(−‖e − eᵢ‖), with no width", page: "The site adds a kernel width σ; σ = 1 recovers VINN", why: "Shows how sharpening moves the mixture toward replay.", kind: "Our choice" },
      { where: "Topic 10 · playground 1", source: "REGENT and RICL retrieve from image or state embeddings and blend with a trained transformer or VLA", page: "2-D positions, four scripted demonstrations, and a straight-to-goal generator standing in for pretrained competence", why: "Isolates what replay, mixing and blending do near and far from the data.", kind: "Simplified" },
      { where: "Topic 10 · playground 2", source: "Attention scores are learned over images or sensorimotor records", page: "Three hand-set features plus a count of gripper events; score is the negative squared distance", why: "Makes phase aliasing and the role of history visible.", kind: "Simplified" },
      { where: "Topic 10 · playground 3", source: "X4 §7.1 proposes meaning-changing and meaning-preserving interventions on real policies", page: "A toy policy that reads the demo with probability w; grasps succeed independently", why: "Shows why interpretation and physical completion need separate readouts.", kind: "Simplified" },
      { where: "Topic 10 · T-OSIL", source: "X4 Table 3 cites TOSIL as [21, 158], and [21] is OSVI-WM", page: "The T-OSIL card uses Dasari & Gupta, arXiv 2011.05970 ([158])", why: "The attention-over-demonstration method is [158].", kind: "Sources disagree" }
    ]
  });
})();
