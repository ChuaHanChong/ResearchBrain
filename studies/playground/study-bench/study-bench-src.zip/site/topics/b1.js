/* Topic 05 · Behavior cloning and why it breaks. Sources: X2 §4 (eq. 18, Fig. 20), P01 eq. 3 and §6.1.2 (Fig. 15),
   method cards: DAgger (tier 1), BC-Z (tier 1), HG-DAgger, ThriftyDAgger, BeT, one-shot imitation, end-to-end visuomotor policies. */
(function () {
  "use strict";
  var RB = window.RB;

  /* RB.bindSeg passes a string to a callback that reads .value, so segments are wired directly (same as topic a3) */
  function onSeg(root, id, cb) { StudyBench.segmented(root.querySelector("#" + id), function (v) { cb(v); }); }
  function font(kind) { return getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); }

  /* =====================================================================================
     Playground 1 · mean collapse on a left-or-right task, and BeT's bins + offsets
     Observation o = where the gripper starts across the table (−1 … 1).
     Action g = the lateral position at which it passes the block (−1 … 1); |g| < 0.33 hits the block.
     ===================================================================================== */
  var BLOCK = 0.33, NDEMO = 60, NTEST = 21;
  function makeDemos(share, seed) {
    var R = RB.rng(seed), d = [];
    for (var i = 0; i < NDEMO; i++) {
      var o = -1 + 2 * (i + R()) / NDEMO, left;
      if (o < -0.5) left = true; else if (o > 0.5) left = false; else left = R() < share;
      var g = (left ? -0.62 : 0.62) + 0.08 * o + 0.05 * R.normal();
      d.push([o, g]);
    }
    return d;
  }
  /* least-squares cubic g = c0 + c1 o + c2 o² + c3 o³ (normal equations, Gaussian elimination) */
  function fitCubic(d) {
    var n = 4, A = [], b = [0, 0, 0, 0], i, j, k;
    for (i = 0; i < n; i++) { A.push([0, 0, 0, 0]); }
    d.forEach(function (p) { var ph = [1, p[0], p[0] * p[0], p[0] * p[0] * p[0]]; for (i = 0; i < n; i++) { b[i] += ph[i] * p[1]; for (j = 0; j < n; j++) A[i][j] += ph[i] * ph[j]; } });
    for (i = 0; i < n; i++) A[i][i] += 1e-6;
    for (i = 0; i < n; i++) {
      var piv = i; for (k = i + 1; k < n; k++) if (Math.abs(A[k][i]) > Math.abs(A[piv][i])) piv = k;
      var t = A[i]; A[i] = A[piv]; A[piv] = t; var tb = b[i]; b[i] = b[piv]; b[piv] = tb;
      for (k = i + 1; k < n; k++) { var f = A[k][i] / A[i][i]; for (j = i; j < n; j++) A[k][j] -= f * A[i][j]; b[k] -= f * b[i]; }
    }
    var c = [0, 0, 0, 0];
    for (i = n - 1; i >= 0; i--) { var s = b[i]; for (j = i + 1; j < n; j++) s -= A[i][j] * c[j]; c[i] = s / A[i][i]; }
    return function (o) { return c[0] + c[1] * o + c[2] * o * o + c[3] * o * o * o; };
  }
  /* BeT-style head: k-means bins over actions, a bin classifier given o (kernel-weighted counts), and a per-bin offset */
  function fitBins(d, k) {
    var gs = d.map(function (p) { return p[1]; }).sort(function (a, b) { return a - b; }), c = [], i, it;
    for (i = 0; i < k; i++) c.push(gs[Math.min(gs.length - 1, Math.floor((i + 0.5) / k * gs.length))]);
    var lab = [];
    for (it = 0; it < 15; it++) {
      lab = d.map(function (p) { var best = 0; for (var j = 1; j < k; j++) if (Math.abs(p[1] - c[j]) < Math.abs(p[1] - c[best])) best = j; return best; });
      for (i = 0; i < k; i++) { var s = 0, n = 0; d.forEach(function (p, q) { if (lab[q] === i) { s += p[1]; n++; } }); if (n) c[i] = s / n; }
    }
    function probs(o) {
      var w = c.map(function () { return 1e-3; }), off = c.map(function () { return 0; }), ws = c.map(function () { return 1e-9; });
      d.forEach(function (p, q) { var z = (o - p[0]) / 0.15, wt = Math.exp(-0.5 * z * z); w[lab[q]] += wt; off[lab[q]] += wt * (p[1] - c[lab[q]]); ws[lab[q]] += wt; });
      var Z = w.reduce(function (a, v) { return a + v; }, 0);
      return { p: w.map(function (v) { return v / Z; }), off: off.map(function (v, j) { return v / ws[j]; }) };
    }
    return { centers: c, sample: function (o, R) { var pr = probs(o), u = R(), j = 0, acc = pr.p[0]; while (u > acc && j < k - 1) { j++; acc += pr.p[j]; } return c[j] + pr.off[j]; }, probs: probs };
  }

  function mountCollapse(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row"><div class="rb-stack"><span class="sb-caption">Policy head</span>' + RB.seg({ id: id + "-head", label: "Policy head", value: "mse", options: [{ value: "mse", label: "Regression" }, { value: "bet", label: "BeT bins" }] }) + "</div>" +
      RB.slider({ id: id + "-k", label: "Bins k", min: 1, max: 6, step: 1, value: 2 }) +
      RB.slider({ id: id + "-share", label: "Share passing left", min: 0, max: 1, step: 0.05, value: 0.5, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Resample demos</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-fit" aria-label="Scatter of demonstrated actions against start position, with what the policy learned"></canvas><figcaption class="sb-caption">Gray dots = demonstrations. Red band = actions that hit the block. Look where the learned line or sampled dots fall for starts near the middle.</figcaption></figure>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-top" aria-label="Top view: 21 gripper paths from different start positions around a block to a target"></canvas><figcaption class="sb-caption">Top view of 21 test starts. Each path passes the block at the lateral position the policy chose, then goes to the target.</figcaption></figure></div>' +
      RB.readouts([{ id: "goal", k: "Reach the target" }, { id: "hit", k: "Into the block" }, { id: "mid", k: "Action at o = 0" }]) +
      '<p class="sb-caption" data-note></p>' +
      RB.legend([{ c: "ink-3", label: "demonstration", kind: "dot" }, { c: "accent", label: "regression fit", kind: "line" }, { c: "data-1", label: "path passes", kind: "line" }, { c: "bad", label: "path hits the block", kind: "line" }]);
    var cvF = body.querySelector("#" + id + "-fit"), cvT = body.querySelector("#" + id + "-top"), note = body.querySelector("[data-note]");
    var head = "mse", k = 2, share = 0.5, seed = 11, demos = [], model = null, fitF = null, test = [];
    var NOTES = {
      mse: "Squared-error regression learns the mean action for each start. Where demonstrators split left and right, the mean passes through the block (X2 §4, Fig. 20).",
      bet: "BeT clusters the demonstrated actions into k bins, predicts which bin to use, then adds a learned offset. Sampling a bin picks one mode (arXiv 2206.11251)."
    };
    var W = 400, H = 300;
    function run() {
      demos = makeDemos(share, seed);
      fitF = fitCubic(demos);
      model = head === "bet" ? fitBins(demos, k) : null;
      var R = RB.rng(seed * 7 + k), goal = 0, hit = 0; test = [];
      for (var i = 0; i < NTEST; i++) {
        var o = -0.95 + 1.9 * i / (NTEST - 1), g = head === "mse" ? fitF(o) : model.sample(o, R), bad = Math.abs(g) < BLOCK;
        test.push({ o: o, g: g, bad: bad }); if (bad) hit++; else goal++;
      }
      RB.setRO(body, "goal", goal + "/" + NTEST);
      RB.setRO(body, "hit", hit + "/" + NTEST);
      RB.setRO(body, "mid", RB.fmt(head === "mse" ? fitF(0) : model.sample(0, RB.rng(seed)), 2));
      note.textContent = NOTES[head];
      body.querySelector("#" + id + "-k").disabled = head === "mse";
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cvF, W, H), sx = function (o) { return 44 + (o + 1) / 2 * (W - 60); }, sy = function (g) { return 16 + (1 - (g + 1) / 2) * (H - 56); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.fillStyle = P["bad-soft"]; c.fillRect(sx(-1), sy(BLOCK), sx(1) - sx(-1), sy(-BLOCK) - sy(BLOCK));
      c.strokeStyle = P.line; c.lineWidth = 1; c.beginPath(); c.moveTo(sx(-1), sy(0)); c.lineTo(sx(1), sy(0)); c.moveTo(sx(0), sy(-1)); c.lineTo(sx(0), sy(1)); c.stroke();
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + font("mono");
      c.fillText("start position o", sx(0.15), H - 12); c.fillText("−1", sx(-1) - 6, H - 24); c.fillText("+1", sx(1) - 14, H - 24);
      c.save(); c.translate(14, sy(-0.6)); c.rotate(-Math.PI / 2); c.fillText("action g: pass at", 0, 0); c.restore();
      c.fillText("right", 18, sy(0.62) + 4); c.fillText("left", 18, sy(-0.62) + 4); c.fillStyle = P.bad; c.fillText("block", sx(-0.98), sy(0) - 4);
      demos.forEach(function (p) { c.fillStyle = P["ink-3"]; c.beginPath(); c.arc(sx(p[0]), sy(p[1]), 3, 0, Math.PI * 2); c.fill(); });
      if (head === "mse") {
        c.strokeStyle = P.accent; c.lineWidth = 2.5; c.beginPath();
        for (var o = -1; o <= 1.0001; o += 0.02) { var y = sy(Math.max(-1, Math.min(1, fitF(o)))); if (o === -1) c.moveTo(sx(o), y); else c.lineTo(sx(o), y); }
        c.stroke(); c.lineWidth = 1;
      } else {
        c.setLineDash([4, 4]); c.strokeStyle = P["ink-3"];
        model.centers.forEach(function (g) { c.beginPath(); c.moveTo(sx(-1), sy(g)); c.lineTo(sx(1), sy(g)); c.stroke(); });
        c.setLineDash([]); c.fillStyle = P["ink-3"]; c.fillText("bin centers", sx(0.55), sy(model.centers[model.centers.length - 1]) - 5);
      }
      test.forEach(function (t) { c.fillStyle = t.bad ? P.bad : P["data-1"]; c.beginPath(); c.arc(sx(t.o), sy(Math.max(-1, Math.min(1, t.g))), 4.5, 0, Math.PI * 2); c.fill(); });
      /* top view */
      var d = RB.canvas(cvT, W, H), tx = function (x) { return W / 2 + x * (W / 2 - 30); }, ty = function (y) { return H - 24 - y * (H - 60); };
      d.fillStyle = P.surface; d.fillRect(0, 0, W, H);
      d.strokeStyle = P["bench-grid"] || P.line; d.lineWidth = 1;
      for (var gx = 0; gx <= W; gx += 40) { d.beginPath(); d.moveTo(gx, 0); d.lineTo(gx, H); d.stroke(); }
      d.fillStyle = P["surface-strong"]; d.strokeStyle = P["line-strong"];
      d.fillRect(tx(-0.3), ty(0.66), tx(0.3) - tx(-0.3), ty(0.44) - ty(0.66)); d.strokeRect(tx(-0.3), ty(0.66), tx(0.3) - tx(-0.3), ty(0.44) - ty(0.66));
      d.fillStyle = P["ink-2"]; d.font = "500 11px " + font("mono"); d.fillText("block", tx(-0.09), ty(0.53));
      d.fillStyle = P["good-soft"]; d.beginPath(); d.arc(tx(0), ty(1), 12, 0, Math.PI * 2); d.fill(); d.fillStyle = P["ink-2"]; d.fillText("target", tx(0) + 16, ty(1) + 4);
      test.forEach(function (t) {
        var g = Math.max(-1, Math.min(1, t.g));
        d.strokeStyle = t.bad ? P.bad : P["data-1"]; d.globalAlpha = 0.75; d.lineWidth = 1.6; d.beginPath();
        d.moveTo(tx(t.o), ty(0)); d.lineTo(tx(g), ty(0.4));
        if (t.bad) { d.lineTo(tx(g), ty(0.44)); d.stroke(); d.globalAlpha = 1; d.fillStyle = P.bad; d.beginPath(); d.arc(tx(g), ty(0.44), 4, 0, Math.PI * 2); d.fill(); return; }
        d.lineTo(tx(g), ty(0.7)); d.lineTo(tx(0), ty(1)); d.stroke(); d.globalAlpha = 1;
      });
      d.lineWidth = 1;
      test.forEach(function (t) { d.fillStyle = P.ink; d.beginPath(); d.arc(tx(t.o), ty(0), 3, 0, Math.PI * 2); d.fill(); });
      d.fillStyle = P["ink-2"]; d.fillText("starts o", 8, ty(0) - 8);
    }
    onSeg(body, id + "-head", function (v) { head = v; run(); });
    RB.bindSlider(body, id + "-k", null, function (v) { k = v; run(); });
    RB.bindSlider(body, id + "-share", function (v) { return (+v).toFixed(2); }, function (v) { share = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { seed++; run(); });
    run();
    RB.onTheme(draw);
    return { state: function () { var h = 0; test.forEach(function (t) { if (t.bad) h++; }); return { head: head, k: k, share: share, hits: h }; } };
  }

  /* =====================================================================================
     Playground 2 · covariate shift: BC vs DAgger vs robot-gated corrections on a lane-keeping toy
     State e = lateral offset of the gripper from the demonstrated path; walls at |e| = 0.3.
     Expert: a* = −0.5 e. Learner: kernel regression on its dataset (nearest label beyond the data),
     plus an error ε · (1 + d/h) · N(0,1) that grows with the distance d to the nearest training state.
     ===================================================================================== */
  var NB = 400, LO = -0.4, BW = 0.8 / NB, WALL = 0.3, TT = 100, SW = 0.006, HB = 0.02, GAIN = 0.5, NEVAL = 20, NCOLLECT = 2;
  function bin(e) { return Math.max(0, Math.min(NB - 1, Math.floor((e - LO) / BW))); }
  function Data() { this.cnt = new Float64Array(NB); this.sum = new Float64Array(NB); this.n = 0; }
  Data.prototype.add = function (e) { var b = bin(e); this.cnt[b]++; this.sum[b] += -GAIN * e; this.n++; };
  Data.prototype.fit = function () {
    var c = this.cnt, s = this.sum, i, j, last;
    this.dist = new Float64Array(NB); last = -1e9;
    for (i = 0; i < NB; i++) { if (c[i]) last = i; this.dist[i] = (i - last) * BW; }
    last = 1e9;
    for (i = NB - 1; i >= 0; i--) { if (c[i]) last = i; this.dist[i] = Math.min(this.dist[i], (last - i) * BW); }
    this.f = new Float64Array(NB); var r = Math.ceil(3 * HB / BW), has = new Uint8Array(NB);
    for (i = 0; i < NB; i++) {
      var num = 0, den = 0;
      for (j = Math.max(0, i - r); j <= Math.min(NB - 1, i + r); j++) { if (!c[j]) continue; var dd = (i - j) * BW, w = Math.exp(-dd * dd / (2 * HB * HB)); num += w * s[j]; den += w * c[j]; }
      if (den > 1e-9) { this.f[i] = num / den; has[i] = 1; }
    }
    var lv = null; for (i = 0; i < NB; i++) { if (has[i]) lv = this.f[i]; else if (lv !== null) { this.f[i] = lv; has[i] = 2; } }
    lv = null; for (i = NB - 1; i >= 0; i--) { if (has[i] === 1) lv = this.f[i]; else if (!has[i] && lv !== null) this.f[i] = lv; }
  };
  function addDemos(D, n, seed) { var R = RB.rng(seed); for (var k = 0; k < n; k++) { var e = SW * R.normal(); for (var t = 0; t < TT; t++) { D.add(e); e = e - GAIN * e + SW * R.normal(); } } }
  /* mode: "eval" (learner alone), "dagger" (learner drives, expert labels every state), "gated" (expert takes over on novel states) */
  function laneRollout(D, eps, R, mode, labels) {
    var e = SW * R.normal(), path = [e], off = 0, ok = true, expert = false, taken = [];
    for (var t = 0; t < TT; t++) {
      var b = bin(e), d = D.dist[b], a;
      if (d > HB) off++;
      if (mode === "gated") { if (!expert && d > HB) expert = true; else if (expert && d < HB / 4) expert = false; }
      if (expert) { a = -GAIN * e; labels.push(e); taken.push(t); }
      else { a = D.f[b] + eps * (1 + d / HB) * R.normal(); if (mode === "dagger") labels.push(e); }
      e = e + a + SW * R.normal(); path.push(e);
      if (Math.abs(e) >= WALL) { ok = false; break; }
    }
    return { path: path, ok: ok, off: off, taken: taken };
  }

  function mountShift(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row"><div class="rb-stack"><span class="sb-caption">Training scheme</span>' + RB.seg({ id: id + "-mode", label: "Training scheme", value: "bc", options: [{ value: "bc", label: "BC only" }, { value: "dagger", label: "DAgger" }, { value: "gated", label: "Robot-gated" }] }) + "</div>" +
      RB.slider({ id: id + "-demos", label: "Expert demos", min: 1, max: 50, step: 1, value: 10 }) +
      RB.slider({ id: id + "-eps", label: "Learner error ε", min: 0.004, max: 0.024, step: 0.002, value: 0.016, fmt: function (v) { return (+v).toFixed(3); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Collect and retrain</button><button class="sb-btn" type="button" id="' + id + '-reset">Reset</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Twenty learner rollouts of lateral offset over time, and histograms of training states and visited states"></canvas><figcaption class="sb-caption">Top: 20 rollouts of the learner alone; red ones hit a wall. Bottom: where the training states are (filled) against where the learner goes (outline). The gap is covariate shift.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "succ", k: "Rollouts that stay in the lane" }, { id: "off", k: "Steps off the training states" }, { id: "labels", k: "Expert labels in 𝒟" }, { id: "iter", k: "Round" }, { id: "hist", k: "Stay-in-lane by round" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "stays in the lane", kind: "line" }, { c: "bad", label: "hits a wall", kind: "line" }, { c: "data-3", label: "training states", kind: "area" }, { c: "data-2", label: "visited states", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), goBtn = body.querySelector("#" + id + "-go");
    var mode = "bc", demos = 10, eps = 0.016, D, iter = 0, hist = [], runs = [], visited = new Float64Array(NB), collectSeed = 5, W = 520, H = 380;
    var NOTES = {
      bc: "Behavior cloning trains once on expert states only. The expert rarely leaves the center, so more demos add almost no new states (DAgger paper: supervised learning stagnates with more data).",
      dagger: "DAgger rolls out the learner, asks the expert to label every state it visited, adds them to 𝒟 and retrains (arXiv 1011.0686).",
      gated: "Robot-gated: the learner asks for help only when a state is far from its data. The expert takes over, and only those states are labeled (ThriftyDAgger's novelty gate, arXiv 2109.08273)."
    };
    function reset() { D = new Data(); addDemos(D, demos, 1); D.fit(); iter = 0; hist = []; evaluate(); }
    function evaluate() {
      var R = RB.rng(99 + iter), s = 0, off = 0, steps = 0; runs = []; visited = new Float64Array(NB);
      for (var i = 0; i < NEVAL; i++) { var r = laneRollout(D, eps, R, "eval", null); runs.push(r); if (r.ok) s++; off += r.off; steps += r.path.length - 1; r.path.forEach(function (e) { visited[bin(e)]++; }); }
      hist[iter] = s;
      RB.setRO(body, "succ", s + " of " + NEVAL);
      RB.setRO(body, "off", Math.round(100 * off / steps) + "%");
      RB.setRO(body, "labels", String(D.n));
      RB.setRO(body, "iter", String(iter));
      RB.setRO(body, "hist", hist.join(" → "));
      note.textContent = NOTES[mode];
      goBtn.disabled = mode === "bc";
      draw();
    }
    function collect() {
      if (mode === "bc") return;
      var R = RB.rng(collectSeed + iter * 13), labels = [];
      for (var j = 0; j < NCOLLECT; j++) laneRollout(D, eps, R, mode, labels);
      labels.forEach(function (e) { D.add(e); }); D.fit(); iter++; evaluate();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), top = 16, th = 220, sx = function (t) { return 40 + t / TT * (W - 60); }, sy = function (e) { return top + (0.5 - e / (2 * 0.32)) * th; };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      /* lane walls */
      c.fillStyle = P["bad-soft"]; c.fillRect(sx(0), top, sx(TT) - sx(0), sy(WALL) - top); c.fillRect(sx(0), sy(-WALL), sx(TT) - sx(0), top + th - sy(-WALL));
      c.strokeStyle = P["ink-3"]; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(sx(0), sy(0)); c.lineTo(sx(TT), sy(0)); c.stroke(); c.setLineDash([]);
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + font("mono");
      c.fillText("wall", sx(0) + 4, top + 11); c.fillText("wall", sx(0) + 4, top + th - 3); c.fillText("demo path", sx(0) + 4, sy(0) - 30);
      c.fillText("0", sx(0) - 4, top + th + 14); c.fillText("step 100", sx(TT) - 50, top + th + 14);
      runs.forEach(function (r) {
        c.strokeStyle = r.ok ? P["data-1"] : P.bad; c.globalAlpha = 0.6; c.lineWidth = 1.4; c.beginPath();
        r.path.forEach(function (e, t) { var y = sy(Math.max(-0.32, Math.min(0.32, e))); if (t) c.lineTo(sx(t), y); else c.moveTo(sx(t), y); }); c.stroke();
      });
      c.globalAlpha = 1; c.lineWidth = 1;
      /* histograms over e: training states vs visited states */
      var hb = top + th + 26, hh = H - hb - 22, groups = 80, per = NB / groups, dc = [], vc = [], mx1 = 1, mx2 = 1, g, i;
      for (g = 0; g < groups; g++) { var a = 0, v = 0; for (i = 0; i < per; i++) { a += D.cnt[g * per + i]; v += visited[g * per + i]; } dc.push(a); vc.push(v); mx1 = Math.max(mx1, a); mx2 = Math.max(mx2, v); }
      var bx = function (g2) { var e = LO + g2 * per * BW; return sx(0) + (e + 0.32) / 0.64 * (sx(TT) - sx(0)); }, bw = (sx(TT) - sx(0)) / 0.64 * per * BW;
      c.fillStyle = P["data-3"]; c.globalAlpha = 0.55;
      dc.forEach(function (a2, g2) { if (!a2) return; var hgt = Math.max(2, Math.sqrt(a2 / mx1) * hh); c.fillRect(bx(g2), hb + hh - hgt, Math.max(1, bw - 1), hgt); });
      c.globalAlpha = 1; c.strokeStyle = P["data-2"]; c.lineWidth = 1.6; c.beginPath();
      vc.forEach(function (v2, g2) { var hgt = Math.sqrt(v2 / mx2) * hh; var y = hb + hh - hgt; if (g2) c.lineTo(bx(g2), y); else c.moveTo(bx(g2), y); c.lineTo(bx(g2) + bw, y); }); c.stroke(); c.lineWidth = 1;
      c.strokeStyle = P.line; c.beginPath(); c.moveTo(sx(0), hb + hh); c.lineTo(sx(TT), hb + hh); c.stroke();
      c.fillStyle = P["ink-2"]; c.fillText("left wall", sx(0), H - 6); c.fillText("lateral offset", (sx(0) + sx(TT)) / 2 - 40, H - 6); c.fillText("right wall", sx(TT) - 62, H - 6);
    }
    onSeg(body, id + "-mode", function (v) { mode = v; reset(); });
    RB.bindSlider(body, id + "-demos", null, function (v) { demos = v; reset(); });
    RB.bindSlider(body, id + "-eps", function (v) { return (+v).toFixed(3); }, function (v) { eps = v; reset(); });
    goBtn.addEventListener("click", collect);
    body.querySelector("#" + id + "-reset").addEventListener("click", reset);
    reset();
    RB.onTheme(draw);
    return { state: function () { return { mode: mode, iter: iter, demos: demos, eps: eps, succ: hist[iter], labels: D.n }; } };
  }

  /* ---------- concept-card drawings (200×56, token classes only) ---------- */
  var ART = {
    bc: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [[14, 40], [24, 32], [34, 34], [44, 24], [54, 22], [64, 14]].map(function (p) { return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="3" class="rb-f-soft"/>'; }).join("") + '<text x="16" y="54" class="rb-t-mono">(oₜ, aₜ)</text><path d="M80 28 H104" class="rb-s-ink"/><path d="M100 24 L106 28 L100 32" class="rb-s-ink"/><path d="M118 44 Q150 36 188 10" class="rb-s-acc"/><text x="112" y="54" class="rb-t-mono">π_θ(oₜ) ≈ aₜ</text></svg>',
    shift: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 48 Q50 48 60 12 Q70 48 110 48" class="rb-s-acc"/><path d="M60 48 Q110 48 125 26 Q140 48 190 48" class="rb-s-line" stroke-dasharray="4 3"/><text x="36" y="9" class="rb-t-mono">expert</text><text x="136" y="20" class="rb-t-mono">learner</text></svg>',
    compound: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 28 H190" class="rb-s-line" stroke-dasharray="4 3"/><path d="M10 28 Q60 28 90 24 T140 14 T186 4" class="rb-s-acc"/><path d="M60 28 V27 M100 28 V21 M140 28 V14 M180 28 V5" class="rb-s-ink"/><text x="10" y="48" class="rb-t-mono">demo path</text><text x="120" y="48" class="rb-t-mono">gap grows</text></svg>',
    avg: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="86" y="8" width="28" height="18" rx="2" class="rb-f-sunk"/><path d="M100 52 Q60 40 64 8" class="rb-s-line"/><path d="M100 52 Q140 40 136 8" class="rb-s-line"/><path d="M100 52 V28" class="rb-s-acc"/><text x="22" y="20" class="rb-t-mono">left</text><text x="148" y="20" class="rb-t-mono">right</text><text x="108" y="46" class="rb-t-acc">mean</text></svg>',
    dagger: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="2" y="18" width="56" height="20" rx="3" class="rb-f-surface"/><text x="30" y="32" text-anchor="middle" class="rb-t-mono">run π̂</text><rect x="68" y="18" width="64" height="20" rx="3" class="rb-f-soft"/><text x="100" y="32" text-anchor="middle" class="rb-t-mono">π* label</text><rect x="142" y="18" width="56" height="20" rx="3" class="rb-f-sunk"/><text x="170" y="32" text-anchor="middle" class="rb-t-mono">𝒟∪𝒟ᵢ</text><path d="M58 28 H68 M132 28 H142" class="rb-s-ink"/><path d="M170 38 Q170 52 100 52 Q30 52 30 38" class="rb-s-acc"/><text x="100" y="12" text-anchor="middle" class="rb-t-mono">retrain, repeat</text></svg>',
    gate: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M8 18 H192" class="rb-s-acc" stroke-dasharray="4 3"/><text x="84" y="12" class="rb-t-acc">threshold</text><path d="M8 48 L30 44 L46 46 L60 12 L72 42 L100 46 L130 42 L150 44 L170 12 L182 44 L192 46" class="rb-s-line"/><circle cx="60" cy="12" r="4" class="rb-f-acc"/><circle cx="170" cy="12" r="4" class="rb-f-acc"/><text x="88" y="38" class="rb-t-mono">novelty</text></svg>',
    bins: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 34 H190" class="rb-s-line"/>' + [30, 80, 150].map(function (x) { return '<rect x="' + (x - 14) + '" y="26" width="28" height="16" rx="2" class="rb-f-soft"/><circle cx="' + x + '" cy="34" r="3" class="rb-f-acc"/>'; }).join("") + '<path d="M150 34 Q156 16 164 20" class="rb-s-acc"/><text x="100" y="12" class="rb-t-mono">bin + offset</text><text x="12" y="53" class="rb-t-mono">k-means action bins</text></svg>',
    task: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="2" y="6" width="62" height="18" rx="3" class="rb-f-surface"/><text x="33" y="19" text-anchor="middle" class="rb-t-mono">sentence</text><rect x="2" y="32" width="62" height="18" rx="3" class="rb-f-surface"/><text x="33" y="45" text-anchor="middle" class="rb-t-mono">video</text><path d="M64 15 L86 27 M64 41 L86 29" class="rb-s-ink"/><circle cx="96" cy="28" r="10" class="rb-f-soft"/><text x="96" y="32" text-anchor="middle" class="rb-t-acc">z</text><path d="M106 28 H126" class="rb-s-ink"/><rect x="128" y="16" width="70" height="24" rx="3" class="rb-f-sunk"/><text x="163" y="32" text-anchor="middle" class="rb-t-mono">FiLM π_θ</text></svg>'
  };

  /* ---------- worked example: expected steps off the demonstrations (computed here) ---------- */
  var EPS = 0.01;
  function cum(t) { var s = 0; for (var k = 1; k <= t; k++) s += 1 - Math.pow(1 - EPS, k); return s; }
  var WX = function (t) { return 70 + t / 200 * 450; }, WY = function (v) { return 200 - v / 120 * 170; };
  function curve(t0, t1) { var d = ""; for (var t = t0; t <= t1; t += 2) d += (t === t0 ? "M" : "L") + WX(t).toFixed(1) + " " + WY(cum(t)).toFixed(1) + " "; return d; }
  var WE_FIG = '<svg viewBox="0 0 560 240" role="img" aria-label="Expected steps off the demonstrations against episode length: the behavior cloning curve bends upward to 37 at 100 steps and 114 at 200 steps, while the non-compounding line reaches only 1 and 2">' +
    '<g class="rb-s-line"><line x1="70" y1="200" x2="530" y2="200"/><line x1="70" y1="200" x2="70" y2="24"/>' + [30, 60, 90, 120].map(function (v) { return '<line x1="66" x2="530" y1="' + WY(v) + '" y2="' + WY(v) + '" stroke-dasharray="2 4"/>'; }).join("") + "</g>" +
    '<g class="rb-t-mono">' + [0, 30, 60, 90, 120].map(function (v) { return '<text x="60" y="' + (WY(v) + 4) + '" text-anchor="end">' + v + "</text>"; }).join("") + [0, 50, 100, 150, 200].map(function (t) { return '<text x="' + WX(t) + '" y="218" text-anchor="middle">' + t + "</text>"; }).join("") +
    '<text x="300" y="236" text-anchor="middle">episode length T (steps)</text><text x="14" y="18">expected steps off the demos</text></g>' +
    '<g data-on="2+"><text x="' + WX(50) + '" y="' + (WY(cum(50)) - 44) + '" text-anchor="middle" class="rb-t-mono">on track: 0.61</text><line x1="' + WX(50) + '" x2="' + WX(50) + '" y1="' + (WY(cum(50)) - 38) + '" y2="200" class="rb-s-line" stroke-dasharray="3 3"/><text x="' + WX(100) + '" y="' + (WY(cum(100)) - 44) + '" text-anchor="middle" class="rb-t-mono">on track: 0.37</text></g>' +
    '<g data-on="3+"><path d="' + curve(0, 100) + '" class="rb-s-acc" fill="none"/><circle cx="' + WX(100) + '" cy="' + WY(cum(100)) + '" r="5" class="rb-f-acc"/><text x="' + (WX(100) + 10) + '" y="' + (WY(cum(100)) + 4) + '" class="rb-t-acc">37.2</text></g>' +
    '<g data-on="4+"><line x1="' + WX(0) + '" y1="' + WY(0) + '" x2="' + WX(100) + '" y2="' + WY(1) + '" class="rb-s-ink"/><circle cx="' + WX(100) + '" cy="' + WY(1) + '" r="4" class="rb-f-surface"/><text x="' + WX(100) + '" y="' + (WY(1) - 8) + '" text-anchor="middle" class="rb-t-ink">1</text></g>' +
    '<g data-on="5+"><path d="' + curve(100, 200) + '" class="rb-s-acc" fill="none"/><circle cx="' + WX(200) + '" cy="' + WY(cum(200)) + '" r="5" class="rb-f-acc"/><text x="' + (WX(200) - 8) + '" y="' + (WY(cum(200)) - 10) + '" text-anchor="end" class="rb-t-acc">114.3 (BC)</text><line x1="' + WX(100) + '" y1="' + WY(1) + '" x2="' + WX(200) + '" y2="' + WY(2) + '" class="rb-s-ink"/></g>' +
    '<g data-on="6"><text x="' + WX(200) + '" y="' + (WY(2) - 10) + '" text-anchor="end" class="rb-t-ink">2 (DAgger, u = 1)</text></g></svg>';

  RB.topic({
    id: "b1",
    title: "Behavior cloning and why it breaks",
    eyebrow: "Part B · Imitation learning",
    lede: "Behavior cloning copies expert actions with supervised learning. Two failures follow: small errors compound, and averaged demonstrations can point into an obstacle.",
    refs: ["X2 §4, eq. 18", "P01 eq. 3, §6.1.2", "DAgger, arXiv 1011.0686"],
    why: "Almost every modern manipulation policy, from ACT to π0, is trained by behavior cloning (BC) on teleoperated demonstrations. It needs no reward and no risky exploration. But a cloned policy sees its own mistakes, not the expert's states, and it averages demonstrators who disagree. Knowing both failures explains chunking, generative heads and interactive corrections.",
    outcomes: [
      "Write the behavior-cloning objective in house notation.",
      "Explain how covariate shift makes errors compound over an episode.",
      "Compute expected off-track steps for a cloned policy by hand.",
      "Compare DAgger, HG-DAgger and ThriftyDAgger by who labels which states.",
      "Explain why squared-error regression collapses a left-or-right task."
    ],
    concepts: [
      { name: "Behavior cloning", def: "Supervised learning of the map from observation to the expert's action, from a fixed, reward-free demonstration dataset.", ref: "X2 eq. 18", art: ART.bc, term: "behavior-cloning", sym: "pi" },
      { name: "Covariate shift", def: "At run time the policy visits its own states, which differ from the expert states it was trained on.", ref: "X2 Fig. 20A", art: ART.shift, term: "covariate-shift" },
      { name: "Compounding error", def: "One mistake leads to an unfamiliar state, where mistakes are likelier; cost can grow with T².", ref: "arXiv 1011.0686", art: ART.compound, term: "compounding-error", sym: "Tsteps" },
      { name: "Mode averaging", def: "A squared-error policy predicts the mean of left and right demonstrations: straight into the obstacle.", ref: "X2 Fig. 20B", art: ART.avg, term: "mode-averaging", href: "#lab/heads" },
      { name: "DAgger", def: "Run the learner, let the expert label the states it visited, add them to the data, retrain.", ref: "arXiv 1011.0686", art: ART.dagger, term: "dagger", sym: "pistar" },
      { name: "Gated interventions", def: "HG-DAgger lets a human take over when unsafe; ThriftyDAgger lets the robot ask when novel or risky.", ref: "arXiv 2109.08273", art: ART.gate, term: "robot-gated-intervention" },
      { name: "Bins plus offsets", def: "BeT replaces regression with a classifier over k-means action bins and a small continuous offset per bin.", ref: "arXiv 2206.11251", art: ART.bins, term: "action-binning" },
      { name: "Task-conditioned BC", def: "BC-Z conditions one policy on a language or video embedding z, so new sentences name new tasks.", ref: "arXiv 2202.02005", art: ART.task, term: "task-embedding", sym: "z" }
    ],
    flow: {
      title: "Where behavior cloning and DAgger act", ref: "X2 §4 · DAgger Alg. 3.1", w: 820, h: 280,
      caption: "Plain BC is the top row: demonstrations in, one supervised fit, a policy out. DAgger adds the dashed loop: the learner's own states go back to the expert for labels.",
      nodes: [
        { id: "expert", x: 10, y: 30, w: 150, h: 56, label: "Expert teleop", sub: "human demonstrations", kind: "agent" },
        { id: "data", x: 235, y: 30, w: 160, h: 56, label: "Dataset 𝒟", sub: "(oₜ, aₜ), no reward", kind: "store" },
        { id: "fit", x: 470, y: 30, w: 150, h: 56, label: "Supervised fit", sub: "min ℒ(aₜ, π_θ(oₜ))", kind: "agent" },
        { id: "robot", x: 660, y: 112, w: 150, h: 56, label: "Robot rollout", sub: "π_θ acts alone", kind: "env" },
        { id: "visit", x: 470, y: 196, w: 150, h: 56, label: "Visited states", sub: "may be off the data", kind: "decision" },
        { id: "label", x: 235, y: 196, w: 160, h: 56, label: "Expert labels", sub: "π*(s): DAgger only", kind: "agent" }
      ],
      edges: [
        { from: "expert", to: "data", label: "demos" },
        { from: "data", to: "fit", label: "batches" },
        { from: "fit", to: "robot", label: "policy π_θ", sides: ["r", "t"], via: [[735, 58]] },
        { from: "robot", to: "visit", label: "own states", sides: ["b", "r"], via: [[735, 224]] },
        { from: "visit", to: "label", label: "query", dashed: true },
        { from: "label", to: "data", label: "aggregate", dashed: true }
      ],
      steps: [
        { on: ["expert", "expert>data", "data"], text: "An operator teleoperates the robot. Each step stores the observation and the expert's action; there is no reward (X2 §4)." },
        { on: ["data", "data>fit", "fit"], text: "Shuffled pairs train the policy with a regression or classification loss: squared error, L1 or cross-entropy (P01 eq. 3)." },
        { on: ["fit>robot", "robot"], text: "The policy now acts alone. Every small error moves it to states that were never in 𝒟." },
        { on: ["robot>visit", "visit"], text: "Those visited states are the covariate shift. Plain BC stops here and the errors compound." },
        { on: ["visit>label", "label", "label>data", "data"], text: "DAgger sends the visited states to the expert for labels and retrains on the union. HG-DAgger and ThriftyDAgger label fewer, chosen states." }
      ]
    },
    worked: {
      title: "How fast a cloned policy drifts",
      ref: "DAgger §2, Thm 3.2", prov: "Our toy numbers: worst-case recovery",
      eq: { tex: "\\class{sym-E}{\\mathbb{E}}[\\text{steps off}] = \\sum_{t=1}^{\\class{sym-Tsteps}{T}} \\big(1 - (1-\\class{sym-bcerr}{\\epsilon})^{t}\\big) \\;\\approx\\; \\tfrac{1}{2}\\class{sym-Tsteps}{T}^2\\class{sym-bcerr}{\\epsilon}", words: "Each step the policy is off track unless it made no mistake so far; for small ε the sum grows with T².", key: ["E", "Tsteps", "bcerr"] },
      figure: WE_FIG,
      steps: [
        { title: "Set up the toy", text: "The clone errs with probability ε = 0.01 per step on expert states. Once off track it never recovers. The episode has T = 100 steps." },
        { title: "Chance of staying on", text: "No mistake in t steps has probability 0.99ᵗ: 0.61 after 50 steps, 0.37 after 100." },
        { title: "Sum the off-track steps", text: "Step t is off track with probability 1 − 0.99ᵗ. Summing t = 1 … 100 gives 37.2 expected steps off the demonstrations." },
        { title: "Compare with no compounding", text: "If each mistake cost one step and the policy returned, the cost is εT = 1. Compounding makes it 37 times worse." },
        { title: "Double the horizon", text: "At T = 200 the sum is 114.3, about three times more for twice the length. The bound T²ε grows from 100 to 400." },
        { title: "What DAgger buys", text: "Trained on its own states, the learner recovers. With u = 1 the bound uTε is 1 step at T = 100, 2 at T = 200." }
      ]
    },
    ruleTitle: "Four rules, from BC to DAgger and BC-Z",
    rules: [
      { name: "Behavior-cloning objective", ref: "X2 eq. 18 · P01 eq. 3", term: "behavior-cloning",
        tex: "\\min_{\\theta}\\; \\class{sym-E}{\\mathbb{E}}_{(\\class{sym-o}{o_t},\\, \\class{sym-a}{a_t}) \\sim \\class{sym-D}{\\mathcal{D}}} \\Big[ \\class{sym-L}{\\mathcal{L}}\\big(\\class{sym-a}{a_t},\\ \\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o_t})\\big) \\Big]",
        words: "Pick parameters that make the policy's action close to the expert's action, averaged over the demonstration pairs.",
        key: ["E", "o", "a", "D", "L", "pi", { glyph: "θ", meaning: "policy parameters" }] },
      { name: "BC cost bound: quadratic in T", ref: "DAgger §2 (Ross & Bagnell 2010)", term: "compounding-error",
        tex: "\\class{sym-Jcost}{J}(\\hat{\\pi}) \\;\\le\\; \\class{sym-Jcost}{J}(\\class{sym-pistar}{\\pi^*}) + \\class{sym-Tsteps}{T}^2\\, \\class{sym-bcerr}{\\epsilon}",
        words: "A clone that errs at rate ε on expert states can cost up to T²ε more than the expert over a T-step task.",
        key: ["Jcost", { glyph: "π̂", meaning: "the cloned policy" }, "pistar", "Tsteps", "bcerr"] },
      { name: "DAgger bound: linear in T", ref: "arXiv 1011.0686, Thm 3.2", term: "dagger",
        before: "\\class{sym-Jcost}{J}(\\hat{\\pi}) \\le \\class{sym-Jcost}{J}(\\class{sym-pistar}{\\pi^*}) + \\class{sym-Tsteps}{T}^2 \\class{sym-bcerr}{\\epsilon}",
        tex: "\\class{sym-Jcost}{J}(\\hat{\\pi}) \\le \\class{sym-Jcost}{J}(\\class{sym-pistar}{\\pi^*}) + \\class{sb-new}{\\class{sym-urec}{u}}\\, \\class{sym-Tsteps}{T}\\, \\class{sb-chg}{\\class{sym-bcerr}{\\epsilon_N}} + \\class{sb-new}{O(1)}",
        words: "Training on the learner's own states turns T² into uT. The error is now measured on the aggregated data after N rounds.",
        key: ["Jcost", "pistar", "urec", "Tsteps", "bcerr", { glyph: "N", meaning: "DAgger rounds, about uT" }], diff: true, beforeLabel: "BC", afterLabel: "DAgger" },
      { name: "BC-Z: condition on a task embedding", ref: "arXiv 2202.02005, §4", term: "task-embedding",
        before: "\\min_{\\theta}\\; \\class{sym-E}{\\mathbb{E}}_{\\class{sym-D}{\\mathcal{D}}}\\, \\class{sym-L}{\\mathcal{L}}\\big(\\class{sym-a}{a_t}, \\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o_t})\\big)",
        tex: "\\min_{\\theta}\\; \\class{sym-E}{\\mathbb{E}}_{\\class{sym-D}{\\mathcal{D}}}\\, \\class{sb-chg}{-\\log \\class{sym-pi}{\\pi_\\theta}\\big(\\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}, \\class{sb-new}{\\class{sym-z}{z}}\\big)} + \\class{sb-new}{D_{\\cos}\\big(\\class{sym-z}{z_h}, \\class{sym-z}{z_\\ell}\\big)}",
        words: "Clone actions given the task embedding z, and pull a human video's embedding toward the embedding of its sentence.",
        key: ["E", "D", "pi", "a", "o", { sym: "z", meaning: "512-D task embedding" }, { glyph: "D_cos", meaning: "cosine distance, 1 − v₁·v₂" }, { glyph: "z_h, z_ℓ", meaning: "video and language embeddings" }], diff: true, beforeLabel: "BC", afterLabel: "BC-Z" }
    ],
    algorithm: {
      title: "DAgger", ref: "arXiv 1011.0686, Alg. 3.1", prov: "Our notation: oₜ for states",
      lines: [
        '<span class="kw">input</span> expert <span data-sym="pistar">π*</span>, rounds N, mixing <span data-sym="beta-i">βᵢ</span> <span class="cm">// βᵢ = 1 for i = 1, else 0 works well</span>',
        '<span data-sym="D">𝒟</span> ← ∅; π̂₁ ← any policy',
        '<span class="kw">for</span> i = 1 … N:',
        '    πᵢ ← <span data-sym="beta-i">βᵢ</span> <span data-sym="pistar">π*</span> + (1 − <span data-sym="beta-i">βᵢ</span>) π̂ᵢ',
        '    run πᵢ for <span data-sym="Tsteps">T</span> steps; keep the visited observations <span data-sym="o">oₜ</span>',
        '    𝒟ᵢ ← {(<span data-sym="o">oₜ</span>, <span data-sym="pistar">π*</span>(<span data-sym="o">oₜ</span>))} <span class="cm">// the expert labels them</span>',
        '    <span data-sym="D">𝒟</span> ← <span data-sym="D">𝒟</span> ∪ 𝒟ᵢ; train π̂ᵢ₊₁ on <span data-sym="D">𝒟</span> with <span data-sym="L">ℒ</span>',
        '<span class="kw">return</span> the best π̂ᵢ on validation'
      ]
    },
    playgrounds: [
      {
        id: "collapse", title: "Regression collapses a left-or-right task", ref: "X2 Fig. 20B · BeT, arXiv 2206.11251", prov: "Simplified: 1-D toy, no network",
        try: "Look at starts near the middle: the regression line crosses the red band. Set Share passing left to 1, then back to 0.5. Switch to BeT and compare 1 bin with 2.",
        mount: mountCollapse,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b1-collapse";
          return [
            { target: q("#" + id + "-fit"), title: "The mean goes through", text: "Starts in the middle were demonstrated half left, half right. The squared-error fit is their mean, near zero: into the block." },
            { target: q("#" + id + "-share"), title: "Remove the ambiguity", text: "If every demonstrator passes left, the data are unimodal and regression is fine. Multimodality, not regression itself, breaks it.", do: function (a) { return a.set(q("#" + id + "-share"), 1); }, task: "Set Share passing left to 1.00", expect: function () { return api.state().share >= 0.95; } },
            { target: q("#" + id + "-share"), title: "Bring the split back", text: "Half left, half right again. The middle paths hit the block.", do: function (a) { return a.set(q("#" + id + "-share"), 0.5); }, task: "Set Share passing left to 0.50", expect: function () { var s = api.state().share; return s > 0.4 && s < 0.6; } },
            { target: q("#" + id + "-head"), title: "Classify, then offset", text: "BeT clusters the actions into bins, samples a bin, and adds an offset. Each sample commits to one side.", do: function (a) { return a.click(q("#" + id + '-head [value="bet"]')); }, task: "Choose BeT bins", expect: function () { return api.state().head === "bet"; } },
            { target: q("#" + id + "-k"), title: "One bin is regression", text: "With k = 1 there is one bin at the mean, and BeT collapses like regression. BeT's paper reports 0.25 of full success without binning.", do: function (a) { return a.set(q("#" + id + "-k"), 1); }, task: "Set Bins k to 1", expect: function () { return api.state().k === 1; } },
            { target: q("#" + id + "-k"), title: "Your turn", text: "Try k = 2, 3 and 6, and press Resample demos. More bins than modes still work, because the classifier gives near-zero weight to empty bins." }
          ];
        }
      },
      {
        id: "shift", title: "Covariate shift, DAgger and gated help", ref: "X2 Fig. 20A · DAgger · ThriftyDAgger", prov: "Simplified: 1-D lane toy",
        try: "In BC only, raise Expert demos from 10 to 50: little changes. Choose DAgger and press Collect and retrain twice. Then try Robot-gated and compare the expert labels.",
        mount: mountShift,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "b1-shift";
          return [
            { target: q("#" + id + "-cv"), title: "The clone drifts", text: "Expert states sit in a thin band around the path. The clone's small errors take it outside, where it errs more, and many rollouts hit a wall." },
            { target: q("#" + id + "-demos"), title: "More demos barely help", text: "The expert rarely leaves the center, so 50 demos cover almost the same states as 10.", do: function (a) { return a.set(q("#" + id + "-demos"), 50); }, task: "Set Expert demos to 50", expect: function () { return api.state().demos >= 45; } },
            { target: q("#" + id + "-mode"), title: "Switch to DAgger", text: "DAgger lets the learner drive and asks the expert what it should have done in every visited state.", do: function (a) { return a.click(q("#" + id + '-mode [value="dagger"]')); }, task: "Choose DAgger", expect: function () { return api.state().mode === "dagger"; } },
            { target: q("#" + id + "-go"), title: "Aggregate and retrain", text: "Each round adds the learner's states with expert labels. The data now cover the drift, and the labels teach recovery.", do: function (a) { return a.click(q("#" + id + "-go")).then(function () { return a.wait(400); }).then(function () { return a.click(q("#" + id + "-go")); }); }, task: "Press Collect and retrain twice", expect: function () { return api.state().iter >= 2; } },
            { target: q("#" + id + "-mode"), title: "Let the robot ask", text: "Robot-gated mode hands control to the expert only on novel states, so far fewer states need labels.", do: function (a) { return a.click(q("#" + id + '-mode [value="gated"]')); }, task: "Choose Robot-gated", expect: function () { return api.state().mode === "gated"; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Press Collect and retrain twice and compare Expert labels with DAgger's. Then raise ε to 0.024 and see which scheme still keeps the lane." }
          ];
        }
      }
    ],
    methods: ["dagger", "bc-z", "hg-dagger", "thriftydagger", "behavior-transformers", "one-shot-imitation", "end-to-end-visuomotor-policies"],
    open: [
      { title: "Better than the demonstrator", text: "BC reproduces behavior at best as good as the demonstrator's and cannot fix suboptimal human choices when demonstrations are scarce.", refs: "X2 §4" },
      { title: "Less human attention", text: "Interactive imitation is moving from continuous human correction to selective intervention; continuous monitoring does not scale to fleets.", refs: "P01 §6.1.2 · ThriftyDAgger" },
      { title: "Shift without an expert", text: "Search, latent policy barriers and failure detection with conformal guarantees try to handle distribution shift when no expert can relabel.", refs: "P01 §6.1.2 (Robustness)" },
      { title: "Causal and cross-embodiment imitation", text: "The survey names causal imitation via counterfactual reasoning and transfer across tasks and embodiments as open directions.", refs: "P01 §6.1.2" }
    ],
    takeaways: [
      "Behavior cloning is supervised regression from observations to expert actions on a reward-free dataset.",
      "A clone meets its own states, not the expert's; its cost can grow with T² instead of T.",
      "DAgger labels the learner's visited states; HG-DAgger lets a human decide, ThriftyDAgger lets the robot ask.",
      "Squared-error cloning averages modes; BeT's bins and offsets, and later generative heads, sample one mode instead.",
      "BC-Z scaled BC with interventions to 100 tasks and conditioned the policy on language or video embeddings."
    ],
    quiz: [
      { q: "Why does a cloned policy visit states that are not in its training data?", options: ["The expert data were shuffled", "Its own small errors move it off the expert's states", "The reward is sparse", "The camera is too slow"], correct: 1, why: "Small prediction errors drive the policy out of distribution, where it is less reliable, so errors compound (X2 §4, Fig. 20A)." },
      { q: "A clone errs with probability 0.01 per step and never recovers. About how many of 100 steps are off track?", options: ["1", "10", "37", "100"], correct: 2, why: "The sum of 1 − 0.99ᵗ over t = 1 … 100 is 37.2, against εT = 1 without compounding." },
      { q: "What does DAgger add to behavior cloning?", options: ["A reward function", "Expert labels on states the learner visits", "A larger network", "Noise on the demonstrations"], correct: 1, why: "DAgger runs the learner, queries the expert on visited states, aggregates the data and retrains, giving a bound linear in T (arXiv 1011.0686)." },
      { q: "What did ThriftyDAgger change compared with HG-DAgger?", options: ["It removed the human entirely", "The robot, not the human, decides when to ask for help", "It trains with RL only", "It clones videos instead of actions"], correct: 1, why: "ThriftyDAgger gates on novelty and risk with thresholds set from an intervention budget; HG-DAgger needs a human watching all the time." },
      { q: "Demonstrators pass a block on the left or right. What does BeT output where regression predicts the mean?", options: ["The mean as well", "A sampled bin center plus an offset: one side", "Nothing", "Both sides at once"], correct: 1, why: "BeT predicts a categorical distribution over k-means action bins and a residual offset, so sampling picks one mode (arXiv 2206.11251)." }
    ],
    cards: [
      { front: "What is the behavior-cloning objective?", back: "Minimize the expected loss between the expert action and the policy's action over demonstration pairs (o, a) from 𝒟.", ref: "X2 eq. 18" },
      { front: "Which two failures does X2 name for point-estimate BC policies?", back: "Compounding errors from covariate shift, and a poor fit to multimodal demonstrations.", ref: "X2 §4, Fig. 20" },
      { front: "BC bound versus DAgger bound?", back: "BC: J(π̂) ≤ J(π*) + T²ε. DAgger: J(π̂) ≤ J(π*) + uTε_N + O(1).", ref: "arXiv 1011.0686" },
      { front: "What did HG-DAgger change about DAgger's gate?", back: "The human, not a random β-mixture, decides when to take over, and keeps uninterrupted control during the recovery.", ref: "arXiv 1810.02890" },
      { front: "How does ThriftyDAgger decide when to ask?", back: "Novelty (ensemble action variance) or risk (low learned chance of reaching the goal), with thresholds set from a budget.", ref: "arXiv 2109.08273" },
      { front: "BC-Z: HG-DAgger versus manual data at equal size?", back: "53% against 27% on one task and 47% against 23% on eight tasks.", ref: "arXiv 2202.02005" },
      { front: "How big was BC-Z's dataset?", back: "25,877 demonstrations over 100 tasks: 11,108 expert-only and 14,769 HG-DAgger episodes, about 125 hours.", ref: "arXiv 2202.02005" }
    ],
    terms: {
      "behavior-cloning": { name: "behavior cloning", aliases: ["BC", "behavioral cloning"], group: "learning", sym: "π_θ", symTex: "\\pi_\\theta", def: "Learning the mapping from observations to expert actions as a supervised problem on offline, reward-free demonstrations.", note: "It is imitation learning without interaction; DAgger-style methods add interaction.", ref: "X2 eq. 18", scene: "system", focus: ["human-teleop", "policy-update"], look: "demonstrations training the policy", uses: ["expert-demonstration"] },
      "expert-demonstration": { name: "expert demonstration", aliases: ["demonstration", "demo", "teleoperated trajectory"], group: "data", sym: "𝒟", symTex: "\\mathcal{D}", def: "A trajectory of observation-action pairs recorded while an expert, usually a teleoperator, does the task; it holds no reward.", note: "Expert trajectories encode success and resets implicitly, so BC needs no success detector.", ref: "X2 §4", scene: "system", focus: ["human-teleop", "data-robot"], look: "the teleoperator recording data", uses: [] },
      "covariate-shift": { name: "covariate shift", aliases: ["distribution shift", "state distribution shift"], group: "learning", def: "The mismatch between the states in the training data and the states the learned policy visits when it acts.", note: "It is caused by the policy's own errors, not by a change in the task.", ref: "X2 §4, Fig. 20A", scene: "robot", focus: ["trajectory"], look: "the path leaving the demonstrations", uses: ["behavior-cloning"] },
      "compounding-error": { name: "compounding error", aliases: ["compounding errors", "error accumulation"], group: "learning", def: "Errors that grow along an episode because each mistake leads to less familiar states where further mistakes are likelier.", note: "Action chunks reduce the number of decisions, which is one reason ACT uses them.", ref: "X2 §4 · arXiv 1011.0686", scene: "robot", focus: ["trajectory", "object"], look: "the growing gap to the target", uses: ["covariate-shift"] },
      "dagger": { name: "DAgger", aliases: ["dataset aggregation"], group: "learning", sym: "π*", symTex: "\\pi^*", def: "Dataset Aggregation: iteratively run the current policy, have the expert label the visited states, aggregate all data and retrain one stationary policy.", note: "It needs an expert who can label any state, even ones the expert would never reach.", ref: "arXiv 1011.0686", scene: "system", focus: ["human-teleop", "policy-update"], look: "expert labels flowing back", uses: ["covariate-shift", "expert-demonstration"] },
      "human-gated-dagger": { name: "human-gated DAgger", aliases: ["HG-DAgger"], group: "learning", def: "Interactive imitation where the human watches, takes uninterrupted control when the robot is unsafe, and only the recovery labels are aggregated.", note: "Unlike DAgger, the human decides when to intervene, which gives better labels but needs constant attention.", ref: "arXiv 1810.02890", scene: "system", focus: ["human-teleop", "robot"], look: "the human taking over", uses: ["dagger"] },
      "robot-gated-intervention": { name: "robot-gated intervention", aliases: ["ThriftyDAgger", "robot-gated DAgger"], group: "learning", def: "The robot requests help when a state is novel or risky, with thresholds set from a target intervention budget.", note: "ThriftyDAgger asks for fewer but longer interventions, which can mean more total human actions on some tasks.", ref: "arXiv 2109.08273", scene: "system", focus: ["robot", "human-teleop"], look: "the robot requesting help", uses: ["human-gated-dagger"] },
      "interactive-imitation-learning": { name: "interactive imitation learning", aliases: ["IIL", "interactive IL"], group: "learning", def: "Imitation that improves a policy through corrective feedback collected while it runs, mitigating distribution shift.", note: "P01 files DAgger variants, LazyDAgger, ThriftyDAgger and Sirius under this branch of Fig. 15.", ref: "P01 §6.1.2, Fig. 15", scene: "system", focus: ["human-teleop", "robot", "policy-update"], look: "corrections feeding the update", uses: ["dagger", "covariate-shift"] },
      "action-binning": { name: "action binning", aliases: ["k-means bins", "bin plus offset"], group: "heads", def: "Discretizing continuous actions into k clusters, predicting a categorical bin, and adding a predicted continuous residual offset.", note: "It fixes mode averaging without diffusion; with k = 1 it reduces to regression.", ref: "arXiv 2206.11251", scene: "system", focus: ["action-head"], look: "the head choosing one bin", uses: ["mode-averaging", "multimodal-actions"] },
      "task-embedding": { name: "task embedding", aliases: ["task conditioning", "language embedding"], group: "vla", sym: "z", symTex: "z", def: "A vector that names the task for a multi-task policy, from a frozen sentence encoder or a video encoder.", note: "BC-Z feeds it through FiLM layers; later VLAs use a full language model instead.", ref: "arXiv 2202.02005", scene: "system", focus: ["instruction", "vision-encoder"], look: "the instruction entering the policy", uses: ["behavior-cloning"] }
    },
    symbols: [
      { id: "pistar", tex: "\\pi^*", glyph: "π*", kind: "Functions", meaning: "expert policy: the demonstrator, queried for labels", short: "expert policy", first: "b1", read: "pi star", papers: "DAgger: π* · P01: π_e · X2: expert" },
      { id: "Tsteps", tex: "T", glyph: "T", kind: "Parameters", meaning: "task horizon: number of steps in an episode (not the transition probability T)", short: "episode length", first: "b1", read: "T", papers: "DAgger: T · X2: T_i" },
      { id: "bcerr", tex: "\\epsilon", glyph: "ε", kind: "Parameters", meaning: "per-step imitation error of the clone on expert states (not the noise ε)", short: "per-step error", first: "b1", read: "epsilon", papers: "DAgger: ε, ε_N" },
      { id: "urec", tex: "u", glyph: "u", kind: "Parameters", meaning: "largest increase in cost-to-go from one wrong action", short: "recovery cost", first: "b1", read: "u", papers: "DAgger: u" },
      { id: "Jcost", tex: "J", glyph: "J", kind: "Functions", meaning: "total cost of a policy over T steps (lower is better)", short: "total T-step cost", first: "b1", read: "J", papers: "DAgger: J(π) as cost" },
      { id: "beta-i", tex: "\\beta_i", glyph: "βᵢ", kind: "Parameters", meaning: "probability of executing the expert in DAgger round i", short: "expert mixing", first: "b1", read: "beta i", papers: "DAgger: β_i" }
    ],
    ledger: [
      { where: "Topic 05 · rules", source: "DAgger writes J(π) for a cost and ε for the per-step error", page: "Shown as Jcost and err, separate from the house J (return) and ε (noise)", why: "Avoids clashing with the reinforcement-learning objective and the diffusion noise.", kind: "Our choice" },
      { where: "Topic 05 · BC objective", source: "X2 eq. 18 writes f(oₜ) with o; P01 eq. 3 writes π(sₜ) and â for the expert label", page: "House notation π_θ(oₜ) and aₜ", why: "One notation across topics.", kind: "Our choice" },
      { where: "Topic 05 · BC-Z rule", source: "BC-Z writes π(a | s, zⁱ) with sums over tasks i", page: "π_θ(aₜ | oₜ, z) with an expectation over 𝒟", why: "Same objective, shorter form.", kind: "Our choice" },
      { where: "Topic 05 · worked example", source: "DAgger's T²ε is an upper bound under worst-case recovery", page: "The example computes the exact expected count Σ(1 − (1 − ε)ᵗ) for a clone that never recovers", why: "Gives numbers a learner can check by hand.", kind: "Simplified" },
      { where: "Topic 05 · playground 2", source: "Real learners are networks whose errors off the data are not modeled", page: "The toy's error grows linearly with distance to the nearest training state", why: "Shows the mechanism X2 describes: less confident outputs out of distribution.", kind: "Simplified" },
      { where: "Topic 05 · DAgger scope", source: "X2 §4 excludes DAgger because it assumes a single offline dataset; P01 §6.1.2 lists it under interactive IL", page: "This topic teaches both", why: "The surveys scope the method differently, not the facts.", kind: "Sources disagree" }
    ]
  });
})();
