/* Topic 10 · World models. Sources: X3 §II–IV (definition, representation spectrum Fig. 2, prediction–action interface),
   P03 §2.1, §3.1 (eq. 1, 4–8), X1 §2.1, §3.2 (L_WM, RSSM / TSSM / JEPA lineage), method cards (World Models → PlaNet → Dreamer →
   DreamerV3 → TD-MPC2 → DINO-WM / V-JEPA 2 → UniSim / IRASim / Cosmos / Genie Envisioner). */
(function () {
  "use strict";
  var RB = window.RB;

  function monoFont() { return getComputedStyle(document.body).getPropertyValue("--font-mono"); }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body"); }

  /* ---------- playground 1: cross-entropy-method (CEM) planning in a toy latent model ---------- */
  /* Latent state z = block position on a table, in [0,1]². An obstacle sits between block and goal.
     The learned model knows the obstacle but assumes a push moves the block exactly by a. The real table can differ
     (gain and sideways drift set by "Model error"). Everything here is our toy; numbers are illustrative. */
  var OB = { x0: 0.42, x1: 0.58, y0: 0.3, y1: 0.7 }, START = [0.15, 0.5], GOAL = [0.85, 0.5], AMAX = 0.12, T_EP = 12;

  function inRect(p, m) { m = m || 0; return p[0] > OB.x0 - m && p[0] < OB.x1 + m && p[1] > OB.y0 - m && p[1] < OB.y1 + m; }
  function segHitsRect(p, q, m) {
    /* Liang–Barsky clip of segment p→q against the rectangle grown by m */
    var x0 = OB.x0 - m, x1 = OB.x1 + m, y0 = OB.y0 - m, y1 = OB.y1 + m, dx = q[0] - p[0], dy = q[1] - p[1], t0 = 0, t1 = 1;
    var P = [-dx, dx, -dy, dy], Q = [p[0] - x0, x1 - p[0], p[1] - y0, y1 - p[1]];
    for (var i = 0; i < 4; i++) {
      if (P[i] === 0) { if (Q[i] < 0) return false; continue; }
      var r = Q[i] / P[i];
      if (P[i] < 0) { if (r > t1) return false; if (r > t0) t0 = r; } else { if (r < t0) return false; if (r < t1) t1 = r; }
    }
    return t1 - t0 > 1e-9;
  }
  function dist(p, q) { var a = p[0] - q[0], b = p[1] - q[1]; return Math.sqrt(a * a + b * b); }
  /* "terminal value": shortest path to the goal around the obstacle (a perfect value estimate for this toy) */
  function geo(z) {
    if (!segHitsRect(z, GOAL, -0.005)) return dist(z, GOAL);
    var m = 0.03, C = [[OB.x0 - m, OB.y0 - m], [OB.x1 + m, OB.y0 - m], [OB.x1 + m, OB.y1 + m], [OB.x0 - m, OB.y1 + m]];
    var nodes = [z].concat(C).concat([GOAL]), n = nodes.length, d = [], done = [];
    for (var i = 0; i < n; i++) { d.push(i ? Infinity : 0); done.push(false); }
    for (var k = 0; k < n; k++) {
      var u = -1; for (var j = 0; j < n; j++) if (!done[j] && (u < 0 || d[j] < d[u])) u = j;
      if (u < 0 || d[u] === Infinity) break; done[u] = true;
      for (var v = 0; v < n; v++) if (!done[v] && !segHitsRect(nodes[u], nodes[v], -0.005)) { var w = d[u] + dist(nodes[u], nodes[v]); if (w < d[v]) d[v] = w; }
    }
    return d[n - 1];
  }
  function step(z, a, err) {
    /* err = 0: the learned model. err > 0: the real table (weaker pushes that drift sideways). */
    var g = 1 - 0.5 * err, th = 1.2 * err, c = Math.cos(th), s = Math.sin(th);
    var n = [z[0] + g * (c * a[0] - s * a[1]), z[1] + g * (s * a[0] + c * a[1])];
    n[0] = RB.clamp(n[0], 0.02, 0.98); n[1] = RB.clamp(n[1], 0.02, 0.98);
    return inRect(n) ? [z[0], z[1]] : n; /* the block cannot enter the obstacle */
  }
  function rollout(z, seq, err) { var tr = [z]; for (var h = 0; h < seq.length; h++) { z = step(z, seq[h], err); tr.push(z); } return tr; }
  function costOf(tr, tv) {
    var run = 0; for (var h = 1; h < tr.length; h++) run += dist(tr[h], GOAL);
    var end = tr[tr.length - 1];
    return (tv ? geo(end) : dist(end, GOAL)) + 0.5 * run / (tr.length - 1);
  }
  function cem(z0, H, N, I, R, tv, warm) {
    var mu = [], sd = [], h, i, it, keep = Math.max(2, Math.round(0.1 * N)), last = null;
    for (h = 0; h < H; h++) { mu.push(warm && warm[h] ? warm[h].slice() : [0, 0]); sd.push([0.08, 0.08]); }
    for (it = 0; it < I; it++) {
      var cand = [];
      for (i = 0; i < N; i++) {
        var seq = [];
        for (h = 0; h < H; h++) seq.push([RB.clamp(mu[h][0] + sd[h][0] * R.normal(), -AMAX, AMAX), RB.clamp(mu[h][1] + sd[h][1] * R.normal(), -AMAX, AMAX)]);
        var tr = rollout(z0, seq, 0);
        cand.push({ seq: seq, tr: tr, c: costOf(tr, tv) });
      }
      cand.sort(function (a, b) { return a.c - b.c; });
      var el = cand.slice(0, keep);
      for (h = 0; h < H; h++) for (var d = 0; d < 2; d++) {
        var m = 0; el.forEach(function (e) { m += e.seq[h][d]; }); m /= keep;
        var v = 0; el.forEach(function (e) { v += (e.seq[h][d] - m) * (e.seq[h][d] - m); }); v /= keep;
        mu[h][d] = m; sd[h][d] = Math.max(0.01, Math.sqrt(v));
      }
      last = { cand: cand, keep: keep };
    }
    var mtr = rollout(z0, mu, 0);
    return { mu: mu, last: last, meanTr: mtr, cost: costOf(mtr, tv) };
  }

  function mountPlanner(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.slider({ id: id + "-n", label: "Samples N", min: 10, max: 300, step: 10, value: 100 }) +
      RB.slider({ id: id + "-i", label: "Iterations", min: 1, max: 8, step: 1, value: 6 }) +
      RB.slider({ id: id + "-h", label: "Horizon H", min: 1, max: 12, step: 1, value: 8 }) +
      RB.slider({ id: id + "-e", label: "Model error", min: 0, max: 0.4, step: 0.05, value: 0, fmt: function (v) { return (+v).toFixed(2); } }) + "</div>" +
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Execution", value: "mpc", options: [{ value: "mpc", label: "Replan" }, { value: "open", label: "Open loop" }] }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-tv"> <span>Terminal value</span></label>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Plan again ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Table seen from above: a block, an obstacle and a goal, with imagined and real paths"></canvas><figcaption class="sb-caption">Compare the dashed imagined path with the solid real path. Faint lines are candidate rollouts from the first plan; colored ones are the elites the planner refits to.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "imag", k: "Imagined distance (first plan)" }, { id: "real", k: "Real distance to goal" }, { id: "ok", k: "Block reached the goal" }, { id: "calls", k: "Model steps per episode" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "ink-3", label: "candidate rollouts", kind: "line" }, { c: "data-1", label: "elites", kind: "line" }, { c: "accent", label: "imagined plan", kind: "dash" }, { c: "data-2", label: "real path", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    var S = { N: 100, I: 6, H: 8, err: 0, mode: "mpc", tv: false, seed: 11 }, res = null, W = 520, Hc = 360;
    function px(p) { return [20 + p[0] * 480, 20 + (1 - p[1]) * 320]; }
    function run() {
      var R = RB.rng(S.seed), z = START.slice(), path = [z], calls = 0, first = null, warm = null;
      if (S.mode === "open") {
        first = cem(z, T_EP, S.N, S.I, R, S.tv, null); calls = S.N * S.I * T_EP;
        for (var t = 0; t < T_EP; t++) { z = step(z, first.mu[t], S.err); path.push(z); }
      } else {
        for (var t2 = 0; t2 < T_EP; t2++) {
          var hz = Math.min(S.H, Math.max(2, T_EP - t2)), pl = cem(z, hz, S.N, S.I, R, S.tv, warm);
          if (!first) first = pl;
          calls += S.N * S.I * hz;
          z = step(z, pl.mu[0], S.err); path.push(z);
          warm = pl.mu.slice(1); warm.push([0, 0]);
        }
      }
      res = { first: first, path: path };
      var imagEnd = first.meanTr[first.meanTr.length - 1], realEnd = path[path.length - 1];
      RB.setRO(body, "imag", RB.fmt(dist(imagEnd, GOAL), 2));
      RB.setRO(body, "real", RB.fmt(dist(realEnd, GOAL), 2));
      RB.setRO(body, "ok", dist(realEnd, GOAL) < 0.06 ? "yes" : "no");
      RB.setRO(body, "calls", calls.toLocaleString("en-US"));
      var stuck = realEnd[0] < OB.x0 && Math.abs(realEnd[1] - 0.5) < 0.2;
      if (S.mode === "open" && S.err > 0) note.textContent = "Open loop: the plan was perfect inside the model, but the real table drifts the block and nothing corrects it.";
      else if (stuck && S.mode === "mpc") note.textContent = "Stuck: every short plan that goes around the obstacle first moves away from the goal, so it scores worse. A longer horizon or a terminal value sees past that.";
      else if (S.mode === "mpc" && S.err > 0) note.textContent = "Replanning from the real state after every push absorbs the model error: this is model-predictive control.";
      else note.textContent = "The planner samples action sequences, imagines each with the model, keeps the best 10% and refits. Only the first action of each plan is executed.";
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, Hc);
      c.fillStyle = P.surface; c.fillRect(0, 0, W, Hc);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (var gx = 20; gx <= 500; gx += 48) { c.beginPath(); c.moveTo(gx, 20); c.lineTo(gx, 340); c.stroke(); }
      for (var gy = 20; gy <= 340; gy += 40) { c.beginPath(); c.moveTo(20, gy); c.lineTo(500, gy); c.stroke(); }
      var o0 = px([OB.x0, OB.y1]), o1 = px([OB.x1, OB.y0]);
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.fillRect(o0[0], o0[1], o1[0] - o0[0], o1[1] - o0[1]); c.strokeRect(o0[0], o0[1], o1[0] - o0[0], o1[1] - o0[1]);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + monoFont(); c.fillText("obstacle", o0[0] + 12, (o0[1] + o1[1]) / 2 + 4);
      var g = px(GOAL); c.strokeStyle = P.good; c.lineWidth = 2; c.beginPath(); c.arc(g[0], g[1], 0.06 * 480, 0, Math.PI * 2); c.stroke();
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + bodyFont(); c.fillText("goal", g[0] - 12, g[1] - 34);
      if (res) {
        var L = res.first.last, show = Math.min(L.cand.length, 60);
        function line(tr, col, w, alpha, dash) { c.globalAlpha = alpha; c.strokeStyle = col; c.lineWidth = w; c.setLineDash(dash || []); c.beginPath(); tr.forEach(function (p, i) { var q = px(p); if (i) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); }); c.stroke(); c.setLineDash([]); c.globalAlpha = 1; }
        for (var i = L.keep; i < show; i++) line(L.cand[i].tr, P["ink-3"], 1, 0.25);
        for (var j = 0; j < L.keep && j < 30; j++) line(L.cand[j].tr, P["data-1"], 1.2, 0.55);
        line(res.first.meanTr, P.accent, 2.5, 1, [6, 4]);
        line(res.path, P["data-2"], 2.5, 1);
        res.path.forEach(function (p) { var q = px(p); c.fillStyle = P["data-2"]; c.beginPath(); c.arc(q[0], q[1], 3, 0, Math.PI * 2); c.fill(); });
        var e = px(res.path[res.path.length - 1]); c.fillStyle = P["data-2"]; c.fillRect(e[0] - 8, e[1] - 8, 16, 16);
      }
      var s = px(START); c.fillStyle = P.ink; c.beginPath(); c.arc(s[0], s[1], 5, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + bodyFont(); c.fillText("start", s[0] - 14, s[1] + 22);
    }
    RB.bindSlider(body, id + "-n", null, function (v) { S.N = v; run(); });
    RB.bindSlider(body, id + "-i", null, function (v) { S.I = v; run(); });
    RB.bindSlider(body, id + "-h", null, function (v) { S.H = v; run(); });
    RB.bindSlider(body, id + "-e", function (v) { return (+v).toFixed(2); }, function (v) { S.err = v; run(); });
    RB.bindSeg(body, id + "-mode", function () { var b = body.querySelector("#" + id + '-mode [aria-pressed="true"]'); S.mode = b ? b.value : S.mode; body.querySelector("#" + id + "-h").disabled = S.mode === "open"; run(); });
    body.querySelector("#" + id + "-tv").addEventListener("change", function (e) { S.tv = e.target.checked; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { S.seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { N: S.N, I: S.I, H: S.H, err: S.err, mode: S.mode, tv: S.tv }; }, result: function () { return res; } };
  }

  /* ---------- playground 2: a planner exploits a learned model where it has no data ---------- */
  /* True table: a push of strength a moves the block 1.5·a cm up to a = 6; harder pushes tip it over.
     Data covers pushes in [0, coverage]. Five cubic models are fit on bootstrap resamples.
     The planner picks a in [0, 10] maximizing mean prediction − κ · spread. Our toy numbers. */
  function trueMove(a) { return a <= 6 ? 1.5 * a : Math.max(0, 9 - 3 * (a - 6)); }
  function fitCubic(pts) {
    /* least squares on [1, a, a², a³] with a tiny ridge, solved by Gaussian elimination */
    var n = 4, S = [], b = [], r, i, j, k;
    for (i = 0; i < n; i++) { S.push([0, 0, 0, 0]); b.push(0); }
    pts.forEach(function (p) { var f = [1, p[0], p[0] * p[0], p[0] * p[0] * p[0]]; for (var i2 = 0; i2 < n; i2++) { b[i2] += f[i2] * p[1]; for (var j2 = 0; j2 < n; j2++) S[i2][j2] += f[i2] * f[j2]; } });
    for (r = 0; r < n; r++) S[r][r] += 1e-3;
    var A = S.map(function (row, i3) { return row.concat([b[i3]]); });
    for (var c = 0; c < n; c++) {
      var piv = c; for (k = c + 1; k < n; k++) if (Math.abs(A[k][c]) > Math.abs(A[piv][c])) piv = k;
      var tmp = A[c]; A[c] = A[piv]; A[piv] = tmp;
      for (k = c + 1; k < n; k++) { var f2 = A[k][c] / A[c][c]; for (j = c; j <= n; j++) A[k][j] -= f2 * A[c][j]; }
    }
    var w = [0, 0, 0, 0]; for (i = n - 1; i >= 0; i--) { var sm = A[i][n]; for (j = i + 1; j < n; j++) sm -= A[i][j] * w[j]; w[i] = sm / A[i][i]; }
    return function (a) { return w[0] + a * (w[1] + a * (w[2] + a * w[3])); };
  }
  function mountExploit(body, ctx) {
    var id = ctx.id;
    body.innerHTML = '<div class="rb-row">' + RB.slider({ id: id + "-c", label: "Data coverage (push up to)", min: 2, max: 10, step: 0.5, value: 4, fmt: function (v) { return (+v).toFixed(1); } }) +
      RB.slider({ id: id + "-k", label: "Disagreement penalty κ", min: 0, max: 3, step: 0.25, value: 0, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New data ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Push strength against block displacement: data points, five fitted models, the true curve and the planner\'s choice"></canvas><figcaption class="sb-caption">Watch the vertical marker: the push the planner chose. Its top dot is what the models promise; its bottom dot is what the real table delivers.</figcaption></figure><div class="rb-stack">' +
      RB.readouts([{ id: "pick", k: "Push the planner chose" }, { id: "pred", k: "Models predict", u: "cm" }, { id: "sd", k: "Models disagree by", u: "± cm" }, { id: "real", k: "Real table gives", u: "cm" }, { id: "gap", k: "Promise minus reality", u: "cm" }]) +
      '<p class="sb-caption">Illustrative. World Models saw the same effect: at a low dream temperature its controller scored 2086 inside the model and 193 in the real game (arXiv 1803.10122).</p>' +
      RB.legend([{ c: "ink-2", label: "real table", kind: "dash" }, { c: "data-1", label: "five fitted models", kind: "line" }, { c: "data-3", label: "recorded pushes", kind: "dot" }, { c: "accent", label: "planner's choice", kind: "line" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), S = { c: 4, k: 0, seed: 5 }, st = null, W = 520, H = 320;
    function run() {
      var R = RB.rng(S.seed), n = 14, data = [];
      for (var i = 0; i < n; i++) { var a = S.c * (i + 0.5) / n; data.push([a, trueMove(a) + 0.35 * R.normal()]); }
      var models = [];
      for (var m = 0; m < 5; m++) { var bs = []; for (var j = 0; j < n; j++) bs.push(data[R.int(n)]); models.push(fitCubic(bs)); }
      var best = null;
      for (var g = 0; g <= 200; g++) {
        var a2 = g * 0.05, ps = models.map(function (f) { return f(a2); }), mean = ps.reduce(function (x, y) { return x + y; }, 0) / 5;
        var sd = Math.sqrt(ps.reduce(function (x, y) { return x + (y - mean) * (y - mean); }, 0) / 5), score = mean - S.k * sd;
        if (!best || score > best.score) best = { a: a2, mean: mean, sd: sd, score: score };
      }
      st = { data: data, models: models, best: best };
      RB.setRO(body, "pick", RB.fmt(best.a, 1));
      RB.setRO(body, "pred", RB.fmt(best.mean, 1)); RB.setRO(body, "sd", RB.fmt(best.sd, 1));
      RB.setRO(body, "real", RB.fmt(trueMove(best.a), 1));
      RB.setRO(body, "gap", RB.fmt(best.mean - trueMove(best.a), 1));
      draw();
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), x0 = 52, x1 = W - 16, y0 = H - 40, y1 = 16, yMax = 20, yMin = -4;
      var sx = function (a) { return x0 + a / 10 * (x1 - x0); }, sy = function (v) { return y0 - (v - yMin) / (yMax - yMin) * (y0 - y1); }, syc = function (v) { return sy(RB.clamp(v, yMin, yMax)); };
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.fillStyle = P["accent-soft"]; c.globalAlpha = 0.5; c.fillRect(sx(0), y1, sx(S.c) - sx(0), y0 - y1); c.globalAlpha = 1;
      c.strokeStyle = P.line; c.lineWidth = 1; c.font = "500 11px " + monoFont(); c.fillStyle = P["ink-3"];
      for (var v = -4; v <= 20; v += 4) { c.beginPath(); c.moveTo(x0, sy(v)); c.lineTo(x1, sy(v)); c.stroke(); c.fillText(String(v), x0 - 24, sy(v) + 4); }
      for (var a = 0; a <= 10; a += 2) c.fillText(String(a), sx(a) - 4, y0 + 16);
      c.fillStyle = P["ink-2"]; c.font = "600 12px " + bodyFont(); c.fillText("push strength", x1 - 92, y0 + 32); c.save(); c.translate(14, y1 + 120); c.rotate(-Math.PI / 2); c.fillText("block moves (cm)", 0, 0); c.restore();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + monoFont(); c.fillText("data", sx(0) + 6, y1 + 14);
      if (!st) return;
      function curve(f, col, w, dash, alpha) { c.globalAlpha = alpha || 1; c.strokeStyle = col; c.lineWidth = w; c.setLineDash(dash || []); c.beginPath(); for (var k = 0; k <= 100; k++) { var q = k / 10; if (k) c.lineTo(sx(q), sy(f(q))); else c.moveTo(sx(q), sy(f(q))); } c.stroke(); c.setLineDash([]); c.globalAlpha = 1; }
      c.save(); c.beginPath(); c.rect(x0, y1, x1 - x0, y0 - y1); c.clip();
      st.models.forEach(function (f) { curve(f, P["data-1"], 1.5, null, 0.7); });
      curve(trueMove, P["ink-2"], 2, [6, 4]);
      st.data.forEach(function (p) { c.fillStyle = P["data-3"]; c.beginPath(); c.arc(sx(p[0]), sy(p[1]), 3.5, 0, Math.PI * 2); c.fill(); });
      c.restore();
      var b = st.best, bx = sx(b.a);
      c.strokeStyle = P.accent; c.lineWidth = 2; c.beginPath(); c.moveTo(bx, y1); c.lineTo(bx, y0); c.stroke();
      c.fillStyle = P.accent; c.beginPath(); c.arc(bx, syc(b.mean), 6, 0, Math.PI * 2); c.fill();
      c.fillStyle = P.bad; c.beginPath(); c.arc(bx, sy(trueMove(b.a)), 6, 0, Math.PI * 2); c.fill();
    }
    RB.bindSlider(body, id + "-c", function (v) { return (+v).toFixed(1); }, function (v) { S.c = v; run(); });
    RB.bindSlider(body, id + "-k", function (v) { return (+v).toFixed(2); }, function (v) { S.k = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { S.seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { c: S.c, k: S.k }; }, best: function () { return st && st.best; } };
  }

  /* ---------- concept-card drawings (200×56, token classes only) ---------- */
  var ART = {
    wm: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="8" width="30" height="18" rx="3" class="rb-f-sunk"/><text x="23" y="21" text-anchor="middle" class="rb-t-mono">oₜ</text><rect x="8" y="32" width="30" height="18" rx="3" class="rb-f-sunk"/><text x="23" y="45" text-anchor="middle" class="rb-t-mono">aₜ</text><path d="M40 17 L70 26 M40 41 L70 32" class="rb-s-ink"/><rect x="72" y="14" width="62" height="28" rx="4" class="rb-f-soft"/><text x="103" y="32" text-anchor="middle" class="rb-t-acc">p_θ</text><path d="M136 28 H158" class="rb-s-ink"/><rect x="160" y="16" width="32" height="24" rx="3" class="rb-f-surface" stroke-dasharray="3 2"/><text x="176" y="32" text-anchor="middle" class="rb-t-mono">o′</text></svg>',
    tests: '<svg viewBox="0 0 200 56" aria-hidden="true">' + ["predictive", "grounded", "what-if"].map(function (w, i) { var x = 27 + i * 66; return '<rect x="' + x + '" y="10" width="14" height="14" rx="2" class="rb-f-soft"/><path d="M' + (x + 3) + ' 17 l3 4 l6 -8" class="rb-s-acc"/><text x="' + (x + 7) + '" y="44" text-anchor="middle" class="rb-t-mono">' + w + "</text>"; }).join("") + "</svg>",
    rssm: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2].map(function (i) { var x = 14 + i * 62; return '<rect x="' + x + '" y="6" width="34" height="18" rx="3" class="rb-f-surface"/><text x="' + (x + 17) + '" y="19" text-anchor="middle" class="rb-t-mono">h</text><circle cx="' + (x + 17) + '" cy="42" r="9" class="rb-f-soft"/><text x="' + (x + 17) + '" y="46" text-anchor="middle" class="rb-t-acc">z</text><path d="M' + (x + 17) + ' 24 V33" class="rb-s-ink"/>' + (i < 2 ? '<path d="M' + (x + 34) + ' 15 H' + (x + 62) + '" class="rb-s-ink"/>' : ""); }).join("") + "</svg>",
    imagine: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="18" cy="28" r="6" class="rb-f-acc"/><path d="M24 28 C60 28 90 8 186 8" class="rb-s-line" stroke-dasharray="4 3"/><path d="M24 28 C70 28 110 26 186 24" class="rb-s-acc" stroke-dasharray="4 3"/><path d="M24 28 C60 30 100 48 186 48" class="rb-s-line" stroke-dasharray="4 3"/><text x="120" y="38" class="rb-t-mono">imagined</text><text x="10" y="52" class="rb-t-mono">zₜ</text></svg>',
    cem: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 48 Q40 46 60 30 Q80 14 100 30 Q120 46 150 48" class="rb-s-line"/><path d="M110 48 Q130 48 140 30 Q150 6 160 30 Q170 48 190 48" class="rb-s-acc"/><line x1="10" y1="48" x2="190" y2="48" class="rb-s-line"/><text x="44" y="12" class="rb-t-mono">iter 1</text><text x="150" y="12" class="rb-t-mono">iter 4</text></svg>',
    spectrum: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 26 H186" class="rb-s-ink"/><path d="M180 21 L188 26 L180 31" class="rb-s-ink"/>' + ["pixel", "latent", "flow", "3D/4D", "physics"].map(function (w, i) { var x = 16 + i * 40; return '<circle cx="' + x + '" cy="26" r="' + (3 + i) + '" class="rb-f-soft"/><text x="' + x + '" y="' + (i % 2 ? 50 : 12) + '" text-anchor="middle" class="rb-t-mono">' + w + "</text>"; }).join("") + "</svg>",
    exploit: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="4" width="70" height="48" class="rb-f-sunk"/><path d="M8 48 L120 16 L188 50" class="rb-s-line" stroke-dasharray="4 3"/><path d="M8 48 L120 16 Q160 4 188 2" class="rb-s-acc"/><line x1="176" y1="4" x2="176" y2="52" class="rb-s-ink"/><text x="14" y="16" class="rb-t-mono">data</text><text x="146" y="50" class="rb-t-mono">real</text><text x="84" y="12" class="rb-t-acc">model</text></svg>'
  };

  /* ---------- worked example figure: one CEM iteration on a 1-D push, numbers computed below ----------
     model ẑ₂ = 0.8(a₁ + a₂); goal 10; candidates (2,1) (6,3) (−1,4) (5,7) (8,−2) → 2.4 7.2 2.4 9.6 4.8;
     costs 57.76 7.84 57.76 0.16 27.04; elites (5,7) (6,3) → mean (5.5, 5.0), std (0.5, 2.0); mean plan → 8.4, cost 2.56;
     execute a₁ = 5.5: model says 4.4, a real gain of 0.7 gives 3.85. */
  var X = function (v) { return (40 + v * 40).toFixed(1); };
  var WE_FIG = '<svg viewBox="0 0 560 150" role="img" aria-label="Number line of block position from 0 to 12 centimeters with the goal at 10; imagined endpoints of five candidate plans, the two elites, the refit plan and the real first push">' +
    '<line x1="' + X(0) + '" y1="84" x2="' + X(12) + '" y2="84" class="rb-s-line"/>' +
    '<g class="rb-t-mono">' + [0, 2, 4, 6, 8, 10, 12].map(function (v) { return '<line x1="' + X(v) + '" y1="80" x2="' + X(v) + '" y2="88" class="rb-s-line"/><text x="' + X(v) + '" y="104" text-anchor="middle">' + v + "</text>"; }).join("") + '<text x="' + X(12) + '" y="122" text-anchor="end">cm</text></g>' +
    '<rect x="' + X(9.7) + '" y="72" width="24" height="22" rx="3" class="rb-f-soft"/><text x="' + X(10) + '" y="64" text-anchor="middle" class="rb-t-ink">goal</text>' +
    '<g data-on="1+"><circle cx="' + X(0) + '" cy="84" r="7" class="rb-f-acc"/><text x="' + X(0) + '" y="64" text-anchor="middle" class="rb-t-ink">z₀</text></g>' +
    '<g data-on="2+">' + [[2.4, 0, "(2,1)"], [7.2, 1, "(6,3)"], [2.4, 2, "(−1,4)"], [9.6, 0, "(5,7)"], [4.8, 3, "(8,−2)"]].map(function (p) { var y = [18, 34, 50, 64][p[1]]; return '<path d="M' + X(p[0]) + " " + (y + 4) + " V78" + '" class="rb-s-line" stroke-dasharray="2 3"/><circle cx="' + X(p[0]) + '" cy="' + y + '" r="4" class="rb-f-surface"/><text x="' + (+X(p[0]) + 8) + '" y="' + (y + 4) + '" class="rb-t-mono">' + p[2] + " → " + p[0] + "</text>"; }).join("") + '</g>' +
    '<g data-on="3+"><circle cx="' + X(9.6) + '" cy="18" r="6" class="rb-f-acc"/><circle cx="' + X(7.2) + '" cy="34" r="6" class="rb-f-acc"/></g>' +
    '<g data-on="4+"><circle cx="' + X(8.4) + '" cy="84" r="6" class="rb-f-acc"/><text x="' + X(8.4) + '" y="122" text-anchor="middle" class="rb-t-acc">mean plan 8.4</text></g>' +
    '<g data-on="5"><circle cx="' + X(4.4) + '" cy="84" r="5" class="rb-f-surface"/><text x="' + X(4.4) + '" y="122" text-anchor="middle" class="rb-t-mono">model 4.4</text><rect x="' + (+X(3.85) - 6) + '" y="128" width="12" height="12" class="rb-f-acc"/><text x="' + (+X(3.85) + 10) + '" y="139" class="rb-t-acc">real 3.85</text></g></svg>';

  RB.topic({
    id: "c1",
    title: "World models: predict, then act",
    eyebrow: "Part C · World models",
    lede: "A world model predicts how the scene changes under the robot's actions, so the robot can compare, practice or check actions before it moves.",
    refs: ["X3 §II–IV", "P03 §2.1, §3.1", "X1 §3.2"],
    why: "A policy maps what the robot sees to what it does, with no notion of what happens next. A world model predicts the next observation for a candidate action. A robot can then search over actions, train a policy on imagined rollouts, or reject a plan before touching anything. The idea runs from Dyna through Dreamer to video world models.",
    outcomes: [
      "State the three tests a manipulation world model must pass.",
      "Trace what each step from World Models to V-JEPA 2 changed.",
      "Compute one cross-entropy-method planning iteration by hand.",
      "Explain how replanning and terminal values handle model error and short horizons.",
      "Predict when a planner will exploit a learned model."
    ],
    concepts: [
      { name: "World model", def: "A learned model p_θ(o′ | o, a): given the present and an action, predict the next observation.", ref: "X1 §2.1 · P03 eq. 1", art: ART.wm, term: "world-model", sym: "ptheta" },
      { name: "Three tests", def: "Predictive, world-grounded and intervention-aware. A reward model or a static encoder alone fails them.", ref: "X3 §II-C", art: ART.tests, term: "intervention-awareness" },
      { name: "RSSM", def: "A recurrent memory h plus a stochastic latent z. PlaNet introduced it; Dreamer and DreamerV3 kept it.", ref: "X1 §3.2.1", art: ART.rssm, term: "recurrent-state-space-model", sym: "hdet" },
      { name: "Latent imagination", def: "Dreamer trains its actor on rollouts imagined in latent space, backpropagating returns through the model.", ref: "arXiv 1912.01603", art: ART.imagine, term: "latent-imagination", href: "#lab/worldmodel", hrefLabel: "Try it in the World-model sandbox →" },
      { name: "CEM planning", def: "Sample action sequences, imagine each, keep the best, refit the sampler, repeat. Execute the first action.", ref: "PlaNet, arXiv 1811.04551", art: ART.cem, term: "cross-entropy-method", sym: "N" },
      { name: "Representation spectrum", def: "Pixels, latents, flow, 3D/4D scenes and physics: more structure, less appearance.", ref: "X3 §III, Fig. 2", art: ART.spectrum, term: "representation-spectrum" },
      { name: "Model exploitation", def: "An optimizer finds actions where the model is wrong in its favor; imagined success, real failure.", ref: "arXiv 1803.10122 · X3 §II-B", art: ART.exploit, term: "model-exploitation" }
    ],
    flow: {
      title: "Where the world model acts: planning in latent space", ref: "X3 §IV-B · PlaNet · TD-MPC2", w: 820, h: 290,
      caption: "The world model sits inside the planning loop: it never sends commands, it scores what candidate commands would do. Dreamer replaces the search with an actor trained in imagination.",
      nodes: [
        { id: "obs", x: 20, y: 40, w: 150, h: 56, label: "Camera image oₜ", sub: "plus joint state", kind: "env" },
        { id: "enc", x: 220, y: 40, w: 150, h: 56, label: "Encoder", sub: "image → latent zₜ", kind: "agent" },
        { id: "wm", x: 420, y: 40, w: 170, h: 56, label: "World model p_θ", sub: "imagines H steps", kind: "agent" },
        { id: "score", x: 640, y: 40, w: 160, h: 56, label: "Scorer", sub: "reward, value or goal", kind: "store" },
        { id: "plan", x: 420, y: 190, w: 170, h: 56, label: "Planner", sub: "CEM or MPPI", kind: "decision" },
        { id: "robot", x: 150, y: 190, w: 150, h: 56, label: "Robot", sub: "runs first action", kind: "env" }
      ],
      edges: [
        { from: "obs", to: "enc", label: "pixels" },
        { from: "enc", to: "wm", label: "zₜ" },
        { from: "plan", to: "wm", label: "candidates", sides: ["t", "b"] },
        { from: "wm", to: "score", label: "futures" },
        { from: "score", to: "plan", label: "costs", sides: ["b", "r"], via: [[720, 218]] },
        { from: "plan", to: "robot", label: "first action" },
        { from: "robot", to: "obs", label: "new image", sides: ["l", "b"], via: [[95, 218]] }
      ],
      steps: [
        { on: ["obs", "obs>enc", "enc"], text: "The image is encoded into a compact latent state zₜ: an RSSM state in PlaNet and Dreamer, frozen DINOv2 patch features in DINO-WM." },
        { on: ["plan", "plan>wm", "wm"], text: "The planner proposes candidate action sequences: 1,000 per iteration in PlaNet's CEM, 512 in TD-MPC2's MPPI, 800 in V-JEPA 2." },
        { on: ["wm", "wm>score", "score"], text: "The world model rolls each candidate H steps forward. The scorer sums predicted rewards, adds a terminal value, or measures distance to a goal image." },
        { on: ["score>plan", "plan"], text: "The planner refits its sampling distribution to the best candidates and repeats: 10 iterations in PlaNet, 6 in TD-MPC2." },
        { on: ["plan>robot", "robot", "robot>obs", "obs"], text: "Only the first action runs. A new image arrives and the robot plans again. This receding-horizon loop is model-predictive control." }
      ]
    },
    worked: {
      title: "One CEM iteration, by hand",
      ref: "PlaNet Alg. 2 · X3 §IV-B", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-z}{\\hat z_{t+2}} = \\class{sym-z}{z_t} + 0.8\\,(\\class{sym-a}{a_t} + \\class{sym-a}{a_{t+1}}),\\qquad c = (\\class{sym-z}{\\hat z_{t+2}} - \\class{sym-z}{z_g})^2", words: "The learned model says each push moves the block 0.8 of its size. A plan's cost is its squared miss of the goal.", key: ["z", "a", { glyph: "0.8", meaning: "push gain the model learned" }, { glyph: "c", meaning: "planning cost" }] },
      figure: WE_FIG,
      steps: [
        { title: "The setup", text: "The block is at z₀ = 0 cm, the goal at 10 cm. Plans have two pushes (H = 2)." },
        { title: "Imagine five plans", text: "Pushes (2,1), (6,3), (−1,4), (5,7), (8,−2) sum to 3, 9, 3, 12, 6. Times 0.8: 2.4, 7.2, 2.4, 9.6, 4.8 cm." },
        { title: "Score and keep elites", text: "Squared misses: 57.76, 7.84, 57.76, 0.16, 27.04. Keep the best two: (5,7) and (6,3)." },
        { title: "Refit the sampler", text: "New mean (5.5, 5.0), spread (0.5, 2.0). The mean plan reaches 0.8 × 10.5 = 8.4 cm, cost 2.56." },
        { title: "Act once, then replan", text: "Execute only 5.5. The model predicts 4.4 cm; if the real gain is 0.7, the block reaches 3.85. Replanning starts there." }
      ]
    },
    ruleTitle: "What a world model learns and how planners use it",
    rules: [
      { name: "World model: make the next observation likely", ref: "X1 §2.1 · P03 eq. 1", term: "world-model",
        tex: "\\class{sym-L}{\\mathcal{L}}_{\\mathrm{WM}} = \\class{sym-E}{\\mathbb{E}}_{(\\class{sym-o}{o},\\,\\class{sym-a}{a},\\,\\class{sym-op}{o'})\\sim\\class{sym-D}{\\mathcal{D}}}\\big[-\\log \\class{sym-ptheta}{p_\\theta}(\\class{sym-op}{o'} \\mid \\class{sym-o}{o}, \\class{sym-a}{a})\\big]",
        words: "Fit a model that makes the recorded next observation likely, given the current observation and the action taken.",
        key: ["L", "E", "o", "a", "op", "D", "ptheta"] },
      { name: "Recurrent state-space model (RSSM)", ref: "PlaNet, arXiv 1811.04551 · X1 §3.2.1", term: "recurrent-state-space-model",
        tex: "\\begin{gathered}\\class{sym-hdet}{h_t} = \\class{sym-f}{f}(\\class{sym-hdet}{h_{t-1}}, \\class{sym-z}{z_{t-1}}, \\class{sym-a}{a_{t-1}}),\\quad \\class{sym-z}{z_t} \\sim \\class{sym-ptheta}{p_\\theta}(\\class{sym-z}{z_t} \\mid \\class{sym-hdet}{h_t}),\\\\ \\class{sym-o}{o_t},\\, \\class{sym-r}{r_t} \\sim \\class{sym-ptheta}{p_\\theta}(\\cdot \\mid \\class{sym-hdet}{h_t}, \\class{sym-z}{z_t})\\end{gathered}",
        words: "A recurrent network carries a deterministic memory h; a stochastic latent z holds what cannot be predicted. Images and rewards are decoded from both.",
        key: ["hdet", "f", "z", "a", "ptheta", "o", "r"] },
      { name: "Planning objective: PlaNet, then TD-MPC2", ref: "arXiv 1811.04551 · 2310.16828", term: "terminal-value",
        before: "\\max_{\\class{sym-achunk}{\\mathbf{a}_{t:t+H}}} \\class{sym-E}{\\mathbb{E}}\\Big[\\textstyle\\sum_{h=t}^{t+\\class{sym-H}{H}-1} \\class{sym-r}{\\hat r_h}\\Big]",
        tex: "\\max_{\\class{sym-achunk}{\\mathbf{a}_{t:t+H}}} \\class{sym-E}{\\mathbb{E}}\\Big[\\textstyle\\sum_{h=t}^{t+\\class{sym-H}{H}-1} \\class{sb-new}{\\class{sym-gamma}{\\gamma}^{h-t}}\\,\\class{sym-r}{\\hat r_h} + \\class{sb-new}{\\class{sym-gamma}{\\gamma}^{\\class{sym-H}{H}}\\,\\class{sym-Q}{Q}(\\class{sym-z}{z_{t+H}}, \\class{sym-a}{a_{t+H}})}\\Big]",
        words: "PlaNet sums predicted rewards inside the horizon. TD-MPC2 discounts them and adds a learned terminal value, so a 3-step plan sees further.",
        key: ["achunk", "E", "H", "r", "gamma", "Q", "z", "a"], diff: true, beforeLabel: "PlaNet", afterLabel: "TD-MPC2" },
      { name: "Reward-free planning to a goal image", ref: "DINO-WM · V-JEPA 2",
        tex: "\\min_{\\class{sym-achunk}{\\mathbf{a}_{t:t+H}}}\\ \\big\\|\\class{sym-z}{\\hat z_{t+H}} - \\class{sym-z}{z_g}\\big\\|^2,\\qquad \\class{sym-z}{\\hat z_{h+1}} = \\class{sym-ptheta}{p_\\theta}(\\class{sym-z}{\\hat z_h}, \\class{sym-a}{a_h}),\\quad \\class{sym-z}{z_g} = \\mathrm{enc}(\\class{sym-o}{o_g})",
        words: "Roll candidates forward in latent space and keep the one whose final latent is closest to the encoded goal image. V-JEPA 2 uses L1 distance.",
        key: ["achunk", "z", "ptheta", "a", "o", { glyph: "enc", meaning: "frozen image encoder" }] }
    ],
    algorithm: {
      title: "Latent CEM planning with replanning", ref: "PlaNet, arXiv 1811.04551", prov: "PlaNet settings in brackets",
      lines: [
        '<span class="kw">input</span> belief <span data-sym="z">zₜ</span>, horizon <span data-sym="H">H</span> [12], candidates <span data-sym="N">N</span> [1,000], elites K [100], iterations I [10]',
        'm ← 0, σ ← 1 for every step of <span data-sym="achunk">a₍ₜ:ₜ₊H₎</span>',
        '<span class="kw">repeat</span> I times:',
        '    sample <span data-sym="N">N</span> sequences <span data-sym="achunk">a</span> ~ 𝒩(m, σ²)',
        '    imagine each with <span data-sym="ptheta">p_θ</span>; score = Σ predicted <span data-sym="r">r̂</span>',
        '    m, σ ← mean and spread of the K best',
        '<span class="kw">execute</span> the first action of m <span class="cm">// then observe, update zₜ, plan again</span>'
      ]
    },
    playgrounds: [
      {
        id: "cem", title: "CEM planning in a toy latent model", ref: "PlaNet · TD-MPC2 · X3 §IV-B", prov: "Simplified: 2-D toy model",
        try: "Lower Horizon H to 2: the block gets stuck behind the obstacle. Tick Terminal value. Then raise Model error and switch to Open loop.",
        mount: mountPlanner,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "c1-cem";
          return [
            { target: q("canvas"), title: "Imagine, then act", text: "Faint lines are imagined rollouts of candidate plans. Colored ones are the elites. The solid line is where the block really went." },
            { target: q("#" + id + "-h"), title: "A short horizon", text: "With 2 steps of lookahead, every detour first moves away from the goal and scores worse. The block pushes into the obstacle and stays.", do: function (a) { return a.set(q("#" + id + "-h"), 2); }, task: "Set Horizon H to 2", expect: function () { return api.state().H <= 2; } },
            { target: q("#" + id + "-tv"), title: "Add a terminal value", text: "A value at the horizon's end scores what lies beyond it. TD-MPC2 plans only 3 steps ahead this way.", do: function (a) { return a.click(q("#" + id + "-tv")); }, task: "Tick Terminal value", expect: function () { return api.state().tv; } },
            { target: q("#" + id + "-e"), title: "Make the model wrong", text: "Now the real table weakens pushes and drifts the block sideways. The learned model does not know.", do: function (a) { return a.set(q("#" + id + "-e"), 0.3); }, task: "Set Model error to 0.30", expect: function () { return api.state().err >= 0.25; } },
            { target: q("#" + id + "-mode"), title: "Plan once, run blind", text: "Open loop: the imagined path still ends at the goal, but the real block drifts away and nothing corrects it.", do: function (a) { return a.click(q("#" + id + '-mode [value="open"]')); }, task: "Choose Open loop", expect: function () { return api.state().mode === "open"; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Switch back to Replan and compare the real distance. Then set Samples to 10 and see the plans get worse." }
          ];
        }
      },
      {
        id: "exploit", title: "When the planner exploits the model", ref: "arXiv 1803.10122 · X3 §II-B", prov: "Illustrative: 1-D toy",
        try: "The data only covers weak pushes. Watch the planner pick a hard push. Raise the disagreement penalty, then widen the data coverage.",
        mount: mountExploit,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "c1-exploit";
          return [
            { target: q("canvas"), title: "Data only for weak pushes", text: "Dots are recorded pushes up to strength 4. The dashed curve is the real table: pushes above 6 tip the block over." },
            { target: q(".sb-readouts"), title: "The planner exploits the gap", text: "It picks the push the models like best, far outside the data. They promise a long move; the real block barely moves." },
            { target: q("#" + id + "-k"), title: "Penalize disagreement", text: "Five models fit on resampled data disagree where there was none. Subtracting their spread keeps the choice near the data.", do: function (a) { return a.set(q("#" + id + "-k"), 1.5); }, task: "Set the penalty κ to 1.5", expect: function () { return api.state().k >= 1; } },
            { target: q("#" + id + "-c"), title: "Collect the missing data", text: "With pushes recorded up to 10, the models see the tipping point and agree about it.", do: function (a) { return a.set(q("#" + id + "-c"), 10); }, task: "Set data coverage to 10", expect: function () { return api.state().c >= 9; } },
            { target: q("#" + id + "-k"), title: "Your turn", text: "Set κ back to 0 with full coverage. With good data the plain planner is safe again: exploitation needs a gap between model and world." }
          ];
        }
      }
    ],
    methodsLede: "How the line evolved: World Models trained a controller inside a VAE and RNN dream. PlaNet learned one RSSM and planned with CEM. Dreamer replaced the planner with an actor trained in imagination; DreamerV3 made one configuration work across domains. TD-MPC2 dropped the decoder and added a terminal value. DINO-WM and V-JEPA 2 plan on frozen pretrained features. UniSim, IRASim and Cosmos predict video instead.",
    methods: ["world-models", "planet", "dreamer", "dreamerv3", "td-mpc2", "dino-wm", "v-jepa-2", "unisim", "irasim", "cosmos-world-foundation-models", "genie-envisioner"],
    open: [
      { title: "Plausible is not executable", text: "A rollout can look coherent while breaking contact, object permanence or force closure. Pixel metrics such as PSNR and FVD miss this.", refs: "X3 §III-A, §IX" },
      { title: "Error that grows with the horizon", text: "Autoregressive world models accumulate error step by step. V-JEPA 2 needs image subgoals for pick-and-place for this reason.", refs: "X1 §3.2.1 · arXiv 2506.09985" },
      { title: "Learned simulators can be exploited", text: "A model good enough to rank policies may be unsafe to optimize against. Benchmarks rarely test closed-loop exploitation.", refs: "X3 §II-B, §IX" },
      { title: "Which substrate suits control", text: "Pixels, latents, flow, geometry or physics: the surveys call the best predictive substrate for control an open empirical question.", refs: "P03 §3 · X3 §III-F" }
    ],
    takeaways: [
      "A world model predicts the next observation given the current one and an action; it helps only if its predictions change what the robot does.",
      "PlaNet planned with CEM in an RSSM latent space; Dreamer learned an actor from imagined rollouts instead.",
      "Short horizons are myopic; TD-MPC2 adds a learned terminal value, and replanning every step absorbs model error.",
      "Planners and policies optimize against the model, so they find its mistakes. Uncertainty penalties and more data reduce exploitation.",
      "Representations range from pixels to physics; X3 argues the right one depends on how the prediction is used."
    ],
    quiz: [
      { q: "Which component is a world model under X3's operational definition?", options: ["A reward model that scores the current image", "A frozen image encoder", "A latent model that predicts the effect of a push", "An inverse model mapping two frames to an action"], correct: 2, why: "X3 requires a world model to be predictive, world-grounded and intervention-aware. Reward models, static encoders and inverse models each fail at least one test (X3 §II-C)." },
      { q: "What did Dreamer change relative to PlaNet?", options: ["It predicted pixels instead of latents", "It replaced online CEM planning with an actor trained on imagined rollouts", "It removed the world model", "It used a frozen DINOv2 encoder"], correct: 1, why: "Dreamer keeps PlaNet's RSSM but learns an actor and a value model in imagination, backpropagating λ-returns through the model (arXiv 1912.01603)." },
      { q: "In the worked example, after refitting to the elites (5,7) and (6,3), where does the mean plan put the block?", options: ["7.2 cm", "8.4 cm", "9.6 cm", "10.5 cm"], correct: 1, why: "The mean plan is (5.5, 5.0). The model predicts 0.8 × (5.5 + 5.0) = 8.4 cm." },
      { q: "A planner with horizon 2 pushes the block into an obstacle and stays there. Which fix follows TD-MPC2?", options: ["Execute the whole plan open loop", "Add a learned terminal value at the horizon's end", "Lower the number of samples", "Remove the stochastic latent"], correct: 1, why: "TD-MPC2 plans only 3 steps but adds γᴴ·Q at the end, so the score reflects what lies beyond the horizon (arXiv 2310.16828)." },
      { q: "World Models trained a Doom controller in its dream at temperature 0.10. What happened in the real game?", options: ["It scored higher than in the dream", "It scored 2086 in the dream but 193 for real", "It matched the dream score", "It could not be trained"], correct: 1, why: "At low temperature the controller exploited model errors: 2086 ± 140 in the dream, 193 ± 58 for real. Higher temperature reduced exploitation (arXiv 1803.10122)." }
    ],
    cards: [
      { front: "What three properties does X3 require of a manipulation world model?", back: "Predictive (models future evolution), world-grounded (describes the external scene), intervention-aware (supports what-if reasoning about robot actions).", ref: "X3 §II-C" },
      { front: "What are the two parts of an RSSM state?", back: "A deterministic recurrent state h carried by a GRU and a stochastic latent z sampled from a learned prior.", ref: "arXiv 1811.04551" },
      { front: "What are PlaNet's CEM planning settings?", back: "Horizon 12, 1,000 candidate sequences, refit to the best 100, for 10 iterations; execute the first action.", ref: "arXiv 1811.04551" },
      { front: "How does TD-MPC2 look beyond a 3-step horizon?", back: "It adds a discounted terminal value γᴴ·Q(z, a) from a learned Q-ensemble to the sum of predicted rewards.", ref: "arXiv 2310.16828" },
      { front: "How do DINO-WM and V-JEPA 2 choose actions without rewards?", back: "They encode a goal image and use CEM to minimize the latent distance between the predicted final state and the goal.", ref: "arXiv 2411.04983 · 2506.09985" },
      { front: "Name X3's five representation families, from least to most structure.", back: "Image and video, learned latents, motion fields and scene flow, geometric 3D/4D, physics-informed dynamics.", ref: "X3 §III, Fig. 2" }
    ],
    terms: {
      "world-model": { name: "world model", aliases: ["learned world model", "dynamics model", "action-conditioned world model"], group: "world", sym: "p_θ", symTex: "p_\\theta", def: "A predictive system that estimates how task-relevant aspects of the external world evolve over time and, in manipulation, predicts or evaluates that evolution under robot intervention.", note: "A video generator that ignores actions is not enough; predictions must change with the action.", ref: "X3 §II-C", scene: "system", focus: ["world-model", "predicted-future"], look: "the model predicting the future", uses: ["forward-model"] },
      "forward-model": { name: "forward model", aliases: ["internal model"], group: "world", def: "A model that predicts how the body and environment will change under a candidate action.", note: "An inverse model goes the other way: it estimates the action that reaches a desired state.", ref: "X3 §II-A", scene: "system", focus: ["world-model"], look: "action in, predicted state out", uses: [] },
      "intervention-awareness": { name: "intervention awareness", aliases: ["intervention-aware"], group: "world", def: "The property that a model supports counterfactual reasoning about what will happen if the robot pushes, grasps, places or otherwise acts.", note: "It usually means explicit action conditioning; passive video predictors qualify only once adapted for action.", ref: "X3 §II-C", scene: "robot", focus: ["gripper", "object"], look: "the gripper about to act", uses: ["world-model"] },
      "recurrent-state-space-model": { name: "recurrent state-space model", aliases: ["RSSM"], group: "world", sym: "hₜ, z", symTex: "h_t,\\ z_t", def: "A latent dynamics model with a deterministic recurrent path and a stochastic latent, capturing both predictable dynamics and uncertainty.", note: "PlaNet found that purely deterministic or purely stochastic versions did worse on all its tasks.", ref: "X1 §3.2.1 · arXiv 1811.04551", scene: "system", focus: ["latent", "world-model"], look: "the latent state inside the model", uses: ["world-model"] },
      "latent-imagination": { name: "latent imagination", aliases: ["imagined rollouts", "learning in imagination"], group: "world", def: "Training a policy on trajectories generated inside a learned latent world model instead of the real environment.", note: "Dreamer backpropagates value gradients through the model; DreamerV3 uses Reinforce with normalized returns.", ref: "arXiv 1912.01603 · 2301.04104", scene: "system", focus: ["world-model", "predicted-future", "policy-update"], look: "imagined futures updating the policy", uses: ["recurrent-state-space-model"] },
      "cross-entropy-method": { name: "cross-entropy method", aliases: ["CEM"], group: "world", sym: "N", symTex: "N", def: "A sampling optimizer: draw candidates from a Gaussian, score them, refit the Gaussian to the best few, and repeat.", note: "In planning it optimizes action sequences through the model; it does not train the model.", ref: "arXiv 1811.04551", scene: "system", focus: ["planner"], look: "the planner refining candidates", uses: [] },
      "terminal-value": { name: "terminal value", aliases: ["value bootstrap"], group: "world", sym: "Q", symTex: "Q", def: "A learned value added at the end of a short planning horizon so the planner accounts for rewards beyond it.", note: "Without it, a short-horizon planner is myopic; with it, TD-MPC2 plans only 3 steps.", ref: "arXiv 2310.16828", scene: "system", focus: ["planner", "reward-model"], look: "the value at the plan's end", uses: ["cross-entropy-method"] },
      "joint-embedding-predictive-architecture": { name: "joint-embedding predictive architecture", aliases: ["JEPA"], group: "world", def: "A model that predicts the embedding of missing or future observations from context, instead of reconstructing raw pixels.", note: "V-JEPA 2 applies it to video, then adds a small action-conditioned predictor for robot planning.", ref: "X1 §3.2.1", scene: "system", focus: ["latent", "predicted-future"], look: "predicting embeddings, not pixels", uses: ["world-model"] },
      "representation-spectrum": { name: "representation spectrum", aliases: ["world-model representations"], group: "world", def: "Five families ordered by increasing structure: image and video, learned latents, motion fields and scene flow, geometric 3D/4D, physics-informed dynamics.", note: "X3 says no family dominates; choose by how the prediction is used.", ref: "X3 §III, Fig. 2", scene: "system", focus: ["predicted-future"], look: "what the future is written in", uses: ["world-model"] },
      "model-exploitation": { name: "model exploitation", aliases: ["exploiting the model", "cheating in the dream"], group: "world", def: "An optimizer finding actions whose predicted outcome is good only because the learned model is wrong there.", note: "Higher sampling temperature, uncertainty penalties, replanning and more data reduce it.", ref: "arXiv 1803.10122 · X3 §II-B", scene: "system", focus: ["world-model", "planner"], look: "the planner fooling itself", uses: ["world-model"] },
      "rollout-error-accumulation": { name: "rollout error accumulation", aliases: ["compounding model error"], group: "world", def: "Small one-step prediction errors that grow when a model feeds its own predictions back as inputs over many steps.", note: "V-JEPA 2 adds a 2-step rollout loss; Robotic World Model trains on its own multi-step predictions.", ref: "X1 §3.2.1", scene: "system", focus: ["predicted-future"], look: "the imagined future drifting", uses: ["world-model"] },
      "world-foundation-model": { name: "world foundation model", aliases: ["WFM", "video world model"], group: "world", def: "A large video generator pretrained on broad video, then post-trained into action-, camera- or instruction-conditioned world models for specific robots.", note: "Cosmos is one example; its authors report it still fails on contact, gravity and object permanence.", ref: "arXiv 2501.03575 · P03 §2.1.2", scene: "system", focus: ["world-model", "data-web"], look: "a video model used as world model", uses: ["world-model"] }
    },
    symbols: [
      { id: "hdet", tex: "h_t", glyph: "hₜ", kind: "Signals", meaning: "deterministic recurrent state of a recurrent state-space model (RSSM)", short: "RSSM recurrent state", first: "c1", read: "h sub t", papers: "PlaNet, Dreamer: h_t with stochastic s_t · DreamerV3: h_t with z_t · World Models: LSTM h_t" }
    ],
    ledger: [
      { where: "Topic 10 · RSSM rule", source: "PlaNet and Dreamer write the stochastic state s_t", page: "The site writes z_t, as DreamerV3 does", why: "House notation keeps sₜ for the true state.", kind: "Our choice" },
      { where: "Topic 10 · worked example", source: "PlaNet plans with 1,000 candidates, 100 elites and 10 iterations", page: "Five candidates, two elites, one iteration on a 1-D push", why: "Small enough to compute by hand.", kind: "Simplified" },
      { where: "Topic 10 · playground 1", source: "Real planners use a trained latent model and learned reward or value", page: "The model and a shortest-path terminal value are given exactly", why: "Isolates horizon, sampling and model error.", kind: "Simplified" },
      { where: "Topic 10 · playground 2", source: "The surveys name exploitation but prescribe no single fix", page: "The planner subtracts κ times the spread of a five-model ensemble", why: "Ensemble disagreement is one common remedy; TD-MPC2 uses a Q-ensemble.", kind: "Our choice" },
      { where: "Topic 10 · methods", source: "TD-MPC2 reports beating DreamerV3 across 104 online tasks; DINO-WM reports TD-MPC2 0.00 vs DreamerV3 0.30 on offline Push-T goal reaching", page: "Both results are shown with their settings", why: "Different settings: DINO-WM retrained both offline without rewards.", kind: "Sources disagree" }
    ]
  });
})();
