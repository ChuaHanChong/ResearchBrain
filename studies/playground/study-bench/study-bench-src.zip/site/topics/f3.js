/* Topic 23 · Benchmarks and what they miss. Sources: P03 §7, X3 §VII–VIII, P01 §2.4 and §3 (Tables 1–3), X1 §6 (Table 9),
   method cards (LIBERO, CALVIN, SIMPLER, RLBench, Meta-World, robomimic, ManiSkill3, WorldSimBench, EWMBench, COLOSSEUM,
   LIBERO-Plus, RoboArena, PolaRiS) and OpenVLA-OFT Table I (arXiv 2502.19645). */
(function () {
  "use strict";
  var RB = window.RB;

  function monoFont() { return getComputedStyle(document.body).getPropertyValue("--font-mono") || "monospace"; }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body") || "sans-serif"; }
  /* standard normal CDF (Abramowitz–Stegun 7.1.26 on erf) */
  function phi(z) {
    var s = z < 0 ? -1 : 1, x = Math.abs(z) / Math.SQRT2, t = 1 / (1 + 0.3275911 * x);
    var y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
    return 0.5 * (1 + s * y);
  }
  /* RB.bindSeg hands its callback b.value, but StudyBench.segmented already passes the value string; wire it directly. */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); if (el) StudyBench.segmented(el, function (v) { cb(v); }); return el; }
  function binom(R, n, p) { var k = 0; for (var i = 0; i < n; i++) if (R() < p) k++; return k; }

  /* ================= Playground 1 · results board, filtered by suite =================
     Rows: OpenVLA-OFT Table I (arXiv 2502.19645) baselines and P03 Table 5 (world-model methods). Success rates in %. */
  var BOARD = [
    { n: "Diffusion Policy", y: 2023, g: "base", v: [78.3, 92.5, 68.3, 50.5, 72.4] },
    { n: "Octo", y: 2024, g: "base", v: [78.9, 85.7, 84.6, 51.1, 75.1] },
    { n: "OpenVLA", y: 2024, g: "base", v: [84.7, 88.4, 79.2, 53.7, 76.5] },
    { n: "π0", y: 2024, g: "base", v: [96.8, 98.8, 95.8, 85.2, 94.2] },
    { n: "OpenVLA-OFT", y: 2025, g: "base", v: [97.6, 98.4, 97.9, 94.5, 97.1] },
    { n: "MimicVideo", y: 2025, g: "wm", v: [94.2, 96.8, 90.6, 94.0, 93.9] },
    { n: "Say-Dream-ACT", y: 2026, g: "wm", v: [99.4, 99.2, 98.6, 95.4, 98.1] },
    { n: "Cosmos Policy", y: 2026, g: "wm", v: [98.1, 100.0, 98.2, 97.6, 98.5] },
    { n: "UD-VLA", y: 2026, g: "wm", v: [94.1, 95.7, 91.2, 89.6, 92.7] },
    { n: "Motus", y: 2025, g: "wm", v: [96.8, 99.8, 96.6, 97.6, 97.7] },
    { n: "LingBot-VA", y: 2026, g: "wm", v: [98.5, 99.6, 97.2, 98.5, 98.5] },
    { n: "RynnVLA-002", y: 2025, g: "wm", v: [99.0, 99.8, 96.4, 94.4, 97.4] },
    { n: "DreamVLA", y: 2025, g: "wm", v: [97.5, 94.0, 89.5, 89.5, 92.6] },
    { n: "UniVLA", y: 2025, g: "wm", v: [96.5, 96.8, 95.6, 92.0, 95.2] },
    { n: "Unified VLA", y: 2025, g: "wm", v: [95.4, 98.8, 93.6, 94.0, 95.5] },
    { n: "CoWVLA", y: 2026, g: "wm", v: [97.2, 97.8, 94.6, 92.8, 95.6] },
    { n: "F1", y: 2025, g: "wm", v: [98.2, 97.8, 95.4, 91.3, 95.7] },
    { n: "TriVLA", y: 2025, g: "wm", v: [91.2, 93.8, 89.8, 73.2, 87.0] },
    { n: "VLA-JEPA", y: 2026, g: "wm", v: [96.2, 99.6, 97.2, 95.8, 97.2] },
    { n: "JEPA-VLA", y: 2026, g: "wm", v: [97.2, 98.0, 95.6, 94.8, 96.4] }
  ];
  /* LIBERO-Plus camera-viewpoint study (arXiv 2510.13626): original → perturbed */
  var CAMERA = [{ n: "OpenVLA-OFT", a: 97.1, b: 59.7 }, { n: "UniVLA", a: 95.2, b: 4.3 }, { n: "π0", a: 94.2, b: 15.8 }];
  var VIEWS = ["Spatial", "Object", "Goal", "Long", "Average"];

  function ciHalf(p, n) { return 1.96 * Math.sqrt(Math.max(p * (1 - p), 0) / n); }

  function mountBoard(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-view", label: "Suite", value: "4", options: [{ value: "0", label: "Spatial" }, { value: "1", label: "Object" }, { value: "2", label: "Goal" }, { value: "3", label: "Long" }, { value: "4", label: "Average" }, { value: "cam", label: "Camera shift" }] }) +
      RB.slider({ id: id + "-n", label: "Episodes per suite", min: 50, max: 2000, step: 50, value: 500 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-zoom"> <span>Zoom to 85–100%</span></label></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Bar chart of LIBERO success rates per method with 95% intervals"></canvas>' +
      '<figcaption class="sb-caption">Bars are reported success rates; whiskers are the 95% interval that the chosen number of episodes allows. A bracket joins neighbors whose gap the episodes cannot resolve.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "best", k: "Top score" }, { id: "spread", k: "Spread of the top five", u: "points" }, { id: "ci", k: "95% interval at the top", u: "points" }, { id: "ties", k: "Top-five neighbors noise cannot separate" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-4", label: "VLA and imitation baselines (OpenVLA-OFT Table I)", kind: "area" }, { c: "data-1", label: "world-model methods (P03 Table 5)", kind: "area" }, { c: "bad", label: "after a camera shift (LIBERO-Plus)", kind: "area" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    var st = { view: "4", n: 500, zoom: false }, W = 540, H = 440, rows = [];
    function neff() { return st.view === "4" ? st.n * 4 : st.n; }
    function build() {
      if (st.view === "cam") { rows = CAMERA.map(function (c) { return { n: c.n, v: c.a, b: c.b, g: "cam" }; }); return; }
      var k = +st.view;
      rows = BOARD.map(function (r) { return { n: r.n, v: r.v[k], g: r.g, y: r.y }; }).sort(function (a, b) { return b.v - a.v; });
    }
    function tied(a, b, n) { var pa = a / 100, pb = b / 100; return Math.abs(pa - pb) < 1.96 * Math.sqrt((pa * (1 - pa) + pb * (1 - pb)) / n); }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont(), bf = bodyFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var x0 = 118, x1 = W - 36, lo = st.zoom && st.view !== "cam" ? 85 : 0, hi = 100;
      var sx = function (v) { return x0 + (Math.max(lo, Math.min(hi, v)) - lo) / (hi - lo) * (x1 - x0); };
      var top = 14, rowH = st.view === "cam" ? 60 : (H - 40) / rows.length;
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1; c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono;
      var stepV = (hi - lo) <= 15 ? 5 : 20;
      for (var g = lo; g <= hi; g += stepV) { c.beginPath(); c.moveTo(sx(g), top - 4); c.lineTo(sx(g), H - 24); c.stroke(); c.fillText(g + "%", sx(g) - 12, H - 8); }
      var n = neff();
      rows.forEach(function (r, i) {
        var y = top + i * rowH, bh = st.view === "cam" ? 16 : Math.max(8, rowH - 6);
        c.fillStyle = P.ink; c.font = "500 12px " + bf; c.textAlign = "right"; c.fillText(r.n, x0 - 8, y + bh / 2 + 4); c.textAlign = "left";
        if (st.view === "cam") {
          c.fillStyle = P["data-4"]; c.fillRect(sx(0), y, sx(r.v) - sx(0), bh);
          c.fillStyle = P.bad; c.fillRect(sx(0), y + bh + 6, sx(r.b) - sx(0), bh);
          c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono; c.fillText(r.v.toFixed(1), sx(r.v) + 4, y + bh - 3); c.fillText(r.b.toFixed(1) + "  (−" + (r.v - r.b).toFixed(1) + ")", sx(r.b) + 4, y + 2 * bh + 3);
          return;
        }
        c.fillStyle = r.g === "base" ? P["data-4"] : P["data-1"]; c.globalAlpha = 0.85;
        if (r.v > lo) c.fillRect(sx(lo), y, sx(r.v) - sx(lo), bh);
        c.globalAlpha = 1;
        var h = 100 * ciHalf(r.v / 100, n), a = sx(r.v - h), b = sx(Math.min(100, r.v + h)), ym = y + bh / 2;
        if (r.v > lo) { c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.moveTo(a, ym); c.lineTo(b, ym); c.moveTo(a, ym - 3); c.lineTo(a, ym + 3); c.moveTo(b, ym - 3); c.lineTo(b, ym + 3); c.stroke(); }
        if (st.zoom && r.v < lo) { c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText("below " + lo + "%", x0 + 4, ym + 4); }
        if (i > 0 && i < 5 && tied(rows[i - 1].v, r.v, n)) {
          c.strokeStyle = P.warn; c.lineWidth = 2; var bx = W - 14; c.beginPath(); c.moveTo(bx - 6, ym - rowH); c.lineTo(bx, ym - rowH); c.lineTo(bx, ym); c.lineTo(bx - 6, ym); c.stroke();
        }
      });
      c.lineWidth = 1;
    }
    function run() {
      build();
      var n = neff();
      if (st.view === "cam") {
        RB.setRO(body, "best", "59.7%"); RB.setRO(body, "spread", "–"); RB.setRO(body, "ci", "±" + RB.fmt(100 * ciHalf(0.597, n), 1)); RB.setRO(body, "ties", "–");
        note.textContent = "LIBERO-Plus moved the camera. All three policies scored at least 94% on the standard suites, yet two fall below 16%. The wrist camera is one reason OpenVLA-OFT holds up best (arXiv 2510.13626).";
      } else {
        var top5 = rows.slice(0, 5), ties = 0;
        for (var i = 1; i < 5; i++) if (tied(top5[i - 1].v, top5[i].v, n)) ties++;
        RB.setRO(body, "best", top5[0].v.toFixed(1) + "%");
        RB.setRO(body, "spread", RB.fmt(top5[0].v - top5[4].v, 1));
        RB.setRO(body, "ci", "±" + RB.fmt(100 * ciHalf(top5[0].v / 100, n), 1));
        RB.setRO(body, "ties", ties + " of 4");
        note.textContent = "Top: " + top5[0].n + ". " + (st.view === "3" ? "Long is the suite that still separates methods: the spread across the whole board is widest here (P03 §7.3)." :
          st.view === "4" ? "The average hides the suites. It is computed over " + n + " episodes, four suites of " + st.n + "." :
          "Most methods score above 90% here; a one-point gap is inside the noise unless you run many episodes.");
      }
      body.querySelector("#" + id + "-n").disabled = false;
      body.querySelector("#" + id + "-zoom").disabled = st.view === "cam";
      draw();
    }
    bindSeg(body, id + "-view", function (v) { st.view = v; run(); });
    RB.bindSlider(body, id + "-n", null, function (v) { st.n = v; run(); });
    body.querySelector("#" + id + "-zoom").addEventListener("change", function (e) { st.zoom = e.target.checked; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { view: st.view, n: st.n, zoom: st.zoom }; } };
  }

  /* ================= Playground 2 · how many rollouts to rank two policies =================
     Two policies with true success p_A and p_A + Δ; each evaluation runs n episodes per policy (Bernoulli trials).
     P(right order) uses the normal approximation; the 40 drawn evaluations are sampled with RB.rng. */
  function mountBudget(body, ctx) {
    var id = ctx.id, pctf = function (v) { return Math.round(v * 100) + "%"; };
    body.innerHTML =
      '<div class="rb-row">' + RB.slider({ id: id + "-pa", label: "True success of A", min: 0.1, max: 0.85, step: 0.05, value: 0.6, fmt: pctf }) +
      RB.slider({ id: id + "-gap", label: "B is better by", min: 0.01, max: 0.3, step: 0.01, value: 0.1, fmt: function (v) { return Math.round(v * 100) + " pts"; } }) +
      RB.slider({ id: id + "-n", label: "Episodes per policy", min: 5, max: 500, step: 5, value: 20 }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Evaluate again ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Forty repeated evaluations of policies A and B on a success axis"></canvas>' +
      '<figcaption class="sb-caption">Each row is one full evaluation: a hollow dot for A, a filled dot for B. Red rows put A ahead of B, the wrong order. Dashed lines mark the true rates.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "right", k: "Chance the order comes out right" }, { id: "wrong", k: "Wrong order in these 40 runs" }, { id: "ci", k: "95% interval on each rate", u: "points" }, { id: "n95", k: "Episodes for a 95% right order" }]) + RB.legend([{ c: "ink-2", label: "policy A (hollow)", kind: "dot" }, { c: "data-1", label: "policy B", kind: "dot" }, { c: "bad", label: "wrong order", kind: "line" }]) +
      '<p class="sb-caption">Reference points: OpenVLA-OFT ran 500 episodes per LIBERO suite and 10 to 24 trials per real ALOHA task (arXiv 2502.19645). RoboArena\'s fixed-task baseline ran 44 episodes per policy (arXiv 2506.18123).</p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), st = { pa: 0.6, gap: 0.1, n: 20, seed: 11 }, runs = [], W = 480, H = 380;
    function toX(p) { return 40 + p * (W - 70); }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1; c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono;
      for (var g = 0; g <= 10; g += 2) { var x = toX(g / 10); c.beginPath(); c.moveTo(x, 10); c.lineTo(x, H - 26); c.stroke(); c.fillText(g * 10 + "%", x - 10, H - 10); }
      var pb = Math.min(1, st.pa + st.gap);
      c.setLineDash([4, 4]); c.strokeStyle = P["ink-3"]; c.beginPath(); c.moveTo(toX(st.pa), 10); c.lineTo(toX(st.pa), H - 26); c.stroke();
      c.strokeStyle = P["data-1"]; c.beginPath(); c.moveTo(toX(pb), 10); c.lineTo(toX(pb), H - 26); c.stroke(); c.setLineDash([]);
      var rh = (H - 40) / runs.length;
      runs.forEach(function (r, i) {
        var y = 14 + i * rh, wrong = r.b < r.a, tie = r.b === r.a;
        c.strokeStyle = wrong ? P.bad : tie ? P["ink-3"] : P["line-strong"]; c.lineWidth = wrong ? 2 : 1;
        c.beginPath(); c.moveTo(toX(r.a), y); c.lineTo(toX(r.b), y); c.stroke();
        c.lineWidth = 1.5; c.strokeStyle = P["ink-2"]; c.fillStyle = P.surface; c.beginPath(); c.arc(toX(r.a), y, 3.5, 0, Math.PI * 2); c.fill(); c.stroke();
        c.fillStyle = P["data-1"]; c.beginPath(); c.arc(toX(r.b), y, 3.5, 0, Math.PI * 2); c.fill();
      });
      c.lineWidth = 1;
    }
    function run() {
      var R = RB.rng(st.seed), pb = Math.min(0.99, st.pa + st.gap), wrong = 0;
      runs = [];
      for (var i = 0; i < 40; i++) { var a = binom(R, st.n, st.pa) / st.n, b = binom(R, st.n, pb) / st.n; runs.push({ a: a, b: b }); if (b < a) wrong++; }
      var v = st.pa * (1 - st.pa) + pb * (1 - pb), sd = Math.sqrt(v / st.n), pr = phi((pb - st.pa) / sd);
      RB.setRO(body, "right", Math.round(100 * pr) + "%");
      RB.setRO(body, "wrong", wrong + " of 40");
      RB.setRO(body, "ci", "±" + RB.fmt(100 * ciHalf(st.pa, st.n), 1));
      RB.setRO(body, "n95", String(Math.ceil(1.6449 * 1.6449 * v / ((pb - st.pa) * (pb - st.pa)))));
      st.pr = pr;
      draw();
    }
    RB.bindSlider(body, id + "-pa", pctf, function (v) { st.pa = v; run(); });
    RB.bindSlider(body, id + "-gap", function (v) { return Math.round(v * 100) + " pts"; }, function (v) { st.gap = v; run(); });
    RB.bindSlider(body, id + "-n", null, function (v) { st.n = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed++; run(); });
    RB.onTheme(draw);
    run();
    return { state: function () { return { pa: st.pa, gap: st.gap, n: st.n, pr: st.pr, seed: st.seed }; } };
  }

  /* ================= Playground 3 · benchmark atlas (year × log demos) =================
     Rows read from X1 Table 9 (year, objects, tasks, trajectories, evaluation-focus tags). null = "–" in the table. */
  var ATLAS = [
    ["Meta-World", 2019, null, 50, ["MT"], "MuJoCo"], ["RLBench", 2020, null, 100, ["G", "MT"], "CoppeliaSim"], ["robomimic", 2021, 6000, 8, [], "MuJoCo"],
    ["Franka Kitchen", 2020, 513, 7, ["LH"], "MuJoCo"], ["CALVIN", 2021, 20000, 34, ["LH"], "PyBullet"], ["ManiSkill", 2021, 30000, 4, ["G"], "SAPIEN"],
    ["ManiSkill2", 2023, 30000, 20, ["MT"], "SAPIEN"], ["ManiSkill3", 2025, null, 62, ["DS", "MT"], "SAPIEN"], ["VIMA-Bench", 2023, 600000, 17, ["Lang"], "PyBullet / Ravens"],
    ["VLMbench", 2024, 6000, 8, ["Lang"], "CoppeliaSim"], ["ARNOLD", 2023, 10000, 8, ["G"], "Isaac Sim"], ["LIBERO", 2023, 6500, 130, ["LL"], "MuJoCo / robosuite"],
    ["LIBERO-Plus", 2025, 20000, 10030, ["G"], "MuJoCo"], ["LIBERO-X", 2026, 2520, 600, ["G"], "MuJoCo"], ["COLOSSEUM", 2024, 2000, 20, ["G"], "CoppeliaSim"],
    ["GemBench", 2025, null, 60, ["G"], "CoppeliaSim"], ["AGNOSTOS", 2025, 3600, 41, ["G"], "CoppeliaSim"], ["SimplerEnv", 2024, null, null, ["S2R"], "SAPIEN"],
    ["RoboCasa", 2024, 100000, 100, ["LH"], "MuJoCo / robosuite"], ["GenManip", 2025, null, 200, ["G"], "Isaac Sim"], ["VLABench", 2024, 5000, 100, ["Lang"], "MuJoCo"],
    ["RoboVerse", 2025, 500000, 276, ["S2R", "DS", "MT"], "MetaSim"], ["robosuite", 2020, 12000, 9, ["MT"], "MuJoCo"], ["RoboEval", 2025, 3000, 8, ["G", "Dex"], "–"],
    ["RoboMME", 2026, 1600, 16, ["Mem"], "ManiSkill3"], ["PolaRiS", 2025, 350, null, ["S2R"], "Isaac Sim"], ["RoboTwin", 2025, 320, null, ["MT", "Dex"], "SAPIEN / ManiSkill3"],
    ["BiGym", 2024, 2000, 40, ["MT", "Dex"], "MuJoCo"], ["HumanoidBench", 2024, 45000, 27, ["MT", "Dex"], "MuJoCo"], ["HumanoidGen", 2025, 200000, 20, ["DS", "Dex"], "SAPIEN"],
    ["HomeRobot", 2023, null, 12, ["G", "S2R"], "AI Habitat"], ["ManipulaTHOR", 2021, 12800, 28, ["G"], "AI2-THOR"], ["BEHAVIOR-1K", 2023, 230000, 1000, ["G", "LH"], "OmniGibson"],
    ["SoftGym", 2021, 10000, 10, ["Dex"], "NVIDIA FleX"], ["PlasticineLab", 2021, 1200, 10, ["Dex"], "Taichi"], ["DaXBench", 2023, 9000, 9, ["Dex"], "DaX"],
    ["TacSL", 2025, null, 3, ["S2R", "Dex"], "Isaac Gym"], ["ManiFeel", 2025, null, 6, ["S2R", "Dex"], "Isaac Sim / TacSL"],
    ["RoboArena", 2025, null, null, ["G"], "real robots"], ["RoboChallenge", 2026, null, 30, ["MT"], "real robots"], ["Maniparena", 2026, 10812, 20, ["G", "LH"], "real robots"]
  ].map(function (r, i) { return { i: i, n: r[0], y: r[1], d: r[2], t: r[3], f: r[4], sim: r[5] }; });
  var FOCUS = { G: "generalization", MT: "multi-task", LH: "long-horizon", Lang: "language", DS: "data scaling", S2R: "sim-to-real", Dex: "dexterity", Mem: "memory", LL: "lifelong" };

  function mountAtlas(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-focus", label: "Evaluation focus", value: "all", options: [{ value: "all", label: "All" }, { value: "G", label: "Generalization" }, { value: "LH", label: "Long-horizon" }, { value: "S2R", label: "Sim-to-real" }, { value: "Dex", label: "Dexterity" }, { value: "Lang", label: "Language" }] }) +
      RB.seg({ id: id + "-axis", label: "Vertical axis", value: "d", options: [{ value: "d", label: "Demos" }, { value: "t", label: "Tasks" }] }) +
      '<label class="sb-field"><span>Benchmark</span><select id="' + id + '-sel">' + ATLAS.slice().sort(function (a, b) { return a.n.localeCompare(b.n); }).map(function (b) { return '<option value="' + b.i + '">' + b.n + "</option>"; }).join("") + "</select></label></div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Scatter of manipulation benchmarks by year and log number of demonstrations"></canvas>' +
      '<figcaption class="sb-caption">Each dot is one benchmark, placed by year and by demonstrations (log scale). Dots in the bottom strip report no count. Click a dot or pick a name.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "shown", k: "Benchmarks with this focus" }, { id: "med", k: "Median of reported counts" }, { id: "none", k: "No count reported" }]) +
      '<div class="rb-well"><p class="rb-h5" data-name>–</p><p class="sb-caption" data-detail>–</p></div></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), sel = body.querySelector("#" + id + "-sel"), W = 520, H = 360, st = { focus: "all", axis: "d", sel: 11 }, pts = [];
    sel.value = "11";
    function val(b) { return st.axis === "d" ? b.d : b.t; }
    function on(b) { return st.focus === "all" || b.f.indexOf(st.focus) >= 0; }
    var Y0 = 1, Y1 = 6, yr0 = 2018.5, yr1 = 2026.5;
    function place(b) {
      var same = ATLAS.filter(function (o) { return o.y === b.y; }), k = same.indexOf(b), jit = (k - (same.length - 1) / 2) * 9;
      var x = 50 + (b.y - yr0) / (yr1 - yr0) * (W - 70) + Math.max(-26, Math.min(26, jit));
      var v = val(b), y = v == null ? H - 36 : 16 + (1 - (Math.log10(v) - Y0) / (Y1 - Y0)) * (H - 78);
      if (v == null) y += (k % 2) * 8 - 4;
      return [x, y];
    }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mono = monoFont(), bf = bodyFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1; c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono;
      for (var e = Y0; e <= Y1; e++) { var y = 16 + (1 - (e - Y0) / (Y1 - Y0)) * (H - 78); c.beginPath(); c.moveTo(44, y); c.lineTo(W - 10, y); c.stroke(); c.fillText(e === 1 ? "10" : "1e" + e, 8, y + 4); }
      for (var yr = 2019; yr <= 2026; yr++) { var x = 50 + (yr - yr0) / (yr1 - yr0) * (W - 70); c.fillText("’" + String(yr).slice(2), x - 8, H - 6); }
      c.fillStyle = P["surface-sunk"]; c.fillRect(44, H - 48, W - 54, 22); c.fillStyle = P["ink-3"]; c.fillText("no count", 48, H - 52);
      pts = [];
      ATLAS.forEach(function (b) {
        var p = place(b), isOn = on(b), isSel = b.i === st.sel; pts.push({ b: b, x: p[0], y: p[1] });
        c.globalAlpha = isOn ? 1 : 0.2;
        c.fillStyle = b.sim === "real robots" ? P["data-3"] : P["data-1"];
        c.beginPath(); c.arc(p[0], p[1], isSel ? 7 : 5, 0, Math.PI * 2); c.fill();
        if (isSel) { c.strokeStyle = P.ink; c.lineWidth = 2; c.stroke(); c.lineWidth = 1; }
        c.globalAlpha = 1;
      });
      var s = pts.filter(function (q) { return q.b.i === st.sel; })[0];
      if (s) { c.fillStyle = P.ink; c.font = "600 12px " + bf; var tw = c.measureText(s.b.n).width, lx = Math.min(W - tw - 6, s.x + 10); c.fillText(s.b.n, lx, s.y < 30 ? s.y + 16 : s.y - 10); }
    }
    function detail() {
      var b = ATLAS[st.sel];
      body.querySelector("[data-name]").textContent = b.n + " (" + b.y + ")";
      body.querySelector("[data-detail]").textContent = "Simulator: " + b.sim + ". Tasks: " + (b.t == null ? "not reported" : b.t) + ". Demonstrations: " + (b.d == null ? "not reported" : b.d.toLocaleString("en-US")) + ". Focus: " + (b.f.length ? b.f.map(function (k) { return FOCUS[k]; }).join(", ") : "none tagged") + ".";
    }
    function run() {
      var shown = ATLAS.filter(on), vals = shown.map(val).filter(function (v) { return v != null; }).sort(function (a, b) { return a - b; });
      RB.setRO(body, "shown", shown.length + " of " + ATLAS.length);
      var med = vals.length ? (vals.length % 2 ? vals[(vals.length - 1) / 2] : (vals[vals.length / 2 - 1] + vals[vals.length / 2]) / 2) : null;
      RB.setRO(body, "med", med == null ? "–" : Math.round(med).toLocaleString("en-US"));
      RB.setRO(body, "none", String(shown.length - vals.length));
      detail(); draw();
    }
    bindSeg(body, id + "-focus", function (v) { st.focus = v; run(); });
    bindSeg(body, id + "-axis", function (v) { st.axis = v; run(); });
    sel.addEventListener("change", function () { st.sel = +sel.value; run(); });
    cv.addEventListener("click", function (ev) {
      var r = cv.getBoundingClientRect(), mx = (ev.clientX - r.left) * W / r.width, my = (ev.clientY - r.top) * H / r.height, best = null, bd = 400;
      pts.forEach(function (q) { var d = (q.x - mx) * (q.x - mx) + (q.y - my) * (q.y - my); if (d < bd) { bd = d; best = q; } });
      if (best) { st.sel = best.b.i; sel.value = String(best.b.i); run(); }
    });
    RB.onTheme(draw);
    run();
    return { state: function () { return { focus: st.focus, axis: st.axis, sel: st.sel }; } };
  }

  /* ---------- concept-card drawings (200 × 56, token colors only) ---------- */
  var ART = {
    suite: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(function (i) { var x = 14 + (i % 5) * 22, y = 6 + Math.floor(i / 5) * 22; return '<rect x="' + x + '" y="' + y + '" width="16" height="16" rx="3" class="' + (i < 7 ? "rb-f-soft" : "rb-f-surface") + '"/>'; }).join("") + '<text x="130" y="22" class="rb-t-ink">7 of 10</text><text x="130" y="40" class="rb-t-mono">SR = 0.70</text></svg>',
    chain: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (i) { var x = 20 + i * 36; return (i < 4 ? '<path d="M' + (x + 9) + ' 22 H' + (x + 27) + '" class="rb-s-line"/>' : "") + '<circle cx="' + x + '" cy="22" r="9" class="' + (i < 3 ? "rb-f-soft" : "rb-f-surface") + '"/><text x="' + x + '" y="26" text-anchor="middle" class="rb-t-mono">' + (i + 1) + "</text>"; }).join("") + '<text x="100" y="50" text-anchor="middle" class="rb-t-mono">3 in a row, then a miss</text></svg>',
    ceiling: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="10" y1="10" x2="190" y2="10" class="rb-s-line" stroke-dasharray="3 3"/><text x="12" y="8" class="rb-t-mono">100%</text><path d="M10 50 C50 44 70 20 110 14 S170 11 190 11" class="rb-s-acc"/><circle cx="72" cy="26" r="3" class="rb-f-acc"/><circle cx="112" cy="14" r="3" class="rb-f-acc"/><circle cx="160" cy="11.5" r="3" class="rb-f-acc"/><text x="120" y="40" class="rb-t-mono">gaps shrink</text></svg>',
    perturb: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="20" y="6" width="26" height="34" class="rb-f-soft"/><rect x="58" y="34" width="26" height="6" class="rb-f-surface"/><text x="33" y="53" text-anchor="middle" class="rb-t-mono">std</text><text x="71" y="53" text-anchor="middle" class="rb-t-mono">shift</text><rect x="112" y="12" width="30" height="20" rx="3" class="rb-f-surface" transform="rotate(-18 127 22)"/><circle cx="130" cy="21" r="5" class="rb-f-sunk"/><text x="152" y="26" class="rb-t-mono">camera</text></svg>',
    realsim: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="4" width="60" height="32" rx="4" class="rb-f-surface"/><text x="40" y="24" text-anchor="middle" class="rb-t-ink">real</text><rect x="130" y="4" width="60" height="32" rx="4" class="rb-f-soft"/><text x="160" y="24" text-anchor="middle" class="rb-t-ink">sim</text><path d="M76 14 H124 M118 10 L124 14 L118 18" class="rb-s-ink"/><path d="M124 27 H76 M82 23 L76 27 L82 31" class="rb-s-line"/><text x="100" y="52" text-anchor="middle" class="rb-t-mono">match looks and control</text></svg>',
    rank: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="20" y1="10" x2="180" y2="10" class="rb-s-line"/><line x1="20" y1="46" x2="180" y2="46" class="rb-s-line"/><path d="M40 10 L60 46 M80 10 L120 46 M120 10 L100 46 M160 10 L150 46" class="rb-s-ink"/><path d="M80 10 L120 46 M120 10 L100 46" class="rb-s-acc"/><text x="4" y="14" class="rb-t-mono">R</text><text x="4" y="50" class="rb-t-mono">Rₛ</text><text x="186" y="32" text-anchor="end" class="rb-t-acc">flip</text></svg>',
    arena: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="6" width="44" height="28" rx="6" class="rb-f-soft"/><text x="32" y="25" text-anchor="middle" class="rb-t-acc">A</text><rect x="146" y="6" width="44" height="28" rx="6" class="rb-f-surface"/><text x="168" y="25" text-anchor="middle" class="rb-t-ink">B</text><text x="100" y="25" text-anchor="middle" class="rb-t-ink">A &gt; B ?</text><text x="100" y="51" text-anchor="middle" class="rb-t-mono">same scene, blind</text></svg>',
    tiers: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="10" y="6" width="96" height="12" rx="3" class="rb-f-surface"/><rect x="10" y="22" width="68" height="12" rx="3" class="rb-f-soft"/><rect x="10" y="38" width="40" height="12" rx="3" class="rb-f-acc"/><text x="114" y="16" class="rb-t-mono">looks right</text><text x="114" y="32" class="rb-t-mono">physics</text><text x="114" y="48" class="rb-t-mono">acts right</text></svg>'
  };

  /* ---------- worked example: MMRV by hand (SIMPLER eq. 1–2). Our toy numbers. ---------- */
  var REAL = [0.1, 0.3, 0.5, 0.7], OFF = [0.2, 0.4, 0.6, 0.8], SIM = [0.25, 0.2, 0.6, 0.5], NAMES = ["A", "B", "C", "D"];
  var WX = function (v) { return (130 + v * 620).toFixed(1); };
  var YO = 36, YR = 112, YS = 190;
  function joins(vals, y0, y1, cls) { return vals.map(function (v, i) { return '<path d="M' + WX(REAL[i]) + " " + y0 + " L" + WX(v) + " " + y1 + '" class="' + cls + '"/>'; }).join(""); }
  var WE_FIG = '<svg viewBox="0 0 640 300" role="img" aria-label="Three number lines: a constant-offset evaluator on top, real success in the middle, a policy-specific evaluator below; crossing lines are rank flips">' +
    '<line x1="120" y1="' + YR + '" x2="630" y2="' + YR + '" class="rb-s-line"/><text x="4" y="' + (YR + 4) + '" class="rb-t-mono">real R</text>' +
    '<g data-on="1+">' + REAL.map(function (v, i) { return '<circle cx="' + WX(v) + '" cy="' + YR + '" r="6" class="rb-f-acc"/><text x="' + (+WX(v) - 10) + '" y="' + (YR - 8) + '" text-anchor="end" class="rb-t-ink">' + NAMES[i] + " " + v.toFixed(1) + "</text>"; }).join("") + "</g>" +
    '<g data-on="2+"><line x1="120" y1="' + YO + '" x2="630" y2="' + YO + '" class="rb-s-line"/><text x="4" y="' + (YO + 4) + '" class="rb-t-mono">offset eval.</text>' + joins(OFF, YR - 6, YO + 6, "rb-s-line") + OFF.map(function (v) { return '<circle cx="' + WX(v) + '" cy="' + YO + '" r="6" class="rb-f-surface"/><text x="' + WX(v) + '" y="' + (YO - 12) + '" text-anchor="middle" class="rb-t-mono">' + v.toFixed(2) + "</text>"; }).join("") + '<text x="4" y="256" class="rb-t-ink">Offset evaluator: +0.10 for every policy, no lines cross, MMRV = 0</text></g>' +
    '<g data-on="3+"><line x1="120" y1="' + YS + '" x2="630" y2="' + YS + '" class="rb-s-line"/><text x="4" y="' + (YS + 4) + '" class="rb-t-mono">evaluator Rₛ</text>' + joins(SIM, YR + 6, YS - 6, "rb-s-ink") + SIM.map(function (v) { return '<circle cx="' + WX(v) + '" cy="' + YS + '" r="6" class="rb-f-soft"/><text x="' + WX(v) + '" y="' + (YS + 20) + '" text-anchor="middle" class="rb-t-mono">' + v.toFixed(2) + "</text>"; }).join("") + "</g>" +
    '<g data-on="4+"><path d="M' + WX(0.1) + " " + (YR + 6) + " L" + WX(0.25) + " " + (YS - 6) + " M" + WX(0.3) + " " + (YR + 6) + " L" + WX(0.2) + " " + (YS - 6) + '" class="rb-s-acc"/><path d="M' + WX(0.5) + " " + (YR + 6) + " L" + WX(0.6) + " " + (YS - 6) + " M" + WX(0.7) + " " + (YR + 6) + " L" + WX(0.5) + " " + (YS - 6) + '" class="rb-s-acc"/>' +
    '<text x="' + WX(0.225) + '" y="230" text-anchor="middle" class="rb-t-acc">A–B flip: 0.20</text><text x="' + WX(0.55) + '" y="230" text-anchor="middle" class="rb-t-acc">C–D flip: 0.20</text></g>' +
    '<g data-on="5+"><text x="4" y="274" class="rb-t-ink">Each policy\'s worst flip is 0.20, so MMRV = 0.20</text></g>' +
    '<g data-on="6"><text x="4" y="292" class="rb-t-ink">Pearson r = 0.77 · Spearman ρ = 0.60</text></g></svg>';

  RB.topic({
    id: "f3",
    title: "Benchmarks and what they miss",
    eyebrow: "Part F · Trust and evaluation",
    lede: "A benchmark turns a policy into one number. Learn what that number measures, how noisy it is, and what it leaves out.",
    refs: ["P01 §2.4, §3", "X1 §6", "P03 §7", "X3 §VIII"],
    why: "Every method in this course reports benchmark scores. LIBERO averages are now above 97%, where one-point gaps sit inside the noise of 500 episodes. The same policies can drop below 16% when the camera moves. Knowing how suites, metrics and proxy evaluators work tells you which reported gains to trust.",
    outcomes: [
      "Compute a success rate and its 95% interval from episode counts.",
      "Compute MMRV by hand for a simulated evaluator against real trials.",
      "Explain why saturated suites cannot rank today's best policies.",
      "Compare fixed suites, perturbation suites, real-to-sim evaluators and real-robot arenas.",
      "Name the three tiers used to evaluate world models."
    ],
    concepts: [
      { name: "Task suite and success rate", def: "A fixed set of tasks and start states; success rate is successful episodes over all episodes.", ref: "P01 §2.4 · X3 Table III", art: ART.suite, term: "success-rate", sym: "sr" },
      { name: "Chained instructions", def: "CALVIN chains five instructions and counts how many succeed in a row: the average length.", ref: "CALVIN, arXiv 2112.03227", art: ART.chain, term: "average-chain-length", sym: "acs" },
      { name: "Saturation", def: "When most methods score near 100%, gaps shrink below the noise and the suite stops ranking.", ref: "P03 Table 5, §7.3", art: ART.ceiling, term: "benchmark-saturation" },
      { name: "Perturbation suites", def: "COLOSSEUM adds 14 perturbation factors to RLBench; LIBERO-Plus adds seven to LIBERO, such as camera pose.", ref: "arXiv 2402.08191 · 2510.13626", art: ART.perturb, term: "perturbation-benchmark" },
      { name: "Real-to-sim evaluation", def: "SIMPLER rebuilds real setups in simulation; PolaRiS replaces its green screens with Gaussian splats from phone scans.", ref: "arXiv 2405.05941 · 2512.16881", art: ART.realsim, term: "real-to-sim-evaluation" },
      { name: "Rank fidelity", def: "An evaluator is trusted if it orders policies like real trials; MMRV weights each flip by the real gap.", ref: "SIMPLER eq. 1–2", art: ART.rank, term: "mean-maximum-rank-violation", sym: "mmrv" },
      { name: "Real-robot arenas", def: "RoboArena compares two policies blind on the same evaluator-chosen scene and fits their abilities from preferences.", ref: "arXiv 2506.18123 · X1 §6.2.5", art: ART.arena, term: "pairwise-arena-evaluation" },
      { name: "World-model tiers", def: "Surveys test world models on looks, then physics, then whether their predictions can be executed.", ref: "X1 §6.1 · X3 §VIII · P03 §7.1", art: ART.tiers, term: "world-model-evaluation-tiers" }
    ],
    flow: {
      title: "Where a benchmark enters the loop", ref: "P01 §2.4 · X3 §VIII", w: 820, h: 270,
      caption: "A score comes from a trained checkpoint, an evaluator and an episode count. Simulated evaluators are cheap; real trials are ground truth. The dashed edge is the check that links them.",
      nodes: [
        { id: "data", x: 20, y: 110, w: 150, h: 52, label: "Demonstrations", sub: "fixed training split", kind: "store" },
        { id: "policy", x: 220, y: 110, w: 150, h: 52, label: "Policy π", sub: "chosen checkpoint", kind: "agent" },
        { id: "bench", x: 430, y: 24, w: 170, h: 56, label: "Simulated suite", sub: "tasks, seeds, n episodes", kind: "env" },
        { id: "real", x: 430, y: 190, w: 170, h: 56, label: "Real robot", sub: "slow, costly trials", kind: "env" },
        { id: "metric", x: 660, y: 110, w: 140, h: 52, label: "Score", sub: "SR, ACS, rank", kind: "decision" }
      ],
      edges: [
        { from: "data", to: "policy", label: "train" },
        { from: "policy", to: "bench", label: "sim rollouts", sides: ["t", "l"], via: [[295, 52]] },
        { from: "policy", to: "real", label: "real trials", sides: ["b", "l"], via: [[295, 218]] },
        { from: "bench", to: "metric", label: "success counts", sides: ["r", "t"], via: [[730, 52]] },
        { from: "real", to: "metric", label: "true rate", sides: ["r", "b"], via: [[730, 218]] },
        { from: "bench", to: "real", label: "rank check", sides: ["b", "t"], dashed: true }
      ],
      steps: [
        { on: ["data", "data>policy", "policy"], text: "A policy trains on the benchmark's fixed demonstrations, such as 50 per LIBERO task. Which checkpoint gets reported is already a protocol choice (P01 §2.4)." },
        { on: ["policy>bench", "bench"], text: "The simulated suite runs n episodes per task. OpenVLA-OFT ran 10 tasks × 50 episodes = 500 per LIBERO suite." },
        { on: ["bench>metric", "metric"], text: "Successes become a score: a success rate, or an average chain length on CALVIN. A score without its episode count hides its noise." },
        { on: ["policy>real", "real", "real>metric"], text: "Real trials are the ground truth, but slow: the real ALOHA tasks in OpenVLA-OFT used 10 to 24 trials each." },
        { on: ["bench>real", "bench", "real"], text: "A simulated or learned evaluator is trusted only if it ranks policies the way real trials do. SIMPLER measures this with MMRV." }
      ]
    },
    worked: {
      title: "Scoring a simulated evaluator with MMRV",
      ref: "SIMPLER eq. 1–2, arXiv 2405.05941", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-mmrv}{\\mathrm{MMRV}} = \\frac{1}{\\class{sym-npol}{N}} \\sum_{i} \\max_{j}\\ |\\class{sym-rreal}{R_i} - \\class{sym-rreal}{R_j}|\\ \\mathbb{1}\\big[(\\class{sym-rsim}{R_{S,i}} < \\class{sym-rsim}{R_{S,j}}) \\neq (\\class{sym-rreal}{R_i} < \\class{sym-rreal}{R_j})\\big]", words: "For each policy, find the worst pair it is wrongly ordered against, weighted by their real gap; average over policies.", key: ["mmrv", "npol", "rreal", "rsim", { glyph: "𝟙[·]", meaning: "1 if the order flips" }] },
      figure: WE_FIG,
      steps: [
        { title: "Real trials first", text: "Four policies have real success rates A 0.1, B 0.3, C 0.5 and D 0.7." },
        { title: "A constant offset", text: "One evaluator adds 0.10 to every policy. Every number is wrong, but no lines cross, so MMRV = 0." },
        { title: "Policy-specific errors", text: "A second evaluator gives 0.25, 0.20, 0.60 and 0.50: each policy is off by a different amount." },
        { title: "Find the flips", text: "A and B swap, as do C and D. Weight each flip by its real gap: 0.3 − 0.1 = 0.20 and 0.7 − 0.5 = 0.20." },
        { title: "Average the worst", text: "Each policy's worst flip is 0.20, so MMRV = (0.2 + 0.2 + 0.2 + 0.2) / 4 = 0.20." },
        { title: "Compare correlations", text: "Pearson r = 0.77 and Spearman ρ = 0.60. SIMPLER's visual matching reached MMRV 0.056; validation MSE only 0.375." }
      ]
    },
    ruleTitle: "Four ways to turn episodes into a number",
    rules: [
      { name: "Success rate with its interval", ref: "X3 Table III · interval ours", term: "success-rate",
        tex: "\\class{sym-sr}{\\widehat{\\mathrm{SR}}} = \\frac{k}{\\class{sym-neps}{n}}, \\qquad \\class{sym-sr}{\\widehat{\\mathrm{SR}}} \\pm 1.96\\sqrt{\\frac{\\class{sym-sr}{\\widehat{\\mathrm{SR}}}\\,(1 - \\class{sym-sr}{\\widehat{\\mathrm{SR}}})}{\\class{sym-neps}{n}}}",
        words: "Count successes over episodes; the normal-approximation 95% interval narrows only with the square root of n.",
        key: ["sr", { glyph: "k", meaning: "successful episodes" }, "neps", { glyph: "1.96", meaning: "95% normal quantile" }] },
      { name: "Average completed subtasks", ref: "X3 Table III · CALVIN", term: "average-chain-length",
        tex: "\\class{sym-acs}{\\mathrm{ACS}} = \\frac{1}{\\class{sym-neps}{n}} \\sum_{i=1}^{\\class{sym-neps}{n}} c_i",
        words: "Average, over episodes, how many chained subtasks succeed in a row before the first failure. CALVIN's maximum is 5.",
        key: ["acs", "neps", { glyph: "cᵢ", meaning: "consecutive subtasks done in episode i" }] },
      { name: "Sample efficiency", ref: "X3 Table III", term: "sample-efficiency-metric",
        tex: "\\class{sym-se}{\\mathrm{SE}} = \\inf \\{\\, \\class{sym-neps}{n} \\ \\mid\\ \\class{sym-sr}{\\mathrm{SR}}_{\\class{sym-neps}{n}} \\geq \\class{sym-srstar}{\\mathrm{SR}^\\star} \\,\\}",
        words: "The fewest training episodes or steps after which the success rate reaches a target. Lower is better.",
        key: ["se", "neps", "sr", "srstar", { glyph: "inf", meaning: "smallest value that qualifies" }] },
      { name: "RoboArena: task-aware pairwise model", ref: "RoboArena, arXiv 2506.18123", term: "pairwise-arena-evaluation",
        before: "p(A \\succ B) = \\sigma\\big(\\class{sym-abil}{u_A} - \\class{sym-abil}{u_B}\\big)",
        tex: "p(A \\succ B) = \\class{sb-new}{\\sum_{t} \\class{sym-tbucket}{\\nu_t}}\\ \\sigma\\big(\\class{sym-abil}{u_A} + \\class{sb-new}{\\class{sym-toff}{\\psi^A_t}} - \\class{sb-new}{\\class{sym-tdiff}{d_t}}\\big)\\ \\class{sb-chg}{\\big(1 - \\sigma(\\class{sym-abil}{u_B} + \\class{sym-toff}{\\psi^B_t} - \\class{sym-tdiff}{d_t})\\big)}",
        words: "Standard Bradley–Terry compares two abilities. RoboArena mixes over latent task buckets with a difficulty and per-policy offsets.",
        key: [{ glyph: "A ≻ B", meaning: "A preferred over B" }, { glyph: "σ", meaning: "logistic sigmoid" }, "abil", "tbucket", "toff", "tdiff"], diff: true, beforeLabel: "Bradley–Terry", afterLabel: "RoboArena" }
    ],
    algorithm: {
      title: "Reporting a benchmark result you can trust", ref: "P01 §2.4 · X3 §VIII-B · arXiv 2502.19645", prov: "Our checklist from the sources",
      lines: [
        '<span class="kw">fix</span> the suite, its demos and the start-state seeds; state the policy inputs <span class="cm">// wrist camera, proprioception</span>',
        '<span class="kw">choose</span> the checkpoint rule before looking: best of every k epochs, top-n average, or last',
        '<span class="kw">for</span> each task: run <span data-sym="neps">n</span> episodes <span class="cm">// OpenVLA-OFT: 50 per task</span>',
        '<span data-sym="sr">SR</span> ← successes / <span data-sym="neps">n</span>; report ±1.96·√(<span data-sym="sr">SR</span>(1 − <span data-sym="sr">SR</span>)/<span data-sym="neps">n</span>) per suite',
        'report each suite, not only the average <span class="cm">// Long separates methods</span>',
        'add a perturbation or unseen-task split <span class="cm">// LIBERO-Plus, COLOSSEUM, AGNOSTOS</span>',
        '<span class="kw">if</span> a proxy evaluator is used: report its <span data-sym="mmrv">MMRV</span> against paired real trials'
      ]
    },
    playgrounds: [
      {
        id: "board", title: "Results board: one benchmark, filtered by suite", ref: "P03 Table 5 · arXiv 2502.19645 · 2510.13626", prov: "Reported numbers; intervals ours",
        try: "Start on Average: the top five sit within about one point. Switch to Long and compare the spread. Lower the episodes to 50, then choose Camera shift.",
        mount: mountBoard,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "f3-board";
          return [
            { target: q("canvas"), title: "A crowded top", text: "On the four-suite average, the best methods lie within about one point of each other, all above 97%." },
            { target: q("#" + id + "-view"), title: "The Long suite", text: "Long-horizon tasks still separate methods: the gap from first to last place is widest here.", do: function (a) { return a.click(q("#" + id + '-view [value="3"]')); }, task: "Choose Long", expect: function () { return api.state().view === "3"; } },
            { target: q("#" + id + "-n"), title: "Fewer episodes", text: "With 50 episodes per suite, each whisker spans several points, and neighbors blur into ties.", do: function (a) { return a.set(q("#" + id + "-n"), 50); }, task: "Set episodes to 100 or fewer", expect: function () { return api.state().n <= 100; } },
            { target: q("#" + id + "-zoom"), title: "Zoom in", text: "Zooming to the top 15 points shows how small the reported differences are next to the noise.", do: function (a) { return a.click(q("#" + id + "-zoom")); }, task: "Tick Zoom to 85–100%", expect: function () { return api.state().zoom; } },
            { target: q("#" + id + "-view"), title: "Move the camera", text: "LIBERO-Plus shifts the camera. Scores that looked tied at 94–97% split apart and collapse.", do: function (a) { return a.click(q("#" + id + '-view [value="cam"]')); }, task: "Choose Camera shift", expect: function () { return api.state().view === "cam"; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Go back to Object with 500 episodes. How many of the top-five neighbor gaps can the episodes actually resolve?" }
          ];
        }
      },
      {
        id: "budget", title: "How many episodes to rank two policies", ref: "X3 Table III · SIMPLER", prov: "Simplified: independent Bernoulli episodes",
        try: "With 20 episodes each, about a quarter of evaluations put the worse policy first. Raise the episodes to 200, then shrink the gap to 2 points.",
        mount: mountBudget,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "f3-budget";
          return [
            { target: q("canvas"), title: "Forty evaluations", text: "Each row is a complete evaluation of A and B with 20 episodes each. Red rows rank them the wrong way round." },
            { target: q("#" + id + "-n"), title: "More episodes", text: "The spread of each estimate falls with the square root of n, so the red rows become rare.", do: function (a) { return a.set(q("#" + id + "-n"), 200); }, task: "Set episodes to 150 or more", expect: function () { return api.state().n >= 150; } },
            { target: q("#" + id + "-gap"), title: "A small gap", text: "A two-point gain, like many leaderboard gains, needs thousands of episodes to order reliably.", do: function (a) { return a.set(q("#" + id + "-gap"), 0.02); }, task: "Set the gap to 3 points or less", expect: function () { return api.state().gap <= 0.03; } },
            { target: q("#" + id + "-go"), title: "Run it again", text: "A new seed draws new evaluations. The wrong-order count changes; the chance readout does not.", do: function (a) { return a.click(q("#" + id + "-go")); }, task: "Press Evaluate again", expect: function () { return api.state().seed > 11; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Set A to 85% with a 10-point gap. Why do fewer episodes suffice near the ceiling than near 50%?" }
          ];
        }
      },
      {
        id: "atlas", title: "Benchmark atlas: year against scale", ref: "X1 Table 9 · P01 Tables 2–3", prov: "Counts as listed in X1 Table 9",
        try: "Filter by Sim-to-real: most of these report no demonstration count. Switch the axis to Tasks and pick LIBERO-Plus.",
        mount: mountAtlas,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "f3-atlas";
          return [
            { target: q("canvas"), title: "Scale grew fast", text: "From 513 demonstrations in Franka Kitchen to 500K in RoboVerse and 600K in VIMA-Bench. Real-robot benchmarks use the second color." },
            { target: q("#" + id + "-focus"), title: "Sim-to-real focus", text: "Benchmarks built to predict real results rarely ship demonstrations; they test policies trained elsewhere.", do: function (a) { return a.click(q("#" + id + '-focus [value="S2R"]')); }, task: "Choose Sim-to-real", expect: function () { return api.state().focus === "S2R"; } },
            { target: q("#" + id + "-axis"), title: "Count tasks instead", text: "Task counts range from 3 in TacSL to 10,030 perturbed variants in LIBERO-Plus.", do: function (a) { return a.click(q("#" + id + '-axis [value="t"]')); }, task: "Choose Tasks", expect: function () { return api.state().axis === "t"; } },
            { target: q("#" + id + "-sel"), title: "Read one entry", text: "LIBERO-Plus keeps LIBERO's scenes and multiplies them by perturbations, which is how its task count explodes.", do: function (a) { return a.set(q("#" + id + "-sel"), "12"); }, task: "Pick LIBERO-Plus", expect: function () { return api.state().sel === 12; } },
            { target: q("#" + id + "-focus"), title: "Your turn", text: "Filter by Dexterity. Which simulators appear, and why might contact-rich tasks need different engines?" }
          ];
        }
      }
    ],
    methods: ["libero", "calvin", "simpler", "rlbench", "meta-world", "robomimic", "maniskill3", "worldsimbench", "ewmbench", "colosseum", "libero-plus", "polaris", "roboarena"],
    methodsLede: "Benchmarks, not policies. Read the Builds on column as a lineage: each suite changed what its predecessor measured.",
    open: [
      { title: "Contact is barely tested", text: "Standard suites emphasize rigid pick-and-place; insertion, cloth, tools and slip need force-aware metrics that vision-only scores cannot provide.", refs: "X3 §VIII-D" },
      { title: "Fragmented metrics", text: "No widely adopted metric covers visual quality, physics, action alignment and downstream use, so papers report the metric that favors them.", refs: "X3 §VIII-D · P03 §7.1" },
      { title: "No joint WAM protocol", text: "World action models are scored with separate video metrics and policy suites; no protocol tests whether predictions and actions agree.", refs: "X1 §6" },
      { title: "Attribution and exploitation", text: "A higher score may come from representations, extra data or search. Policies optimized inside a learned evaluator can exploit its errors.", refs: "X3 §VIII-B, §VIII-D" }
    ],
    takeaways: [
      "A success rate is only as precise as its episode count; at 500 episodes, a 97% score carries about ±1.5 points.",
      "LIBERO is near its ceiling: top methods in P03 Table 5 differ by about one point, yet a camera shift drops some below 16%.",
      "Perturbation and unseen-task suites (COLOSSEUM, LIBERO-Plus, AGNOSTOS) expose what fixed suites hide.",
      "A proxy evaluator must rank policies like real trials. MMRV weights each flip by the real gap; a constant offset costs nothing.",
      "World-model benchmarks moved from appearance to physics to executability; visually convincing videos can still fail the inverse-dynamics test."
    ],
    quiz: [
      { q: "A policy succeeds in 485 of 500 episodes. Roughly what is the 95% interval on its success rate?", options: ["97% ± 0.1 points", "97% ± 1.5 points", "97% ± 5 points", "Exactly 97%, no interval"], correct: 1, why: "1.96 × √(0.97 × 0.03 / 500) ≈ 0.015, so about ±1.5 points. Many LIBERO gaps between top methods are smaller than that." },
      { q: "A simulator adds 0.10 to every policy's real success rate. What is its MMRV?", options: ["0.10", "0", "0.20", "It cannot be computed"], correct: 1, why: "A constant offset preserves every pairwise order, so there are no rank violations and MMRV is 0 (SIMPLER eq. 1–2)." },
      { q: "What did LIBERO-Plus find when it moved the camera for π0?", options: ["Success stayed near 94%", "Success fell from 94.2% to 15.8%", "Success rose slightly", "The policy refused to act"], correct: 1, why: "π0 fell from 94.2% to 15.8% under camera perturbation; UniVLA fell to 4.3% and OpenVLA-OFT to 59.7% (arXiv 2510.13626)." },
      { q: "Which tier asks whether a world model's generated video can be turned into executable actions?", options: ["Visual fidelity", "Physical commonsense", "Action plausibility", "Data scaling"], correct: 2, why: "X1 §6.1.3 calls it action plausibility: WorldSimBench and the IDM Turing test convert generated videos into actions and check execution." },
      { q: "On CALVIN, what does an average length of 3 mean?", options: ["Episodes last three seconds", "On average three of five chained instructions succeed in a row", "Three tasks were tested", "Three cameras were used"], correct: 1, why: "CALVIN evaluates chains of five instructions and advances only on success; the average length counts consecutive successes per chain (X3 Table III, ACS)." }
    ],
    cards: [
      { front: "What does SIMPLER change compared with sim-to-real training?", back: "It evaluates real-trained policies in simulation, matching control by system identification and visuals by green screens and textures, then checks ranking against paired real trials.", ref: "arXiv 2405.05941" },
      { front: "SIMPLER's MMRV and Pearson r on Google Robot tasks versus validation MSE?", back: "Visual matching: MMRV 0.056, r 0.924. Validation action MSE: MMRV 0.375, r 0.308.", ref: "arXiv 2405.05941" },
      { front: "What did COLOSSEUM add to RLBench, and what happened?", back: "14 perturbation factors over 20 tasks. Single factors cut success by 30–50%; all combined by at least 75%.", ref: "arXiv 2402.08191" },
      { front: "How did CALVIN extend earlier play-data setups?", back: "34 instead of 18 subtasks, chains of 5 instead of 4, several sensors, four environments and zero-shot ABC→D evaluation.", ref: "arXiv 2112.03227" },
      { front: "How does GraspNet-1Billion score a grasp detector?", back: "Average precision: mean precision over the top 1 to 50 grasps, averaged over friction coefficients 0.2 to 1.0, scored by an analytic force-closure check.", ref: "GraspNet-1Billion, CVPR 2020" },
      { front: "What gap did AGNOSTOS measure for π0?", back: "70.5% on 18 seen RLBench tasks versus 17.5% on 23 unseen tasks.", ref: "arXiv 2505.15660" },
      { front: "Name the three evaluation tiers for world models in X3.", back: "Direct predictive fidelity, downstream task performance and simulator reliability, such as policy-rank correlation.", ref: "X3 §VIII, Table III" }
    ],
    terms: {
      "success-rate": { name: "success rate", aliases: ["SR", "task success rate"], group: "eval", sym: "SR", symTex: "\\mathrm{SR}", def: "The fraction of evaluation episodes in which the task is completed, under a fixed evaluation protocol.", note: "Without the episode count it has no error bar; 50 and 500 episodes give very different precision.", ref: "P01 §2.4 · X3 Table III", scene: "system", focus: ["simulator", "robot"], look: "episodes ending in success", uses: ["evaluation-budget"] },
      "average-chain-length": { name: "average chain length", aliases: ["average length", "Avg. Len.", "average completed subtasks", "ACS"], group: "eval", sym: "ACS", symTex: "\\mathrm{ACS}", def: "In long-horizon evaluation, the average number of consecutive subtasks completed before the first failure; CALVIN chains five instructions.", note: "It rewards early steps most: failing step one ends the chain.", ref: "X3 Table III · CALVIN", scene: "system", focus: ["instruction", "simulator"], look: "a chain of five instructions", uses: ["success-rate"] },
      "benchmark-saturation": { name: "benchmark saturation", aliases: ["ceiling effect", "saturated benchmark"], group: "eval", def: "The state in which most methods score near the maximum, so differences between them fall within evaluation noise.", note: "A saturated suite can still catch regressions; it can no longer rank the best methods.", ref: "P03 Table 5, §7.3", scene: "system", focus: ["simulator"], look: "scores bunched near 100%", uses: ["success-rate", "evaluation-budget"] },
      "perturbation-benchmark": { name: "perturbation benchmark", aliases: ["robustness suite", "LIBERO-Plus", "COLOSSEUM"], group: "eval", def: "A benchmark that re-runs known tasks under controlled changes, such as camera pose, lighting, textures, distractors or robot start state, to measure robustness.", note: "Training still uses the unperturbed data; the drop measures fragility, not a new skill.", ref: "X1 §6.2.1 · arXiv 2510.13626", scene: "robot", focus: ["scene-camera", "object", "table"], look: "the same task, camera moved", uses: ["success-rate"] },
      "real-to-sim-evaluation": { name: "real-to-sim evaluation", aliases: ["SIMPLER", "SimplerEnv", "real2sim evaluation"], group: "eval", def: "Evaluating policies trained on real data inside simulated replicas of real setups, validated by comparing policy rankings with paired real trials.", note: "Opposite of sim-to-real training: the policy never trains in the simulator.", ref: "arXiv 2405.05941 · X1 §6.2.1", scene: "system", focus: ["simulator", "robot"], look: "a simulated copy of the real scene", uses: ["visual-matching"] },
      "visual-matching": { name: "visual matching", aliases: ["green-screening", "texture matching"], group: "eval", def: "SIMPLER's way to close the visual gap: overlay real backgrounds and bake real textures onto simulated objects and robot.", note: "Its alternative, variant aggregation, averages over randomized scenes and ranked less faithfully (MMRV 0.143 versus 0.056).", ref: "arXiv 2405.05941", scene: "system", focus: ["camera-image", "simulator"], look: "real background behind simulated objects", uses: [] },
      "pairwise-arena-evaluation": { name: "pairwise arena evaluation", aliases: ["RoboArena", "A/B evaluation"], group: "eval", def: "Real-robot evaluation in which evaluators run two anonymous policies on the same self-chosen task and report a preference; abilities are fitted from many comparisons.", note: "RoboArena's fixed-task baseline correlated only 0.69 with its oracle ranking; the arena reached 0.98.", ref: "arXiv 2506.18123 · X1 §6.2.5", scene: "system", focus: ["robot", "human-teleop"], look: "two policies, one scene", uses: ["success-rate"] },
      "evaluation-budget": { name: "evaluation budget", aliases: ["number of episodes", "rollouts per policy"], group: "eval", sym: "n", symTex: "n", def: "The number of episodes run to estimate a policy's score; the 95% interval shrinks with the square root of this number.", note: "Halving the interval needs four times the episodes, which is costly on real robots.", ref: "X3 Table III · arXiv 2502.19645", scene: "system", focus: ["robot", "simulator"], look: "many repeated episodes", uses: [] },
      "sample-efficiency-metric": { name: "sample efficiency (metric)", aliases: ["SE", "episodes to target success"], group: "eval", sym: "SE", symTex: "\\mathrm{SE}", def: "The smallest number of episodes or environment steps after which the success rate reaches a target; lower is better.", note: "It measures training cost, while the evaluation budget measures how precisely the result is known.", ref: "X3 Table III", scene: "system", focus: ["policy-update", "simulator"], look: "the learning curve crossing a line", uses: ["success-rate"] },
      "world-model-evaluation-tiers": { name: "world-model evaluation tiers", aliases: ["visual fidelity, physical commonsense, action plausibility"], group: "eval", def: "Layered tests for world models: predictive fidelity of the video, physical and downstream usefulness, and reliability when used as a simulator or evaluator.", note: "Surveys split the tiers differently; all agree no single metric suffices.", ref: "X3 §VIII · X1 §6.1 · P03 §7.1", scene: "system", focus: ["world-model", "predicted-future"], look: "the predicted future being checked", uses: ["idm-turing-test"] },
      "idm-turing-test": { name: "IDM Turing test", aliases: ["inverse-dynamics Turing test", "implicit manipulative evaluation"], group: "eval", def: "Turning a generated video into actions with an inverse dynamics model and executing them on a robot; success shows the video is executable.", note: "Many visually convincing video models fall to near-zero success under this test.", ref: "X1 §6.1.3 · arXiv 2601.04137", scene: "system", focus: ["predicted-future", "robot"], look: "generated video driving the robot", uses: [] },
      "grasp-average-precision": { name: "grasp average precision", aliases: ["grasp AP", "GraspNet AP"], group: "grasp", def: "GraspNet-1Billion's score: precision of the top-k predicted grasps for k from 1 to 50, averaged over friction coefficients from 0.2 to 1.0.", note: "Scores drop on novel objects: 27.56 AP on seen versus 10.55 on novel scenes for the baseline.", ref: "GraspNet-1Billion, CVPR 2020 · P01 Table 1", scene: "robot", focus: ["grasp-pose", "object", "friction-cone"], look: "ranked grasp candidates on clutter", uses: [] }
    },
    symbols: [
      { id: "sr", tex: "\\mathrm{SR}", glyph: "SR", kind: "Functions", meaning: "success rate: successful episodes divided by all episodes", short: "success rate", first: "f3", read: "S R", papers: "X3 Table III: SR · P01 §2.4: success rate" },
      { id: "neps", tex: "n", glyph: "n", kind: "Parameters", meaning: "number of episodes counted by an evaluation metric", short: "number of episodes", first: "f3", read: "n", papers: "X3 Table III: N (episodes) · OpenVLA-OFT: trials" },
      { id: "acs", tex: "\\mathrm{ACS}", glyph: "ACS", kind: "Functions", meaning: "average completed subtasks in a chain before the first failure", short: "average chain length", first: "f3", read: "A C S", papers: "X3 Table III: ACS · CALVIN papers: Avg. Len." },
      { id: "se", tex: "\\mathrm{SE}", glyph: "SE", kind: "Functions", meaning: "sample efficiency: fewest episodes to reach a target success rate", short: "sample efficiency", first: "f3", read: "S E", papers: "X3 Table III: SE" },
      { id: "srstar", tex: "\\mathrm{SR}^\\star", glyph: "SR*", kind: "Parameters", meaning: "target success rate used by the sample-efficiency metric", short: "target success rate", first: "f3", read: "S R star", papers: "X3 Table III: τ" },
      { id: "rreal", tex: "R_i", glyph: "Rᵢ", kind: "Signals", meaning: "real-world success rate of policy i", short: "real success of policy i", first: "f3", read: "R sub i", papers: "SIMPLER eq. 1: R_i" },
      { id: "rsim", tex: "R_{S,i}", glyph: "R_S,i", kind: "Signals", meaning: "success rate of policy i measured by a simulated or learned evaluator", short: "evaluator's success of policy i", first: "f3", read: "R sub S i", papers: "SIMPLER eq. 1: R_{S,i}" },
      { id: "mmrv", tex: "\\mathrm{MMRV}", glyph: "MMRV", kind: "Functions", meaning: "mean maximum rank violation between evaluator and real rankings; lower is better", short: "mean maximum rank violation", first: "f3", read: "M M R V", papers: "SIMPLER eq. 2 · WorldEval, RoboArena, PolaRiS: MMRV" },
      { id: "npol", tex: "N", glyph: "N", kind: "Parameters", meaning: "number of policies being ranked", short: "number of policies", first: "f3", read: "N", papers: "SIMPLER eq. 2: N" },
      { id: "abil", tex: "u_A", glyph: "u_A", kind: "Parameters", meaning: "latent ability of policy A in a pairwise preference model", short: "policy ability", first: "f3", read: "u sub A", papers: "RoboArena: θ_A" },
      { id: "tbucket", tex: "\\nu_t", glyph: "νₜ", kind: "Parameters", meaning: "prior weight of latent task bucket t", short: "task-bucket weight", first: "f3", read: "nu sub t", papers: "RoboArena: ν_t" },
      { id: "toff", tex: "\\psi^A_t", glyph: "ψᴬₜ", kind: "Parameters", meaning: "offset of policy A's ability in task bucket t", short: "policy–task offset", first: "f3", read: "psi A sub t", papers: "RoboArena: ψ^A_t" },
      { id: "tdiff", tex: "d_t", glyph: "dₜ", kind: "Parameters", meaning: "difficulty of latent task bucket t", short: "bucket difficulty", first: "f3", read: "d sub t", papers: "RoboArena: τ_t" }
    ],
    ledger: [
      { where: "Topic 23 · atlas", source: "CALVIN's demonstration count: P01 Table 2 lists 40M, X1 Table 9 lists 20K+, X3 Table II ∼24 h of play; the CALVIN paper reports ∼2.4M interaction steps", page: "The atlas plots X1's 20K+", why: "The atlas follows one table (X1 Table 9) for all rows; the counts measure different things.", kind: "Sources disagree" },
      { where: "Topic 23 · atlas", source: "X1 Table 9 dates CALVIN 2021 (arXiv) and RLBench 2020; P01 Table 2 gives venue years (RA-L 2022, RA-L 2020)", page: "Years as in X1 Table 9", why: "One consistent source per chart.", kind: "Sources disagree" },
      { where: "Topic 23 · results board", source: "P03 Table 5 and OpenVLA-OFT Table I mix policies with different inputs, training data and checkpoint rules", page: "All rows are shown on one board", why: "This is how the numbers are compared in practice; the mismatch is part of the lesson.", kind: "Our choice" },
      { where: "Topic 23 · results board", source: "Papers do not report intervals for these LIBERO numbers", page: "Whiskers use a normal-approximation 95% interval with the chosen episode count (default 500, OpenVLA-OFT's protocol)", why: "Shows how much of a gap the episodes can resolve.", kind: "Simplified" },
      { where: "Topic 23 · rules", source: "X3 Table III writes the target success rate as τ and episodes as N; RoboArena writes ability θ and difficulty τ_t", page: "The site writes SR*, n, u_A and d_t", why: "House notation reserves τ for flow time, θ for policy parameters and N for candidates.", kind: "Our choice" },
      { where: "Topic 23 · worked example", source: "Some summaries write MMRV as a double sum over pairs; SIMPLER eq. 1–2 takes the maximum violation per policy", page: "The site uses the paper's per-policy maximum", why: "Follows the defining paper.", kind: "Sources disagree" },
      { where: "Topic 23 · playground 2", source: "Real episodes are correlated through shared scenes, resets and operators", page: "Episodes are independent Bernoulli trials; P(right order) uses the normal approximation", why: "Isolates the effect of the episode count.", kind: "Simplified" }
    ]
  });
})();
