/* Topic 19 · Touch and force. Sources: P10 (TF-ART) §1–5, §7, eq. 1–10, Fig. 1–2, Tables 2–5; P01 §6.2.3–6.2.4; method cards (topic E5). */
(function () {
  "use strict";
  var RB = window.RB;

  function mono() { return getComputedStyle(document.body).getPropertyValue("--font-mono") || "monospace"; }
  function bodyFont() { return getComputedStyle(document.body).getPropertyValue("--font-body") || "sans-serif"; }
  function sig(v) { return 1 / (1 + Math.exp(-v)); }

  /* =====================================================================================
     Playground 1: when should the policy listen to force? A 2-D peg-in-hole toy.
     x = lateral offset of the peg tip from the hole center (mm), z = tip height above the surface (mm).
     Vision knows the hole only up to an error δ. Force carries two kinds of information:
       normal force Fn (how hard the peg presses) and lateral force Fx (the chamfer pushes toward the center).
     The policy mixes a vision term and a force term; the fusion mode sets the weight w on the force term:
       vision only: w = 0 · concatenate: w = 1 always · gated (FoAR-style): w = φ = σ(b − z + Fn_meas − 2)
       MoE top-1: the router picks the free-space expert (w = 0) or the contact expert (w = 1) by φ > 0.5.
     Our toy numbers throughout; nothing here is fitted to a paper.
     ===================================================================================== */
  var PEG = { c: 0.6, R: 2.6, kEnv: 1.5, Fstar: 5, Flim: 25, v: 0.3, kv: 0.06, kf: 0.12, kz: 0.05, T: 320, depth: 8, z0: 30, x0: -4 };

  function simPeg(mode, delta, sigma, bias, seed) {
    var R = RB.rng(seed), x = PEG.x0, zc = PEG.z0, inHole = false, done = false;
    var hist = [], peak = 0, switches = 0, lastExpert = 0, freeSteps = [], result = "timeout", tDone = -1;
    for (var t = 0; t < PEG.T; t++) {
      var z = inHole ? zc : Math.max(zc, 0);
      var contact = !inHole && zc <= 0;
      var Fn = contact ? PEG.kEnv * (-zc) : 0;
      var Fx = 0;
      if (contact && Math.abs(x) >= PEG.c && Math.abs(x) < PEG.R) Fx = -(x > 0 ? 1 : -1) * 0.5 * Fn;
      var FnM = Fn + sigma * R.normal(), FxM = Fx + sigma * R.normal();
      var phi = sig(bias - z + (FnM - 2));
      var w = mode === "vision" ? 0 : mode === "concat" ? 1 : mode === "gate" ? phi : (phi > 0.5 ? 1 : 0);
      if (mode === "moe") { var ex = phi > 0.5 ? 1 : 0; if (t > 0 && ex !== lastExpert) switches++; lastExpert = ex; }
      peak = Math.max(peak, Fn);
      var phase = inHole ? "insert" : contact ? "contact" : "approach";
      hist.push({ x: x, z: z, phi: phi, w: w, Fn: Fn, FnM: FnM, phase: phase });
      if (done) continue;
      if (Fn > PEG.Flim) { result = "force"; done = true; tDone = t; continue; }
      if (inHole && zc <= -PEG.depth) { result = "ok"; done = true; tDone = t; continue; }
      /* lateral command: vision pulls toward its estimate δ; force term follows the measured lateral force */
      var dx = PEG.kv * (delta - x) + w * PEG.kf * FxM + 0.01 * R.normal();
      if (inHole) dx = 0;
      if (!contact && !inHole) freeSteps.push(dx);
      x += dx;
      /* vertical command: descend in free space; with force weight w, regulate the normal force to F* */
      var dz = -PEG.v * (1 - w) + w * PEG.kz * (FnM - PEG.Fstar);
      if (inHole) dz = -PEG.v;
      zc += dz;
      if (!inHole && zc <= 0 && Math.abs(x) < PEG.c) { inHole = true; zc = Math.min(zc, 0); }
    }
    var m = 0, s2 = 0; freeSteps.forEach(function (d) { m += d; }); m /= Math.max(1, freeSteps.length);
    freeSteps.forEach(function (d) { s2 += (d - m) * (d - m); });
    return { hist: hist, peak: peak, jitter: Math.sqrt(s2 / Math.max(1, freeSteps.length)), result: result, tDone: tDone, switches: switches };
  }

  function mountGate(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Fusion of the force feature", value: "gate", options: [{ value: "vision", label: "Vision only" }, { value: "concat", label: "Concatenate" }, { value: "gate", label: "Gated" }, { value: "moe", label: "MoE top-1" }] }) +
      RB.slider({ id: id + "-noise", label: "Sensor noise σ (N)", min: 0, max: 4, step: 0.5, value: 2, fmt: function (v) { return (+v).toFixed(1); } }) +
      RB.slider({ id: id + "-delta", label: "Vision error δ (mm)", min: 0, max: 2.5, step: 0.25, value: 1.5, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-bias", label: "Gate bias b (mm)", min: -24, max: 12, step: 1, value: 2 }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">New trial ▶</button></div>' +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Side view of a peg above a chamfered hole, with a timeline of the gate value and the normal force below"></canvas><figcaption class="sb-caption">Top: the peg tip path (accent) toward the hole. Bottom: gate value φ and measured normal force over time, shaded by phase: approach, contact, insert.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "res", k: "This trial" }, { id: "peak", k: "Peak normal force", u: "N" }, { id: "jit", k: "Approach jitter per step", u: "mm" }, { id: "succ", k: "Inserted, 20 trials" }, { id: "sw", k: "Expert switches" }]) +
      '<p class="sb-caption" data-note></p>' + RB.legend([{ c: "data-1", label: "gate φ (0 to 1)", kind: "line" }, { c: "data-2", label: "measured normal force", kind: "line" }, { c: "bad", label: "force limit (25 N)", kind: "dash" }]) + "</div></div>";
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]");
    var st = { mode: "gate", sigma: 2, delta: 1.5, bias: 2, seed: 11 }, last = null, W = 520, H = 400, TOP = 250;
    var NOTES = {
      vision: "Without force, the peg lands δ off center and keeps pressing. If δ exceeds the clearance, the force climbs to the limit. Vision cannot see the jam.",
      concat: "Concatenation feeds force in every phase. Before contact the reading is pure noise, and the policy moves on it: see the jagged approach. FoAR saw naive fusion hurt for this reason.",
      gate: "FoAR scales the force feature by a predicted contact probability φ. It stays near 0 in free space and opens at contact, where force now centers the peg.",
      moe: "ForceVLA routes each token to one of four experts. Top-1 routing is a hard switch: clean when φ is clear, chattering when noise sits near the threshold."
    };
    function toX(x) { return W / 2 + x * 22; }
    function toY(z) { return 170 - z * 4.2; }
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mf = mono(), bf = bodyFont();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      /* workpiece with a chamfered hole */
      var sy = toY(0), hl = toX(-PEG.c), hr = toX(PEG.c), cl = toX(-PEG.R), cr = toX(PEG.R);
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(10, sy); c.lineTo(cl, sy); c.lineTo(hl, sy + 10); c.lineTo(hl, toY(-12)); c.lineTo(10, toY(-12)); c.closePath(); c.fill(); c.stroke();
      c.beginPath(); c.moveTo(W - 10, sy); c.lineTo(cr, sy); c.lineTo(hr, sy + 10); c.lineTo(hr, toY(-12)); c.lineTo(W - 10, toY(-12)); c.closePath(); c.fill(); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mf; c.fillText("hole", toX(0) - 12, toY(-11.5) + 14 > TOP - 4 ? TOP - 8 : toY(-11.5) + 14);
      /* vision estimate */
      c.strokeStyle = P["ink-3"]; c.setLineDash([4, 4]); c.beginPath(); c.moveTo(toX(st.delta), 14); c.lineTo(toX(st.delta), sy - 2); c.stroke(); c.setLineDash([]);
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + mf; c.fillText("vision thinks the hole is here", Math.min(toX(st.delta) + 6, W - 200), 24);
      if (last) {
        c.strokeStyle = P.accent; c.lineWidth = 1.5; c.beginPath();
        last.hist.forEach(function (h, i) { var X = toX(h.x), Y = toY(h.z); if (i) c.lineTo(X, Y); else c.moveTo(X, Y); }); c.stroke();
        var e = last.hist[last.tDone >= 0 ? last.tDone : last.hist.length - 1];
        c.fillStyle = P["robot-body"] || P["ink-2"]; c.globalAlpha = 0.85;
        c.fillRect(toX(e.x - PEG.c * 0.8), toY(e.z + 9), (toX(PEG.c * 0.8) - toX(-PEG.c * 0.8)), toY(e.z) - toY(e.z + 9)); c.globalAlpha = 1;
      }
      /* timeline */
      var tx0 = 44, tx1 = W - 12, ty0 = TOP + 18, ty1 = H - 22, T = PEG.T;
      var sx = function (t) { return tx0 + t / T * (tx1 - tx0); }, syPhi = function (v) { return ty1 - v * (ty1 - ty0); }, syF = function (f) { return ty1 - Math.min(f, 30) / 30 * (ty1 - ty0); };
      c.strokeStyle = P.line; c.lineWidth = 1; c.strokeRect(tx0, ty0, tx1 - tx0, ty1 - ty0);
      if (last) {
        var ph = null, start = 0, shade = { approach: null, contact: P["warn-soft"], insert: P["good-soft"] };
        var n = last.tDone >= 0 ? last.tDone + 1 : last.hist.length;
        for (var t = 0; t <= n; t++) {
          var p = t < n ? last.hist[t].phase : null;
          if (p !== ph) {
            if (ph && shade[ph]) { c.fillStyle = shade[ph]; c.fillRect(sx(start), ty0 + 1, sx(t) - sx(start), ty1 - ty0 - 2); }
            if (ph) { c.fillStyle = P["ink-3"]; c.font = "500 11px " + mf; if (sx(t) - sx(start) > 50) c.fillText(ph, sx(start) + 4, ty0 + 12); }
            ph = p; start = t;
          }
        }
        c.strokeStyle = P.bad; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(tx0, syF(PEG.Flim)); c.lineTo(tx1, syF(PEG.Flim)); c.stroke(); c.setLineDash([]);
        c.lineWidth = 1.5; c.strokeStyle = P["data-2"]; c.beginPath();
        for (var i = 0; i < n; i++) { var y = syF(Math.max(0, last.hist[i].FnM)); if (i) c.lineTo(sx(i), y); else c.moveTo(sx(i), y); } c.stroke();
        c.lineWidth = 2; c.strokeStyle = P["data-1"]; c.beginPath();
        for (var j = 0; j < n; j++) { var y2 = syPhi(st.mode === "moe" ? last.hist[j].w : last.hist[j].phi); if (j) c.lineTo(sx(j), y2); else c.moveTo(sx(j), y2); } c.stroke();
      }
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + mf;
      c.fillText("1", tx0 - 14, ty0 + 8); c.fillText("0", tx0 - 14, ty1); c.fillText("30 N", tx1 - 34, ty0 - 4);
      c.fillText("time →", tx1 - 44, H - 6);
      c.font = "600 12px " + bf; c.fillStyle = P["ink-2"]; c.fillText("φ", tx0 - 30, (ty0 + ty1) / 2);
    }
    function run() {
      last = simPeg(st.mode, st.delta, st.sigma, st.bias, st.seed);
      var ok = 0; for (var k = 0; k < 20; k++) if (simPeg(st.mode, st.delta, st.sigma, st.bias, 100 + k).result === "ok") ok++;
      RB.setRO(body, "res", last.result === "ok" ? "Inserted" : last.result === "force" ? "Force limit" : "Timed out");
      RB.setRO(body, "peak", RB.fmt(last.peak, 1));
      RB.setRO(body, "jit", RB.fmt(last.jitter, 3));
      RB.setRO(body, "succ", ok + " of 20");
      RB.setRO(body, "sw", st.mode === "moe" ? String(last.switches) : "–");
      note.textContent = NOTES[st.mode];
      body.querySelector("#" + id + "-bias").disabled = st.mode === "vision" || st.mode === "concat";
      api.ok = ok; api.result = last.result;
      draw();
    }
    var api = {
      state: function () { return { mode: st.mode, sigma: st.sigma, delta: st.delta, bias: st.bias }; },
      ok: 0, result: "–"
    };
    RB.bindSeg(body, id + "-mode", function (v) { st.mode = String(v); run(); });
    RB.bindSlider(body, id + "-noise", function (v) { return (+v).toFixed(1); }, function (v) { st.sigma = v; run(); });
    RB.bindSlider(body, id + "-delta", function (v) { return (+v).toFixed(2); }, function (v) { st.delta = v; run(); });
    RB.bindSlider(body, id + "-bias", null, function (v) { st.bias = v; run(); });
    body.querySelector("#" + id + "-go").addEventListener("click", function () { st.seed++; run(); });
    RB.onTheme(draw);
    run();
    return api;
  }

  /* =====================================================================================
     Playground 2: slow–fast loop (after Reactive Diffusion Policy).
     1-D wiping: the tool presses a surface through a compliant spring, F = k·max(0, s − z_cmd), k = 1 N/mm.
     The slow policy plans a chunk every 1/f_slow s from an observation that is L = 0.1 s old
     (RDP reports about 100 ms for its latent diffusion policy). Within a chunk the plan is open loop,
     unless the fast loop corrects it at 24 Hz from the latest force reading.
     Our toy numbers, except the 24 Hz and 100 ms taken from RDP.
     ===================================================================================== */
  var WIPE = { k: 1, Fstar: 6, band: 1.5, dt: 1 / 24, Tend: 4, L: 0.1, g: 0.6 };
  function surface(t, h) { if (t >= 1.2 && t < 2.3) return h; if (t >= 2.7 && t < 3.5) return -0.75 * h; return 0; }
  function simWipe(fast, fSlow, h, seed) {
    var R = RB.rng(seed), n = Math.round(WIPE.Tend / WIPE.dt), plan = -WIPE.Fstar / WIPE.k, pending = [], nextPlan = 0, corr = 0;
    var out = [], outBand = 0, peak = 0, lost = 0, chunks = [];
    for (var i = 0; i <= n; i++) {
      var t = i * WIPE.dt;
      if (t >= nextPlan - 1e-9) { pending.push({ at: t + WIPE.L, z: surface(Math.max(0, t - WIPE.L), h) - WIPE.Fstar / WIPE.k }); chunks.push(t); nextPlan += 1 / fSlow; }
      while (pending.length && t >= pending[0].at - 1e-9) { var np = pending.shift().z; if (fast) corr -= np - plan; plan = np; } /* the fast loop hands over smoothly: its correction already holds what the new plan adds */
      var s = surface(t, h), zc = plan + corr, F = WIPE.k * Math.max(0, s - zc), Fm = F + 0.15 * R.normal();
      out.push({ t: t, s: s, zc: zc, F: F });
      if (Math.abs(F - WIPE.Fstar) > WIPE.band) outBand++;
      if (F <= 0) lost++;
      peak = Math.max(peak, F);
      if (fast) corr += WIPE.g * (Fm - WIPE.Fstar) / WIPE.k;
    }
    return { out: out, pctOut: 100 * outBand / out.length, peak: peak, lost: lost * WIPE.dt, chunks: chunks };
  }

  function mountSlowFast(body, ctx) {
    var id = ctx.id;
    body.innerHTML =
      '<div class="rb-row">' + RB.seg({ id: id + "-fast", label: "Fast 24 Hz loop", value: "off", options: [{ value: "off", label: "Fast off" }, { value: "on", label: "Fast on" }] }) +
      RB.slider({ id: id + "-rate", label: "Slow policy rate (Hz)", min: 1, max: 10, step: 1, value: 2 }) +
      RB.slider({ id: id + "-bump", label: "Surface bump (mm)", min: 0, max: 6, step: 0.5, value: 4, fmt: function (v) { return (+v).toFixed(1); } }) + "</div>" +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Surface height and commanded tool height over four seconds, and the contact force against its target band"></canvas><figcaption class="sb-caption">Top: surface (gray) and commanded tool height (accent); ticks mark new chunks. Bottom: contact force; the green band is the target 6 ± 1.5 N.</figcaption></figure>' +
      '<div class="rb-stack">' + RB.readouts([{ id: "out", k: "Time outside the force band", u: "%" }, { id: "peak", k: "Peak force", u: "N" }, { id: "lost", k: "Contact lost", u: "s" }, { id: "calls", k: "Slow-policy calls in 4 s" }]) +
      '<p class="sb-caption" data-note></p></div></div>';
    var cv = body.querySelector("#" + id + "-cv"), note = body.querySelector("[data-note]"), st = { fast: false, rate: 2, bump: 4 }, last = null, W = 520, H = 340;
    function draw() {
      var P = RB.pal(), c = RB.canvas(cv, W, H), mf = mono();
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var x0 = 44, x1 = W - 12, sx = function (t) { return x0 + t / WIPE.Tend * (x1 - x0); };
      var a0 = 14, a1 = 150, zy = function (z) { return a0 + (6 - z) / 16 * (a1 - a0); };
      var b0 = 176, b1 = H - 24, fy = function (f) { return b1 - Math.min(f, 14) / 14 * (b1 - b0); };
      c.strokeStyle = P.line; c.lineWidth = 1; c.strokeRect(x0, a0, x1 - x0, a1 - a0); c.strokeRect(x0, b0, x1 - x0, b1 - b0);
      c.fillStyle = P["good-soft"]; c.fillRect(x0 + 1, fy(WIPE.Fstar + WIPE.band), x1 - x0 - 2, fy(WIPE.Fstar - WIPE.band) - fy(WIPE.Fstar + WIPE.band));
      if (last) {
        c.strokeStyle = P["ink-3"]; last.chunks.forEach(function (t) { c.beginPath(); c.moveTo(sx(t), a1 - 8); c.lineTo(sx(t), a1); c.stroke(); });
        c.lineWidth = 2; c.strokeStyle = P["line-strong"]; c.beginPath(); last.out.forEach(function (p, i) { if (i) { c.lineTo(sx(p.t), zy(last.out[i - 1].s)); c.lineTo(sx(p.t), zy(p.s)); } else c.moveTo(sx(p.t), zy(p.s)); }); c.stroke();
        c.lineWidth = 1.5; c.strokeStyle = P.accent; c.beginPath(); last.out.forEach(function (p, i) { if (i) { c.lineTo(sx(p.t), zy(last.out[i - 1].zc)); c.lineTo(sx(p.t), zy(p.zc)); } else c.moveTo(sx(p.t), zy(p.zc)); }); c.stroke();
        c.lineWidth = 2; c.strokeStyle = P["data-2"]; c.beginPath(); last.out.forEach(function (p, i) { if (i) c.lineTo(sx(p.t), fy(p.F)); else c.moveTo(sx(p.t), fy(p.F)); }); c.stroke();
      }
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + mf;
      c.fillText("height (mm)", x0 + 6, a0 + 14); c.fillText("force (N)", x0 + 6, b0 + 14);
      c.fillText("0", x0 - 14, fy(0) + 4); c.fillText("6", x0 - 14, fy(6) + 4); c.fillText("12", x0 - 20, fy(12) + 4);
      c.fillText("0 s", x0, H - 8); c.fillText("4 s", x1 - 20, H - 8);
    }
    function run() {
      last = simWipe(st.fast, st.rate, st.bump, 5);
      RB.setRO(body, "out", RB.fmt(last.pctOut, 0));
      RB.setRO(body, "peak", RB.fmt(last.peak, 1));
      RB.setRO(body, "lost", RB.fmt(last.lost, 2));
      RB.setRO(body, "calls", String(last.chunks.length));
      note.textContent = st.fast ? "The fast decoder reads the latest force every 1/24 s and shifts the plan, like RDP's asymmetric tokenizer. Errors fade within a few ticks, whatever the slow rate." : "Between chunks the plan runs open loop. A bump raises the force until the next chunk, which also sees the scene 0.1 s late. Faster slow calls help, but each costs a full model pass.";
      api.pct = last.pctOut;
      draw();
    }
    var api = { state: function () { return { fast: st.fast, rate: st.rate, bump: st.bump }; }, pct: 0 };
    RB.bindSeg(body, id + "-fast", function (v) { st.fast = String(v) === "on"; run(); });
    RB.bindSlider(body, id + "-rate", null, function (v) { st.rate = v; run(); });
    RB.bindSlider(body, id + "-bump", function (v) { return (+v).toFixed(1); }, function (v) { st.bump = v; run(); });
    RB.onTheme(draw);
    run();
    return api;
  }

  /* ---------- concept-card drawings (200 × 56, token colors only) ---------- */
  var ART = {
    twoSenses: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="6" width="30" height="13" rx="2" class="rb-f-sunk"/><text x="23" y="16" text-anchor="middle" class="rb-t-mono">F/T</text><path d="M23 19 V32" class="rb-s-ink"/><rect x="11" y="32" width="24" height="12" rx="2" class="rb-f-surface"/><text x="44" y="30" class="rb-t-mono">load</text>' +
      '<rect x="116" y="8" width="14" height="38" rx="3" class="rb-f-surface"/>' + [0, 1, 2, 3].map(function (i) { return '<rect x="132" y="' + (10 + i * 9) + '" width="7" height="7" class="' + (i === 1 || i === 2 ? "rb-f-acc" : "rb-f-soft") + '"/>'; }).join("") + '<text x="146" y="30" class="rb-t-mono">patch</text></svg>',
    phases: '<svg viewBox="0 0 200 56" aria-hidden="true">' + ["0", "1", "2", "3"].map(function (s, i) { var x = 8 + i * 48; return '<rect x="' + x + '" y="12" width="36" height="24" rx="4" class="' + (i === 2 ? "rb-f-soft" : "rb-f-surface") + '"/><text x="' + (x + 18) + '" y="28" text-anchor="middle" class="rb-t-mono">' + s + "</text>" + (i < 3 ? '<path d="M' + (x + 36) + ' 24 H' + (x + 48) + '" class="rb-s-ink"/>' : ""); }).join("") + '<text x="100" y="50" text-anchor="middle" class="rb-t-mono">fuse plan refine control</text></svg>',
    gate: '<svg viewBox="0 0 200 56" aria-hidden="true"><path d="M10 44 H80 C96 44 100 12 116 12 H190" class="rb-s-acc"/><line x1="10" y1="50" x2="190" y2="50" class="rb-s-line"/><text x="12" y="36" class="rb-t-mono">φ≈0</text><text x="150" y="30" class="rb-t-mono">φ≈1</text><text x="100" y="12" text-anchor="end" class="rb-t-mono">contact</text></svg>',
    moe: '<svg viewBox="0 0 200 56" aria-hidden="true"><circle cx="20" cy="28" r="10" class="rb-f-soft"/><text x="20" y="32" text-anchor="middle" class="rb-t-acc">f</text><path d="M30 28 H56" class="rb-s-ink"/><rect x="56" y="18" width="26" height="20" rx="3" class="rb-f-sunk"/><text x="69" y="32" text-anchor="middle" class="rb-t-mono">r</text>' + [0, 1, 2, 3].map(function (i) { var y = 6 + i * 12; return '<path d="M82 28 L116 ' + (y + 4) + '" class="' + (i === 2 ? "rb-s-acc" : "rb-s-line") + '"/><rect x="116" y="' + y + '" width="26" height="9" rx="2" class="' + (i === 2 ? "rb-f-acc" : "rb-f-surface") + '"/>'; }).join("") + '<text x="150" y="42" class="rb-t-mono">top-1</text></svg>',
    ssl: '<svg viewBox="0 0 200 56" aria-hidden="true">' + [0, 1, 2, 3, 4].map(function (i) { return '<rect x="' + (8 + i * 16) + '" y="10" width="13" height="13" class="' + ([1, 2, 4].indexOf(i) >= 0 ? "rb-f-sunk" : "rb-f-soft") + '"/>'; }).join("") + '<text x="8" y="44" class="rb-t-mono">mask</text><circle cx="130" cy="16" r="5" class="rb-f-acc"/><circle cx="142" cy="20" r="5" class="rb-f-soft"/><circle cx="182" cy="16" r="5" class="rb-f-surface"/><text x="126" y="44" class="rb-t-mono">align</text></svg>',
    stiffness: '<svg viewBox="0 0 200 56" aria-hidden="true"><line x1="10" y1="48" x2="190" y2="48" class="rb-s-line"/><rect x="86" y="6" width="28" height="14" rx="2" class="rb-f-surface"/><path d="M100 20 l-6 3 l12 4 l-6 3 l6 3 l-12 4 l6 3 V48" class="rb-s-acc"/><circle cx="100" cy="48" r="4" class="rb-f-acc"/><text x="122" y="36" class="rb-t-mono">soft</text><path d="M58 13 H84 M116 13 H142" class="rb-s-ink"/><text x="10" y="17" class="rb-t-mono">stiff</text></svg>',
    slowfast: '<svg viewBox="0 0 200 56" aria-hidden="true"><rect x="8" y="8" width="88" height="14" rx="3" class="rb-f-soft"/><text x="52" y="18" text-anchor="middle" class="rb-t-mono">slow</text><rect x="102" y="8" width="88" height="14" rx="3" class="rb-f-soft"/><text x="146" y="18" text-anchor="middle" class="rb-t-mono">slow</text>' + Array.apply(null, Array(16)).map(function (_, i) { return '<line x1="' + (12 + i * 11.5) + '" y1="30" x2="' + (12 + i * 11.5) + '" y2="40" class="rb-s-acc"/>'; }).join("") + '<text x="8" y="53" class="rb-t-mono">fast ticks</text></svg>'
  };

  /* ---------- worked example figure: an ACP-style compliance label for one wiping frame ---------- */
  var MM = 5, SY = 70; /* 5 px per mm, surface at y = 70 */
  var kx = function (f) { return 340 + f / 12 * 200; }, ky = function (k) { return 140 - k / 1000 * 110; };
  var WE_FIG = '<svg viewBox="0 0 560 170" role="img" aria-label="Left: a wiping tool on a surface with a virtual target 10 mm below it. Right: the low stiffness falls from 1000 to 200 newtons per meter as force rises from 1 to 11 newtons">' +
    '<rect x="20" y="' + SY + '" width="280" height="84" class="rb-f-sunk"/>' +
    '<g data-on="1+"><rect x="150" y="' + (SY - 34) + '" width="40" height="34" rx="3" class="rb-f-surface"/><text x="170" y="' + (SY - 40) + '" text-anchor="middle" class="rb-t-mono">tool</text><path d="M200 ' + (SY - 26) + ' V' + (SY - 4) + '" class="rb-s-acc"/><path d="M196 ' + (SY - 9) + ' L200 ' + (SY - 3) + ' L204 ' + (SY - 9) + '" class="rb-s-acc"/><text x="208" y="' + (SY - 12) + '" class="rb-t-acc">f = 6 N</text></g>' +
    '<g data-on="3+"><text x="26" y="' + (SY + 76) + '" class="rb-t-mono">soft along f</text><text x="294" y="' + (SY + 76) + '" text-anchor="end" class="rb-t-mono">stiff sideways</text></g>' +
    '<g data-on="4+"><path d="M170 ' + SY + ' l-7 5 l14 8 l-14 8 l14 8 l-14 8 l7 5" class="rb-s-acc"/><circle cx="170" cy="' + (SY + 10 * MM) + '" r="5" class="rb-f-acc"/><text x="182" y="' + (SY + 10 * MM + 4) + '" class="rb-t-ink">virtual target</text><text x="182" y="' + (SY + 26) + '" class="rb-t-mono">10 mm</text></g>' +
    '<g data-on="5"><line x1="20" y1="' + (SY - 4 * MM) + '" x2="140" y2="' + (SY - 4 * MM) + '" class="rb-s-ink" stroke-dasharray="4 3"/><text x="24" y="' + (SY - 4 * MM - 6) + '" class="rb-t-acc">+4 mm: 8.4 N</text></g>' +
    '<g data-on="6"><line x1="20" y1="' + (SY + 4 * MM) + '" x2="140" y2="' + (SY + 4 * MM) + '" class="rb-s-ink" stroke-dasharray="4 3"/><text x="24" y="' + (SY + 4 * MM + 16) + '" class="rb-t-acc">−4 mm: 3.6 N</text></g>' +
    '<g data-on="2+"><line x1="340" y1="140" x2="545" y2="140" class="rb-s-line"/><line x1="340" y1="24" x2="340" y2="140" class="rb-s-line"/>' +
    '<path d="M' + kx(0) + " " + ky(1000) + " H" + kx(1) + " L" + kx(11) + " " + ky(200) + " H" + kx(12) + '" class="rb-s-acc"/>' +
    '<line x1="' + kx(6) + '" y1="140" x2="' + kx(6) + '" y2="' + ky(600) + '" class="rb-s-line" stroke-dasharray="3 3"/><circle cx="' + kx(6) + '" cy="' + ky(600) + '" r="5" class="rb-f-acc"/>' +
    '<text x="' + (kx(6) + 8) + '" y="' + (ky(600) - 6) + '" class="rb-t-acc">600 N/m</text>' +
    '<text x="348" y="16" class="rb-t-mono">k_low (N/m)</text><text x="' + kx(6) + '" y="156" text-anchor="middle" class="rb-t-mono">6 N</text><text x="545" y="156" text-anchor="end" class="rb-t-mono">|f|</text>' +
    '<text x="334" y="' + (ky(1000) + 4) + '" text-anchor="end" class="rb-t-mono">1000</text><text x="' + (kx(11) - 18) + '" y="' + (ky(200) - 8) + '" class="rb-t-mono">200</text></g></svg>';

  RB.topic({
    id: "e5",
    title: "Touch and force in the loop",
    eyebrow: "Part E · Touch and force",
    lede: "Touch and force matter only during contact, and they change fast. Policies must learn when to listen to them and how to react in time.",
    refs: ["P10 §2–5", "P10 Fig. 1–2", "P01 §6.2.3"],
    why: "Vision cannot see a peg jam inside a hole or feel how hard a sponge presses. Force/torque (F/T) sensors measure the overall load; tactile sensors measure the local contact. This topic follows how policies take these signals in, when they listen to them, and how they act on them fast enough to matter.",
    outcomes: [
      "Place a method's use of touch or force in the four TF-ART phases.",
      "Compare FiLM, attention, mixture-of-experts and gated fusion of force features.",
      "Explain why an ungated force feature hurts during free-space motion.",
      "Compute an ACP-style stiffness label and virtual target from a measured force.",
      "Explain how a slow–fast policy corrects actions inside a chunk."
    ],
    concepts: [
      { name: "Force versus touch", def: "Force/torque sensing gives the global wrench at the wrist; tactile sensing gives local pressure, deformation and texture.", ref: "P10 §1.1", art: ART.twoSenses, term: "wrench" },
      { name: "TF-ART phases", def: "Phase 0 fuses signals, Phase 1 plans actions, Phase 2 refines them, Phase 3 controls the robot.", ref: "P10 Fig. 1–2", art: ART.phases, term: "tf-art" },
      { name: "Gated filtering", def: "A learned gate between 0 and 1 scales a modality's feature, so touch counts only when contact makes it useful.", ref: "P10 eq. 10", art: ART.gate, term: "gated-filtering", sym: "cphi" },
      { name: "Mixture of experts", def: "A router sends each token to a few specialist networks, for example free-space or contact experts.", ref: "P10 eq. 9", art: ART.moe, term: "mixture-of-experts" },
      { name: "Self-supervised touch", def: "Masked, quantized or contrastive objectives train tactile encoders before or beside the action loss.", ref: "P10 §2.4, eq. 1–6", art: ART.ssl, term: "masked-autoencoding" },
      { name: "Stiffness and force as actions", def: "The policy also outputs stiffness K or a reference force, which a compliant controller then realizes.", ref: "P10 §3.2.2–3.2.3", art: ART.stiffness, term: "control-stiffness", href: "#lab/compliance" },
      { name: "Slow–fast refinement", def: "A slow policy plans chunks; a small fast policy corrects them from the latest touch at high rate.", ref: "P10 §4.4", art: ART.slowfast, term: "slow-fast-policy" }
    ],
    flow: {
      title: "Where touch and force enter the pipeline", ref: "P10 Fig. 1–2, §2–5", w: 820, h: 290,
      caption: "Touch and force can enter at every phase. Most methods fuse them into the slow policy; multi-phase methods also route the latest reading to a fast refiner.",
      nodes: [
        { id: "sens", x: 10, y: 44, w: 140, h: 56, label: "Sensors", sub: "wrench, touch", kind: "env" },
        { id: "p0", x: 220, y: 44, w: 140, h: 56, label: "Phase 0: fuse", sub: "gate or route", kind: "agent" },
        { id: "p1", x: 430, y: 44, w: 140, h: 56, label: "Phase 1: plan", sub: "slow: chunk, K", kind: "agent" },
        { id: "p2", x: 640, y: 44, w: 170, h: 56, label: "Phase 2: refine", sub: "fast: latest touch", kind: "decision" },
        { id: "p3", x: 640, y: 190, w: 170, h: 56, label: "Phase 3: control", sub: "impedance, admittance", kind: "agent" },
        { id: "robot", x: 300, y: 190, w: 180, h: 56, label: "Robot", sub: "tool meets object", kind: "env" }
      ],
      edges: [
        { from: "sens", to: "p0", label: "signals" },
        { from: "p0", to: "p1", label: "tokens" },
        { from: "p1", to: "p2", label: "chunk" },
        { from: "sens", to: "p2", label: "latest force or touch", sides: ["t", "t"], via: [[80, 16], [725, 16]], dashed: true },
        { from: "p2", to: "p3", label: "refined action" },
        { from: "p3", to: "robot", label: "torques" },
        { from: "robot", to: "sens", label: "contact", sides: ["l", "b"], via: [[80, 218]] }
      ],
      steps: [
        { on: ["sens", "sens>p0", "p0"], text: "Phase 0 encodes images, wrench and touch, then fuses them: FiLM, attention, a mixture of experts or a gate (P10 §2.5)." },
        { on: ["p0>p1", "p1"], text: "Phase 1 is the primary policy. Besides an action chunk it may predict a stiffness K or a reference force (P10 §3.2)." },
        { on: ["sens>p2", "p1>p2", "p2"], text: "Phase 2 is optional: a small fast policy or rule corrects the chunk from the latest force or touch. RDP decodes at 20–30 Hz." },
        { on: ["p2>p3", "p3"], text: "Phase 3 turns targets into torques with position, impedance, admittance or hybrid force/position control (P10 Table 5)." },
        { on: ["p3>robot", "robot", "robot>sens"], text: "Contact changes the readings, and the loop runs again. The fastest loops sit closest to the robot." }
      ]
    },
    worked: {
      title: "An ACP-style compliance label for one frame",
      ref: "ACP, arXiv 2410.09309 · P10 §3.2.3", prov: "Our toy numbers",
      eq: { tex: "\\class{sym-klow}{k_{\\text{low}}} = k_{\\max} - (k_{\\max}-k_{\\min})\\,\\frac{|\\class{sym-Fext}{F_{\\mathrm{ext}}}| - f_{\\min}}{f_{\\max}-f_{\\min}}", words: "Between two force thresholds, stiffness along the force falls linearly as the force grows.", key: ["klow", { glyph: "k_max, k_min", meaning: "stiffness limits (hardware)" }, "Fext", { glyph: "f_max, f_min", meaning: "force thresholds (hardware)" }] },
      figure: WE_FIG,
      steps: [
        { title: "Read the force", text: "A wiping demonstration frame measures 6 N pressing into the table, after ACP's 1 s moving average." },
        { title: "Stiffness along the force", text: "With toy limits 1–11 N and 200–1000 N/m: k_low = 1000 − 800 × 5/10 = 600 N/m." },
        { title: "Build the stiffness matrix", text: "The first axis of S points along the force. K is 600 N/m into the table, 1000 N/m sideways." },
        { title: "Place the virtual target", text: "6 N ÷ 600 N/m = 10 mm. A spring target 10 mm below the surface presses with 6 N." },
        { title: "The surface rises 4 mm", text: "The spring compresses 14 mm: 8.4 N, only 2.4 N more. A 5000 N/m position target would add 20 N." },
        { title: "The surface drops 4 mm", text: "The spring still compresses 6 mm: 3.6 N, and wiping continues. A stiff target on the surface loses contact." }
      ]
    },
    ruleTitle: "How force enters the policy, and what the policy returns",
    rules: [
      { name: "Gated filtering", ref: "P10 eq. 10", term: "gated-filtering",
        tex: "\\tilde{\\class{sym-fmod}{F}}^{m} = \\sigma\\big(G_m(\\class{sym-s}{s_t})\\big) \\odot \\class{sym-fmod}{F^{m}}",
        words: "A gating network reads the task state and outputs a value between 0 and 1 that scales the modality's feature.",
        key: ["fmod", { glyph: "σ", meaning: "sigmoid, output in (0, 1)" }, { glyph: "G_m", meaning: "gating network for modality m" }, "s", { glyph: "⊙", meaning: "element-wise product" }] },
      { name: "FoAR: gate force by predicted contact", ref: "arXiv 2411.15753", term: "future-contact-prediction",
        before: "h_t = \\big[\\class{sym-hscene}{h^{s}_t};\\ \\class{sym-hforce}{h^{f}_t}\\big]",
        tex: "h_t = \\big[\\class{sym-hscene}{h^{s}_t};\\ \\class{sb-new}{\\class{sym-cphi}{\\phi_t}}\\,\\class{sym-hforce}{h^{f}_t} + \\class{sb-new}{(1-\\class{sym-cphi}{\\phi_t})\\,\\class{sym-hneutral}{h^{*}}}\\big]",
        words: "Blend the force feature with a learned neutral embedding, weighted by the predicted probability of contact, before joining the scene feature.",
        key: ["hscene", "hforce", "cphi", "hneutral", { glyph: "h_t", meaning: "fused feature for the head" }], diff: true, beforeLabel: "Concat", afterLabel: "FoAR" },
      { name: "Mixture of experts (ForceVLA's fusion)", ref: "P10 eq. 9 · arXiv 2505.22159", term: "mixture-of-experts",
        tex: "\\tilde{f}_j = \\sum_{i \\in S_j} r_{j,i}\\, E_i(f_j)",
        words: "Each token is sent to a few selected experts and their outputs are mixed by the router's weights. ForceVLA keeps one of four.",
        key: [{ glyph: "f_j", meaning: "token j (vision, language or force)" }, { glyph: "S_j", meaning: "experts selected for token j" }, { glyph: "r_j,i", meaning: "router weight" }, { glyph: "E_i", meaning: "expert network i" }] },
      { name: "FiLM injection", ref: "P10 eq. 7", term: "film-conditioning",
        tex: "\\tilde{\\class{sym-x-tau}{\\mathbf{a}}}^{\\class{sym-tau}{\\tau}} = \\gamma_m \\odot \\class{sym-x-tau}{\\mathbf{a}^{\\tau}} + \\beta_m",
        words: "A modality's pooled feature produces a scale and a shift that modulate the noisy action tokens inside a diffusion head.",
        key: ["x-tau", "tau", { glyph: "γ_m", meaning: "scale from modality m" }, { glyph: "β_m", meaning: "shift from modality m" }] },
      { name: "Multimodal contrastive alignment", ref: "P10 eq. 5", term: "multimodal-contrastive-alignment",
        tex: "\\class{sym-L}{\\mathcal{L}}_{a\\to b} = -\\frac{1}{B}\\sum_{i=1}^{B} \\log \\frac{\\exp\\big(\\mathrm{sim}(\\class{sym-z}{z^a_i}, \\class{sym-z}{z^b_i})/\\kappa\\big)}{\\sum_{j=1}^{B}\\exp\\big(\\mathrm{sim}(\\class{sym-z}{z^a_i}, \\class{sym-z}{z^b_j})/\\kappa\\big)}",
        words: "Pull the embeddings of matching touch and vision (or language) samples together and push mismatched pairs in the batch apart.",
        key: ["L", "z", { glyph: "B", meaning: "batch size" }, { glyph: "sim", meaning: "cosine similarity" }, { glyph: "κ", meaning: "temperature (P10 writes τ)" }] },
      { name: "ACP: stiffness from the force direction", ref: "arXiv 2410.09309 · P10 §3.2.3", term: "control-stiffness",
        tex: "\\class{sym-Kd}{K_d} = \\class{sym-sforce}{S}\\,\\mathrm{diag}\\big(\\class{sym-klow}{k_{\\text{low}}},\\, k_{\\text{high}},\\, k_{\\text{high}}\\big)\\,\\class{sym-sforce}{S}^{-1}",
        words: "Stiffness is low along the measured force and high in the other directions. ACP proves this cannot violate the contact constraint.",
        key: ["Kd", "sforce", "klow", { glyph: "k_high", meaning: "stiffness off the force axis" }] }
    ],
    algorithm: {
      title: "Reactive Diffusion Policy at run time", ref: "arXiv 2503.02881", prov: "Our notation",
      lines: [
        '<span class="kw">every</span> chunk (slow, 1–2 Hz):',
        '    <span data-sym="z">z</span> ← latent diffusion policy(<span data-sym="o">oₜ</span>: 2 frames of image, touch, pose)  <span class="cm">// 8 denoising steps, about 100 ms</span>',
        '    drop the first latent steps to cover that latency',
        '    <span class="kw">for</span> each 24 Hz tick <span class="kw">in</span> the chunk:',
        '        read the latest tactile PCA features or 6-D wrench',
        '        <span data-sym="a">aₜ</span> ← GRU decoder(<span data-sym="z">z</span>, latest touch)  <span class="cm">// under 1 ms</span>',
        '        send <span data-sym="a">aₜ</span> as a relative pose, interpolated above 500 Hz'
      ]
    },
    playgrounds: [
      {
        id: "gate", title: "When should the policy listen to force?", ref: "P10 §2.5.3–2.5.4 · FoAR · ForceVLA", prov: "Simplified: peg-in-hole toy",
        try: "Start on Gated and watch φ open at contact. Switch to Vision only, then Concatenate, and compare peak force and jitter. On Gated, drag the gate bias far negative.",
        mount: mountGate,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e5-gate";
          return [
            { target: q("canvas"), title: "Read the timeline", text: "The accent line φ stays near 0 during the approach and rises to 1 at contact, when force starts to carry information about the hole." },
            { target: q("#" + id + "-mode"), title: "Take force away", text: "Vision alone lands 1.5 mm off center, cannot feel the jam, and keeps pressing until the force limit.", do: function (a) { return a.click(q("#" + id + '-mode [value="vision"]')); }, task: "Choose Vision only", expect: function () { return api.state().mode === "vision"; } },
            { target: q("#" + id + "-mode"), title: "Force in every phase", text: "Concatenation inserts the peg, but the approach path is jagged: before contact the force reading is noise, and the policy acts on it.", do: function (a) { return a.click(q("#" + id + '-mode [value="concat"]')); }, task: "Choose Concatenate", expect: function () { return api.state().mode === "concat"; } },
            { target: q("#" + id + "-noise"), title: "Noisier sensor", text: "At 4 N of noise the approach jitter grows. The gated policy would ignore that noise in free space.", do: function (a) { return a.set(q("#" + id + "-noise"), 4); }, task: "Set sensor noise to 4 N", expect: function () { return api.state().sigma >= 4; } },
            { target: q("#" + id + "-mode"), title: "Gate by contact", text: "The gate keeps the approach smooth and still uses force once the peg touches the chamfer.", do: function (a) { return a.click(q("#" + id + '-mode [value="gate"]')); }, task: "Choose Gated", expect: function () { return api.state().mode === "gate"; } },
            { target: q("#" + id + "-bias"), title: "A gate that opens late", text: "With a bias of −20 the gate waits for about 20 N before trusting force, so the peak force climbs.", do: function (a) { return a.set(q("#" + id + "-bias"), -20); }, task: "Set the gate bias to −20", expect: function () { return api.state().bias <= -16; } },
            { target: q("#" + id + "-mode"), title: "Your turn", text: "Try MoE top-1 with noise 4 N and watch the expert switches. Then set vision error to 0: now force matters much less." }
          ];
        }
      },
      {
        id: "slowfast", title: "Slow plans, fast touch", ref: "RDP, arXiv 2503.02881 · P10 §4.4", prov: "Simplified: 1-D wiping toy",
        try: "Watch the force leave the band when the bump arrives. Raise the slow rate to 10 Hz, then return it to 2 Hz and switch on the fast loop.",
        mount: mountSlowFast,
        demo: function (body, api) {
          var q = function (s) { return body.querySelector(s); }, id = "e5-slowfast";
          return [
            { target: q("canvas"), title: "Open loop inside a chunk", text: "At 2 Hz the plan changes only at the ticks. The bump at 1.2 s pushes the force out of the band until the next chunk." },
            { target: q("#" + id + "-rate"), title: "Call the big model more", text: "At 10 Hz the error is shorter, but every call is a full diffusion pass. RDP's slow policy needs about 100 ms.", do: function (a) { return a.set(q("#" + id + "-rate"), 10); }, task: "Set the slow rate to 10 Hz", expect: function () { return api.state().rate >= 9; } },
            { target: q("#" + id + "-rate"), title: "Back to slow", text: "Return to 2 Hz, the rate RDP's latent diffusion policy runs at in practice.", do: function (a) { return a.set(q("#" + id + "-rate"), 2); }, task: "Set the slow rate to 2 Hz", expect: function () { return api.state().rate <= 2; } },
            { target: q("#" + id + "-fast"), title: "Add the fast loop", text: "A small decoder reads the latest force every 1/24 s and shifts the plan. The force returns to the band within a few ticks.", do: function (a) { return a.click(q("#" + id + '-fast [value="on"]')); }, task: "Switch on the fast loop", expect: function () { return api.state().fast; } },
            { target: q(".sb-readouts"), title: "Your turn", text: "Set the bump to 6 mm and compare contact lost with the fast loop off and on. Why does raising the slow rate cost more?" }
          ];
        }
      }
    ],
    methodsLede: "How the line evolved: M3L masked-autoencoded pixels and taxels for RL. 3D-ViTac placed taxels as 3D points beside the visual cloud; UniT froze a VQGAN tactile encoder trained on one object. FoAR gated RISE's force feature by predicted contact; ACP taught Diffusion Policy to output stiffness. RDP split Diffusion Policy into slow latent chunks and a fast touch-conditioned decoder. FuSe, ForceVLA, TA-VLA and Tactile-VLA carried touch, wrench or torque into VLAs, differing mainly in where the signal enters.",
    methods: ["reactive-diffusion-policy", "foar", "forcevla", "adaptive-compliance-policy", "tactile-vla", "ta-vla", "3d-vitac", "unit", "fuse", "m3l", "tacdiffusion", "vital"],
    open: [
      { title: "No shared touch backbone", text: "Wrench readings depend on mounting and robot dynamics; tactile sensors differ in mechanism and resolution. No pretrained backbone spans sensors and embodiments.", refs: "P10 §7.1.1" },
      { title: "General phase signals", text: "Contact probabilities and routing weights are learned per task. A reusable encoding of non-contact, pre-contact and in-contact phases is missing.", refs: "P10 §7.1.2" },
      { title: "Slow reasoning, fast contact", text: "Large policies are too slow for millisecond feedback and millimeter precision. The split between slow planners and fast reactive modules is not yet formalized.", refs: "P10 §7.1.3 · P01 §6.2.3" },
      { title: "Platform-bound control outputs", text: "Predicted stiffness or reference force only works where the robot exposes that control mode. Policies that mimic compliance through position control are open.", refs: "P10 §7.1.4" }
    ],
    takeaways: [
      "Force/torque sensing measures the global load; touch measures the local contact. Both matter mostly once contact begins.",
      "Where force enters matters: ForceVLA's plug insertion ranged from 0% to 80% across fusion placements.",
      "Gating or routing by contact phase keeps free-space noise out; FoAR scales force by predicted contact probability.",
      "Policies can output stiffness or reference force; ACP's direction-aware stiffness reached 96% flipping success against 14% for a stiff policy.",
      "Slow–fast designs react inside a chunk: RDP decodes latent chunks at 24 Hz from the latest touch, in under 1 ms."
    ],
    quiz: [
      { q: "During the free-space approach, why can a force feature hurt a policy that always concatenates it?", options: ["The force sensor switches off", "The reading is only noise, and the policy acts on it", "Force features are too large to store", "Vision stops working"], correct: 1, why: "Before contact the wrench carries no task information. FoAR found naive fusion injects noisy readings and gates force by predicted contact (arXiv 2411.15753)." },
      { q: "ForceVLA tested where to fuse force for plug insertion. Which placement worked best?", options: ["Mixture of experts before the VLM", "Linear projection before the VLM", "Concatenation after the VLM", "Mixture-of-experts fusion after the VLM"], correct: 3, why: "Success was 0%, 55%, 60% and 80% for these placements; late fusion through the force-aware mixture of experts worked best (arXiv 2505.22159)." },
      { q: "In Reactive Diffusion Policy, what runs at 24 Hz?", options: ["The latent diffusion policy", "A GRU decoder reading the latest touch or force", "The camera encoder", "A vision-language model"], correct: 1, why: "The slow latent diffusion policy plans at 1–2 Hz; the asymmetric tokenizer's GRU decoder turns the latent chunk into actions every tick (arXiv 2503.02881)." },
      { q: "ACP labels stiffness from a demonstration. Along which direction is stiffness low?", options: ["Along gravity", "Along the measured force", "Perpendicular to the force", "Along the camera axis"], correct: 1, why: "K = S K₀ S⁻¹ puts k_low on the force direction and k_high elsewhere, which ACP proves keeps the contact constraint satisfied (arXiv 2410.09309)." },
      { q: "In the worked example, the surface rises 4 mm under a spring of 600 N/m. How much does the force rise?", options: ["0.6 N", "2.4 N", "20 N", "It drops to zero"], correct: 1, why: "ΔF = k Δx = 600 N/m × 0.004 m = 2.4 N, so 6 N becomes 8.4 N." }
    ],
    cards: [
      { front: "What are the four TF-ART phases?", back: "Phase 0 multimodal fusion, Phase 1 primary action policy, Phase 2 action refinement, Phase 3 robot-end control.", ref: "P10 Fig. 1–2" },
      { front: "Which four fusion families does P10 name?", back: "FiLM injection, attention conditioning, mixture of experts and gated filtering.", ref: "P10 §2.5" },
      { front: "How does FoAR fuse force?", back: "It blends the force feature with a learned neutral embedding, weighted by predicted contact probability φ, then concatenates the scene feature.", ref: "arXiv 2411.15753" },
      { front: "What does ACP add to Diffusion Policy's action?", back: "A virtual target pose and a stiffness scalar, executed by an admittance controller with stiffness low along the force.", ref: "arXiv 2410.09309" },
      { front: "Why does RDP feed touch only to the decoder, not the encoder?", back: "So the latent keeps the high-level plan; the symmetric version dropped Peeling from 0.95 to 0.58.", ref: "arXiv 2503.02881" },
      { front: "Where did TA-VLA find torque works best in π0?", back: "As one history token on the action-decoder side: 12/20 versus 8/20 on the encoder side for charger plugging.", ref: "arXiv 2509.07962" }
    ],
    terms: {
      "tf-art": { name: "TF-ART", aliases: ["tactile/force-aware robot learning taxonomy"], group: "contact", def: "A taxonomy that maps each touch- or force-aware method onto four phases: multimodal fusion, primary action policy, action refinement and robot-end control.", note: "Phase 2 is optional; many methods go straight from the primary policy to the controller.", ref: "P10 Fig. 1–2", scene: "system", focus: ["vision-encoder", "action-head", "controller"], look: "the pipeline from sensors to controller", uses: ["slow-fast-policy"] },
      "wrench": { name: "wrench", aliases: ["force/torque reading", "F/T", "6-D wrench"], group: "contact", def: "The six-dimensional force and torque at the end effector, measured by a wrist force/torque sensor or estimated from joint torques.", note: "It is global: one wrench cannot say where on the fingers the contact is.", ref: "P10 §1.1, §2.2", scene: "robot", focus: ["ft-sensor", "end-effector"], look: "the sensor at the wrist", uses: [] },
      "vision-based-tactile-sensor": { name: "vision-based tactile sensor", aliases: ["GelSight", "optical tactile sensor", "visual-tactile"], group: "contact", def: "A sensor whose camera images a soft gel as it deforms, giving a tactile image of the contact patch.", note: "Rich but bulky; piezoresistive pads such as 3D-ViTac's are cheap but sense normal pressure only.", ref: "P10 §2.1, Table 2", scene: "robot", focus: ["tactile-pad", "fingers"], look: "the pad on the finger", uses: [] },
      "gated-filtering": { name: "gated filtering", aliases: ["modality gate", "gated fusion"], group: "contact", sym: "φₜ", symTex: "\\phi_t", def: "Scaling a modality's features by a learned value between 0 and 1 that depends on the task state, suppressing the modality when it is uninformative.", note: "A gate is soft; top-1 expert routing is a hard switch.", ref: "P10 eq. 10", scene: "system", focus: ["vision-encoder", "action-head"], look: "the gate before the head", uses: ["future-contact-prediction"] },
      "future-contact-prediction": { name: "future contact prediction", aliases: ["contact probability"], group: "contact", def: "A separate predictor estimates the probability of contact in the coming steps; FoAR uses it to gate force features and trigger reactive corrections.", note: "FoAR's version that shared the 3D encoder collapsed to 0.175 on wiping.", ref: "arXiv 2411.15753", scene: "robot", focus: ["contact-point", "object"], look: "the gripper about to touch", uses: [] },
      "mixture-of-experts": { name: "mixture of experts", aliases: ["MoE", "expert routing"], group: "contact", def: "A router sends each token to a small set of specialist networks and mixes their outputs by routing weights.", note: "MoE transforms features; it still needs concatenation, FiLM or attention to reach the action head.", ref: "P10 eq. 9", scene: "system", focus: ["llm-backbone", "action-head"], look: "tokens routed to experts", uses: [] },
      "film-conditioning": { name: "FiLM conditioning", aliases: ["feature-wise linear modulation", "FiLM injection"], group: "contact", def: "A pooled modality feature produces a per-channel scale and shift that modulate the action tokens inside the policy.", note: "It is global per sample: it cannot attend to one tactile patch.", ref: "P10 eq. 7", scene: "system", focus: ["action-head"], look: "features modulating the head", uses: [] },
      "masked-autoencoding": { name: "masked autoencoding", aliases: ["MAE", "multimodal MAE"], group: "contact", def: "Masking most input tokens and training the encoder to reconstruct them; with vision and touch together it learns cross-modal structure.", note: "M3L masks 95% of pixel and taxel tokens and trains it jointly with PPO.", ref: "P10 eq. 2", scene: "system", focus: ["vision-encoder", "latent"], look: "the encoder learning from masks", uses: [] },
      "vq-based-reconstruction": { name: "VQ-based reconstruction", aliases: ["vector quantization", "VQR"], group: "contact", def: "Mapping each continuous latent token to its nearest learned codebook entry, then reconstructing the input from the codes.", note: "UniT's VQGAN tactile encoder, trained on one object, beat encoders trained on more data.", ref: "P10 eq. 3–4", scene: "system", focus: ["latent"], look: "discrete codes in the latent", uses: [] },
      "multimodal-contrastive-alignment": { name: "multimodal contrastive alignment", aliases: ["InfoNCE", "CLIP-style loss", "MCA"], group: "contact", def: "Pulling together embeddings of matched samples from two modalities and pushing apart mismatched pairs in the batch.", note: "It needs no reconstruction; FuSe aligns touch and audio with language this way.", ref: "P10 eq. 5–6", scene: "system", focus: ["vision-encoder", "latent"], look: "two encoders meeting in one space", uses: [] },
      "reference-force": { name: "reference force", aliases: ["target force", "F_ref"], group: "contact", def: "A force the policy asks the controller to apply, used as feed-forward compensation or a target for force regulation.", note: "Only meaningful with a force-capable controller; Tactile-VLA mapped 'softly' to 0.51 N and 'hard' to 2.57 N.", ref: "P10 §3.2.2", scene: "robot", focus: ["end-effector", "object"], look: "the tool pressing on the object", uses: [] },
      "control-stiffness": { name: "control stiffness", aliases: ["predicted stiffness", "stiffness gain"], group: "contact", sym: "K_d", symTex: "K_d", def: "Stiffness gains a policy outputs for an impedance or admittance controller: large gains act rigidly, small gains let the robot yield under contact.", note: "ACP predicts one scalar per step; Comp-ACT and DIPCOM predict diagonal stiffness.", ref: "P10 §3.2.3", scene: "robot", focus: ["end-effector", "contact-point"], look: "the spring between tool and target", uses: ["reference-force"] },
      "slow-fast-policy": { name: "slow–fast policy", aliases: ["dual-frequency policy", "multi-phase refinement"], group: "contact", def: "A slow model plans chunks from vision and language; a small fast model or rule corrects them from the latest touch or force.", note: "It fixes reaction time inside a chunk, not the slow model's latency.", ref: "P10 §4.4", scene: "system", focus: ["action-chunk", "controller"], look: "a fast loop beside the chunk", uses: ["asymmetric-tokenizer"] },
      "asymmetric-tokenizer": { name: "asymmetric tokenizer", aliases: ["RDP fast policy"], group: "contact", def: "RDP's fast policy: a 1-D CNN compresses action chunks into latents; a GRU decoder rebuilds actions from the latent and the latest touch or wrench.", note: "Touch enters only the decoder, so the latent holds strategy and the decoder handles reflexes.", ref: "arXiv 2503.02881", scene: "system", focus: ["latent", "action-head"], look: "a latent decoded tick by tick", uses: [] }
    },
    symbols: [
      { id: "fmod", tex: "F^{m}", glyph: "Fᵐ", kind: "Signals", meaning: "encoded feature of one input modality m (touch, force, vision)", short: "modality feature", first: "e5", read: "F superscript m", papers: "P10 eq. 1, 10: F^m" },
      { id: "cphi", tex: "\\phi_t", glyph: "φₜ", kind: "Signals", meaning: "gate value in [0, 1]: predicted probability of contact that scales the force feature", short: "contact gate", first: "e5", read: "phi sub t", papers: "FoAR: φ(t) · P10 eq. 10: σ(G_m(s_t))" },
      { id: "hscene", tex: "h^{s}_t", glyph: "hˢₜ", kind: "Signals", meaning: "scene feature from images or point clouds", short: "scene feature", first: "e5", read: "h s sub t", papers: "FoAR: h^s_t" },
      { id: "hforce", tex: "h^{f}_t", glyph: "hᶠₜ", kind: "Signals", meaning: "force/torque feature from the wrench history", short: "force feature", first: "e5", read: "h f sub t", papers: "FoAR: h^f_t" },
      { id: "hneutral", tex: "h^{*}", glyph: "h*", kind: "Parameters", meaning: "learned neutral embedding that replaces the force feature when no contact is expected", short: "neutral embedding", first: "e5", read: "h star", papers: "FoAR: h*" },
      { id: "sforce", tex: "S", glyph: "S", kind: "Parameters", meaning: "orthonormal basis whose first column is the unit force direction", short: "force-aligned basis", first: "e5", read: "S", papers: "ACP: S (first column f/|f|)" },
      { id: "klow", tex: "k_{\\text{low}}", glyph: "k_low", kind: "Parameters", meaning: "stiffness along the measured force direction", short: "stiffness along the force", first: "e5", read: "k low", papers: "ACP: k_low" }
    ],
    ledger: [
      { where: "Topic 19 · rules", source: "P10 eq. 5 writes the contrastive temperature as τ", page: "This page writes κ", why: "τ is flow time in the house notation.", kind: "Our choice" },
      { where: "Topic 19 · rules", source: "ACP writes stiffness K; P10 eq. 7 writes noisy action tokens Ãₜ", page: "House K_d for stiffness and a^τ for noisy actions", why: "One symbol per idea across the site.", kind: "Our choice" },
      { where: "Topic 19 · worked example", source: "ACP says k_max, k_min, f_max and f_min are set per hardware and gives no values", page: "Toy values 1000 and 200 N/m, 1 and 11 N; signs and the virtual-target offset shown along one axis", why: "Makes the label computable by hand.", kind: "Simplified" },
      { where: "Topic 19 · playground 1", source: "FoAR predicts contact with a separate ResNet-18 and MLP; ForceVLA routes tokens with a learned router", page: "The gate is a fixed sigmoid of height and measured normal force; the router thresholds the same value", why: "Isolates the effect of when force is used.", kind: "Simplified" },
      { where: "Topic 19 · playground 2", source: "RDP decodes latent chunks with a GRU conditioned on tactile PCA features or wrench", page: "The fast loop is an integral force correction at 24 Hz on a 1-D wiping toy", why: "Shows reaction inside a chunk without a network.", kind: "Simplified" },
      { where: "Topic 19 · ForceVLA numbers", source: "ForceVLA's text calls 37.3% 'π0-base w/ F'; its figure shows 37.3% without force and 40.2% with force", page: "The site follows the figure", why: "The stated 23.2-point gain (60.5 − 37.3) also implies 37.3% is without force.", kind: "Sources disagree" }
    ]
  });
})();
