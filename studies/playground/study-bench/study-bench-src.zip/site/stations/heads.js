/* Lab station · Policy head bench (topics 05, 06). Sources: X2 §4 (eq. 18, 44–53), ACT, Diffusion Policy, π0, Consistency Policy method cards.
   Toy: a point robot moves up at fixed speed past a block. Demonstrations pass it on the left or on the right.
   Every head gets the exact (ideal) score or velocity of the two-mode chunk distribution at the robot's state,
   softened by a model-error temperature, so differences come from the head, the sampler and the execution scheme. */
(function () {
  "use strict";
  var RB = window.RB;

  var SIM = (function () {
  var V = 0.025, AMP = 0.45, SW = 0.12, S = 0.08, VC = 0.04, OBS = { x0: -0.2, x1: 0.2, y0: 0.35, y1: 0.65 }, RAD = 0.025, GOALX = 0.15, TMAX = 70;
  function pathX(m, y) { return (m === 0 ? -1 : 1) * AMP * Math.sin(Math.PI * Math.min(1.2, Math.max(0, y))); }
  function modeW(x, y) {
    var l = [0, 1].map(function (m) { var d = x - pathX(m, y); return -d * d / (2 * SW * SW); }), mx = Math.max(l[0], l[1]);
    var e = l.map(function (v) { return Math.exp(v - mx); }), z = e[0] + e[1]; return [e[0] / z, e[1] / z];
  }
  /* mean chunk (normalized lateral velocities, H dims) for mode m from state (x, y) */
  function modeMean(m, x, y, H) {
    var d0 = x - pathX(m, y), d = Math.abs(d0), rho = 1 - 0.2 * Math.exp(-(d / 0.12) * (d / 0.12)), out = [], px = x;
    for (var j = 1; j <= H; j++) { var yj = y + j * V, xj = pathX(m, yj) + d0 * Math.pow(rho, j); out.push(Math.max(-3, Math.min(3, (xj - px) / VC))); px = xj; }
    return out;
  }
  function abar(u) { var s = 0.008, f = function (v) { var c = Math.cos((v + s) / (1 + s) * Math.PI / 2); return c * c; }; return Math.max(1e-4, Math.min(0.9999, f(u) / f(0))); }
  var SB = 0.999;
  function pBeta(t) { var u = (SB - t) / SB; return u <= 0 ? 0 : 1.5 * Math.sqrt(u) / SB; }
  function temp(head, t, eps) { if (head === "fmb") return 1 + eps / Math.max(0.2, pBeta(t)); return 1 + eps; }
  /* posterior over components for x ~ a*mu + noise(var s2) */
  function post(x, mus, w, a, s2, T) {
    var l = mus.map(function (mu, i) { var q = 0; for (var j = 0; j < x.length; j++) { var d = x[j] - a * mu[j]; q += d * d; } return (Math.log(w[i] + 1e-12) - q / (2 * s2)) / T; }), mx = Math.max.apply(null, l);
    var e = l.map(function (v) { return Math.exp(v - mx); }), z = e.reduce(function (p, c) { return p + c; }, 0); return e.map(function (v) { return v / z; });
  }
  function flowV(x, t, mus, w, T) {
    var s2 = t * t * S * S + (1 - t) * (1 - t), r = post(x, mus, w, t, s2, T), v = x.map(function () { return 0; });
    mus.forEach(function (mu, i) { for (var j = 0; j < x.length; j++) { var d = x[j] - t * mu[j]; v[j] += r[i] * (mu[j] + t * S * S / s2 * d - (1 - t) / s2 * d); } });
    return v;
  }
  function epsHat(x, ab, mus, w, T) {
    var s2 = ab * S * S + 1 - ab, sa = Math.sqrt(ab), r = post(x, mus, w, sa, s2, T), e = x.map(function () { return 0; });
    mus.forEach(function (mu, i) { for (var j = 0; j < x.length; j++) e[j] += r[i] * Math.sqrt(1 - ab) / s2 * (x[j] - sa * mu[j]); });
    return e;
  }
  function Phi_inv(p) { /* probit via bisection-free approx (Acklam-lite) */ p = Math.min(1 - 1e-6, Math.max(1e-6, p)); var t = Math.sqrt(-2 * Math.log(p < 0.5 ? p : 1 - p)); var z = t - (2.515517 + 0.802853 * t + 0.010328 * t * t) / (1 + 1.432788 * t + 0.189269 * t * t + 0.001308 * t * t * t); return p < 0.5 ? -z : z; }
  var NFE1 = { mse: 1, cvae: 1, one: 1 };
  function nfe(head, K) { return NFE1[head] ? 1 : K; }
  /* sample one chunk; returns {u: H-vector, path: [H-vectors] (sampling trajectory), mode: 0|1|-1} */
  function sampleChunk(head, x, y, H, K, eps, R, keepPath) {
    var w = modeW(x, y), mus = [modeMean(0, x, y, H), modeMean(1, x, y, H)], path = [], u, k;
    var gauss = function () { var g = []; for (var j = 0; j < H; j++) g.push(R.normal()); return g; };
    if (head === "mse") { u = mus[0].map(function (v, j) { return w[0] * v + w[1] * mus[1][j]; }); if (keepPath) path = [u.map(function () { return 0; }), u]; }
    else if (head === "cvae") {
      var z = R.normal(), sh = 8 / (1 + 2 * eps), g = 1 / (1 + Math.exp(-sh * (z - Phi_inv(w[0])))), n = gauss();
      u = mus[0].map(function (v, j) { return (1 - g) * v + g * mus[1][j] + S * n[j]; }); if (keepPath) path = [u.map(function () { return z * 0.3; }), u];
    } else if (head === "fm" || head === "fmb" || head === "one") {
      var xx = gauss(), KK = head === "one" ? 32 : K; if (keepPath) path.push(xx.slice());
      for (k = 0; k < KK; k++) { var t = k / KK, v = flowV(xx, t, mus, w, temp(head === "one" ? "fm" : head, t, eps)); xx = xx.map(function (a, j) { return a + v[j] / KK; }); if (keepPath && head !== "one") path.push(xx.slice()); }
      if (head === "one") { var dn = gauss(); xx = xx.map(function (a, j) { return a + 0.5 * S * dn[j]; }); if (keepPath) path.push(xx.slice()); }
      u = xx;
    } else { /* ddpm / ddim on a cosine schedule */
      var xd = gauss(); if (keepPath) path.push(xd.slice());
      for (k = K; k >= 1; k--) {
        var ab = abar(k / K), abp = k > 1 ? abar((k - 1) / K) : 1, e = epsHat(xd, ab, mus, w, 1 + eps);
        if (head === "ddim") { var x0 = xd.map(function (a, j) { return (a - Math.sqrt(1 - ab) * e[j]) / Math.sqrt(ab); }); xd = x0.map(function (a, j) { return Math.sqrt(abp) * a + Math.sqrt(1 - abp) * e[j]; }); }
        else { var al = ab / abp, be = 1 - al, sd = k > 1 ? Math.sqrt(be * (1 - abp) / (1 - ab)) : 0; xd = xd.map(function (a, j) { return (a - be / Math.sqrt(1 - ab) * e[j]) / Math.sqrt(al) + sd * R.normal(); }); }
        if (keepPath) path.push(xd.slice());
      }
      u = xd;
    }
    /* which mode is the chunk closest to (or -1 when it sits between them) */
    var dd = mus.map(function (mu) { var q = 0; for (var j = 0; j < H; j++) q += (u[j] - mu[j]) * (u[j] - mu[j]); return Math.sqrt(q / H); });
    var sep = Math.sqrt(mus[0].reduce(function (a, v, j) { return a + (v - mus[1][j]) * (v - mus[1][j]); }, 0) / H);
    var mode = sep < 0.15 ? (dd[0] < dd[1] ? 0 : 1) : (Math.min(dd[0], dd[1]) < 0.35 * sep ? (dd[0] < dd[1] ? 0 : 1) : -1);
    return { u: u, path: path, mode: mode, mus: mus };
  }
  function nearD(x, y) { return Math.min(Math.abs(x - pathX(0, y)), Math.abs(x - pathX(1, y))); }
  function hits(x, y) { return x > OBS.x0 - RAD && x < OBS.x1 + RAD && y > OBS.y0 - RAD && y < OBS.y1 + RAD; }
  /* one rollout. o: {head, K, H, exec:"all"|"half"|"ens", m, dist, eps, shove} */
  function rollout(o, R) {
    var x = 0, y = 0, xs = [[x, y]], queries = [], plan = [], buf = [], t, res = "timeout", lastMode = null, switches = 0, jerk = 0, vPrev = 0, vPrev2 = 0;
    var Ta = o.exec === "half" ? Math.max(1, Math.ceil(o.H / 2)) : o.H;
    for (t = 0; t < TMAX; t++) {
      var need = o.exec === "ens" || !plan.length;
      if (need) {
        var ch = sampleChunk(o.head, x, y, o.H, o.K, o.eps, R, false);
        /* one query = one learned-model error: a lateral offset that grows off the demonstrations */
        var d = nearD(x, y), qe = o.eps * 0.04 * (1 + d / 0.05) * R.normal() / VC;
        var vel = ch.u.map(function (u, j) { return (u + (j === 0 ? qe : 0)) * VC; });
        var qrec = { t: t, len: o.exec === "ens" ? 1 : Math.min(Ta, o.H), mode: ch.mode };
        if (o.plans) { var px = x, py = y; qrec.plan = vel.map(function (v) { px += v; py += V; return [px, py]; }); }
        queries.push(qrec);
        if (ch.mode >= 0) { if (lastMode !== null && ch.mode !== lastMode) switches++; lastMode = ch.mode; }
        if (o.exec === "ens") { buf.push({ t0: t, v: vel }); buf = buf.filter(function (b) { return t - b.t0 < b.v.length; }); }
        else plan = vel.slice(0, Ta);
      }
      var vx;
      if (o.exec === "ens") { var num = 0, den = 0; buf.forEach(function (b, i) { var wt = Math.exp(-o.m * i); num += wt * b.v[t - b.t0]; den += wt; }); vx = num / den; }
      else vx = plan.shift();
      var push = (o.shove && t === 14) ? 0.12 : 0;
      x += vx + o.dist * 0.01 * R.normal() + push; y += V;
      jerk += Math.abs(vx - 2 * vPrev + vPrev2); vPrev2 = vPrev; vPrev = vx;
      xs.push([x, y]);
      if (hits(x, y)) { res = "hit"; break; }
      if (Math.abs(x) > 0.95) { res = "lost"; break; }
      if (y >= 1) { res = Math.abs(x) <= GOALX ? "goal" : "miss"; break; }
    }
    var side = xs.reduce(function (a, p) { return p[1] > 0.35 && p[1] < 0.65 ? a + p[0] : a; }, 0);
    return { xs: xs, res: res, queries: queries, switches: switches, jerk: jerk / Math.max(1, xs.length), side: side < 0 ? 0 : 1, steps: xs.length - 1 };
  }
  function batch(o, n, seed) { var R = RB.rng(seed), out = []; for (var i = 0; i < n; i++) out.push(rollout(o, R)); return out; }
  return { rollout: rollout, batch: batch, sampleChunk: sampleChunk, nfe: nfe, pathX: pathX, modeW: modeW, OBS: OBS, V: V, VC: VC, GOALX: GOALX, TMAX: TMAX, RAD: RAD };
})();

  /* ================= station UI ================= */
  var HEADS = [
    { value: "mse", label: "Regression" }, { value: "cvae", label: "CVAE" }, { value: "ddpm", label: "DDPM" }, { value: "ddim", label: "DDIM" },
    { value: "fm", label: "Flow" }, { value: "fmb", label: "Flow β" }, { value: "one", label: "One-step" }
  ];
  var HEAD_NAME = { mse: "Regression (MSE)", cvae: "CVAE", ddpm: "DDPM", ddim: "DDIM", fm: "Flow, uniform τ", fmb: "Flow, Beta τ", one: "One-step" };
  var HEAD_NOTE = {
    mse: "Regression returns the mean chunk. Near the start both ways are equally likely, so the mean goes straight at the block (X2 eq. 18, §4).",
    cvae: "The CVAE draws a style z and decodes one chunk. ACT sets z = 0 at test time; here z is sampled so you can see both modes (X2 eq. 50).",
    ddpm: "DDPM removes noise in K stochastic steps (X2 eq. 44–45). Diffusion Policy uses 100 steps in simulation (arXiv 2303.04137).",
    ddim: "DDIM takes the same noise predictor through K deterministic steps. Diffusion Policy runs 16 DDIM steps on the robot (arXiv 2303.04137).",
    fm: "Flow matching integrates a velocity field in K Euler steps, with training times τ drawn uniformly (X2 eq. 49).",
    fmb: "The same flow head trained with π0's Beta-shaped τ, which puts more training on noisy chunks (X2 eq. 52–53). π0 uses 10 steps.",
    one: "A one-step head maps noise to a chunk in one call, like a distilled consistency policy (arXiv 2405.07503)."
  };
  var PRESETS = {
    bc: { head: "mse", K: 10, H: 1, exec: "all", label: "Per-step BC" },
    act: { head: "cvae", K: 10, H: 16, exec: "all", label: "ACT-like" },
    dp: { head: "ddim", K: 16, H: 16, exec: "half", label: "Diffusion Policy" },
    pi0: { head: "fmb", K: 10, H: 16, exec: "all", label: "π0-like" },
    cp: { head: "one", K: 10, H: 16, exec: "half", label: "Consistency" }
  };
  var MS_PER_CALL = 1.1; /* Consistency Policy: DDPM 100 steps = 110 ms on an NVIDIA P5000 (arXiv 2405.07503) */
  var NROLL = 12;

  function mount(api) {
    var id = api.id, sc = api.scene, ct = api.controls;
    var st = { head: "fm", K: 10, H: 8, exec: "all", m: 0.1, dist: 0.5, eps: 0.3, shove: false, seed: 3, preset: null };
    var runs = [], tNow = 0, maxT = 1, done = false, raf = 0, t0 = 0, chartT = 0, dead = false, den = null, denK = 0, stepped = 0;

    sc.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Workspace: twelve rollouts from the start past a block to the goal"></canvas><figcaption class="sb-caption">Dashed = the two demonstrated ways around the block. Watch where rollouts fail: into the block, off the goal, or wobbling between sides. The accent line ahead of rollout 1 is its current chunk.</figcaption></figure>' +
      RB.legend([{ c: "data-1", label: "passes left", kind: "line" }, { c: "data-2", label: "passes right", kind: "line" }, { c: "bad", label: "fails", kind: "line" }, { c: "ink-3", label: "demonstrations", kind: "dash" }]) +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-tl" aria-label="Timeline of policy queries for rollout 1"></canvas><figcaption class="sb-caption">Rollout 1 over time: each bar is one chunk, colored by the side it plans. Many short bars of mixed color mean the robot keeps changing its mind.</figcaption></figure>' +
      RB.readouts([{ id: "goal", k: "Reached the goal" }, { id: "hit", k: "Hit the block" }, { id: "lr", k: "Left / right" }, { id: "sw", k: "Side switches", u: "per rollout" }, { id: "nfe", k: "Network calls", u: "per chunk" }, { id: "calls", k: "Calls per rollout" }, { id: "lat", k: "Latency per chunk", u: "ms, est." }, { id: "jerk", k: "Mean jerk", u: "×10⁻³" }]) +
      '<p class="sb-caption" id="' + id + '-note"></p>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-dn" aria-label="Sixteen candidate chunks being denoised from the start state"></canvas><figcaption class="sb-caption">Sixteen chunks sampled at the start, drawn as planned paths. Press Step denoiser to watch noise become one of the two dashed plans, or the mean.</figcaption></figure>' +
      '<div id="' + id + '-chart"></div>';

    ct.innerHTML =
      '<div class="rb-stack"><span class="sb-caption">Preset</span>' + RB.seg({ id: id + "-pre", label: "Preset", value: "", options: Object.keys(PRESETS).map(function (k) { return { value: k, label: PRESETS[k].label }; }) }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Policy head</span>' + RB.seg({ id: id + "-head", label: "Policy head", value: st.head, options: HEADS }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Execution</span>' + RB.seg({ id: id + "-exec", label: "Execution", value: st.exec, options: [{ value: "all", label: "All H" }, { value: "half", label: "Half H" }, { value: "ens", label: "Ensemble" }] }) + "</div>" +
      RB.slider({ id: id + "-k", label: "Steps K", min: 1, max: 50, step: 1, value: st.K }) +
      RB.slider({ id: id + "-h", label: "Chunk size H", min: 1, max: 32, step: 1, value: st.H }) +
      RB.slider({ id: id + "-m", label: "Ensemble weight m", min: 0, max: 1, step: 0.05, value: st.m, fmt: f2 }) +
      RB.slider({ id: id + "-dist", label: "Disturbance", min: 0, max: 2, step: 0.1, value: st.dist, fmt: f1 }) +
      RB.slider({ id: id + "-eps", label: "Model error", min: 0, max: 1.5, step: 0.05, value: st.eps, fmt: f2 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-shove"> <span>Shove at step 15</span></label>' +
      '<div class="sb-btn-row"><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-run">Run rollouts ▶</button><button class="sb-btn" type="button" id="' + id + '-step">Step denoiser</button><button class="sb-btn sb-btn--ghost" type="button" id="' + id + '-seed">New seed</button></div>';

    function f1(v) { return (+v).toFixed(1); }
    function f2(v) { return (+v).toFixed(2); }
    var q = function (s) { return sc.querySelector(s) || ct.querySelector(s); };
    var cv = q("#" + id + "-cv"), dn = q("#" + id + "-dn"), tl = q("#" + id + "-tl"), note = q("#" + id + "-note");
    var FW = 560, FH = 420, DW = 560, DH = 260, TW = 560, TH = 100;
    var font = function (w, px, kind) { return w + " " + px + "px " + getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); };
    var toPx = function (x, y) { return [FW / 2 + x * 250, FH - 30 - y * 340]; };

    function colOf(r, P) { return r.res === "goal" ? (r.side === 0 ? P["data-1"] : P["data-2"]) : P.bad; }
    function drawField() {
      if (dead) return;
      var P = RB.pal(), c = RB.canvas(cv, FW, FH), O = SIM.OBS, i;
      c.fillStyle = P.surface; c.fillRect(0, 0, FW, FH);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (i = 0; i <= FW; i += 40) { c.beginPath(); c.moveTo(i, 0); c.lineTo(i, FH); c.stroke(); }
      for (i = 0; i <= FH; i += 40) { c.beginPath(); c.moveTo(0, i); c.lineTo(FW, i); c.stroke(); }
      var g0 = toPx(-SIM.GOALX, 1.08), g1 = toPx(SIM.GOALX, 1); c.fillStyle = P["good-soft"]; c.fillRect(g0[0], g0[1], g1[0] - g0[0], g1[1] - g0[1]);
      c.fillStyle = P["ink-2"]; c.font = font("600", 12, "body"); c.textAlign = "center"; c.fillText("goal", (g0[0] + g1[0]) / 2, g0[1] - 6);
      var o0 = toPx(O.x0, O.y1), o1 = toPx(O.x1, O.y0);
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.fillRect(o0[0], o0[1], o1[0] - o0[0], o1[1] - o0[1]); c.strokeRect(o0[0], o0[1], o1[0] - o0[0], o1[1] - o0[1]);
      c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.fillText("block", (o0[0] + o1[0]) / 2, (o0[1] + o1[1]) / 2 + 4);
      [0, 1].forEach(function (m) { c.strokeStyle = P["ink-3"]; c.setLineDash([5, 5]); c.beginPath(); for (var y = 0; y <= 1.0001; y += 0.02) { var p = toPx(SIM.pathX(m, y), y); if (y) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); } c.stroke(); c.setLineDash([]); });
      c.textAlign = "left";
      runs.forEach(function (r, k) {
        var n = Math.min(r.xs.length - 1, Math.floor(tNow)), fin = n >= r.xs.length - 1;
        c.strokeStyle = fin ? colOf(r, P) : P["ink-2"]; c.globalAlpha = k === 0 ? 1 : 0.6; c.lineWidth = k === 0 ? 2.5 : 1.5;
        c.beginPath(); for (var j = 0; j <= n; j++) { var p = toPx(r.xs[j][0], r.xs[j][1]); if (j) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); } c.stroke();
        var e = toPx(r.xs[n][0], r.xs[n][1]);
        if (fin && r.res !== "goal") { c.strokeStyle = P.bad; c.lineWidth = 2; c.beginPath(); c.moveTo(e[0] - 5, e[1] - 5); c.lineTo(e[0] + 5, e[1] + 5); c.moveTo(e[0] + 5, e[1] - 5); c.lineTo(e[0] - 5, e[1] + 5); c.stroke(); }
        else { c.fillStyle = fin ? colOf(r, P) : P.ink; c.beginPath(); c.arc(e[0], e[1], k === 0 ? 4.5 : 3, 0, Math.PI * 2); c.fill(); }
        c.globalAlpha = 1; c.lineWidth = 1;
        if (k === 0 && !fin) { /* the chunk rollout 1 is executing */
          var qq = null; r.queries.forEach(function (x) { if (x.t <= n) qq = x; });
          if (qq && qq.plan) { c.strokeStyle = P.accent; c.lineWidth = 2; c.setLineDash([2, 3]); c.beginPath(); var s0 = toPx(r.xs[qq.t][0], r.xs[qq.t][1]); c.moveTo(s0[0], s0[1]); qq.plan.forEach(function (pp) { var z = toPx(pp[0], pp[1]); c.lineTo(z[0], z[1]); }); c.stroke(); c.setLineDash([]); c.lineWidth = 1; }
        }
      });
      var s = toPx(0, 0); c.fillStyle = P.ink; c.beginPath(); c.arc(s[0], s[1], 6, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-2"]; c.font = font("600", 12, "body"); c.fillText("start", s[0] + 10, s[1] + 4);
      c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.fillText("t = " + Math.min(Math.floor(tNow), maxT), 10, 18);
    }

    /* ---- denoiser view: 16 chunks from the start state ---- */
    function makeDen() {
      var R = RB.rng(st.seed * 7 + 11), out = [];
      for (var i = 0; i < 16; i++) out.push(SIM.sampleChunk(st.head, 0, 0, st.H, st.K, st.eps, R, true));
      den = out; denK = den[0].path.length - 1;
    }
    function drawDen() {
      if (dead || !den) return;
      var P = RB.pal(), c = RB.canvas(dn, DW, DH), H = st.H, steps = den[0].path.length - 1, k = Math.min(denK, steps);
      c.fillStyle = P.surface; c.fillRect(0, 0, DW, DH);
      var cum = function (u) { var x = 0, o = [[0, 0]]; for (var j = 0; j < u.length; j++) { x += u[j] * SIM.VC; o.push([x, (j + 1) * SIM.V]); } return o; };
      var ref = den[0].mus.map(cum), span = 0.04; ref.forEach(function (p) { p.forEach(function (z) { span = Math.max(span, Math.abs(z[0]) * 1.25); }); });
      var yMax = H * SIM.V, px = function (z) { return [DW / 2 + z[0] / span * (DW / 2 - 24), DH - 26 - z[1] / yMax * (DH - 58)]; };
      c.strokeStyle = P["bench-grid"] || P.line; c.beginPath(); c.moveTo(DW / 2, 30); c.lineTo(DW / 2, DH - 26); c.stroke();
      ref.forEach(function (p) { c.strokeStyle = P["ink-3"]; c.setLineDash([5, 5]); c.beginPath(); p.forEach(function (z, j) { var q2 = px(z); if (j) c.lineTo(q2[0], q2[1]); else c.moveTo(q2[0], q2[1]); }); c.stroke(); c.setLineDash([]); });
      c.save(); c.beginPath(); c.rect(0, 24, DW, DH - 24); c.clip();
      den.forEach(function (d) {
        var u = d.path[k], p = cum(u), fin = k === steps;
        c.strokeStyle = fin ? (d.mode === 0 ? P["data-1"] : d.mode === 1 ? P["data-2"] : P.bad) : P["ink-2"]; c.globalAlpha = fin ? 0.85 : 0.5; c.lineWidth = 1.5;
        c.beginPath(); p.forEach(function (z, j) { var q2 = px(z); if (j) c.lineTo(q2[0], q2[1]); else c.moveTo(q2[0], q2[1]); }); c.stroke();
        var e = px(p[p.length - 1]); c.fillStyle = c.strokeStyle; c.beginPath(); c.arc(e[0], e[1], 3, 0, Math.PI * 2); c.fill();
      });
      c.restore(); c.globalAlpha = 1;
      c.fillStyle = P.ink; c.beginPath(); var s = px([0, 0]); c.arc(s[0], s[1], 4, 0, Math.PI * 2); c.fill();
      c.fillStyle = P["ink-2"]; c.font = font("600", 14, "body"); c.textAlign = "left";
      var lab = st.head === "mse" ? "mean chunk (no sampling)" : st.head === "cvae" ? (k ? "decoded from z" : "style z") : st.head === "one" ? (k ? "one call" : "noise") : "step " + k + " of " + steps + (st.head === "fm" || st.head === "fmb" ? " · τ = " + RB.fmt(k / steps, 2) : "");
      c.fillText(lab, 10, 18);
      c.fillStyle = P["ink-3"]; c.font = font("500", 13, "mono"); c.textAlign = "right"; c.fillText("H = " + H + " steps ahead", DW - 10, 18); c.textAlign = "left";
    }

    /* ---- timeline of rollout 1 ---- */
    function drawTL() {
      if (dead) return;
      var P = RB.pal(), c = RB.canvas(tl, TW, TH), r = runs[0];
      c.fillStyle = P.surface; c.fillRect(0, 0, TW, TH);
      var sx = function (t) { return 14 + t / SIM.TMAX * (TW - 28); };
      c.strokeStyle = P["line-strong"]; c.beginPath(); c.moveTo(sx(0), 62); c.lineTo(sx(SIM.TMAX), 62); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = font("500", 13, "mono");
      [0, 20, 40, 60].forEach(function (t) { c.textAlign = "center"; c.fillText(String(t), sx(t), 79); });
      c.textAlign = "left"; c.fillText("control step t", sx(0), 92);
      if (!r) return;
      var n = Math.floor(tNow);
      r.queries.forEach(function (qq) {
        if (qq.t > n) return;
        c.fillStyle = qq.mode === 0 ? P["data-1"] : qq.mode === 1 ? P["data-2"] : P.bad;
        var x0 = sx(qq.t), x1 = sx(Math.min(qq.t + qq.len, r.steps)); c.fillRect(x0, 34, Math.max(1.5, x1 - x0 - 1), 22);
      });
      c.strokeStyle = P.accent; c.lineWidth = 2; c.beginPath(); c.moveTo(sx(Math.min(n, r.steps)), 28); c.lineTo(sx(Math.min(n, r.steps)), 62); c.stroke(); c.lineWidth = 1;
      c.fillStyle = P["ink-2"]; c.font = font("600", 14, "body"); c.fillText(r.queries.filter(function (qq) { return qq.t <= n; }).length + " queries so far", sx(0), 20);
    }

    function stats() {
      var n = runs.length, g = 0, h = 0, L = 0, Rr = 0, sw = 0, calls = 0, jerk = 0, nf = SIM.nfe(st.head, st.K);
      runs.forEach(function (r) { if (r.res === "goal") { g++; if (r.side === 0) L++; else Rr++; } if (r.res === "hit") h++; sw += r.switches; calls += r.queries.length * nf; jerk += r.jerk; });
      RB.setRO(sc, "goal", g + " of " + n); RB.setRO(sc, "hit", h + " of " + n); RB.setRO(sc, "lr", L + " / " + Rr);
      RB.setRO(sc, "sw", RB.fmt(sw / n, 1)); RB.setRO(sc, "nfe", String(nf)); RB.setRO(sc, "calls", String(Math.round(calls / n)));
      RB.setRO(sc, "lat", RB.fmt(nf * MS_PER_CALL, 1)); RB.setRO(sc, "jerk", RB.fmt(jerk / n * 1000, 1));
    }
    function frame(ts) {
      if (dead) return;
      if (!t0) t0 = ts;
      tNow = (ts - t0) / 1000 * 30; /* 30 control steps per second of animation */
      if (tNow >= maxT) { tNow = maxT; done = true; }
      drawField(); drawTL();
      if (done) { stats(); api.live("paused", "Done · " + runs.filter(function (r) { return r.res === "goal"; }).length + " of " + runs.length + " reached the goal"); raf = 0; return; }
      api.live("running", "Rolling out · t = " + Math.floor(tNow));
      raf = requestAnimationFrame(frame);
    }
    function opts(o) { return { head: st.head, K: st.K, H: st.H, exec: st.exec, m: st.m, dist: st.dist, eps: st.eps, shove: st.shove, plans: !!(o && o.plans) }; }
    function run(animate) {
      if (dead) return;
      runs = SIM.batch(opts({ plans: true }), NROLL, st.seed);
      maxT = runs.reduce(function (a, r) { return Math.max(a, r.xs.length - 1); }, 1);
      note.textContent = HEAD_NOTE[st.head];
      q("#" + id + "-k").disabled = SIM.nfe(st.head, 2) === 1;
      q("#" + id + "-m").disabled = st.exec !== "ens";
      api.meta(HEAD_NAME[st.head] + " · " + NROLL + " rollouts · seed " + st.seed);
      makeDen(); drawDen();
      if (raf) cancelAnimationFrame(raf);
      done = false; t0 = 0;
      if (animate === false) { tNow = maxT; done = true; drawField(); drawTL(); stats(); api.live("paused", "Ready"); }
      else raf = requestAnimationFrame(frame);
      clearTimeout(chartT); chartT = setTimeout(chart, 60);
    }

    /* ---- sweep chart: success against chunk size ---- */
    function chart() {
      if (dead) return;
      var host = q("#" + id + "-chart"), Hs = [1, 2, 4, 8, 12, 16, 24, 32], mk = function (over) {
        return Hs.map(function (H) { var o = opts(); Object.keys(over).forEach(function (k) { o[k] = over[k]; }); o.H = H; var b = SIM.batch(o, 24, 500 + st.seed); return [H, b.filter(function (r) { return r.res === "goal"; }).length / b.length]; });
      };
      var series = [
        { name: "All H", color: "data-1", points: mk({ exec: "all" }) },
        { name: "Ensemble", color: "data-3", points: mk({ exec: "ens" }), dash: true }
      ];
      if (st.head !== "mse") series.push({ name: "Regression",  color: "data-5", points: mk({ exec: "all", head: "mse" }) });
      host.innerHTML = "";
      StudyBench.lineChart(host, { title: HEAD_NAME[st.head] + ": success against chunk size", x: { label: "Chunk size H", min: 1, max: 32, ticks: [1, 8, 16, 24, 32] }, y: { label: "Reached the goal", min: 0, max: 1, ticks: [0, 0.25, 0.5, 0.75, 1], fmt: function (v) { return Math.round(v * 100) + "%"; } }, series: series, height: 220, caption: "Our toy numbers for the current head: 24 seeded rollouts per point. Compare All H with Ensemble as H grows. ACT reports 1% to 44% for chunk size 1 to 100 (X2 §4.2)." });
    }

    /* ---- wiring ---- */
    function setSeg(sid, v) { RB.$$("#" + sid + " button", ct).forEach(function (b) { b.setAttribute("aria-pressed", b.value === v ? "true" : "false"); }); }
    function setSlider(sid, v, fmt) { var inp = q("#" + sid), out = ct.querySelector('[data-out="' + sid + '"]'); inp.value = v; if (out) out.textContent = fmt ? fmt(v) : v; }
    /* segmented controls: accept either (value, button) or (button) from StudyBench.segmented */
    function bindSeg(sid, cb) { StudyBench.segmented(ct.querySelector("#" + sid), function (a, b) { cb(b ? b.value : (a && a.value) || a); }); }
    function manual() { st.preset = null; setSeg(id + "-pre", "__none"); }
    bindSeg(id + "-pre", function (v) {
      var p = PRESETS[v]; if (!p) return;
      st.head = p.head; st.K = p.K; st.H = p.H; st.exec = p.exec; st.preset = v;
      setSeg(id + "-head", p.head); setSeg(id + "-exec", p.exec); setSlider(id + "-k", p.K); setSlider(id + "-h", p.H);
      run();
    });
    bindSeg(id + "-head", function (v) { st.head = v; manual(); run(); });
    bindSeg(id + "-exec", function (v) { st.exec = v; manual(); run(); });
    RB.bindSlider(ct, id + "-k", null, function (v) { st.K = v; manual(); run(); });
    RB.bindSlider(ct, id + "-h", null, function (v) { st.H = v; manual(); run(); });
    RB.bindSlider(ct, id + "-m", f2, function (v) { st.m = v; run(); });
    RB.bindSlider(ct, id + "-dist", f1, function (v) { st.dist = v; run(); });
    RB.bindSlider(ct, id + "-eps", f2, function (v) { st.eps = v; run(); });
    q("#" + id + "-shove").addEventListener("change", function (e) { st.shove = e.target.checked; run(); });
    q("#" + id + "-run").addEventListener("click", function () { run(); });
    q("#" + id + "-seed").addEventListener("click", function () { st.seed++; run(); });
    q("#" + id + "-step").addEventListener("click", function () { var n = den ? den[0].path.length - 1 : 0; denK = denK >= n ? 0 : denK + 1; stepped++; drawDen(); });
    RB.onTheme(function () { if (dead || !document.contains(cv)) return; drawField(); drawDen(); drawTL(); });

    /* side panel: reference numbers from the method papers */
    if (api.side) {
      api.side.style.minWidth = "0";
      api.side.innerHTML = '<p class="rb-h5">Reference numbers</p>' + [
        ["ACT chunking", "1% success at chunk 1, 44% at chunk 100", "arXiv 2304.13705"], ["ACT without CVAE", "35.3% → 2% on human data", "arXiv 2304.13705"], ["ACT ensembling", "+3.3% success; π0 found it hurt", "arXiv 2304.13705 · 2410.24164"],
        ["Diffusion Policy", "100 DDPM steps in simulation, 16 DDIM on the robot; runs 8 of 16 actions", "arXiv 2303.04137"], ["π0", "chunk of 50, 10 Euler steps, 73 ms per chunk", "arXiv 2410.24164"],
        ["Consistency Policy", "1 ms for one step; DDIM 15 steps 11 ms; DDPM 100 steps 110 ms", "arXiv 2405.07503"], ["OneDP", "7 ms for one step; DDIM 10 steps 66 ms; DDPM 100 steps 660 ms", "arXiv 2410.21257"]
      ].map(function (r) { return '<p class="sb-caption"><b>' + r[0] + "</b>: " + r[1] + ' <span class="sb-ref">' + r[2] + "</span></p>"; }).join("");
    }

    run(false);

    return {
      state: function () { return st; },
      demo: function () {
        var pre = function (v) { return q("#" + id + "-pre [value=\"" + v + "\"]"); }, hb = function (v) { return q("#" + id + "-head [value=\"" + v + "\"]"); };
        var fin = function (a) { return a.until(function () { return done; }, 8000); };
        return [
          { target: q("#" + id + "-pre"), title: "Regression, one step", text: "Per-step behavior cloning regresses one action each step. Noise pushes most rollouts off the centerline, and feedback then follows the nearer demonstration.", do: function (a) { return a.click(pre("bc")).then(function () { return fin(a); }); }, task: "Choose the Per-step BC preset", expect: function () { return st.preset === "bc"; } },
          { target: q("#" + id + "-h"), title: "Regressed chunks hit", text: "With chunks of 8, regression commits to the mean plan for 8 steps. The mean of left and right goes into the block.", do: function (a) { return a.set(q("#" + id + "-h"), 8).then(function () { return fin(a); }); }, task: "Set Chunk size H to 8 or more", expect: function () { return st.head === "mse" && st.H >= 8; } },
          { target: q("#" + id + "-head"), title: "Flow picks a side", text: "A flow head samples a whole chunk. Each rollout commits to left or right, so almost all reach the goal.", do: function (a) { return a.click(hb("fm")).then(function () { return fin(a); }); }, task: "Choose the Flow head", expect: function () { return st.head === "fm"; } },
          { target: q("#" + id + "-step"), title: "Step the denoiser", text: "The right panel shows sixteen chunks at the start. Step from noise: the chunks split into the two plans over K steps.", do: function (a) { var b = q("#" + id + "-step"); b.click(); return a.wait(500).then(function () { b.click(); return a.wait(500); }).then(function () { b.click(); return a.wait(500); }); }, task: "Press Step denoiser a few times", expect: function () { return stepped >= 2; } },
          { target: q("#" + id + "-k"), title: "One step is the mean", text: "With K = 1 the only Euler step points at the mean, so every chunk lands between the plans and hits the block.", do: function (a) { return a.set(q("#" + id + "-k"), 1).then(function () { return fin(a); }); }, task: "Set Steps K to 1", expect: function () { return st.K === 1; } },
          { target: q("#" + id + "-exec"), title: "Ensembling mixes modes", text: "Back at K = 10, ensembling averages chunks that may plan different sides. Watch side switches rise; π0 found ensembling hurt.", do: function (a) { return a.set(q("#" + id + "-k"), 10).then(function () { return a.click(q("#" + id + "-exec [value=\"ens\"]")); }).then(function () { return fin(a); }); }, task: "Choose Ensemble execution", expect: function () { return st.exec === "ens"; } },
          { target: q("#" + id + "-pre"), title: "Your turn", text: "Try the Diffusion Policy preset, then tick Shove at step 15. Compare how fast chunks of 16 and chunks of 4 recover." }
        ];
      },
      destroy: function () { dead = true; if (raf) cancelAnimationFrame(raf); raf = 0; clearTimeout(chartT); }
    };
  }


  RB.station({
    id: "heads", name: "Policy head bench", sub: "05 · 06",
    refs: ["X2 eq. 18, 44–53", "X2 §4.2–4.3", "ACT, arXiv 2304.13705"], prov: "Simplified: exact 2-D toy scores, no network",
    summary: "Seven policy heads drive the same robot past a block that demonstrators pass on either side. Change the head, the sampling steps, the chunk size and the execution scheme, and watch rollouts succeed, dither or crash.",
    notice: [
      "Regressed chunks aim at the mean of left and right, which is the block.",
      "Sampling heads need a few steps: with K = 1 flow and diffusion also return the mean.",
      "Chunk size 1 lets a sampling head change sides every step; longer chunks commit to one plan.",
      "Ensembling averages chunks that may plan different sides, so it can reintroduce mode averaging.",
      "Network calls per chunk set latency: K for DDPM, DDIM and flow, one for the rest."
    ],
    card: "Pick a head, step its denoiser, and watch chunked rollouts pass a block or crash into it.",
    ledger: [
      { where: "Lab · Policy head bench", source: "Real heads are neural networks trained on demonstrations", page: "The bench uses the exact noise and velocity of a two-mode Gaussian chunk distribution, softened by a model-error temperature", why: "Isolates what the head and sampler do; the model error stands in for an imperfect network.", kind: "Simplified" },
      { where: "Lab · Policy head bench", source: "X2 Fig. 20 describes compounding error qualitatively", page: "Each policy query adds one lateral error that grows with the distance from the demonstrations", why: "A minimal mechanism for covariate shift, so chunk size matters.", kind: "Our choice" },
      { where: "Lab · Policy head bench", source: "X2 eq. 52 writes τ ∼ Beta over [0, s] with shape (1.5, 1) and says it favors noisier chunks", page: "With τ = 0 as noise, the bench uses a training density proportional to √((s − τ)/s), s = 0.999", why: "Keeps the stated emphasis on noisy τ in the site's convention.", kind: "Our choice" },
      { where: "Lab · Policy head bench", source: "Robot actions are multi-dimensional", page: "The robot moves up at fixed speed; heads generate lateral velocities only", why: "One dimension per step keeps the sampling paths drawable.", kind: "Simplified" },
      { where: "Lab · Policy head bench", source: "ACT sets z = 0 at test time", page: "The CVAE head samples z ∼ 𝒩(0, 1)", why: "In this symmetric toy z = 0 sits exactly between the two modes.", kind: "Our choice" },
      { where: "Lab · Policy head bench", source: "Consistency Policy is distilled from a diffusion teacher", page: "The one-step head returns the endpoint of the 32-step flow teacher plus small noise", why: "An ideal distillation; real students lose a little quality.", kind: "Simplified" },
      { where: "Lab · Policy head bench", source: "Diffusion Policy Table 7 lists 16 DDIM steps on the robot; its §3.4 cites 10 steps for 0.1 s latency", page: "The Diffusion Policy preset uses 16 steps", why: "The table is the deployed setting.", kind: "Sources disagree" },
      { where: "Lab · Policy head bench", source: "Consistency Policy: DDPM with 100 steps takes 110 ms on an NVIDIA P5000", page: "Latency = network calls × 1.1 ms, ignoring the encoder", why: "Shows how latency scales with calls, not absolute speed.", kind: "Our choice" }
    ],
    mount: mount
  });
})();
