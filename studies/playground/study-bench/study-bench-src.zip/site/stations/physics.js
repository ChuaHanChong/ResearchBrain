/* Interactive Lab · Physics-prior station (topic 20). Sources: P11 §3.1–3.2 (eq. 1–6: Lagrangian, Cholesky mass matrix,
   Hamilton's equations), P11 §3.4 (eq. 8: ResNet as Euler step; VINs and symplectic integrators), P11 Table 7 (trade-offs),
   P11 §8 Direction 6 (low-DoF validation). Method cards: DeLaN (1907.04490), HNN (1906.01563), LNN (2003.04630), VIN (1910.09349).
   Two benches on one pendulum (m l² = 1, g/l = 9.81 s⁻²):
   1. Learned models: a black-box regressor, a DeLaN-style energy model and an HNN-style Hamiltonian are fit by least squares on
      fixed features from noisy, torque-excited samples inside a data box, then released unforced and rolled out.
   2. Integrators: the true pendulum stepped with explicit Euler, RK4, symplectic Euler and Störmer–Verlet.
   Every number drawn is computed here; paper numbers appear only in the side panel with their refs. */
(function () {
  "use strict";
  var RB = window.RB;
  var SID = "physics", W2 = 9.81, QBOX = 2.2, FRIC = 0.4, TAUMAX = 3;

  function font(kind) { return getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body") || "sans-serif"; }
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function pressSeg(root, id, v) { RB.$$("#" + id + " button", root).forEach(function (b) { var on = b.value === v; b.setAttribute("aria-pressed", on ? "true" : "false"); b.tabIndex = on ? 0 : -1; }); }
  function wrap(a) { return Math.atan2(Math.sin(a), Math.cos(a)); }
  function energy(q, v) { return 0.5 * v * v + W2 * (1 - Math.cos(q)); }
  function pct(v) { if (!isFinite(v)) return "–"; if (Math.abs(v) >= 999.5) return v > 0 ? "> +999%" : "< −999%"; return (v >= 0 ? "+" : "−") + Math.abs(v).toFixed(Math.abs(v) < 10 ? 1 : 0) + "%"; }

  /* ---------- least squares with a small ridge (Gaussian elimination, partial pivoting) ---------- */
  function lsq(rows, ys, ridge) {
    var n = rows[0].length, A = [], b = [], i, j, k;
    for (i = 0; i < n; i++) { A.push(new Array(n).fill(0)); b.push(0); }
    rows.forEach(function (r, m) { for (i = 0; i < n; i++) { b[i] += r[i] * ys[m]; for (j = 0; j < n; j++) A[i][j] += r[i] * r[j]; } });
    for (i = 0; i < n; i++) A[i][i] += ridge;
    for (i = 0; i < n; i++) {
      var p = i; for (k = i + 1; k < n; k++) if (Math.abs(A[k][i]) > Math.abs(A[p][i])) p = k;
      var t = A[i]; A[i] = A[p]; A[p] = t; var tb = b[i]; b[i] = b[p]; b[p] = tb;
      for (k = i + 1; k < n; k++) { var f = A[k][i] / A[i][i]; for (j = i; j < n; j++) A[k][j] -= f * A[i][j]; b[k] -= f * b[i]; }
    }
    var x = new Array(n).fill(0);
    for (i = n - 1; i >= 0; i--) { var s = b[i]; for (j = i + 1; j < n; j++) s -= A[i][j] * x[j]; x[i] = s / A[i][i]; }
    return x;
  }
  function dot(a, b) { var s = 0; for (var i = 0; i < a.length; i++) s += a[i] * b[i]; return s; }

  /* ---------- data: torque-excited samples inside the box |q| ≤ 2.2, |q̇| ≤ vmax ---------- */
  function makeData(n, vmax, fric, seed) {
    var R = RB.rng(seed), out = [];
    for (var i = 0; i < n; i++) {
      var q = -QBOX + 2 * QBOX * R(), v = -vmax + 2 * vmax * R(), tau = -TAUMAX + 2 * TAUMAX * R();
      var a = tau - W2 * Math.sin(q) - (fric ? FRIC : 0) * v;
      out.push({ q: q, v: v, tau: tau, vm: v + 0.05 * R.normal(), am: a + 0.3 * R.normal() });
    }
    return out;
  }

  /* ---------- three learned models; each returns a vector field on (q, y) and a velocity map ---------- */
  /* Black box ("MLP"): radial basis functions over the data box, plus 1, q, q̇ and a linear torque input */
  function fitMLP(data, vmax) {
    var sq = 2 * QBOX / 5, sv = 2 * vmax / 5;
    function feat(q, v, tau) {
      var f = [1, q, v, tau];
      for (var i = 0; i < 6; i++) for (var j = 0; j < 6; j++) { var dq = (q + QBOX - i * sq) / sq, dv = (v + vmax - j * sv) / sv; f.push(Math.exp(-0.5 * (dq * dq + dv * dv))); }
      return f;
    }
    var w = lsq(data.map(function (d) { return feat(d.q, d.vm, d.tau); }), data.map(function (d) { return d.am; }), 1e-3);
    var acc = function (q, v, tau) { return dot(w, feat(q, v, tau || 0)); };
    return { acc: acc, f: function (q, y) { return [y, acc(q, y, 0)]; }, vel: function (q, y) { return y; }, damp: null };
  }
  /* DeLaN-style: m(q) and U(q) from q only; inverse dynamics τ = m q̈ + ½ m′ q̇² + U′ (+ d q̇) is linear in the weights */
  var PHI = [function (q) { return [1, 0]; }, function (q) { return [Math.cos(q), -Math.sin(q)]; }, function (q) { return [Math.sin(q), Math.cos(q)]; }, function (q) { return [Math.cos(2 * q), -2 * Math.sin(2 * q)]; }, function (q) { return [Math.sin(2 * q), 2 * Math.cos(2 * q)]; }];
  var DU = [function (q) { return -Math.sin(q); }, function (q) { return Math.cos(q); }, function (q) { return -2 * Math.sin(2 * q); }, function (q) { return 2 * Math.cos(2 * q); }];
  function fitDeLaN(data, diss) {
    var rows = data.map(function (d) {
      var r = PHI.map(function (p) { var m = p(d.q); return m[0] * d.am + 0.5 * m[1] * d.vm * d.vm; }).concat(DU.map(function (u) { return u(d.q); }));
      if (diss) r.push(d.vm); return r;
    });
    var w = lsq(rows, data.map(function (d) { return d.tau; }), 1e-6), dd = diss ? w[9] : 0;
    if (dd < 0) { w = lsq(rows.map(function (r) { return r.slice(0, 9); }), data.map(function (d) { return d.tau; }), 1e-6); dd = 0; }
    function mm(q) { var m = 0, dm = 0; PHI.forEach(function (p, k) { var z = p(q); m += w[k] * z[0]; dm += w[k] * z[1]; }); return [Math.max(0.05, m), m < 0.05 ? 0 : dm]; }
    function du(q) { var s = 0; DU.forEach(function (u, k) { s += w[5 + k] * u(q); }); return s; }
    var acc = function (q, v, tau) { var m = mm(q); return ((tau || 0) - 0.5 * m[1] * v * v - du(q) - dd * v) / m[0]; };
    return { acc: acc, f: function (q, y) { return [y, acc(q, y, 0)]; }, vel: function (q, y) { return y; }, damp: diss ? dd : null, m0: mm(0)[0] };
  }
  /* HNN-style: ℋ(q, p) = Σ c_k χ_k(q, p); q̇ = ∂ℋ/∂p, ṗ = −∂ℋ/∂q − d ∂ℋ/∂p + τ. Each χ_k listed as [∂/∂q, ∂/∂p]. */
  var CHI = [
    function (q, p) { return [0, 1]; }, function (q, p) { return [-p * Math.sin(q), Math.cos(q)]; }, function (q, p) { return [p * Math.cos(q), Math.sin(q)]; },
    function (q, p) { return [0, p]; }, function (q, p) { return [-0.5 * p * p * Math.sin(q), p * Math.cos(q)]; }, function (q, p) { return [0.5 * p * p * Math.cos(q), p * Math.sin(q)]; },
    function (q, p) { return [0, p * p * p / 10]; },
    function (q, p) { return [-Math.sin(q), 0]; }, function (q, p) { return [Math.cos(q), 0]; }, function (q, p) { return [-2 * Math.sin(2 * q), 0]; }, function (q, p) { return [2 * Math.cos(2 * q), 0]; }
  ];
  function fitHNN(data, diss) {
    var rows = [], ys = [];
    data.forEach(function (d) {
      var g = CHI.map(function (c) { return c(d.q, d.vm); });
      rows.push(g.map(function (z) { return z[1]; }).concat(diss ? [0] : [])); ys.push(d.vm);                 /* q̇ = ∂ℋ/∂p */
      rows.push(g.map(function (z) { return -z[0]; }).concat(diss ? [-d.vm] : [])); ys.push(d.am - d.tau);    /* ṗ − τ = −∂ℋ/∂q − d q̇ */
    });
    var c = lsq(rows, ys, 1e-6), dd = diss ? c[CHI.length] : 0;
    if (dd < 0) { c = lsq(rows.map(function (r) { return r.slice(0, CHI.length); }), ys, 1e-6); dd = 0; }
    function grad(q, p) { var gq = 0, gp = 0; for (var k = 0; k < CHI.length; k++) { var z = CHI[k](q, p); gq += c[k] * z[0]; gp += c[k] * z[1]; } return [gq, gp]; }
    return { f: function (q, y) { var g = grad(q, y); return [g[1], -g[0] - dd * g[1]]; }, vel: function (q, y) { return grad(q, y)[1]; }, acc: function (q, v, tau) { return -grad(q, v)[0] - dd * v + (tau || 0); }, damp: diss ? dd : null };
  }
  function realSys(fric) { var b = fric ? FRIC : 0; return { f: function (q, y) { return [y, -W2 * Math.sin(q) - b * y]; }, vel: function (q, y) { return y; } }; }

  /* ---------- integrators on a vector field f(q, y) → [q̇, ẏ] ---------- */
  var STEP = {
    euler: function (f, q, y, h) { var k = f(q, y); return [q + h * k[0], y + h * k[1]]; },
    rk4: function (f, q, y, h) {
      var a = f(q, y), b = f(q + 0.5 * h * a[0], y + 0.5 * h * a[1]), c = f(q + 0.5 * h * b[0], y + 0.5 * h * b[1]), d = f(q + h * c[0], y + h * c[1]);
      return [q + h / 6 * (a[0] + 2 * b[0] + 2 * c[0] + d[0]), y + h / 6 * (a[1] + 2 * b[1] + 2 * c[1] + d[1])];
    },
    symp: function (f, q, y, h) { var y1 = y + h * f(q, y)[1]; return [q + h * f(q, y1)[0], y1]; },
    verlet: function (f, q, y, h) { var yh = y + 0.5 * h * f(q, y)[1], q1 = q + h * f(q, yh)[0]; return [q1, yh + 0.5 * h * f(q1, yh)[1]]; }
  };
  var INTS = [{ value: "euler", label: "Euler" }, { value: "rk4", label: "RK4" }, { value: "symp", label: "Symplectic Euler" }, { value: "verlet", label: "Verlet" }];
  var INT_NAME = { euler: "explicit Euler", rk4: "RK4", symp: "symplectic Euler", verlet: "Störmer–Verlet" };

  /* roll out from (q0, v0); samples every `every` seconds; stops (frozen) if the state blows up */
  function rollout(sys, method, q0, v0, h, T, every, sub) {
    var q = q0, y = v0, n = Math.round(T / h), stride = Math.max(1, Math.round(every / h)), out = [], dead = false, st = STEP[method], hs = h / (sub || 1);
    out.push({ t: 0, q: q, v: sys.vel(q, y) });
    for (var k = 1; k <= n; k++) {
      if (!dead) {
        var nq = q, ny = y;
        for (var s = 0; s < (sub || 1); s++) { var r = st(sys.f, nq, ny, hs); nq = r[0]; ny = r[1]; }
        if (!isFinite(nq) || !isFinite(ny) || Math.abs(ny) > 60) dead = k * h; else { q = nq; y = ny; }
      }
      if (k % stride === 0 || k === n) out.push({ t: k * h, q: q, v: sys.vel(q, y) });
    }
    out.dead = dead;
    return out;
  }

  var MODELS = [{ id: "mlp", name: "Black box", tag: "MLP-style", c: "data-1" }, { id: "delan", name: "DeLaN", tag: "M(q), U(q)", c: "data-2" }, { id: "hnn", name: "HNN", tag: "ℋ(q, p)", c: "data-4" }];
  var ICOL = { euler: "data-5", rk4: "data-1", symp: "data-2", verlet: "data-4" };

  var PRESETS = {
    inside: { bench: "models", label: "In data", N: 150, vmax: 4, q0: 1.2, dt: 0.01, T: 10, fric: false, diss: false, integ: "rk4",
      note: "Released at 1.2 rad, the real orbit stays inside the data box. All three models fit the samples, and all three predict the swing well." },
    extrap: { bench: "models", label: "Extrapolate", N: 150, vmax: 3, q0: 2.8, dt: 0.01, T: 10, fric: false, diss: false, integ: "rk4",
      note: "Released at 2.8 rad, the pendulum reaches about 6 rad/s, twice the fastest sample. DeLaN and HNN get velocity dependence from mechanics, so they extrapolate; the black box guesses (P11 §3.1.1)." },
    scarce: { bench: "models", label: "Scarce data", N: 15, vmax: 5, q0: 2, dt: 0.01, T: 10, fric: false, diss: false, integ: "rk4",
      note: "Fifteen samples: the black box has 40 weights and overfits the noise. The energy models have 9 and 11, and the structure does the rest. Try New data a few times." },
    friction: { bench: "models", label: "Friction", N: 150, vmax: 5, q0: 2, dt: 0.01, T: 10, fric: true, diss: false, integ: "rk4",
      note: "The real pendulum now loses energy. DeLaN and HNN conserve energy by construction, so they cannot fit it; the black box can. Tick Learn a damping term (P11 Table 7)." },
    coarse: { bench: "ints", label: "Coarse step", N: 150, vmax: 4, q0: 2, dt: 0.1, T: 30, fric: false, diss: false, integ: "euler",
      note: "The true pendulum, no learning. At Δt = 0.1 s explicit Euler gains energy every step and spirals out; symplectic Euler and Verlet keep a bounded energy error." },
    long: { bench: "ints", label: "Long horizon", N: 150, vmax: 4, q0: 2, dt: 0.15, T: 300, fric: false, diss: false, integ: "rk4",
      note: "Five minutes at Δt = 0.15 s. RK4 is more accurate per step, but its energy leaks away steadily. Verlet's energy error oscillates and stays bounded, so it ends closer (P11 §3.4)." }
  };
  var PKEYS = ["inside", "extrap", "scarce", "friction", "coarse", "long"];

  function mount(api) {
    var id = SID, scene = api.scene, ctl = api.controls;
    var st = { bench: "models", preset: "inside", N: 150, vmax: 4, q0: 1.2, dt: 0.01, T: 10, fric: false, diss: false, integ: "rk4", seed: 3 };
    var res = null, raf = 0, playT = null, runs = 0, ro = null, lastW = 0, chartT = 0, simT = 0, sweepCache = {};

    scene.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-pend" aria-label="Side-by-side pendulums, one per model or integrator, with an energy bar under each"></canvas>' +
      '<figcaption class="sb-caption" id="' + id + '-cap1">–</figcaption></figure>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-phase" aria-label="Phase plot of angle against angular velocity"></canvas>' +
      '<div id="' + id + '-leg"></div><figcaption class="sb-caption" id="' + id + '-cap2">–</figcaption></figure>' +
      '<div id="' + id + '-ro"></div>' +
      '<div class="rb-stack"><h4 class="rb-h5" id="' + id + '-tabT">–</h4><div class="sb-scroll-x" id="' + id + '-tab"></div><p class="sb-caption"><span class="sb-prov">Our toy numbers</span> Energy is the true pendulum energy of each predicted state, per unit m l².</p></div>' +
      '<div id="' + id + '-c1"></div><div id="' + id + '-c2"></div>';
    ctl.innerHTML =
      '<div class="rb-stack">' +
      '<div class="rb-row">' + RB.seg({ id: id + "-bench", label: "Bench", value: "models", options: [{ value: "models", label: "Learned models" }, { value: "ints", label: "Integrators" }] }) +
      RB.seg({ id: id + "-pre", label: "Preset", value: "inside", options: PKEYS.map(function (k) { return { value: k, label: PRESETS[k].label }; }) }) + "</div>" +
      '<div class="rb-row">' + RB.seg({ id: id + "-int", label: "Integrator", value: "rk4", options: INTS }) + "</div>" +
      '<div class="rb-row">' +
      RB.slider({ id: id + "-n", label: "Training samples N", min: 10, max: 300, step: 5, value: 150 }) +
      RB.slider({ id: id + "-vmax", label: "Data speed limit (rad/s)", min: 1, max: 8, step: 0.5, value: 4, fmt: function (v) { return (+v).toFixed(1); } }) +
      RB.slider({ id: id + "-q0", label: "Release angle (rad)", min: 0.2, max: 3, step: 0.1, value: 1.2, fmt: function (v) { return (+v).toFixed(1); } }) +
      RB.slider({ id: id + "-dt", label: "Step Δt (s)", min: 0.005, max: 0.2, step: 0.005, value: 0.01, fmt: function (v) { return (+v).toFixed(3); } }) +
      RB.slider({ id: id + "-T", label: "Horizon T (s)", min: 5, max: 300, step: 5, value: 10 }) + "</div>" +
      '<div class="rb-row"><label class="sb-field"><input type="checkbox" id="' + id + '-fric"> <span>Friction in the real pendulum</span></label>' +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-diss"> <span>Learn a damping term</span></label>' +
      '<button class="sb-btn" type="button" id="' + id + '-seed">New data</button>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Play ▶</button></div></div>';
    api.side.innerHTML = '<p class="rb-muted" id="' + id + '-note">–</p>' +
      RB.eqBlock({ name: "DeLaN on one joint", ref: "P11 eq. 3–4", tex: "\\class{sym-torque}{\\boldsymbol{\\tau}} = \\class{sym-M}{M(q)}\\,\\ddot{\\class{sym-qj}{q}} + \\tfrac{1}{2}\\class{sym-M}{M'(q)}\\,\\dot{\\class{sym-qj}{q}}^{2} + \\class{sym-Upot}{U'(q)}", words: "Only M and U are learned, from the angle alone. How torque depends on speed comes from mechanics.", key: ["torque", "M", "qj", { sym: "Upot", glyph: "U(q)", meaning: "potential energy" }] }) +
      RB.eqBlock({ name: "HNN dynamics", ref: "P11 eq. 6", tex: "\\dot{\\class{sym-qj}{q}} = \\frac{\\partial \\class{sym-Ham}{\\mathcal{H}}}{\\partial \\class{sym-pmom}{p}}, \\quad \\dot{\\class{sym-pmom}{p}} = -\\frac{\\partial \\class{sym-Ham}{\\mathcal{H}}}{\\partial \\class{sym-qj}{q}} + \\class{sym-torque}{\\boldsymbol{\\tau}}", words: "The network outputs one number, the energy. Motion is its symplectic gradient, so unforced motion keeps the learned energy.", key: ["qj", "Ham", { sym: "pmom", glyph: "p", meaning: "generalized momentum" }, "torque"] }) +
      RB.eqBlock({ name: "Symplectic Euler step", ref: "P11 §3.4", prov: "Standard form", tex: "\\begin{aligned} \\class{sym-pmom}{p}_{k+1} &= \\class{sym-pmom}{p}_k - \\Delta t\\,\\frac{\\partial \\class{sym-Ham}{\\mathcal{H}}}{\\partial \\class{sym-qj}{q}}(\\class{sym-qj}{q}_k) \\\\ \\class{sym-qj}{q}_{k+1} &= \\class{sym-qj}{q}_k + \\Delta t\\,\\class{sym-pmom}{p}_{k+1} \\end{aligned}", words: "Update momentum first, then position with the new momentum. Explicit Euler uses the old momentum, which pumps energy in.", key: [{ sym: "pmom", glyph: "p", meaning: "generalized momentum" }, { glyph: "Δt", meaning: "integration step" }, "Ham", "qj"] }) +
      '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
      '<li>HNN on a real pendulum: energy MSE 14 ± 5 against 390 ± 7 for a plain network (×10³); test loss 6.0 against 2.2, because the real pendulum has friction <span class="sb-ref">arXiv 1906.01563</span></li>' +
      '<li>LNN on a double pendulum: energy error 0.4% of the maximum potential energy, against 8% for an MLP at similar loss <span class="sb-ref">arXiv 2003.04630</span></li>' +
      '<li>VIN, pendulum from pixels, 5 s forecast: RMSE 3.4 ± 0.6 against 6.1 ± 0.2 for a residual RNN <span class="sb-ref">arXiv 1910.09349</span></li>' +
      '<li>DeLaN ran in a 500 Hz control loop, with the feed-forward torque updated at 200 Hz <span class="sb-ref">arXiv 1907.04490</span></li>' +
      '<li>71% of surveyed methods are physics-encoded; 17 papers test only canonical systems such as pendulums and cart-poles <span class="sb-ref">P11 §3 · §8</span></li></ul>';

    var cvP = scene.querySelector("#" + id + "-pend"), cvF = scene.querySelector("#" + id + "-phase");
    var roHost = scene.querySelector("#" + id + "-ro"), tabHost = scene.querySelector("#" + id + "-tab"), c1 = scene.querySelector("#" + id + "-c1"), c2 = scene.querySelector("#" + id + "-c2");
    var SL = { N: "-n", vmax: "-vmax", q0: "-q0", dt: "-dt", T: "-T" }, FMT = { N: String, vmax: function (v) { return (+v).toFixed(1); }, q0: function (v) { return (+v).toFixed(1); }, dt: function (v) { return (+v).toFixed(3); }, T: String };
    function setSlider(key, v) { var inp = ctl.querySelector("#" + id + SL[key]), out = ctl.querySelector('[data-out="' + id + SL[key] + '"]'); inp.value = v; if (out) out.textContent = FMT[key](v); }

    /* ----- compute everything for the current state ----- */
    function compute() {
      var every = Math.max(st.dt, st.T / 1200), E0 = energy(st.q0, 0), tracks = [];
      if (st.bench === "models") {
        var data = makeData(st.N, st.vmax, st.fric, st.seed);
        var fits = { mlp: fitMLP(data, st.vmax), delan: fitDeLaN(data, st.diss), hnn: fitHNN(data, st.diss) };
        var sub = Math.max(1, Math.round(st.dt / 0.005));
        var real = rollout(realSys(st.fric), "rk4", st.q0, 0, st.dt, st.T, every, sub);
        tracks.push({ id: "real", name: "Real pendulum", c: "data-3", dash: true, tr: real });
        MODELS.forEach(function (m) {
          var f = fits[m.id], se = 0;
          data.forEach(function (d) { var e = f.acc(d.q, d.vm, d.tau) - d.am; se += e * e; });
          var tr = rollout(f, st.integ, st.q0, 0, st.dt, st.T, every, 1);
          tracks.push({ id: m.id, name: m.name, tag: m.tag, c: m.c, tr: tr, fit: Math.sqrt(se / data.length), damp: f.damp, model: f });
        });
        var leave = null; real.some(function (s) { if (Math.abs(s.v) > st.vmax || Math.abs(wrap(s.q)) > QBOX) { leave = s.t; return true; } return false; });
        res = { bench: "models", data: data, tracks: tracks, E0: E0, leave: leave, real: real };
      } else {
        INTS.forEach(function (it) { tracks.push({ id: it.value, name: it.label, c: ICOL[it.value], tr: rollout(realSys(false), it.value, st.q0, 0, st.dt, st.T, every, 1) }); });
        res = { bench: "ints", tracks: tracks, E0: E0 };
      }
      /* per-track summary */
      var ref = res.bench === "models" ? res.tracks[0].tr : null;
      res.tracks.forEach(function (k) {
        var last = k.tr[k.tr.length - 1], em = 0, se = 0;
        k.tr.forEach(function (s, i) { var e = Math.abs(energy(s.q, s.v) - E0); if (e > em) em = e; if (ref && ref[i]) { var d = wrap(s.q - ref[i].q); se += d * d; } });
        k.dE = 100 * (energy(last.q, last.v) - E0) / E0; k.maxE = 100 * em / E0; k.rms = ref ? Math.sqrt(se / k.tr.length) : null;
      });
      summarize(); drawTable(); drawPend(); drawPhase();
    }

    function summarize() {
      var P = PRESETS[st.preset], ints = st.bench === "ints";
      document.getElementById(id + "-note").textContent = P ? P.note : (ints ? "Custom settings. All four integrators step the same ideal pendulum from the same release." : "Custom settings. The three models are refit whenever the data change.");
      scene.querySelector("#" + id + "-cap1").textContent = ints ? "One ideal pendulum, four integrators. Watch whether a bob swings higher or lower than its release, and read the energy bar under it." :
        "Each cell shows one learned model; the dashed ghost is the real pendulum. Watch whether the bob keeps up with its ghost and whether the energy bar stays at the tick.";
      scene.querySelector("#" + id + "-cap2").textContent = ints ? "A closed orbit means energy is kept. An outward spiral is energy gained, an inward spiral energy lost." :
        "Shaded box: where training samples lie. Follow each colored orbit after it leaves the box, compared with the dashed real orbit.";
      scene.querySelector("#" + id + "-leg").innerHTML = RB.legend(res.tracks.map(function (k) { return { c: k.c, label: k.name, kind: k.dash ? "dash" : "line" }; }).concat(ints ? [] : [{ c: "accent", label: "training data", kind: "area" }]));
      scene.querySelector("#" + id + "-tabT").textContent = ints ? "Energy kept by each integrator" : "How each learned model does";
      var E0 = res.E0;
      if (ints) {
        roHost.innerHTML = RB.readouts([{ id: "e0", k: "Energy at release", u: "J per kg·m²" }, { id: "steps", k: "Steps taken" }, { id: "sps", k: "Steps per small swing" }, { id: "best", k: "Smallest energy error" }]);
        RB.setRO(roHost, "e0", RB.fmt(E0, 2)); RB.setRO(roHost, "steps", String(Math.round(st.T / st.dt)));
        RB.setRO(roHost, "sps", RB.fmt(2 * Math.PI / Math.sqrt(W2) / st.dt, 0));
        var best = res.tracks.slice().sort(function (a, b) { return a.maxE - b.maxE; })[0]; RB.setRO(roHost, "best", best.name);
      } else {
        roHost.innerHTML = RB.readouts([{ id: "e0", k: "Energy at release", u: "J per kg·m²" }, { id: "vtop", k: "Top real speed", u: "rad/s" }, { id: "leave", k: "Leaves data box at", u: "s" }, { id: "n", k: "Training samples" }]);
        RB.setRO(roHost, "e0", RB.fmt(E0, 2));
        RB.setRO(roHost, "vtop", RB.fmt(res.real.reduce(function (a, s) { return Math.max(a, Math.abs(s.v)); }, 0), 1));
        RB.setRO(roHost, "leave", res.leave == null ? "never" : res.leave === 0 ? "at release" : RB.fmt(res.leave, 2));
        RB.setRO(roHost, "n", String(st.N));
      }
      api.meta("Δt = " + st.dt.toFixed(3) + " s · T = " + st.T + " s" + (ints ? " · ideal pendulum" : " · " + INT_NAME[st.integ] + (st.fric ? " · friction on" : "")));
      [["-n", ints], ["-vmax", ints], ["-seed", ints], ["-diss", ints], ["-fric", ints]].forEach(function (p) {
        var el = ctl.querySelector("#" + id + p[0]); if (!el) return;
        if (el.tagName === "DIV") RB.$$("button", el).forEach(function (b) { b.disabled = p[1]; }); else el.disabled = p[1];
      });
    }

    function drawTable() {
      var ints = res.bench === "ints";
      var head = ints ? "<tr><th scope=\"col\">Integrator</th><th scope=\"col\">Energy change at T</th><th scope=\"col\">Worst energy error</th><th scope=\"col\">Kind</th></tr>" :
        "<tr><th scope=\"col\">Model</th><th scope=\"col\">Fit error on data</th><th scope=\"col\">Energy change at T</th><th scope=\"col\">Angle error, RMS</th><th scope=\"col\">Damping</th></tr>";
      var KIND = { euler: "first order, not symplectic", rk4: "fourth order, not symplectic", symp: "first order, symplectic", verlet: "second order, symplectic" };
      var rows = res.tracks.filter(function (k) { return k.id !== "real"; }).map(function (k) {
        var cur = ints ? k.id === st.integ : false, sw = '<span class="sb-sw sb-sw--line" style="--c: var(--' + k.c + ')"></span> ';
        var dead = k.tr.dead ? ' <span class="rb-mono" style="color:var(--bad)">diverged at ' + RB.fmt(k.tr.dead, 1) + " s</span>" : "";
        if (ints) return "<tr" + (cur ? ' aria-current="true" style="background:var(--accent-soft)"' : "") + '><th scope="row">' + sw + k.name + '</th><td class="rb-mono">' + pct(k.dE) + dead + '</td><td class="rb-mono">' + pct(k.maxE).replace("+", "") + '</td><td style="white-space:nowrap">' + KIND[k.id] + "</td></tr>";
        return '<tr><th scope="row">' + sw + k.name + '<br><span class="rb-mono rb-muted">' + k.tag + '</span></th><td class="rb-mono">' + RB.fmt(k.fit, 2) + ' rad/s²</td><td class="rb-mono">' + pct(k.dE) + dead + '</td><td class="rb-mono">' + RB.fmt(k.rms, 2) + ' rad</td><td class="rb-mono">' + (k.damp == null ? (k.id === "mlp" ? "implicit" : "off") : RB.fmt(k.damp, 2) + " s⁻¹") + "</td></tr>";
      });
      if (!ints) rows.push('<tr><th scope="row"><span class="sb-sw sb-sw--dash" style="--c: var(--data-3)"></span> Real pendulum</th><td class="rb-mono">–</td><td class="rb-mono">' + pct(res.tracks[0].dE) + '</td><td class="rb-mono">0</td><td class="rb-mono">' + (st.fric ? FRIC.toFixed(2) + " s⁻¹ (true)" : "none") + "</td></tr>");
      tabHost.innerHTML = '<table class="sb-table sb-table--compact"><thead>' + head + "</thead><tbody>" + rows.join("") + "</tbody></table>";
    }

    /* ----- sample a track at time t ----- */
    function at(tr, t) {
      if (t == null) return tr[tr.length - 1];
      var lo = 0, hi = tr.length - 1; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (tr[m].t <= t) lo = m; else hi = m; }
      return tr[lo];
    }

    /* ----- pendulum strip ----- */
    function drawPend() {
      if (!res || !cvP.isConnected) return;
      var P = RB.pal(), W = Math.max(300, Math.min(760, cvP.parentNode.clientWidth || 640)), narrow = W < 520, H = narrow ? 206 : 236;
      var c = RB.canvas(cvP, W, H), mono = font("mono"), body = font("body"), items = res.tracks.filter(function (k) { return k.id !== "real"; });
      var n = items.length, cw = W / n, L = Math.min(cw * 0.36, narrow ? 44 : 62), py = 16 + L + 8, t = playT == null ? st.T : playT, E0 = res.E0;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      items.forEach(function (k, i) {
        var cx = cw * i + cw / 2, s = at(k.tr, t);
        if (i) { c.strokeStyle = P.line; c.lineWidth = 1; c.beginPath(); c.moveTo(cw * i, 8); c.lineTo(cw * i, H - 8); c.stroke(); }
        c.strokeStyle = P.line; c.setLineDash([2, 4]); c.beginPath(); c.arc(cx, py, L, 0, Math.PI * 2); c.stroke(); c.setLineDash([]);
        /* release height marker */
        var rx = cx + L * Math.sin(st.q0), ry = py + L * Math.cos(st.q0); c.fillStyle = P["ink-3"]; c.beginPath(); c.arc(rx, ry, 2.5, 0, Math.PI * 2); c.fill();
        c.strokeStyle = P["ink-3"]; c.lineWidth = 1; c.setLineDash([3, 3]); c.beginPath(); c.moveTo(cx - L - 4, ry); c.lineTo(cx + L + 4, ry); c.stroke(); c.setLineDash([]);
        /* trail: last second */
        c.strokeStyle = P[k.c]; c.globalAlpha = 0.35; c.lineWidth = 2; c.beginPath(); var on = false;
        k.tr.forEach(function (z) { if (z.t > t || z.t < t - 1) return; var x = cx + L * Math.sin(z.q), y = py + L * Math.cos(z.q); if (on) c.lineTo(x, y); else { c.moveTo(x, y); on = true; } }); c.stroke(); c.globalAlpha = 1;
        /* ghost of the real pendulum */
        if (res.bench === "models") {
          var g = at(res.tracks[0].tr, t), gx = cx + L * Math.sin(g.q), gy = py + L * Math.cos(g.q);
          c.strokeStyle = P["ink-3"]; c.lineWidth = 1.5; c.setLineDash([4, 3]); c.beginPath(); c.moveTo(cx, py); c.lineTo(gx, gy); c.stroke(); c.setLineDash([]);
          c.beginPath(); c.arc(gx, gy, 7, 0, Math.PI * 2); c.stroke();
        }
        var bx = cx + L * Math.sin(s.q), by = py + L * Math.cos(s.q);
        c.strokeStyle = P["ink-2"]; c.lineWidth = 2.5; c.beginPath(); c.moveTo(cx, py); c.lineTo(bx, by); c.stroke();
        c.fillStyle = P[k.c]; c.beginPath(); c.arc(bx, by, 8, 0, Math.PI * 2); c.fill();
        c.fillStyle = P.ink; c.beginPath(); c.arc(cx, py, 3, 0, Math.PI * 2); c.fill();
        /* label and energy bar */
        var yl = py + L + 26; c.textAlign = "center"; c.fillStyle = P.ink; c.font = "600 " + (narrow ? 11 : 12) + "px " + body;
        c.fillText(narrow && k.name === "Symplectic Euler" ? "Sympl. Euler" : k.name, cx, yl);
        var e = energy(s.q, s.v) / E0, bw = cw * 0.7, bx0 = cx - bw / 2, by0 = yl + 10;
        c.fillStyle = P["surface-sunk"]; c.fillRect(bx0, by0, bw, 10);
        c.fillStyle = Math.abs(e - 1) < 0.05 ? P.good : P.warn; c.fillRect(bx0, by0, bw * Math.min(1, e / 2), 10);
        c.fillStyle = P.ink; c.fillRect(bx0 + bw / 2 - 1, by0 - 3, 2, 16);
        c.fillStyle = P["ink-2"]; c.font = "500 10px " + mono; c.fillText("E " + pct(100 * (e - 1)), cx, by0 + 24);
        if (k.tr.dead && k.tr.dead <= t) { c.fillStyle = P.bad; c.fillText("diverged", cx, 12); }
      });
      c.textAlign = "left"; c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.fillText("t = " + RB.fmt(t, 1) + " s", 6, H - 6);
    }

    /* ----- phase plot ----- */
    function drawPhase() {
      if (!res || !cvF.isConnected) return;
      var P = RB.pal(), W = Math.max(300, Math.min(760, cvF.parentNode.clientWidth || 640)), narrow = W < 520, H = narrow ? 230 : 280, mono = font("mono");
      var c = RB.canvas(cvF, W, H), VM = Math.max(8, Math.ceil(res.tracks.reduce(function (a, k) { return k.tr.reduce(function (b, s) { return Math.max(b, Math.abs(s.v)); }, a); }, 0)) + 1);
      VM = Math.min(VM, 14);
      var l = 34, r = 10, tp = 10, bt = 24, X = function (q) { return l + (wrap(q) + Math.PI) / (2 * Math.PI) * (W - l - r); }, Y = function (v) { return tp + (H - tp - bt) / 2 - RB.clamp(v, -VM, VM) / VM * ((H - tp - bt) / 2); };
      var t = playT == null ? st.T : playT;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1; c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono;
      [-3, -2, -1, 0, 1, 2, 3].forEach(function (q) { var x = l + (q + Math.PI) / (2 * Math.PI) * (W - l - r); c.beginPath(); c.moveTo(x, tp); c.lineTo(x, H - bt); c.stroke(); c.textAlign = "center"; c.fillText(String(q), x, H - bt + 13); });
      var vt = VM > 10 ? 5 : 4; for (var v = -Math.floor(VM / vt) * vt; v <= VM; v += vt) { c.beginPath(); c.moveTo(l, Y(v)); c.lineTo(W - r, Y(v)); c.stroke(); c.textAlign = "right"; c.fillText(String(v), l - 4, Y(v) + 3); }
      c.textAlign = "center"; c.fillText("angle q (rad)", (l + W) / 2, H - 2); c.save(); c.translate(10, H / 2); c.rotate(-Math.PI / 2); c.fillText("q̇ (rad/s)", 0, 0); c.restore();
      if (res.bench === "models") {
        c.fillStyle = P["accent-soft"]; c.strokeStyle = P.accent; c.lineWidth = 1.5;
        var x0 = X(-QBOX), x1 = X(QBOX), y0 = Y(st.vmax), y1 = Y(-st.vmax); c.fillRect(x0, y0, x1 - x0, y1 - y0); c.strokeRect(x0, y0, x1 - x0, y1 - y0);
        c.fillStyle = P["ink-3"]; res.data.forEach(function (d) { c.fillRect(X(d.q) - 1, Y(d.vm) - 1, 2, 2); });
      }
      res.tracks.forEach(function (k) {
        c.strokeStyle = P[k.c]; c.lineWidth = k.dash ? 2.2 : 1.6; c.setLineDash(k.dash ? [6, 4] : []); c.beginPath(); var prev = null;
        k.tr.forEach(function (s) { if (s.t > t) return; var x = X(s.q), y = Y(s.v); if (prev == null || Math.abs(wrap(s.q) - wrap(prev)) > Math.PI) c.moveTo(x, y); else c.lineTo(x, y); prev = s.q; });
        c.stroke(); c.setLineDash([]);
        var s = at(k.tr, t); c.fillStyle = P[k.c]; c.beginPath(); c.arc(X(s.q), Y(s.v), 4, 0, Math.PI * 2); c.fill();
      });
      c.textAlign = "left";
    }

    /* ----- charts ----- */
    function drawCharts() {
      if (!res) return;
      c1.innerHTML = ""; c2.innerHTML = "";
      var E0 = res.E0, ymax = Math.max(4, Math.ceil(E0 * 2 / 2) * 2), step = Math.max(1, Math.floor(res.tracks[0].tr.length / 240));
      var series = res.tracks.map(function (k) { return { name: k.name, color: k.c, dash: !!k.dash, points: k.tr.filter(function (s, i) { return i % step === 0; }).map(function (s) { return [+s.t.toFixed(2), Math.min(ymax, energy(s.q, s.v))]; }) }; });
      StudyBench.lineChart(c1, { title: "Energy over time", height: 220, directLabels: false, x: { label: "time (s)", min: 0, max: st.T }, y: { label: "energy (J per kg·m²)", min: 0, max: ymax, fmt: function (v) { return (+v).toFixed(1); } }, series: series,
        caption: res.bench === "ints" ? "The ideal pendulum keeps its energy, so a correct integrator draws a flat line at " + RB.fmt(E0, 1) + ". Values above " + ymax + " are clipped." : "A model that drifts up or down here will mispredict every later state. Values above " + ymax + " are clipped." });
      if (res.bench === "models") sweepModels(); else sweepSteps();
    }
    /* models: error against release speed, 5 s horizon, RK4 at 0.01 s for all (independent of the integrator choice) */
    function sweepModels() {
      var key = ["m", st.N, st.vmax, st.fric, st.diss, st.seed].join("|"), sw = sweepCache[key];
      if (!sw) {
        var data = res.data, fits = { mlp: fitMLP(data, st.vmax), delan: fitDeLaN(data, st.diss), hnn: fitHNN(data, st.diss) }, rs = realSys(st.fric);
        sw = MODELS.map(function (m) { return { name: m.name, color: m.c, points: [] }; });
        for (var v0 = 0; v0 <= 9.001; v0 += 0.5) {
          var ref = rollout(rs, "rk4", 0, v0, 0.01, 5, 0.05, 2);
          MODELS.forEach(function (m, j) {
            var tr = rollout(fits[m.id], "rk4", 0, v0, 0.01, 5, 0.05, 1), se = 0;
            tr.forEach(function (s, i) { var d = wrap(s.q - ref[i].q); se += d * d; });
            sw[j].points.push([+v0.toFixed(1), Math.min(Math.PI, Math.sqrt(se / tr.length))]);
          });
        }
        sweepCache = {}; sweepCache[key] = sw;
      }
      StudyBench.lineChart(c2, { title: "Angle error against release speed", height: 220, directLabels: false, x: { label: "release speed from q = 0 (rad/s)", min: 0, max: 9 }, y: { label: "angle error, RMS over 5 s (rad)", min: 0, max: 3.2, fmt: function (v) { return (+v).toFixed(1); } }, series: sw,
        caption: "Training data stop at " + st.vmax.toFixed(1) + " rad/s; compare the curves to the right of it. Near 6.3 rad/s the pendulum barely reaches the top, so small errors decide whether it flips. RK4, 0.01 s." });
    }
    /* integrators: worst relative energy error against step size, log scale, horizon min(T, 60) s */
    function sweepSteps() {
      var Th = Math.min(st.T, 60), key = ["i", st.q0, Th].join("|"), sw = sweepCache[key];
      if (!sw) {
        var rs = realSys(false), E0 = res.E0, DTS = [0.005, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.08, 0.1, 0.12, 0.15, 0.2];
        sw = INTS.map(function (it) { return { name: it.label, color: ICOL[it.value], points: [] }; });
        DTS.forEach(function (h) {
          INTS.forEach(function (it, j) {
            var tr = rollout(rs, it.value, st.q0, 0, h, Th, h, 1), em = 1e-12;
            tr.forEach(function (s) { em = Math.max(em, Math.abs(energy(s.q, s.v) - E0) / E0); });
            if (tr.dead) em = 100;
            sw[j].points.push([h, RB.clamp(Math.log10(em), -10, 2)]);
          });
        });
        sweepCache = {}; sweepCache[key] = sw;
      }
      StudyBench.lineChart(c2, { title: "Worst energy error against step size", height: 220, directLabels: false, x: { label: "step Δt (s)", min: 0, max: 0.2 }, y: { label: "energy error", min: -10, max: 2, ticks: [-10, -8, -6, -4, -2, 0, 2], fmt: function (v) { return "1e" + Math.round(v); } }, series: sw,
        caption: "Log scale, over the first " + Th + " s. Lower is better; 1e0 means the error equals the whole energy. Your step is " + st.dt.toFixed(3) + " s." });
    }
    function chartSoon() { clearTimeout(chartT); chartT = setTimeout(drawCharts, 120); }
    function computeSoon() { clearTimeout(simT); simT = setTimeout(function () { compute(); chartSoon(); }, 40); }

    /* ----- playback ----- */
    function stop() { if (raf) cancelAnimationFrame(raf); raf = 0; }
    function play() {
      stop(); var t0 = performance.now(), speed = Math.max(1, st.T / 8);
      api.live("running", "Playing at " + RB.fmt(speed, speed < 10 ? 1 : 0) + "× speed");
      (function tick(now) {
        playT = Math.min(st.T, (now - t0) / 1000 * speed); drawPend(); drawPhase();
        if (playT >= st.T) { playT = null; raf = 0; runs++; drawPend(); drawPhase(); api.live("paused", "Played " + st.T + " s"); return; }
        raf = requestAnimationFrame(tick);
      })(t0);
    }
    function reset() { stop(); playT = null; api.live("paused", "Paused"); }

    function manual() { st.preset = null; pressSeg(ctl, id + "-pre", "__none"); }
    function applyPreset(k) {
      var p = PRESETS[k]; if (!p) return;
      st.preset = k; st.bench = p.bench; ["N", "vmax", "q0", "dt", "T"].forEach(function (key) { st[key] = p[key]; setSlider(key, p[key]); });
      st.fric = p.fric; st.diss = p.diss; st.integ = p.integ;
      ctl.querySelector("#" + id + "-fric").checked = st.fric; ctl.querySelector("#" + id + "-diss").checked = st.diss;
      pressSeg(ctl, id + "-bench", st.bench); pressSeg(ctl, id + "-int", st.integ); pressSeg(ctl, id + "-pre", k);
    }
    bindSeg(ctl, id + "-bench", function (v) { reset(); applyPreset(v === "ints" ? "coarse" : "inside"); compute(); chartSoon(); });
    bindSeg(ctl, id + "-pre", function (v) { reset(); applyPreset(v); compute(); chartSoon(); });
    bindSeg(ctl, id + "-int", function (v) { st.integ = v; reset(); if (st.bench === "models") manual(); compute(); chartSoon(); });
    ["N", "vmax", "q0", "dt", "T"].forEach(function (key) {
      RB.bindSlider(ctl, id + SL[key], FMT[key], function (v) { st[key] = v; manual(); reset(); computeSoon(); });
    });
    ctl.querySelector("#" + id + "-fric").addEventListener("change", function (e) { st.fric = e.target.checked; manual(); reset(); compute(); chartSoon(); });
    ctl.querySelector("#" + id + "-diss").addEventListener("change", function (e) { st.diss = e.target.checked; reset(); compute(); chartSoon(); });
    ctl.querySelector("#" + id + "-seed").addEventListener("click", function () { st.seed++; reset(); compute(); chartSoon(); });
    ctl.querySelector("#" + id + "-go").addEventListener("click", play);
    if (window.ResizeObserver) { ro = new ResizeObserver(function () { var w = scene.clientWidth; if (Math.abs(w - lastW) < 2) return; lastW = w; drawPend(); drawPhase(); chartSoon(); }); ro.observe(scene); }
    applyPreset("inside"); compute(); drawCharts();
    RB.onTheme(function () { if (cvP.isConnected) { drawPend(); drawPhase(); drawCharts(); } });

    function state() { return { bench: st.bench, preset: st.preset, integ: st.integ, dt: st.dt, fric: st.fric, diss: st.diss, N: st.N, playing: !!raf, runs: runs }; }
    return {
      state: state,
      destroy: function () { stop(); clearTimeout(chartT); clearTimeout(simT); if (ro) ro.disconnect(); },
      demo: function () {
        var q = function (s) { return scene.querySelector(s) || ctl.querySelector(s); }, S = state, r0 = runs;
        return [
          { target: q("#" + id + "-pend"), title: "Three models, one pendulum", text: "Each cell is a model fit to noisy samples. The dashed ghost is the real pendulum; the bar shows energy against the release energy." },
          { target: q("#" + id + "-pre"), title: "Release beyond the data", text: "At 2.8 rad the swing reaches about 6 rad/s, but samples stop at 3 rad/s. Watch the phase plot leave the shaded box.", do: function (a) { return a.click(q("#" + id + '-pre [value="extrap"]')); }, task: "Choose the Extrapolate preset", expect: function () { return S().preset === "extrap"; } },
          { target: q("#" + id + "-go"), title: "Play the swing", text: "DeLaN and HNN stay with the ghost because speed dependence comes from mechanics. The black box has only its guess outside the box.", do: function (a) { r0 = runs; return a.click(q("#" + id + "-go")).then(function () { return a.until(function () { return !S().playing; }, 10000); }); }, task: "Press Play and watch the ten seconds", expect: function () { return S().runs > r0 && !S().playing; } },
          { target: q("#" + id + "-pre"), title: "Add friction", text: "The real pendulum now loses energy. Energy-conserving models cannot follow it, while the black box fits friction inside the data.", do: function (a) { return a.click(q("#" + id + '-pre [value="friction"]')); }, task: "Choose the Friction preset", expect: function () { return S().preset === "friction"; } },
          { target: q("#" + id + "-diss"), title: "Learn one damping term", text: "One learned coefficient d ≥ 0 lets DeLaN and HNN lose energy but never create it, the port-Hamiltonian idea.", do: function (a) { return a.click(q("#" + id + "-diss")); }, task: "Tick Learn a damping term", expect: function () { return S().diss; } },
          { target: q("#" + id + "-bench"), title: "Now the integrator", text: "No learning: the true pendulum at Δt = 0.1 s. Explicit Euler spirals outward; the symplectic methods keep a closed orbit.", do: function (a) { return a.click(q("#" + id + '-bench [value="ints"]')); }, task: "Switch the bench to Integrators", expect: function () { return S().bench === "ints"; } },
          { target: q("#" + id + "-dt"), title: "Shrink the step", text: "Smaller steps shrink every error, but Euler still drifts steadily. Compare the log-scale chart below the table.", do: function (a) { return a.set(q("#" + id + "-dt"), 0.02); }, task: "Set the step Δt to 0.02 s or less", expect: function () { return S().dt <= 0.02; } },
          { target: q("#" + id + "-pre"), title: "Your turn", text: "Try Long horizon, then return to Learned models, pick Euler as the integrator and see HNN drift despite its structure." }
        ];
      }
    };
  }

  RB.station({
    id: SID, name: "Physics-prior station", sub: "20 · models and integrators",
    refs: ["P11 §3.1–3.2, eq. 1–6", "P11 §3.4, eq. 8", "P11 Table 7"], prov: "Simplified: 1-DoF pendulum, linear fits",
    summary: "Fit a black box, a DeLaN-style model and an HNN-style model to the same noisy pendulum samples, then release them outside the data. A second bench steps the true pendulum with four integrators.",
    notice: [
      "Inside the data all three models fit; the difference shows only when the orbit leaves the box.",
      "Energy structure fixes how dynamics depend on speed, so DeLaN and HNN extrapolate.",
      "Conservation is a bias: without a damping term the structured models cannot fit friction.",
      "The integrator matters as much as the model: explicit Euler adds energy every step.",
      "Symplectic steps keep energy error bounded; RK4 is more accurate per step but still drifts."
    ],
    card: "Release learned pendulum models outside their data, then compare Euler, RK4 and symplectic steps.",
    terms: {
      "symplectic-integrator": { name: "symplectic integrator", aliases: ["symplectic Euler", "Störmer–Verlet", "leapfrog", "variational integrator"], group: "physics", def: "A time-stepping rule that preserves the symplectic structure of Hamiltonian dynamics, giving bounded energy error over long horizons rather than steady drift.", note: "Higher order is not the same thing: RK4 is more accurate per step, yet its energy error still accumulates.", ref: "P11 §3.4", scene: "robot", focus: ["trajectory"], look: "an orbit that stays closed", uses: [] }
    },
    ledger: [
      { where: "Lab · Physics-prior station · models", source: "DeLaN and HNN train deep networks by gradient descent (arXiv 1907.04490, 1906.01563)", page: "Each model is linear least squares on fixed features: radial basis functions for the black box, Fourier terms in q for DeLaN, Fourier-times-polynomial terms in (q, p) for HNN", why: "Isolates the effect of structure and refits instantly in the browser.", kind: "Simplified" },
      { where: "Lab · Physics-prior station · black box", source: "A black-box MLP would learn how torque enters the dynamics", page: "Torque enters the black box as one linear input", why: "Keeps the black box honest inside the data without a larger feature set.", kind: "Our choice" },
      { where: "Lab · Physics-prior station · DeLaN", source: "P11 eq. 4: M(q) = L(q)L(q)ᵀ with a positive diagonal", page: "One joint, so M(q) is a scalar clipped at 0.05 or above", why: "The Cholesky factor of a 1 × 1 matrix is its square root; clipping keeps the same guarantee.", kind: "Simplified" },
      { where: "Lab · Physics-prior station · HNN", source: "P11 Table 7: HNNs require generalized momenta or their reconstruction", page: "The HNN is given p = q̇, which is exact here because the true m l² is 1", why: "Avoids a momentum-estimation step the station does not teach.", kind: "Simplified" },
      { where: "Lab · Physics-prior station · damping", source: "Port-Hamiltonian models learn a dissipation matrix; DeLaN extensions learn structured friction (P11 §3.1.1, §3.2.2)", page: "One damping coefficient d ≥ 0, refit at 0 if negative", why: "A 1-DoF toy needs only one term.", kind: "Simplified" },
      { where: "Lab · Physics-prior station · integrators", source: "VINs build the symplectic integrator into the network (P11 §3.4, arXiv 1910.09349)", page: "Symplectic Euler and Verlet are applied at rollout time, also to non-separable learned Hamiltonians and damped systems, where they are only approximately symplectic", why: "Lets you swap integrator and model independently.", kind: "Simplified" },
      { where: "Lab · Physics-prior station · energy", source: "HNN conserves its own learned energy, not the true one", page: "All energies shown are the true pendulum energy evaluated at each predicted state", why: "One yardstick for every model and integrator.", kind: "Our choice" },
      { where: "Lab · Physics-prior station · notation", source: "P11 writes the potential as V(q) and gravity as g(q)", page: "The station writes U(q) and the gravity torque U′(q)", why: "V and g mean value and goal elsewhere on the site.", kind: "Our choice" }
    ],
    mount: mount
  });
})();
