/* Lab station · Grasp lab (topics 15, 16). Sources: P01 §2.1, §3.1, §4.1 (Fig. 4, Table 1) · P05 §6.8 · method cards
   (GraspNet-1Billion, GG-CNN, 6-DoF GraspNet, Contact-GraspNet, AnyGrasp, ThinkGrasp, GraspGPT, GraspVLA, DexGraspNet).
   Toy: a top-down tabletop of prism-shaped objects (convex parts, in millimetres, y up). Three grippers are checked with
   the same 2-D friction-cone test the topic uses, plus a sweep test for collisions while the fingers close, and a 3-D
   centerline test for the approach direction. Language targets rank sampled candidates the way planner-guided methods do. */
(function () {
  "use strict";
  var RB = window.RB;
  var DEG = Math.PI / 180;

  /* ================= geometry ================= */
  function circ(r, n) { var p = []; for (var i = 0; i < n; i++) { var a = 2 * Math.PI * i / n; p.push([r * Math.cos(a), r * Math.sin(a)]); } return p; }
  function rect(x0, y0, x1, y1) { return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]; }
  function tf(poly, cx, cy, rot) { var c = Math.cos(rot * DEG), s = Math.sin(rot * DEG); return poly.map(function (q) { return [cx + c * q[0] - s * q[1], cy + s * q[0] + c * q[1]]; }); }
  function area(poly) { var a = 0; for (var i = 0; i < poly.length; i++) { var p = poly[i], q = poly[(i + 1) % poly.length]; a += p[0] * q[1] - q[0] * p[1]; } return a / 2; }
  function centroid(poly) { var a = 0, x = 0, y = 0; for (var i = 0; i < poly.length; i++) { var p = poly[i], q = poly[(i + 1) % poly.length], k = p[0] * q[1] - q[0] * p[1]; a += k; x += (p[0] + q[0]) * k; y += (p[1] + q[1]) * k; } return [x / (3 * a), y / (3 * a)]; }
  function bbox(poly) { var b = [1e9, 1e9, -1e9, -1e9]; poly.forEach(function (q) { b[0] = Math.min(b[0], q[0]); b[1] = Math.min(b[1], q[1]); b[2] = Math.max(b[2], q[0]); b[3] = Math.max(b[3], q[1]); }); return b; }
  /* point in a counter-clockwise convex polygon */
  function inPart(pt, p) {
    var b = p.bb; if (pt[0] < b[0] || pt[0] > b[2] || pt[1] < b[1] || pt[1] > b[3]) return false;
    var poly = p.poly, n = poly.length;
    for (var i = 0; i < n; i++) { var A = poly[i], B = poly[(i + 1) % n]; if ((B[0] - A[0]) * (pt[1] - A[1]) - (B[1] - A[1]) * (pt[0] - A[0]) < 0) return false; }
    return true;
  }
  /* distance from an inside point to the nearest edge */
  function edgeDist(pt, poly) {
    var d = 1e9, n = poly.length;
    for (var i = 0; i < n; i++) { var A = poly[i], B = poly[(i + 1) % n], ex = B[0] - A[0], ey = B[1] - A[1], L = Math.hypot(ex, ey); d = Math.min(d, ((pt[0] - A[0]) * ey - (pt[1] - A[1]) * ex) / -L); }
    return Math.abs(d);
  }
  /* Cyrus–Beck: parameter interval of the line c + t·u inside a convex polygon, with the entry and exit normals */
  function clip(poly, c, u) {
    var tin = -Infinity, tout = Infinity, nin = null, nout = null, n = poly.length;
    for (var i = 0; i < n; i++) {
      var A = poly[i], B = poly[(i + 1) % n], ex = B[0] - A[0], ey = B[1] - A[1], L = Math.hypot(ex, ey);
      var nx = ey / L, ny = -ex / L, den = nx * u[0] + ny * u[1], num = nx * (A[0] - c[0]) + ny * (A[1] - c[1]);
      if (Math.abs(den) < 1e-9) { if (num < 0) return null; continue; }
      var t = num / den;
      if (den < 0) { if (t > tin) { tin = t; nin = [nx, ny]; } } else if (t < tout) { tout = t; nout = [nx, ny]; }
    }
    return tin > tout || !nin || !nout ? null : { tin: tin, tout: tout, nin: nin, nout: nout };
  }

  /* ================= objects and scenes ================= */
  /* top: "flat" (a suction cup can seal), "open" (a hole), "curved" (no seal in this toy) */
  var OBJ = {
    box: { name: "box", h: 120, col: "data-1", parts: [{ id: "body", name: "box", poly: rect(-25, -40, 25, 40), top: "flat" }] },
    mug: { name: "mug", h: 95, col: "data-2", parts: [{ id: "body", name: "mug body", poly: circ(30, 32), top: "open" }, { id: "handle", name: "mug handle", poly: rect(29, -8, 48, 8), top: "curved" }] },
    bottle: { name: "bottle", h: 200, col: "data-3", parts: [{ id: "body", name: "bottle", poly: circ(24, 28), top: "curved" }] },
    knife: { name: "knife", h: 18, col: "data-4", parts: [{ id: "handle", name: "knife handle", poly: rect(-75, -8, -5, 8), top: "flat" }, { id: "blade", name: "knife blade", poly: [[-5, -9], [72, -9], [90, 1], [-5, 9]], top: "flat" }] },
    block: { name: "block", h: 45, col: "data-5", parts: [{ id: "body", name: "block", poly: [[-30, -22], [30, -22], [16, 22], [-16, 22]], top: "flat" }] }
  };
  var SCENES = {
    clutter: { label: "Clutter", place: { box: [-95, 35, 15], mug: [5, 40, -35], bottle: [95, 45, 0], knife: [-30, -60, 8], block: [105, -58, -10] } },
    packed: { label: "Packed", place: { box: [-60, 20, 0], mug: [0, 25, -90], bottle: [58, 28, 0], knife: [-10, -58, 0], block: [118, -10, 90] } },
    shelf: { label: "Shelf", shelf: { y0: 5, z0: 110, t: 14 }, place: { mug: [-40, 52, 90], block: [72, 55, 0], bottle: [85, -52, 0], knife: [-35, -65, 5] } }
  };
  function buildScene(key) {
    var S = SCENES[key], objs = [];
    Object.keys(S.place).forEach(function (k) {
      var o = OBJ[k], pl = S.place[k], A = 0, cx = 0, cy = 0;
      var parts = o.parts.map(function (p) { var poly = tf(p.poly, pl[0], pl[1], pl[2]), a = area(poly), c = centroid(poly); A += a; cx += c[0] * a; cy += c[1] * a; return { id: p.id, name: p.name, top: p.top, poly: poly, bb: bbox(poly), area: a, obj: k }; });
      objs.push({ id: k, name: o.name, h: o.h, col: o.col, parts: parts, com: [cx / A, cy / A] });
    });
    var all = []; objs.forEach(function (o) { o.parts.forEach(function (p) { all.push(p); }); });
    return { key: key, objs: objs, parts: all, shelf: S.shelf || null, byId: objs.reduce(function (m, o) { m[o.id] = o; return m; }, {}) };
  }

  /* ================= grasp checks ================= */
  var INSTR = {
    any: { label: "Anything", say: "Pick up anything", obj: null, part: null },
    handle: { label: "Mug handle", say: "Lift the mug by its handle", obj: "mug", part: "handle" },
    knife: { label: "Knife", say: "Hand me the knife", obj: "knife", part: "handle" },
    bottle: { label: "Bottle", say: "Get the bottle", obj: "bottle", part: "body" }
  };
  var GRIP = { jaw: "Parallel jaw", suction: "Suction", three: "3-finger" };
  function partAt(sc, pt) { var best = null; sc.parts.forEach(function (p) { if (inPart(pt, p) && (!best || p.area < best.area)) best = p; }); return best; }
  function hitOther(sc, pt, skip) { for (var i = 0; i < sc.parts.length; i++) { var p = sc.parts[i]; if (p !== skip && inPart(pt, p)) return p; } return null; }
  function label(need) { var m = Math.max(0.1, Math.ceil(need * 10 - 1e-9) / 10); return m > 1.0001 ? 0 : Math.round((1.1 - m) * 10) / 10; }

  /* 3-D approach along the centerline (plus the palm's width) from the grasp point; returns the first blocking thing */
  function approach(sc, g, part, grip) {
    var o = sc.byId[part.obj], z0 = grip === "suction" ? o.h : Math.min(o.h / 2, 40), phi = grip === "suction" ? 0 : g.tilt * DEG;
    var v = [-Math.sin(g.th * DEG), Math.cos(g.th * DEG)], u = [Math.cos(g.th * DEG), Math.sin(g.th * DEG)];
    var d = [Math.sin(phi) * v[0], Math.sin(phi) * v[1], Math.cos(phi)], sh = sc.shelf;
    for (var s = 4; s <= 300; s += 3) {
      var offs = s >= 30 ? [-12, 0, 12] : [0];
      for (var k = 0; k < offs.length; k++) {
        var q = [g.x + s * d[0] + offs[k] * u[0], g.y + s * d[1] + offs[k] * u[1]], z = z0 + s * d[2];
        if (sh && q[1] >= sh.y0 && z >= sh.z0) return { by: "the shelf", at: [q[0], q[1], z], s: s };
        for (var i = 0; i < sc.objs.length; i++) { var ob = sc.objs[i]; if (ob.id === o.id || z >= ob.h) continue; for (var j = 0; j < ob.parts.length; j++) if (inPart(q, ob.parts[j])) return { by: "the " + ob.name, at: [q[0], q[1], z], s: s }; }
      }
    }
    return null;
  }
  /* sweep one finger from its open position to its contact; returns the first point inside another part */
  function sweep(sc, c, dir, side, t0, t1, offs, part, step) {
    for (var t = t0; t <= t1; t += step) for (var k = 0; k < offs.length; k++) {
      var pt = [c[0] + t * dir[0] + offs[k] * side[0], c[1] + t * dir[1] + offs[k] * side[1]], hp = hitOther(sc, pt, part);
      if (hp) return { pt: pt, part: hp };
    }
    return null;
  }
  /* evaluate one grasp g = {x, y, th, w, h, tilt} for gripper grip at friction mu.
     kind: miss | wide | collide | blocked | noseal | peel | slip | hold */
  function evaluate(sc, g, grip, mu, fast) {
    var c = [g.x, g.y], part = partAt(sc, c), step = fast ? 3.5 : 2;
    if (!part) return { kind: "miss", s: 0 };
    var r = { part: part, obj: part.obj, s: 0, contacts: [] }, cone = Math.atan(mu);
    var u = [Math.cos(g.th * DEG), Math.sin(g.th * DEG)], v = [-u[1], u[0]];
    if (grip === "suction") {
      var rc = g.h / 2, ob = sc.byId[part.obj], d = Math.hypot(c[0] - ob.com[0], c[1] - ob.com[1]);
      r.rc = rc; r.d = d;
      if (part.top !== "flat" || edgeDist(c, part.poly) < rc) { r.kind = "noseal"; r.why = part.top === "open" ? "open" : part.top === "curved" ? "curved" : "small"; return r; }
      var q = Math.round((1 - d / (3 * rc)) * 10) / 10;
      r.kind = q > 0 ? "hold" : "peel"; r.s = Math.max(0, q);
    } else if (grip === "jaw") {
      var cl = clip(part.poly, c, u);
      if (!cl) return { kind: "miss", s: 0 };
      r.chord = cl.tout - cl.tin;
      if (cl.tin < -g.w / 2 || cl.tout > g.w / 2) { r.kind = "wide"; return r; }
      var a1 = Math.acos(RB.clamp(-(u[0] * cl.nin[0] + u[1] * cl.nin[1]), -1, 1)), a2 = Math.acos(RB.clamp(u[0] * cl.nout[0] + u[1] * cl.nout[1], -1, 1));
      r.contacts = [{ p: [c[0] + cl.tin * u[0], c[1] + cl.tin * u[1]], n: cl.nin, a: a1 }, { p: [c[0] + cl.tout * u[0], c[1] + cl.tout * u[1]], n: cl.nout, a: a2 }];
      var offs = [-g.h / 2, -g.h / 4, 0, g.h / 4, g.h / 2];
      var h1 = sweep(sc, c, u, v, cl.tout + 1, g.w / 2 + 6, offs, part, step) || sweep(sc, c, [-u[0], -u[1]], v, -cl.tin + 1, g.w / 2 + 6, offs, part, step);
      if (h1) { r.kind = "collide"; r.hit = h1; return r; }
    } else {
      var R0 = g.w / 2, fin = [];
      for (var k = 0; k < 3; k++) {
        var ang = g.th * DEG + k * 2 * Math.PI / 3, dk = [Math.cos(ang), Math.sin(ang)], ck = clip(part.poly, c, dk);
        if (!ck) return { kind: "miss", s: 0 };
        if (ck.tout > R0) { r.kind = "wide"; r.chord = 2 * ck.tout; return r; }
        fin.push({ p: [c[0] + ck.tout * dk[0], c[1] + ck.tout * dk[1]], n: ck.nout, a: Math.acos(RB.clamp(dk[0] * ck.nout[0] + dk[1] * ck.nout[1], -1, 1)), d: dk, t: ck.tout });
      }
      r.contacts = fin;
      for (var m = 0; m < 3; m++) { var hk = sweep(sc, c, fin[m].d, [-fin[m].d[1], fin[m].d[0]], fin[m].t + 1, R0 + 6, [-g.h / 4, 0, g.h / 4], part, step); if (hk) { r.kind = "collide"; r.hit = hk; return r; } }
    }
    var ap = approach(sc, g, part, grip);
    if (ap) { r.kind = "blocked"; r.block = ap; return r; }
    if (grip !== "suction") {
      var amax = Math.max.apply(null, r.contacts.map(function (x) { return x.a; }));
      r.amax = amax; r.need = Math.tan(amax); r.s = label(r.need);
      r.kind = amax <= cone + 1e-9 ? "hold" : "slip";
    }
    return r;
  }
  function onTarget(r, ins) { var I = INSTR[ins]; return !I.obj || (r.obj === I.obj && r.part && r.part.id === I.part); }
  function success(r, ins) { return r.kind === "hold" && onTarget(r, ins); }
  /* failed grasps are ordered by how close they came, so a fallback is still on an object */
  var FAIL = { slip: 0.3, peel: 0.25, blocked: 0.2, collide: 0.15, noseal: 0.1, wide: 0.05, miss: 0 };
  function rankKey(r, ins, useLang) { return r.kind === "hold" ? 1 + r.s + (useLang && onTarget(r, ins) ? 10 : 0) : FAIL[r.kind]; }
  /* sample and rank: returns candidates sorted by the chosen key */
  function sampleRank(sc, o, N, seed, useLang, fast) {
    var R = RB.rng(seed), out = [];
    for (var i = 0; i < N; i++) {
      var g = { x: -145 + 290 * R(), y: -100 + 200 * R(), th: 180 * R(), w: o.w, h: o.h, tilt: o.tilt };
      var r = evaluate(sc, g, o.grip, o.mu, fast); out.push({ g: g, r: r, key: rankKey(r, o.ins, useLang) });
    }
    return out.sort(function (a, b) { return b.key - a.key; });
  }
  var NANG = 12; /* 12 in-plane angles, as GraspNet-1Billion / AnyGrasp discretize rotation (arXiv 2212.08333) */
  function qualityMap(sc, o) {
    var cells = [], best = null, stepC = 5;
    for (var x = -147.5; x < 150; x += stepC) for (var y = -102.5; y < 105; y += stepC) {
      if (!partAt(sc, [x, y])) continue;
      var top = 0, topG = null, topR = null, nA = o.grip === "suction" ? 1 : o.grip === "three" ? 4 : NANG;
      for (var k = 0; k < nA; k++) {
        var g = { x: x, y: y, th: k * (o.grip === "three" ? 120 : 180) / nA, w: o.w, h: o.h, tilt: o.tilt }, r = evaluate(sc, g, o.grip, o.mu, true);
        var val = r.kind === "hold" ? r.s : 0;
        if (val > top || !topG) { top = val; topG = g; topR = r; }
      }
      var cell = { x: x, y: y, s: top, g: topG, r: topR, on: onTarget(topR, o.ins) };
      cells.push(cell);
      var key = top + (o.ins !== "any" && cell.on && top > 0 ? 10 : 0);
      if (top > 0 && (!best || key > best.key)) best = { key: key, g: topG, r: topR };
    }
    return { cells: cells, step: stepC, best: best };
  }

  /* ================= station UI ================= */
  function mount(api) {
    var id = api.id, sc = api.scene, ct = api.controls;
    var st = { scene: "clutter", grip: "jaw", mode: "hand", ins: "any", x: 5, y: 40, th: 0, w: 80, h: 20, mu: 0.5, tilt: 0, N: 40, sig: 2, seed: 7 };
    var scene = buildScene(st.scene), cur = null, cand = null, map = null, chosen = null, dead = false, raf = 0, chartT = 0, mapT = 0;
    var anim = null, execN = 0, execDone = false, lastExec = null, sampled = 0;
    var TW = 600, TH = 420, S = 2, SW = 600, SH = 260;
    var font = function (w, px, kind) { return w + " " + px + "px " + getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); };
    var px = function (q) { return [TW / 2 + q[0] * S, TH / 2 - q[1] * S]; };
    function f2(v) { return (+v).toFixed(2); }
    function deg(v) { return v + "°"; }
    function mm(v) { return v + " mm"; }

    sc.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-top" aria-label="Top view of a tabletop with objects and the current grasp; drag to place the grasp"></canvas><figcaption class="sb-caption">Drag on an object to place the grasp. Look at the contacts: green wedges are friction cones that hold, red ones slip. A red cross marks where a finger or the arm hits something.</figcaption></figure>' +
      RB.legend([{ c: "good", label: "holds", kind: "area" }, { c: "bad", label: "slips or collides", kind: "area" }, { c: "accent", label: "gripper and target", kind: "line" }, { c: "ink-3", label: "rejected candidate", kind: "line" }]) +
      RB.readouts([{ id: "verdict", k: "Verdict" }, { id: "target", k: "Grasped part", u: "–" }, { id: "ang", k: "Largest contact angle" }, { id: "need", k: "Friction needed" }, { id: "s", k: "Label s_g" }, { id: "rob", k: "Succeeds under error", u: "of 40" }, { id: "evals", k: "Grasps checked" }, { id: "hit", k: "Instruction met" }]) +
      '<p class="sb-caption" id="' + id + '-note"></p>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-side" aria-label="Side view along the approach plane with object heights, the shelf and the approach path"></canvas><figcaption class="sb-caption">Side cut through the grasp point. The accent line is the approach path at tilt φ; it must reach the grasp without passing through the shelf or a taller object.</figcaption></figure>' +
      '<div class="rb-stack" id="' + id + '-rank"></div>' +
      '<div id="' + id + '-chart"></div>';

    ct.innerHTML =
      '<div class="rb-stack"><span class="sb-caption">Scene</span>' + RB.seg({ id: id + "-scene", label: "Scene", value: st.scene, options: Object.keys(SCENES).map(function (k) { return { value: k, label: SCENES[k].label }; }) }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Gripper</span>' + RB.seg({ id: id + "-grip", label: "Gripper", value: st.grip, options: Object.keys(GRIP).map(function (k) { return { value: k, label: GRIP[k] }; }) }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Search</span>' + RB.seg({ id: id + "-mode", label: "Search", value: st.mode, options: [{ value: "hand", label: "By hand" }, { value: "sample", label: "Sample, rank" }, { value: "map", label: "Quality map" }] }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Instruction ℓ</span>' + RB.seg({ id: id + "-ins", label: "Instruction", value: st.ins, options: Object.keys(INSTR).map(function (k) { return { value: k, label: INSTR[k].label }; }) }) + "</div>" +
      RB.slider({ id: id + "-th", label: "Grasp angle θ", min: 0, max: 179, step: 1, value: st.th, fmt: deg }) +
      RB.slider({ id: id + "-w", label: "Opening w", min: 20, max: 130, step: 2, value: st.w, fmt: mm }) +
      RB.slider({ id: id + "-h", label: "Jaw or cup size h", min: 8, max: 40, step: 2, value: st.h, fmt: mm }) +
      RB.slider({ id: id + "-mu", label: "Friction μ", min: 0.1, max: 1, step: 0.05, value: st.mu, fmt: f2 }) +
      RB.slider({ id: id + "-tilt", label: "Approach tilt φ", min: -75, max: 75, step: 5, value: st.tilt, fmt: deg }) +
      RB.slider({ id: id + "-n", label: "Samples N", min: 1, max: 300, step: 1, value: st.N }) +
      RB.slider({ id: id + "-sig", label: "Execution error σ", min: 0, max: 8, step: 0.5, value: st.sig, fmt: function (v) { return (+v).toFixed(1) + " mm"; } }) +
      '<div class="sb-btn-row"><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-exec">Execute grasp ▶</button><button class="sb-btn" type="button" id="' + id + '-again">Sample again</button><button class="sb-btn sb-btn--ghost" type="button" id="' + id + '-reset">Reset</button></div>';

    var q = function (s) { return sc.querySelector(s) || ct.querySelector(s); };
    var top = q("#" + id + "-top"), side = q("#" + id + "-side"), note = q("#" + id + "-note"), rankEl = q("#" + id + "-rank");

    function opts() { return { grip: st.grip, mu: st.mu, w: st.w, h: st.h, tilt: st.tilt, ins: st.ins }; }
    function handG() { return { x: st.x, y: st.y, th: st.th, w: st.w, h: st.h, tilt: st.tilt }; }
    function robust(g) {
      if (st.sig === 0) return null;
      var R = RB.rng(st.seed * 31 + 5), ok = 0;
      for (var i = 0; i < 40; i++) { var h = { x: g.x + st.sig * R.normal(), y: g.y + st.sig * R.normal(), th: g.th + 1.5 * st.sig * R.normal(), w: g.w, h: g.h, tilt: g.tilt }; if (success(evaluate(scene, h, st.grip, st.mu, true), st.ins)) ok++; }
      return ok;
    }

    /* ---------- top view ---------- */
    function drawTop() {
      if (dead) return;
      var P = RB.pal(), c = RB.canvas(top, TW, TH), i;
      c.fillStyle = P.surface; c.fillRect(0, 0, TW, TH);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (i = 0; i <= TW; i += 20) { c.beginPath(); c.moveTo(i, 0); c.lineTo(i, TH); c.stroke(); }
      for (i = 0; i <= TH; i += 20) { c.beginPath(); c.moveTo(0, i); c.lineTo(TW, i); c.stroke(); }
      if (scene.shelf) {
        var s0 = px([-150, 105]), s1 = px([150, scene.shelf.y0]);
        c.fillStyle = P["surface-sunk"]; c.fillRect(s0[0], s0[1], s1[0] - s0[0], s1[1] - s0[1]);
        c.strokeStyle = P["line-strong"]; c.setLineDash([6, 4]); c.beginPath(); c.moveTo(s0[0], s1[1]); c.lineTo(s1[0], s1[1]); c.stroke(); c.setLineDash([]);
        c.fillStyle = P["ink-3"]; c.font = font("500", 12, "mono"); c.textAlign = "left"; c.fillText("shelf above, " + scene.shelf.z0 + " mm up", 8, s1[1] - 8);
      }
      if (st.mode === "map" && map) {
        var cs = map.step * S;
        map.cells.forEach(function (cl) { if (cl.s <= 0) return; var z = px([cl.x, cl.y]); c.fillStyle = st.ins !== "any" && !cl.on ? P["ink-3"] : P.accent; c.globalAlpha = 0.15 + 0.7 * cl.s; c.fillRect(z[0] - cs / 2, z[1] - cs / 2, cs + 0.5, cs + 0.5); });
        c.globalAlpha = 1;
      }
      var I = INSTR[st.ins];
      scene.objs.forEach(function (o) {
        o.parts.forEach(function (p) {
          c.beginPath(); p.poly.forEach(function (qq, k) { var z = px(qq); if (k) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.closePath();
          c.globalAlpha = st.mode === "map" ? 0.25 : 0.4; c.fillStyle = P[o.col]; c.fill(); c.globalAlpha = 1;
          c.strokeStyle = P["line-strong"]; c.lineWidth = 1.5; c.stroke();
          if (I.obj === o.id && I.part === p.id) { c.strokeStyle = P.accent; c.lineWidth = 2.5; c.setLineDash([5, 3]); c.stroke(); c.setLineDash([]); }
        });
        var lb = px([o.com[0], o.com[1]]); c.textAlign = "center"; c.lineJoin = "round"; c.strokeStyle = P.surface; c.lineWidth = 3;
        c.font = font("600", 12, "body"); c.strokeText(o.name, lb[0], lb[1] + 4); c.fillStyle = P.ink; c.fillText(o.name, lb[0], lb[1] + 4);
        c.font = font("500", 11, "mono"); c.strokeText(o.h + " mm", lb[0], lb[1] + 18); c.fillStyle = P["ink-2"]; c.fillText(o.h + " mm", lb[0], lb[1] + 18);
      });
      c.textAlign = "left";
      if (st.mode === "sample" && cand) {
        cand.forEach(function (cd, k) {
          if (k === 0) return;
          var g = cd.g, u = [Math.cos(g.th * DEG), Math.sin(g.th * DEG)], a = px([g.x - 9 * u[0], g.y - 9 * u[1]]), b = px([g.x + 9 * u[0], g.y + 9 * u[1]]);
          var good = cd.r.kind === "hold" && (st.ins === "any" || onTarget(cd.r, st.ins));
          c.strokeStyle = good ? P.good : P["ink-3"]; c.globalAlpha = good ? 0.95 : 0.4; c.lineWidth = good ? 2.5 : 1.5;
          c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); c.globalAlpha = 1;
        });
      }
      if (chosen) drawGrasp(c, P, chosen.g, chosen.r);
      if (anim || lastExec) {
        var msg = anim ? "executing" : lastExec.text;
        c.fillStyle = P.ink; c.font = font("600", 14, "body"); c.textAlign = "right"; c.fillText(msg, TW - 10, 20); c.textAlign = "left";
      }
      c.fillStyle = P["ink-3"]; c.font = font("500", 12, "mono"); c.fillText(GRIP[st.grip] + " · μ = " + f2(st.mu), 8, TH - 8);
    }
    function cross(c, P, pt) { var z = px(pt); c.strokeStyle = P.bad; c.lineWidth = 2.5; c.beginPath(); c.moveTo(z[0] - 6, z[1] - 6); c.lineTo(z[0] + 6, z[1] + 6); c.moveTo(z[0] + 6, z[1] - 6); c.lineTo(z[0] - 6, z[1] + 6); c.stroke(); }
    function drawCone(c, P, ct0, ok) {
      var half = Math.atan(st.mu), base = Math.atan2(-ct0.n[1], -ct0.n[0]), L = 16;
      c.fillStyle = ok ? P["good-soft"] : P["bad-soft"]; c.strokeStyle = ok ? P.good : P.bad; c.lineWidth = 1.5;
      c.beginPath(); var z = px(ct0.p); c.moveTo(z[0], z[1]);
      for (var k = 0; k <= 12; k++) { var a = base - half + 2 * half * k / 12, w = px([ct0.p[0] + L * Math.cos(a), ct0.p[1] + L * Math.sin(a)]); c.lineTo(w[0], w[1]); }
      c.closePath(); c.globalAlpha = 0.85; c.fill(); c.globalAlpha = 1; c.stroke();
      c.fillStyle = P.ink; c.beginPath(); c.arc(z[0], z[1], 3.5, 0, 2 * Math.PI); c.fill();
    }
    function drawGrasp(c, P, g, r) {
      var u = [Math.cos(g.th * DEG), Math.sin(g.th * DEG)], v = [-u[1], u[0]], close = anim ? anim.close : 0;
      c.strokeStyle = P.accent; c.lineCap = "round";
      if (st.grip === "jaw") {
        var tL = g.w / 2, tR = g.w / 2;
        if (r.contacts.length && close > 0) { tL = g.w / 2 + (-(r.contacts[0].p[0] - g.x) * u[0] - (r.contacts[0].p[1] - g.y) * u[1] - g.w / 2) * close; tR = g.w / 2 + ((r.contacts[1].p[0] - g.x) * u[0] + (r.contacts[1].p[1] - g.y) * u[1] - g.w / 2) * close; }
        /* the 5-D rectangle: opening w along u, jaw size h along v */
        var cn = [[-g.w / 2, -g.h / 2], [g.w / 2, -g.h / 2], [g.w / 2, g.h / 2], [-g.w / 2, g.h / 2]].map(function (a) { return px([g.x + a[0] * u[0] + a[1] * v[0], g.y + a[0] * u[1] + a[1] * v[1]]); });
        c.lineWidth = 1; c.setLineDash([3, 3]); c.beginPath(); cn.forEach(function (z, k) { if (k) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.closePath(); c.stroke(); c.setLineDash([]);
        [[-1, tL], [1, tR]].forEach(function (sd) {
          var e = [g.x + sd[0] * sd[1] * u[0], g.y + sd[0] * sd[1] * u[1]], a = px([e[0] + g.h / 2 * v[0], e[1] + g.h / 2 * v[1]]), b = px([e[0] - g.h / 2 * v[0], e[1] - g.h / 2 * v[1]]);
          c.lineWidth = 5; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
        });
        var e1 = px([g.x - tL * u[0], g.y - tL * u[1]]), e2 = px([g.x + tR * u[0], g.y + tR * u[1]]);
        c.lineWidth = 1.5; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(e1[0], e1[1]); c.lineTo(e2[0], e2[1]); c.stroke(); c.setLineDash([]);
      } else if (st.grip === "three") {
        for (var k = 0; k < 3; k++) {
          var ang = g.th * DEG + k * 2 * Math.PI / 3, d = [Math.cos(ang), Math.sin(ang)], sd = [-d[1], d[0]], t = g.w / 2;
          if (r.contacts[k] && close > 0) t = g.w / 2 + (r.contacts[k].t - g.w / 2) * close;
          var pc = [g.x + t * d[0], g.y + t * d[1]], a2 = px([pc[0] + g.h / 4 * sd[0], pc[1] + g.h / 4 * sd[1]]), b2 = px([pc[0] - g.h / 4 * sd[0], pc[1] - g.h / 4 * sd[1]]), o0 = px([g.x, g.y]), o1 = px(pc);
          c.lineWidth = 1.5; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(o0[0], o0[1]); c.lineTo(o1[0], o1[1]); c.stroke(); c.setLineDash([]);
          c.lineWidth = 5; c.beginPath(); c.moveTo(a2[0], a2[1]); c.lineTo(b2[0], b2[1]); c.stroke();
        }
      } else {
        var z0 = px([g.x, g.y]);
        c.lineWidth = 2.5; c.beginPath(); c.arc(z0[0], z0[1], g.h / 2 * S, 0, 2 * Math.PI); c.stroke();
        if (r.kind === "noseal") { c.fillStyle = P["bad-soft"]; c.fill(); } else if (r.kind === "hold") { c.fillStyle = P["good-soft"]; c.globalAlpha = 0.7; c.fill(); c.globalAlpha = 1; }
        var ob = scene.byId[r.obj];
        if (ob && r.kind !== "miss") { var cm = px(ob.com); c.strokeStyle = P["ink-2"]; c.lineWidth = 1; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(z0[0], z0[1]); c.lineTo(cm[0], cm[1]); c.stroke(); c.setLineDash([]); c.fillStyle = P["ink-2"]; c.beginPath(); c.arc(cm[0], cm[1], 3, 0, 2 * Math.PI); c.fill(); }
      }
      c.lineCap = "butt";
      if (r.contacts && r.contacts.length && (r.kind === "hold" || r.kind === "slip")) r.contacts.forEach(function (ct0) { drawCone(c, P, ct0, ct0.a <= Math.atan(st.mu) + 1e-9); });
      if (r.kind === "collide") cross(c, P, r.hit.pt);
      if (r.kind === "blocked") cross(c, P, [r.block.at[0], r.block.at[1]]);
      if (st.grip !== "suction" && st.tilt !== 0) { /* approach direction, projected */
        var a0 = px([g.x, g.y]), sg = Math.sin(st.tilt * DEG) * 60, a1 = px([g.x + sg * v[0], g.y + sg * v[1]]);
        c.strokeStyle = P.accent; c.lineWidth = 2; c.beginPath(); c.moveTo(a1[0], a1[1]); c.lineTo(a0[0], a0[1]); c.stroke();
        c.fillStyle = P.accent; c.beginPath(); c.arc(a1[0], a1[1], 4, 0, 2 * Math.PI); c.fill();
      }
      var zc = px([g.x, g.y]); c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.arc(zc[0], zc[1], 4, 0, 2 * Math.PI); c.stroke();
    }

    /* ---------- side view: vertical cut through the grasp point along v ---------- */
    function drawSide() {
      if (dead) return;
      var P = RB.pal(), c = RB.canvas(side, SW, SH), g = chosen ? chosen.g : handG(), r = chosen ? chosen.r : { kind: "miss" };
      var K = 1.0, X0 = SW / 2, Z0 = SH - 26, v = [-Math.sin(g.th * DEG), Math.cos(g.th * DEG)];
      var sx = function (s) { return X0 + s * K; }, sz = function (z) { return Z0 - z * K; };
      c.fillStyle = P.surface; c.fillRect(0, 0, SW, SH);
      c.strokeStyle = P["line-strong"]; c.lineWidth = 2; c.beginPath(); c.moveTo(0, Z0); c.lineTo(SW, Z0); c.stroke();
      var lift = anim ? anim.lift : 0, liftOK = anim ? anim.ok : false;
      scene.objs.forEach(function (o) {
        o.parts.forEach(function (p) {
          var cl = clip(p.poly, [g.x, g.y], v); if (!cl) return;
          var up = (o.id === r.obj && liftOK) ? lift * 40 : 0;
          c.globalAlpha = 0.45; c.fillStyle = P[o.col]; c.fillRect(sx(cl.tin), sz(o.h + up), (cl.tout - cl.tin) * K, o.h * K); c.globalAlpha = 1;
          c.strokeStyle = o.id === r.obj ? P.ink : P["line-strong"]; c.lineWidth = o.id === r.obj ? 2 : 1; c.strokeRect(sx(cl.tin), sz(o.h + up), (cl.tout - cl.tin) * K, o.h * K);
        });
      });
      if (scene.shelf) {
        /* where the cut line is over the shelf region (y >= y0) */
        var y0 = scene.shelf.y0, a = -9999, b = 9999;
        if (Math.abs(v[1]) < 1e-6) { if (g.y < y0) { a = 1; b = 0; } } else { var t0 = (y0 - g.y) / v[1]; if (v[1] > 0) a = t0; else b = t0; }
        a = Math.max(a, -SW / 2 / K); b = Math.min(b, SW / 2 / K);
        if (b > a) { c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.fillRect(sx(a), sz(scene.shelf.z0 + scene.shelf.t), (b - a) * K, scene.shelf.t * K); c.strokeRect(sx(a), sz(scene.shelf.z0 + scene.shelf.t), (b - a) * K, scene.shelf.t * K); c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.textAlign = "left"; c.fillText("shelf", sx(a) + 6, sz(scene.shelf.z0 + scene.shelf.t) - 5); }
      }
      c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.textAlign = "left"; c.fillText("table", 6, Z0 + 16);
      if (r.kind === "miss" || !r.obj) { c.fillStyle = P["ink-2"]; c.font = font("600", 13, "body"); c.fillText("Place the grasp on an object to see its approach", 10, 20); return; }
      var o = scene.byId[r.obj], zg = st.grip === "suction" ? o.h : Math.min(o.h / 2, 40), phi = st.grip === "suction" ? 0 : st.tilt * DEG;
      var d = [Math.sin(phi), Math.cos(phi)], L = 220, sPos = anim ? (1 - anim.reach) * 150 : 0, up = anim ? anim.lift * 40 : 0;
      c.strokeStyle = r.kind === "blocked" ? P.bad : P.accent; c.lineWidth = 2; c.setLineDash([6, 4]); c.beginPath(); c.moveTo(sx(0), sz(zg)); c.lineTo(sx(L * d[0]), sz(zg + L * d[1])); c.stroke(); c.setLineDash([]);
      /* gripper glyph at distance sPos along the path: palm and two fingers pointing back along -d */
      var gp = [sPos * d[0], zg + sPos * d[1] + up], nrm = [d[1], -d[0]], fl = 22, hw = st.grip === "suction" ? 6 : 12;
      var P0 = [gp[0] + fl * d[0], gp[1] + fl * d[1]];
      c.strokeStyle = P.accent; c.lineWidth = 3; c.lineCap = "round"; c.beginPath();
      c.moveTo(sx(P0[0] + hw * nrm[0]), sz(P0[1] + hw * nrm[1])); c.lineTo(sx(P0[0] - hw * nrm[0]), sz(P0[1] - hw * nrm[1]));
      [-1, 1].forEach(function (sg) { if (st.grip === "suction" && sg > 0) return; var off = st.grip === "suction" ? 0 : sg * hw; c.moveTo(sx(P0[0] + off * nrm[0]), sz(P0[1] + off * nrm[1])); c.lineTo(sx(gp[0] + off * nrm[0]), sz(gp[1] + off * nrm[1])); });
      c.moveTo(sx(P0[0]), sz(P0[1])); c.lineTo(sx(P0[0] + 40 * d[0]), sz(P0[1] + 40 * d[1])); c.stroke(); c.lineCap = "butt";
      if (r.kind === "blocked") { var bs = r.block.s; var bx = sx(bs * d[0]), bz = sz(zg + bs * d[1]); c.strokeStyle = P.bad; c.lineWidth = 2.5; c.beginPath(); c.moveTo(bx - 6, bz - 6); c.lineTo(bx + 6, bz + 6); c.moveTo(bx + 6, bz - 6); c.lineTo(bx - 6, bz + 6); c.stroke(); }
      c.fillStyle = P["ink-2"]; c.font = font("600", 13, "body"); c.textAlign = "left"; c.fillText("φ = " + (st.grip === "suction" ? 0 : st.tilt) + "°" + (r.kind === "blocked" ? " · blocked by " + r.block.by : " · path clear"), 10, 20);
    }

    /* ---------- readouts, notes, ranking list ---------- */
    var VERD = { miss: "Misses", wide: "Too wide", collide: "Collides", blocked: "Approach blocked", noseal: "No seal", peel: "Peels off", slip: "Slips", hold: "Holds" };
    function noteFor(r) {
      var I = INSTR[st.ins];
      if (!r || r.kind === "miss") return "The grasp center is not on an object. Drag it onto one, or let the search choose.";
      if (r.kind === "wide") return "The part is " + Math.round(r.chord) + " mm across along the fingers, more than the " + st.w + " mm opening. Open wider or turn the grasp.";
      if (r.kind === "collide") return "A finger sweeps into the " + r.hit.part.name + " while it closes. In clutter the space around the contacts matters as much as the contacts.";
      if (r.kind === "blocked") return "The arm's path to the grasp passes through " + r.block.by + ". Tilt the approach (a 6-DoF grasp) or pick another object.";
      if (r.kind === "noseal") return r.why === "open" ? "The mug's top is an opening, so the cup cannot seal." : r.why === "curved" ? "This top is curved in the toy, so the cup leaks." : "The cup does not fit inside the flat face: make h smaller or move to the middle of the face.";
      if (r.kind === "peel") return "The cup seals, but it sits " + Math.round(r.d) + " mm from the center of mass. The weight's torque peels it off in this toy.";
      var off = I.obj && !onTarget(r, st.ins) ? " It holds, but not on the part the instruction asks for." : "";
      if (st.grip === "suction") return "The cup seals on a flat face near the center of mass. Suction ignores friction here." + off;
      if (r.kind === "slip") return "The largest contact angle is " + Math.round(r.amax / DEG) + "°, outside the " + (Math.atan(st.mu) / DEG).toFixed(1) + "° cone. Raise μ or turn the fingers toward the surface normals.";
      return (st.grip === "three" ? "All three contact angles fit inside the friction cones, and the three squeeze lines meet at the center." : "Both contact angles fit inside the friction cones, so the jaws can squeeze without sliding.") + off;
    }
    function refresh() {
      if (dead) return;
      var I = INSTR[st.ins];
      if (st.mode === "hand") { chosen = { g: handG(), r: evaluate(scene, handG(), st.grip, st.mu) }; }
      else if (st.mode === "sample") {
        cand = sampleRank(scene, opts(), st.N, st.seed, st.ins !== "any");
        chosen = cand.length && cand[0].r.kind === "hold" ? { g: cand[0].g, r: cand[0].r } : { g: cand[0].g, r: cand[0].r };
      } else {
        map = qualityMap(scene, opts());
        chosen = map.best ? { g: map.best.g, r: evaluate(scene, map.best.g, st.grip, st.mu) } : null;
      }
      var r = chosen ? chosen.r : { kind: "miss" };
      RB.setRO(sc, "verdict", VERD[r.kind]);
      RB.setRO(sc, "target", r.part ? (r.part.id === "body" ? r.part.obj : r.part.id) : "–");
      var tu = sc.querySelector('[data-ro="target"]'); tu = tu && tu.parentNode.querySelector(".sb-readout-u"); if (tu) tu.textContent = r.part ? (r.part.id === "body" ? "body" : "of the " + r.part.obj) : "–";
      var hasC = r.contacts && r.contacts.length && r.amax != null;
      RB.setRO(sc, "ang", hasC ? Math.round(r.amax / DEG) + "°" : "–");
      RB.setRO(sc, "need", hasC ? RB.fmt(r.need, 2) : st.grip === "suction" && r.kind !== "miss" ? "none" : "–");
      RB.setRO(sc, "s", r.kind === "hold" || r.kind === "slip" || r.kind === "peel" ? (r.s > 0 ? r.s.toFixed(1) : "none") + (st.grip === "suction" ? " (toy)" : "") : "–");
      var rb = chosen && r.kind !== "miss" ? robust(chosen.g) : null;
      RB.setRO(sc, "rob", rb == null ? "–" : String(rb));
      RB.setRO(sc, "evals", st.mode === "hand" ? "1" : st.mode === "sample" ? String(st.N) : String(map.cells.length * (st.grip === "suction" ? 1 : st.grip === "three" ? 4 : NANG)));
      RB.setRO(sc, "hit", I.obj ? (success(r, st.ins) ? "Yes" : "No") : "–");
      note.textContent = noteFor(r);
      ["th"].forEach(function (k) { q("#" + id + "-" + k).disabled = st.mode !== "hand"; });
      q("#" + id + "-tilt").disabled = st.grip === "suction";
      q("#" + id + "-n").disabled = st.mode !== "sample"; q("#" + id + "-again").disabled = st.mode !== "sample";
      api.meta(SCENES[st.scene].label + " · " + GRIP[st.grip] + " · " + (st.mode === "hand" ? "by hand" : st.mode === "sample" ? st.N + " samples" : "quality map"));
      drawRank(); drawTop(); drawSide();
      clearTimeout(chartT); chartT = setTimeout(chart, 80);
    }
    function drawRank() {
      var I = INSTR[st.ins], html = '<p class="rb-h5">' + (st.mode === "sample" ? "Top candidates" : st.mode === "map" ? "Best cell of the map" : "Your grasp") + "</p>";
      html += '<p class="sb-caption">Instruction: “' + I.say + "”. " + (I.obj ? "Candidates on the " + I.obj + " " + (I.part === "body" ? "" : I.part + " ") + "are ranked first, then by label, as planner-guided methods filter a grasp model's candidates (P01 Fig. 4c)." : "Candidates are ranked by label alone.") + "</p>";
      if (st.mode === "sample" && cand) {
        var geo = cand.slice().sort(function (a, b) { return rankKey(b.r, st.ins, false) - rankKey(a.r, st.ins, false); })[0];
        html += '<ol class="rb-notice">' + cand.slice(0, 4).map(function (cd) { return "<li>" + (cd.r.part ? cd.r.part.name : "table") + " · " + VERD[cd.r.kind].toLowerCase() + (cd.r.kind === "hold" ? ", s = " + cd.r.s.toFixed(1) : "") + "</li>"; }).join("") + "</ol>";
        if (I.obj && !(cand[0].r.kind === "hold" && onTarget(cand[0].r, st.ins))) html += '<p class="sb-caption">No sampled grasp holds on the target, so the best other grasp is ranked first. Sample more or sample again.</p>';
        if (I.obj) html += '<p class="sb-caption">Ranking by label alone would pick: <b>' + (geo.r.part ? geo.r.part.name : "nothing") + "</b>" + (geo.r.kind === "hold" ? ", s = " + geo.r.s.toFixed(1) : "") + ".</p>";
      } else if (st.mode === "map" && map) {
        var on = map.cells.filter(function (cl) { return cl.s > 0; }).length;
        html += '<p class="sb-caption">' + on + " of " + map.cells.length + " object cells have a holding grasp at some angle. The chosen cell is the brightest" + (I.obj ? " on the target part." : ".") + "</p>";
      } else html += '<p class="sb-caption">Drag the center on the top view and turn it with θ. Switch Search to let the station propose grasps.</p>';
      if (lastExec) html += '<p class="sb-caption"><b>Last execution:</b> ' + lastExec.text + ".</p>";
      rankEl.innerHTML = html;
    }

    /* ---------- chart: success against the number of samples ---------- */
    function chart() {
      if (dead) return;
      var host = q("#" + id + "-chart"), Ns = [1, 5, 10, 20, 40, 80, 120, 160, 200], SEEDS = 16, o = opts();
      var mk = function (useLang) { return Ns.map(function (N) { var ok = 0; for (var s = 0; s < SEEDS; s++) { var cd = sampleRank(scene, o, N, 900 + s * 13, useLang, true); if (success(cd[0].r, st.ins)) ok++; } return [N, ok / SEEDS]; }); };
      var series = [{ name: st.ins === "any" ? "Rank by label" : "Label only", color: "data-1", points: mk(false) }];
      if (st.ins !== "any") series.push({ name: "Instruction first", color: "data-3", points: mk(true), dash: true });
      host.innerHTML = "";
      StudyBench.lineChart(host, { title: "Chosen grasp holds" + (st.ins !== "any" ? " on the target" : "") + " against samples N", x: { label: "Samples N", min: 0, max: 200, ticks: [0, 50, 100, 150, 200] }, y: { label: st.ins === "any" ? "Holds" : "Holds on target", min: 0, max: 1, ticks: [0, 0.25, 0.5, 0.75, 1], fmt: function (v) { return Math.round(v * 100) + "%"; } }, series: series, height: 220, caption: "Our toy numbers: " + SEEDS + " seeded runs per point, current scene, gripper and μ. " + (st.ins === "any" ? "Pick an instruction to compare ranking with and without it." : "Label-only ranking rarely lands on the named part; the gap is what language adds.") });
    }

    /* ---------- execute: approach, close, lift ---------- */
    function execute() {
      if (dead || !chosen) return;
      if (raf) cancelAnimationFrame(raf);
      execN++; execDone = false; lastExec = null;
      var R = RB.rng(st.seed * 101 + execN), g = chosen.g, h = st.sig > 0 ? { x: g.x + st.sig * R.normal(), y: g.y + st.sig * R.normal(), th: g.th + 1.5 * st.sig * R.normal(), w: g.w, h: g.h, tilt: g.tilt } : g;
      var rr = evaluate(scene, h, st.grip, st.mu), ok = success(rr, st.ins) || (st.ins === "any" && rr.kind === "hold");
      var text = rr.kind === "hold" ? (ok ? "Lifted the " + rr.part.name : "Lifted the wrong part (" + rr.part.name + ")") : "Failed: " + VERD[rr.kind].toLowerCase();
      if (rr.kind === "hold" && !onTarget(rr, st.ins)) ok = false;
      var t0 = 0, blocked = rr.kind === "blocked";
      anim = { reach: 0, close: 0, lift: 0, ok: rr.kind === "hold" };
      function fr(ts) {
        if (dead) return;
        if (!t0) t0 = ts;
        var t = (ts - t0) / 1000;
        anim.reach = blocked ? Math.min(1, t / 0.6) * (1 - Math.min(1, rr.block.s / 150)) : Math.min(1, t / 0.6);
        anim.close = RB.clamp((t - 0.6) / 0.4, 0, 1);
        anim.lift = RB.clamp((t - 1.0) / 0.6, 0, 1);
        drawTop(); drawSide();
        if (t >= 1.7 || (blocked && t >= 0.8)) { raf = 0; anim = null; lastExec = { text: text, ok: rr.kind === "hold" && onTarget(rr, st.ins) }; execDone = true; drawTop(); drawSide(); drawRank(); api.live("paused", text); return; }
        api.live("running", t < 0.6 ? "Approaching" : t < 1.0 ? "Closing" : "Lifting");
        raf = requestAnimationFrame(fr);
      }
      raf = requestAnimationFrame(fr);
    }

    /* ---------- wiring ---------- */
    function setSeg(sid, v) { RB.$$("#" + sid + " button", ct).forEach(function (b) { b.setAttribute("aria-pressed", b.value === v ? "true" : "false"); }); }
    function setSlider(sid, v, fmt) { var inp = q("#" + sid), out = ct.querySelector('[data-out="' + sid + '"]'); inp.value = v; if (out) out.textContent = fmt ? fmt(v) : v; }
    function bindSeg(sid, cb) { StudyBench.segmented(ct.querySelector("#" + sid), function (a, b) { var btn = ct.querySelector("#" + sid + ' [aria-pressed="true"]'); cb(b ? b.value : (a && a.value) || (typeof a === "string" ? a : btn && btn.value)); }); }
    function clearExec() { lastExec = null; execDone = false; }
    bindSeg(id + "-scene", function (v) {
      st.scene = v; scene = buildScene(v); clearExec();
      /* put the hand grasp on the mug body, which every scene has */
      var m = scene.byId.mug; st.x = Math.round(m.com[0]); st.y = Math.round(m.com[1]); refresh();
    });
    bindSeg(id + "-grip", function (v) { st.grip = v; clearExec(); refresh(); });
    bindSeg(id + "-mode", function (v) { st.mode = v; clearExec(); refresh(); });
    bindSeg(id + "-ins", function (v) { st.ins = v; clearExec(); refresh(); });
    RB.bindSlider(ct, id + "-th", deg, function (v) { st.th = v; clearExec(); refresh(); });
    RB.bindSlider(ct, id + "-w", mm, function (v) { st.w = v; clearExec(); sched(); });
    RB.bindSlider(ct, id + "-h", mm, function (v) { st.h = v; clearExec(); sched(); });
    RB.bindSlider(ct, id + "-mu", f2, function (v) { st.mu = v; clearExec(); sched(); });
    RB.bindSlider(ct, id + "-tilt", deg, function (v) { st.tilt = v; clearExec(); sched(); });
    RB.bindSlider(ct, id + "-n", null, function (v) { st.N = v; clearExec(); sched(); });
    RB.bindSlider(ct, id + "-sig", function (v) { return (+v).toFixed(1) + " mm"; }, function (v) { st.sig = v; clearExec(); sched(); });
    function sched() { if (st.mode === "map") { clearTimeout(mapT); mapT = setTimeout(refresh, 40); } else refresh(); }
    q("#" + id + "-exec").addEventListener("click", execute);
    q("#" + id + "-again").addEventListener("click", function () { st.seed++; sampled++; clearExec(); refresh(); });
    q("#" + id + "-reset").addEventListener("click", function () {
      st.th = 0; st.w = 80; st.h = 20; st.mu = 0.5; st.tilt = 0; st.sig = 2; st.N = 40;
      setSlider(id + "-th", 0, deg); setSlider(id + "-w", 80, mm); setSlider(id + "-h", 20, mm); setSlider(id + "-mu", 0.5, f2); setSlider(id + "-tilt", 0, deg); setSlider(id + "-n", 40); setSlider(id + "-sig", 2, function (v) { return (+v).toFixed(1) + " mm"; });
      var m = scene.byId.mug; st.x = Math.round(m.com[0]); st.y = Math.round(m.com[1]); clearExec(); refresh();
    });
    var dragging = false;
    function toMM(e) { var b = top.getBoundingClientRect(), kx = TW / b.width, ky = TH / b.height; return [RB.clamp(Math.round(((e.clientX - b.left) * kx - TW / 2) / S), -148, 148), RB.clamp(Math.round((TH / 2 - (e.clientY - b.top) * ky) / S), -103, 103)]; }
    function place(e) { var m = toMM(e); st.x = m[0]; st.y = m[1]; if (st.mode !== "hand") { st.mode = "hand"; setSeg(id + "-mode", "hand"); } clearExec(); refresh(); }
    top.addEventListener("pointerdown", function (e) { dragging = true; try { top.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } place(e); });
    top.addEventListener("pointermove", function (e) { if (dragging) place(e); });
    top.addEventListener("pointerup", function () { dragging = false; });
    top.addEventListener("pointercancel", function () { dragging = false; });
    RB.onTheme(function () { if (dead || !document.contains(top)) return; drawTop(); drawSide(); });

    if (api.side) {
      api.side.style.minWidth = "0";
      api.side.innerHTML = '<div class="rb-stack"><p class="rb-h5">Which gripper for which object</p>' +
        '<p class="sb-caption"><b>Parallel jaw</b>: two opposite faces whose normals line up with the squeeze. The most common end-effector <span class="sb-ref">P01 §2.1</span></p>' +
        '<p class="sb-caption"><b>Suction</b>: a flat, sealed face near the center of mass. P01 names single end-effectors, suction or jaw, as a limit <span class="sb-ref">P01 §4.1</span></p>' +
        '<p class="sb-caption"><b>3-finger</b>: round objects, where three squeeze lines meet at the center, like the Robotiq 3-Finger gripper <span class="sb-ref">P01 §2.1</span></p>' +
        '<p class="rb-h5">Reference numbers</p>' + [
          ["GraspNet-1Billion", "label s = 1.1 − μ_min, μ stepped by 0.1", "arXiv 1912.13470"],
          ["AnyGrasp", "93.3% bin-clearing success on over 300 unseen objects; over 900 picks per hour", "arXiv 2212.08333"],
          ["Contact-GraspNet", "90.2% in clutter vs 80.39% for 6-DoF GraspNet with CollisionNet", "arXiv 2103.14127"],
          ["ThinkGrasp", "0.980 success in PyBullet clutter vs 0.753 for VLG; 0.789 in heavy clutter", "arXiv 2407.11298"],
          ["GraspGPT", "77% / 71% real task-oriented grasp success on held-out classes / tasks", "arXiv 2307.13204"],
          ["GraspVLA", "bounding box then grasp pose as chain of thought: 66.6% → 93.3%", "arXiv 2505.03233"],
          ["DexGraspNet", "1.32M ShadowHand grasps on 5355 objects", "arXiv 2210.02697"]
        ].map(function (r) { return '<p class="sb-caption"><b>' + r[0] + "</b>: " + r[1] + ' <span class="sb-ref">' + r[2] + "</span></p>"; }).join("") + "</div>";
    }

    /* used by the demo: put the hand grasp at an object's center of mass */
    function placeOn(oid) { var o = scene.byId[oid]; if (!o) return; st.x = Math.round(o.com[0]); st.y = Math.round(o.com[1]); st.th = 0; setSlider(id + "-th", 0, deg); if (st.mode !== "hand") { st.mode = "hand"; setSeg(id + "-mode", "hand"); } clearExec(); refresh(); }

    refresh();

    return {
      state: function () { return st; },
      demo: function () {
        var seg = function (s, v) { return q("#" + id + "-" + s + ' [value="' + v + '"]'); };
        var sl = function (s) { return q("#" + id + "-" + s); };
        var fin = function (a) { return a.until(function () { return execDone; }, 6000); };
        return [
          { target: top, title: "A grasp on the mug", text: "The jaws squeeze across the mug body at θ = 0. Both contacts face the squeeze line, so the green cones hold.", do: function (a) { return a.click(q("#" + id + "-exec")).then(function () { return fin(a); }); } },
          { target: top, title: "Move to the block", text: "The block's sides lean. At θ = 0 one contact angle is about 28°, just outside the 26.6° cone at μ = 0.5, so it slips.", do: function (a) { placeOn("block"); return a.wait(600); }, task: "Drag the grasp onto the block", expect: function () { return chosen && chosen.r.obj === "block"; } },
          { target: sl("mu"), title: "Add friction", text: "A rubbery pad widens both cones. At μ = 0.6 the half-angle is 31°, enough for the leaning face.", do: function (a) { return a.set(sl("mu"), 0.6); }, task: "Raise μ until the block grasp holds", expect: function () { return chosen && chosen.r.obj === "block" && chosen.r.kind === "hold"; } },
          { target: q("#" + id + "-grip"), title: "Switch to suction", text: "Suction needs a sealed flat face, not friction. On the mug the top is open, so it fails where jaws work.", do: function (a) { placeOn("mug"); return a.click(seg("grip", "suction")); }, task: "Choose the Suction gripper", expect: function () { return st.grip === "suction"; } },
          { target: q("#" + id + "-mode"), title: "Sample and rank", text: "Now let the station draw random grasps, check each, and keep the best. Suction picks a flat face like the box top.", do: function (a) { return a.click(seg("mode", "sample")); }, task: "Choose Sample, rank under Search", expect: function () { return st.mode === "sample"; } },
          { target: q("#" + id + "-ins"), title: "Name the part", text: "“Hand me the knife” names the handle. Back with the jaws, candidates on the handle are ranked first; the chart shows what that adds.", do: function (a) { return a.click(seg("grip", "jaw")).then(function () { return a.click(seg("ins", "knife")); }); }, task: "Choose the Knife instruction", expect: function () { return st.ins === "knife"; } },
          { target: q("#" + id + "-scene"), title: "Under a shelf", text: "In the shelf scene a top-down path to the mug hits the shelf. Tilt the approach to 45° so the arm comes in from the front, then execute.", do: function (a) { return a.click(seg("scene", "shelf")).then(function () { return a.click(seg("ins", "any")); }).then(function () { return a.click(seg("mode", "hand")); }).then(function () { return a.set(sl("th"), 0); }).then(function () { return a.set(sl("mu"), 0.5); }).then(function () { return a.set(sl("tilt"), -45); }).then(function () { return a.click(q("#" + id + "-exec")); }).then(function () { return fin(a); }); }, task: "Open Shelf and tilt the approach", expect: function () { return st.scene === "shelf" && Math.abs(st.tilt) >= 35; } },
          { target: q("#" + id + "-mode"), title: "Your turn", text: "Switch to Quality map with the 3-finger gripper. Round objects light up; the box's corners do not. Then try Packed with the jaws." }
        ];
      },
      destroy: function () { dead = true; if (raf) cancelAnimationFrame(raf); raf = 0; clearTimeout(chartT); clearTimeout(mapT); }
    };
  }

  RB.station({
    id: "grasp", name: "Grasp lab", sub: "15 · 16",
    refs: ["P01 §3.1, §4.1", "P01 Fig. 4", "P05 §6.8"], prov: "Simplified: 2-D prisms, point contacts",
    summary: "Place a 5-D grasp rectangle in a cluttered tabletop, or let the station sample and rank candidates, build a quality map, or follow an instruction. Switch between jaws, suction and three fingers, tilt the approach, then execute.",
    notice: [
      "A grasp holds only if every squeeze line stays inside its friction cone of half-angle arctan μ.",
      "In clutter, most failures are fingers sweeping into neighbors, not bad contacts.",
      "Each gripper suits different shapes: parallel faces, flat sealed tops, or round bodies.",
      "Ranking by grasp quality alone ignores what the instruction asks for; filtering by the named part fixes that.",
      "Top-down grasps fail under a shelf; a tilted 6-DoF approach reaches in from the open side."
    ],
    card: "Place, sample or map grasps in clutter; switch grippers, name a part, tilt the approach, and execute.",
    terms: {
      "approach-direction": { name: "approach direction", aliases: ["approach vector", "approach tilt"], group: "grasp", def: "The direction along which the gripper moves in to reach a grasp. A 6-DoF grasp label may include it along with position, orientation and a quality score.", note: "Rectangle grasps assume a top-down approach; tilting the approach is what lets 6-DoF grasps reach under shelves and around clutter.", ref: "P01 §3.1, §4.1", scene: "robot", focus: ["gripper", "grasp-pose", "obstacle"], look: "the path the gripper takes in", uses: [] },
      "suction-grasp": { name: "suction grasp", aliases: ["suction gripper", "vacuum grasp"], group: "grasp", def: "A grasp made by sealing a vacuum cup on a surface instead of squeezing with fingers. P01 lists suction and parallel grippers as the usual single end-effectors.", note: "Suction needs a sealable face, not friction cones. Dex-Net's ambidextrous policies choose between suction and a parallel jaw per object.", ref: "P01 §4.1", scene: "robot", focus: ["end-effector", "object"], look: "a cup sealed on a flat face", uses: [] }
    },
    ledger: [
      { where: "Lab · Grasp lab", source: "Real grasp labels use 3-D meshes, soft contacts and physics checks (GraspNet-1Billion, ACRONYM)", page: "Objects are prisms of convex 2-D parts; contacts are two or three points on the squeeze lines through the center", why: "Keeps the friction-cone test visible and fast enough for a live quality map.", kind: "Simplified" },
      { where: "Lab · Grasp lab", source: "Suction models in the literature test seal and wrench resistance", page: "A seal needs a flat face with the cup inside it; the toy score is 1 − d / (3 r), with d the offset from the center of mass and r the cup radius", why: "Shows why suction prefers flat faces near the center of mass. The factor 3 is our choice, not a measured value.", kind: "Our choice" },
      { where: "Lab · Grasp lab", source: "Three-finger force closure needs a wrench-space test", page: "Three fingers at 120° squeeze toward the center; the grasp holds when every contact angle fits its friction cone", why: "The three squeeze lines meet at one point, so equal forces balance; a full test would also check torques.", kind: "Simplified" },
      { where: "Lab · Grasp lab", source: "Collision checks use the full gripper and arm geometry", page: "Fingers are swept as short plates while they close; the approach is checked along a centerline plus the palm's width", why: "Enough to show clutter and shelf failures without a mesh model.", kind: "Simplified" },
      { where: "Lab · Grasp lab", source: "ThinkGrasp re-ranks the top grasps near a VLM-chosen target point; GraspGPT scores candidates with a language-conditioned evaluator", page: "The Instruction control ranks candidates on the named part first, then by label", why: "The essence of the planner-guided family in P01 Fig. 4c, without a language model.", kind: "Simplified" },
      { where: "Lab · Grasp lab", source: "Grasp models propose candidates near objects", page: "Sample and rank draws grasp centers uniformly over the table", why: "A uniform sampler makes the cost of a weak proposal step visible.", kind: "Our choice" },
      { where: "Lab · Grasp lab", source: "Tilted 6-DoF grasps change the finger geometry in 3-D", page: "Tilt turns the approach about the squeeze line, so the squeeze stays horizontal and the 2-D contact test still applies", why: "One extra degree of freedom is enough to show the shelf case.", kind: "Simplified" },
      { where: "Lab · Grasp lab", source: "Execution error depends on the robot and calibration", page: "Robustness adds σ mm of position error and 1.5σ degrees of angle error, 40 seeded trials", why: "Matches the Grasping topic's playground; the numbers are ours.", kind: "Our choice" }
    ],
    mount: mount
  });
})();
