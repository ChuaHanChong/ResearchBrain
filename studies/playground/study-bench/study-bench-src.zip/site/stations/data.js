/* Interactive Lab · Data recipe mixer (topics 13, 14).
   Sources: P05 §1 (five layers, scalability vs robot alignment, the six dimensions and the layer cards), P05 §7.2.1 and Table 7
   (recipe evolution: π0 → π0.5 → π0.7, LingBot-VA → LingBot-VA 2.0, Qwen-RobotManip, Xiaomi-Robotics-1, EgoScale), P05 §8.6
   (the optimal proportions are unknown). Method cards: π0 (2410.24164), π0.5 (2504.16054), π0.7 (2604.15483), GR00T N1 (2503.14734),
   LingBot-VA (2601.21998), Qwen-RobotManip (2606.17846), DreamZero (2602.15922), EgoScale (2602.16710), Mobile ALOHA (2401.02117), Re-Mix (2408.14037).
   Toy: a fixed budget is split across the five layers. Each layer buys hour-equivalents at its own (toy) cost, returns diminish
   within a layer, and six capabilities fill up from what was bought. A deployment target weights the capabilities; its score is
   a weighted geometric mean, so a missing capability hurts. Costs, strengths and target weights are ours; see the ledger. */
(function () {
  "use strict";
  var RB = window.RB;
  var SID = "data";

  /* ---------- the toy model (all numbers ours; P05 gives only the qualitative ordering) ---------- */
  /* c = cost of one hour-equivalent in real-robot hours; h = hours after which a layer starts to repeat itself;
     a = strength on [perception, reasoning, action, world prediction, scene coverage, robot grounding] */
  var LAYERS = [
    { id: "real", name: "Real robot", short: "Real", c: 1, h: 150, a: [0.3, 0.1, 1.0, 0.6, 0.2, 1.0], col: "data-1" },
    { id: "umi", name: "UMI-style", short: "UMI", c: 0.3, h: 600, a: [0.3, 0.1, 0.7, 0.4, 0.55, 0.35], col: "data-2" },
    { id: "ego", name: "Egocentric human", short: "Ego", c: 0.06, h: 4000, a: [0.5, 0.3, 0.25, 0.65, 0.8, 0.05], col: "data-3" },
    { id: "sim", name: "Simulation", short: "Sim", c: 0.03, h: 8000, a: [0.2, 0.15, 0.6, 0.3, 0.4, 0.25], col: "data-4" },
    { id: "web", name: "General (web)", short: "Web", c: 0.004, h: 60000, a: [1.0, 1.0, 0, 0.15, 0.9, 0], col: "data-5" }
  ];
  var CAPS = ["Perception", "Reasoning", "Action", "World prediction", "Scene coverage", "Robot grounding"];
  var CAPS_SHORT = ["Perception", "Reasoning", "Action", "World pred.", "Coverage", "Grounding"];
  var GAIN = 1.1;
  var TARGETS = {
    seen: { label: "Seen tasks", long: "seen tasks on the target robot", w: [0.1, 0.05, 0.4, 0.05, 0.05, 0.35] },
    unseen: { label: "Unseen objects", long: "unseen objects and scenes", w: [0.2, 0.1, 0.25, 0.05, 0.25, 0.15] },
    long: { label: "Long instructions", long: "long-horizon language instructions", w: [0.15, 0.35, 0.2, 0.1, 0.1, 0.1] },
    world: { label: "World prediction", long: "predicting what happens next (a WAM)", w: [0.1, 0.05, 0.15, 0.45, 0.15, 0.1] }
  };
  var TKEYS = ["seen", "unseen", "long", "world"];

  /* published recipes: which layers each report uses (P05 §7.2.1 or the method card). The shares are ours. */
  var RECIPES = {
    pi0: { label: "π0", sh: [100, 0, 0, 0, 0], use: [1, 0, 0, 0, 0], scale: "903M timesteps; over 10,000 h", ref: "arXiv 2410.24164",
      note: "π0 pretrains on robot data only: its own 903M timesteps plus open datasets, weighted by n^0.43. Web knowledge enters through the vision-language model's initialization, not through the mixture." },
    pi05: { label: "π0.5", sh: [70, 0, 0, 0, 30], use: [1, 0, 0, 0, 1], scale: "about 400 h of home mobile data", ref: "arXiv 2504.16054",
      note: "π0.5 adds web data and subtask annotations. Removing web data barely changed in-distribution tasks but hurt out-of-distribution objects (arXiv 2504.16054)." },
    pi07: { label: "π0.7", sh: [55, 0, 20, 0, 25], use: [1, 0, 1, 0, 1], scale: "hours not stated", ref: "arXiv 2604.15483",
      note: "π0.7 adds egocentric human video and keeps failure and intervention data, labeled with metadata (P05 §7.2.1). Removing the most task-diverse 20% hurt unseen tasks." },
    groot: { label: "GR00T N1", sh: [40, 0, 20, 25, 15], use: [1, 0, 1, 1, 1], scale: "827 h neural, from 88 h teleoperation", ref: "arXiv 2503.14734",
      note: "GR00T N1 uses four layers: real teleoperation, human video with latent actions, simulation and neural trajectories, and web data (arXiv 2503.14734)." },
    lva: { label: "LingBot-VA", sh: [70, 15, 0, 15, 0], use: [1, 1, 0, 1, 0], scale: "about 16K h", ref: "arXiv 2601.21998",
      note: "LingBot-VA, a world action model, combines real-robot, UMI and simulation data (P05 §7.2.1): about 16K hours including InternData-A1 and UMI sets (arXiv 2601.21998)." },
    lva2: { label: "LingBot-VA 2.0", sh: [40, 15, 15, 15, 15], use: [1, 1, 1, 1, 1], scale: "hours not given", ref: "P05 §7.2.1",
      note: "LingBot-VA 2.0 extends its predecessor's recipe to all five layers of the pyramid (P05 §7.2.1). The survey does not give its proportions." },
    qwen: { label: "Qwen-RobotManip", sh: [35, 0, 40, 10, 15], use: [1, 0, 1, 1, 1], scale: "about 38,100 h; 24,808 h from ego video", ref: "P05 §7.2.1",
      note: "Qwen-RobotManip builds about 38,100 hours. Most of it is robot-compatible trajectories synthesized from egocentric video, plus open robot data, synthetic and vision-language data (P05 §7.2.1)." },
    xiaomi: { label: "Xiaomi-Robotics-1", sh: [15, 85, 0, 0, 0], use: [1, 1, 0, 0, 0], scale: "over 100,000 h UMI", ref: "P05 §7.2.1",
      note: "Xiaomi-Robotics-1 pretrains on more than 100,000 hours of UMI trajectories, then post-trains on about 10,000 hours, over 7,200 of them in-house robot data (P05 §7.2.1)." },
    dz: { label: "DreamZero", sh: [100, 0, 0, 0, 0], use: [1, 0, 0, 0, 0], scale: "about 500 h teleoperation", ref: "arXiv 2602.15922",
      note: "DreamZero trains on robot data only, about 500 hours, and still performs strongly. P05 notes that more sources are not proven to be better (P05 §7.2.1)." },
    ego: { label: "EgoScale", sh: [10, 0, 90, 0, 0], use: [1, 0, 1, 0, 0], scale: "20,854 h ego, 4 h robot", ref: "arXiv 2602.16710",
      note: "EgoScale pretrains on 20,854 hours of egocentric video, then mid-trains on about 50 hours of aligned human data and 4 hours of robot data (arXiv 2602.16710)." }
  };
  var RKEYS = ["pi0", "pi05", "pi07", "groot", "lva", "lva2", "qwen", "xiaomi", "dz", "ego"];

  function hours(sh, B) { var tot = sh.reduce(function (a, b) { return a + b; }, 0) || 1; return sh.map(function (s, k) { return (s / tot) * B / LAYERS[k].c; }); }
  function caps(sh, B) {
    var u = hours(sh, B), v = u.map(function (x, k) { return Math.log(1 + x / LAYERS[k].h); });
    return CAPS.map(function (_, j) { var s = 0; v.forEach(function (x, k) { s += x * LAYERS[k].a[j]; }); return 1 - Math.exp(-GAIN * s); });
  }
  function score(C, w) { var s = 0; w.forEach(function (x, j) { s += x * Math.log(C[j] + 0.01); }); return Math.max(0, Math.exp(s) - 0.01); }
  /* all splits of 100% into five shares in 5% steps (10,626 of them) */
  var GRID = (function () { var out = []; for (var a = 0; a <= 20; a++) for (var b = 0; b <= 20 - a; b++) for (var c = 0; c <= 20 - a - b; c++) for (var d = 0; d <= 20 - a - b - c; d++) out.push([a * 5, b * 5, c * 5, d * 5, (20 - a - b - c - d) * 5]); return out; })();
  function bestFor(B, w) { var bs = -1, bi = 0; for (var i = 0; i < GRID.length; i++) { var s = score(caps(GRID[i], B), w); if (s > bs) { bs = s; bi = i; } } return { sh: GRID[bi], s: bs }; }
  function b2s(v) { return Math.round(20 * Math.pow(10, v / 100 * Math.log10(150))); } /* slider 0..100 → budget 20..3000 */
  function s2b(B) { return Math.round(100 * Math.log10(B / 20) / Math.log10(150)); }
  function fmtH(x) { return x >= 10000 ? Math.round(x / 1000) + "k" : x >= 1000 ? (x / 1000).toFixed(1) + "k" : String(Math.round(x)); }
  function font(kind) { return getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); }
  function pressSeg(root, id, v) { RB.$$("#" + id + " button", root).forEach(function (b) { var on = b.value === v; b.setAttribute("aria-pressed", on ? "true" : "false"); b.tabIndex = on ? 0 : -1; }); }
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }

  function mount(api) {
    var id = SID, scene = api.scene, ctl = api.controls;
    var st = { recipe: "pi0", sh: RECIPES.pi0.sh.slice(), B: b2s(s2b(300)), target: "seen", chart: "sweep", sweep: 0 };
    var cur = null, best = null, search = null, raf = 0, searches = 0, ro = null, lastW = 0, chartT = 0, calcT = 0;

    scene.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Left: the five-layer pyramid shaded by budget share with the hours each layer buys. Right: six capabilities as a radar, current recipe against the best toy recipe"></canvas>' +
      RB.legend([{ c: "accent", label: "your recipe", kind: "area" }, { c: "ink-2", label: "best toy recipe for this target", kind: "dash" }]) +
      '<figcaption class="sb-caption">Read the pyramid for where the budget goes and how many hours it buys. On the radar, bold axes matter most for the chosen target; the dashed shape appears after a search.</figcaption></figure>' +
      RB.readouts([{ id: "score", k: "Target score (toy)" }, { id: "best", k: "Best toy score" }, { id: "real", k: "Real-robot hours", u: "h" }, { id: "total", k: "All hours bought", u: "h-eq" }, { id: "weak", k: "Weakest need", u: "–" }, { id: "layers", k: "Layers used" }]) +
      '<div id="' + id + '-chart"></div>' +
      '<div class="rb-stack"><h4 class="rb-h5">Published recipes by pyramid layer</h4><div class="sb-scroll-x" id="' + id + '-tab"></div>' +
      '<p class="sb-caption">Dots show which layers a report uses. Scale is as reported; P05 warns these totals are not comparable across modality, filtering and stage. <span class="sb-ref">P05 §7.2.1, Table 7</span></p></div>';
    ctl.innerHTML =
      '<div class="rb-stack">' +
      '<div class="rb-row"><label class="sb-field"><span>Published recipe</span><select class="sb-select" id="' + id + '-rec">' + RKEYS.map(function (k) { return '<option value="' + k + '"' + (k === "pi0" ? " selected" : "") + ">" + RECIPES[k].label + "</option>"; }).join("") + '<option value="custom">Custom</option></select></label>' +
      RB.seg({ id: id + "-tgt", label: "Deployment target", value: "seen", options: TKEYS.map(function (k) { return { value: k, label: TARGETS[k].label }; }) }) + "</div>" +
      '<div class="rb-row">' + LAYERS.map(function (L, k) { return RB.slider({ id: id + "-s" + k, label: L.short === "Web" ? "Web" : L.short === "Ego" ? "Egocentric" : L.short === "Sim" ? "Simulation" : L.name, min: 0, max: 100, step: 5, value: st.sh[k] }); }).join("") +
      RB.slider({ id: id + "-b", label: "Budget (h)", min: 0, max: 100, step: 1, value: s2b(300), fmt: function (v) { return String(b2s(v)); } }) + "</div>" +
      '<div class="rb-row">' + RB.seg({ id: id + "-ch", label: "Chart", value: "sweep", options: [{ value: "sweep", label: "Layer sweep" }, { value: "budget", label: "Budget sweep" }] }) +
      '<label class="sb-field"><span>Swept layer</span><select class="sb-select" id="' + id + '-sw">' + LAYERS.map(function (L, k) { return '<option value="' + k + '">' + L.name + "</option>"; }).join("") + "</select></label>" +
      '<button class="sb-btn" type="button" id="' + id + '-apply" disabled>Use best mix</button>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Search best mix ▶</button></div></div>';
    api.side.innerHTML = '<p class="rb-muted" id="' + id + '-note">–</p>' +
      RB.eqBlock({ name: "Hours a share buys", ref: "Our toy model", tex: "u_k = \\frac{s_k\\, B}{c_k}, \\qquad v_k = \\ln\\!\\left(1 + \\frac{u_k}{h_k}\\right)", words: "Cheap layers buy many hours, but each layer's value grows only logarithmically once it starts repeating itself.", key: [{ glyph: "s_k", meaning: "budget share of layer k" }, { glyph: "B", meaning: "budget in real-robot hours" }, { glyph: "c_k", meaning: "cost per hour-equivalent" }, { glyph: "h_k", meaning: "hours before returns diminish" }] }) +
      RB.eqBlock({ name: "Capabilities fill up", ref: "Our toy model · P05 §1", tex: "C_j = 1 - e^{-g \\sum_k a_{kj} v_k}", words: "Each capability fills from the layers that carry it, and never passes 1.", key: [{ glyph: "a_kj", meaning: "strength of layer k on capability j" }, { glyph: "g", meaning: "gain, 1.1 here" }] }) +
      RB.eqBlock({ name: "Target score", ref: "Our toy model · P05 §7", tex: "\\mathrm{score} = \\prod_j C_j^{\\,w_j}", words: "A weighted geometric mean: one missing capability drags the whole score down.", key: [{ glyph: "w_j", meaning: "target weight on capability j" }] }) +
      '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
      "<li>π0: 903M timesteps, sources weighted by n^0.43 <span class=\"sb-ref\">arXiv 2410.24164</span></li>" +
      "<li>Mobile ALOHA: 50/50 batches; Wipe Wine 95% with co-training, 50% without <span class=\"sb-ref\">arXiv 2401.02117</span></li>" +
      "<li>Re-Mix: learned weights beat uniform by 38% on average <span class=\"sb-ref\">arXiv 2408.14037</span></li>" +
      "<li>EgoScale: task completion 0.30 at 1k h of human video, 0.71 at 20k h <span class=\"sb-ref\">arXiv 2602.16710</span></li>" +
      "<li>DreamZero: diverse data 50% vs repetitive 33% task progress, same hours <span class=\"sb-ref\">arXiv 2602.15922</span></li></ul>";

    var cv = scene.querySelector("#" + id + "-cv"), chartHost = scene.querySelector("#" + id + "-chart"), tabHost = scene.querySelector("#" + id + "-tab");
    var recSel = ctl.querySelector("#" + id + "-rec"), swSel = ctl.querySelector("#" + id + "-sw"), applyBtn = ctl.querySelector("#" + id + "-apply"), goBtn = ctl.querySelector("#" + id + "-go");

    function setSliders() { LAYERS.forEach(function (L, k) { var inp = ctl.querySelector("#" + id + "-s" + k), out = ctl.querySelector('[data-out="' + id + "-s" + k + '"]'); inp.value = st.sh[k]; if (out) out.textContent = st.sh[k]; }); }
    function clearBest() { stopSearch(); best = null; applyBtn.disabled = true; }

    function compute() {
      var C = caps(st.sh, st.B), T = TARGETS[st.target], u = hours(st.sh, st.B), tot = st.sh.reduce(function (a, b) { return a + b; }, 0);
      cur = { C: C, s: tot > 0 ? score(C, T.w) : 0, u: u, tot: tot };
      RB.setRO(scene, "score", tot > 0 ? RB.fmt(cur.s, 2) : "–");
      RB.setRO(scene, "best", best ? RB.fmt(best.s, 2) : "–");
      RB.setRO(scene, "real", tot > 0 ? fmtH(u[0]) : "–");
      RB.setRO(scene, "total", tot > 0 ? fmtH(u.reduce(function (a, b) { return a + b; }, 0)) : "–");
      var wk = -1; C.forEach(function (c, j) { if (T.w[j] >= 0.1 && (wk < 0 || c < C[wk])) wk = j; });
      RB.setRO(scene, "weak", tot > 0 ? RB.fmt(C[wk], 2) : "–"); var wu = scene.querySelector('[data-ro="weak"]').nextElementSibling; if (wu) wu.textContent = tot > 0 ? CAPS[wk].toLowerCase() : "–";
      RB.setRO(scene, "layers", tot > 0 ? String(st.sh.filter(function (x) { return x > 0; }).length) + " of 5" : "–");
      var r = RECIPES[st.recipe];
      document.getElementById(id + "-note").textContent = (r ? r.note + " Shares in the preset are ours." : "Custom recipe: no paper behind these shares.") + " Target: " + T.long + ".";
      api.meta("budget " + st.B + " real-robot h · target: " + T.label.toLowerCase());
      drawTable(); draw();
    }

    function drawTable() {
      tabHost.innerHTML = '<table class="sb-table sb-table--compact"><thead><tr><th scope="col">Model</th>' + LAYERS.map(function (L) { return '<th scope="col">' + L.short + "</th>"; }).join("") + '<th scope="col">Reported scale</th></tr></thead><tbody>' +
        RKEYS.map(function (k) {
          var r = RECIPES[k];
          return "<tr" + (k === st.recipe ? ' aria-current="true" style="background:var(--accent-soft)"' : "") + '><th scope="row" style="vertical-align:top">' + r.label + "</th>" +
            r.use.map(function (u, j) { return '<td style="text-align:center;vertical-align:top">' + (u ? '<span aria-label="uses ' + LAYERS[j].name + '" style="display:inline-block;width:10px;height:10px;border-radius:5px;background:var(--' + LAYERS[j].col + ')"></span>' : '<span class="rb-muted" aria-label="does not use">·</span>') + "</td>"; }).join("") +
            '<td class="rb-muted" style="vertical-align:top">' + r.scale + ' <span class="sb-ref">' + r.ref + "</span></td></tr>";
        }).join("") + "</tbody></table>";
    }

    /* ----- canvas: pyramid (left or top) and capability radar (right or bottom) ----- */
    function draw() {
      if (!cur || !cv.isConnected) return;
      var P = RB.pal(), W = Math.max(300, Math.min(920, cv.parentNode.clientWidth || 720)), wide = W >= 620, mono = font("mono"), body = font("body");
      var pyW = wide ? Math.round(W * 0.5) : W, pyH = 270, rdW = wide ? W - pyW : W, rdH = wide ? pyH : 300, H = wide ? pyH : pyH + rdH;
      var c = RB.canvas(cv, W, H);
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      /* pyramid */
      var top = 30, bh = 46, cx = Math.round(pyW * 0.26) + 8, maxW = Math.round(pyW * 0.48), labX = cx + Math.round(maxW / 2) + 12;
      var tot = cur.tot || 1;
      c.font = "600 11px " + mono; c.fillStyle = P["ink-3"]; c.textAlign = "left"; c.fillText("robot alignment ↑  scalability ↓", 8, 16);
      for (var k = 0; k < 5; k++) {
        var y0 = top + k * bh, y1 = y0 + bh - 4, w0 = 18 + k * (maxW - 18) / 5, w1 = 18 + (k + 1) * (maxW - 18) / 5, share = st.sh[k] / tot;
        c.beginPath(); c.moveTo(cx - w0 / 2, y0); c.lineTo(cx + w0 / 2, y0); c.lineTo(cx + w1 / 2, y1); c.lineTo(cx - w1 / 2, y1); c.closePath();
        c.fillStyle = P["surface-sunk"]; c.fill();
        c.globalAlpha = cur.tot > 0 ? 0.12 + 0.88 * share : 0.12; c.fillStyle = P[LAYERS[k].col]; c.fill(); c.globalAlpha = 1;
        c.strokeStyle = st.chart === "sweep" && st.sweep === k ? P.ink : P["line-strong"]; c.lineWidth = st.chart === "sweep" && st.sweep === k ? 2 : 1; c.stroke();
        c.fillStyle = P.ink; c.font = "600 12px " + body; c.fillText(LAYERS[k].name, labX, y0 + 16);
        c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono;
        c.fillText(cur.tot > 0 ? Math.round(share * 100) + "% → " + fmtH(cur.u[k]) + " h" : "–", labX, y0 + 32);
      }
      /* radar */
      var ox = wide ? pyW : 0, oy = wide ? 0 : pyH, rcx = ox + rdW / 2, rcy = oy + rdH / 2 + 12, R = Math.max(60, Math.min(rdW / 2 - 78, rdH / 2 - 46)), n = CAPS.length, T = TARGETS[st.target];
      function pt(j, r) { var ang = -Math.PI / 2 + j * 2 * Math.PI / n; return [rcx + Math.cos(ang) * r, rcy + Math.sin(ang) * r]; }
      c.strokeStyle = P.line || P["line-strong"]; c.lineWidth = 1;
      [0.25, 0.5, 0.75, 1].forEach(function (f) { c.beginPath(); for (var j = 0; j <= n; j++) { var p = pt(j % n, R * f); if (j) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); } c.stroke(); });
      for (var j = 0; j < n; j++) {
        var pe = pt(j, R); c.beginPath(); c.moveTo(rcx, rcy); c.lineTo(pe[0], pe[1]); c.stroke();
        var pl = pt(j, R + 14), strong = T.w[j] >= 0.2;
        c.fillStyle = strong ? P.ink : P["ink-3"]; c.font = (strong ? "700 " : "500 ") + "12px " + body;
        c.textAlign = Math.abs(pl[0] - rcx) < 4 ? "center" : pl[0] > rcx ? "left" : "right";
        c.fillText(CAPS_SHORT[j], pl[0], pl[1] + (pl[1] < rcy - 4 ? -2 : pl[1] > rcy + 4 ? 12 : 4));
      }
      c.textAlign = "left";
      function poly(C) { c.beginPath(); C.forEach(function (v, j) { var p = pt(j, R * Math.max(0.01, v)); if (j) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); }); c.closePath(); }
      if (cur.tot > 0) { poly(cur.C); c.globalAlpha = 0.22; c.fillStyle = P.accent; c.fill(); c.globalAlpha = 1; c.strokeStyle = P.accent; c.lineWidth = 2; c.stroke(); cur.C.forEach(function (v, j) { var p = pt(j, R * v); c.fillStyle = P.accent; c.beginPath(); c.arc(p[0], p[1], 3, 0, Math.PI * 2); c.fill(); }); }
      var shown = search ? search.best : best;
      if (shown) { poly(caps(shown.sh, st.B)); c.setLineDash([6, 4]); c.strokeStyle = P["ink-2"]; c.lineWidth = 1.8; c.stroke(); c.setLineDash([]); }
      c.font = "500 11px " + mono; c.fillStyle = P["ink-3"];
      c.fillText(search ? "searching " + Math.round(100 * search.i / GRID.length) + "%" : shown ? "best: " + shown.sh.map(function (x, q) { return LAYERS[q].short + " " + x; }).filter(function (s, q) { return shown.sh[q] > 0; }).join(" · ") : "press Search to find the toy optimum", ox + 8, oy + 14);
    }

    /* ----- chart ----- */
    function drawChart() {
      chartHost.innerHTML = "";
      if (st.chart === "sweep") {
        var k = st.sweep, rest = st.sh.map(function (x, q) { return q === k ? 0 : x; }), rs = rest.reduce(function (a, b) { return a + b; }, 0);
        if (rs === 0) rest = rest.map(function (x, q) { return q === k ? 0 : 1; }), rs = 4;
        var series = TKEYS.map(function (t, i) {
          var pts = [];
          for (var p = 0; p <= 100; p += 5) { var sh = rest.map(function (x, q) { return q === k ? p : x / rs * (100 - p); }); pts.push([p, +score(caps(sh, st.B), TARGETS[t].w).toFixed(3)]); }
          return { name: TARGETS[t].label, color: ["data-1", "data-2", "data-5", "data-4"][i], points: pts, dash: t !== st.target };
        });
        var curShare = cur.tot > 0 ? Math.round(100 * st.sh[k] / cur.tot) : 0;
        StudyBench.lineChart(chartHost, {
          title: "Target score as one layer takes more of the budget", x: { label: LAYERS[k].name + " share (%)", min: 0, max: 100 }, y: { label: "toy score", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(2); } },
          series: series, directLabels: false,
          caption: "The other layers keep their relative weights. Your share is " + curShare + "%. Where a solid curve peaks inside the range, mixing beats both extremes."
        });
      } else {
        var T = TARGETS[st.target], pts = LAYERS.map(function () { return []; });
        for (var d = 0; d <= 7; d++) { var B = 25 * Math.pow(2, d), b = bestFor(B, T.w); b.sh.forEach(function (x, q) { pts[q].push([d, x]); }); }
        StudyBench.lineChart(chartHost, {
          title: "Best toy share of each layer as the budget doubles", x: { label: "budget doublings (0 = 25 h, 7 = 3,200 h)", min: 0, max: 7, ticks: [0, 1, 2, 3, 4, 5, 6, 7] }, y: { label: "best share (%)", min: 0, max: 100, fmt: function (v) { return String(Math.round(v)); } },
          series: LAYERS.map(function (L, q) { return { name: L.name, color: L.col, points: pts[q] }; }), directLabels: false,
          caption: "For " + T.long + ". A small budget goes mostly to the real robot; as it grows, the toy spreads it down the pyramid. Real optima are unknown (P05 §8.6)."
        });
      }
    }
    function chartSoon() { clearTimeout(chartT); chartT = setTimeout(drawChart, 160); }
    function calcSoon() { clearTimeout(calcT); calcT = setTimeout(function () { compute(); chartSoon(); }, 30); }

    /* ----- animated exhaustive search over 10,626 splits ----- */
    function stopSearch() { if (raf) cancelAnimationFrame(raf); raf = 0; if (search) { search = null; api.live("paused", "Search stopped"); } goBtn.disabled = false; }
    function runSearch() {
      stopSearch(); best = null; applyBtn.disabled = true;
      var T = TARGETS[st.target];
      search = { i: 0, best: { sh: GRID[0], s: -1 } };
      goBtn.disabled = true; api.live("running", "Searching 10,626 splits");
      (function tick() {
        if (!search) return;
        var end = Math.min(GRID.length, search.i + 260);
        for (; search.i < end; search.i++) { var s = score(caps(GRID[search.i], st.B), T.w); if (s > search.best.s) search.best = { sh: GRID[search.i], s: s }; }
        draw();
        if (search.i >= GRID.length) { best = search.best; search = null; raf = 0; searches++; goBtn.disabled = false; applyBtn.disabled = false; api.live("paused", "Best toy score " + RB.fmt(best.s, 2)); compute(); return; }
        raf = requestAnimationFrame(tick);
      })();
    }

    function toCustom() { st.recipe = "custom"; recSel.value = "custom"; }
    recSel.addEventListener("change", function () { var k = recSel.value; st.recipe = k; if (RECIPES[k]) { st.sh = RECIPES[k].sh.slice(); setSliders(); } compute(); chartSoon(); });
    bindSeg(ctl, id + "-tgt", function (v) { st.target = v; clearBest(); compute(); chartSoon(); });
    LAYERS.forEach(function (L, k) { RB.bindSlider(ctl, id + "-s" + k, null, function (v) { st.sh[k] = v; toCustom(); calcSoon(); }); });
    RB.bindSlider(ctl, id + "-b", function (v) { return String(b2s(v)); }, function (v) { st.B = b2s(v); clearBest(); calcSoon(); });
    bindSeg(ctl, id + "-ch", function (v) { st.chart = v; swSel.disabled = v !== "sweep"; draw(); drawChart(); });
    swSel.addEventListener("change", function () { st.sweep = +swSel.value; draw(); chartSoon(); });
    goBtn.addEventListener("click", runSearch);
    applyBtn.addEventListener("click", function () { if (!best) return; st.sh = best.sh.slice(); toCustom(); setSliders(); compute(); chartSoon(); });
    if (window.ResizeObserver) { ro = new ResizeObserver(function () { var w = scene.clientWidth; if (Math.abs(w - lastW) < 2) return; lastW = w; draw(); chartSoon(); }); ro.observe(scene); }
    compute(); drawChart();
    RB.onTheme(function () { if (cv.isConnected) { draw(); drawChart(); } });

    function state() { return { recipe: st.recipe, target: st.target, B: st.B, chart: st.chart, sweep: st.sweep, sh: st.sh.slice(), score: cur ? cur.s : 0, best: best ? best.s : null, searching: !!search, searches: searches }; }
    return {
      state: state,
      destroy: function () { if (raf) cancelAnimationFrame(raf); raf = 0; search = null; clearTimeout(chartT); clearTimeout(calcT); if (ro) ro.disconnect(); },
      demo: function () {
        var q = function (s) { return scene.querySelector(s) || ctl.querySelector(s); }, S = state;
        function pick(sel, v) { return function (a) { sel.value = v; sel.dispatchEvent(new Event("change", { bubbles: true })); return a.wait(300); }; }
        return [
          { target: q("#" + id + "-cv"), title: "One budget, five layers", text: "π0 spends everything on real-robot data. The radar shows strong action and grounding, weak perception and reasoning: web knowledge came only from its initialization." },
          { target: recSel, title: "Add web data", text: "π0.5 moved part of the budget to web data. Perception and reasoning grow; action barely drops.", do: pick(recSel, "pi05"), task: "Choose the π0.5 recipe", expect: function () { return S().recipe === "pi05"; } },
          { target: q("#" + id + "-tgt"), title: "Change what you deploy for", text: "Unseen objects weight perception and scene coverage more. The same recipe now scores differently.", do: function (a) { return a.click(q("#" + id + '-tgt [value="unseen"]')); }, task: "Choose the Unseen objects target", expect: function () { return S().target === "unseen"; } },
          { target: goBtn, title: "Search the toy optimum", text: "The search tries all 10,626 splits in 5% steps. The dashed shape is the best toy recipe for this target and budget.", do: function (a) { return a.click(goBtn).then(function () { return a.until(function () { return !S().searching && S().best != null; }, 8000); }); }, task: "Press Search best mix", expect: function () { return S().best != null; } },
          { target: q("#" + id + "-ch"), title: "Budget moves the optimum", text: "At 25 h the toy spends almost all on the real robot. As the budget doubles, cheaper layers take over.", do: function (a) { return a.click(q("#" + id + '-ch [value="budget"]')); }, task: "Show the Budget sweep chart", expect: function () { return S().chart === "budget"; } },
          { target: recSel, title: "Robot data only still works", text: "DreamZero used about 500 hours of robot data only and performed strongly. P05 says more sources are not proven better.", do: pick(recSel, "dz"), task: "Choose the DreamZero recipe", expect: function () { return S().recipe === "dz"; } },
          { target: q("#" + id + "-tab"), title: "Your turn", text: "Pick the World prediction target and compare LingBot-VA with LingBot-VA 2.0. Which layer lifts world prediction in the toy?" }
        ];
      }
    };
  }

  RB.station({
    id: SID, name: "Data recipe mixer", sub: "13 · 14",
    refs: ["P05 §1, §7.2.1", "P05 §8.6", "P05 Table 7"], prov: "Illustrative: toy utility model",
    summary: "Split a fixed data budget across the five pyramid layers, choose what the robot must do, and see which capabilities fill up. Compare with published recipes and search the toy's best mix.",
    notice: [
      "Cheap layers buy far more hours, but hours from one layer repeat themselves, so returns diminish.",
      "Without real-robot data the grounding axis stays near zero, whatever else you add.",
      "The best toy mix depends on the target and on the budget: small budgets favor the apex.",
      "The toy assumes layers complement each other. P05 says the real optimum is unknown and more sources are not proven better."
    ],
    card: "Split a data budget across the pyramid and compare published recipes.",
    terms: {
      "compute-matched-ablation": { name: "compute-matched ablation", aliases: ["data ablation"], group: "data", def: "An experiment that removes or swaps one data source while keeping training compute fixed, so any difference comes from the data itself.", note: "P05 notes such ablations of single datasets and data categories remain limited, so recipe claims are hard to compare.", ref: "P05 §8.6", scene: "system", focus: ["data-robot", "data-web", "policy-update"], look: "one source swapped, compute fixed", uses: [] }
    },
    ledger: [
      { where: "Lab · Data recipe mixer · model", source: "P05 §1 orders the layers by scalability and robot alignment and describes each qualitatively", page: "Toy costs per hour, diminishing-returns scales and capability strengths chosen by us", why: "Shows the trade-off mechanism; scores are not predictions of real model performance.", kind: "Simplified" },
      { where: "Lab · Data recipe mixer · capabilities", source: "P05 relates data to perception, reasoning, planning, action generation and world prediction", page: "Six axes: reasoning and planning merged, scene coverage and robot grounding added", why: "Coverage and grounding carry P05's diversity and robot-alignment dimensions.", kind: "Our choice" },
      { where: "Lab · Data recipe mixer · score", source: "P05 §7.2.1: current evidence does not establish that more data sources are inherently preferable", page: "A weighted geometric mean, which rewards covering every capability and so favors mixtures", why: "Complementarity is P05's argument, not an established result; the notice says so.", kind: "Simplified" },
      { where: "Lab · Data recipe mixer · presets", source: "P05 §7.2.1 and method cards state which layers each model uses; proportions are rarely published", page: "Layer presence follows the sources; the shares inside each preset are ours", why: "Makes recipes comparable in one budget; each preset note says what the paper states.", kind: "Our choice" },
      { where: "Lab · Data recipe mixer · Qwen-RobotManip", source: "P05 counts 24,808 h synthesized from egocentric video; the method card calls them robot-compatible trajectories", page: "Counted in the egocentric layer", why: "Their origin is human video; the synthesis step is what aligns them to robots.", kind: "Our choice" },
      { where: "Lab · Data recipe mixer · π0", source: "π0 has web knowledge from its vision-language initialization but pretrains on robot data only", page: "Preset uses 100% real-robot data and the toy ignores initialization", why: "The mixer models data mixtures, not model initialization.", kind: "Simplified" }
    ],
    mount: mount
  });
})();
