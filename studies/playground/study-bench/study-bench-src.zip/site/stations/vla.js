/* Lab station · VLA dissector (topic 08, b4). Sources: P02 §IV-A and Fig. 4 (seven sensorimotor cells); X2 §5.3–5.4, Figs. 37–39
   (π0 blockwise causal mask, KV caching, SmolVLA interleaved CA/SA, 450M vs 3.3B); method cards: RT-1, Octo, RDT-1B, OpenVLA,
   DexVLA, π0, GR00T N1, SmolVLA.
   Toy: a handful of tokens per block stands in for the real sequence. The bench counts which query rows a transformer layer must
   compute at each decoding or denoising step, with and without a key-value cache. Parameter counts come from the method cards;
   weight memory is our arithmetic (parameters × bytes per parameter). */
(function () {
  "use strict";
  var RB = window.RB;

  /* ---------- facts (method cards and P02) ---------- */
  var HEADS = [{ value: "tok", label: "Tokens" }, { value: "dh", label: "Diffusion head" }, { value: "fh", label: "Flow head" }, { value: "dit", label: "DiT" }];
  var CELLS = {
    "tf-tok": { n: "1", name: "Transformer + discrete action token", ex: "Gato, VIMA, RT-1", model: "rt1" },
    "tf-dh": { n: "2", name: "Transformer + diffusion action head", ex: "Octo, NoMAD, TinyVLA", model: "octo" },
    "tf-fh": { n: "–", name: "No cell in P02 Fig. 4", ex: "P02 lists flow heads only after a VLM backbone (cells 6 and 7)", model: null },
    "tf-dit": { n: "3", name: "Diffusion transformer", ex: "RDT-1B, LBM, MDT, Dita", model: "rdt" },
    "vlm-tok": { n: "4", name: "VLM + discrete action token", ex: "RT-2, OpenVLA, RT-H, ECoT", model: "openvla" },
    "vlm-dh": { n: "5", name: "VLM + diffusion action head", ex: "DiffusionVLA, DexVLA, GO-1", model: "dexvla" },
    "vlm-fh": { n: "6", name: "VLM + flow matching action head", ex: "π0, GraspVLA, Hume", model: "pi0" },
    "vlm-dit": { n: "7", name: "VLM + diffusion transformer", ex: "GR00T N1, CogACT, SmolVLA", model: "gr00t" }
  };
  /* params in billions; bb = backbone part, hd = action module part (null when the card gives no split) */
  var MODELS = {
    rt1: { name: "RT-1", cell: "tf-tok", total: 0.035, bb: 0.035, hd: 0, size: "35M", split: "one 35M model; 19M in the transformer", out: "11 action tokens in one pass", ref: "arXiv 2212.06817" },
    octo: { name: "Octo-Base", cell: "tf-dh", total: 0.093, bb: 0.093, hd: 0, size: "93M", split: "27M in Octo-Small", out: "action chunk from a diffusion head", ref: "arXiv 2405.12213" },
    rdt: { name: "RDT-1B", cell: "tf-dit", total: 1.2, bb: 1.2, hd: 0, size: "1.2B", split: "one diffusion transformer, 28 layers", out: "64-action chunk", ref: "arXiv 2410.07864" },
    openvla: { name: "OpenVLA", cell: "vlm-tok", total: 7, bb: 7, hd: 0, size: "7B", split: "Prismatic-7B; actions are Llama 2 tokens", out: "one 7-D action as 7 tokens", ref: "arXiv 2406.09246" },
    dexvla: { name: "DexVLA", cell: "vlm-dh", total: 3, bb: 2, hd: 1, size: "about 3B", split: "2B Qwen2-VL + 1B diffusion expert", out: "continuous joint actions", ref: "arXiv 2502.05855" },
    pi0: { name: "π0", cell: "vlm-fh", total: 3.3, bb: 3, hd: 0.3, size: "3.3B", split: "3B PaliGemma + 300M action expert", out: "50-action chunk, 10 Euler steps", ref: "arXiv 2410.24164" },
    gr00t: { name: "GR00T N1", cell: "vlm-dit", total: 2.2, bb: 1.34, hd: 0.86, size: "2.2B", split: "1.34B in the VLM, the rest in the DiT and adapters", out: "16-action chunk, 4 flow steps", ref: "arXiv 2503.14734" },
    smolvla: { name: "SmolVLA", cell: "vlm-dit", total: 0.45, bb: 0.35, hd: 0.1, size: "0.45B", split: "SmolVLM-2 (first 16 layers) + about 100M expert", out: "50-action chunk, 10 flow steps", ref: "arXiv 2506.01844" }
  };
  var BAR_ORDER = ["openvla", "pi0", "dexvla", "gr00t", "rdt", "smolvla", "octo", "rt1"];
  var PRESETS = {
    openvla: { mode: "ar", K: 10, label: "OpenVLA" },
    pi0: { mode: "block", K: 10, label: "π0" },
    smolvla: { mode: "smol", K: 10, label: "SmolVLA" },
    gr00t: { mode: "smol", K: 4, label: "GR00T N1" }
  };
  var MODES = [{ value: "block", label: "π0 blocks" }, { value: "smol", label: "SmolVLA" }, { value: "ar", label: "Causal" }, { value: "full", label: "No mask" }];
  var MODE_NOTE = {
    block: "π0 puts images and text, the state, and the actions in three blocks. A token sees its own block and earlier blocks, so the VLM never reads action tokens (X2 §5.3, Fig. 37).",
    smol: "SmolVLA's expert alternates layers: cross-attention reads the VLM's keys and values, and causal self-attention links the action tokens. The state token sits in the VLM prefix (X2 §5.4, arXiv 2506.01844).",
    ar: "OpenVLA writes one 7-D action as 7 tokens, one decoding pass each, with no action chunk (arXiv 2406.09246). The cache keeps the prefix and the tokens already written.",
    full: "Hypothetical: every token sees every other. Prefix tokens now read noisy actions that change at each step, so their keys and values must be recomputed every step."
  };
  var BYTES = { fp32: 4, bf16: 2, int4: 0.5 };
  var D_AR = 7, IMG_PER_CAM = 3, TXT = 3;

  /* ---------- token model (toy counts) ---------- */
  function tokens(mode, cams, H) {
    var out = [], i;
    for (i = 0; i < cams * IMG_PER_CAM; i++) out.push("img");
    for (i = 0; i < TXT; i++) out.push("txt");
    if (mode !== "ar") out.push("st");
    var A = mode === "ar" ? D_AR : H;
    for (i = 0; i < A; i++) out.push("act");
    return out;
  }
  var BLK = { img: 0, txt: 0, st: 1, act: 2 };
  function allowed(mode, layer, T, i, j) {
    var bi = T[i], bj = T[j];
    if (mode === "full") return true;
    if (mode === "block") return BLK[bj] <= BLK[bi];
    if (mode === "ar") return j <= i;
    /* smol: prefix (images, text, state) is one block; the expert's action rows use CA or SA */
    if (bi !== "act") return bj !== "act";
    if (layer === "ca") return bj !== "act";
    return bj === "act" && j <= i;
  }
  /* rows (query tokens) computed at step s (1-based) and whether keys/values of a column are cached */
  function plan(mode, cache, T, S, s) {
    var P = T.filter(function (b) { return b !== "act"; }).length, N = T.length, rows = [], i;
    var canCache = cache && mode !== "full";
    if (s < 1) return { rows: [], cached: [] };
    if (mode === "ar") {
      if (canCache) { if (s === 1) for (i = 0; i < P; i++) rows.push(i); else rows.push(P + s - 2); }
      else for (i = 0; i < P + s - 1; i++) rows.push(i);
      var cached = []; if (canCache) for (i = 0; i < P + s - 1; i++) if (rows.indexOf(i) < 0) cached.push(i);
      return { rows: rows, cached: cached };
    }
    if (canCache && s > 1) { for (i = P; i < N; i++) rows.push(i); var c2 = []; for (i = 0; i < P; i++) c2.push(i); return { rows: rows, cached: c2 }; }
    for (i = 0; i < N; i++) rows.push(i);
    return { rows: rows, cached: [] };
  }
  function totals(mode, cache, T, S) { var t = 0; for (var s = 1; s <= S; s++) t += plan(mode, cache, T, S, s).rows.length; return t; }

  function mount(api) {
    var id = api.id, sc = api.scene, ct = api.controls;
    var st = { preset: "pi0", model: "pi0", bb: "vlm", head: "fh", mode: "block", layer: "ca", cams: 2, H: 6, K: 10, cache: true, prec: "bf16", s: 0 };
    var dead = false, timer = 0, chartT = 0, stepped = 0, playing = false;

    sc.innerHTML =
      '<figure class="rb-fig"><div id="' + id + '-cells" style="max-width:560px"></div><figcaption class="sb-caption">The seven cells of P02 Fig. 4: two backbones by four ways to output actions. Click a cell; the accent cell is the model on the bench.</figcaption></figure>' +
      '<div class="rb-well" id="' + id + '-facts"></div>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-mask" aria-label="Attention mask: rows are query tokens, columns are the keys and values they may read"></canvas><figcaption class="sb-caption">Row = a token asking, column = a token it may read. Accent rows are computed at this step; the strip on top shows keys and values computed now, cached, or idle.</figcaption></figure>' +
      RB.legend([{ c: "data-1", label: "may attend" }, { c: "bad", label: "prefix reads actions" }, { c: "accent", label: "computed this step" }, { c: "data-3", label: "read from cache" }]) +
      '<p class="sb-caption" id="' + id + '-stepline"></p>' +
      RB.readouts([{ id: "cell", k: "Cell in P02 Fig. 4" }, { id: "par", k: "Parameters", u: "model on the bench" }, { id: "mem", k: "Weights memory", u: "GB, our arithmetic" }, { id: "now", k: "Rows this step" }, { id: "tot", k: "Rows per chunk" }, { id: "nocache", k: "Rows without cache" }, { id: "save", k: "Cache saves" }, { id: "valid", k: "Prefix cache" }]) +
      '<p class="sb-caption" id="' + id + '-note"></p>' +
      '<div id="' + id + '-chart"></div>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-bars" aria-label="Parameter counts of eight models, split into backbone and action module, with weight memory"></canvas><figcaption class="sb-caption">Bars: parameters from the method cards, backbone and action module. Right column: weight memory at the chosen precision, our arithmetic without activations or cache.</figcaption></figure>';

    ct.innerHTML =
      '<div class="rb-stack"><span class="sb-caption">Preset</span>' + RB.seg({ id: id + "-pre", label: "Preset", value: st.preset, options: Object.keys(PRESETS).map(function (k) { return { value: k, label: PRESETS[k].label }; }) }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Backbone</span>' + RB.seg({ id: id + "-bb", label: "Backbone", value: st.bb, options: [{ value: "tf", label: "Transformer" }, { value: "vlm", label: "Pretrained VLM" }] }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Action output</span>' + RB.seg({ id: id + "-head", label: "Action output", value: st.head, options: HEADS }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Attention mask</span>' + RB.seg({ id: id + "-mode", label: "Attention mask", value: st.mode, options: MODES }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Expert layer (SmolVLA)</span>' + RB.seg({ id: id + "-layer", label: "Expert layer", value: st.layer, options: [{ value: "ca", label: "Cross-attention" }, { value: "sa", label: "Self-attention" }] }) + "</div>" +
      RB.slider({ id: id + "-cams", label: "Cameras", min: 1, max: 3, step: 1, value: st.cams }) +
      RB.slider({ id: id + "-h", label: "Action tokens drawn", min: 2, max: 8, step: 1, value: st.H }) +
      RB.slider({ id: id + "-k", label: "Flow steps K", min: 1, max: 10, step: 1, value: st.K }) +
      '<label class="rb-row" style="gap:8px"><input type="checkbox" id="' + id + '-cache" checked><span>Key-value cache</span></label>' +
      '<div class="rb-stack"><span class="sb-caption">Weight precision</span>' + RB.seg({ id: id + "-prec", label: "Weight precision", value: st.prec, options: [{ value: "fp32", label: "fp32" }, { value: "bf16", label: "bf16" }, { value: "int4", label: "int4" }] }) + "</div>" +
      '<div class="sb-btn-row"><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-step">Step ▶</button><button class="sb-btn" type="button" id="' + id + '-play">Play chunk</button><button class="sb-btn sb-btn--ghost" type="button" id="' + id + '-reset">Reset</button></div>';

    var q = function (s) { return sc.querySelector(s) || ct.querySelector(s); };
    var maskCv = q("#" + id + "-mask"), barCv = q("#" + id + "-bars");
    var font = function (w, px, kind) { return w + " " + px + "px " + getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); };
    function S() { return st.mode === "ar" ? D_AR : st.K; }
    function T() { return tokens(st.mode, st.cams, st.H); }

    /* ---------- cell grid (SVG) ---------- */
    function drawCells() {
      var host = q("#" + id + "-cells"), cols = HEADS.map(function (h) { return h.value; }), nar = (host.parentNode.clientWidth || 560) < 460;
      var rows = [["tf", nar ? "TF" : "Transformer"], ["vlm", "VLM"]], X0 = nar ? 46 : 110, DX = nar ? 88 : 104, CW = nar ? 82 : 96, VW = nar ? 400 : 560;
      var s = '<svg class="rb-svg" viewBox="0 0 ' + VW + ' 196" role="img" aria-label="Grid of the seven VLA cells of P02 Fig. 4: two backbones by four action outputs">';
      HEADS.forEach(function (h, ci) { s += '<text x="' + (X0 + CW / 2 + ci * DX) + '" y="18" text-anchor="middle" class="rb-t-mono" style="font-size:13px">' + (h.value === "dh" ? "Diffusion" : h.value === "fh" ? "Flow" : h.label) + "</text>"; });
      rows.forEach(function (r, ri) {
        var y = 30 + ri * 82;
        s += '<text x="6" y="' + (y + 42) + '" class="rb-t-ink" style="font-size:15px">' + r[1] + "</text>";
        cols.forEach(function (c, ci) {
          var key = r[0] + "-" + c, cell = CELLS[key], x = X0 + ci * DX, on = r[0] === st.bb && c === st.head, rep = cell.model ? MODELS[cell.model].name : "–";
          s += '<g data-cell="' + key + '" style="cursor:pointer" role="button" tabindex="0" aria-label="Cell ' + cell.n + ": " + RB.esc(cell.name) + '"><rect x="' + x + '" y="' + y + '" width="' + CW + '" height="74" rx="6" class="' + (on ? "rb-f-soft" : cell.n === "–" ? "rb-f-sunk" : "rb-f-surface") + '"/>' +
            '<text x="' + (x + CW / 2) + '" y="' + (y + 32) + '" text-anchor="middle" class="' + (on ? "rb-t-acc" : "rb-t-ink") + '" style="font-size:17px">' + (cell.n === "–" ? "none" : "(" + cell.n + ")") + "</text>" +
            '<text x="' + (x + CW / 2) + '" y="' + (y + 54) + '" text-anchor="middle" class="rb-t-mono" style="font-size:13px">' + RB.esc(rep) + "</text></g>";
        });
      });
      s += "</svg>";
      host.innerHTML = s;
      RB.$$("[data-cell]", host).forEach(function (g) {
        var pick = function () { var k = g.getAttribute("data-cell").split("-"); st.bb = k[0]; st.head = k[1]; var m = CELLS[g.getAttribute("data-cell")].model; if (m) st.model = m; clearPreset(); setSeg(id + "-bb", st.bb); setSeg(id + "-head", st.head); render(); };
        g.addEventListener("click", pick); g.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(); } });
      });
    }
    function drawFacts() {
      var cell = CELLS[st.bb + "-" + st.head], m = cell.model ? MODELS[st.model && MODELS[st.model].cell === st.bb + "-" + st.head ? st.model : cell.model] : null;
      var h = '<p class="rb-h5">' + (cell.n === "–" ? "" : "(" + cell.n + ") ") + RB.esc(cell.name) + '</p><p class="sb-caption">Examples: ' + RB.esc(cell.ex) + ' <span class="sb-ref">P02 §IV-A</span></p>';
      if (m) h += '<dl class="rb-kv"><dt>Model</dt><dd>' + RB.esc(m.name) + "</dd><dt>Size</dt><dd>" + RB.esc(m.size) + "</dd><dt>Split</dt><dd>" + RB.esc(m.split) + "</dd><dt>Output</dt><dd>" + RB.esc(m.out) + '</dd></dl><p class="sb-caption"><span class="sb-ref">' + m.ref + "</span></p>";
      else h += '<p class="sb-caption">No representative model. The nearest cell is (2), a transformer with a diffusion head.</p>';
      q("#" + id + "-facts").innerHTML = h;
    }

    /* ---------- attention mask + KV strip (canvas) ---------- */
    function avail(el) { var w = el.parentNode ? el.parentNode.clientWidth : 0; return w > 0 ? Math.max(320, Math.min(560, Math.floor(w))) : 560; }
    function drawMask() {
      if (dead) return;
      var MW = avail(maskCv), P = RB.pal(), Tk = T(), N = Tk.length, cs = Math.min(22, Math.floor((MW - 88) / N)), gx = 72, gy = 96, MH = gy + N * cs + 34;
      var c = RB.canvas(maskCv, MW, MH), pl = plan(st.mode, st.cache, Tk, S(), st.s), i, j;
      c.fillStyle = P.surface; c.fillRect(0, 0, MW, MH);
      /* block labels */
      var NAMES = { img: "images", txt: "text", st: "state", act: "actions" }, SHORT = { img: "img", txt: "txt", st: "st", act: "act" };
      var runs = []; Tk.forEach(function (b, k) { if (!runs.length || runs[runs.length - 1].b !== b) runs.push({ b: b, a: k, n: 1 }); else runs[runs.length - 1].n++; });
      c.font = font("500", 12, "mono"); c.fillStyle = P["ink-2"]; c.textAlign = "center";
      runs.forEach(function (r) { var w = r.n * cs, lab = w > 52 ? NAMES[r.b] : SHORT[r.b]; c.fillText(lab, gx + (r.a + r.n / 2) * cs, 22); });
      c.textAlign = "right";
      runs.forEach(function (r) { c.fillText(NAMES[r.b], gx - 8, gy + (r.a + r.n / 2) * cs + 4); });
      /* KV strip */
      c.textAlign = "left"; c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.fillText("K, V", 8, 50);
      for (j = 0; j < N; j++) {
        var now = pl.rows.indexOf(j) >= 0, ca = pl.cached.indexOf(j) >= 0;
        c.fillStyle = now ? P.accent : ca ? P["data-3"] : P["surface-sunk"];
        c.fillRect(gx + j * cs + 1, 36, cs - 2, 22);
      }
      /* grid */
      for (i = 0; i < N; i++) for (j = 0; j < N; j++) {
        var ok = allowed(st.mode, st.layer, Tk, i, j), leak = st.mode === "full" && Tk[i] !== "act" && Tk[j] === "act";
        c.fillStyle = leak ? P.bad : ok ? P["data-1"] : P["surface-sunk"];
        c.globalAlpha = ok ? 0.8 : 1;
        c.fillRect(gx + j * cs + 1, gy + i * cs + 1, cs - 2, cs - 2);
      }
      c.globalAlpha = 1;
      /* block separators */
      c.strokeStyle = P["line-strong"]; c.lineWidth = 1.5;
      runs.forEach(function (r) { if (!r.a) return; var p = r.a * cs; c.beginPath(); c.moveTo(gx + p, gy - 4); c.lineTo(gx + p, gy + N * cs); c.moveTo(gx - 4, gy + p); c.lineTo(gx + N * cs, gy + p); c.stroke(); });
      /* rows computed now */
      c.strokeStyle = P.accent; c.lineWidth = 2.5;
      var rr = pl.rows.slice().sort(function (x, y) { return x - y; }), k0 = 0; for (var k = 1; k <= rr.length; k++) { if (k === rr.length || rr[k] !== rr[k - 1] + 1) { c.strokeRect(gx + 0.5, gy + rr[k0] * cs + 1, N * cs - 1, (rr[k - 1] - rr[k0] + 1) * cs - 2); k0 = k; } }
      c.fillStyle = P.accent; pl.rows.forEach(function (r) { c.beginPath(); c.moveTo(gx - 3, gy + r * cs + cs / 2); c.lineTo(gx - 9, gy + r * cs + cs / 2 - 4); c.lineTo(gx - 9, gy + r * cs + cs / 2 + 4); c.fill(); });
      c.lineWidth = 1;
      c.fillStyle = P["ink-3"]; c.font = font("500", 12, "mono"); c.textAlign = "left";
      c.fillText(MW < 460 ? "rows: queries · columns: keys, values" : "rows: query tokens · columns: keys and values", MW < 460 ? 8 : gx, gy + N * cs + 22);
      c.textAlign = "right"; c.fillStyle = P["ink-2"]; c.font = font("600", 13, "body");
      c.font = font("600", 12, "body"); c.fillText(st.s ? (st.mode === "ar" ? "token " + st.s + " of " + S() : "step " + st.s + " of " + S()) : "press Step", MW - 8, 80);
    }

    /* ---------- parameter and memory bars ---------- */
    function drawBars() {
      if (dead) return;
      var P = RB.pal(), BW = avail(barCv), rowH = 30, top = 34, BH = top + BAR_ORDER.length * rowH + 30, c = RB.canvas(barCv, BW, BH);
      var x0 = 92, x1 = BW - (BW < 460 ? 90 : 130), maxB = 7.5, sx = function (v) { return x0 + v / maxB * (x1 - x0); };
      c.fillStyle = P.surface; c.fillRect(0, 0, BW, BH);
      c.font = font("600", 13, "body"); c.fillStyle = P["ink-2"]; c.textAlign = "left"; c.fillText("parameters (billions)", x0, 18);
      c.textAlign = "right"; c.fillText("weights, " + st.prec, BW - 8, 18);
      c.strokeStyle = P["bench-grid"] || P.line; c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.textAlign = "center";
      [0, 2, 4, 6].forEach(function (v) { c.beginPath(); c.moveTo(sx(v), top - 4); c.lineTo(sx(v), top + BAR_ORDER.length * rowH); c.stroke(); c.fillText(String(v), sx(v), top + BAR_ORDER.length * rowH + 14); });
      BAR_ORDER.forEach(function (k, r) {
        var m = MODELS[k], y = top + r * rowH, on = k === st.model;
        if (on) { c.fillStyle = P["accent-soft"]; c.fillRect(0, y, BW, rowH); }
        c.fillStyle = on ? P.ink : P["ink-2"]; c.font = font(on ? "700" : "500", 13, "body"); c.textAlign = "left"; c.fillText(m.name, 8, y + 20);
        c.fillStyle = P["data-1"]; c.fillRect(sx(0), y + 7, Math.max(2, sx(m.bb) - sx(0)), rowH - 14);
        if (m.hd) { c.fillStyle = P["data-2"]; c.fillRect(sx(m.bb), y + 7, Math.max(2, sx(m.bb + m.hd) - sx(m.bb)), rowH - 14); }
        c.fillStyle = P["ink-2"]; c.font = font("500", 12, "mono"); c.textAlign = "left"; if (BW >= 460 || m.total < 5) c.fillText(m.size, Math.max(sx(m.total), sx(0) + 2) + 6, y + 19);
        c.textAlign = "right"; c.fillStyle = on ? P.ink : P["ink-2"]; c.fillText(RB.fmt(m.total * BYTES[st.prec], m.total * BYTES[st.prec] < 1 ? 2 : 1) + " GB", BW - 8, y + 19);
      });
    }

    /* ---------- numbers ---------- */
    function stats() {
      var Tk = T(), n = S(), m = MODELS[st.model], cell = CELLS[st.bb + "-" + st.head];
      var withC = totals(st.mode, st.cache, Tk, n), noC = totals(st.mode, false, Tk, n), pl = plan(st.mode, st.cache, Tk, n, st.s);
      RB.setRO(sc, "cell", cell.n === "–" ? "none" : "(" + cell.n + ")");
      RB.setRO(sc, "par", m ? m.size : "–");
      RB.setRO(sc, "mem", m ? RB.fmt(m.total * BYTES[st.prec], m.total * BYTES[st.prec] < 1 ? 2 : 1) : "–");
      RB.setRO(sc, "now", st.s ? String(pl.rows.length) : "–");
      RB.setRO(sc, "tot", String(withC)); RB.setRO(sc, "nocache", String(noC));
      RB.setRO(sc, "save", st.mode === "full" || !st.cache ? "0%" : Math.round((1 - withC / noC) * 100) + "%");
      RB.setRO(sc, "valid", st.mode === "full" ? "not possible" : st.cache ? "reused" : "off");
      var P = Tk.filter(function (b) { return b !== "act"; }).length, A = Tk.length - P;
      q("#" + id + "-stepline").textContent = !st.s ? "Press Step to run the first pass of this chunk." :
        st.mode === "ar" ? (st.s === 1 ? "Token 1: the whole prefix is computed once, and its keys and values go into the cache." : "Token " + st.s + ": " + (st.cache ? "only the newest token is computed; " + (P + st.s - 2) + " earlier tokens are read from the cache." : "no cache, so all " + pl.rows.length + " tokens are computed again."))
          : st.mode === "full" ? "Step " + st.s + ": the prefix reads the noisy actions, which change every step, so all " + Tk.length + " rows are recomputed."
          : st.s === 1 ? "Step 1: the " + P + " prefix rows and " + A + " action rows are computed; the prefix keys and values " + (st.cache ? "go into the cache." : "are thrown away.")
          : "Step " + st.s + ": " + (st.cache ? "only the " + A + " action rows run; the prefix is read from the cache." : "no cache, so all " + Tk.length + " rows run again.");
    }

    function chart() {
      if (dead) return;
      var host = q("#" + id + "-chart"), Tk = T(), xs = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], isAR = st.mode === "ar";
      var ser = function (cache) { return xs.map(function (k) { var Tt = isAR ? Tk : Tk; return [k, totals(st.mode, cache, Tt, k)]; }); };
      var series = [{ name: "No cache", color: "data-5", points: ser(false) }];
      if (st.mode !== "full") series.push({ name: "Cache", color: "data-1", points: ser(true) });
      var ymax = Math.max.apply(null, series[0].points.map(function (p) { return p[1]; }));
      host.innerHTML = "";
      StudyBench.lineChart(host, { title: "Rows computed per chunk", height: 220,
        x: { label: isAR ? "action tokens decoded" : "flow steps K", min: 1, max: 10, ticks: [1, 4, 7, 10] },
        y: { label: "query rows (one layer)", min: 0, max: Math.ceil(ymax / 10) * 10, fmt: function (v) { return String(Math.round(v)); } },
        series: series,
        caption: "Our toy counts for the current mask and token counts. Without a cache every step repeats the prefix; with it, the prefix runs once." });
    }

    function render() {
      if (dead) return;
      var m = MODELS[st.model];
      drawCells(); drawFacts(); drawMask(); drawBars(); stats();
      q("#" + id + "-note").textContent = MODE_NOTE[st.mode];
      q("#" + id + "-k").disabled = st.mode === "ar";
      q("#" + id + "-h").disabled = st.mode === "ar";
      q("#" + id + "-cache").disabled = st.mode === "full";
      RB.$$("#" + id + "-layer button", ct).forEach(function (b) { b.disabled = st.mode !== "smol"; });
      api.meta((m ? m.name + " · " : "") + MODES.filter(function (x) { return x.value === st.mode; })[0].label);
      clearTimeout(chartT); chartT = setTimeout(chart, 40);
    }
    function redraw() { if (dead) return; drawMask(); stats(); }

    /* ---------- stepping ---------- */
    function stepOnce() { st.s = st.s >= S() ? 1 : st.s + 1; stepped++; redraw(); }
    function stopPlay(msg) { if (timer) clearInterval(timer); timer = 0; playing = false; api.live("paused", msg || "Paused"); }
    function play() {
      stopPlay(); st.s = 0; redraw(); playing = true; api.live("running", "Running the chunk");
      timer = setInterval(function () {
        if (dead) { stopPlay(); return; }
        st.s++; redraw();
        if (st.s >= S()) { var Tk = T(); stopPlay("Done · " + totals(st.mode, st.cache, Tk, S()) + " rows for this chunk"); }
      }, 450);
    }
    function resetSteps() { stopPlay(); st.s = 0; }

    /* ---------- wiring ---------- */
    function setSeg(sid, v) { RB.$$("#" + sid + " button", ct).forEach(function (b) { b.setAttribute("aria-pressed", b.value === v ? "true" : "false"); }); }
    function setSlider(sid, v) { var inp = q("#" + sid), out = ct.querySelector('[data-out="' + sid + '"]'); inp.value = v; if (out) out.textContent = v; }
    function bindSeg(sid, cb) { StudyBench.segmented(ct.querySelector("#" + sid), function (a, b) { cb(b ? b.value : (a && a.value) || a); }); }
    function clearPreset() { st.preset = null; setSeg(id + "-pre", "__none"); }
    bindSeg(id + "-pre", function (v) {
      var p = PRESETS[v]; if (!p) return;
      var m = MODELS[v], k = m.cell.split("-");
      st.preset = v; st.model = v; st.bb = k[0]; st.head = k[1]; st.mode = p.mode; st.K = p.K;
      setSeg(id + "-bb", st.bb); setSeg(id + "-head", st.head); setSeg(id + "-mode", st.mode); setSlider(id + "-k", st.K);
      resetSteps(); render();
    });
    bindSeg(id + "-bb", function (v) { st.bb = v; var m = CELLS[st.bb + "-" + st.head].model; if (m) st.model = m; clearPreset(); render(); });
    bindSeg(id + "-head", function (v) { st.head = v; var m = CELLS[st.bb + "-" + st.head].model; if (m) st.model = m; clearPreset(); render(); });
    bindSeg(id + "-mode", function (v) { st.mode = v; clearPreset(); resetSteps(); render(); });
    bindSeg(id + "-layer", function (v) { st.layer = v; redraw(); });
    bindSeg(id + "-prec", function (v) { st.prec = v; drawBars(); stats(); });
    RB.bindSlider(ct, id + "-cams", null, function (v) { st.cams = v; resetSteps(); render(); });
    RB.bindSlider(ct, id + "-h", null, function (v) { st.H = v; resetSteps(); render(); });
    RB.bindSlider(ct, id + "-k", null, function (v) { st.K = v; clearPreset(); resetSteps(); render(); });
    q("#" + id + "-cache").addEventListener("change", function (e) { st.cache = e.target.checked; resetSteps(); render(); });
    q("#" + id + "-step").addEventListener("click", function () { stopPlay(); stepOnce(); });
    q("#" + id + "-play").addEventListener("click", play);
    q("#" + id + "-reset").addEventListener("click", function () { resetSteps(); redraw(); });
    RB.onTheme(function () { if (dead || !document.contains(maskCv)) return; drawMask(); drawBars(); });
    var rzT = 0, lastW = sc.clientWidth;
    function onResize() { clearTimeout(rzT); rzT = setTimeout(function () { if (dead || sc.clientWidth === lastW) return; lastW = sc.clientWidth; drawCells(); drawMask(); drawBars(); }, 120); }
    window.addEventListener("resize", onResize);

    /* side panel: reference numbers */
    if (api.side) {
      api.side.style.minWidth = "0";
      api.side.innerHTML = '<p class="rb-h5">Reference numbers</p>' + [
        ["π0", "3.3B: 3B PaliGemma + 300M action expert; 50 actions, 10 Euler steps; 73 ms per chunk on an RTX 4090", "arXiv 2410.24164"],
        ["SmolVLA", "0.45B with an expert of about 100M; first 16 LLM layers; 64 visual tokens per frame", "arXiv 2506.01844"],
        ["SmolVLA vs π0", "About 40% faster to train, 6× less memory; the Fig. 39 caption says 7×", "X2 §5.4, Fig. 39"],
        ["OpenVLA", "7B; 15 GB in bf16 for inference; int4 7.0 GB vs 16.8 GB", "arXiv 2406.09246"],
        ["GR00T N1", "2.2B, 1.34B in the VLM; 16 actions, 4 flow steps; 63.9 ms per chunk on an L40", "arXiv 2503.14734"],
        ["SmolVLA on LIBERO", "87.3% vs π0 86.0% and OpenVLA 76.5%", "arXiv 2506.01844"]
      ].map(function (r) { return '<p class="sb-caption"><b>' + r[0] + "</b>: " + r[1] + ' <span class="sb-ref">' + r[2] + "</span></p>"; }).join("");
    }

    render();

    return {
      state: function () { return st; },
      demo: function () {
        var pre = function (v) { return q("#" + id + '-pre [value="' + v + '"]'); };
        return [
          { target: q("#" + id + "-pre"), title: "Tokens, one at a time", text: "OpenVLA is cell (4): a 7B VLM that writes a 7-D action as 7 tokens. The mask is causal, one pass per token.", do: function (a) { return a.click(pre("openvla")).then(function () { return a.wait(500); }); }, task: "Choose the OpenVLA preset", expect: function () { return st.preset === "openvla"; } },
          { target: q("#" + id + "-pre"), title: "π0: three blocks", text: "π0 is cell (6). Images and text, state, and actions form three blocks; no block reads a later one.", do: function (a) { return a.click(pre("pi0")).then(function () { return a.wait(500); }); }, task: "Choose the π0 preset", expect: function () { return st.preset === "pi0"; } },
          { target: q("#" + id + "-step"), title: "Step through a chunk", text: "Step 1 computes every row. From step 2 only the action rows run; the prefix keys and values come from the cache.", do: function (a) { var b = q("#" + id + "-step"); b.click(); return a.wait(600).then(function () { b.click(); return a.wait(600); }).then(function () { b.click(); return a.wait(600); }); }, task: "Press Step at least twice", expect: function () { return stepped >= 2 && st.s >= 2; } },
          { target: q("#" + id + "-mode"), title: "Break the mask", text: "Without the mask the prefix reads noisy actions. Those change every step, so nothing can be cached and the row count jumps.", do: function (a) { return a.click(q("#" + id + '-mode [value="full"]')).then(function () { return a.wait(600); }); }, task: "Choose No mask", expect: function () { return st.mode === "full"; } },
          { target: q("#" + id + "-pre"), title: "SmolVLA's expert", text: "SmolVLA keeps the cache. Its expert alternates cross-attention to the VLM with causal self-attention among actions.", do: function (a) { return a.click(pre("smolvla")).then(function () { return a.wait(400); }).then(function () { return a.click(q("#" + id + '-layer [value="sa"]')); }).then(function () { return a.wait(500); }); }, task: "Choose SmolVLA, then the Self-attention layer", expect: function () { return st.mode === "smol" && st.layer === "sa"; } },
          { target: q("#" + id + "-prec"), title: "Weights in memory", text: "Weight memory is parameters times bytes. At bf16, π0 needs 6.6 GB and SmolVLA 0.9 GB, about 7× less.", do: function (a) { return a.click(q("#" + id + '-prec [value="int4"]')).then(function () { return a.wait(500); }); }, task: "Choose int4 precision", expect: function () { return st.prec === "int4"; } },
          { target: q("#" + id + "-pre"), title: "Your turn", text: "Choose GR00T N1, press Play chunk, then untick the cache. Compare rows per chunk at 4 flow steps and at 10." }
        ];
      },
      destroy: function () { dead = true; if (timer) clearInterval(timer); timer = 0; clearTimeout(chartT); clearTimeout(rzT); window.removeEventListener("resize", onResize); }
    };
  }

  RB.station({
    id: "vla", name: "VLA dissector", sub: "08 · architecture",
    refs: ["P02 §IV-A, Fig. 4", "X2 §5.3–5.4, Figs. 37–39"], prov: "Simplified: toy token counts, no network",
    summary: "Place a model in the seven cells of P02, then open its attention mask. Step through one action chunk to see which rows a layer computes, what the cache saves, and how model size sets memory.",
    notice: [
      "The seven cells cross two backbones with four action outputs; a plain transformer with a flow head has no cell.",
      "π0's blockwise mask never lets the prefix read actions, so its keys and values are computed once per chunk.",
      "Remove the mask and the prefix reads noisy actions, so every step recomputes everything.",
      "SmolVLA alternates cross-attention to the VLM with causal self-attention among action tokens.",
      "Weight memory scales with parameters: 3.3B against 450M is about 7× at any precision."
    ],
    card: "Place a VLA in P02's seven cells, step its attention mask, and watch the key-value cache save work.",
    terms: {
      "key-value-cache": { name: "key-value cache", aliases: ["KV cache", "KV caching"], group: "vla", def: "Stored keys and values of tokens whose inputs do not change, reused at later decoding or denoising steps instead of being recomputed.", note: "It only works if cached tokens never attend to tokens that change; that is why π0 masks actions from the prefix.", ref: "X2 §5.3", scene: "system", focus: ["llm-backbone", "action-head"], look: "prefix computed once, reused each step", uses: [] },
      "layer-skipping": { name: "layer skipping", aliases: ["early-layer features"], group: "vla", def: "Using features from only the first N of L backbone layers; SmolVLA takes N = L/2, which about halves the backbone's compute.", note: "GR00T N1 does something similar, reading the 12th LLM layer instead of the last.", ref: "X2 §5.4 · arXiv 2503.14734", scene: "system", focus: ["llm-backbone"], look: "the upper backbone layers left unused", uses: [] }
    },
    ledger: [
      { where: "Lab · VLA dissector", source: "Real VLAs use hundreds of tokens per image and 50-action chunks", page: "The mask shows 3 tokens per camera, 3 text tokens, 1 state token and 2–8 action tokens", why: "Keeps the mask readable; row counts are our toy numbers.", kind: "Simplified" },
      { where: "Lab · VLA dissector", source: "X2 §5.4 says SmolVLA's experts use simple causal masking without blocks", page: "The SmolVLA prefix is drawn as one bidirectional block; action rows follow the CA or SA layer", why: "The tutorial does not specify the prefix mask; the expert's layers are the point.", kind: "Our choice" },
      { where: "Lab · VLA dissector", source: "GR00T N1 alternates cross- and self-attention in a DiT (arXiv 2503.14734)", page: "The GR00T N1 preset reuses the SmolVLA mask view", why: "Both read VLM keys and values by cross-attention; details of the self-attention differ.", kind: "Simplified" },
      { where: "Lab · VLA dissector", source: "X2 §5.4 and the SmolVLA paper say 6× less memory than π0; X2 Fig. 39 caption says 7×", page: "The bench shows weight memory only, 3.3B / 0.45B ≈ 7.3×", why: "Measured memory includes activations and cache; weights alone give the larger ratio.", kind: "Sources disagree" },
      { where: "Lab · VLA dissector", source: "X2 §5.3 names Gemma 2.6B as π0's backbone; the π0 paper says 3B PaliGemma", page: "Bars use 3B + 300M = 3.3B", why: "The method paper's total matches the 3.3B that X2 Fig. 39 compares against.", kind: "Sources disagree" },
      { where: "Lab · VLA dissector", source: "Rows computed per step stand in for compute", page: "One layer, attention cost and expert width ignored", why: "Shows what caching saves, not absolute latency.", kind: "Our choice" },
      { where: "Lab · VLA dissector", source: "OpenVLA decodes 7 tokens autoregressively", page: "Causal view shows standard language-model key-value caching", why: "OpenVLA does not report its cache use; this is the usual decoder practice.", kind: "Our choice" },
      { where: "Lab · VLA dissector", source: "GR00T N1's 0.86B beyond the VLM includes the DiT and embodiment adapters", page: "Drawn as one action-module bar", why: "The card gives only the total and the VLM share.", kind: "Simplified" }
    ],
    mount: mount
  });
})();
