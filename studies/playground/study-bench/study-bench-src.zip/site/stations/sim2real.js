/* Interactive Lab · Sim-to-real station (topics 04, 03).
   Sources: P08 §2.1.2 (eq. 2, gap sources incl. action delay), P08 §3.2 (constant and random delay MDPs, DCAC), P08 §3.3 (GAT);
   P07 §4.1.1 (actuator models, dynamics randomization, privileged learning with observation history), P07 §4.3.3.
   Method cards: dynamics randomization (Peng, arXiv 1710.06537), ADR (1910.07113), GAT via SGAT (2008.01281), RMA (2107.04034),
   Lee 2020 teacher–student (2010.11251), Tan 2018 (1804.10332), DCAC (2010.02966).
   Toy: a cart-pole with classic constants must stay upright for 5 s and survive a tap at 2.5 s. "Training" is an exhaustive search
   over a two-parameter linear controller family (gain g, damping r, and in one mode a last-action weight c) that maximizes the mean
   return over a set of training simulators. The "real robot" is the same physics with hidden parameters and sensor noise.
   Every number drawn is computed here; paper numbers appear only in notes. */
(function () {
  "use strict";
  var RB = window.RB;
  var SID = "sim2real";
  var DT = 0.02, NSTEP = 250, PUSH_T = 125, CHANGE_T = 100, GRAV = 9.8, MC = 1.0, TH_FAIL = 0.4, X_FAIL = 2.4;
  var NOM = { mp: 0.1, l: 0.5, km: 10, b: 0.1, d: 0, jit: 0 };
  var GS = [0.5, 0.71, 1, 1.41, 2, 2.83, 4, 5.66, 8, 11.3], RS = [0.25, 0.5, 1, 2, 4], CS = [-0.6, -0.3, 0, 0.3];
  var NTRAIN = 12, NEVAL = 40;
  var REALS = {
    weak: { label: "Weak motor", w: { km: 3.5, b: 0.4 }, text: "motor force 35% of nominal, friction ×4" },
    heavy: { label: "Heavy pole", w: { mp: 0.25, l: 1.2 }, text: "pole mass ×2.5, pole length ×2.4" },
    both: { label: "Both", w: { km: 4.5, b: 0.3, mp: 0.25, l: 0.8 }, text: "weaker motor, heavier and longer pole" }
  };
  var GAT_REAL = { km: 3, b: 0.6 };
  function tsRef(t) { return 0.8 * Math.sin(2 * Math.PI * t * DT / 2.5); }
  var NLIST = [8, 15, 30, 60, 125, 250, 500, 1000];
  var KLIST = [1, 2, 5, 10, 20, 35, 50, 75, 100];
  var MODES = [{ value: "dr", label: "Randomize" }, { value: "delay", label: "Delay" }, { value: "gat", label: "Ground (GAT)" }, { value: "ts", label: "Teacher–student" }];

  function world(extra) { var w = {}; Object.keys(NOM).forEach(function (k) { w[k] = NOM[k]; }); if (extra) Object.keys(extra).forEach(function (k) { w[k] = extra[k]; }); return w; }
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function pressSeg(root, id, v) { RB.$$("#" + id + " button", root).forEach(function (b) { var on = b.value === v; b.setAttribute("aria-pressed", on ? "true" : "false"); b.tabIndex = on ? 0 : -1; }); }
  function font(kind) { return getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body") || "sans-serif"; }
  function pct(v) { return v == null || isNaN(v) ? "–" : Math.round(100 * v) + "%"; }

  /* ---------- physics: classic cart-pole (Euler, 50 Hz) with viscous cart friction ---------- */
  function accel(s, F, w) {
    var M = MC + w.mp, st = Math.sin(s[2]), ct = Math.cos(s[2]);
    var tmp = (F - w.b * s[1] + w.mp * w.l * s[3] * s[3] * st) / M;
    var thdd = (GRAV * st - ct * tmp) / (w.l * (4 / 3 - w.mp * ct * ct / M));
    return [tmp - w.mp * w.l * thdd * ct / M, thdd];
  }
  function step(s, F, w) {
    var A = accel(s, F, w), xd = s[1] + DT * A[0], thd = s[3] + DT * A[1];
    return [s[0] + DT * xd, xd, s[2] + DT * thd, thd];
  }
  function observe(s, R) { return [s[0] + 0.02 * R.normal(), s[1] + 0.02 * R.normal(), s[2] + 0.005 * R.normal(), s[3] + 0.02 * R.normal()]; }

  /* ---------- the policy family: a = clip(g·(0.1x + 0.2ẋ + 2θ + 0.4r·θ̇) + c·a_prev) ---------- */
  function pol(g, r, c) { return { g: g, r: r, c: c || 0, k: [0.1 * g, 0.2 * g, 2 * g, 0.4 * g * r] }; }
  function raw(p, o, prev) { return p.k[0] * o[0] + p.k[1] * o[1] + p.k[2] * o[2] + p.k[3] * o[3] + p.c * prev; }
  function clip(u) { return u > 1 ? 1 : u < -1 ? -1 : u; }

  /* one episode. o: {traj, push, ground(s,a)→a, kmAt(t), lat:"teacher"|"student", kWin, init} */
  function episode(p, w, R, o) {
    o = o || {};
    var s = o.init ? o.init.slice() : [0.2 * (R() - 0.5), 0, 0.12 * (R() - 0.5) + (R() < 0.5 ? -0.06 : 0.06), 0];
    var dmax = w.d | 0, buf = [], prev = 0, ret = 0, alive = NSTEP, traj = o.traj ? [] : null, pushDir = R() < 0.5 ? -1 : 1;
    for (var i = 0; i < dmax + 1; i++) buf.push(0);
    var ring = [], sumYB = 0, sumBB = 0, lastObs = null, lastA = 0, zhat = 0, km = w.km;
    for (var t = 0; t < NSTEP; t++) {
      km = o.kmAt ? o.kmAt(t) : w.km;
      var ob = w.noise === 0 ? s.slice() : observe(s, R);
      /* student: least-squares motor strength from the last kWin transitions (known model up to km) */
      if (o.lat === "student" && lastObs) {
        var A0 = accel(lastObs, 0, NOM), A1 = accel(lastObs, 1, NOM), bx = (A1[0] - A0[0]) * lastA, bt = (A1[1] - A0[1]) * lastA;
        var yx = (ob[1] - lastObs[1]) / DT - A0[0], yt = (ob[3] - lastObs[3]) / DT - A0[1];
        var e = [yx * bx + yt * bt, bx * bx + bt * bt]; ring.push(e); sumYB += e[0]; sumBB += e[1];
        if (ring.length > o.kWin) { var old = ring.shift(); sumYB -= old[0]; sumBB -= old[1]; }
        var P = 0.05, kh = (sumYB + P * NOM.km) / (sumBB + P);
        zhat = Math.log(RB.clamp(kh, 0.5, 30) / NOM.km);
      }
      var scale = o.lat === "teacher" ? NOM.km / km : o.lat === "student" ? Math.exp(-zhat) : 1;
      if (o.ref) ob = [ob[0] - o.ref(t), ob[1], ob[2], ob[3]];
      var a = clip(scale * raw(p, ob, prev));
      buf.unshift(a); buf.length = dmax + 1;
      var d = dmax; if (w.jit) d = Math.floor(R() * (dmax + 1));
      var ae = buf[d];
      if (t === PUSH_T && o.push !== false) s[3] += 0.5 * pushDir;
      var cmd = o.ground ? o.ground(s, ae) : ae;
      s = step(s, km * cmd, w);
      lastObs = ob; lastA = ae;
      if (traj) traj.push({ x: s[0], th: s[2], a: a, ae: ae, z: Math.log(km / NOM.km), zh: zhat });
      if (Math.abs(s[2]) > TH_FAIL || Math.abs(s[0]) > X_FAIL) { alive = t + 1; break; }
      ret += 1 - 0.5 * s[2] * s[2] / (TH_FAIL * TH_FAIL) - 0.1 * s[0] * s[0] / (X_FAIL * X_FAIL) - 0.15 * a * a - 0.5 * (a - prev) * (a - prev);
      prev = a;
    }
    return { alive: alive, ok: alive === NSTEP, ret: ret, traj: traj };
  }
  function evalSet(p, worlds, seed, o) {
    var R = RB.rng(seed), J = 0, ok = 0;
    for (var i = 0; i < worlds.length; i++) { var e = episode(p, worlds[i], R, o); J += e.ret; ok += e.ok ? 1 : 0; }
    return { J: J / worlds.length, succ: ok / worlds.length };
  }
  function rep(w, n) { var a = []; for (var i = 0; i < n; i++) a.push(w); return a; }

  /* "training": exhaustive search of the policy family on the training worlds */
  function trainGrid(worlds, o) {
    o = o || {};
    var best = null, grid = [];
    (o.useC ? CS : [0]).forEach(function (c, ci) {
      RS.forEach(function (r, ri) {
        GS.forEach(function (g, gi) {
          var p = pol(g, r, c), J = evalSet(p, worlds, 11, o).J;
          if (!grid[ri]) grid[ri] = [];
          if (grid[ri][gi] == null || J > grid[ri][gi].J) grid[ri][gi] = { J: J, c: c };
          if (!best || J > best.J) best = { p: p, J: J, ri: ri, gi: gi };
        });
      });
    });
    best.grid = grid; return best;
  }
  function landscape(worlds, c, seed, o) { return RS.map(function (r) { return GS.map(function (g) { return { J: evalSet(pol(g, r, c), worlds, seed, o).J, c: c }; }); }); }
  function argmax(grid) { var b = null; grid.forEach(function (row, ri) { row.forEach(function (v, gi) { if (!b || v.J > b.J) b = { J: v.J, ri: ri, gi: gi }; }); }); return b; }

  function drWorlds(width, n, seed) {
    var R = RB.rng(seed), W = [];
    function lu(v) { return v * Math.exp((2 * R() - 1) * Math.log(1 + width)); }
    for (var i = 0; i < n; i++) W.push(width > 0 ? world({ mp: lu(NOM.mp), l: lu(NOM.l), km: lu(NOM.km), b: lu(NOM.b) }) : world());
    return W;
  }
  function delayWorlds(dmax, n, seed) { var R = RB.rng(seed), W = []; for (var i = 0; i < n; i++) W.push(world({ d: dmax ? Math.floor(R() * (dmax + 1)) : 0 })); return W; }

  /* ---------- GAT: fit f_real by least squares, invert the simulator per step ---------- */
  function lstsq(X, Y) {
    var n = X[0].length, A = [], b = [], i, j, r;
    for (i = 0; i < n; i++) { A.push([]); for (j = 0; j < n; j++) A[i].push(0); b.push(0); }
    X.forEach(function (x, k) { for (var i2 = 0; i2 < n; i2++) { b[i2] += x[i2] * Y[k]; for (var j2 = 0; j2 < n; j2++) A[i2][j2] += x[i2] * x[j2]; } });
    for (i = 0; i < n; i++) A[i][i] += 1e-3;
    for (var c = 0; c < n; c++) {
      var pv = c; for (r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > Math.abs(A[pv][c])) pv = r;
      var tr = A[c]; A[c] = A[pv]; A[pv] = tr; var tb = b[c]; b[c] = b[pv]; b[pv] = tb;
      for (r = c + 1; r < n; r++) { var f = A[r][c] / A[c][c]; for (j = c; j < n; j++) A[r][j] -= f * A[c][j]; b[r] -= f * b[c]; }
    }
    var x = []; for (i = 0; i < n; i++) x.push(0);
    for (i = n - 1; i >= 0; i--) { var sm = b[i]; for (j = i + 1; j < n; j++) sm -= A[i][j] * x[j]; x[i] = sm / A[i][i]; }
    return x;
  }
  function feat(o, a) { return [1, o[1], o[2], o[3], a]; }
  function collect(p, realW, n, seed) {
    var R = RB.rng(seed), data = [];
    while (data.length < n) {
      var s = [0.2 * (R() - 0.5), 0, 0.1 * (R() - 0.5), 0], ob = observe(s, R);
      for (var t = 0; t < NSTEP && data.length < n; t++) {
        var a = clip(raw(p, ob, 0) + 0.3 * R.normal());
        s = step(s, realW.km * a, realW);
        var ob2 = observe(s, R); data.push({ o: ob, a: a, o2: ob2 }); ob = ob2;
        if (Math.abs(s[2]) > TH_FAIL || Math.abs(s[0]) > X_FAIL) break;
      }
    }
    return data;
  }
  function fitReal(data) {
    var X = data.map(function (d) { return feat(d.o, d.a); });
    return [lstsq(X, data.map(function (d) { return (d.o2[1] - d.o[1]) / DT; })), lstsq(X, data.map(function (d) { return (d.o2[3] - d.o[3]) / DT; }))];
  }
  function predict(m, s, a) { var f = feat(s, a), px = 0, pt = 0; for (var i = 0; i < 5; i++) { px += m[0][i] * f[i]; pt += m[1][i] * f[i]; } return [px, pt]; }
  function grounder(m) {
    return function (s, a) {
      var T = predict(m, s, a), A0 = accel(s, 0, NOM), A1 = accel(s, 1, NOM), bx = A1[0] - A0[0], bt = A1[1] - A0[1];
      var F = ((T[0] - A0[0]) * bx + (T[1] - A0[1]) * bt) / (bx * bx + bt * bt);
      return RB.clamp(F / NOM.km, -3, 3);
    };
  }
  /* one-step acceleration error against the true (hidden) real dynamics, on states from a fixed probe set */
  function modelErr(realW, g) {
    var R = RB.rng(77), e = 0, n = 200;
    for (var i = 0; i < n; i++) {
      var s = [0.4 * (R() - 0.5), 0.6 * (R() - 0.5), 0.3 * (R() - 0.5), 1.0 * (R() - 0.5)], a = 2 * R() - 1;
      var Ar = accel(s, realW.km * a, realW), As = accel(s, NOM.km * (g ? g(s, a) : a), NOM);
      e += Math.abs(Ar[0] - As[0]) + Math.abs(Ar[1] - As[1]);
    }
    return e / n;
  }

  /* ---------- the station ---------- */
  function mount(api) {
    var id = SID, scene = api.scene, ctl = api.controls;
    var st = { mode: "dr", real: "weak", width: 0.5, view: "train", dReal: 100, dType: "const", dTrain: 0, hist: false, nReal: 5, kWin: 20, frac: 0.4 };
    var cache = {}, res = null, seed = 3, raf = 0, playT = null, runs = 0, ro = null, lastW = 0, simT = 0, chartT = 0, chartTok = 0;

    scene.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Two cart-poles side by side with the pole angle over five seconds"></canvas>' +
      '<figcaption class="sb-caption" id="' + id + '-cap">–</figcaption></figure>' +
      RB.readouts([{ id: "r1", k: "–" }, { id: "r2", k: "–" }, { id: "r3", k: "–" }, { id: "r4", k: "–" }, { id: "r5", k: "–" }, { id: "r6", k: "–" }]) +
      '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv2" aria-label="Second view for this mode"></canvas><figcaption class="sb-caption" id="' + id + '-cap2">–</figcaption></figure>' +
      '<div id="' + id + '-chart"></div></div>';
    ctl.innerHTML =
      '<div class="rb-stack">' +
      '<div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Mode", value: "dr", options: MODES }) +
      '<button class="sb-btn" type="button" id="' + id + '-seed">New noise draw</button>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Replay ▶</button></div>' +
      '<div class="rb-row" data-m="dr">' + RB.seg({ id: id + "-real", label: "Real robot", value: "weak", options: Object.keys(REALS).map(function (k) { return { value: k, label: REALS[k].label }; }) }) +
      RB.slider({ id: id + "-w", label: "Randomization width ±", min: 0, max: 150, step: 25, value: 50, fmt: function (v) { return v + "%"; } }) +
      RB.seg({ id: id + "-view", label: "Landscape", value: "train", options: [{ value: "train", label: "Training sims" }, { value: "real", label: "Real robot" }] }) + "</div>" +
      '<div class="rb-row" data-m="delay" hidden>' +
      RB.slider({ id: id + "-dr", label: "Real delay (ms)", min: 0, max: 200, step: 20, value: 100 }) +
      RB.seg({ id: id + "-dt", label: "Delay type", value: "const", options: [{ value: "const", label: "Constant" }, { value: "rand", label: "Random" }] }) +
      RB.slider({ id: id + "-dtr", label: "Train delay up to (ms)", min: 0, max: 200, step: 20, value: 0 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-hist"> <span>Feed the last action back</span></label></div>' +
      '<div class="rb-row" data-m="gat" hidden>' +
      RB.slider({ id: id + "-n", label: "Real transitions", min: 0, max: NLIST.length - 1, step: 1, value: 5, fmt: function (v) { return String(NLIST[v]); } }) + "</div>" +
      '<div class="rb-row" data-m="ts" hidden>' +
      RB.slider({ id: id + "-k", label: "Student history k", min: 1, max: 100, step: 1, value: 20, fmt: function (v) { return v + " steps (" + RB.fmt(v * DT, 2) + " s)"; } }) +
      RB.slider({ id: id + "-f", label: "Motor after 2 s", min: 20, max: 100, step: 10, value: 40, fmt: function (v) { return v + "%"; } }) + "</div>" +
      "</div>";
    api.side.innerHTML =
      '<p class="rb-muted" id="' + id + '-note">–</p>' +
      '<div data-s="dr">' + RB.eqBlock({ name: "Domain randomization objective", ref: "P08 eq. 1 · arXiv 1710.06537", tex: "\\class{sym-J}{J}(\\class{sym-pi}{\\pi_\\theta}) = \\class{sym-E}{\\mathbb{E}}_{\\class{sym-omega}{\\omega} \\sim \\class{sym-p-omega}{P(\\omega)}}\\Big[\\class{sym-E}{\\mathbb{E}}\\Big[\\textstyle\\sum_t \\class{sym-r}{r_t} \\,\\Big|\\, \\class{sym-omega}{\\omega}\\Big]\\Big]", words: "Pick the policy with the best average return over many simulators. Here ω is pole mass, pole length, motor force and friction.", key: ["J", "pi", "E", "omega", { sym: "p-omega", glyph: "P(ω)", meaning: "randomization distribution" }, "r"] }) + "</div>" +
      '<div data-s="delay" hidden>' + RB.eqBlock({ name: "Delayed MDP state", ref: "P08 §3.2 · arXiv 2010.02966", tex: "\\tilde{\\class{sym-s}{s}}_t = \\big(\\class{sym-o}{o_t},\\ \\class{sym-a}{a}_{t-1}, \\dots, \\class{sym-a}{a}_{t-d}\\big), \\qquad d \\sim \\mathcal{U}\\{0, \\dots, d_{\\max}\\}", words: "With delay the observation alone is not a Markov state; the actions still in flight complete it. Random-delay MDPs also resample d.", key: ["s", "o", "a", { glyph: "d", meaning: "delay in control steps" }] }) + "</div>" +
      '<div data-s="gat" hidden>' + RB.eqBlock({ name: "Grounded action", ref: "P08 §3.3 · arXiv 2008.01281", tex: "\\hat{a}_t = \\class{sym-f}{f}_{\\mathrm{sim}}^{-1}\\big(\\class{sym-s}{s_t},\\ \\hat{\\class{sym-f}{f}}_{\\mathrm{real}}(\\class{sym-s}{s_t}, \\class{sym-a}{a_t})\\big)", words: "Predict the real next state with a model fit on real transitions, then find the simulator action that reaches it.", key: ["f", "s", "a", { glyph: "â", meaning: "grounded action run in sim" }] }) + "</div>" +
      '<div data-s="ts" hidden>' + RB.eqBlock({ name: "Student latent", ref: "arXiv 2107.04034 · 2010.11251", tex: "\\class{sym-zhat}{\\hat z_t} = \\class{sym-adapt-phi}{\\phi}\\big(\\class{sym-hist}{h_{t-k:t}}\\big), \\qquad \\class{sym-a}{a_t} = \\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o_t}, \\class{sym-zhat}{\\hat z_t})", words: "The teacher reads z from the simulator. The student estimates it from the last k states and actions, then acts with the same policy.", key: [{ sym: "zhat", glyph: "ẑₜ", meaning: "estimated latent" }, { sym: "adapt-phi", glyph: "φ", meaning: "adaptation module" }, { sym: "hist", glyph: "hₜ₋ₖ:ₜ", meaning: "state-action history" }, "a", "pi", "o"] }) + "</div>" +
      '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
      '<li>Peng et al. randomized 95 dynamics parameters, including the action timestep; real pushing success 0.89 <span class="sb-ref">arXiv 1710.06537</span></li>' +
      '<li>Same policy with a fixed action timestep: 0.29; without any randomization: 0.0 <span class="sb-ref">arXiv 1710.06537</span></li>' +
      '<li>Minitaur controllers failed on the real robot without the actuator model or latency simulation <span class="sb-ref">arXiv 1804.10332</span></li>' +
      '<li>GAT made a NAO walk over 43% faster; on uneven ground its policy fell 10 of 10 times, SGAT 1 of 10 <span class="sb-ref">arXiv 2008.01281</span></li>' +
      '<li>RMA reads 0.5 s of history (k = 50); without the adaptation module, real 15 cm step-down success fell from 80% to 0% <span class="sb-ref">arXiv 2107.04034</span></li>' +
      '<li>Lee et al. compared student histories of 0.02, 0.4 and 2.0 s; longer ones came closer to the teacher <span class="sb-ref">arXiv 2010.11251</span></li></ul>';

    var cv = scene.querySelector("#" + id + "-cv"), cv2 = scene.querySelector("#" + id + "-cv2"), chartHost = scene.querySelector("#" + id + "-chart");
    function setSlider(sid, v, txt) { var inp = ctl.querySelector("#" + id + sid), out = ctl.querySelector('[data-out="' + id + sid + '"]'); inp.value = v; if (out) out.textContent = txt; }
    function label(k, txt) { var el = scene.querySelector('[data-ro="' + k + '"]'); if (el && el.parentNode) el.parentNode.querySelector(".sb-readout-k").textContent = txt; }
    function memo(key, fn) { if (!(key in cache)) cache[key] = fn(); return cache[key]; }
    function nominalPolicy() { return memo("nom", function () { return trainGrid(rep(world(), NTRAIN)); }); }
    function realDR() { return world(REALS[st.real].w); }
    function realDelay() { return world({ d: Math.round(st.dReal / 20), jit: st.dType === "rand" ? 1 : 0 }); }
    function realGAT() { return world(GAT_REAL); }
    function trainDR(width) { return memo("dr" + width, function () { return trainGrid(drWorlds(width, NTRAIN, 1)); }); }
    function trainDelay(dmaxSteps, hist) { return memo("dl" + dmaxSteps + hist, function () { return trainGrid(delayWorlds(dmaxSteps, NTRAIN, 1), { useC: hist }); }); }
    function gatRun(n, ds) {
      return memo("gat" + n + "_" + ds, function () {
        var base = nominalPolicy(), data = collect(base.p, realGAT(), n, ds), m = fitReal(data), g = grounder(m);
        var tr = trainGrid(rep(world(), NTRAIN), { ground: g });
        return { base: base, m: m, g: g, tr: tr, errG: modelErr(realGAT(), g) };
      });
    }
    function trajOf(p, w, o) { o = o || {}; o.traj = true; return episode(p, w, RB.rng(seed * 101 + 7), o); }

    /* ----- compute everything for the current mode ----- */
    function compute() {
      var m = st.mode, lanes = [], P;
      res = { mode: m };
      if (m === "dr") {
        var tr = trainDR(st.width), rw = realDR(), sims = drWorlds(st.width, NEVAL, 2 + seed);
        P = tr.p;
        res.psiS = evalSet(P, sims, 50 + seed).succ; res.psiR = evalSet(P, rep(rw, NEVAL), 60 + seed).succ;
        res.gridTrain = tr.grid; res.chosen = { ri: tr.ri, gi: tr.gi };
        res.gridReal = memo("land" + st.real, function () { return landscape(rep(rw, NTRAIN), 0, 11); });
        res.bestReal = argmax(res.gridReal);
        lanes = [{ name: "Simulator, nominal ω", ep: trajOf(P, world()), c: "data-1" }, { name: "Real robot: " + REALS[st.real].label.toLowerCase(), ep: trajOf(P, rw), c: "data-3" }];
        label("r1", "ψ in training sims"); label("r2", "ψ on the real robot"); label("r3", "Gap G(π)"); label("r4", "Chosen g, r"); label("r5", "Best g, r on real"); label("r6", "Training sims");
        RB.setRO(scene, "r1", pct(res.psiS)); RB.setRO(scene, "r2", pct(res.psiR)); RB.setRO(scene, "r3", RB.fmt(res.psiS - res.psiR, 2));
        RB.setRO(scene, "r4", GS[tr.gi] + ", " + RS[tr.ri]); RB.setRO(scene, "r5", GS[res.bestReal.gi] + ", " + RS[res.bestReal.ri]); RB.setRO(scene, "r6", NTRAIN + (st.width ? " random" : " nominal"));
        api.meta("Width ±" + Math.round(st.width * 100) + "% · real: " + REALS[st.real].text);
        cap("Same policy, two worlds. Watch whether the real cart-pole survives the tap at 2.5 s; the red band marks the 0.4 rad failure angle.",
          "Each cell is one controller: stronger color means higher mean return. The ring is the policy training chose; the diamond is the best one on the real robot.");
      } else if (m === "delay") {
        var dS = Math.round(st.dTrain / 20), tr2 = trainDelay(dS, st.hist), none = trainDelay(0, false), rw2 = realDelay();
        P = tr2.p;
        res.psiS = evalSet(P, delayWorlds(dS, NEVAL, 2 + seed), 50 + seed).succ; res.psiR = evalSet(P, rep(rw2, NEVAL), 60 + seed).succ;
        res.psiNone = evalSet(none.p, rep(rw2, NEVAL), 60 + seed).succ;
        res.gridTrain = tr2.grid; res.chosen = { ri: tr2.ri, gi: tr2.gi };
        res.gridReal = landscape(rep(rw2, NTRAIN), P.c, 11); res.bestReal = argmax(res.gridReal);
        lanes = [{ name: "Trained without delay", ep: trajOf(none.p, rw2), c: "data-1" }, { name: "Your recipe", ep: trajOf(P, rw2), c: "data-3" }];
        label("r1", "ψ in training sims"); label("r2", "ψ real, your recipe"); label("r3", "ψ real, no-delay policy"); label("r4", "Chosen g, r"); label("r5", "Last-action weight c"); label("r6", "Real delay");
        RB.setRO(scene, "r1", pct(res.psiS)); RB.setRO(scene, "r2", pct(res.psiR)); RB.setRO(scene, "r3", pct(res.psiNone));
        RB.setRO(scene, "r4", GS[tr2.gi] + ", " + RS[tr2.ri]); RB.setRO(scene, "r5", st.hist ? RB.fmt(P.c, 1) : "off"); RB.setRO(scene, "r6", st.dReal + " ms" + (st.dType === "rand" ? " max" : ""));
        api.meta("Control 50 Hz · one step = 20 ms · training delay 0 to " + st.dTrain + " ms");
        cap("Both policies run on the same delayed robot. Look for growing oscillation: the policy corrects an angle that has already changed.",
          "Controllers ranked on the training sims (ring = chosen). Switch to Randomize to compare with the real-robot landscape there.");
      } else if (m === "gat") {
        var gr = gatRun(NLIST[st.nReal], seed + 2), rw3 = realGAT(), orc = memo("gatOracle", function () { return trainGrid(rep(rw3, NTRAIN)); });
        P = gr.tr.p;
        res.psiBase = evalSet(gr.base.p, rep(rw3, NEVAL), 60 + seed).succ; res.psiR = evalSet(P, rep(rw3, NEVAL), 60 + seed).succ;
        res.psiOr = evalSet(orc.p, rep(rw3, NEVAL), 60 + seed).succ; res.err0 = memo("gatErr0", function () { return modelErr(rw3, null); }); res.errG = gr.errG;
        var init = [0, 0, 0.1, 0];
        res.open = [
          { name: "sim", c: "data-1", ep: episode(gr.base.p, world({ noise: 0 }), RB.rng(1), { traj: true, init: init, push: false }) },
          { name: "grounded", c: "data-2", ep: episode(gr.base.p, world({ noise: 0 }), RB.rng(1), { traj: true, init: init, push: false, ground: gr.g }) },
          { name: "real", c: "data-3", ep: episode(gr.base.p, world({ km: rw3.km, b: rw3.b, noise: 0 }), RB.rng(1), { traj: true, init: init, push: false }) }
        ];
        lanes = [{ name: "Sim-trained policy on real", ep: trajOf(gr.base.p, rw3), c: "data-1" }, { name: "Grounded policy on real", ep: trajOf(P, rw3), c: "data-3" }];
        label("r1", "ψ real, sim-only policy"); label("r2", "ψ real, grounded policy"); label("r3", "ψ real, true-ω policy"); label("r4", "Model error, raw sim"); label("r5", "Model error, grounded"); label("r6", "Grounded pick g, r");
        RB.setRO(scene, "r1", pct(res.psiBase)); RB.setRO(scene, "r2", pct(res.psiR)); RB.setRO(scene, "r3", pct(res.psiOr));
        RB.setRO(scene, "r4", RB.fmt(res.err0, 2)); RB.setRO(scene, "r5", RB.fmt(res.errG, 2)); RB.setRO(scene, "r6", P.g + ", " + P.r);
        api.meta("Real robot: motor force 30% of nominal, friction ×6 · " + NLIST[st.nReal] + " real transitions");
        cap("The simulator-trained controller is too gentle for the weak real motor. The grounded policy was trained only in simulation, but through the learned action transformer.",
          "Sim-trained controller, same start, no noise. Grounding makes the simulator lean and fall like the real robot, so training sees the real problem.");
      } else {
        var base = nominalPolicy(), kmAt = function (t) { return t < CHANGE_T ? NOM.km : NOM.km * st.frac; }, rw4 = world(), R0 = seed * 101 + 7;
        P = base.p;
        var mk = function (lat) { return episode(P, rw4, RB.rng(R0), { traj: true, push: false, kmAt: kmAt, lat: lat, kWin: st.kWin, ref: tsRef }); };
        var eNone = mk(null), eT = mk("teacher"), eS = mk("student");
        lanes = [{ name: "No latent (fixed policy)", ep: eNone, c: "data-1" }, { name: "Student, k = " + st.kWin, ep: eS, c: "data-3" }];
        res.teacher = eT; res.student = eS;
        var errB = latErr(eS.traj, 50, CHANGE_T), errA = latErr(eS.traj, CHANGE_T, CHANGE_T + 50);
        var gap = 0, ng = 0; for (var i = 0; i < Math.min(eT.traj.length, eS.traj.length); i++) { gap += Math.abs(eT.traj[i].a - eS.traj[i].a); ng++; }
        label("r1", "Fixed policy upright"); label("r2", "Teacher upright"); label("r3", "Student upright"); label("r4", "|ẑ − z| before change"); label("r5", "|ẑ − z| first 1 s after"); label("r6", "Mean |a_student − a_teacher|");
        RB.setRO(scene, "r1", eNone.ok ? "all 5 s" : RB.fmt(eNone.alive * DT, 1) + " s"); RB.setRO(scene, "r2", eT.ok ? "all 5 s" : RB.fmt(eT.alive * DT, 1) + " s"); RB.setRO(scene, "r3", eS.ok ? "all 5 s" : RB.fmt(eS.alive * DT, 1) + " s");
        RB.setRO(scene, "r4", RB.fmt(errB, 2)); RB.setRO(scene, "r5", errA == null ? "–" : RB.fmt(errA, 2)); RB.setRO(scene, "r6", RB.fmt(gap / Math.max(1, ng), 3));
        api.meta("Motor drops to " + Math.round(st.frac * 100) + "% at 2 s · latent z = ln(force / nominal force)");
        cap("At 2 s the motor weakens, as with a sagging battery or added load. The fixed policy keeps its old gains; the student rescales its actions by its estimate ẑ.",
          "True latent z (dashed) against the student's estimate ẑ. Short histories are noisy; long ones lag behind the change.");
      }
      res.lanes = lanes; res.policy = P;
      var note = {
        dr: "Randomization trains one controller over simulators whose parameters vary by up to ±" + Math.round(st.width * 100) + "%. Peng et al. did this with 95 parameters and an LSTM policy; here a two-parameter controller has no memory, so it can only be conservative.",
        delay: "Real commands take effect late. P08 lists this latency as an action-side gap source and covers constant-delay and random-delay MDPs. Training with random delays is the early fix; feeding recent actions back is the delayed-MDP fix.",
        gat: "GAT keeps the simulator as a black box. A forward model fit on real transitions predicts where the real robot goes; the inverse simulator model picks the sim action that goes there. The policy then trains in the grounded simulator.",
        ts: "The teacher reads the true motor strength from the simulator, which is privileged information. The student sees only sensor history, like RMA's adaptation module, and must estimate the same latent online."
      }[m];
      document.getElementById(id + "-note").textContent = note;
      draw(); draw2();
    }
    function latErr(tr, a, b) { var s = 0, n = 0; for (var i = a; i < Math.min(b, tr.length); i++) { s += Math.abs(tr[i].zh - tr[i].z); n++; } return n ? s / n : null; }
    function cap(a, b) { document.getElementById(id + "-cap").textContent = a; document.getElementById(id + "-cap2").textContent = b; }

    /* ----- chart: one parameter sweep per mode (computed in the background) ----- */
    function drawChart() {
      var tok = ++chartTok, m = st.mode;
      chartHost.innerHTML = '<p class="sb-caption">Computing the sweep…</p>';
      setTimeout(function () {
        if (tok !== chartTok || !chartHost.isConnected) return;
        var spec;
        if (m === "dr") {
          var ws = [0, 0.25, 0.5, 0.75, 1, 1.25, 1.5], rw = realDR();
          var pS = [], pR = [];
          ws.forEach(function (w) { var tr = trainDR(w); pS.push([Math.round(w * 100), evalSet(tr.p, drWorlds(w, NEVAL, 2), 50).succ]); pR.push([Math.round(w * 100), evalSet(tr.p, rep(rw, NEVAL), 60).succ]); });
          spec = { title: "Success against randomization width", x: { label: "Randomization width ± (%)", min: 0, max: 150 }, y: { label: "success rate", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(2); } },
            series: [{ name: "training sims", color: "data-1", points: pS }, { name: "real: " + REALS[st.real].label.toLowerCase(), color: "data-3", points: pR }],
            caption: "Each width retrains the controller. Transfer appears once the range covers the real robot; wider ranges cost some success in the harder training sims. Your width: ±" + Math.round(st.width * 100) + "%." };
        } else if (m === "delay") {
          var dsR = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], dS = Math.round(st.dTrain / 20), jit = st.dType === "rand" ? 1 : 0;
          var rec = [{ name: "no delay in training", p: trainDelay(0, false).p, c: "data-1" }, { name: "delay 0 to " + Math.max(st.dTrain, 160) + " ms", p: trainDelay(Math.max(dS, 8), false).p, c: "data-2" }, { name: "same + last action", p: trainDelay(Math.max(dS, 8), true).p, c: "data-3" }];
          spec = { title: "Real success against real delay", x: { label: "real delay (ms)", min: 0, max: 200 }, y: { label: "success rate", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(2); } },
            series: rec.map(function (r) { return { name: r.name, color: r.c, points: dsR.map(function (d) { return [d * 20, evalSet(r.p, rep(world({ d: d, jit: jit }), NEVAL), 60).succ]; }) }; }),
            caption: "Three training recipes on a real robot with " + (jit ? "random" : "constant") + " delay. Your real delay is " + st.dReal + " ms." };
        } else if (m === "gat") {
          var rw3 = realGAT(), orc = memo("gatOracle", function () { return trainGrid(rep(rw3, NTRAIN)); });
          var base = evalSet(nominalPolicy().p, rep(rw3, NEVAL), 60).succ, or = evalSet(orc.p, rep(rw3, NEVAL), 60).succ;
          spec = { title: "Real success against real data used for grounding", x: { label: "log₂ real transitions (10 = 1000)", min: 3, max: 10 }, y: { label: "success rate", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(2); } },
            series: [{ name: "grounded policy (3 data draws)", color: "data-3", points: NLIST.map(function (n) { var sm = 0; for (var ds = 5; ds < 8; ds++) sm += evalSet(gatRun(n, ds).tr.p, rep(rw3, NEVAL), 60).succ; return [+RB.fmt(Math.log(n) / Math.LN2, 1), sm / 3]; }) },
              { name: "sim-only policy", color: "data-1", dash: true, points: NLIST.map(function (n) { return [+RB.fmt(Math.log(n) / Math.LN2, 1), base]; }) },
              { name: "trained on true real ω", color: "data-4", dash: true, points: NLIST.map(function (n) { return [+RB.fmt(Math.log(n) / Math.LN2, 1), or]; }) }],
            caption: "Three data draws per point. With 8 transitions the fitted model can mislead retraining; from 15 on (0.3 s of driving at 50 Hz) it transfers. Your setting: " + NLIST[st.nReal] + "." };
        } else {
          var kmAt = function (t) { return t < CHANGE_T ? NOM.km : NOM.km * st.frac; }, P = nominalPolicy().p, pb = [], pa = [];
          KLIST.forEach(function (k) {
            var eb = 0, ea = 0;
            for (var sd = 0; sd < 5; sd++) { var e = episode(P, world(), RB.rng(900 + sd), { traj: true, push: false, kmAt: kmAt, lat: "student", kWin: k, ref: tsRef }); eb += latErr(e.traj, 50, CHANGE_T) || 0; var aa = latErr(e.traj, CHANGE_T, CHANGE_T + 50); ea += aa == null ? Math.abs(Math.log(st.frac)) : aa; }
            pb.push([k * DT, eb / 5]); pa.push([k * DT, ea / 5]);
          });
          spec = { title: "Latent error against history length", x: { label: "student history (s)", min: 0, max: 2 }, y: { label: "mean |ẑ − z|", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(2); } },
            series: [{ name: "steady (noise)", color: "data-2", points: pb }, { name: "after the change (lag)", color: "data-3", points: pa }],
            caption: "Five episodes per point. Noise falls and lag grows with k; Lee et al.'s 0.02, 0.4 and 2.0 s and RMA's 0.5 s sit on this axis." };
        }
        if (tok !== chartTok || !chartHost.isConnected) return;
        chartHost.innerHTML = ""; spec.directLabels = false; StudyBench.lineChart(chartHost, spec);
      }, 30);
    }

    /* ----- canvas 1: lanes of cart-poles and their pole angle ----- */
    function draw() {
      if (!res || !cv.isConnected) return;
      var P = RB.pal(), W = Math.max(300, Math.min(900, cv.parentNode.clientWidth || 720)), narrow = W < 560, mono = font("mono"), body = font("body");
      var lanes = res.lanes, laneH = narrow ? 196 : 132, Ht = lanes.length * laneH + 24;
      var c = RB.canvas(cv, W, Ht), lim = playT == null ? NSTEP : playT;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, Ht);
      lanes.forEach(function (ln, li) {
        var y0 = li * laneH + 4, tr = ln.ep.traj, n = tr.length, k = Math.min(n, lim) - 1, fr = tr[Math.max(0, k)];
        var cw = narrow ? W - 8 : Math.round(W * 0.4), ch = narrow ? 100 : laneH - 26, tx = narrow ? 44 : cw + 56, tw = W - tx - 10, ty = narrow ? y0 + 22 + ch + 8 : y0 + 22, th = narrow ? laneH - ch - 42 : laneH - 34;
        c.fillStyle = P.ink; c.font = "600 12px " + body; c.textAlign = "left"; c.fillText(ln.name, 4, y0 + 12);
        var fell = !ln.ep.ok && k >= n - 1;
        c.fillStyle = fell ? P.bad : P["ink-3"]; c.font = "500 11px " + mono; c.textAlign = "right";
        c.fillText(ln.ep.ok ? (k >= NSTEP - 1 ? "balanced 5 s" : RB.fmt((k + 1) * DT, 1) + " s") : (fell ? "fell at " + RB.fmt(n * DT, 2) + " s" : RB.fmt((k + 1) * DT, 1) + " s"), narrow ? W - 6 : cw, y0 + 12); c.textAlign = "left";
        /* cart view */
        var cx0 = 4, cy0 = y0 + 20, sc = cw / 5.4, gy = cy0 + ch - 14;
        c.fillStyle = P["surface-sunk"]; c.fillRect(cx0, cy0, cw, ch);
        c.strokeStyle = P["line-strong"]; c.lineWidth = 2; c.beginPath(); c.moveTo(cx0 + 6, gy + 9); c.lineTo(cx0 + cw - 6, gy + 9); c.stroke();
        [-X_FAIL, X_FAIL].forEach(function (xl) { var xx = cx0 + cw / 2 + xl * sc; c.strokeStyle = P.bad; c.lineWidth = 1; c.setLineDash([3, 3]); c.beginPath(); c.moveTo(xx, gy - 4); c.lineTo(xx, gy + 12); c.stroke(); c.setLineDash([]); });
        var px = cx0 + cw / 2 + RB.clamp(fr.x, -2.6, 2.6) * sc, plen = Math.min(ch - 26, 1.0 * sc * 1.1);
        c.fillStyle = fell ? P["bad-soft"] : P["surface-strong"]; c.strokeStyle = fell ? P.bad : P["ink-2"]; c.lineWidth = 1.5;
        c.fillRect(px - 16, gy - 4, 32, 12); c.strokeRect(px - 16, gy - 4, 32, 12);
        c.strokeStyle = P[ln.c]; c.lineWidth = 4; c.lineCap = "round"; c.beginPath(); c.moveTo(px, gy - 4); c.lineTo(px + plen * Math.sin(fr.th), gy - 4 - plen * Math.cos(fr.th)); c.stroke(); c.lineCap = "butt";
        c.fillStyle = P.ink; c.beginPath(); c.arc(px, gy - 4, 3, 0, 7); c.fill();
        /* applied force arrow */
        var fa = fr.ae; if (Math.abs(fa) > 0.02) { c.strokeStyle = P.accent; c.fillStyle = P.accent; c.lineWidth = 2; var ax = px + (fa > 0 ? 18 : -18), bx2 = ax + fa * 26; c.beginPath(); c.moveTo(ax, gy + 2); c.lineTo(bx2, gy + 2); c.stroke(); c.beginPath(); c.moveTo(bx2 + (fa > 0 ? 5 : -5), gy + 2); c.lineTo(bx2, gy - 2); c.lineTo(bx2, gy + 6); c.closePath(); c.fill(); }
        /* trace */
        var sx = function (t) { return tx + t / NSTEP * tw; }, sy = function (v) { return ty + th / 2 - v / 0.45 * (th / 2); };
        c.fillStyle = P["surface-sunk"]; c.fillRect(tx, ty, tw, th);
        c.fillStyle = P["bad-soft"]; c.fillRect(tx, ty, tw, Math.max(0, sy(TH_FAIL) - ty)); c.fillRect(tx, sy(-TH_FAIL), tw, Math.max(0, ty + th - sy(-TH_FAIL)));
        c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.beginPath(); c.moveTo(tx, sy(0)); c.lineTo(tx + tw, sy(0)); c.stroke();
        c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.textAlign = "right"; c.fillText("θ", tx - 26, sy(0) + 4); c.fillText("+0.4", tx - 3, sy(TH_FAIL) + 4); c.fillText("−0.4", tx - 3, sy(-TH_FAIL) + 4); c.textAlign = "left";
        if (res.mode !== "ts") { c.strokeStyle = P["ink-3"]; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(sx(PUSH_T), ty); c.lineTo(sx(PUSH_T), ty + th); c.stroke(); c.setLineDash([]); c.fillStyle = P["ink-3"]; c.fillText("tap", sx(PUSH_T) + 3, ty + 10); }
        else { c.strokeStyle = P.warn; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(sx(CHANGE_T), ty); c.lineTo(sx(CHANGE_T), ty + th); c.stroke(); c.setLineDash([]); c.fillStyle = P["ink-3"]; c.fillText("motor weakens", sx(CHANGE_T) + 3, ty + 10); }
        c.strokeStyle = P[ln.c]; c.lineWidth = 1.8; c.beginPath();
        for (var i = 0; i <= k; i++) { var yy = sy(RB.clamp(tr[i].th, -0.45, 0.45)); if (i) c.lineTo(sx(i), yy); else c.moveTo(sx(i), yy); } c.stroke();
        if (fell) { c.fillStyle = P.bad; c.beginPath(); c.arc(sx(n - 1), sy(RB.clamp(tr[n - 1].th, -0.45, 0.45)), 4, 0, 7); c.fill(); }
        if (playT != null) { c.strokeStyle = P.accent; c.lineWidth = 1.5; c.beginPath(); c.moveTo(sx(Math.min(lim, NSTEP)), ty); c.lineTo(sx(Math.min(lim, NSTEP)), ty + th); c.stroke(); }
      });
      c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.textAlign = "right"; c.fillText("time: 0 to 5 s", W - 10, Ht - 6); c.textAlign = "left";
    }

    /* ----- canvas 2: landscape heat map, grounding traces or latent trace ----- */
    function draw2() {
      if (!res || !cv2.isConnected) return;
      var P = RB.pal(), W = Math.max(280, Math.min(520, cv2.parentNode.clientWidth || 440)), mono = font("mono"), body = font("body"), H = 260;
      var c = RB.canvas(cv2, W, H); c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      if (res.mode === "dr" || res.mode === "delay") {
        var grid = res.mode === "dr" && st.view === "real" ? res.gridReal : res.gridTrain, l = 54, t = 26, gw = W - l - 12, gh = H - t - 44, cwid = gw / GS.length, chh = gh / RS.length;
        c.fillStyle = P.ink; c.font = "600 12px " + body; c.fillText(res.mode === "dr" && st.view === "real" ? "Mean return on the real robot" : "Mean return in the training sims", l, 16);
        for (var ri = 0; ri < RS.length; ri++) for (var gi = 0; gi < GS.length; gi++) {
          var v = grid[ri][gi].J, a = RB.clamp(v / 250, 0, 1), x = l + gi * cwid, y = t + (RS.length - 1 - ri) * chh;
          c.fillStyle = P["surface-sunk"]; c.fillRect(x + 1, y + 1, cwid - 2, chh - 2);
          c.globalAlpha = a * a; c.fillStyle = P["data-2"]; c.fillRect(x + 1, y + 1, cwid - 2, chh - 2); c.globalAlpha = 1;
        }
        function mark(cell, kind) { var x = l + (cell.gi + 0.5) * cwid, y = t + (RS.length - 1 - cell.ri + 0.5) * chh; c.lineWidth = 2.5; if (kind === "ring") { c.strokeStyle = P.ink; c.beginPath(); c.arc(x, y, Math.min(cwid, chh) * 0.34, 0, 7); c.stroke(); } else { c.fillStyle = P.accent; c.beginPath(); c.moveTo(x, y - 6); c.lineTo(x + 6, y); c.lineTo(x, y + 6); c.lineTo(x - 6, y); c.closePath(); c.fill(); } }
        mark(res.chosen, "ring"); if (res.mode === "dr") mark(res.bestReal, "dia");
        c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.textAlign = "center";
        GS.forEach(function (g, gi2) { if (W > 380 || gi2 % 2 === 0) c.fillText(String(g), l + (gi2 + 0.5) * cwid, t + gh + 13); });
        c.fillText("gain g (log scale)", l + gw / 2, t + gh + 28); c.textAlign = "right";
        RS.forEach(function (r, ri2) { c.fillText(String(r), l - 6, t + (RS.length - 1 - ri2 + 0.5) * chh + 4); });
        c.save(); c.translate(12, t + gh / 2); c.rotate(-Math.PI / 2); c.textAlign = "center"; c.fillText("damping r", 0, 0); c.restore(); c.textAlign = "left";
      } else if (res.mode === "gat") {
        var l2 = 40, t2 = 30, w2 = W - l2 - 10, h2 = H - t2 - 34, T2 = 75, sx = function (i) { return l2 + i / T2 * w2; }, sy = function (v) { return t2 + h2 / 2 - v / 0.45 * (h2 / 2); };
        c.fillStyle = P.ink; c.font = "600 12px " + body; c.fillText("Pole angle, first 1.5 s", 6, 16);
        c.fillStyle = P["surface-sunk"]; c.fillRect(l2, t2, w2, h2);
        c.fillStyle = P["bad-soft"]; c.fillRect(l2, t2, w2, sy(TH_FAIL) - t2); c.fillRect(l2, sy(-TH_FAIL), w2, t2 + h2 - sy(-TH_FAIL));
        res.open.forEach(function (o, k2) {
          c.strokeStyle = P[o.c]; c.lineWidth = k2 === 1 ? 2.5 : 1.8; c.setLineDash(k2 === 1 ? [6, 4] : []); c.beginPath();
          o.ep.traj.slice(0, T2).forEach(function (q, i) { var yy = sy(RB.clamp(q.th, -0.45, 0.45)); if (i) c.lineTo(sx(i), yy); else c.moveTo(sx(i), yy); }); c.stroke(); c.setLineDash([]);
        });
        c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.textAlign = "right"; c.fillText("+0.4", l2 - 4, sy(TH_FAIL) + 4); c.fillText("0", l2 - 4, sy(0) + 4); c.fillText("−0.4", l2 - 4, sy(-TH_FAIL) + 4);
        c.textAlign = "left"; c.fillText("0 s", l2, t2 + h2 + 14); c.textAlign = "right"; c.fillText("1.5 s", l2 + w2, t2 + h2 + 14); c.textAlign = "left";
        var lx = l2 + 4; res.open.forEach(function (o, k3) { c.fillStyle = P[o.c]; c.fillRect(lx, H - 12, 14, 3); c.fillStyle = P["ink-2"]; c.font = "500 11px " + body; c.fillText(o.name, lx + 18, H - 7); lx += 22 + c.measureText(o.name).width + 12; });
      } else {
        var l3 = 44, t3 = 30, w3 = W - l3 - 10, h3 = H - t3 - 34, trS = res.student.traj, sx3 = function (i) { return l3 + i / NSTEP * w3; }, sy3 = function (v) { return t3 + h3 * (0.15 + 0.7 * (0.3 - v) / 1.9); };
        c.fillStyle = P.ink; c.font = "600 12px " + body; c.fillText("Motor latent z and the student's ẑ", 6, 16);
        c.fillStyle = P["surface-sunk"]; c.fillRect(l3, t3, w3, h3);
        c.strokeStyle = P.ink; c.lineWidth = 1.5; c.setLineDash([5, 4]); c.beginPath(); c.moveTo(sx3(0), sy3(0)); c.lineTo(sx3(CHANGE_T), sy3(0)); c.lineTo(sx3(CHANGE_T), sy3(Math.log(st.frac))); c.lineTo(sx3(NSTEP), sy3(Math.log(st.frac))); c.stroke(); c.setLineDash([]);
        c.strokeStyle = P["data-3"]; c.lineWidth = 1.6; c.beginPath(); trS.forEach(function (q, i) { var yy = sy3(RB.clamp(q.zh, -1.6, 0.3)); if (i) c.lineTo(sx3(i), yy); else c.moveTo(sx3(i), yy); }); c.stroke();
        c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.textAlign = "right"; [0, -0.5, -1, -1.5].forEach(function (v) { c.fillText(RB.fmt(v, 1), l3 - 4, sy3(v) + 4); });
        c.textAlign = "left"; c.fillText("0 s", l3, t3 + h3 + 14); c.textAlign = "right"; c.fillText(trS.length < NSTEP ? "fell at " + RB.fmt(trS.length * DT, 2) + " s" : "5 s", l3 + w3, t3 + h3 + 14); c.textAlign = "left";
        c.fillStyle = P.ink; c.fillRect(l3 + 4, H - 12, 14, 2); c.fillStyle = P["ink-2"]; c.font = "500 11px " + body; c.fillText("true z", l3 + 22, H - 7);
        c.fillStyle = P["data-3"]; c.fillRect(l3 + 80, H - 12, 14, 3); c.fillStyle = P["ink-2"]; c.fillText("ẑ, k = " + st.kWin, l3 + 98, H - 7);
      }
    }

    /* ----- replay ----- */
    function stop() { if (raf) cancelAnimationFrame(raf); raf = 0; }
    function play() {
      stop(); var t0 = performance.now(), speed = 2;
      api.live("running", "Replaying at 2× speed");
      (function tick(now) {
        playT = Math.min(NSTEP, Math.floor((now - t0) / 1000 * speed / DT)); draw();
        if (playT >= NSTEP) { playT = null; raf = 0; runs++; draw(); api.live("paused", "Replayed 5 s"); return; }
        raf = requestAnimationFrame(tick);
      })(t0);
    }
    function showMode() {
      RB.$$("[data-m]", ctl).forEach(function (r) { r.hidden = r.getAttribute("data-m") !== st.mode; });
      RB.$$("[data-s]", api.side).forEach(function (r) { r.hidden = r.getAttribute("data-s") !== st.mode; });
    }
    function refresh(withChart) { stop(); playT = null; clearTimeout(simT); simT = setTimeout(function () { compute(); if (withChart) { clearTimeout(chartT); chartT = setTimeout(drawChart, 60); } }, 20); }

    bindSeg(ctl, id + "-mode", function (v) { st.mode = v; showMode(); refresh(true); });
    bindSeg(ctl, id + "-real", function (v) { st.real = v; refresh(true); });
    bindSeg(ctl, id + "-view", function (v) { st.view = v; draw2(); });
    bindSeg(ctl, id + "-dt", function (v) { st.dType = v; refresh(true); });
    RB.bindSlider(ctl, id + "-w", function (v) { return v + "%"; }, function (v) { st.width = v / 100; refresh(true); });
    RB.bindSlider(ctl, id + "-dr", null, function (v) { st.dReal = v; refresh(true); });
    RB.bindSlider(ctl, id + "-dtr", null, function (v) { st.dTrain = v; refresh(true); });
    ctl.querySelector("#" + id + "-hist").addEventListener("change", function (e) { st.hist = e.target.checked; refresh(false); });
    RB.bindSlider(ctl, id + "-n", function (v) { return String(NLIST[v]); }, function (v) { st.nReal = v; refresh(false); });
    RB.bindSlider(ctl, id + "-k", function (v) { return v + " steps (" + RB.fmt(v * DT, 2) + " s)"; }, function (v) { st.kWin = v; refresh(false); });
    RB.bindSlider(ctl, id + "-f", function (v) { return v + "%"; }, function (v) { st.frac = v / 100; refresh(true); });
    ctl.querySelector("#" + id + "-seed").addEventListener("click", function () { seed++; refresh(false); });
    ctl.querySelector("#" + id + "-go").addEventListener("click", play);
    if (window.ResizeObserver) { ro = new ResizeObserver(function () { var w = scene.clientWidth; if (Math.abs(w - lastW) < 2) return; lastW = w; draw(); draw2(); }); ro.observe(scene); }
    showMode(); compute(); drawChart();
    RB.onTheme(function () { if (cv.isConnected) { draw(); draw2(); if (chartHost.querySelector("svg")) drawChart(); } });

    function state() { return { mode: st.mode, width: st.width, view: st.view, dTrain: st.dTrain, hist: st.hist, kWin: st.kWin, nReal: NLIST[st.nReal], playing: !!raf, runs: runs, psiR: res ? res.psiR : null }; }
    return {
      state: state,
      destroy: function () { stop(); clearTimeout(simT); clearTimeout(chartT); chartTok++; if (ro) ro.disconnect(); },
      demo: function () {
        var q = function (s) { return scene.querySelector(s) || ctl.querySelector(s); }, S = state;
        return [
          { target: q("#" + id + "-cv"), title: "One policy, two worlds", text: "Top: the simulator the controller was tuned in. Bottom: a real robot with a weaker motor it never saw. Both get a tap at 2.5 s." },
          { target: q("#" + id + "-w"), title: "Train on one simulator", text: "At 0% the search tunes the controller to the nominal simulator only. It balances there but falls in most episodes on the weak real motor.", do: function (a) { return a.set(q("#" + id + "-w"), 0); }, task: "Set the randomization width to 0%", expect: function () { return S().width === 0; } },
          { target: q("#" + id + "-view"), title: "Where the real optimum is", text: "The real robot's landscape differs from the nominal one. Widen the range to 100% and the chosen ring moves toward the diamond.", do: function (a) { return a.click(q("#" + id + '-view [value="real"]')).then(function () { return a.set(q("#" + id + "-w"), 100); }); }, task: "Show the real-robot landscape", expect: function () { return S().view === "real"; } },
          { target: q("#" + id + "-mode"), title: "Commands arrive late", text: "The real robot now applies each command 100 ms late. A controller tuned without delay overcorrects and oscillates.", do: function (a) { return a.click(q("#" + id + '-mode [value="delay"]')); }, task: "Choose the Delay mode", expect: function () { return S().mode === "delay"; } },
          { target: q("#" + id + "-dtr"), title: "Randomize the delay", text: "Train with delays drawn up to 160 ms, as Peng et al. randomized the action timestep. The search picks a calmer controller.", do: function (a) { return a.set(q("#" + id + "-dtr"), 160); }, task: "Train with delays up to 160 ms", expect: function () { return S().dTrain >= 160; } },
          { target: q("#" + id + "-mode"), title: "Ground the simulator", text: "GAT fits the real dynamics from logged transitions, then transforms every simulated action. The grounded simulator falls like the real robot.", do: function (a) { return a.click(q("#" + id + '-mode [value="gat"]')); }, task: "Choose Ground (GAT)", expect: function () { return S().mode === "gat"; } },
          { target: q("#" + id + "-k"), title: "Estimate the hidden latent", text: "The motor weakens at 2 s. The student estimates it from its history. Try a single step: the estimate becomes noisy.", do: function (a) { return a.click(q("#" + id + '-mode [value="ts"]')).then(function () { return a.wait(300); }).then(function () { return a.set(q("#" + id + "-k"), 1); }); }, task: "Set the student history to 1 step", expect: function () { return S().mode === "ts" && S().kWin <= 2; } },
          { target: q("#" + id + "-go"), title: "Your turn", text: "Try 20, 50 and 100 steps and replay each. Then compare the sweep chart with Lee et al.'s 0.02, 0.4 and 2.0 s histories.", do: function (a) { return a.click(q("#" + id + "-go")).then(function () { return a.until(function () { return !S().playing; }, 6000); }); } }
        ];
      }
    };
  }

  RB.station({
    id: SID, name: "Sim-to-real station", sub: "04 · 03",
    refs: ["P08 §2.1.2, §3.2–3.3", "P07 §4.1.1"], prov: "Simplified: cart-pole toy",
    summary: "A cart-pole controller is tuned in simulation, then run on a hidden real robot. Randomize the simulator, add delay, ground the simulator with real data, or let a student estimate a hidden latent.",
    notice: [
      "A controller tuned on one simulator can fall on a robot it never saw; randomization moves the choice toward robust controllers.",
      "Delay hurts high-gain controllers most; training with random delays, or feeding recent actions back, restores stability.",
      "Grounding needs a few hundred real transitions here, and the policy still trains only in simulation.",
      "A short history gives a noisy latent estimate; a long one lags behind a sudden change."
    ],
    card: "Randomize, delay, ground and distill: four ways to make a sim-trained cart-pole survive a hidden real robot.",
    ledger: [
      { where: "Lab · Sim-to-real · task", source: "The brief names cart-pole or hopper; P08 and P07 discuss locomotion and manipulation robots", page: "One cart-pole with classic constants: cart 1 kg, pole 0.1 kg, half-length 0.5 m, 10 N motor, 50 Hz, plus viscous cart friction", why: "Four mechanisms fit in one small, fast system; a hopper needs contact physics the browser toy does not have.", kind: "Our choice" },
      { where: "Lab · Sim-to-real · training", source: "The papers train neural policies with RL (PPO, DDPG with HER)", page: "Exhaustive search over a linear controller family with gain g, damping r and, in Delay mode, a last-action weight c", why: "Deterministic, fast and visible as a landscape; the transfer effects come from the same objective.", kind: "Simplified" },
      { where: "Lab · Sim-to-real · ψ", source: "P08 eq. 2 defines G(π) = ψₛ − ψᵣ with one calibrated metric", page: "ψ is the share of 40 episodes that stay upright for 5 s; ψₛ is measured on the training distribution", why: "For a randomized policy, the nominal simulator alone would overstate ψₛ.", kind: "Our choice" },
      { where: "Lab · Sim-to-real · delay", source: "P08 §3.2 and DCAC (arXiv 2010.02966) augment the state with the action buffer and delay values", page: "Delay mode feeds back only the last action, with one weight c; random delay redraws 0 to d steps every step", why: "One extra input shows the effect of state augmentation on a linear controller.", kind: "Simplified" },
      { where: "Lab · Sim-to-real · GAT", source: "GAT learns a forward model of the real robot and an inverse model of the simulator (SGAT §II-C, arXiv 2008.01281)", page: "f_real is a linear least-squares fit of accelerations; the simulator inverse is exact, because force enters the toy linearly", why: "Keeps the two-model structure without training networks in the browser.", kind: "Simplified" },
      { where: "Lab · Sim-to-real · teacher–student", source: "RMA and Lee 2020 learn a latent of many environment parameters with networks", page: "One latent z = ln(motor force / nominal); the student estimates it by least squares over its last k transitions and rescales its actions", why: "Makes the noise-against-lag trade-off of the history length visible.", kind: "Simplified" },
      { where: "Lab · Sim-to-real · history units", source: "RMA runs at 100 Hz with k = 50 (0.5 s); Lee 2020 compares 1, 20 and 100 steps at 50 Hz", page: "The student slider counts 20 ms steps and also shows seconds", why: "Compare by time: our 50 Hz steps match Lee 2020's history lengths.", kind: "Our choice" }
    ],
    mount: mount
  });
})();
