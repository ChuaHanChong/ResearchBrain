/* Interactive Lab · Compliance station (topics 02, 19, 18).
   Sources: P10 §5.1 (eq. 22–28: PD, impedance, admittance, hybrid force/position with selection matrix S), P10 §5.2–5.3
   (controller counts and platforms), P10 §3.2.2–3.2.3 and Fig. 1–2 (TF-ART phases, reference force, stiffness outputs);
   P09 §VI-A–C (eq. 5–7, hierarchical versus weighted QP). Method cards: ACP (2410.09309), SERL (2401.16013), FoAR (2411.15753),
   Force Policy (2602.22088), MOMA-Force (2308.03624).
   Two benches:
   1. Arm: a 2-D point tool (1.5 kg per axis, no gravity) wipes a surface with an unseen bump or dip. Physics at 5 kHz, control
      at 1 kHz, wrist force sensor with noise and a 2 ms filter, Coulomb friction on the surface and in the arm. Five controllers
      execute the same planned stroke; a TF-ART timeline shows the contact gate (Phase 0), plan ticks (Phase 1), an optional fast
      force refiner (Phase 2) and the control mode (Phase 3).
   2. Humanoid: a static planar balance toy. A standing body presses its hand on a table; the whole-body controller picks the hand
      force and a lean of the center of mass under a strict task hierarchy or with weights. All numbers are ours unless cited. */
(function () {
  "use strict";
  var RB = window.RB;
  var SID = "compliance";

  function font(kind) { return getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body") || "sans-serif"; }
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function pressSeg(root, id, v) { RB.$$("#" + id + " button", root).forEach(function (b) { var on = b.value === v; b.setAttribute("aria-pressed", on ? "true" : "false"); b.tabIndex = on ? 0 : -1; }); }
  function sig(v) { return 1 / (1 + Math.exp(-v)); }
  function CHK(k, label, on) { return '<label style="display:inline-flex;align-items:center;gap:6px;font:500 14px/20px var(--font-body);color:var(--ink)"><input type="checkbox" id="' + SID + "-" + k + '"' + (on ? " checked" : "") + "> " + label + "</label>"; }

  /* =========================== bench 1: the arm at the surface =========================== */
  var T_END = 4, DT = 0.0002, SUB = 5, REC = 25; /* 5 kHz physics, 1 kHz control, record every 5 ms */
  var MASS = 1.5, KP_STIFF = 40000, X0 = 0.04, X1 = 0.36, Z_UP = 0.06, BUMP_X = 0.2, BUMP_W = 0.03, F_LIMIT = 50;
  var ENV = { sponge: 5e3, rubber: 3e4, wood: 3e5 };
  var CTRL = [{ value: "pd", label: "PD position" }, { value: "imp", label: "Impedance" }, { value: "adm", label: "Admittance" }, { value: "hyb", label: "Hybrid" }, { value: "acp", label: "Learned stiffness" }];
  var CCOL = { pd: "data-3", imp: "data-1", adm: "data-2", hyb: "data-4", acp: "data-5" };
  var CNAME = { pd: "PD position", imp: "Impedance", adm: "Admittance", hyb: "Hybrid F/P", acp: "Learned stiffness" };
  var SENSOR = { pd: false, imp: false, adm: true, hyb: true, acp: true };
  var ACP_K = { kmin: 200, kmax: 1000, fmin: 1, fmax: 11 }; /* toy limits, as in Topic 19's worked example */

  function smooth(u) { u = RB.clamp(u, 0, 1); return u * u * (3 - 2 * u); }
  function surfH(x, A, O) { var d = (x - BUMP_X) / BUMP_W; return (O || 0) + A * Math.exp(-d * d / 2); }
  function surfD(x, A) { var d = (x - BUMP_X) / BUMP_W; return -A * d / BUMP_W * Math.exp(-d * d / 2); }
  function phaseAt(t) { return t < 0.8 ? "approach" : t < 3.2 ? "wipe" : "lift"; }
  /* the planned stroke: the policy believes the surface is flat at z = 0 and aims `depth` below it */
  function plan(t, depth) {
    var x, z, vx = 0, vz = 0;
    if (t < 0.8) { var u = smooth((t - 0.2) / 0.6); x = X0; z = Z_UP + (-depth - Z_UP) * u; }
    else if (t < 3.2) { var w = (t - 0.8) / 2.4, s = smooth(w); x = X0 + (X1 - X0) * s; z = -depth; vx = (X1 - X0) * 6 * w * (1 - w) / 2.4; }
    else { x = X1; z = -depth + (Z_UP + depth) * smooth((t - 3.2) / 0.6); }
    if (t >= 0.2 && t < 0.8) { var uu = RB.clamp((t - 0.2) / 0.6, 0, 1); vz = (-depth - Z_UP) * 6 * uu * (1 - uu) / 0.6; }
    if (t >= 3.2 && t < 3.8) { var u3 = RB.clamp((t - 3.2) / 0.6, 0, 1); vz = (Z_UP + depth) * 6 * u3 * (1 - u3) / 0.6; }
    return { x: x, z: z, vx: vx, vz: vz };
  }
  function band(Fref) { return 0.3 * Fref + 1; }
  function acpK(F) { return RB.clamp(ACP_K.kmax - (ACP_K.kmax - ACP_K.kmin) * (Math.abs(F) - ACP_K.fmin) / (ACP_K.fmax - ACP_K.fmin), ACP_K.kmin, ACP_K.kmax); }

  function simulate(c, P, seed) {
    var R = RB.rng(seed), ke = ENV[P.env], be = 2 * 0.1 * Math.sqrt(ke * MASS), A = P.bump / 1000, O = P.off / 1000, depth = P.Fref / P.Kz;
    var Kx = P.Kx, Kz = P.Kz, Bx = 2 * 0.7 * Math.sqrt(Kx * MASS), Bz = 2 * 0.7 * Math.sqrt(Kz * MASS), Kv = 2 * 0.7 * Math.sqrt(KP_STIFF * MASS);
    var Md = 2, BdxA = 2 * 0.9 * Math.sqrt(Kx * Md), BdzA = 2 * 0.9 * Math.sqrt(Kz * Md);
    var x = X0, z = Z_UP, vx = 0, vz = 0, ux = 0, uz = 0;
    var fmx = 0, fmz = 0, fav = 0, phi = 0, alpha = 1 - Math.exp(-0.5); /* 2 ms sensor filter at 1 kHz */
    var xc = X0, zc = Z_UP, vxc = 0, vzc = 0, Iint = 0, zRel = null, dzRef = 0, zv = null, kz = ACP_K.kmax, mode = "pos";
    var rec = [], p1 = [], p2 = [], peak = 0, n = 0, latch = false;
    for (var i = 0; i <= T_END / DT; i++) {
      var t = i * DT, h = surfH(x, A, O), hd = surfD(x, A), nrm = Math.sqrt(1 + hd * hd), nx = -hd / nrm, nz = 1 / nrm;
      var pen = h - z, Fn = 0, Ft = 0;
      if (pen > 0) { Fn = Math.max(0, ke * pen / nrm - be * (vx * nx + vz * nz)); var vt = (vx + vz * hd) / nrm; Ft = -P.mu * Fn * Math.tanh(vt / 0.003); }
      var tx = 1 / nrm, tz = hd / nrm, Fx = Fn * nx + Ft * tx, Fz = Fn * nz + Ft * tz;
      if (Fn > peak && t >= 1.0 && t <= 3.1) peak = Fn;
      if (i % SUB === 0) {
        n++;
        /* wrist sensor: noisy, filtered; a 10 ms average feeds the contact gate (Phase 0, 100 Hz) */
        fmx += (Fx + P.noise * R.normal() - fmx) * alpha; fmz += (Fz + P.noise * R.normal() - fmz) * alpha;
        fav += (fmz - fav) * 0.2;
        phi = sig((fav - 2) / 0.6);
        var ph = phaseAt(t), pl = plan(t, depth);
        /* a mode switch latches: once the gate opens before or during the wipe, force control stays on until the lift */
        if (ph === "lift") latch = false; else if (phi > 0.5) latch = true;
        var wantsForce = latch;
        /* Phase 2: optional fast force refiner at 50 Hz shifts the depth target (PD, impedance, admittance) */
        if (P.refine && (c === "pd" || c === "imp" || c === "adm") && n % 20 === 0) {
          if (wantsForce && ph === "wipe") { dzRef += 0.25 * (fmz - P.Fref) / (c === "pd" ? 20000 : Kz); dzRef = RB.clamp(dzRef, -0.03, 0.03); p2.push(t); }
          else if (ph !== "wipe") dzRef = 0;
        }
        var zd = pl.z + dzRef;
        if (c === "pd") { ux = KP_STIFF * (pl.x - x) + Kv * (pl.vx - vx); uz = KP_STIFF * (zd - z) + Kv * (pl.vz - vz); mode = "pos"; }
        else if (c === "imp") { ux = Kx * (pl.x - x) + Bx * (pl.vx - vx); uz = Kz * (zd - z) + Bz * (pl.vz - vz); mode = "imp"; }
        else if (c === "adm") {
          var axc = (fmx - BdxA * (vxc - pl.vx) - Kx * (xc - pl.x)) / Md, azc = (fmz - BdzA * (vzc - pl.vz) - Kz * (zc - zd)) / Md;
          vxc += axc * 0.001; xc += vxc * 0.001; vzc += azc * 0.001; zc += vzc * 0.001;
          ux = KP_STIFF * (xc - x) + Kv * (vxc - vx); uz = KP_STIFF * (zc - z) + Kv * (vzc - vz); mode = "adm";
        } else if (c === "hyb") {
          /* u = F(S e_F) + P((I − S) e): force PI with damping on selected axes once the gate reports contact */
          if (wantsForce && P.Sz) { var eF = P.Fref - fmz; Iint = RB.clamp(Iint + eF * 0.001, -2, 2); uz = -P.Fref - 0.3 * eF - 15 * Iint - 60 * vz; mode = "force"; }
          else {
            Iint = 0; var zt2 = pl.z, vt2 = pl.vz;
            if (ph === "lift") { if (zRel === null) zRel = z; var ul = smooth((t - 3.2) / 0.6); zt2 = zRel + (Z_UP - zRel) * ul; vt2 = 0; }
            uz = KP_STIFF * (zt2 - z) + Kv * (vt2 - vz); mode = "pos";
          }
          if (wantsForce && P.Sx && ph === "wipe") ux = -60 * vx; else ux = KP_STIFF * (pl.x - x) + Kv * (pl.vx - vx);
          if (wantsForce && P.Sx && ph === "wipe") mode = P.Sz ? "forcexz" : "mixed";
        } else {
          /* learned stiffness (ACP-style): every 100 ms read the force, set k along it and a virtual target F_ref/k below the tool */
          if (n % 100 === 1 || zv === null) {
            if (ph === "wipe" && latch) { kz = acpK(P.Fref); zv = z - P.Fref / kz; } else { kz = ACP_K.kmax; zv = null; }
            if (n % 100 === 1) p1.push(t);
          }
          var zt = zv === null ? pl.z : zv, kk = zv === null ? Kz : kz, bb = 2 * 0.7 * Math.sqrt(kk * MASS);
          ux = Kx * (pl.x - x) + Bx * (pl.vx - vx); uz = kk * (zt - z) + bb * ((zv === null ? pl.vz : 0) - vz); mode = "imp";
        }
        if (n % 5 === 0) rec.push({ t: t, x: x, z: z, Fn: Fn, fm: fmz, phi: phi, mode: ph === "wipe" || c !== "hyb" ? mode : "pos", xd: pl.x, zd: c === "acp" && zv !== null ? zv : zd, xc: xc, zc: zc, k: c === "acp" ? kz : null, ph: ph });
      }
      /* unmodeled arm friction (Coulomb) acts on the robot's own motion */
      var frx = P.fr * Math.tanh(vx / 0.002), frz = P.fr * Math.tanh(vz / 0.002);
      vx += (ux + Fx - frx) / MASS * DT; vz += (uz + Fz - frz) / MASS * DT; x += vx * DT; z += vz * DT;
      if (!isFinite(x) || !isFinite(z) || Math.abs(z) > 2) { x = X0; z = Z_UP; vx = vz = 0; break; }
    }
    if (c !== "acp") { p1 = []; for (var q = 0; q <= T_END; q += 0.1) p1.push(q); }
    var wipe = rec.filter(function (r) { return r.t >= 1.0 && r.t <= 3.1; }), bw = band(P.Fref);
    var good = 0, lost = 0, err2 = 0, lag = 0;
    wipe.forEach(function (r) { var e = r.Fn - P.Fref; if (Math.abs(e) <= bw) good++; if (r.Fn < 0.5) lost++; err2 += e * e; lag = Math.max(lag, Math.abs(r.xd - r.x)); });
    var xEnd = rec.filter(function (r) { return r.t <= 3.2; }).pop().x;
    return { rec: rec, p1: p1, p2: p2, peak: peak, good: good / wipe.length, lost: lost / wipe.length, rms: Math.sqrt(err2 / wipe.length), lag: lag, cover: RB.clamp((xEnd - X0) / (X1 - X0), 0, 1), depth: depth };
  }
  function status(r, Fref) { var e = r.Fn - Fref, bw = band(Fref); return r.Fn < 0.5 ? "lost" : e > bw ? "hard" : e < -bw ? "light" : "good"; }

  /* =========================== bench 2: whole-body priority on a humanoid =========================== */
  var HB = { m: 60, g: 9.81, heel: -0.07, toe: 0.17, marg: 0.02, zh: 0.9, cmin: -0.03, cmax: 0.1, fmax: 150 };
  function cop(Fn, c, xh, s, mu) { return (HB.m * HB.g * c - Fn * (xh + s * mu * HB.zh)) / (HB.m * HB.g - Fn); }
  function viol(xp) { var lo = HB.heel + HB.marg, hi = HB.toe - HB.marg; return Math.max(0, lo - xp, xp - hi); }
  function wbcSolve(o, coarse) {
    var df = coarse ? 1 : 0.5, dc = coarse ? 0.002 : 0.001, pts = [];
    for (var F = 0; F <= HB.fmax + 1e-9; F += df) for (var c = HB.cmin; c <= HB.cmax + 1e-9; c += dc) {
      var xp = cop(F, c, o.xh, o.s, o.mu), v = viol(xp);
      pts.push({ F: F, c: c, xp: xp, bal: v * v, frc: (F - o.Fref) * (F - o.Fref), pos: c * c });
    }
    var best;
    if (o.solver === "wqp") {
      var J = function (p) { return o.wb * p.bal / 1e-4 + p.frc / 100 + 0.2 * p.pos / 0.0025; };
      best = pts.reduce(function (a, p) { return J(p) < J(a) ? p : a; });
      return { F: best.F, c: best.c, xp: best.xp, solves: 1 };
    }
    var order = o.order === "force" ? ["frc", "bal", "pos"] : ["bal", "frc", "pos"], tol = { bal: 1e-8, frc: df * df * 0.3, pos: 1e-9 }, set = pts;
    order.forEach(function (k) { var mn = Math.min.apply(null, set.map(function (p) { return p[k]; })); set = set.filter(function (p) { return p[k] <= mn + tol[k]; }); });
    best = set[0];
    return { F: best.F, c: best.c, xp: best.xp, solves: 3 };
  }

  /* =========================== mount =========================== */
  function mount(api) {
    var id = SID, scene = api.scene, ctl = api.controls;
    var P = { env: "rubber", Kz: 500, Kx: 2000, Fref: 10, bump: 10, off: 0, mu: 0.4, noise: 0.5, fr: 3, Sx: false, Sz: true, refine: false };
    var st = { bench: "arm", ctrl: "imp", seed: 3, runs: 0, playing: false, tPlay: null };
    var H = { solver: "hqp", order: "bal", wb: 1, xh: 0.55, s: 1, Fref: 60 };
    var res = {}, wres = null, raf = 0, ro = null, lastW = 0, chartT = 0, wchartT = 0, simT = 0, dead = false;
    var mm = function (v) { return v + " mm"; }, nm = function (v) { return v + " N/m"; }, nn = function (v) { return v + " N"; };

    scene.innerHTML =
      '<div id="' + id + '-arm" class="rb-stack">' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Side view of an arm wiping a surface with an unseen bump; the tool path is colored by contact force"></canvas>' +
      RB.legend([{ c: "good", label: "force in band", kind: "line" }, { c: "bad", label: "too hard", kind: "line" }, { c: "warn", label: "too light or lost", kind: "line" }, { c: "ink-3", label: "planned surface and target", kind: "dash" }, { c: "vec-wrench", label: "contact force", kind: "line" }]) +
      '<figcaption class="sb-caption">The policy plans a flat surface (dashed). Watch the tool path over the hidden bump: its color says whether the normal force stayed in the band around F_ref.</figcaption></figure>' +
      RB.readouts([{ id: "good", k: "Wipe in force band" }, { id: "peak", k: "Peak force while wiping", u: "N" }, { id: "rms", k: "Force error (RMS)", u: "N" }, { id: "lost", k: "Contact lost" }, { id: "lag", k: "Largest lag along the stroke", u: "mm" }, { id: "cover", k: "Stroke covered" }, { id: "sensor", k: "Needs a force sensor" }]) +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-tl" aria-label="Timeline of the four TF-ART phases and the normal force during one stroke"></canvas>' +
      '<figcaption class="sb-caption">Read one moment top to bottom: is the contact gate open, when does the policy plan, does a fast refiner act, which control law runs, and where the force sits.</figcaption></figure>' +
      '<div id="' + id + '-chart"></div></div>' +
      '<div id="' + id + '-wbc" class="rb-stack" hidden>' +
      '<div class="rb-grid2"><figure class="rb-fig"><svg class="rb-svg" id="' + id + '-hum" viewBox="0 0 300 304" role="img" aria-label="Side view of a humanoid pressing its hand on a table, with the center of pressure on its foot"></svg>' +
      '<figcaption class="sb-caption">The table pushes back on the hand. Where does the center of pressure (triangle) land? Outside the green part of the foot, the body tips.</figcaption></figure>' +
      '<div class="rb-stack"><h4 class="rb-h5">Task stack this step</h4><ol class="rb-notice" id="' + id + '-stack"></ol>' +
      RB.readouts([{ id: "wF", k: "Hand force: got / asked", u: "N" }, { id: "wcop", k: "Center of pressure", u: "cm" }, { id: "wlean", k: "Lean of the center of mass", u: "cm" }, { id: "wbal", k: "Balance" }, { id: "wqp", k: "QPs solved per step" }]) + "</div></div>" +
      '<div id="' + id + '-wchart"></div></div>';

    ctl.innerHTML =
      '<div class="rb-stack">' +
      '<div class="rb-row">' + RB.seg({ id: id + "-bench", label: "Bench", value: "arm", options: [{ value: "arm", label: "Arm contact" }, { value: "wbc", label: "Humanoid" }] }) + "</div>" +
      '<div id="' + id + '-carm" class="rb-stack">' +
      '<div class="rb-row">' + RB.seg({ id: id + "-ctrl", label: "Controller", value: "imp", options: CTRL }) +
      RB.seg({ id: id + "-env", label: "Surface", value: "rubber", options: [{ value: "sponge", label: "Sponge" }, { value: "rubber", label: "Rubber" }, { value: "wood", label: "Wood" }] }) + "</div>" +
      '<div class="rb-row" id="' + id + '-srow"><span class="rb-muted">Hybrid selection matrix S:</span>' + CHK("sx", "force along x", false) + CHK("sz", "force along z", true) + CHK("ref", "Phase 2 fast refiner", false) + "</div>" +
      '<div class="rb-row">' +
      RB.slider({ id: id + "-fref", label: "Reference force F_ref", min: 2, max: 30, step: 1, value: 10, fmt: nn }) +
      RB.slider({ id: id + "-kz", label: "Normal stiffness K_d,z", min: 100, max: 3000, step: 50, value: 500, fmt: nm }) +
      RB.slider({ id: id + "-kx", label: "Tangent stiffness K_d,x", min: 500, max: 5000, step: 100, value: 2000, fmt: nm }) +
      RB.slider({ id: id + "-bump", label: "Unseen bump", min: -15, max: 20, step: 1, value: 10, fmt: mm }) +
      RB.slider({ id: id + "-off", label: "Surface height error", min: -10, max: 15, step: 1, value: 0, fmt: mm }) + "</div>" +
      '<div class="rb-row">' +
      RB.slider({ id: id + "-mu", label: "Surface friction μ", min: 0, max: 1, step: 0.05, value: 0.4, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-noise", label: "Sensor noise σ", min: 0, max: 3, step: 0.25, value: 0.5, fmt: function (v) { return (+v).toFixed(2) + " N"; } }) +
      RB.slider({ id: id + "-fr", label: "Unmodeled arm friction", min: 0, max: 10, step: 1, value: 3, fmt: nn }) +
      '<button class="sb-btn" type="button" id="' + id + '-seed">New noise</button><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Run stroke ▶</button></div></div>' +
      '<div id="' + id + '-cwbc" class="rb-stack" hidden>' +
      '<div class="rb-row">' + RB.seg({ id: id + "-solver", label: "Solver", value: "hqp", options: [{ value: "hqp", label: "Hierarchical QP" }, { value: "wqp", label: "Weighted QP" }] }) +
      RB.seg({ id: id + "-order", label: "Priority order", value: "bal", options: [{ value: "bal", label: "Balance first" }, { value: "force", label: "Force first" }] }) +
      RB.seg({ id: id + "-dir", label: "Wipe direction", value: "push", options: [{ value: "push", label: "Push away" }, { value: "pull", label: "Pull in" }] }) + "</div>" +
      '<div class="rb-row">' +
      RB.slider({ id: id + "-hf", label: "Requested hand force", min: 0, max: 150, step: 5, value: 60, fmt: nn }) +
      RB.slider({ id: id + "-xh", label: "Hand reach", min: 35, max: 75, step: 1, value: 55, fmt: function (v) { return v + " cm"; } }) +
      RB.slider({ id: id + "-wb", label: "Balance weight (log₁₀)", min: -2, max: 2, step: 0.25, value: 0, fmt: function (v) { return (+v).toFixed(2); } }) + "</div></div></div>";

    api.side.innerHTML = '<p class="rb-muted" id="' + id + '-note">–</p><div id="' + id + '-eq"></div>' +
      '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
      '<li>Controllers in P10\'s survey: position 13 papers, impedance 10, hybrid 4, admittance 3 <span class="sb-ref">P10 §5.2</span></li>' +
      '<li>Franka exposes impedance, Flexiv Rizon hybrid force/position, UR5e admittance through its force sensor <span class="sb-ref">P10 §5.2</span></li>' +
      '<li>ACP item flipping: 96%, against 23% at a fixed 500 N/m and 14% for a stiff policy <span class="sb-ref">arXiv 2410.09309</span></li>' +
      '<li>SERL: policy at 10 Hz over a 1 kHz impedance controller <span class="sb-ref">arXiv 2401.16013</span></li>' +
      '<li>FoAR wiping: 0.875 with force at 100 Hz, 0.625 at 2 Hz <span class="sb-ref">arXiv 2411.15753</span></li>' +
      '<li>Force Policy: 5 Hz vision policy in free space, 50 Hz force policy that predicts the selection mask on contact <span class="sb-ref">arXiv 2602.22088</span></li>' +
      '<li>MOMA-Force, admittance whole-body control: 73.3% success, 45.0% without force control <span class="sb-ref">arXiv 2308.03624</span></li></ul>';

    var cv = scene.querySelector("#" + id + "-cv"), tl = scene.querySelector("#" + id + "-tl"), chartHost = scene.querySelector("#" + id + "-chart");
    var hum = scene.querySelector("#" + id + "-hum"), wchartHost = scene.querySelector("#" + id + "-wchart"), stackEl = scene.querySelector("#" + id + "-stack");
    var noteEl = api.side.querySelector("#" + id + "-note"), eqEl = api.side.querySelector("#" + id + "-eq");

    var NOTES = {
      pd: "Position control is the most common low-level controller in P10's survey because every robot offers it. It follows the planned depth literally, so an unseen bump becomes a large force. ACP's stiff baseline broke the tool in vase wiping (arXiv 2410.09309).",
      imp: "Impedance makes the tool act like a spring K_d to the target, with no force sensor. It is the most common compliant mode in P10 and native on the Franka. Unmodeled friction appears as lag along the stroke (P10 §5.1.3).",
      adm: "Admittance feeds the measured force into a virtual mass-spring-damper whose output a stiff position loop tracks (P10 eq. 27). Friction lag shrinks; sensor noise and the filter now enter the loop. ACP and AdmitDiff execute through admittance.",
      hyb: "Hybrid control regulates force along directions with S = 1 and position along the others (P10 eq. 28). Here force control starts when the contact gate opens. Try force along x as well: nothing then drives the stroke.",
      acp: "Variable impedance in the style of ACP: every 100 ms (our choice) the policy reads the force, lowers the normal stiffness and places a virtual target F_ref/k below the tool, so the spring presses with F_ref wherever the surface is."
    };
    var WNOTE = "A humanoid is often asked to apply interaction forces with low priority while keeping balance with high priority (P09 §VI-B). A hierarchical QP solves one problem per level inside the optimum of the levels above; a weighted QP solves once, so low-priority tasks can interfere (P09 §VI-C).";
    var EQ = {
      pd: { name: "PD position control", ref: "P10 eq. 24", tex: "F = K_P\\, \\class{sym-err}{e} + K_V\\, \\dot{\\class{sym-err}{e}}, \\quad \\class{sym-err}{e} = \\class{sym-x}{x}_{\\mathrm{des}} - \\class{sym-x}{x}", words: "Drive the tool to the planned pose with high gains; the force is whatever the surface returns.", key: [{ glyph: "K_P, K_V", meaning: "stiff position gains" }, { sym: "err", glyph: "e", meaning: "pose error" }, "x"] },
      imp: { name: "Impedance control", ref: "P10 eq. 22, 25", tex: "F = \\class{sym-Kd}{K_d}\\, \\class{sym-err}{e} + \\class{sym-Bd}{B_d}\\, \\dot{\\class{sym-err}{e}}, \\quad \\class{sym-err}{e} = \\class{sym-x}{x}_{\\mathrm{des}} - \\class{sym-x}{x}", words: "A spring and damper between target and tool; at rest the contact force is K_d times the gap.", key: ["Kd", { sym: "err", glyph: "e", meaning: "pose error" }, "Bd", "x"] },
      adm: { name: "Admittance control", ref: "P10 eq. 27", tex: "\\class{sym-Md}{M_d}\\ddot{\\class{sym-x}{x}}_c + \\class{sym-Bd}{B_d}(\\dot{\\class{sym-x}{x}}_c - \\dot{\\class{sym-x}{x}}_{\\mathrm{des}}) + \\class{sym-Kd}{K_d}(\\class{sym-x}{x}_c - \\class{sym-x}{x}_{\\mathrm{des}}) = \\class{sym-Fext}{F_{\\mathrm{ext}}}", words: "The measured force moves a virtual target x_c; a stiff position loop tracks it.", key: ["Md", "x", "Bd", "Kd", "Fext", { glyph: "x_c", meaning: "compliant target" }] },
      hyb: { name: "Hybrid force/position control", ref: "P10 eq. 28", tex: "u = \\mathcal{F}\\big(\\class{sym-Ssel}{S_F}\\, e_F\\big) + \\mathcal{P}\\big((I - \\class{sym-Ssel}{S_F})\\, e\\big)", words: "Here S_F = diag(S_x, S_z). Force error goes to a force controller along selected directions, position error to a position controller along the rest.", key: [{ sym: "Ssel", glyph: "S_F", meaning: "force selection matrix" }, { glyph: "e_F, e", meaning: "force and pose errors" }, { glyph: "𝓕, 𝓟", meaning: "force and position controllers" }] },
      acp: { name: "Stiffness from the force (ACP)", ref: "arXiv 2410.09309", prov: "Toy limits", tex: "k = k_{\\max} - (k_{\\max}-k_{\\min})\\frac{|\\class{sym-Fext}{F_{\\mathrm{ext}}}| - f_{\\min}}{f_{\\max}-f_{\\min}}, \\quad z_v = z - \\frac{F_{\\mathrm{ref}}}{k}", words: "Stiffness falls as force grows; the virtual target sits F_ref/k below the tool.", key: ["Fext", { glyph: "k", meaning: "stiffness along the force" }, { glyph: "z_v", meaning: "virtual target height" }] },
      wbc: { name: "Hierarchical versus weighted QP", ref: "P09 eq. 7, §VI-C", tex: "e_i = A_i X - b_i", words: "Every task is linear in the decision variables X. A hierarchical QP minimizes each ‖e_i‖² in priority order; a weighted QP minimizes Σ w_i ‖e_i‖² once.", key: [{ glyph: "e_i", meaning: "task error" }, { glyph: "A_i, b_i", meaning: "task matrix and target" }, { glyph: "X", meaning: "accelerations, contact forces, torques" }, { glyph: "w_i", meaning: "task weight (weighted QP)" }] }
    };
    var eqShown = null;
    function showEq(k) { if (eqShown === k) return; eqShown = k; eqEl.innerHTML = RB.eqBlock(EQ[k]); RB.typeset(eqEl); }

    /* ---------------- arm computations ---------------- */
    function computeArm() {
      ["pd", "imp", "adm", "hyb", "acp"].forEach(function (c) { res[c] = simulate(c, P, st.seed); });
      var r = res[st.ctrl];
      RB.setRO(scene, "good", Math.round(100 * r.good) + "%");
      RB.setRO(scene, "peak", RB.fmt(r.peak, 1) + (r.peak > F_LIMIT ? " ✗" : ""));
      RB.setRO(scene, "rms", RB.fmt(r.rms, 1));
      RB.setRO(scene, "lost", Math.round(100 * r.lost) + "%");
      RB.setRO(scene, "lag", RB.fmt(r.lag * 1000, 1));
      RB.setRO(scene, "cover", Math.round(100 * r.cover) + "%");
      RB.setRO(scene, "sensor", SENSOR[st.ctrl] ? "yes" : "no");
      noteEl.textContent = NOTES[st.ctrl] + (r.peak > F_LIMIT ? " Peak force passed " + F_LIMIT + " N, our toy limit for a wiping tool." : "");
      showEq(st.ctrl);
      ctl.querySelector("#" + id + "-srow").style.opacity = "1";
      ["sx", "sz"].forEach(function (k) { ctl.querySelector("#" + id + "-" + k).disabled = st.ctrl !== "hyb"; });
      ctl.querySelector("#" + id + "-ref").disabled = !(st.ctrl === "pd" || st.ctrl === "imp" || st.ctrl === "adm");
      ctl.querySelector("#" + id + "-kz").disabled = st.ctrl === "pd";
      api.meta("S_F = diag(" + (P.Sx ? 1 : 0) + ", " + (P.Sz ? 1 : 0) + ") · planned depth " + RB.fmt(r.depth * 1000, 0) + " mm · control 1 kHz");
      drawArm(); drawTL(); chartSoon();
    }
    function computeSoon() { clearTimeout(simT); simT = setTimeout(function () { if (!dead) computeArm(); }, 30); }

    function sizeW(el) { return Math.max(300, Math.min(900, (el.parentNode && el.parentNode.clientWidth) || 720)); }

    function drawArm() {
      if (dead || !cv.isConnected || !res[st.ctrl]) return;
      var Pl = RB.pal(), W = sizeW(cv), Hh = W < 520 ? 280 : 330, c = RB.canvas(cv, W, Hh), mono = font("mono"), bodyF = font("body");
      var r = res[st.ctrl], A = P.bump / 1000, O = P.off / 1000, lim = st.tPlay == null ? T_END : st.tPlay;
      var L = 24, Rr = W - 16, sxs = (Rr - L) / 0.4, y0 = Hh - 64, szs = Math.min(1500, sxs * 2.5);
      var X = function (x) { return L + x * sxs; }, Y = function (z) { return y0 - z * szs; };
      c.fillStyle = Pl.surface; c.fillRect(0, 0, W, Hh);
      /* surface body */
      c.fillStyle = Pl["surface-strong"]; c.beginPath(); c.moveTo(X(0), Hh); for (var i = 0; i <= 200; i++) { var xx = i / 200 * 0.4; c.lineTo(X(xx), Y(surfH(xx, A, O))); } c.lineTo(X(0.4), Hh); c.closePath(); c.fill();
      c.strokeStyle = Pl["line-strong"]; c.lineWidth = 1.5; c.beginPath(); for (i = 0; i <= 200; i++) { xx = i / 200 * 0.4; if (i) c.lineTo(X(xx), Y(surfH(xx, A, O))); else c.moveTo(X(xx), Y(surfH(xx, A, O))); } c.stroke();
      c.setLineDash([5, 4]); c.strokeStyle = Pl["ink-3"]; c.lineWidth = 1; c.beginPath(); c.moveTo(X(0), Y(0)); c.lineTo(X(0.4), Y(0)); c.stroke();
      c.beginPath(); c.moveTo(X(X0), Y(-r.depth)); c.lineTo(X(X1), Y(-r.depth)); c.stroke(); c.setLineDash([]);
      c.font = "500 11px " + mono; c.fillStyle = Pl["ink-3"]; c.textAlign = "left";
      c.textAlign = "right"; c.textAlign = "left"; c.fillText("planned surface", X(0.07), Y(0) - 6); c.textAlign = "right"; c.textAlign = "left"; c.fillText("target " + RB.fmt(r.depth * 1000, 0) + " mm below", X(X0) + 6, Y(-r.depth) - 5);
      if (Math.abs(P.bump) > 0) { c.textAlign = "center"; c.fillText("unseen " + (P.bump > 0 ? "bump " : "dip ") + Math.abs(P.bump) + " mm", X(BUMP_X), Hh - 22); c.textAlign = "left"; }
      if (P.off) c.fillText("surface " + Math.abs(P.off) + " mm " + (P.off > 0 ? "higher" : "lower"), L + 4, Hh - 22);
      if (szs / sxs > 1.2) { c.textAlign = "left"; c.fillText("height ×" + RB.fmt(szs / sxs, 1), L, 30); }
      /* wiped strip and the tool path, colored by force status */
      var recs = r.rec.filter(function (q) { return q.t <= lim; });
      var col = function (s) { return s === "good" ? Pl.good : s === "hard" ? Pl.bad : Pl.warn; };
      c.lineWidth = 2.5;
      for (i = 1; i < recs.length; i++) {
        var a = recs[i - 1], b = recs[i];
        c.strokeStyle = b.ph === "wipe" ? col(status(b, P.Fref)) : Pl["ink-3"];
        c.beginPath(); c.moveTo(X(a.x), Y(Math.max(a.z, -0.04))); c.lineTo(X(b.x), Y(Math.max(b.z, -0.04))); c.stroke();
        if (b.ph === "wipe") { c.fillStyle = col(status(b, P.Fref)); c.fillRect(X(a.x), Hh - 14, Math.max(1, X(b.x) - X(a.x)), 6); }
      }

      var cur = recs[recs.length - 1] || r.rec[0], atPeak = false;
      if (st.tPlay == null) { r.rec.forEach(function (q) { if (q.ph === "wipe" && q.t >= 1.0 && q.Fn > (atPeak ? atPeak.Fn : -1)) atPeak = q; }); if (atPeak) cur = atPeak; }
      /* schematic two-link arm from a base above the table (not to scale) */
      var tx = X(cur.x), ty = Y(cur.z) - 12, bx = W * 0.7, by = 18, dx = tx - bx, dy = ty - by, d = Math.sqrt(dx * dx + dy * dy);
      var Ln = Math.max(d / 2 + 4, Math.sqrt((W * 0.7) * (W * 0.7) + (y0 - by) * (y0 - by)) * 0.54), cosA = RB.clamp(d / (2 * Ln), -1, 1), base = Math.atan2(dy, dx), side = dx >= 0 ? -1 : 1;
      var ex = bx + Ln * Math.cos(base + side * Math.acos(cosA)), ey = by + Ln * Math.sin(base + side * Math.acos(cosA));
      var ex2 = bx + Ln * Math.cos(base - side * Math.acos(cosA)), ey2 = by + Ln * Math.sin(base - side * Math.acos(cosA));
      if (ey < 14 && ey2 > ey) { ex = ex2; ey = ey2; }
      c.strokeStyle = Pl["robot-body"] || Pl["data-2"]; c.lineCap = "round"; c.lineWidth = 9; c.globalAlpha = 0.85;
      c.beginPath(); c.moveTo(bx, by); c.lineTo(ex, ey); c.lineTo(tx, ty); c.stroke(); c.globalAlpha = 1; c.lineCap = "butt";
      c.fillStyle = Pl["ink-2"]; c.fillRect(bx - 22, 4, 44, 12); [[bx, by], [ex, ey]].forEach(function (p) { c.beginPath(); c.arc(p[0], p[1], 5, 0, Math.PI * 2); c.fill(); });
      /* the tool (a sponge) */
      c.fillStyle = Pl["accent-soft"]; c.strokeStyle = Pl.accent; c.lineWidth = 1.5; c.fillRect(tx - 16, ty, 32, 12); c.strokeRect(tx - 16, ty, 32, 12);
      /* what the controller is pulling toward */
      var gx = X(cur.xd), gz = Y(cur.zd);
      if (st.ctrl === "imp" || st.ctrl === "acp") {
        c.strokeStyle = Pl["ink-2"]; c.lineWidth = 1.2; c.beginPath(); var n = 8; for (i = 0; i <= n; i++) { var u = i / n, px = tx + (gx - tx) * u + (i % 2 ? 5 : -5) * (i > 0 && i < n ? 1 : 0), py = (ty + 12) + (gz - ty - 12) * u; if (i) c.lineTo(px, py); else c.moveTo(px, py); } c.stroke();
      }
      if (st.ctrl === "adm") { c.strokeStyle = Pl["data-2"]; c.lineWidth = 1.5; c.strokeRect(X(cur.xc) - 5, Y(cur.zc) - 5, 10, 10); c.fillStyle = Pl["ink-3"]; c.fillText("x_c", X(cur.xc) + 8, Y(cur.zc) + 4); }
      if (!(st.ctrl === "hyb" && cur.mode !== "pos")) { c.strokeStyle = Pl["ink-2"]; c.lineWidth = 1.2; c.beginPath(); c.moveTo(gx - 6, gz); c.lineTo(gx + 6, gz); c.moveTo(gx, gz - 6); c.lineTo(gx, gz + 6); c.stroke(); }
      else { c.setLineDash([3, 3]); c.strokeStyle = Pl["ink-3"]; c.beginPath(); c.moveTo(gx, ty - 20); c.lineTo(gx, ty + 30); c.stroke(); c.setLineDash([]); c.fillStyle = Pl["ink-2"]; c.fillText("F_ref " + P.Fref + " N", tx + 20, ty - 4); }
      /* contact force arrow */
      if (cur.Fn > 0.2) {
        var fl = Math.min(90, cur.Fn * 3), fy = Y(cur.z);
        c.strokeStyle = Pl["vec-wrench"] || Pl["data-6"]; c.fillStyle = c.strokeStyle; c.lineWidth = 2.5;
        c.beginPath(); c.moveTo(tx, fy + 8); c.lineTo(tx, fy + 8 - fl); c.stroke();
        c.beginPath(); c.moveTo(tx, fy + 8 - fl - 7); c.lineTo(tx - 5, fy + 8 - fl + 1); c.lineTo(tx + 5, fy + 8 - fl + 1); c.closePath(); c.fill();
        c.font = "600 12px " + bodyF; c.fillStyle = Pl.ink; c.fillText(RB.fmt(cur.Fn, 1) + " N", tx - 58, fy - 20);
      }
      c.font = "600 12px " + bodyF; c.fillStyle = Pl.ink; c.textAlign = "left"; c.fillText((W < 520 ? "" : CNAME[st.ctrl] + " · ") + "t = " + RB.fmt(cur.t, 2) + " s" + (atPeak ? " (peak force)" : ""), L, 14);
    }

    function drawTL() {
      if (dead || !tl.isConnected || !res[st.ctrl]) return;
      var Pl = RB.pal(), W = sizeW(tl), narrow = W < 560, lw = narrow ? 70 : 110, pw = W - lw - 12, mono = font("mono"), bodyF = font("body");
      var lanes = [["Phase 0 · gate φ", 30], ["Phase 1 · plan", 18], ["Phase 2 · refine", 18], ["Phase 3 · control", 18], ["Normal force", narrow ? 70 : 90]];
      var y = 22, gap = 10, ys = lanes.map(function (l) { var y1 = y; y += l[1] + gap; return y1; }), Ht = y + 18, c = RB.canvas(tl, W, Ht);
      var r = res[st.ctrl], lim = st.tPlay == null ? T_END : st.tPlay, sx = function (t) { return lw + t / T_END * pw; };
      c.fillStyle = Pl.surface; c.fillRect(0, 0, W, Ht);
      c.font = "500 11px " + mono; c.fillStyle = Pl["ink-3"];
      [[narrow ? "app." : "approach", 0, 0.8], ["wipe", 0.8, 3.2], ["lift", 3.2, 4]].forEach(function (p) { c.fillText(p[0], sx(p[1]) + 4, 14); c.strokeStyle = Pl.line; c.beginPath(); c.moveTo(sx(p[1]), 18); c.lineTo(sx(p[1]), Ht - 16); c.stroke(); });
      lanes.forEach(function (l, k) {
        c.fillStyle = Pl["surface-sunk"]; c.fillRect(lw, ys[k], pw, l[1]);
        c.fillStyle = Pl["ink-2"]; c.font = "600 " + (narrow ? 10 : 12) + "px " + bodyF;
        var txt = narrow ? l[0].replace("Phase ", "P").replace(" · ", " ") : l[0]; c.fillText(txt, 2, ys[k] + l[1] / 2 + 4);
      });
      var recs = r.rec.filter(function (q) { return q.t <= lim; });
      /* Phase 0: gate */
      c.strokeStyle = Pl["data-1"]; c.fillStyle = Pl["data-1"]; c.globalAlpha = 0.25; c.beginPath(); c.moveTo(sx(0), ys[0] + 30);
      recs.forEach(function (q) { c.lineTo(sx(q.t), ys[0] + 30 - q.phi * 30); }); if (recs.length) c.lineTo(sx(recs[recs.length - 1].t), ys[0] + 30); c.closePath(); c.fill(); c.globalAlpha = 1;
      c.lineWidth = 1.5; c.beginPath(); recs.forEach(function (q, j) { var yy = ys[0] + 30 - q.phi * 30; if (j) c.lineTo(sx(q.t), yy); else c.moveTo(sx(q.t), yy); }); c.stroke();
      /* Phase 1: plan ticks at 10 Hz */
      c.fillStyle = Pl["data-5"]; r.p1.forEach(function (t) { if (t > lim) return; c.fillRect(sx(t) - 1, ys[1] + 4, 2, 10); });
      c.font = "500 10px " + mono; c.fillStyle = Pl["ink-3"]; if (!narrow) { c.textAlign = "right"; c.fillText(st.ctrl === "acp" ? "10 Hz: target, K" : "10 Hz: target", W - 14, ys[1] + 13); c.textAlign = "left"; }
      /* Phase 2 */
      if (r.p2.length) { c.fillStyle = Pl["data-6"]; r.p2.forEach(function (t) { if (t > lim) return; c.fillRect(sx(t) - 0.5, ys[2] + 3, 1.5, 12); }); }
      else { c.fillStyle = Pl["ink-3"]; c.font = "500 11px " + mono; c.fillText(st.ctrl === "hyb" || st.ctrl === "acp" ? "skipped: this preset" : "skipped (tick the refiner)", lw + 6, ys[2] + 13); }
      /* Phase 3: control mode on the normal axis */
      var MC = { pos: "data-3", imp: "data-1", adm: "data-2", force: "data-4", forcexz: "data-6", mixed: "data-7" }, ML = { pos: "position", imp: "impedance", adm: "admittance", force: "force (S_z = 1)", forcexz: "force on x and z", mixed: "x force, z position" };
      var segStart = 0, curM = recs.length ? recs[0].mode : null, labels = [];
      recs.forEach(function (q, j) { if (q.mode !== curM || j === recs.length - 1) { c.fillStyle = Pl[MC[curM]] || Pl["data-3"]; c.fillRect(sx(segStart), ys[3] + 3, Math.max(1, sx(q.t) - sx(segStart)), 12); labels.push([segStart, q.t, curM]); segStart = q.t; curM = q.mode; } });
      c.font = "500 11px " + mono; labels.forEach(function (lb) { var w = sx(lb[1]) - sx(lb[0]), s = ML[lb[2]]; if (c.measureText(s).width + 8 < w) { c.fillStyle = Pl["on-accent"] || Pl.surface; c.fillText(s, sx(lb[0]) + 4, ys[3] + 13); } });
      /* force lane */
      var fy = ys[4], fh = lanes[4][1], fmax = Math.max(P.Fref * 2, Math.min(80, r.peak * 1.1), 10), sfy = function (F) { return fy + fh - Math.min(F, fmax) / fmax * fh; }, bw = band(P.Fref);
      c.fillStyle = Pl["good-soft"]; c.fillRect(sx(0.8), sfy(P.Fref + bw), sx(3.2) - sx(0.8), sfy(Math.max(0, P.Fref - bw)) - sfy(P.Fref + bw));
      if (F_LIMIT < fmax) { c.setLineDash([4, 3]); c.strokeStyle = Pl.bad; c.beginPath(); c.moveTo(lw, sfy(F_LIMIT)); c.lineTo(lw + pw, sfy(F_LIMIT)); c.stroke(); c.setLineDash([]); }
      c.strokeStyle = Pl["ink-3"]; c.lineWidth = 1; c.globalAlpha = 0.6; c.beginPath(); recs.forEach(function (q, j) { if (j) c.lineTo(sx(q.t), sfy(q.fm)); else c.moveTo(sx(q.t), sfy(q.fm)); }); c.stroke(); c.globalAlpha = 1;
      c.strokeStyle = Pl[CCOL[st.ctrl]]; c.lineWidth = 2; c.beginPath(); recs.forEach(function (q, j) { if (j) c.lineTo(sx(q.t), sfy(q.Fn)); else c.moveTo(sx(q.t), sfy(q.Fn)); }); c.stroke();
      c.font = "500 10px " + mono; c.fillStyle = Pl["ink-3"]; c.textAlign = "right"; c.fillText(RB.fmt(fmax, 0) + " N", lw - 4, fy + 9); c.fillText("0", lw - 4, fy + fh); c.textAlign = "left";
      [0, 1, 2, 3, 4].forEach(function (t) { c.textAlign = "center"; c.fillText(t + " s", sx(t), Ht - 4); }); c.textAlign = "left";
      if (st.tPlay != null) { c.strokeStyle = Pl.accent; c.lineWidth = 1.5; c.beginPath(); c.moveTo(sx(lim), 18); c.lineTo(sx(lim), Ht - 14); c.stroke(); }
    }

    function drawChart() {
      if (dead) return;
      chartHost.innerHTML = "";
      var ymax = Math.max(P.Fref * 2.5, 20), series = ["pd", "imp", "adm", "hyb", "acp"].map(function (k) {
        var pts = []; for (var j = 0; j <= 80; j++) { var t = j * 0.05, q = res[k].rec[Math.min(res[k].rec.length - 1, Math.round(t / 0.005))]; pts.push([+t.toFixed(2), Math.min(ymax, q.Fn)]); }
        return { name: CNAME[k], color: CCOL[k], points: pts };
      });
      series.push({ name: "F_ref", color: "ink-3", dash: true, points: series[0].points.map(function (p) { return [p[0], p[0] >= 0.8 && p[0] <= 3.2 ? P.Fref : 0]; }) });
      StudyBench.lineChart(chartHost, {
        title: "Normal force for all five controllers", x: { label: "Time (s)", min: 0, max: 4 }, y: { label: "Normal force (N)", min: 0, max: ymax, fmt: function (v) { return RB.fmt(v, 1); } },
        series: series, directLabels: false,
        caption: "Same plan, same surface, five control laws (our toy). Values above " + RB.fmt(ymax, 0) + " N are clipped. Compare the bump near 2 s."
      });
    }
    function chartSoon() { clearTimeout(chartT); chartT = setTimeout(drawChart, 150); }

    /* ---------------- playback ---------------- */
    function stopPlay() { if (raf) cancelAnimationFrame(raf); raf = 0; st.playing = false; st.tPlay = null; api.live("paused", "Paused"); }
    function play() {
      if (raf) cancelAnimationFrame(raf);
      st.runs++; st.playing = true; st.tPlay = 0; api.live("running", "Wiping");
      var t0 = null;
      function tick(ts) {
        if (dead) return;
        if (t0 == null) t0 = ts;
        st.tPlay = Math.min(T_END, (ts - t0) / 1000);
        drawArm(); drawTL();
        if (st.tPlay >= T_END) { raf = 0; st.playing = false; st.tPlay = null; api.live("paused", "Done"); drawArm(); drawTL(); return; }
        raf = requestAnimationFrame(tick);
      }
      raf = requestAnimationFrame(tick);
    }

    /* ---------------- humanoid ---------------- */
    function computeWBC() {
      var o = { solver: H.solver, order: H.order, wb: Math.pow(10, H.wb), xh: H.xh, s: H.s, mu: P.mu, Fref: H.Fref };
      wres = wbcSolve(o, false);
      var inFoot = wres.xp >= HB.heel && wres.xp <= HB.toe, inMargin = viol(wres.xp) < 1e-4;
      RB.setRO(scene, "wF", RB.fmt(wres.F, 0) + " / " + H.Fref);
      RB.setRO(scene, "wcop", RB.fmt(wres.xp * 100, 1));
      RB.setRO(scene, "wlean", RB.fmt(wres.c * 100, 1));
      RB.setRO(scene, "wbal", inMargin ? "stable" : inFoot ? "at the edge" : "tips over");
      RB.setRO(scene, "wqp", String(wres.solves));
      var tasks = H.solver === "wqp" ? [["Balance", "weight 10^" + RB.fmt(H.wb, 2)], ["Hand force", "weight 1"], ["Upright posture", "weight 0.2"]] :
        (H.order === "bal" ? [["Balance", "level 1"], ["Hand force", "level 2"], ["Upright posture", "level 3"]] : [["Hand force", "level 1"], ["Balance", "level 2"], ["Upright posture", "level 3"]]);
      var ok = { "Balance": inMargin, "Hand force": Math.abs(wres.F - H.Fref) < 1, "Upright posture": Math.abs(wres.c) < 0.005 };
      var det = { "Balance": "center of pressure " + RB.fmt(wres.xp * 100, 1) + " cm", "Hand force": RB.fmt(wres.F, 0) + " of " + H.Fref + " N", "Upright posture": "lean " + RB.fmt(wres.c * 100, 1) + " cm" };
      stackEl.innerHTML = tasks.map(function (tk) { return '<li><b>' + tk[0] + "</b> <span class=\"rb-mono rb-muted\">(" + tk[1] + ')</span> <span class="rb-mono" style="color:var(--' + (ok[tk[0]] ? "good" : "bad") + ')">' + (ok[tk[0]] ? "✓" : "✗") + "</span> " + det[tk[0]] + "</li>"; }).join("");
      ctl.querySelector("#" + id + "-wb").disabled = H.solver !== "wqp";
      RB.$$("#" + id + "-order button", ctl).forEach(function (b) { b.disabled = H.solver === "wqp"; });
      noteEl.textContent = WNOTE;
      showEq("wbc");
      api.meta("static toy · 60 kg · hand at 0.9 m · μ = " + RB.fmt(P.mu, 2));
      drawHum(); wchartSoon();
    }
    function drawHum() {
      if (dead || !wres) return;
      var s = 160, gx = 60, gy = 270, X = function (x) { return (gx + x * s).toFixed(1); }, Y = function (z) { return (gy - z * s).toFixed(1); };
      var c = wres.c, hip = [c * 0.8, 0.85], sh = [c * 1.6, 1.35], hand = [H.xh, HB.zh], L = 0.4;
      var dx = hand[0] - sh[0], dz = hand[1] - sh[1], d = Math.min(2 * L - 1e-3, Math.sqrt(dx * dx + dz * dz)), a = Math.atan2(dz, dx), b = Math.acos(d / (2 * L)), el = [sh[0] + L * Math.cos(a - b), sh[1] + L * Math.sin(a - b)];
      var inFoot = wres.xp >= HB.heel && wres.xp <= HB.toe, inMargin = viol(wres.xp) < 1e-4, copCol = inMargin ? "good" : inFoot ? "warn" : "bad";
      var xp = RB.clamp(wres.xp, -0.35, 1.4), fl = Math.min(80, wres.F * 0.6), fr = Math.min(60, P.mu * wres.F * 0.6);
      var o = '<rect x="0" y="' + gy + '" width="300" height="30" class="rb-f-sunk"/>' +
        '<rect x="' + X(H.xh - 0.06) + '" y="' + Y(HB.zh) + '" width="' + (300 - +X(H.xh - 0.06)) + '" height="10" class="rb-f-surface"/><line x1="' + (+X(H.xh - 0.06) + 20) + '" y1="' + (+Y(HB.zh) + 10) + '" x2="' + (+X(H.xh - 0.06) + 20) + '" y2="' + gy + '" class="rb-s-line"/><line x1="290" y1="' + (+Y(HB.zh) + 10) + '" x2="290" y2="' + gy + '" class="rb-s-line"/>' +
        '<text x="' + (+X(H.xh) + 10) + '" y="' + (+Y(HB.zh) - 8) + '" class="rb-t-mono">table</text>' +
        '<line x1="' + X(HB.heel) + '" y1="' + (gy - 3) + '" x2="' + X(HB.toe) + '" y2="' + (gy - 3) + '" style="stroke:var(--ink-2);stroke-width:6;stroke-linecap:round"/>' +
        '<line x1="' + X(HB.heel + HB.marg) + '" y1="' + (gy + 6) + '" x2="' + X(HB.toe - HB.marg) + '" y2="' + (gy + 6) + '" style="stroke:var(--good);stroke-width:4"/>' +
        '<g style="stroke:var(--robot-body);stroke-width:9;stroke-linecap:round;fill:none;opacity:0.9"><polyline points="' + X(0) + "," + Y(0.08) + " " + X(hip[0]) + "," + Y(hip[1]) + " " + X(sh[0]) + "," + Y(sh[1]) + '"/><polyline style="stroke-width:6" points="' + X(sh[0]) + "," + Y(sh[1]) + " " + X(el[0]) + "," + Y(el[1]) + " " + X(hand[0]) + "," + Y(hand[1]) + '"/></g>' +
        '<circle cx="' + X(c * 1.8) + '" cy="' + Y(1.5) + '" r="12" style="fill:var(--surface);stroke:var(--robot-body);stroke-width:3"/>' +
        '<circle cx="' + X(c) + '" cy="' + Y(0.95) + '" r="6" style="fill:var(--ink)"/><line x1="' + X(c) + '" y1="' + Y(0.95) + '" x2="' + X(c) + '" y2="' + gy + '" class="rb-s-line" stroke-dasharray="4 3"/>' +
        '<text x="' + (+X(c) - 10) + '" y="' + Y(1.0) + '" text-anchor="end" class="rb-t-mono">CoM</text>' +
        '<path d="M' + X(xp) + " " + (gy + 8) + " l-7 12 h14 z\" style=\"fill:var(--" + copCol + ')"/><text x="' + X(xp) + '" y="' + (gy + 30) + '" text-anchor="middle" class="rb-t-ink">CoP</text>';
      if (wres.F > 0.5) {
        var hx = +X(hand[0]), hy = +Y(hand[1]);
        o += '<g style="stroke:var(--vec-wrench);stroke-width:3;fill:var(--vec-wrench)"><line x1="' + hx + '" y1="' + hy + '" x2="' + hx + '" y2="' + (hy - fl) + '"/><path d="M' + hx + " " + (hy - fl - 8) + " l-5 9 h10 z\" style=\"stroke:none\"/>" +
          (fr > 2 ? '<line x1="' + hx + '" y1="' + (hy + 4) + '" x2="' + (hx - H.s * fr) + '" y2="' + (hy + 4) + '"/><path d="M' + (hx - H.s * (fr + 8)) + " " + (hy + 4) + " l9 -5 v10 z\" transform=\"" + (H.s < 0 ? "rotate(180 " + (hx - H.s * (fr + 4)) + " " + (hy + 4) + ")" : "") + "\" style=\"stroke:none\"/>" : "") + "</g>" +
          '<text x="' + (hx + 8) + '" y="' + (hy - fl + 4) + '" class="rb-t-ink">' + RB.fmt(wres.F, 0) + " N</text>";
      }
      o += '<text x="292" y="14" text-anchor="end" class="rb-t-mono">' + (H.solver === "wqp" ? "weighted QP" : "hierarchical QP · " + (H.order === "bal" ? "balance first" : "force first")) + "</text>";
      hum.innerHTML = o;
    }
    function drawWChart() {
      if (dead) return;
      wchartHost.innerHTML = "";
      var base = { xh: H.xh, s: H.s, mu: P.mu, wb: Math.pow(10, H.wb) }, pts = { bal: [], force: [], wqp: [], req: [] };
      for (var F = 0; F <= 150; F += 10) {
        ["bal", "force", "wqp"].forEach(function (k) { var o = { xh: base.xh, s: base.s, mu: base.mu, wb: base.wb, Fref: F, solver: k === "wqp" ? "wqp" : "hqp", order: k === "force" ? "force" : "bal" }; var r = wbcSolve(o, true); pts[k].push([F, r.F]); });
        pts.req.push([F, F]);
      }
      StudyBench.lineChart(wchartHost, {
        title: "Hand force the controller delivers", x: { label: "Requested hand force (N)", min: 0, max: 150 }, y: { label: "Delivered (N)", min: 0, max: 150, fmt: function (v) { return RB.fmt(v, 0); } },
        series: [{ name: "HQP, balance first", color: "data-1", points: pts.bal }, { name: "HQP, force first", color: "data-4", points: pts.force }, { name: "Weighted QP", color: "data-2", points: pts.wqp }, { name: "requested", color: "ink-3", dash: true, points: pts.req }],
        directLabels: false,
        caption: "Where a line leaves the dashed diagonal, balance wins and the hand presses less. Force first always delivers, even when the body would tip (our static toy)."
      });
    }
    function wchartSoon() { clearTimeout(wchartT); wchartT = setTimeout(drawWChart, 150); }

    function setBench(b) {
      st.bench = b;
      scene.querySelector("#" + id + "-arm").hidden = b !== "arm"; scene.querySelector("#" + id + "-wbc").hidden = b !== "wbc";
      ctl.querySelector("#" + id + "-carm").hidden = b !== "arm"; ctl.querySelector("#" + id + "-cwbc").hidden = b !== "wbc";
      if (b === "wbc") { stopPlay(); computeWBC(); } else { computeArm(); }
    }

    /* ---------------- wiring ---------------- */
    bindSeg(ctl, id + "-bench", setBench);
    bindSeg(ctl, id + "-ctrl", function (v) { st.ctrl = v; computeArm(); });
    bindSeg(ctl, id + "-env", function (v) { P.env = v; computeArm(); });
    ctl.querySelector("#" + id + "-sx").addEventListener("change", function (e) { P.Sx = e.target.checked; computeArm(); });
    ctl.querySelector("#" + id + "-sz").addEventListener("change", function (e) { P.Sz = e.target.checked; computeArm(); });
    ctl.querySelector("#" + id + "-ref").addEventListener("change", function (e) { P.refine = e.target.checked; computeArm(); });
    RB.bindSlider(ctl, id + "-fref", nn, function (v) { P.Fref = v; computeSoon(); });
    RB.bindSlider(ctl, id + "-kz", nm, function (v) { P.Kz = v; computeSoon(); });
    RB.bindSlider(ctl, id + "-kx", nm, function (v) { P.Kx = v; computeSoon(); });
    RB.bindSlider(ctl, id + "-bump", mm, function (v) { P.bump = v; computeSoon(); });
    RB.bindSlider(ctl, id + "-off", mm, function (v) { P.off = v; computeSoon(); });
    RB.bindSlider(ctl, id + "-mu", function (v) { return (+v).toFixed(2); }, function (v) { P.mu = v; computeSoon(); });
    RB.bindSlider(ctl, id + "-noise", function (v) { return (+v).toFixed(2) + " N"; }, function (v) { P.noise = v; computeSoon(); });
    RB.bindSlider(ctl, id + "-fr", nn, function (v) { P.fr = v; computeSoon(); });
    ctl.querySelector("#" + id + "-seed").addEventListener("click", function () { st.seed++; computeArm(); });
    ctl.querySelector("#" + id + "-go").addEventListener("click", function () { play(); });
    bindSeg(ctl, id + "-solver", function (v) { H.solver = v; computeWBC(); });
    bindSeg(ctl, id + "-order", function (v) { H.order = v; computeWBC(); });
    bindSeg(ctl, id + "-dir", function (v) { H.s = v === "push" ? 1 : -1; computeWBC(); });
    RB.bindSlider(ctl, id + "-hf", nn, function (v) { H.Fref = v; computeWBC(); });
    RB.bindSlider(ctl, id + "-xh", function (v) { return v + " cm"; }, function (v) { H.xh = v / 100; computeWBC(); });
    RB.bindSlider(ctl, id + "-wb", function (v) { return (+v).toFixed(2); }, function (v) { H.wb = v; computeWBC(); });

    RB.onTheme(function () { if (dead) return; if (st.bench === "arm") { drawArm(); drawTL(); chartSoon(); } else { drawHum(); wchartSoon(); } });
    if (window.ResizeObserver) { ro = new ResizeObserver(function () { var w = scene.clientWidth; if (Math.abs(w - lastW) < 2) return; lastW = w; if (st.bench === "arm") { drawArm(); drawTL(); } }); ro.observe(scene); }
    computeArm();

    var self = {
      state: function () { return { bench: st.bench, ctrl: st.ctrl, Sx: P.Sx, Sz: P.Sz, bump: P.bump, off: P.off, Fref: P.Fref, runs: st.runs, playing: st.playing, solver: H.solver, order: H.order, hf: H.Fref }; },
      result: function () { return res[st.ctrl]; },
      demo: function () {
        var q = function (s) { return scene.querySelector(s) || ctl.querySelector(s); }, runs0 = st.runs;
        var seg = function (sid, v) { return function (a) { return a.click(ctl.querySelector("#" + id + "-" + sid + ' [value="' + v + '"]')); }; };
        return [
          { target: q("#" + id + "-cv"), title: "One planned stroke", text: "The policy believes the surface is flat and aims a few millimeters below it. A 10 mm bump it cannot see sits in the middle.",
            do: function (a) { return st.bench === "arm" ? a.wait(200) : seg("bench", "arm")(a); } },
          { target: q("#" + id + "-ctrl"), title: "Stiff position control", text: "PD position control follows the target literally. Over the bump the force shoots past our 50 N tool limit.", do: seg("ctrl", "pd"), task: "Choose PD position", expect: function () { return st.ctrl === "pd"; } },
          { target: q("#" + id + "-ctrl"), title: "Make the tool a spring", text: "Impedance control puts a 500 N/m spring between target and tool. The bump adds only a few newtons, with no force sensor.", do: seg("ctrl", "imp"), task: "Choose Impedance", expect: function () { return st.ctrl === "imp"; } },
          { target: q("#" + id + "-ctrl"), title: "Regulate force directly", text: "Hybrid control with S = diag(0, 1) regulates force along z and position along x. It holds F_ref over the bump.", do: seg("ctrl", "hyb"), task: "Choose Hybrid", expect: function () { return st.ctrl === "hyb"; } },
          { target: q("#" + id + "-go"), title: "Watch the gate switch", text: "Run the stroke and watch the timeline: the gate opens at contact, and only then does the z axis switch from position to force control.",
            do: function (a) { return a.click(q("#" + id + "-go")).then(function () { return a.until(function () { return !st.playing; }, 6000); }); }, task: "Press Run stroke", expect: function () { return st.runs > runs0; } },
          { target: q("#" + id + "-ctrl"), title: "Let the policy set stiffness", text: "Now the whole surface sits 10 mm higher than planned. Fixed gains press too hard all stroke; learned stiffness resets its target every 100 ms.",
            do: function (a) { return a.set(q("#" + id + "-off"), 10).then(function () { return seg("ctrl", "acp")(a); }); }, task: "Choose Learned stiffness", expect: function () { return st.ctrl === "acp"; } },
          { target: q("#" + id + "-bench"), title: "Now a whole body", text: "A humanoid pressing on a table must also stay balanced. The table pushes back and moves the center of pressure toward the heel.", do: seg("bench", "wbc"), task: "Choose the Humanoid bench", expect: function () { return st.bench === "wbc"; } },
          { target: q("#" + id + "-hf"), title: "Your turn", text: "Raise the requested force to 120 N and compare balance first, force first and the weighted QP. Then try the arm with force along x ticked.",
            do: function (a) { return a.set(q("#" + id + "-hf"), 120); }, task: "Set the hand force to 120 N or more", expect: function () { return H.Fref >= 120; } }
        ];
      },
      destroy: function () { dead = true; if (raf) cancelAnimationFrame(raf); raf = 0; clearTimeout(chartT); clearTimeout(wchartT); clearTimeout(simT); if (ro) ro.disconnect(); }
    };
    return self;
  }

  RB.station({
    id: SID, name: "Compliance station", sub: "02 · 19 · 18",
    refs: ["P10 §5.1–5.3, eq. 22–28", "P10 Fig. 1–2", "P09 §VI-A–C"], prov: "Simplified: toy contact models",
    summary: "Wipe a surface with a bump the policy cannot see, using five control laws. Follow the TF-ART phases on a timeline, then give a humanoid the same job and watch balance and hand force compete.",
    notice: [
      "Stiff position control turns a few millimeters of surprise into tens of newtons.",
      "Impedance needs no sensor but lags under friction; admittance and hybrid control need a force sensor.",
      "The selection matrix must pick the right directions: force along x leaves nothing driving the stroke.",
      "A contact gate decides when force control is safe to switch on.",
      "With a strict hierarchy, balance caps the hand force; with weights, the body may tip."
    ],
    card: "Five contact controllers on one wiping stroke, a TF-ART phase timeline, and a humanoid balancing its hand force.",
    ledger: [
      { where: "Lab · Compliance station · arm", source: "P10 §5.1 writes the controllers for a full manipulator in joint space (eq. 21–28)", page: "A 2-D point tool of 1.5 kg per axis without gravity, penalty contact, surface and arm Coulomb friction, a noisy 2 ms-filtered force sensor, physics at 5 kHz and control at 1 kHz", why: "Shows the trade-offs P10 names with forces you can read off.", kind: "Simplified" },
      { where: "Lab · Compliance station · impedance", source: "P10 eq. 25 includes desired inertia M_d and model compensation", page: "The toy uses F = K_d e + B_d ė on a point mass, with damping ratio 0.7", why: "Same spring behavior with fewer parameters.", kind: "Simplified" },
      { where: "Lab · Compliance station · plan", source: "Policies such as ACP predict a virtual target from demonstrations", page: "Every controller receives the same flat plan, F_ref/K_d,z below the believed surface; the PD preset executes it literally", why: "One plan isolates the effect of the control law.", kind: "Our choice" },
      { where: "Lab · Compliance station · hybrid", source: "P10 eq. 28 names generic force and position controllers 𝓕 and 𝓟", page: "𝓕 is a force PI loop with velocity damping (our gains), switched on when the contact gate opens during the wipe", why: "Force control in free space would accelerate the tool into the surface.", kind: "Our choice" },
      { where: "Lab · Compliance station · gate", source: "FoAR gates force with a separately trained future-contact predictor (arXiv 2411.15753)", page: "The gate is a sigmoid of the 10 ms average of the measured normal force, updated at 100 Hz", why: "Keeps the gate visible and tied to the sensor.", kind: "Simplified" },
      { where: "Lab · Compliance station · learned stiffness", source: "ACP executes its stiffness and virtual target with an admittance controller and learns them from demonstrations", page: "The toy applies ACP's labeling rule directly every 100 ms and executes it with the impedance law; limits 200–1000 N/m and 1–11 N are ours", why: "At steady state both give the same spring; the rule, not the network, is on show.", kind: "Simplified" },
      { where: "Lab · Compliance station · humanoid", source: "P09 eq. 5–7 solves for accelerations, contact forces and torques of the full floating-base body", page: "A static planar balance with two decision variables, hand force and center-of-mass lean, solved exactly on a grid; each HQP level keeps the optimal set of the level above", why: "Makes strict versus weighted priority visible in one picture.", kind: "Simplified" }
    ],
    mount: mount
  });
})();
