/* Lab station · WAM coupling playground (topic 11). Sources: P03 eq. 4–8 (one joint, four queries), P04 §2.3 eq. 5–7 and
   §4.1 eq. 10–12 (cascade / score / joint couplings), P04 §5.2 (causality, leakage-free denoising), X1 §4 (cascaded vs joint),
   X1 §6.1.3 (IDM Turing test), method cards UWM (arXiv 2504.02792), PAD (2411.18179), Fast-WAM (2603.16666),
   WoW-World-Eval (2601.04137), World Action Verifier (2604.01985).
   Toy: a puck is pushed from the bottom of a table at one of 7 angles and lands in one of 9 cells on the far edge.
   The joint p(o′, a | o, ℓ) = demonstrator policy × dynamics is an exact 9 × 7 table. Learned components are that
   table mixed with uniform noise (our error model). Everything computed here is our toy. */
(function () {
  "use strict";
  var RB = window.RB;

  /* ================= the push world ================= */
  var W = (function () {
    var NA = 7, NO = 9, BETA = 5;
    var ANG = [], LX = [];
    for (var i = 0; i < NA; i++) { ANG.push((-45 + 15 * i) * Math.PI / 180); LX.push(Math.tan(ANG[i])); }
    var CELLW = 2 / NO;
    function cellX(j) { return -1 + (j + 0.5) * CELLW; }
    function cellOf(x) { return Math.max(0, Math.min(NO - 1, Math.floor((x + 1) / CELLW))); }
    var GOALS = { left: [1, 2], either: [1, 2, 6, 7], play: [1, 2, 6, 7] };
    function erf(x) { var s = x < 0 ? -1 : 1; x = Math.abs(x); var t = 1 / (1 + 0.3275911 * x); var y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return s * y; }
    function Phi(x) { return 0.5 * (1 + erf(x / Math.SQRT2)); }
    /* landing points (x, weight) for action i */
    function lands(i, peg) { if (peg && i === 3) return [[-0.62, 0.5], [0.62, 0.5]]; return [[Math.max(-1, Math.min(1, LX[i])), 1]]; }
    /* p(o′ | a): Gaussian spread around each landing point, integrated over cells; edge cells absorb the tails */
    function dyn(i, sig, peg) {
      var p = []; for (var j = 0; j < NO; j++) p.push(0);
      lands(i, peg).forEach(function (L) {
        for (var j = 0; j < NO; j++) {
          var lo = j === 0 ? -1e9 : -1 + j * CELLW, hi = j === NO - 1 ? 1e9 : -1 + (j + 1) * CELLW;
          p[j] += L[1] * (Phi((hi - L[0]) / sig) - Phi((lo - L[0]) / sig));
        }
      });
      return p;
    }
    function build(instr, sig, peg) {
      var goal = GOALS[instr], D = [], S = [], pi = [], Z = 0, i, j;
      for (i = 0; i < NA; i++) { D.push(dyn(i, sig, peg)); S.push(goal.reduce(function (s, g) { return s + D[i][g]; }, 0)); }
      for (i = 0; i < NA; i++) { var w = instr === "play" ? 1 : Math.exp(BETA * S[i]); pi.push(w); Z += w; }
      pi = pi.map(function (w) { return w / Z; });
      var J = []; for (j = 0; j < NO; j++) { J.push([]); for (i = 0; i < NA; i++) J[j].push(pi[i] * D[i][j]); }
      /* inverse dynamics trained on play data (uniform actions, no instruction), as a cascade's IDM would be */
      var IP = []; for (j = 0; j < NO; j++) { var row = [], z = 0; for (i = 0; i < NA; i++) { row.push(D[i][j]); z += D[i][j]; } IP.push(row.map(function (v) { return z > 1e-12 ? v / z : 1 / NA; })); }
      return { J: J, D: D, S: S, pi: pi, IP: IP, goal: goal, instr: instr, sig: sig, peg: peg };
    }
    function norm(d) { var z = d.reduce(function (a, b) { return a + b; }, 0); return z > 1e-12 ? d.map(function (v) { return v / z; }) : d.map(function () { return 1 / d.length; }); }
    function mixU(d, e) { e = Math.max(0, Math.min(1, e)); return d.map(function (v) { return (1 - e) * v + e / d.length; }); }
    function video(M) { var d = []; for (var j = 0; j < NO; j++) d.push(M.J[j].reduce(function (a, b) { return a + b; }, 0)); return d; }
    function rowIDM(M, j) { return norm(M.J[j].slice()); }
    function colFwd(M, i) { return M.D[i].slice(); }
    function inGoal(M, j) { return M.goal.indexOf(j) >= 0; }
    function sample(R, d) { var u = R(), c = 0; for (var k = 0; k < d.length; k++) { c += d[k]; if (u < c) return k; } return d.length - 1; }
    return { NA: NA, NO: NO, ANG: ANG, LX: LX, cellX: cellX, cellOf: cellOf, lands: lands, build: build, norm: norm, mixU: mixU, video: video, rowIDM: rowIDM, colFwd: colFwd, inGoal: inGoal, sample: sample, CELLW: CELLW };
  })();

  /* ================= couplings with learned-model error ================= */
  /* Our error rule: each learned table = exact table mixed with uniform. The weight grows as action labels shrink:
     fastest for the VLA policy (labels only), slower for the joint model (co-trains on action-free video),
     slower still for the IDM (play data, low-dimensional); the video model needs no labels. */
  function errs(eps, L) { var g = 1 - L; return { video: eps, policy: Math.min(0.95, eps * (1 + 2 * g)), joint: Math.min(0.95, eps * (1 + g)), fwd: Math.min(0.95, eps * (1 + g)), idm: Math.min(0.95, eps * (1 + 0.5 * g)) }; }
  function coupling(M, kind, eps, L, N) {
    var E = errs(eps, L), NA = W.NA, NO = W.NO, i, j, pa = [], succ = 0, cons = null, futures = 0;
    for (i = 0; i < NA; i++) pa.push(0);
    if (kind === "policy") { pa = W.mixU(M.pi, E.policy); }
    else if (kind === "cascade") {
      var v = W.mixU(W.video(M), E.video); futures = 1; cons = 0;
      for (j = 0; j < NO; j++) { var id = W.mixU(M.IP[j], E.idm); for (i = 0; i < NA; i++) { pa[i] += v[j] * id[i]; cons += v[j] * id[i] * M.D[i][j]; } }
    } else if (kind === "score") {
      var q = W.mixU(M.pi, E.policy), sc = [], order = [], F = 0; futures = N; cons = 0;
      for (i = 0; i < NA; i++) { var f = W.mixU(M.D[i], E.fwd); sc.push(M.goal.reduce(function (s, g) { return s + f[g]; }, 0)); order.push(i); }
      order.sort(function (x, y) { return sc[x] - sc[y] || x - y; });
      order.forEach(function (k) { var F0 = F; F += q[k]; pa[k] = Math.pow(F, N) - Math.pow(F0, N); });
      for (i = 0; i < NA; i++) { var fh = W.mixU(M.D[i], E.fwd); for (j = 0; j < NO; j++) cons += pa[i] * fh[j] * M.D[i][j]; }
    } else { /* joint */
      futures = 1; cons = 0; var U = 1 / (NA * NO);
      for (j = 0; j < NO; j++) for (i = 0; i < NA; i++) { var pj = (1 - E.joint) * M.J[j][i] + E.joint * U; pa[i] += pj; cons += pj * M.D[i][j]; }
    }
    for (i = 0; i < NA; i++) succ += pa[i] * M.S[i];
    return { pa: pa, succ: succ, cons: cons, futures: futures, E: E };
  }
  /* sampled episodes for drawing: imagined future (or null) and real outcome */
  function episodes(M, kind, eps, L, N, n, seed) {
    var R = RB.rng(seed), E = errs(eps, L), out = [], NA = W.NA;
    for (var k = 0; k < n; k++) {
      var a, img = null;
      if (kind === "policy") a = W.sample(R, W.mixU(M.pi, E.policy));
      else if (kind === "cascade") { img = W.sample(R, W.mixU(W.video(M), E.video)); a = W.sample(R, W.mixU(M.IP[img], E.idm)); }
      else if (kind === "score") {
        var best = -1, bs = -1, q = W.mixU(M.pi, E.policy);
        for (var c = 0; c < N; c++) { var ai = W.sample(R, q), f = W.mixU(M.D[ai], E.fwd), s = M.goal.reduce(function (t, g) { return t + f[g]; }, 0); if (s > bs) { bs = s; best = ai; } }
        a = best; img = W.sample(R, W.mixU(M.D[a], E.fwd));
      } else {
        var U = 1 / (NA * W.NO), u = R(), acc = 0; a = 0; img = 0;
        outer: for (var j = 0; j < W.NO; j++) for (var i = 0; i < NA; i++) { acc += (1 - E.joint) * M.J[j][i] + E.joint * U; if (u < acc) { a = i; img = j; break outer; } }
      }
      var real = W.sample(R, M.D[a]);
      out.push({ a: a, img: img, real: real, ok: W.inGoal(M, real) });
    }
    return out;
  }

  /* ================= leakage (P04 §5.2) ================= */
  /* A leaky action head was trained while seeing the true future o′, so it acts like p(a | o′). At deployment the future
     token is only partly denoised when the action is read: with probability τ_read it holds a real model sample, else noise. */
  function leak(M, leaky, tr) {
    var NA = W.NA, NO = W.NO, v = W.video(M), fit = 0, succ = 0, i, j;
    if (!leaky) { for (i = 0; i < NA; i++) { fit += M.pi[i] * M.pi[i]; succ += M.pi[i] * M.S[i]; } return { fit: fit, succ: succ }; }
    for (j = 0; j < NO; j++) { var id = W.rowIDM(M, j), seen = tr * v[j] + (1 - tr) / NO; for (i = 0; i < NA; i++) { fit += M.J[j][i] * id[i]; succ += seen * id[i] * M.S[i]; } }
    return { fit: fit, succ: succ };
  }
  function leakEpisodes(M, leaky, tr, n, seed) {
    var R = RB.rng(seed), v = W.video(M), out = [];
    for (var k = 0; k < n; k++) {
      var a, img = null, noise = false;
      if (!leaky) a = W.sample(R, M.pi);
      else { noise = R() >= tr; img = noise ? R.int(W.NO) : W.sample(R, v); a = W.sample(R, W.rowIDM(M, img)); }
      var real = W.sample(R, M.D[a]); out.push({ a: a, img: img, noise: noise, real: real, ok: W.inGoal(M, real) });
    }
    return out;
  }

  /* ================= IDM Turing test (after WoW-World-Eval, arXiv 2601.04137) ================= */
  var GENS = {
    replay: { s: 1, c: 1, label: "Replay", name: "Real videos (replay)" },
    sharp: { s: 0.95, c: 0.05, label: "Sharp", name: "Sharp, unphysical" },
    blurry: { s: 0.45, c: 0.95, label: "Blurry", name: "Blurry, physical" },
    balanced: { s: 0.75, c: 0.6, label: "Balanced", name: "Balanced" }
  };
  function idmMiss(s) { return 0.1 + 0.5 * (1 - s); } /* 10% misreads on real videos, matching the 90% replay accuracy WoW reports; blur adds more */
  function genVideo(M, s, c, R) {
    /* the generator intends a demonstrated (o′, a) pair; with probability c its first motion matches that push */
    var u = R(), acc = 0, a = 0, o = 0;
    outer: for (var j = 0; j < W.NO; j++) for (var i = 0; i < W.NA; i++) { acc += M.J[j][i]; if (u < acc) { a = i; o = j; break outer; } }
    var phys = R() < c, first = a;
    if (!phys) { first = R.int(W.NA - 1); if (first >= a) first++; } /* unphysical: the first motion points some other way */
    var dec = first; if (R() < idmMiss(s)) dec = Math.max(0, Math.min(W.NA - 1, first + (R() < 0.5 ? -1 : 1)));
    var real = W.sample(R, M.D[dec]);
    return { a: a, o: o, phys: phys, first: first, dec: dec, real: real, ok: W.inGoal(M, real), s: s };
  }
  function idmTest(M, s, c, n, seed) { var R = RB.rng(seed), ok = 0, unp = 0; for (var k = 0; k < n; k++) { var v = genVideo(M, s, c, R); if (v.ok) ok++; if (!v.phys) unp++; } return { succ: ok / n, unphys: unp / n, looks: s }; }

  /* ================= station UI ================= */
  var QNAME = { policy: "Σ over o′", video: "Σ over a", forward: "fix a", idm: "fix o′" };
  var QREF = { policy: "P03 eq. 5", video: "P03 eq. 6", forward: "P03 eq. 7", idm: "P03 eq. 8" };
  var QNOTE = {
    policy: "Sum the table over o′: the action distribution a vision-language-action (VLA) policy learns. UWM gets it by leaving the future at pure noise (arXiv 2504.02792).",
    video: "Sum over a: a passive video model. It can be trained on action-free video, which is why cascades start here (P04 eq. 5).",
    forward: "Fix one push and read its column: the consequence of that action. Scoring couplings rank candidates with this query (P04 eq. 6).",
    idm: "Fix where the puck lands and read its row: which push made that future. Cascades such as UniPi decode actions this way (P03 eq. 8)."
  };
  var CNAME = { policy: "Policy only (VLA)", cascade: "Cascade: imagine, decode", score: "Score: propose, predict", joint: "Joint: one model" };
  var CNOTE = {
    policy: "No future in the path: sample an action from the learned policy. It needs action labels for everything, so it degrades fastest when labels are scarce.",
    cascade: "Sample a future from the video model, then decode the push with an IDM trained on play data (P04 eq. 5, 12). A hallucinated future is decoded anyway.",
    score: "Propose N pushes from the policy, predict each one's landing with the forward model, run the best (P04 eq. 6, 10). Costs N predicted futures.",
    joint: "Sample the landing and the push together from one model (P04 eq. 7, 11). Co-training on action-free video keeps its action part sharper here."
  };
  var MODES = [{ value: "query", label: "Queries" }, { value: "couple", label: "Couplings" }, { value: "uwm", label: "UWM dials" }, { value: "leak", label: "Leakage" }, { value: "idm", label: "IDM test" }];
  var MODE_NAME = { query: "One joint, four queries", couple: "Three couplings", uwm: "Per-modality noise", leak: "Future leakage", idm: "IDM Turing test" };
  var NEP = 24;

  function mount(api) {
    var id = api.id, sc = api.scene, ct = api.controls;
    var st = { mode: "query", instr: "either", sig: 0.12, peg: false, q: "policy", fa: 3, fo: 6, kind: "cascade", eps: 0.25, L: 0.3, N: 4, train: "indep", gen: "action", tauO: 0.5, leak: false, tr: 1, preset: "replay", s: 1, c: 1, seed: 5 };
    var M = null, eps = [], shown = 0, raf = 0, t0 = 0, chartT = 0, dead = false, vids = [];

    function f2(v) { return (+v).toFixed(2); }
    function pct(v) { return Math.round(v * 100) + "%"; }
    function angFmt(i) { return Math.round(-45 + 15 * i) + "°"; }
    function cellFmt(j) { return RB.fmt(W.cellX(j), 2); }
    var font = function (w, px, kind) { return w + " " + px + "px " + getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); };
    var blk = function (m, html) { return '<div class="rb-stack" data-mode="' + m + '">' + html + "</div>"; };

    sc.innerHTML =
      '<div class="rb-stack">' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-world" aria-label="Top-down table: the puck starts at the bottom and is pushed at one of seven angles toward nine landing cells on the far edge"></canvas><figcaption class="sb-caption" id="' + id + '-wcap">Green = the instructed bin. Ray width = probability of each push; bars on the far edge = probability of each landing cell.</figcaption></figure>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-table" aria-label="Heat map of the joint distribution over push angle and landing cell, with marginal bars"></canvas><figcaption class="sb-caption">The whole world model as one table p(o′, a | o, ℓ). Bottom bars sum over o′, right bars sum over a. Click a cell to fix a push or a landing.</figcaption></figure></div>' +
      blk("query", RB.readouts([{ id: "q-name", k: "Query" }, { id: "q-ref", k: "Source" }, { id: "q-best", k: "Most likely" }, { id: "q-bin", k: "Mass in the bin" }, { id: "q-pk", k: "Peaks" }]) + '<p class="sb-caption" id="' + id + '-qnote"></p>') +
      blk("couple", RB.readouts([{ id: "c-succ", k: "Lands in the bin", u: "exact" }, { id: "c-cons", k: "Real matches imagined" }, { id: "c-fut", k: "Predicted futures", u: "per action" }, { id: "c-samp", k: "Sampled episodes", u: "in the bin" }]) +
        '<p class="sb-caption" id="' + id + '-cnote"></p><p class="sb-caption" id="' + id + '-cerr"></p>' + RB.legend([{ c: "good", label: "lands in the bin", kind: "line" }, { c: "bad", label: "misses", kind: "line" }, { c: "accent", label: "imagined landing", kind: "dot" }]) + '<div id="' + id + '-cchart"></div>') +
      blk("uwm", '<div class="rb-grid2"><figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-plane" aria-label="Square of action noise level against future noise level, with training samples and the sampling path"></canvas><figcaption class="sb-caption">Dots = noise-level pairs seen in training. The accent line is the path the sampler walks. Its edges are the four models; off the dots the model is guessing.</figcaption></figure>' +
        '<div class="rb-stack">' + RB.readouts([{ id: "u-as", k: "Acts as" }, { id: "u-cov", k: "Path covered by training" }, { id: "u-best", k: "Most likely" }, { id: "u-bin", k: "Mass in the bin" }]) + '<p class="sb-caption" id="' + id + '-unote"></p></div></div>') +
      blk("leak", RB.readouts([{ id: "l-fit", k: "Training fit", u: "prob. of demo action" }, { id: "l-succ", k: "Deployed success" }, { id: "l-steps", k: "Denoising steps before acting", u: "of 10, toy" }, { id: "l-samp", k: "Sampled episodes", u: "in the bin" }]) +
        '<p class="sb-caption" id="' + id + '-lnote"></p><div id="' + id + '-lchart"></div>') +
      blk("idm", '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-film" aria-label="Six generated videos of the puck, each with the push an inverse dynamics model reads from it and where that push really lands"></canvas><figcaption class="sb-caption">Six generated videos. Faded pucks = frames. Accent arrow = the push the IDM reads from the first motion. Dashed = where that push really lands.</figcaption></figure>' +
        RB.readouts([{ id: "i-look", k: "Looks real", u: "toy sharpness" }, { id: "i-succ", k: "IDM execution success" }, { id: "i-unp", k: "Unphysical videos" }]) +
        '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-bars" aria-label="Bars comparing how real each toy generator looks against how often its videos execute"></canvas><figcaption class="sb-caption">Our toy numbers, 400 videos per generator. Looks real and executes are different axes: WoW reports that many visually convincing models fall near zero here.</figcaption></figure>');

    ct.innerHTML =
      '<div class="rb-stack"><span class="sb-caption">Bench mode</span>' + RB.seg({ id: id + "-mode", label: "Bench mode", value: st.mode, options: MODES }) + "</div>" +
      '<div class="rb-stack"><span class="sb-caption">Instruction ℓ</span>' + RB.seg({ id: id + "-instr", label: "Instruction", value: st.instr, options: [{ value: "left", label: "Left bin" }, { value: "either", label: "Either bin" }, { value: "play", label: "Play data" }] }) + "</div>" +
      RB.slider({ id: id + "-sig", label: "Dynamics noise σ", min: 0.04, max: 0.4, step: 0.02, value: st.sig, fmt: f2 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-peg"> <span>Peg in the middle</span></label>' +
      '<div class="rb-stack" data-cmode="query"><span class="sb-caption">Query</span>' + RB.seg({ id: id + "-q", label: "Query", value: st.q, options: [{ value: "policy", label: "Policy" }, { value: "video", label: "Video model" }, { value: "forward", label: "Forward model" }, { value: "idm", label: "Inverse dynamics" }] }) + "</div>" +
      '<div class="rb-stack" data-cmode="query uwm">' + RB.slider({ id: id + "-fa", label: "Fixed push a", min: 0, max: 6, step: 1, value: st.fa, fmt: angFmt }) + RB.slider({ id: id + "-fo", label: "Fixed landing o′", min: 0, max: 8, step: 1, value: st.fo, fmt: cellFmt }) + "</div>" +
      '<div class="rb-stack" data-cmode="couple"><span class="sb-caption">Coupling</span>' + RB.seg({ id: id + "-kind", label: "Coupling", value: st.kind, options: [{ value: "policy", label: "Policy only" }, { value: "cascade", label: "Cascade" }, { value: "score", label: "Score" }, { value: "joint", label: "Joint" }] }) +
        RB.slider({ id: id + "-eps", label: "Model error ε", min: 0, max: 0.6, step: 0.05, value: st.eps, fmt: f2 }) + RB.slider({ id: id + "-lab", label: "Action-labeled share", min: 0.05, max: 1, step: 0.05, value: st.L, fmt: pct }) + RB.slider({ id: id + "-n", label: "Candidates N (score)", min: 1, max: 16, step: 1, value: st.N }) + "</div>" +
      '<div class="rb-stack" data-cmode="uwm"><span class="sb-caption">Training noise levels</span>' + RB.seg({ id: id + "-train", label: "Training noise levels", value: st.train, options: [{ value: "shared", label: "Shared τ" }, { value: "indep", label: "Independent τ" }] }) +
        '<span class="sb-caption">Denoise</span>' + RB.seg({ id: id + "-gen", label: "Denoise", value: st.gen, options: [{ value: "action", label: "Action" }, { value: "future", label: "Future" }] }) +
        RB.slider({ id: id + "-tauo", label: "τ of the other modality", min: 0, max: 1, step: 0.05, value: st.tauO, fmt: f2 }) + "</div>" +
      '<div class="rb-stack" data-cmode="leak"><label class="sb-field"><input type="checkbox" id="' + id + '-leak"> <span>Action attends to future tokens</span></label>' +
        RB.slider({ id: id + "-tr", label: "Future denoised at readout", min: 0, max: 1, step: 0.1, value: st.tr, fmt: f2 }) + "</div>" +
      '<div class="rb-stack" data-cmode="idm"><span class="sb-caption">Toy generator</span>' + RB.seg({ id: id + "-pre", label: "Toy generator", value: st.preset, options: Object.keys(GENS).map(function (k) { return { value: k, label: GENS[k].label }; }) }) +
        RB.slider({ id: id + "-s", label: "Sharpness", min: 0.2, max: 1, step: 0.05, value: st.s, fmt: f2 }) + RB.slider({ id: id + "-c", label: "Physical consistency", min: 0, max: 1, step: 0.05, value: st.c, fmt: f2 }) + "</div>" +
      '<div class="sb-btn-row"><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-run">Sample episodes ▶</button><button class="sb-btn sb-btn--ghost" type="button" id="' + id + '-seed">New seed</button></div>';

    var q = function (s) { return sc.querySelector(s) || ct.querySelector(s); };
    var cvW = q("#" + id + "-world"), cvT = q("#" + id + "-table"), cvP = q("#" + id + "-plane"), cvF = q("#" + id + "-film"), cvB = q("#" + id + "-bars");
    var WW = 520, WH = 380, TW = 380, TH = 380;
    var toPx = function (x, y) { return [WW / 2 + x * 205, WH - 44 - y * 290]; };

    /* ---------- drawing: the world ---------- */
    function drawTableTop(c, P, M, toP, small) {
      var a0 = toP(-1.1, 1.06), a1 = toP(1.1, -0.08);
      c.fillStyle = P["surface-sunk"]; c.fillRect(a0[0], a0[1], a1[0] - a0[0], a1[1] - a0[1]);
      c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.strokeRect(a0[0], a0[1], a1[0] - a0[0], a1[1] - a0[1]);
      for (var j = 0; j < W.NO; j++) {
        var l = toP(-1 + j * W.CELLW, 1), r = toP(-1 + (j + 1) * W.CELLW, 1);
        if (W.inGoal(M, j)) { c.fillStyle = P["good-soft"]; c.fillRect(l[0], l[1] - (small ? 6 : 12), r[0] - l[0], small ? 6 : 12); }
        c.strokeStyle = P["line-strong"]; c.beginPath(); c.moveTo(l[0], l[1] - (small ? 6 : 12)); c.lineTo(l[0], l[1]); c.stroke();
      }
      var e0 = toP(-1, 1), e1 = toP(1, 1); c.strokeStyle = P["ink-3"]; c.beginPath(); c.moveTo(e0[0], e0[1]); c.lineTo(e1[0], e1[1]); c.stroke();
      if (M.peg) { var pg = toP(0, 0.5); c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.beginPath(); c.arc(pg[0], pg[1], small ? 4 : 10, 0, Math.PI * 2); c.fill(); c.stroke(); }
    }
    function pathPts(i, landX, peg) {
      if (peg && i === 3) return [[0, 0], [0, 0.44], [landX, 1]];
      return [[0, 0], [landX, 1]];
    }
    function strokePath(c, pts, toP) { c.beginPath(); pts.forEach(function (p, k) { var z = toP(p[0], p[1]); if (k) c.lineTo(z[0], z[1]); else c.moveTo(z[0], z[1]); }); c.stroke(); }
    function curOut() {
      /* the distribution the current mode is showing: {on:"a"|"o", d:[...]} */
      if (st.mode === "query") {
        if (st.q === "policy") return { on: "a", d: M.pi.slice() };
        if (st.q === "video") return { on: "o", d: W.video(M) };
        if (st.q === "forward") return { on: "o", d: W.colFwd(M, st.fa) };
        return { on: "a", d: W.rowIDM(M, st.fo) };
      }
      if (st.mode === "uwm") return uwmOut();
      return null;
    }
    function drawWorld() {
      if (dead || !M) return;
      var P = RB.pal(), c = RB.canvas(cvW, WW, WH), i;
      c.fillStyle = P.surface; c.fillRect(0, 0, WW, WH);
      drawTableTop(c, P, M, toPx, false);
      var s = toPx(0, 0), out = curOut();
      /* faint rays for all pushes */
      for (i = 0; i < W.NA; i++) { c.strokeStyle = P["ink-3"]; c.globalAlpha = 0.35; c.setLineDash([3, 4]); strokePath(c, pathPts(i, W.lands(i, M.peg)[0][0], M.peg), toPx); c.setLineDash([]); c.globalAlpha = 1; }
      if (out && out.on === "a") {
        var mx = Math.max.apply(null, out.d) || 1;
        for (i = 0; i < W.NA; i++) {
          var w = out.d[i] / mx; if (w < 0.01) continue;
          c.strokeStyle = P["data-1"]; c.globalAlpha = 0.25 + 0.75 * w; c.lineWidth = 1 + 9 * w;
          var e = toPx(0.62 * Math.tan(W.ANG[i]), 0.62); c.beginPath(); c.moveTo(s[0], s[1]); c.lineTo(e[0], e[1]); c.stroke();
        }
        c.globalAlpha = 1; c.lineWidth = 1;
        c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.textAlign = "center";
        for (i = 0; i < W.NA; i++) { var tp = toPx(0.7 * Math.tan(W.ANG[i]), 0.7); c.fillText(pct(out.d[i]), tp[0], tp[1] - 2); }
      }
      if (out && out.on === "o") {
        var mo = Math.max.apply(null, out.d) || 1;
        for (var j = 0; j < W.NO; j++) {
          var l = toPx(-1 + j * W.CELLW, 1), r = toPx(-1 + (j + 1) * W.CELLW, 1), h = 60 * out.d[j] / mo;
          c.fillStyle = P["data-2"]; c.fillRect(l[0] + 3, l[1] + 4, r[0] - l[0] - 6, h);
          if (out.d[j] > 0.02) { c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.textAlign = "center"; c.fillText(pct(out.d[j]), (l[0] + r[0]) / 2, l[1] + h + 18); }
        }
      }
      if (st.mode === "query" && st.q === "forward") { c.strokeStyle = P.accent; c.lineWidth = 2.5; strokePath(c, pathPts(st.fa, W.lands(st.fa, M.peg)[0][0], M.peg), toPx); if (M.peg && st.fa === 3) strokePath(c, pathPts(3, W.lands(3, true)[1][0], true), toPx); c.lineWidth = 1; }
      if (st.mode === "query" && st.q === "idm") { var fo = toPx(W.cellX(st.fo), 1); c.fillStyle = P.accent; c.beginPath(); c.arc(fo[0], fo[1], 7, 0, Math.PI * 2); c.fill(); }
      if ((st.mode === "couple" || st.mode === "leak") && eps.length) {
        eps.slice(0, shown).forEach(function (ep, k) {
          var lx = W.cellX(ep.real) + ((k * 37) % 11 - 5) * 0.012;
          c.strokeStyle = ep.ok ? P.good : P.bad; c.globalAlpha = 0.6; c.lineWidth = 1.5;
          strokePath(c, pathPts(ep.a, lx, M.peg && ep.a === 3), toPx); c.globalAlpha = 1;
          var e = toPx(lx, 1); c.fillStyle = ep.ok ? P.good : P.bad; c.beginPath(); c.arc(e[0], e[1], 3.5, 0, Math.PI * 2); c.fill();
          if (ep.img != null) { var im = toPx(W.cellX(ep.img) + ((k * 53) % 9 - 4) * 0.014, 1.02 + (k % 4) * 0.012); c.strokeStyle = ep.noise ? P["ink-3"] : P.accent; c.lineWidth = 1.5; c.beginPath(); c.arc(im[0], im[1] - 10, 3.5, 0, Math.PI * 2); c.stroke(); c.lineWidth = 1; }
        });
      }
      c.fillStyle = P.ink; c.beginPath(); c.arc(s[0], s[1], 7, 0, Math.PI * 2); c.fill();
      c.textAlign = "left"; c.fillStyle = P["ink-2"]; c.font = font("600", 12, "body"); c.fillText("puck", s[0] + 12, s[1] + 4);
      c.fillStyle = P["ink-3"]; c.font = font("500", 12, "mono"); c.fillText("far edge: 9 landing cells o′", 12, WH - 8);
      c.textAlign = "right"; c.fillText(st.instr === "play" ? "play data · scored on both bins" : st.instr === "left" ? "ℓ = left bin" : "ℓ = either bin", WW - 12, WH - 8); c.textAlign = "left";
    }

    /* ---------- drawing: the joint table ---------- */
    var GX = 50, GY = 14, CW = 38, CH = 30;
    function drawTable() {
      if (dead || !M) return;
      var P = RB.pal(), c = RB.canvas(cvT, TW, TH), i, j, mx = 0, gw = CW * W.NA, gh = CH * W.NO;
      c.fillStyle = P.surface; c.fillRect(0, 0, TW, TH);
      for (j = 0; j < W.NO; j++) for (i = 0; i < W.NA; i++) mx = Math.max(mx, M.J[j][i]);
      c.fillStyle = P["surface-sunk"]; c.fillRect(GX, GY, gw, gh);
      var dimA = st.mode === "query" && st.q === "forward", dimO = st.mode === "query" && st.q === "idm";
      for (j = 0; j < W.NO; j++) for (i = 0; i < W.NA; i++) {
        var on = (dimA && i !== st.fa) || (dimO && j !== st.fo) ? 0.2 : 1;
        c.globalAlpha = on * Math.sqrt(M.J[j][i] / mx); c.fillStyle = P["data-1"];
        c.fillRect(GX + i * CW + 1, GY + (W.NO - 1 - j) * CH + 1, CW - 2, CH - 2);
      }
      c.globalAlpha = 1; c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.strokeRect(GX, GY, gw, gh);
      for (j = 0; j < W.NO; j++) if (W.inGoal(M, j)) { c.fillStyle = P.good; c.fillRect(GX - 7, GY + (W.NO - 1 - j) * CH + 2, 4, CH - 4); }
      /* marginals */
      var pa = M.pi, po = W.video(M), mpa = Math.max.apply(null, pa), mpo = Math.max.apply(null, po);
      var hiA = st.mode === "query" && st.q === "policy", hiO = st.mode === "query" && st.q === "video";
      for (i = 0; i < W.NA; i++) { var h = 34 * pa[i] / mpa; c.fillStyle = hiA ? P.accent : P["ink-3"]; c.fillRect(GX + i * CW + 6, GY + gh + 6, CW - 12, h); }
      for (j = 0; j < W.NO; j++) { var w = 40 * po[j] / mpo; c.fillStyle = hiO ? P.accent : P["ink-3"]; c.fillRect(GX + gw + 6, GY + (W.NO - 1 - j) * CH + 6, w, CH - 12); }
      c.strokeStyle = P.accent; c.lineWidth = 2.5;
      if (st.mode === "query" && st.q === "forward" || st.mode === "uwm" && st.gen === "future") { c.globalAlpha = st.mode === "uwm" ? 0.3 + 0.7 * st.tauO : 1; c.strokeRect(GX + st.fa * CW, GY, CW, gh); }
      if (st.mode === "query" && st.q === "idm" || st.mode === "uwm" && st.gen === "action") { c.globalAlpha = st.mode === "uwm" ? 0.3 + 0.7 * st.tauO : 1; c.strokeRect(GX, GY + (W.NO - 1 - st.fo) * CH, gw, CH); }
      c.globalAlpha = 1; c.lineWidth = 1;
      c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.textAlign = "center";
      for (i = 0; i < W.NA; i += 1) c.fillText(angFmt(i), GX + i * CW + CW / 2, GY + gh + 54);
      c.textAlign = "right"; [0, 4, 8].forEach(function (jj) { c.fillText(RB.fmt(W.cellX(jj), 1), GX - 10, GY + (W.NO - 1 - jj) * CH + CH / 2 + 4); });
      c.fillStyle = P["ink-2"]; c.font = font("600", 12, "body"); c.textAlign = "center";
      c.fillText("push angle a", GX + gw / 2, TH - 8);
      c.save(); c.translate(13, GY + gh / 2); c.rotate(-Math.PI / 2); c.fillText("landing cell o′", 0, 0); c.restore();
      c.textAlign = "left";
    }

    /* ---------- UWM: per-modality noise levels ---------- */
    function uwmRel() {
      if (st.train === "indep") return 1;
      var cc = st.tauO, md = (cc * cc + (1 - cc) * (1 - cc)) / 2 / Math.SQRT2; return Math.exp(-md / 0.12);
    }
    function uwmOut() {
      var t = st.tauO, r = uwmRel(), d = [], i, j;
      if (st.gen === "action") {
        for (i = 0; i < W.NA; i++) { var s = 0; for (j = 0; j < W.NO; j++) s += M.J[j][i] * ((j === st.fo ? t : 0) + (1 - t) / W.NO); d.push(s); }
        return { on: "a", d: W.mixU(W.norm(d), 1 - r) };
      }
      for (j = 0; j < W.NO; j++) { var s2 = 0; for (i = 0; i < W.NA; i++) s2 += M.J[j][i] * ((i === st.fa ? t : 0) + (1 - t) / W.NA); d.push(s2); }
      return { on: "o", d: W.mixU(W.norm(d), 1 - r) };
    }
    var PW = 300, PH = 300;
    function drawPlane() {
      if (dead) return;
      var P = RB.pal(), c = RB.canvas(cvP, PW, PH), x0 = 56, y0 = 20, S = 200;
      var px = function (ta, to) { return [x0 + ta * S, y0 + S - to * S]; };
      c.fillStyle = P.surface; c.fillRect(0, 0, PW, PH);
      c.fillStyle = P["surface-sunk"]; c.fillRect(x0, y0, S, S); c.strokeStyle = P["line-strong"]; c.strokeRect(x0, y0, S, S);
      var R = RB.rng(11); c.fillStyle = P["ink-3"]; c.globalAlpha = 0.55;
      for (var k = 0; k < 160; k++) { var u = R(), v = st.train === "shared" ? u : R(); var p = px(u, v); c.beginPath(); c.arc(p[0], p[1], 1.8, 0, Math.PI * 2); c.fill(); }
      c.globalAlpha = 1;
      /* sampler path: the generated modality goes 0 → 1 while the other stays at τ */
      var a0 = st.gen === "action" ? px(0, st.tauO) : px(st.tauO, 0), a1 = st.gen === "action" ? px(1, st.tauO) : px(st.tauO, 1);
      c.strokeStyle = P.accent; c.lineWidth = 3; c.beginPath(); c.moveTo(a0[0], a0[1]); c.lineTo(a1[0], a1[1]); c.stroke(); c.lineWidth = 1;
      c.fillStyle = P.accent; c.beginPath(); c.arc(a1[0], a1[1], 5, 0, Math.PI * 2); c.fill();
      /* each edge of the square is one of the four models */
      c.fillStyle = P.ink; c.font = font("600", 12, "body"); c.textAlign = "center";
      c.fillText("policy", x0 + S / 2, y0 + S - 8); c.fillText("inverse dynamics", x0 + S / 2, y0 + 16);
      c.save(); c.translate(x0 + 14, y0 + S / 2); c.rotate(-Math.PI / 2); c.fillText("video model", 0, 0); c.restore();
      c.save(); c.translate(x0 + S - 8, y0 + S / 2); c.rotate(Math.PI / 2); c.fillText("forward model", 0, 0); c.restore();
      c.fillStyle = P["ink-2"]; c.font = font("600", 12, "body"); c.textAlign = "center";
      c.fillText("action noise level τₐ (1 = clean)", x0 + S / 2, PH - 34);
      c.fillStyle = P["ink-3"]; c.font = font("500", 11, "mono"); c.fillText("0", x0, y0 + S + 28); c.fillText("1", x0 + S, y0 + S + 28);
      c.save(); c.translate(18, y0 + S / 2); c.rotate(-Math.PI / 2); c.fillStyle = P["ink-2"]; c.font = font("600", 12, "body"); c.fillText("future noise level τₒ′", 0, 0); c.restore();
      c.fillStyle = P["ink-2"]; c.font = font("600", 12, "body"); c.textAlign = "left";
      c.fillText(st.train === "shared" ? "Shared τ (PAD-style)" : "Independent τ (UWM)", x0, PH - 12);
    }

    /* ---------- IDM Turing test: filmstrip and bars ---------- */
    var FWd = 440, FHt = 480, BW = 440, BH = 200;
    function drawFilm() {
      if (dead || !M) return;
      var P = RB.pal(), c = RB.canvas(cvF, FWd, FHt), cols = 2, pw = FWd / cols, ph = FHt / 3;
      c.fillStyle = P.surface; c.fillRect(0, 0, FWd, FHt);
      vids.forEach(function (v, k) {
        var ox = (k % cols) * pw, oy = Math.floor(k / cols) * ph;
        var toP = function (x, y) { return [ox + pw / 2 + x * (pw / 2 - 16), oy + ph - 30 - y * (ph - 56)]; };
        drawTableTop(c, P, M, toP, true);
        var end = [W.cellX(v.o), 1], th = W.ANG[v.first], mid = [0.42 * Math.tan(th), 0.42];
        var pts = v.phys ? pathPts(v.a, end[0], M.peg && v.a === 3) : [[0, 0], mid, end];
        /* frames along the generated path */
        var seg = [], L = 0; for (var q1 = 1; q1 < pts.length; q1++) { var dx = pts[q1][0] - pts[q1 - 1][0], dy = pts[q1][1] - pts[q1 - 1][1]; seg.push(Math.sqrt(dx * dx + dy * dy)); L += seg[seg.length - 1]; }
        for (var f = 0; f <= 5; f++) {
          var d = f / 5 * L, s0 = 0; while (s0 < seg.length - 1 && d > seg[s0]) { d -= seg[s0]; s0++; }
          var r = Math.min(1, d / seg[s0]), p = [pts[s0][0] + (pts[s0 + 1][0] - pts[s0][0]) * r, pts[s0][1] + (pts[s0 + 1][1] - pts[s0][1]) * r], z = toP(p[0], p[1]);
          c.globalAlpha = 0.25 + 0.12 * f; c.fillStyle = P["ink-2"]; c.beginPath(); c.arc(z[0], z[1], 3 + 4 * (1 - v.s), 0, Math.PI * 2); c.fill();
        }
        c.globalAlpha = 1;
        /* decoded push and its real landing */
        var s = toP(0, 0), e = toP(0.3 * Math.tan(W.ANG[v.dec]), 0.3);
        c.strokeStyle = P.accent; c.lineWidth = 2.5; c.beginPath(); c.moveTo(s[0], s[1]); c.lineTo(e[0], e[1]); c.stroke(); c.lineWidth = 1;
        c.strokeStyle = v.ok ? P.good : P.bad; c.setLineDash([4, 3]); strokePath(c, pathPts(v.dec, W.cellX(v.real), M.peg && v.dec === 3), toP); c.setLineDash([]);
        var rl = toP(W.cellX(v.real), 1); c.fillStyle = v.ok ? P.good : P.bad; c.beginPath(); c.arc(rl[0], rl[1], 4, 0, Math.PI * 2); c.fill();
        c.fillStyle = P["ink-2"]; c.font = font("500", 12, "mono"); c.textAlign = "left"; c.fillText((v.phys ? "physical" : "unphysical") + " · " + (v.ok ? "executes" : "fails"), ox + 8, oy + ph - 8);
      });
      c.textAlign = "left";
    }
    function drawBars() {
      if (dead || !M) return;
      var P = RB.pal(), c = RB.canvas(cvB, BW, BH), keys = Object.keys(GENS), x0 = 20, gw = (BW - 40) / keys.length, y0 = 20, hh = 110;
      c.fillStyle = P.surface; c.fillRect(0, 0, BW, BH);
      c.strokeStyle = P["line-strong"]; c.beginPath(); c.moveTo(x0, y0 + hh + 0.5); c.lineTo(BW - 20, y0 + hh + 0.5); c.stroke();
      keys.forEach(function (k, n) {
        var g = GENS[k], r = idmTest(M, g.s, g.c, 400, 900 + st.seed), bx = x0 + n * gw + gw / 2 - 40;
        [[r.looks, P["data-3"]], [r.succ, P["data-1"]]].forEach(function (b, m) {
          var h = b[0] * hh; c.fillStyle = b[1]; c.fillRect(bx + m * 42, y0 + hh - h, 36, h);
          c.fillStyle = P["ink-2"]; c.font = font("500", 11, "mono"); c.textAlign = "center"; c.fillText(pct(b[0]), bx + m * 42 + 18, y0 + hh - h - 5);
        });
        c.fillStyle = st.mode === "idm" && st.preset === k ? P.accent : P["ink-2"]; c.font = font("600", 12, "body"); c.textAlign = "center"; c.fillText(g.label, bx + 39, y0 + hh + 18);
      });
      c.textAlign = "left"; c.font = font("500", 11, "mono");
      c.fillStyle = P["data-3"]; c.fillRect(x0, BH - 22, 10, 10); c.fillStyle = P["ink-2"]; c.fillText("looks real", x0 + 16, BH - 13);
      c.fillStyle = P["data-1"]; c.fillRect(x0 + 110, BH - 22, 10, 10); c.fillStyle = P["ink-2"]; c.fillText("executes (lands in the bin)", x0 + 126, BH - 13);
    }

    /* ---------- per-mode updates ---------- */
    function peaks(d) { var mx = Math.max.apply(null, d), n = 0; for (var i = 0; i < d.length; i++) { var l = i ? d[i - 1] : -1, r = i < d.length - 1 ? d[i + 1] : -1; if (d[i] >= l && d[i] > r && d[i] > 0.15 * mx) n++; } return n; }
    function argmax(d) { var b = 0; d.forEach(function (v, i) { if (v > d[b]) b = i; }); return b; }
    function binMass(out) { if (out.on === "o") return M.goal.reduce(function (s, g) { return s + out.d[g]; }, 0); return out.d.reduce(function (s, p, i) { return s + p * M.S[i]; }, 0); }
    function descr(out) { var b = argmax(out.d); return out.on === "a" ? "push " + angFmt(b) : "cell at " + cellFmt(b); }
    function updQuery() {
      var out = curOut();
      RB.setRO(sc, "q-name", QNAME[st.q]); RB.setRO(sc, "q-ref", QREF[st.q]); RB.setRO(sc, "q-best", descr(out)); RB.setRO(sc, "q-bin", pct(binMass(out))); RB.setRO(sc, "q-pk", String(peaks(out.d)));
      q("#" + id + "-qnote").textContent = QNOTE[st.q];
      q("#" + id + "-fa").disabled = st.q !== "forward"; q("#" + id + "-fo").disabled = st.q !== "idm";
    }
    function updUwm() {
      var out = uwmOut(), t = st.tauO, as;
      if (st.gen === "action") as = t <= 0.001 ? "policy" : t >= 0.999 ? "IDM" : "policy → IDM";
      else as = t <= 0.001 ? "video" : t >= 0.999 ? "forward" : "video → fwd";
      RB.setRO(sc, "u-as", as); RB.setRO(sc, "u-cov", pct(uwmRel())); RB.setRO(sc, "u-best", descr(out)); RB.setRO(sc, "u-bin", pct(binMass(out)));
      q("#" + id + "-unote").textContent = st.train === "shared"
        ? "With one shared noise level, training only visits the diagonal, so pure-noise or clean corners for one modality are untrained. Outputs there drift toward guesses (UWM contrasts this with PAD)."
        : "UWM samples a separate noise level per modality, so every corner is trained: pure noise marginalizes a modality, clean conditions on it (arXiv 2504.02792).";
      q("#" + id + "-fa").disabled = st.gen !== "future"; q("#" + id + "-fo").disabled = st.gen !== "action";
      drawPlane();
    }
    function updCouple() {
      var r = coupling(M, st.kind, st.eps, st.L, st.N), E = r.E;
      RB.setRO(sc, "c-succ", pct(r.succ)); RB.setRO(sc, "c-cons", r.cons == null ? "–" : pct(r.cons)); RB.setRO(sc, "c-fut", String(r.futures));
      q("#" + id + "-cerr").textContent = "Error of the learned parts: " + (st.kind === "policy" ? "policy " + f2(E.policy) : st.kind === "cascade" ? "video " + f2(E.video) + ", IDM " + f2(E.idm) : st.kind === "score" ? "policy " + f2(E.policy) + ", forward " + f2(E.fwd) : "joint " + f2(E.joint)) + " (our error rule).";
      q("#" + id + "-cnote").textContent = CNOTE[st.kind];
      q("#" + id + "-n").disabled = st.kind !== "score";
    }
    function updLeak() {
      var r = leak(M, st.leak, st.tr);
      RB.setRO(sc, "l-fit", pct(r.fit)); RB.setRO(sc, "l-succ", pct(r.succ)); RB.setRO(sc, "l-steps", st.leak ? String(Math.round(st.tr * 10)) : "0 needed");
      q("#" + id + "-lnote").textContent = st.leak
        ? "The action head learned to read the true future, so training fit is high. Read early, the future token is still mostly noise and the head decodes a push for a random landing (P04 §5.2)."
        : "A causal mask stops action tokens from attending to future tokens, so the head learns the policy itself and can act before the future is denoised (P04 §5.2).";
      q("#" + id + "-tr").disabled = !st.leak;
    }
    function updIdm() {
      var R = RB.rng(700 + st.seed); vids = []; for (var k = 0; k < 6; k++) vids.push(genVideo(M, st.s, st.c, R));
      var r = idmTest(M, st.s, st.c, 400, 900 + st.seed);
      RB.setRO(sc, "i-look", pct(r.looks)); RB.setRO(sc, "i-succ", pct(r.succ)); RB.setRO(sc, "i-unp", pct(r.unphys));
      drawFilm(); drawBars();
    }

    function sampleEps() {
      if (st.mode === "couple") eps = episodes(M, st.kind, st.eps, st.L, st.N, NEP, st.seed);
      else if (st.mode === "leak") eps = leakEpisodes(M, st.leak, st.tr, NEP, st.seed);
      else eps = [];
    }
    function frame(ts) {
      if (dead) return;
      if (!t0) t0 = ts;
      shown = Math.min(eps.length, Math.floor((ts - t0) / 45) + 1);
      drawWorld(); setSamp();
      if (shown >= eps.length) { raf = 0; api.live("paused", "Done · " + eps.filter(function (e) { return e.ok; }).length + " of " + eps.length + " landed in the bin"); return; }
      api.live("running", "Sampling · " + shown + " of " + eps.length);
      raf = requestAnimationFrame(frame);
    }
    function setSamp() { var k = eps.slice(0, shown).filter(function (e) { return e.ok; }).length; var txt = eps.length ? k + " / " + shown : "–"; RB.setRO(sc, "c-samp", txt); RB.setRO(sc, "l-samp", txt); }
    function animate() { if (raf) cancelAnimationFrame(raf); raf = 0; t0 = 0; shown = 0; sampleEps(); if (!eps.length) { drawWorld(); return; } raf = requestAnimationFrame(frame); }

    function showMode() {
      RB.$$("[data-mode]", sc).forEach(function (b) { b.style.display = b.getAttribute("data-mode") === st.mode ? "" : "none"; });
      RB.$$("[data-cmode]", ct).forEach(function (b) { b.style.display = b.getAttribute("data-cmode").split(" ").indexOf(st.mode) >= 0 ? "" : "none"; });
      var runB = q("#" + id + "-run"); runB.textContent = st.mode === "idm" ? "Generate videos ▶" : "Sample episodes ▶"; runB.disabled = st.mode === "query" || st.mode === "uwm";
      q("#" + id + "-wcap").textContent = st.mode === "couple" || st.mode === "leak"
        ? "Each line is one episode: green lands in the bin, red misses. Rings above the edge mark the landing the model imagined (gray rings are noise)."
        : "Green = the instructed bin. Ray width = probability of each push; bars on the far edge = probability of each landing cell.";
    }
    function update(opts) {
      if (dead) return;
      M = W.build(st.instr, st.sig, st.peg);
      showMode();
      api.meta(MODE_NAME[st.mode] + " · " + (st.instr === "play" ? "play data" : st.instr + " bin") + " · seed " + st.seed);
      if (st.mode === "query") updQuery();
      if (st.mode === "uwm") updUwm();
      if (st.mode === "couple") updCouple();
      if (st.mode === "leak") updLeak();
      if (st.mode === "idm") updIdm();
      drawTable();
      if ((st.mode === "couple" || st.mode === "leak") && !(opts && opts.still)) animate();
      else { if (raf) cancelAnimationFrame(raf); raf = 0; if (st.mode !== "couple" && st.mode !== "leak") eps = []; else { sampleEps(); shown = eps.length; setSamp(); } drawWorld(); api.live("paused", "Ready"); }
      clearTimeout(chartT); chartT = setTimeout(chart, 80);
    }

    /* ---------- charts ---------- */
    function chart() {
      if (dead || !M) return;
      if (st.mode === "couple") {
        var host = q("#" + id + "-cchart"), Ls = [0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 1], cols = { policy: "data-5", cascade: "data-1", score: "data-3", joint: "data-2" };
        host.innerHTML = "";
        StudyBench.lineChart(host, {
          title: "Success against action-labeled share", x: { label: "Action-labeled share", min: 0, max: 1, ticks: [0, 0.25, 0.5, 0.75, 1] },
          y: { label: "Lands in the bin", min: 0, max: 1, ticks: [0, 0.25, 0.5, 0.75, 1], fmt: function (v) { return Math.round(v * 100) + "%"; } },
          series: ["policy", "cascade", "score", "joint"].map(function (k) { return { name: { policy: "Policy", cascade: "Cascade", score: "Score", joint: "Joint" }[k], color: cols[k], dash: k === "policy", points: Ls.map(function (L) { return [L, coupling(M, k, st.eps, L, st.N).succ]; }) }; }),
          height: 220, caption: "Our toy numbers at the current ε and N. Fewer action labels hurt the policy most. UWM reports co-training on video raising Stack-Bowls success from 0.86 to 0.92."
        });
      } else if (st.mode === "leak") {
        var h2 = q("#" + id + "-lchart"), T = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1];
        h2.innerHTML = "";
        StudyBench.lineChart(h2, {
          title: "Training fit and deployed success against readout time", x: { label: "Future denoised at readout", min: 0, max: 1, ticks: [0, 0.25, 0.5, 0.75, 1] },
          y: { label: "Share", min: 0, max: 1, ticks: [0, 0.25, 0.5, 0.75, 1], fmt: function (v) { return Math.round(v * 100) + "%"; } },
          series: [
            { name: "Leaky, deployed", color: "data-5", points: T.map(function (t) { return [t, leak(M, true, t).succ]; }) },
            { name: "Causal, deployed", color: "data-1", points: T.map(function (t) { return [t, leak(M, false, t).succ]; }) },
            { name: "Leaky, training", color: "data-5", dash: true, points: T.map(function (t) { return [t, leak(M, true, t).fit]; }) },
            { name: "Causal, training", color: "data-1", dash: true, points: T.map(function (t) { return [t, leak(M, false, t).fit]; }) }
          ],
          height: 220, directLabels: false, caption: "Our toy numbers. The leaky head always fits training better, yet deployed it is only as good as the future it reads. The causal head does not depend on readout time."
        });
      }
    }

    /* ---------- wiring ---------- */
    function bindSeg(sid, cb) { StudyBench.segmented(ct.querySelector("#" + sid), function (a, b) { cb(b ? b.value : a); }); }
    function setSeg(sid, v) { RB.$$("#" + sid + " button", ct).forEach(function (b) { b.setAttribute("aria-pressed", b.value === v ? "true" : "false"); }); }
    function setSlider(sid, v, fmt) { var inp = q("#" + sid), out = ct.querySelector('[data-out="' + sid + '"]'); inp.value = v; if (out) out.textContent = fmt ? fmt(v) : v; }
    bindSeg(id + "-mode", function (v) { st.mode = v; update(); });
    bindSeg(id + "-instr", function (v) { st.instr = v; update(); });
    bindSeg(id + "-q", function (v) { st.q = v; update(); });
    bindSeg(id + "-kind", function (v) { st.kind = v; update(); });
    bindSeg(id + "-train", function (v) { st.train = v; update(); });
    bindSeg(id + "-gen", function (v) { st.gen = v; update(); });
    bindSeg(id + "-pre", function (v) { var g = GENS[v]; if (!g) return; st.preset = v; st.s = g.s; st.c = g.c; setSlider(id + "-s", g.s, f2); setSlider(id + "-c", g.c, f2); update(); });
    RB.bindSlider(ct, id + "-sig", f2, function (v) { st.sig = v; update(); });
    RB.bindSlider(ct, id + "-fa", angFmt, function (v) { st.fa = v; update(); });
    RB.bindSlider(ct, id + "-fo", cellFmt, function (v) { st.fo = v; update(); });
    RB.bindSlider(ct, id + "-eps", f2, function (v) { st.eps = v; update(); });
    RB.bindSlider(ct, id + "-lab", pct, function (v) { st.L = v; update(); });
    RB.bindSlider(ct, id + "-n", null, function (v) { st.N = v; update(); });
    RB.bindSlider(ct, id + "-tauo", f2, function (v) { st.tauO = v; update(); });
    RB.bindSlider(ct, id + "-tr", f2, function (v) { st.tr = v; update(); });
    RB.bindSlider(ct, id + "-s", f2, function (v) { st.s = v; st.preset = null; setSeg(id + "-pre", "__none"); update(); });
    RB.bindSlider(ct, id + "-c", f2, function (v) { st.c = v; st.preset = null; setSeg(id + "-pre", "__none"); update(); });
    q("#" + id + "-peg").addEventListener("change", function (e) { st.peg = e.target.checked; update(); });
    q("#" + id + "-leak").addEventListener("change", function (e) { st.leak = e.target.checked; update(); });
    q("#" + id + "-run").addEventListener("click", function () { st.seed++; update(); });
    q("#" + id + "-seed").addEventListener("click", function () { st.seed++; update({ still: true }); });
    cvT.addEventListener("click", function (e) {
      var r = cvT.getBoundingClientRect(), x = (e.clientX - r.left) / r.width * TW, y = (e.clientY - r.top) / r.height * TH;
      var i = Math.floor((x - GX) / CW), j = W.NO - 1 - Math.floor((y - GY) / CH);
      if (i < 0 || i >= W.NA || j < 0 || j >= W.NO) return;
      st.fa = i; st.fo = j; setSlider(id + "-fa", i, angFmt); setSlider(id + "-fo", j, cellFmt); update({ still: true });
    });
    RB.onTheme(function () { if (dead || !document.contains(cvW)) return; drawWorld(); drawTable(); if (st.mode === "uwm") drawPlane(); if (st.mode === "idm") { drawFilm(); drawBars(); } });

    /* side panel: reference numbers from the method cards */
    if (api.side) {
      api.side.style.minWidth = "0";
      api.side.innerHTML = '<p class="rb-h5">Reference numbers</p>' + [
        ["UWM co-training", "Stack-Bowls success 0.86 → 0.92 with robot video; PAD 0.08 / 0.20", "arXiv 2504.02792"],
        ["UWM as IDM", "LIBERO tracking 0.65 / 0.55 against 0.47 / 0.26 as a policy", "arXiv 2504.02792"],
        ["PAD without image prediction", "Metaworld success 72.5% → 43.6%", "arXiv 2411.18179"],
        ["Fast-WAM", "RoboTwin 91.8%, 83.8% without video co-training; 190 / 580 / 810 ms for skip, joint, IDM", "arXiv 2603.16666"],
        ["IDM Turing test", "WoW-wan 40.74%, Kling 9.88%, Cosmos-Predict2 8.64%, Hailuo 2.47%, three models 0%", "arXiv 2601.04137"],
        ["GC-IDM replay", "90% of real videos replayed correctly; the benchmark's authors also built the WoW models", "arXiv 2601.04137"]
      ].map(function (r) { return '<p class="sb-caption"><b>' + r[0] + "</b>: " + r[1] + ' <span class="sb-ref">' + r[2] + "</span></p>"; }).join("");
    }

    update({ still: true });

    return {
      state: function () { return st; },
      demo: function () {
        var seg = function (sid, v) { return q("#" + id + "-" + sid + ' [value="' + v + '"]'); };
        var fin = function (a) { return a.until(function () { return !raf; }, 6000); };
        return [
          { target: q("#" + id + "-q"), title: "Fix the push", text: "The policy sums the table over landings. Now fix one push instead: the forward model reads that push's column of the same table.", do: function (a) { return a.click(seg("q", "forward")); }, task: "Choose the Forward model query", expect: function () { return st.mode === "query" && st.q === "forward"; } },
          { target: q("#" + id + "-peg"), title: "A peg splits the future", text: "With a peg in the middle, the straight push lands left or right. The forward model for 0° now has two peaks.", do: function (a) { return a.click(q("#" + id + "-peg")); }, task: "Tick Peg in the middle", expect: function () { return st.peg; } },
          { target: q("#" + id + "-mode"), title: "Three couplings", text: "Couplings use the queries to act. A cascade imagines a landing, then an IDM decodes the push that should reach it.", do: function (a) { return a.click(seg("mode", "couple")).then(function () { return fin(a); }); }, task: "Open the Couplings mode", expect: function () { return st.mode === "couple"; } },
          { target: q("#" + id + "-lab"), title: "Scarce action labels", text: "With 10% action labels the policy loses most. The cascade barely moves: its video model needs no labels. Compare the chart lines.", do: function (a) { return a.set(q("#" + id + "-lab"), 0.1).then(function () { return fin(a); }); }, task: "Set Action-labeled share to 20% or less", expect: function () { return st.mode === "couple" && st.L <= 0.2; } },
          { target: q("#" + id + "-mode"), title: "Why UWM needs two dials", text: "UWM gives action and future their own noise levels. With one shared level, training never visits the corners the four models need.", do: function (a) { return a.click(seg("mode", "uwm")).then(function () { return a.wait(300); }).then(function () { return a.click(seg("train", "shared")); }); }, task: "Open UWM dials, then choose Shared τ", expect: function () { return st.mode === "uwm" && st.train === "shared"; } },
          { target: q("#" + id + "-mode"), title: "Leaking the future", text: "If action tokens attend to future tokens, training looks great. Read the action early and the future is still noise.", do: function (a) { return a.click(seg("mode", "leak")).then(function () { return a.click(q("#" + id + "-leak")); }).then(function () { return a.set(q("#" + id + "-tr"), 0.2); }).then(function () { return fin(a); }); }, task: "Open Leakage, tick the leak, set readout to 0.3 or less", expect: function () { return st.mode === "leak" && st.leak && st.tr <= 0.3; } },
          { target: q("#" + id + "-mode"), title: "Looks real is not enough", text: "The IDM Turing test executes the push an IDM reads from a generated video. A sharp but unphysical generator looks real and fails.", do: function (a) { return a.click(seg("mode", "idm")).then(function () { return a.wait(300); }).then(function () { return a.click(seg("pre", "sharp")); }); }, task: "Open IDM test, then choose the Sharp generator", expect: function () { return st.mode === "idm" && st.preset === "sharp"; } },
          { target: q("#" + id + "-mode"), title: "Your turn", text: "Back in Couplings, raise Model error ε and compare Score at N = 1 and N = 16. More candidates cost more predicted futures." }
        ];
      },
      destroy: function () { dead = true; if (raf) cancelAnimationFrame(raf); raf = 0; clearTimeout(chartT); }
    };
  }

  RB.station({
    id: "wam", name: "WAM coupling playground", sub: "11 · couplings",
    refs: ["P03 eq. 4–8", "P04 §2.3, §4.1, §5.2", "X1 §4, §6.1.3"], prov: "Simplified: exact 9 × 7 toy table",
    summary: "One small table p(o′, a | o, ℓ) holds a whole push world. Query it four ways, act on it through a cascade, a scoring loop or a joint model, then break it with shared noise, leakage or unphysical video.",
    notice: [
      "Policy, video model, forward model and inverse dynamics are sums or slices of one joint table.",
      "A cascade decodes whatever the video model imagines, so hallucinated landings become real misses.",
      "Scoring improves with more candidates, at the cost of one predicted future each.",
      "Independent noise levels per modality are what let one UWM network answer all four queries.",
      "A video can look sharp and still fail the IDM Turing test if its motion is not executable."
    ],
    card: "Query one joint table four ways, couple it three ways, then test leakage and generated videos.",
    terms: {
      "future-leakage": { name: "future leakage", aliases: ["leakage", "leakage-free denoising", "causal action mask"], group: "wam", def: "Future information reaching the action being executed now, for example action tokens attending to future-frame tokens that are not available at inference.", note: "Leaky models fit training well and can fail when the action is read before the future is generated.", ref: "P04 §5.2", scene: "system", focus: ["predicted-future", "action-head"], look: "the future feeding the action head", uses: [] },
      "idm-turing-test": { name: "IDM Turing test", aliases: ["inverse dynamics Turing test"], group: "eval", def: "An evaluation that applies an inverse dynamics model to generated videos, executes the inferred actions on a real robot and scores task success.", note: "It measures action plausibility, which visual-quality metrics such as FVD do not.", ref: "X1 §6.1.3 · arXiv 2601.04137", scene: "system", focus: ["predicted-future", "robot"], look: "generated future driving the robot", uses: [] }
    },
    ledger: [
      { where: "Lab · WAM coupling playground", source: "P03 eq. 4–8 define the queries on continuous observations and action chunks", page: "The bench uses one push angle (7 values) and one landing cell (9 values), so the joint is an exact table", why: "Every query becomes a visible row, column or sum.", kind: "Simplified" },
      { where: "Lab · WAM coupling playground", source: "Demonstrations come from people", page: "The demonstrator picks push i with probability ∝ exp(5 × its chance of reaching the bin); play data is uniform", why: "A noisy-rational demonstrator gives multimodal but sensible demos.", kind: "Our choice" },
      { where: "Lab · WAM coupling playground · couplings", source: "Learned models err in structured ways", page: "Each learned table is the exact table mixed with uniform noise; the mixing grows as action labels shrink, fastest for the policy, then joint and forward, then IDM, not at all for video", why: "Encodes the direction of the co-training results of UWM and Fast-WAM and the IDM-vs-world-model comparison of World Action Verifier, not their sizes.", kind: "Our choice" },
      { where: "Lab · WAM coupling playground · UWM dials", source: "UWM marginalizes a modality at diffusion timestep T and conditions on it at timestep 0", page: "The bench writes house τ (0 = noise, 1 = clean) and models an intermediate level as evidence that keeps the true value with probability τ", why: "One flow-time convention across the site; a discrete stand-in for partial noise.", kind: "Our choice" },
      { where: "Lab · WAM coupling playground · UWM dials", source: "UWM contrasts independent timesteps with PAD's shared schedule qualitatively", page: "Under shared τ, outputs are blended toward uniform by how far the sampling path lies from the trained diagonal", why: "A toy for untrained noise-level pairs, not a measured degradation.", kind: "Simplified" },
      { where: "Lab · WAM coupling playground · leakage", source: "P04 §5.2 describes leakage in words: a model that attends to the next frame can fail at inference", page: "The leaky head is the exact IDM; at readout the future token is a model sample with probability τ, else a random cell", why: "Shows the training-versus-deployment gap without a network.", kind: "Simplified" },
      { where: "Lab · WAM coupling playground · IDM test", source: "WoW-World-Eval executes IDM-decoded actions on a real robot over 9 tasks", page: "The bench decodes the push from the first motion of a toy video; sharpness and physical consistency are separate dials; the toy IDM misreads 10% of real videos", why: "The 10% matches the 90% replay accuracy WoW reports; the rest is our toy.", kind: "Simplified" },
    ],
    mount: mount
  });
})();
