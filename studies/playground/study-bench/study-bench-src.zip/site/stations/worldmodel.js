/* Lab station · World-model sandbox (topics 10, 12). Sources: P03 §4 (eq. 16–19), X3 §V-C–V-D, PlaNet, TD-MPC2, V-JEPA 2, DINO-WM, GPC, VLA-Reasoner, WMPO method cards.
   Toy: a pusher moves a round block toward a goal on a 60 × 40 cm table. The "learned" world model is the true pushing physics
   with two hand-built errors (it misses a share of the veer that fast pushes cause, and adds a small drift), set by one slider.
   Plan mode runs model-predictive control with five planners; imagination mode optimizes a small policy inside the model. */
(function () {
  "use strict";
  var RB = window.RB;

  var SIM = (function () {
    /* World units: centimeters on a 60 × 40 cm table. One control step moves the pusher at most AMAX. */
    var TW = 60, TH = 40, RB_ = 3, RP = 1.2, RR = RB_ + RP, AMAX = 1.5, T = 45, GR = 2.5, D2R = Math.PI / 180;
    var GOAL = [46, 26], B0 = [22, 20], P0 = [8, 12], GX = GOAL[0], GY = GOAL[1];
    var DEMO_SP = 0.5; /* demonstrations push at half the top speed: slow enough that the block never veers */
    var VS = 0.8, SLIP = 50 * D2R, NB = 15; /* real world: pushes faster than VS cm/step make the block veer by up to SLIP */
    function slipOf(v) { var f = (v - VS) / (AMAX - VS); return SLIP * (f <= 0 ? 0 : f >= 1 ? 1 : f); }
    function bin(v) { return Math.max(0, Math.min(NB - 1, Math.floor(v / AMAX * NB))); }
    /* model error. m = {bias, cov: Float64Array(NB) | null}; null = the real world. Returns [rotation (rad), gain] of the block's push displacement.
       The model knows a fraction of the real slip: 1 − bias·(1 − coverage), and adds a constant 8°·bias drift. */
    function know(v, m) { if (!m) return 1; var c = m.cov ? Math.min(1, m.cov[bin(v)]) : 0; return 1 - m.bias * (1 - c); }
    function errRot(v, m) { if (!m) return [slipOf(v), 1, 0]; var c = m.cov ? Math.min(1, m.cov[bin(v)]) : 0, b = m.bias * (1 - c); return [slipOf(v) * know(v, m), 1 + 0.1 * b, 8 * D2R * b]; }
    /* which way a fast push veers depends on where the block sits (a deterministic stand-in for unmodeled contact detail) */
    function hsign(x, y) { var h = Math.sin(Math.floor(x * 0.8) * 12.9898 + Math.floor(y * 0.8) * 78.233) * 43758.5453; return h - Math.floor(h) < 0.5 ? -1 : 1; }
    var OUT = new Float64Array(4);
    /* one step in place on scalars; writes OUT. Pusher moves by a (clipped), the block is pushed out of contact along the normal. */
    function step4(px, py, bx, by, ax, ay, m) {
      var n = Math.sqrt(ax * ax + ay * ay); if (n > AMAX) { ax = ax / n * AMAX; ay = ay / n * AMAX; }
      px += ax; py += ay; px = px < RP ? RP : px > TW - RP ? TW - RP : px; py = py < RP ? RP : py > TH - RP ? TH - RP : py;
      var dx = bx - px, dy = by - py, d = Math.sqrt(dx * dx + dy * dy);
      if (d < RR && d > 1e-6) {
        var pen = RR - d, nx = dx / d, ny = dy / d, mx = pen * nx, my = pen * ny;
        if (true) { var e = errRot(n > AMAX ? AMAX : n, m), sg = hsign(bx, by), c = Math.cos(sg * e[0] + e[2]) * e[1], s = Math.sin(sg * e[0] + e[2]) * e[1]; var tx = c * mx - s * my; my = s * mx + c * my; mx = tx; }
        bx += mx; by += my; bx = bx < RB_ ? RB_ : bx > TW - RB_ ? TW - RB_ : bx; by = by < RB_ ? RB_ : by > TH - RB_ ? TH - RB_ : by;
      }
      OUT[0] = px; OUT[1] = py; OUT[2] = bx; OUT[3] = by;
    }
    function step(s, a, m) { step4(s[0], s[1], s[2], s[3], a[0], a[1], m); return [OUT[0], OUT[1], OUT[2], OUT[3]]; }
    function dist(s) { var x = s[2] - GX, y = s[3] - GY; return Math.sqrt(x * x + y * y); }
    /* planning cost of an action sequence A (Float64Array, 2H) from s under model m: mean over the horizon of
       (block-to-goal distance + 0.3 × pusher-to-block gap) plus the final block-to-goal distance. keep=true also returns the trajectory. */
    function seqCost(s, A, m, keep) {
      var px = s[0], py = s[1], bx = s[2], by = s[3], H = A.length / 2, c = 0, tr = keep ? [s] : null;
      for (var k = 0; k < H; k++) {
        step4(px, py, bx, by, A[2 * k], A[2 * k + 1], m); px = OUT[0]; py = OUT[1]; bx = OUT[2]; by = OUT[3];
        var gx = bx - GX, gy = by - GY, qx = bx - px, qy = by - py, g = Math.sqrt(qx * qx + qy * qy) - RR;
        c += Math.sqrt(gx * gx + gy * gy) + (g > 0 ? 0.3 * g : 0);
        if (tr) tr.push([px, py, bx, by]);
      }
      c = c / H + Math.sqrt((bx - GX) * (bx - GX) + (by - GY) * (by - GY));
      return keep ? { c: c, tr: tr } : c;
    }
    /* scripted pushing policy (the "policy prior"): get behind the block, then push toward the goal direction rotated by delta at speed sp·AMAX */
    function prior(s, delta, sp) {
      var ux = GX - s[2], uy = GY - s[3], du = Math.sqrt(ux * ux + uy * uy);
      if (du < 0.8) return [0, 0];
      ux /= du; uy /= du;
      var c = Math.cos(delta), sn = Math.sin(delta), vx = c * ux - sn * uy, vy = sn * ux + c * uy;
      var wx = s[0] - s[2], wy = s[1] - s[3], back = -(wx * vx + wy * vy);
      var qx = s[2] - (RR - 0.3) * vx, qy = s[3] - (RR - 0.3) * vy, tx, ty;
      if (back < 0.55 * RR) { var side = (vx * wy - vy * wx) >= 0 ? 1 : -1, ox = -vy * side, oy = vx * side, L = RR + 2; tx = s[2] + L * (0.75 * ox - 0.66 * vx); ty = s[3] + L * (0.75 * oy - 0.66 * vy); }
      else if (Math.sqrt((s[0] - qx) * (s[0] - qx) + (s[1] - qy) * (s[1] - qy)) > 0.9 && back < RR - 0.2) { tx = qx; ty = qy; }
      else return [sp * AMAX * vx, sp * AMAX * vy];
      var ex = tx - s[0], ey = ty - s[1], de = Math.sqrt(ex * ex + ey * ey) || 1, v = Math.min(AMAX, de);
      return [ex / de * v, ey / de * v];
    }
    function priorSeq(s, H, m, delta, sp) { var A = new Float64Array(2 * H); for (var k = 0; k < H; k++) { var a = prior(s, delta, sp); A[2 * k] = a[0]; A[2 * k + 1] = a[1]; s = step(s, a, m); } return A; }
    function clipSeq(A) { for (var k = 0; k < A.length; k += 2) { var n = Math.sqrt(A[k] * A[k] + A[k + 1] * A[k + 1]); if (n > AMAX) { A[k] *= AMAX / n; A[k + 1] *= AMAX / n; } } return A; }
    var DIRS = []; for (var q = 0; q < 8; q++) DIRS.push([AMAX * Math.cos(q * Math.PI / 4), AMAX * Math.sin(q * Math.PI / 4)]);
    /* planners. o: {planner, H, N, I, m, warm (Float64Array or null)}. Every planner spends about N × I imagined sequences of length H. */
    function plan(s, o, R) {
      var H = o.H, N = o.N, I = o.I, m = o.m, calls = 0, best = null, bestC = Infinity, cands = [], p = o.planner, i, k;
      function consider(A) { var c = seqCost(s, A, m); calls += H; if (c < bestC) { bestC = c; best = A; } return c; }
      if (p === "prior") { best = priorSeq(s, H, m, 0, DEMO_SP); return { plan: best, cost: seqCost(s, best, m), cands: [], calls: 0 }; }
      if (p === "shoot") {
        for (i = 0; i < N * I; i++) { var A = new Float64Array(2 * H); for (k = 0; k < 2 * H; k++) A[k] = AMAX * 0.8 * R.normal(); consider(clipSeq(A)); if (cands.length < 16) cands.push(A); }
      } else if (p === "rerank") {
        for (i = 0; i < N * I; i++) { var B = priorSeq(s, H, m, 25 * D2R * R.normal(), 0.45 + 0.55 * R()); consider(B); if (cands.length < 16) cands.push(B); }
      } else if (p === "cem" || p === "mppi") {
        var mean = new Float64Array(2 * H), sd = new Float64Array(2 * H), K = Math.max(2, Math.round(N / 10));
        if (o.warm && o.warm.length === 2 * H) mean.set(o.warm);
        sd.fill(AMAX * 0.8);
        for (var it = 0; it < I; it++) {
          var pop = [];
          for (var n = 0; n < N; n++) { var C = new Float64Array(2 * H); for (k = 0; k < 2 * H; k++) C[k] = mean[k] + sd[k] * R.normal(); clipSeq(C); pop.push({ a: C, c: consider(C) }); }
          if (it === I - 1) cands = pop.slice(0, 16).map(function (x) { return x.a; });
          var w;
          if (p === "cem") { pop.sort(function (x, y) { return x.c - y.c; }); pop = pop.slice(0, K); w = pop.map(function () { return 1 / K; }); }
          else {
            var cmin = Infinity, cmean = 0; pop.forEach(function (x) { cmin = Math.min(cmin, x.c); cmean += x.c / N; });
            var lam = 0.5 * Math.max(1e-3, cmean - cmin), Z = 0; w = pop.map(function (x) { var e = Math.exp(-(x.c - cmin) / lam); Z += e; return e; }); w = w.map(function (e) { return e / Z; });
          }
          for (k = 0; k < 2 * H; k++) {
            var mu = 0, vr = 0, j;
            for (j = 0; j < pop.length; j++) mu += w[j] * pop[j].a[k];
            for (j = 0; j < pop.length; j++) vr += w[j] * (pop[j].a[k] - mu) * (pop[j].a[k] - mu);
            mean[k] = mu; sd[k] = Math.max(0.05, Math.sqrt(vr));
          }
        }
        consider(clipSeq(Float64Array.from(mean)));
      } else if (p === "mcts") {
        /* UCT over 8 push directions; each simulation descends the tree, expands one node and finishes with a random rollout to depth H */
        var root = { s: s, n: 0, w: 0, ch: null, d: 0, c: 0 }, sims = Math.min(3000, N * I);
        for (var si = 0; si < sims; si++) {
          var node = root, path = [root], acc = 0;
          while (node.ch && node.d < H) {
            var bu = -Infinity, pick = null;
            for (var ci = 0; ci < 8; ci++) { var ch = node.ch[ci], u = ch.n ? -ch.w / ch.n / 10 + 1.2 * Math.sqrt(Math.log(node.n + 1) / ch.n) : Infinity; if (u > bu) { bu = u; pick = ch; } }
            node = pick; path.push(node);
          }
          if (node.d < H && !node.ch) {
            node.ch = DIRS.map(function (a, ai) { var ns = step(node.s, a, m), g = Math.max(0, Math.sqrt((ns[2] - ns[0]) * (ns[2] - ns[0]) + (ns[3] - ns[1]) * (ns[3] - ns[1])) - RR); calls++; return { s: ns, a: ai, n: 0, w: 0, ch: null, d: node.d + 1, c: dist(ns) + 0.3 * g }; });
            node = node.ch[R.int(8)]; path.push(node);
          }
          for (k = 1; k < path.length; k++) acc += path[k].c;
          var rs = node.s, dd = node.d;
          if (dd < H) { var tail = new Float64Array(2 * (H - dd)); for (k = 0; k < H - dd; k++) { var dr = DIRS[R.int(8)]; tail[2 * k] = dr[0]; tail[2 * k + 1] = dr[1]; } var tc = seqCost(rs, tail, m, true); calls += H - dd; rs = tc.tr[tc.tr.length - 1]; acc += (tc.c - dist(rs)) * (H - dd); }
          var val = acc / H + dist(rs);
          for (k = 0; k < path.length; k++) { path[k].n++; path[k].w += val; }
        }
        var acts = [], nd = root;
        while (nd.ch) { var bb = null; nd.ch.forEach(function (x) { if (!bb || x.n > bb.n) bb = x; }); if (!bb.n) break; acts.push(DIRS[bb.a]); nd = bb; }
        best = new Float64Array(2 * H); acts.forEach(function (a, ai) { if (ai < H) { best[2 * ai] = a[0]; best[2 * ai + 1] = a[1]; } });
        bestC = seqCost(s, best, m);
        if (root.ch) root.ch.forEach(function (x) { if (x.n) { var A1 = new Float64Array(2); A1[0] = DIRS[x.a][0]; A1[1] = DIRS[x.a][1]; cands.push(A1); } });
      }
      return { plan: best, cost: bestC, cands: cands, calls: calls };
    }
    /* one episode of model-predictive control in the real world, planning in the model.
       o: {planner, H, N, I, bias, every:"1"|"half"|"H", seed, keep, jitter}. Task cost = mean block-to-goal distance over the episode. */
    function episode(o) {
      var R = RB.rng(o.seed), m = { bias: o.bias, cov: null }, s = [P0[0], P0[1], B0[0], B0[1]];
      if (o.jitter) { s[2] += (R() - 0.5) * 3; s[3] += (R() - 0.5) * 3; }
      var xs = [s], queue = [], warm = null, calls = 0, dec = [], cost = 0;
      for (var t = 0; t < T; t++) {
        if (!queue.length) {
          var r = plan(s, { planner: o.planner, H: o.H, N: o.N, I: o.I, m: m, warm: warm }, R), H = o.H;
          calls += r.calls;
          var run = o.every === "H" ? H : o.every === "half" ? Math.ceil(H / 2) : 1;
          for (var k = 0; k < run; k++) queue.push([r.plan[2 * k], r.plan[2 * k + 1]]);
          warm = new Float64Array(2 * H); warm.set(r.plan.subarray(2 * run));
          if (o.keep) dec.push({ t: t, s: s, plan: r.plan, pred: r.cost, im: seqCost(s, r.plan, m, true).tr, re: seqCost(s, r.plan, null, true).tr,
            cands: r.cands.map(function (A) { return seqCost(s, A, m, true).tr; }) });
        }
        s = step(s, queue.shift(), null); xs.push(s); cost += dist(s);
      }
      var fd = dist(s);
      return { xs: xs, dec: dec, final: fd, cost: cost / T, ok: fd < GR, calls: calls };
    }
    /* imagination RL: the policy is the scripted pusher with parameters θ = (delta, speed); J = mean block-to-goal distance over an episode */
    function polRoll(th, m) { var s = [P0[0], P0[1], B0[0], B0[1]], c = 0, tr = [s]; for (var t = 0; t < T; t++) { s = step(s, prior(s, th[0], th[1]), m); c += dist(s); tr.push(s); } return { c: c / T, tr: tr, final: dist(s) }; }
    /* one policy update in imagination: try 6 antithetic perturbations, move halfway toward the best one if it beats the current policy */
    function esUpdate(th, m, R) {
      var bc = polRoll(th, m).c, best = null;
      for (var i = 0; i < 6; i++) {
        var e0 = 8 * D2R * R.normal(), e1 = 0.1 * R.normal();
        for (var sg = -1; sg <= 1; sg += 2) { var c2 = [th[0] + sg * e0, Math.max(0.2, Math.min(1, th[1] + sg * e1))], v = polRoll(c2, m).c; if (v < bc) { bc = v; best = c2; } }
      }
      return best ? [th[0] + 0.5 * (best[0] - th[0]), th[1] + 0.5 * (best[1] - th[1])] : th.slice();
    }
    /* co-evolution (P03 eq. 19): refit the model on real rollouts — coverage grows around the push directions the real block moved in */
    function addCov(m, tr) {
      if (!m.cov) m.cov = new Float64Array(NB);
      for (var i = 1; i < tr.length; i++) { var a = tr[i], p = tr[i - 1], mx = a[2] - p[2], my = a[3] - p[3]; if (mx * mx + my * my < 0.0025) continue; var v = Math.sqrt((a[0] - p[0]) * (a[0] - p[0]) + (a[1] - p[1]) * (a[1] - p[1])), k = bin(v); for (var j = -1; j <= 1; j++) if (k + j >= 0 && k + j < NB) m.cov[k + j] += j ? 0.06 : 0.12; }
    }
    return { step: step, plan: plan, episode: episode, polRoll: polRoll, esUpdate: esUpdate, addCov: addCov, errRot: errRot, slipOf: slipOf, know: know, bin: bin, VS: VS, dist: dist, seqCost: seqCost, priorSeq: priorSeq,
      DEMO_SP: DEMO_SP, SLIP: SLIP, TW: TW, TH: TH, RB: RB_, RP: RP, AMAX: AMAX, T: T, GR: GR, GOAL: GOAL, B0: B0, P0: P0, D2R: D2R, NB: NB };
  })();

  /* ================= station UI ================= */
  var PLANNERS = [
    { value: "shoot", label: "Random shooting" }, { value: "cem", label: "CEM" }, { value: "mppi", label: "MPPI" },
    { value: "rerank", label: "Rerank" }, { value: "mcts", label: "MCTS" }, { value: "prior", label: "Prior only" }
  ];
  var P_NAME = { shoot: "Random shooting", cem: "Cross-entropy method", mppi: "MPPI", rerank: "Candidate rerank (GPC-style)", mcts: "Monte Carlo tree search", prior: "Policy prior only" };
  var P_NOTE = {
    shoot: "Random shooting samples N × I action sequences, imagines each one and keeps the best. PlaNet reports that best-of-random is worse than iterative CEM on every task (arXiv 1811.04551).",
    cem: "CEM samples N sequences, keeps the best tenth (the elites), refits a Gaussian to them and repeats I times. PlaNet plans this way with H = 12, 1,000 samples, 100 elites and 10 iterations.",
    mppi: "MPPI weights every sample by exp(−cost / temperature) instead of keeping hard elites. TD-MPC2 runs 6 iterations over 512 samples with horizon 3 and a learned terminal value (arXiv 2310.16828).",
    rerank: "The policy prior proposes N × I chunks (the scripted pusher, varied in aim and speed); the model imagines each and the best one runs. GPC ranks diffusion-policy proposals this way (arXiv 2502.00622).",
    mcts: "MCTS grows a search tree over eight push directions, balancing tried branches against untried ones. VLA-Reasoner searches this way with a world model and a value model (arXiv 2509.22643).",
    prior: "No model and no search: the scripted pusher at demonstration speed. It is slow but never veers, so model error cannot hurt it."
  };
  var PRESETS = {
    planet: { label: "PlaNet", planner: "cem", H: 12, N: 64, I: 10, every: "1" },
    tdmpc2: { label: "TD-MPC2", planner: "mppi", H: 3, N: 64, I: 6, every: "1" },
    vjepa: { label: "V-JEPA 2", planner: "cem", H: 1, N: 80, I: 10, every: "1" },
    gpc: { label: "GPC", planner: "rerank", H: 16, N: 32, I: 1, every: "half" },
    reasoner: { label: "VLA-Reasoner", planner: "mcts", H: 6, N: 32, I: 4, every: "1" }
  };
  var UPDATES = 30;

  function mount(api) {
    var id = api.id, sc = api.scene, ct = api.controls;
    var st = { mode: "plan", planner: "cem", H: 10, N: 32, I: 3, every: "1", bias: 0.6, seed: 3, coevo: false, preset: null };
    var dead = false, raf = 0, lastTs = 0, chartT = 0, running = false, done = false, stepped = 0, trained = 0;
    var ep = null;   /* live plan-mode episode */
    var im = null;   /* live imagination-mode run */

    sc.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Top view of a 60 by 40 centimeter table: a pusher, a round block and a goal ring"></canvas><figcaption class="sb-caption" id="' + id + '-cap"></figcaption></figure>' +
      '<div id="' + id + '-lg"></div>' +
      '<div class="rb-grid2"><div class="rb-stack">' +
        '<div id="' + id + '-ro-plan">' + RB.readouts([{ id: "cost", k: "Real task cost", u: "cm" }, { id: "final", k: "Final distance", u: "cm" }, { id: "gap", k: "Plan: imagined vs real", u: "cm apart" }, { id: "calls", k: "Imagined steps", u: "per decision" }, { id: "t", k: "Control step" }, { id: "ok", k: "Block in the goal" }]) + "</div>" +
        '<div id="' + id + '-ro-im">' + RB.readouts([{ id: "imc", k: "Imagined cost", u: "cm" }, { id: "rec", k: "Real cost", u: "cm" }, { id: "spd", k: "Push speed", u: "cm/step" }, { id: "aim", k: "Aim offset", u: "°" }, { id: "upd", k: "Policy updates" }, { id: "gapi", k: "Real − imagined", u: "cm" }]) + "</div>" +
        '<p class="sb-caption" id="' + id + '-note"></p></div>' +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-kn" aria-label="How far the block veers against push speed, in the real world and in the model"></canvas>' + RB.legend([{ c: "data-1", label: "real veer", kind: "line" }, { c: "accent", label: "model\'s veer", kind: "dash" }]) + '<figcaption class="sb-caption">Veer angle of a push against its speed. The model learned from slow demonstrations (shaded), so with model error it misses the veer of fast pushes.</figcaption></figure></div>' +
      '<div class="rb-grid2" id="' + id + '-charts-plan"><div id="' + id + '-chA"></div><div id="' + id + '-chB"></div></div>' +
      '<div id="' + id + '-charts-im"><div id="' + id + '-chC"></div></div>';

    ct.innerHTML =
      '<div class="rb-stack"><span class="sb-caption">Mode</span>' + RB.seg({ id: id + "-mode", label: "Mode", value: st.mode, options: [{ value: "plan", label: "Plan" }, { value: "imagine", label: "Imagine" }] }) + "</div>" +
      '<div class="rb-stack" data-plan><span class="sb-caption">Preset</span>' + RB.seg({ id: id + "-pre", label: "Preset", value: "", options: Object.keys(PRESETS).map(function (k) { return { value: k, label: PRESETS[k].label + "-like" }; }) }) + "</div>" +
      '<div class="rb-stack" data-plan><span class="sb-caption">Planner</span>' + RB.seg({ id: id + "-pl", label: "Planner", value: st.planner, options: PLANNERS }) + "</div>" +
      '<div class="rb-stack" data-plan><span class="sb-caption">Execution</span>' + RB.seg({ id: id + "-ex", label: "Execution", value: st.every, options: [{ value: "1", label: "Every step" }, { value: "half", label: "Half plan" }, { value: "H", label: "Whole plan" }] }) + "</div>" +
      RB.slider({ id: id + "-h", label: "Horizon H", min: 1, max: 20, step: 1, value: st.H }) +
      RB.slider({ id: id + "-n", label: "Candidates N", min: 8, max: 128, step: 8, value: st.N }) +
      RB.slider({ id: id + "-i", label: "Iterations I", min: 1, max: 10, step: 1, value: st.I }) +
      RB.slider({ id: id + "-b", label: "Model error", min: 0, max: 1, step: 0.05, value: st.bias, fmt: f2 }) +
      '<label class="sb-field" data-im><input type="checkbox" id="' + id + '-co"> <span>Refit the model on real rollouts</span></label>' +
      '<div class="sb-btn-row"><button class="sb-btn sb-btn--primary" type="button" id="' + id + '-run">Run episode ▶</button><button class="sb-btn" type="button" id="' + id + '-step">Step once</button><button class="sb-btn sb-btn--ghost" type="button" id="' + id + '-seed">New seed</button></div>';

    function f2(v) { return (+v).toFixed(2); }
    var q = function (s) { return sc.querySelector(s) || ct.querySelector(s); };
    var cv = q("#" + id + "-cv"), kn = q("#" + id + "-kn"), note = q("#" + id + "-note");
    var W = 600, H = 400, KW = 340, KH = 220, S = 10; /* 10 px per cm */
    var font = function (w, px, kind) { return w + " " + px + "px " + getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); };
    var X = function (x) { return x * S; }, Y = function (y) { return H - y * S; };

    /* ---------- drawing: the table ---------- */
    function path(c, pts, ix, iy) { c.beginPath(); pts.forEach(function (p, k) { if (k) c.lineTo(X(p[ix]), Y(p[iy])); else c.moveTo(X(p[ix]), Y(p[iy])); }); c.stroke(); }
    function disc(c, x, y, r, fill, stroke, dash) { c.beginPath(); c.arc(X(x), Y(y), r * S, 0, Math.PI * 2); if (fill) { c.fillStyle = fill; c.fill(); } if (stroke) { c.strokeStyle = stroke; c.lineWidth = 1.5; if (dash) c.setLineDash(dash); c.stroke(); c.setLineDash([]); } }
    function drawTable() {
      if (dead) return;
      var P = RB.pal(), c = RB.canvas(cv, W, H), i;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (i = 0; i <= W; i += 50) { c.beginPath(); c.moveTo(i, 0); c.lineTo(i, H); c.stroke(); }
      for (i = 0; i <= H; i += 50) { c.beginPath(); c.moveTo(0, i); c.lineTo(W, i); c.stroke(); }
      /* goal */
      disc(c, SIM.GOAL[0], SIM.GOAL[1], SIM.GR, P["good-soft"], P.good);
      c.fillStyle = P["ink-2"]; c.font = font("600", 12, "body"); c.textAlign = "center"; c.fillText("goal", X(SIM.GOAL[0]), Y(SIM.GOAL[1] + SIM.GR) - 6);
      var s = null, lab = "";
      if (st.mode === "plan" && ep) {
        var xs = ep.xs, n = xs.length - 1, d = ep.dec[ep.dec.length - 1];
        c.lineWidth = 1; c.globalAlpha = 0.9; c.strokeStyle = P["ink-3"]; c.setLineDash([2, 3]); path(c, xs, 0, 1); c.setLineDash([]);
        c.lineWidth = 2.5; c.strokeStyle = P["ink-2"]; c.globalAlpha = 1; path(c, xs, 2, 3);
        if (done && ep.dec.length) { d = ep.dec.reduce(function (x, y) { return gapOf(y) > gapOf(x) ? y : x; }); }
        if (d) {
          c.lineWidth = 1; c.strokeStyle = P["line-strong"]; c.globalAlpha = 0.7;
          d.cands.forEach(function (tr) { path(c, tr, 2, 3); });
          c.globalAlpha = 1; c.lineWidth = 2.5; c.strokeStyle = P["data-1"]; path(c, d.re, 2, 3);
          c.strokeStyle = P.accent; c.setLineDash([7, 5]); path(c, d.im, 2, 3); c.setLineDash([]);
          var e = d.im[d.im.length - 1]; disc(c, e[2], e[3], SIM.RB, null, P.accent, [4, 4]);
        }
        s = xs[n]; lab = "t = " + n + " of " + SIM.T + (done && d ? " · shown: plan from t = " + d.t + ", the largest split" : "");
      } else if (st.mode === "imagine" && im) {
        var a = im.imTr, b = im.reTr;
        c.lineWidth = 1; c.strokeStyle = P["ink-3"]; c.setLineDash([2, 3]); path(c, b, 0, 1); c.setLineDash([]);
        c.lineWidth = 2.5; c.strokeStyle = P["data-1"]; path(c, b, 2, 3);
        c.strokeStyle = P.accent; c.setLineDash([7, 5]); path(c, a, 2, 3); c.setLineDash([]);
        var ea = a[a.length - 1]; disc(c, ea[2], ea[3], SIM.RB, null, P.accent, [4, 4]);
        s = b[b.length - 1]; lab = "update " + im.u + " of " + UPDATES;
      }
      if (!s) s = [SIM.P0[0], SIM.P0[1], SIM.B0[0], SIM.B0[1]];
      disc(c, s[2], s[3], SIM.RB, P["surface-strong"], P["line-strong"]);
      c.fillStyle = P["ink-2"]; c.font = font("500", 11, "mono"); c.textAlign = "center"; c.fillText("block", X(s[2]), Y(s[3]) + 4);
      disc(c, s[0], s[1], SIM.RP, P.ink, null);
      disc(c, SIM.B0[0], SIM.B0[1], SIM.RB, null, P["ink-3"], [2, 3]);
      c.textAlign = "left"; c.fillStyle = P["ink-3"]; c.font = font("500", 12, "mono"); c.fillText(lab, 10, 18);
      c.textAlign = "right"; c.fillText("60 × 40 cm", W - 10, 18); c.textAlign = "left";
    }

    /* ---------- drawing: what the model knows (veer angle vs push speed) ---------- */
    function drawKnow() {
      if (dead) return;
      var P = RB.pal(), c = RB.canvas(kn, KW, KH), L = 52, Rm = 16, T0 = 28, B = 40;
      var sx = function (v) { return L + v / SIM.AMAX * (KW - L - Rm); }, sy = function (a) { return KH - B - a / 60 * (KH - B - T0); };
      c.fillStyle = P.surface; c.fillRect(0, 0, KW, KH);
      c.fillStyle = P["accent-soft"]; c.fillRect(sx(0), T0, sx(SIM.AMAX * SIM.DEMO_SP) - sx(0), KH - B - T0);
      c.fillStyle = P["ink-2"]; c.font = font("500", 12, "mono"); c.fillText("demos", sx(0) + 6, T0 + 16);
      c.strokeStyle = P["line-strong"]; c.lineWidth = 1; c.beginPath(); c.moveTo(L, T0); c.lineTo(L, KH - B); c.lineTo(KW - Rm, KH - B); c.stroke();
      c.textAlign = "center"; [0, 0.5, 1, 1.5].forEach(function (v) { c.fillText(String(v), sx(v), KH - B + 16); });
      c.fillText("push speed (cm/step)", (L + KW - Rm) / 2, KH - 6);
      c.textAlign = "right"; [0, 20, 40, 60].forEach(function (a) { c.fillText(a + "°", L - 6, sy(a) + 4); });
      var m = modelNow(), pts = [];
      for (var v = 0; v <= SIM.AMAX + 1e-9; v += SIM.AMAX / 60) pts.push(v);
      c.lineWidth = 2.5; c.strokeStyle = P["data-1"]; c.beginPath(); pts.forEach(function (v, k) { var y = sy(SIM.slipOf(v) / SIM.D2R); if (k) c.lineTo(sx(v), y); else c.moveTo(sx(v), y); }); c.stroke();
      c.strokeStyle = P.accent; c.setLineDash([7, 5]); c.beginPath(); pts.forEach(function (v, k) { var y = sy(SIM.slipOf(v) * SIM.know(v, m) / SIM.D2R); if (k) c.lineTo(sx(v), y); else c.moveTo(sx(v), y); }); c.stroke(); c.setLineDash([]);
      var spd = st.mode === "imagine" && im ? im.th[1] * SIM.AMAX : null;
      if (spd != null) { c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.moveTo(sx(spd), T0); c.lineTo(sx(spd), KH - B); c.stroke(); c.textAlign = "center"; c.fillStyle = P.ink; c.font = font("600", 12, "body"); c.fillText("policy", Math.min(sx(spd), KW - 30), T0 - 8); }
      c.textAlign = "left"; c.font = font("600", 12, "body"); c.fillStyle = P["ink-2"]; c.fillText("veer angle", 8, 16);
    }
    function gapOf(d) { var a = d.im[d.im.length - 1], b = d.re[d.re.length - 1]; return Math.hypot(a[2] - b[2], a[3] - b[3]); }
    function modelNow() { return st.mode === "imagine" && im ? im.m : { bias: st.bias, cov: null }; }

    /* ---------- plan mode ---------- */
    function newEpisode() {
      var R = RB.rng(st.seed), m = { bias: st.bias, cov: null };
      ep = { R: R, m: m, xs: [[SIM.P0[0], SIM.P0[1], SIM.B0[0], SIM.B0[1]]], acts: [], dec: [], queue: [], warm: null, calls: 0, cost: 0 };
      done = false;
    }
    function tick() {
      /* one control step: plan if the queue is empty, then act in the real world */
      var s = ep.xs[ep.xs.length - 1], t = ep.xs.length - 1;
      if (t >= SIM.T) return false;
      if (!ep.queue.length) {
        var r = SIM.plan(s, { planner: st.planner, H: st.H, N: st.N, I: st.I, m: ep.m, warm: ep.warm }, ep.R);
        var run = st.every === "H" ? st.H : st.every === "half" ? Math.ceil(st.H / 2) : 1;
        for (var k = 0; k < run; k++) ep.queue.push([r.plan[2 * k], r.plan[2 * k + 1]]);
        ep.warm = new Float64Array(2 * st.H); ep.warm.set(r.plan.subarray(2 * run));
        ep.lastCalls = r.calls;
        ep.dec.push({ t: t, s: s, plan: r.plan, im: SIM.seqCost(s, r.plan, ep.m, true).tr, re: SIM.seqCost(s, r.plan, null, true).tr, cands: r.cands.slice(0, 12).map(function (A) { return SIM.seqCost(s, A, ep.m, true).tr; }) });
      }
      var a = ep.queue.shift(); ep.acts.push(a);
      var s2 = SIM.step(s, a, null); ep.xs.push(s2); ep.cost += SIM.dist(s2);
      return ep.xs.length - 1 < SIM.T;
    }
    function planStats() {
      var n = ep.xs.length - 1, s = ep.xs[n], d = ep.dec[ep.dec.length - 1];
      if (done && ep.dec.length) d = ep.dec.reduce(function (x, y) { return gapOf(y) > gapOf(x) ? y : x; });
      RB.setRO(sc, "cost", n ? RB.fmt(ep.cost / n, 1) : "–"); RB.setRO(sc, "final", RB.fmt(SIM.dist(s), 1));
      if (d) { var a = d.im[d.im.length - 1], b = d.re[d.re.length - 1]; RB.setRO(sc, "gap", RB.fmt(Math.hypot(a[2] - b[2], a[3] - b[3]), 1)); } else RB.setRO(sc, "gap", "–");
      RB.setRO(sc, "calls", st.planner === "prior" ? "0" : String(ep.lastCalls || 0)); RB.setRO(sc, "t", n + " of " + SIM.T);
      RB.setRO(sc, "ok", n >= SIM.T ? (SIM.dist(s) < SIM.GR ? "Yes" : "No") : "–");
    }
    function finishPlan() {
      done = true; running = false; raf = 0; planStats(); drawTable();
      var n = ep.xs.length - 1;
      api.live("paused", "Done · task cost " + RB.fmt(ep.cost / n, 1) + " cm · final distance " + RB.fmt(SIM.dist(ep.xs[n]), 1) + " cm");
      clearTimeout(chartT); chartT = setTimeout(planCharts, 40);
    }
    function runPlanInstant() { newEpisode(); while (tick()) { /* run to the end */ } finishPlan(); }

    function planCharts() {
      if (dead || st.mode !== "plan" || !ep) return;
      /* A: replay the executed actions open-loop in the model; the gap to the real block grows with steps ahead */
      var Hn = st.H, errs = function (b) {
        var m = { bias: b, cov: null }, acc = []; for (var k = 0; k < Hn; k++) acc.push(0);
        ep.dec.forEach(function (d) { var a = SIM.seqCost(d.s, d.plan, m, true).tr; for (var k = 1; k <= Hn; k++) acc[k - 1] += Math.hypot(a[k][2] - d.re[k][2], a[k][3] - d.re[k][3]); });
        return acc.map(function (v, k) { return [k + 1, v / ep.dec.length]; });
      };
      var A = errs(st.bias), A2 = errs(st.bias / 2), top = Math.max(2, Math.ceil(Math.max.apply(null, A.map(function (p) { return p[1]; })) / 2) * 2);
      var hA = q("#" + id + "-chA"); hA.innerHTML = "";
      StudyBench.lineChart(hA, { title: "Prediction error against steps ahead", x: { label: "Steps ahead in the plan", min: 1, max: Math.max(2, Hn) }, y: { label: "Block error (cm)", min: 0, max: top, fmt: function (v) { return (+v).toFixed(1); } }, series: [{ name: "Your model", color: "data-1", points: A }, { name: "Half the error", color: "data-3", points: A2, dash: true }], height: 220, caption: "Our toy numbers: imagined minus real block position along each plan, averaged over the episode. Errors compound with every step the model predicts on its own." });
      /* B: real task cost against horizon, for this planner, with the model error set and with an exact model */
      var Hs = [1, 2, 4, 6, 8, 12, 16, 20], NI = Math.min(96, st.N * st.I), N2 = Math.min(st.N, NI), I2 = Math.max(1, Math.floor(NI / N2));
      var sweep = function (b) { return Hs.map(function (h) { return [h, SIM.episode({ planner: st.planner, H: h, N: N2, I: I2, bias: b, every: st.every, seed: 100 + st.seed }).cost]; }); };
      var B1 = sweep(st.bias), B0 = sweep(0), hi = Math.ceil(Math.max.apply(null, B1.concat(B0).map(function (p) { return p[1]; })) / 4) * 4;
      var hB = q("#" + id + "-chB"); hB.innerHTML = "";
      StudyBench.lineChart(hB, { title: "Real task cost against horizon", x: { label: "Horizon H", min: 1, max: 20, ticks: [1, 4, 8, 12, 16, 20] }, y: { label: "Real task cost (cm)", min: 8, max: Math.max(16, hi), fmt: function (v) { return (+v).toFixed(1); } }, series: [{ name: "Your model", color: "data-1", points: B1 }, { name: "Exact model", color: "data-4", points: B0, dash: true }], height: 220, caption: "Our toy numbers, one seeded episode per point, budget N × I ≤ 96. Longer horizons see further but give model error more steps to compound." });
    }

    /* ---------- imagination mode ---------- */
    function newImagine() {
      var m = { bias: st.bias, cov: null }, th = [0, 0.45];
      im = { m: m, th: th, u: 0, R: RB.rng(st.seed * 13 + 1), curve: [], imTr: null, reTr: null };
      evalIm();
    }
    function evalIm() {
      var a = SIM.polRoll(im.th, im.m), b = SIM.polRoll(im.th, null);
      im.imTr = a.tr; im.reTr = b.tr; im.imc = a.c; im.rec = b.c; im.curve.push([im.u, a.c, b.c]);
    }
    function imUpdate() {
      im.u++;
      im.th = SIM.esUpdate(im.th, im.m, im.R);
      if (st.coevo && im.u % 5 === 0) SIM.addCov(im.m, SIM.polRoll(im.th, null).tr);
      evalIm();
    }
    function imStats() {
      RB.setRO(sc, "imc", RB.fmt(im.imc, 1)); RB.setRO(sc, "rec", RB.fmt(im.rec, 1)); RB.setRO(sc, "spd", RB.fmt(im.th[1] * SIM.AMAX, 2));
      RB.setRO(sc, "aim", RB.fmt(im.th[0] / SIM.D2R, 0)); RB.setRO(sc, "upd", im.u + " of " + UPDATES); RB.setRO(sc, "gapi", RB.fmt(im.rec - im.imc, 1));
    }
    function imChart() {
      if (dead || st.mode !== "imagine" || !im) return;
      var h = q("#" + id + "-chC"); h.innerHTML = "";
      var pts = im.curve, hi = Math.max(22, Math.ceil(Math.max.apply(null, pts.map(function (p) { return Math.max(p[1], p[2]); })) / 4) * 4);
      StudyBench.lineChart(h, { title: "Imagined and real cost during training", x: { label: "Policy update", min: 0, max: UPDATES, ticks: [0, 10, 20, 30] }, y: { label: "Task cost (cm)", min: 8, max: hi, fmt: function (v) { return (+v).toFixed(1); } },
        series: [{ name: "Imagined", color: "accent", points: pts.map(function (p) { return [p[0], p[1]]; }), dash: true }, { name: "Real", color: "data-1", points: pts.map(function (p) { return [p[0], p[2]]; }) }], height: 230,
        caption: "Our toy numbers. Each update tries 12 policy variants in the model only. Lower is better: watch whether the real line follows the imagined one down." });
    }

    /* ---------- loop ---------- */
    function frame(ts) {
      if (dead) return;
      var dt = st.mode === "plan" ? 70 : 220;
      if (!lastTs || ts - lastTs >= dt) {
        lastTs = ts;
        if (st.mode === "plan") {
          var more = tick(); planStats(); drawTable();
          api.live("running", "Planning · step " + (ep.xs.length - 1) + " of " + SIM.T);
          if (!more) { finishPlan(); return; }
        } else {
          imUpdate(); imStats(); drawTable(); drawKnow();
          if (im.u % 3 === 0 || im.u >= UPDATES) imChart();
          api.live("running", "Training in imagination · update " + im.u);
          if (im.u >= UPDATES) { running = false; done = true; raf = 0; trained++; api.live("paused", "Done · imagined " + RB.fmt(im.imc, 1) + " cm, real " + RB.fmt(im.rec, 1) + " cm"); return; }
        }
      }
      raf = requestAnimationFrame(frame);
    }
    function stop() { if (raf) cancelAnimationFrame(raf); raf = 0; running = false; lastTs = 0; }
    function start() {
      if (dead) return;
      stop(); done = false;
      if (st.mode === "plan") { newEpisode(); planStats(); } else { newImagine(); imStats(); imChart(); }
      drawTable(); drawKnow();
      running = true; raf = requestAnimationFrame(frame);
    }
    function stepOnce() {
      if (dead) return;
      stop();
      if (st.mode === "plan") {
        if (!ep || done || ep.xs.length - 1 >= SIM.T) { newEpisode(); }
        var more = tick(); stepped++; planStats(); drawTable();
        if (!more) finishPlan(); else api.live("paused", "Paused · step " + (ep.xs.length - 1) + " of " + SIM.T);
      } else {
        if (!im || im.u >= UPDATES) newImagine();
        imUpdate(); stepped++; imStats(); drawTable(); drawKnow(); imChart();
        api.live("paused", "Paused · update " + im.u + " of " + UPDATES);
      }
    }

    /* ---------- mode switching and wiring ---------- */
    function applyMode() {
      var plan = st.mode === "plan";
      RB.$$("[data-plan]", ct).forEach(function (e) { e.style.display = plan ? "" : "none"; });
      RB.$$("[data-im]", ct).forEach(function (e) { e.style.display = plan ? "none" : ""; });
      ["-h", "-n", "-i"].forEach(function (k) { var e = q("#" + id + k); if (e) e.closest(".sb-field").style.display = plan ? "" : "none"; });
      q("#" + id + "-ro-plan").style.display = plan ? "" : "none"; q("#" + id + "-ro-im").style.display = plan ? "none" : "";
      q("#" + id + "-charts-plan").style.display = plan ? "" : "none"; q("#" + id + "-charts-im").style.display = plan ? "none" : "";
      q("#" + id + "-run").textContent = plan ? "Run episode ▶" : "Train policy ▶";
      q("#" + id + "-lg").innerHTML = plan ?
        RB.legend([{ c: "ink-2", label: "block so far", kind: "line" }, { c: "accent", label: "plan, as imagined", kind: "dash" }, { c: "data-1", label: "same plan, real", kind: "line" }, { c: "line-strong", label: "other candidates", kind: "line" }]) :
        RB.legend([{ c: "accent", label: "policy in imagination", kind: "dash" }, { c: "data-1", label: "same policy, real", kind: "line" }, { c: "ink-3", label: "pusher path", kind: "dash" }]);
      q("#" + id + "-cap").textContent = plan ?
        "Dashed accent = where the model says the current plan takes the block; solid = where the same actions really take it. Watch the two split after fast pushes." :
        "The policy is the scripted pusher with two knobs: push speed and aim offset. Dashed = its episode in the model, solid = the same policy on the real table.";
      note.textContent = plan ? P_NOTE[st.planner] : (st.coevo ? "Every five updates the model is refit on a real rollout of the current policy (P03 eq. 19), so it learns how fast pushes veer and the policy stops exploiting them." : "Training in imagination optimizes the policy against the model only (P03 eq. 17). The optimizer finds fast pushes, which the model wrongly treats as free.");
      api.meta(plan ? P_NAME[st.planner] + " · H " + st.H + " · N " + st.N + " · I " + st.I + " · seed " + st.seed : "Policy search in the model · " + UPDATES + " updates · seed " + st.seed);
      q("#" + id + "-i").disabled = st.planner === "prior";
      q("#" + id + "-n").disabled = st.planner === "prior";
    }
    function setSeg(sid, v) { RB.$$("#" + sid + " button", ct).forEach(function (b) { b.setAttribute("aria-pressed", b.value === v ? "true" : "false"); }); }
    function setSlider(sid, v, fmt) { var inp = q("#" + sid), out = ct.querySelector('[data-out="' + sid + '"]'); inp.value = v; if (out) out.textContent = fmt ? fmt(v) : v; }
    function bindSeg(sid, cb) { StudyBench.segmented(ct.querySelector("#" + sid), function (a, b) { cb(b ? b.value : (a && a.value) || a); }); }
    function manual() { st.preset = null; setSeg(id + "-pre", "__none"); }
    function changed() { applyMode(); if (st.mode === "plan") runPlanInstant(); else { stop(); newImagine(); imStats(); imChart(); drawTable(); drawKnow(); api.live("paused", "Ready · press Train policy"); } drawKnow(); }

    bindSeg(id + "-mode", function (v) { st.mode = v; stop(); changed(); });
    bindSeg(id + "-pre", function (v) {
      var p = PRESETS[v]; if (!p) return;
      st.planner = p.planner; st.H = p.H; st.N = p.N; st.I = p.I; st.every = p.every; st.preset = v;
      setSeg(id + "-pl", p.planner); setSeg(id + "-ex", p.every); setSlider(id + "-h", p.H); setSlider(id + "-n", p.N); setSlider(id + "-i", p.I);
      start(); applyMode();
    });
    bindSeg(id + "-pl", function (v) { st.planner = v; manual(); changed(); });
    bindSeg(id + "-ex", function (v) { st.every = v; manual(); changed(); });
    RB.bindSlider(ct, id + "-h", null, function (v) { st.H = v; manual(); changed(); });
    RB.bindSlider(ct, id + "-n", null, function (v) { st.N = v; manual(); changed(); });
    RB.bindSlider(ct, id + "-i", null, function (v) { st.I = v; manual(); changed(); });
    RB.bindSlider(ct, id + "-b", f2, function (v) { st.bias = v; changed(); });
    q("#" + id + "-co").addEventListener("change", function (e) { st.coevo = e.target.checked; changed(); });
    q("#" + id + "-run").addEventListener("click", start);
    q("#" + id + "-step").addEventListener("click", stepOnce);
    q("#" + id + "-seed").addEventListener("click", function () { st.seed++; if (st.mode === "plan") start(); else changed(); });
    RB.onTheme(function () { if (dead || !document.contains(cv)) return; drawTable(); drawKnow(); });

    /* side panel: the equations behind the two modes and reference numbers from the method cards */
    if (api.side) {
      api.side.style.minWidth = "0";
      api.side.innerHTML =
        RB.eqBlock({ name: "Policy optimization in imagination", ref: "P03 eq. 17", tex: "J(\\theta)=\\mathbb{E}_{\\class{sym-xi}{\\hat\\xi}\\sim(\\class{sym-pi}{\\pi_\\theta},\\,\\class{sym-pphi}{p_\\phi})}\\Big[\\sum_t \\class{sym-gamma}{\\gamma}^t\\,\\class{sym-r}{\\hat r_t}\\Big]",
          words: "The return is averaged over trajectories the policy produces inside the world model, not on the robot.",
          key: [{ glyph: "J(θ)", meaning: "expected imagined return" }, { sym: "xi", glyph: "ξ̂", meaning: "imagined trajectory" }, "pi", { sym: "pphi", glyph: "p_φ", meaning: "world model as simulator" }, "gamma", { sym: "r", glyph: "r̂ₜ", meaning: "predicted reward" }] }) +
        '<p class="sb-caption">P03 eq. 19 adds the fix this bench calls refitting: update the model on real and policy rollouts, then update the policy on the improved model (WoVR, World-VLA-Loop).</p>' +
        '<p class="rb-h5">Reference numbers</p>' + [
          ["PlaNet", "CEM with H = 12, 1,000 samples, 100 elites, 10 iterations", "arXiv 1811.04551"],
          ["TD-MPC2", "MPPI with H = 3, 512 samples, 64 elites, 6 iterations, temperature 0.5", "arXiv 2310.16828"],
          ["V-JEPA 2", "CEM with 800 samples, 10 iterations, top 10, horizon 1; about 16 s per action", "arXiv 2506.09985"],
          ["DINO-WM", "CEM with 100 samples × 10 iterations takes 53 s", "arXiv 2411.04983"],
          ["GPC", "Vision Push-T: Diffusion Policy 0.642, rerank of 100 proposals 0.739; MPPI or CEM without a policy prior score below 0.2", "arXiv 2502.00622"],
          ["WMPO", "GRPO inside a video world model: 33.6% → 47.1% mean success at 128 rollouts", "arXiv 2511.09515"],
          ["Robotic World Model", "Pretrained in simulation because training from scratch let the policy exploit model errors", "arXiv 2501.10100"]
        ].map(function (r) { return '<p class="sb-caption"><b>' + r[0] + "</b>: " + r[1] + ' <span class="sb-ref">' + r[2] + "</span></p>"; }).join("");
    }

    applyMode(); runPlanInstant(); drawKnow(); api.live("paused", "Ready · press Run episode");

    return {
      state: function () { return st; },
      demo: function () {
        var seg = function (sid, v) { return q("#" + id + "-" + sid + " [value=\"" + v + "\"]"); };
        var fin = function (a) { return a.until(function () { return done && !running; }, 15000); };
        return [
          { target: q("#" + id + "-pre"), title: "Plan with CEM", text: "The PlaNet-like preset plans 12 steps ahead with the cross-entropy method, replanning after every step. The dashed plan and the real outcome stay close.", do: function (a) { return a.click(seg("pre", "planet")).then(function () { return fin(a); }); }, task: "Choose the PlaNet-like preset", expect: function () { return st.preset === "planet"; } },
          { target: q("#" + id + "-b"), title: "Make the model wrong", text: "Raise the model error. The model now misses how fast pushes veer, so plans that look fast in imagination curve off on the real table.", do: function (a) { return a.set(q("#" + id + "-b"), 1).then(function () { return a.click(q("#" + id + "-run")); }).then(function () { return fin(a); }); }, task: "Set Model error to 0.9 or more", expect: function () { return st.bias >= 0.9; } },
          { target: q("#" + id + "-ex"), title: "Errors compound open loop", text: "Run the whole plan before replanning. Without feedback, each step's small error carries into the next; the left chart shows the gap growing with steps ahead.", do: function (a) { return a.click(seg("ex", "H")).then(function () { return a.click(q("#" + id + "-run")); }).then(function () { return fin(a); }); }, task: "Choose Whole plan execution", expect: function () { return st.every === "H"; } },
          { target: q("#" + id + "-pl"), title: "Let a policy propose", text: "Rerank samples chunks from the policy prior and keeps the one the model scores best, as GPC does. Good proposals need far less search.", do: function (a) { return a.click(seg("ex", "1")).then(function () { return a.click(seg("pl", "rerank")); }).then(function () { return a.click(q("#" + id + "-run")); }).then(function () { return fin(a); }); }, task: "Choose the Rerank planner", expect: function () { return st.planner === "rerank"; } },
          { target: q("#" + id + "-mode"), title: "Train in imagination", text: "Now optimize a policy inside the model. Imagined cost keeps falling while real cost stops improving and rises: the optimizer exploits the model's error.", do: function (a) { return a.click(seg("mode", "imagine")).then(function () { return a.click(q("#" + id + "-run")); }).then(function () { return fin(a); }); }, task: "Switch to Imagine mode and press Train policy", expect: function () { return st.mode === "imagine" && trained > 0; } },
          { target: q("#" + id + "-co"), title: "Refit the model", text: "Refitting on real rollouts every five updates teaches the model how fast pushes veer. Imagined and real cost now fall together (P03 eq. 19).", do: function (a) { var cb = q("#" + id + "-co"); if (!cb.checked) cb.click(); return a.wait(200).then(function () { return a.click(q("#" + id + "-run")); }).then(function () { return fin(a); }); }, task: "Tick Refit the model on real rollouts", expect: function () { return st.coevo; } },
          { target: q("#" + id + "-mode"), title: "Your turn", text: "Back in planning mode, compare Random shooting and MPPI at the same budget, then open the Planners race on the Compare page." }
        ];
      },
      destroy: function () { dead = true; stop(); clearTimeout(chartT); }
    };
  }


  RB.station({
    id: "worldmodel", name: "World-model sandbox", sub: "10 · 12",
    refs: ["P03 §4, eq. 16–19", "X3 §V-C, V-D", "GPC, arXiv 2502.00622"], prov: "Simplified: toy push world",
    summary: "Plan a block push inside a learned model with five planners, or train a policy entirely in imagination. Set how wrong the model is and watch imagined and real outcomes split.",
    notice: [
      "Replanning every step hides much of the model's error; running whole plans lets it compound.",
      "Search optimizes against the model, so it also finds the model's mistakes (X3 §V-C).",
      "A good policy prior needs far less search than sampling from scratch, as in GPC.",
      "Training in imagination drives imagined cost down while real cost rises: simulator exploitation (X3 §V-D).",
      "Refitting the model on real rollouts closes the gap (P03 eq. 19)."
    ],
    card: "Plan a block push inside a biased world model, then train in imagination and watch real cost rise.",
    terms: {
      "random-shooting": { name: "random shooting", aliases: ["best-of-N planning"], group: "world", scene: "system", focus: ["planner", "world-model"], look: "Many random plans, keep the best", def: "Planning by sampling many action sequences, imagining each with the model and executing the best one, without refining the sampling distribution.", note: "Easy to implement but wasteful: PlaNet found best-of-1,000 random sequences worse than iterative CEM on every task.", ref: "arXiv 1811.04551", uses: [] },
      "model-predictive-path-integral": { name: "model predictive path integral", aliases: ["MPPI"], group: "world", scene: "system", focus: ["planner", "world-model"], look: "Cost-weighted average of sampled plans", def: "A sampling planner that refits its action distribution as an average of sampled sequences weighted by exp(−cost / temperature), iterating a few times per control step.", note: "Unlike CEM it has no hard elite cut; TD-MPC2 combines both, weighting its top 64 samples.", ref: "arXiv 2310.16828", uses: ["random-shooting"] },
      "monte-carlo-tree-search": { name: "Monte Carlo tree search", aliases: ["MCTS"], group: "world", scene: "system", focus: ["planner", "world-model"], look: "A search tree over imagined futures", def: "Search that grows a tree of action choices, simulating futures with a model and balancing well-scored branches against rarely tried ones.", note: "It needs discrete choices; VLA-Reasoner seeds its branches with the policy's own actions.", ref: "arXiv 2509.22643 · X3 §V-C", uses: [] }
    },
    ledger: [
      { where: "Lab · World-model sandbox", source: "Real world models are learned video or latent predictors trained on robot data", page: "The model is the true pushing physics with two hand-built errors: it misses a share of the veer of fast pushes and adds a small drift", why: "Makes the model's error visible and adjustable with one slider.", kind: "Simplified" },
      { where: "Lab · World-model sandbox", source: "X3 §V-D and P03 §4.1 describe simulator exploitation in general terms", page: "The exploit is concrete: demonstrations push slowly, so the model never saw fast pushes veer", why: "One clear, physical blind spot that an optimizer can find.", kind: "Our choice" },
      { where: "Lab · World-model sandbox", source: "PlaNet uses 1,000 samples, V-JEPA 2 800, TD-MPC2 512", page: "Presets use 64 or 80 samples with the papers' horizons and iteration counts", why: "Keeps each decision under a few milliseconds in the browser.", kind: "Simplified" },
      { where: "Lab · World-model sandbox", source: "TD-MPC2 bootstraps its short horizon with a learned terminal Q-value", page: "The planning cost adds the block's final distance to the goal, a hand-made terminal value", why: "Lets short horizons work without training a critic.", kind: "Our choice" },
      { where: "Lab · World-model sandbox", source: "GPC ranks proposals from a trained diffusion policy by a learned reward", page: "Rerank proposals come from a scripted pusher varied in aim and speed, scored by the planning cost", why: "A stand-in prior with the same role: good proposals, no search.", kind: "Simplified" },
      { where: "Lab · World-model sandbox", source: "P03 eq. 18 trains the policy with a PPO or GRPO clipped objective", page: "Training in imagination uses a two-parameter policy and a simple evolution-strategy update", why: "Shows the exploitation mechanism in milliseconds; the objective is still P03 eq. 17.", kind: "Simplified" },
      { where: "Lab · World-model sandbox", source: "P03 writes the simulator as p_ϕ and the imagined trajectory as τ̂", page: "The side panel writes p_φ and ξ̂", why: "House notation keeps τ for flow time.", kind: "Our choice" },
      { where: "Lab · World-model sandbox", source: "P03 lists eqs. 16–19 in §4.1; the station brief cites them under X3 §V", page: "The station cites P03 for the equations and X3 §V-C, V-D for the planning and exploitation risks", why: "X3 §V has no numbered equations for these roles.", kind: "Sources disagree" }
    ],
    mount: mount
  });
})();
