/* Interactive Lab · Failure detector and verifier lab (topics 21, 22). Sources: P14 §1, §4.2, §5.1, §6.3–6.4, Table 7;
   P13 §5.1.3–5.1.4; method cards: FAIL-Detect (2503.08558), SAFE (2506.09937), FIPER (2510.09459), Sentinel (2410.04640),
   V-GPS (2410.13816), RoboMonkey (2506.17811), FlowHijack (2604.09651), BadVLA (2505.16640).
   Four benches on toy models, all numbers drawn are computed here:
   Detect   – a single-pass novelty score on a pick-and-place path, thresholded by a constant or a time-varying conformal band.
   Select   – best-of-N on one grasp: a noisy VLM-style verifier, an offline critic with a blind spot, and the policy's own likelihood.
   Optimize – a two-parameter policy (real skill, shortcut share) trained by gradient ascent on a verifier that shortcuts can fool.
   Attack   – an exact three-mode flow field with a FlowHijack-style early-τ backdoor, and a velocity-norm monitor. */
(function () {
  "use strict";
  var RB = window.RB;
  var SID = "verifier";

  function font(kind) { return getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); }
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function pressSeg(root, id, v) { RB.$$("#" + id + " button", root).forEach(function (b) { var on = b.value === v; b.setAttribute("aria-pressed", on ? "true" : "false"); b.tabIndex = on ? 0 : -1; }); }
  function pct(v) { return v == null || isNaN(v) ? "–" : Math.round(v * 100) + "%"; }
  /* split-conformal quantile: the ⌈(n + 1)(1 − α)⌉-th smallest score, Infinity when that index exceeds n */
  function cpQuantile(vals, alpha) { var s = vals.slice().sort(function (a, b) { return a - b; }), n = s.length, k = Math.ceil((n + 1) * (1 - alpha)); return k > n ? Infinity : s[k - 1]; }
  function sig(x) { return 1 / (1 + Math.exp(-x)); }
  
  /* =================================================================================
     Detect: toy pick-and-place. The policy's observation embedding follows a demonstrated
     path m(u); successes scatter around it, more during the grasp. Score = squared distance
     to the path in units of S0, averaged over 3 steps (a stand-in for a one-pass density score).
     ================================================================================= */
  var T = 60, S0 = 0.02, GRID = 121, NCAL = 200, NT = 100, TG = 26;
  function mPath(u) { return [0.1 + 0.8 * u, 0.3 + 0.45 * Math.sin(Math.PI * u)]; }
  function nrm(u) { var d = [0.8, 0.45 * Math.PI * Math.cos(Math.PI * u)], L = Math.sqrt(d[0] * d[0] + d[1] * d[1]); return [-d[1] / L, d[0] / L]; }
  var TUBE = []; for (var gi = 0; gi < GRID; gi++) TUBE.push(mPath(gi / (GRID - 1)));
  function bump(t) { return Math.exp(-Math.pow((t - TG) / 6, 2)); }
  function tubeD2(p) { var best = 1e9; for (var g = 0; g < GRID; g++) { var dx = p[0] - TUBE[g][0], dy = p[1] - TUBE[g][1], d = dx * dx + dy * dy; if (d < best) best = d; } return best; }
  function detRollout(R, kind, shift) {
    var t0 = kind === "ok" ? null : 14 + R.int(31), rate = 0.0025 + 0.0025 * R(), side = R() < 0.5 ? -1 : 1, nz = [R.normal(), R.normal()];
    var pos = [], raw = [], S = [], vis = null;
    for (var t = 0; t <= T; t++) {
      var u = t / T, sd = S0 * (1 + 1.5 * bump(t)), c = mPath(u), n = nrm(u);
      if (kind === "stall" && t >= t0) { c = mPath(t0 / T); n = nrm(t0 / T); sd *= 0.7; }
      nz = [0.6 * nz[0] + 0.8 * R.normal(), 0.6 * nz[1] + 0.8 * R.normal()];
      var p = [c[0] + sd * nz[0], c[1] + sd * nz[1]];
      if (kind === "slip" && t >= t0) { var dv = side * rate * (t - t0); p[0] += dv * n[0]; p[1] += dv * n[1]; if (vis === null && Math.abs(dv) > 4 * S0) vis = t; }
      if (kind === "ok" && shift) { p[0] += shift * S0 * n[0]; p[1] += shift * S0 * n[1]; }
      pos.push(p); raw.push(tubeD2(p) / (S0 * S0));
      var a = 0, k = 0; for (var j = Math.max(0, t - 2); j <= t; j++) { a += raw[j]; k++; } S.push(a / k);
    }
    if (kind === "stall") vis = Math.min(T, t0 + 10);
    return { kind: kind, t0: t0, vis: vis, pos: pos, S: S };
  }
  var CAL = (function () { var R = RB.rng(101), a = []; for (var i = 0; i < NCAL; i++) a.push(detRollout(R, "ok", 0)); return a; })();
  function calibrate(band, alpha, M) {
    var cal = CAL.slice(0, M), thr = [], t;
    if (band === "const") { var g = cpQuantile(cal.map(function (r) { return Math.max.apply(null, r.S.slice(2)); }), alpha); for (t = 0; t <= T; t++) thr.push(g); return thr; }
    var h2 = Math.floor(M / 2), A = cal.slice(0, h2), B = cal.slice(h2), mu = [], sd = [];
    for (t = 0; t <= T; t++) {
      var m = 0; A.forEach(function (r) { m += r.S[t]; }); m /= A.length;
      var v = 0; A.forEach(function (r) { v += (r.S[t] - m) * (r.S[t] - m); }); v = Math.sqrt(v / Math.max(1, A.length - 1));
      mu.push(m); sd.push(Math.max(v, 0.1));
    }
    var h = cpQuantile(B.map(function (r) { var mx = -1e9; for (var t3 = 2; t3 <= T; t3++) mx = Math.max(mx, (r.S[t3] - mu[t3]) / sd[t3]); return mx; }), alpha);
    return mu.map(function (m, i) { return m + h * sd[i]; });
  }
  function firstAlarm(r, thr) { for (var t = 2; t <= T; t++) if (r.S[t] > thr[t]) return t; return null; }
  function detEval(test, thr) {
    var fa = 0, nOk = 0, caught = 0, nF = 0, delay = 0, early = 0;
    test.forEach(function (r) {
      r.alarm = firstAlarm(r, thr);
      if (r.kind === "ok") { nOk++; if (r.alarm !== null) fa++; }
      else { nF++; if (r.alarm !== null) { caught++; delay += Math.max(0, r.alarm - r.t0); if (r.alarm < r.vis) early++; } }
    });
    return { fpr: fa / nOk, tpr: caught / nF, delay: caught ? delay / caught : null, early: caught ? early / caught : null };
  }

  /* =================================================================================
     Select: one grasp, candidates from a Gaussian policy (cm). True success
     p(x) = exp(−|x|²/2σs²). Verifiers: VLM-style = p + noise; critic = p + a bump of
     overestimation far from the data (its blind spot); intrinsic = policy log-likelihood.
     ================================================================================= */
  var SP = 2.0, SS = 1.5, HUMP = [-4.2, 3.0], HA = 1.6, HW = 1.3, EPIS = 300, NMAX = 128;
  var SEL_PRE = { id: { mu: [0.4, 0.3], label: "In distribution" }, shift: { mu: [2.8, 1.8], label: "Shifted scene" } };
  var VER = [{ k: "vlm", name: "VLM verifier", c: "data-1" }, { k: "q", name: "Offline critic", c: "data-3" }, { k: "int", name: "Policy likelihood", c: "data-5" }, { k: "or", name: "True score", c: "ink-3" }];
  function pTrue(x) { return Math.exp(-(x[0] * x[0] + x[1] * x[1]) / (2 * SS * SS)); }
  function qErr(x) { var dx = x[0] - HUMP[0], dy = x[1] - HUMP[1]; return HA * Math.exp(-(dx * dx + dy * dy) / (2 * HW * HW)); }
  function selSim(pre, sv, seed) {
    var R = RB.rng(seed), mu = SEL_PRE[pre].mu, eps = [], acc = {}, NS = [1, 2, 4, 8, 16, 32, 64, 128];
    VER.forEach(function (v) { acc[v.k] = NS.map(function () { return 0; }); });
    for (var e = 0; e < EPIS; e++) {
      var C = [];
      for (var i = 0; i < NMAX; i++) {
        var x = [mu[0] + SP * R.normal(), mu[1] + SP * R.normal()], p = pTrue(x), dx = x[0] - mu[0], dy = x[1] - mu[1];
        C.push({ x: x, p: p, s: { vlm: p + sv * R.normal(), q: p + qErr(x) + 0.05 * R.normal(), int: -(dx * dx + dy * dy), or: p } });
      }
      if (e < 12) eps.push(C);
      VER.forEach(function (v) {
        var best = -1e9, bi = 0, ni = 0;
        for (var j = 0; j < NMAX; j++) { if (C[j].s[v.k] > best) { best = C[j].s[v.k]; bi = j; } if (j + 1 === NS[ni]) { acc[v.k][ni] += C[bi].p; ni++; } }
      });
    }
    VER.forEach(function (v) { acc[v.k] = acc[v.k].map(function (a) { return a / EPIS; }); });
    return { NS: NS, acc: acc, eps: eps, mu: mu };
  }
  function pickIdx(C, k, N) { var best = -1e9, bi = 0; for (var j = 0; j < N; j++) if (C[j].s[k] > best) { best = C[j].s[k]; bi = j; } return bi; }

  /* =================================================================================
     Optimize: policy θ = (g, h). g = real grasp skill, s = σ(8(g − 0.6)) is the chance a real
     grasp works. h = share of episodes where the policy takes a shortcut instead (hover so the
     object looks held). True success = (1 − h)s. The training verifier passes a shortcut
     episode with probability w; held-out panel verifiers with probability ρw.
     Gradient ascent, slow on g, fast on h, with an anchor β‖θ − θ₀‖².
     ================================================================================= */
  var ITER = 150, TH0 = [0.35, 0.05];
  function optS(g) { return sig(8 * (g - 0.6)); }
  function optTrue(g, h) { return (1 - h) * optS(g); }
  function optProxy(g, h, w) { return (1 - h) * optS(g) + h * w; }
  function optRun(w, rho, beta) {
    var g = TH0[0], h = TH0[1], path = [];
    for (var i = 0; i <= ITER; i++) {
      var pr = optProxy(g, h, w);
      path.push({ g: g, h: h, proxy: pr, panel: optProxy(g, h, w * rho), tru: optTrue(g, h), rej: pr > 0 ? h * w * (1 - rho) / pr : 0 });
      var e = 1e-4, dg = (optProxy(g + e, h, w) - optProxy(g - e, h, w)) / (2 * e), dh = (optProxy(g, h + e, w) - optProxy(g, h - e, w)) / (2 * e);
      dg -= 2 * beta * (g - TH0[0]); dh -= 2 * beta * (h - TH0[1]);
      g = RB.clamp(g + 0.006 * dg, 0, 1.2); h = RB.clamp(h + 0.05 * dh, 0, 1);
    }
    return path;
  }

  /* =================================================================================
     Attack: 2-D action space with three demonstrated modes (this observation asks for the bin).
     Exact flow velocity of the mode mixture (τ: 0 = noise, 1 = clean), K Euler steps.
     Triggered: for τ < τ0 the field points to the attacker's target instead: another demonstrated
     mode (context-aware) or a fixed pose outside the data. A filter rejects final actions far from
     every demonstrated mode; a speed monitor flags unusual flow speeds.
     ================================================================================= */
  var AS = 0.1, AK = 10, AR = 0.5;
  var AMODES = [{ m: [-1.5, 1.75], w: 0.96, name: "bin (asked for)" }, { m: [1.5, 1.75], w: 0.02, name: "shelf" }, { m: [1.75, -0.9], w: 0.02, name: "table edge" }];
  var APOSE = [-1.6, -1.2];
  function flowV(x, t, modes) {
    var sig2 = t * t * AS * AS + (1 - t) * (1 - t), lg = [], mx = -1e300;
    modes.forEach(function (c) { var d0 = x[0] - t * c.m[0], d1 = x[1] - t * c.m[1], l = Math.log(c.w) - (d0 * d0 + d1 * d1) / (2 * sig2); lg.push(l); if (l > mx) mx = l; });
    var rs = lg.map(function (l) { return Math.exp(l - mx); }), Z = rs.reduce(function (a, r) { return a + r; }, 0), v = [0, 0];
    modes.forEach(function (c, i) { var r = rs[i] / Z; for (var j = 0; j < 2; j++) { var d = x[j] - t * c.m[j], Ea = c.m[j] + t * AS * AS / sig2 * d, Ee = (1 - t) / sig2 * d; v[j] += r * (Ea - Ee); } });
    return v;
  }
  function tgtOf(kind) { return kind === "pose" ? APOSE : AMODES[2].m; }
  function aSample(R, trig, tau0, kind) {
    var x = [R.normal(), R.normal()], path = [x.slice()], norms = [], tg = [{ m: tgtOf(kind), w: 1 }];
    for (var k = 0; k < AK; k++) {
      var t = k / AK, v = trig && t < tau0 - 1e-9 ? flowV(x, t, tg) : flowV(x, t, AMODES);
      norms.push(Math.hypot(v[0], v[1]));
      x = [x[0] + v[0] / AK, x[1] + v[1] / AK]; path.push(x.slice());
    }
    var near = -1, nd = 1e9; AMODES.forEach(function (c, i) { var d = Math.hypot(x[0] - c.m[0], x[1] - c.m[1]); if (d < nd) { nd = d; near = i; } });
    var tgm = tgtOf(kind);
    return { x: x, path: path, norms: norms, mode: nd < AR ? near : -1, hit: Math.hypot(x[0] - tgm[0], x[1] - tgm[1]) < AR };
  }
  /* speed monitor, calibrated on benign samples: z-score of the flow speed per step, alarm on the max, conformal α = 0.05 */
  var ACAL = (function () {
    var R = RB.rng(707), n = 300, S = [];
    for (var i = 0; i < n; i++) S.push(aSample(R, false, 0, "mode").norms);
    var mu = [], sd = [];
    for (var k = 0; k < AK; k++) { var m = 0, v = 0; S.forEach(function (s) { m += s[k]; }); m /= n; S.forEach(function (s) { v += (s[k] - m) * (s[k] - m); }); mu.push(m); sd.push(Math.sqrt(v / (n - 1)) || 1); }
    return { mu: mu, sd: sd };
  })();
  function monScore(s) { var mx = -1e9; s.norms.forEach(function (v, k) { mx = Math.max(mx, Math.abs(v - ACAL.mu[k]) / ACAL.sd[k]); }); return mx; }
  var AMON = (function () { var R = RB.rng(909), sc = []; for (var i = 0; i < 300; i++) sc.push(monScore(aSample(R, false, 0, "mode"))); return cpQuantile(sc, 0.05); })();
  function atkSim(tau0, kind, seed, n) {
    var R = RB.rng(seed), R2 = RB.rng(seed + 17), ben = [], trg = [];
    for (var i = 0; i < n; i++) ben.push(aSample(R, false, tau0, kind));
    for (var j = 0; j < n; j++) trg.push(aSample(R2, true, tau0, kind));
    var f = function (arr, fn) { return arr.filter(fn).length / arr.length; };
    return {
      ben: ben, trg: trg,
      clean: f(ben, function (s) { return s.mode === 0; }), asr: f(trg, function (s) { return s.hit; }),
      asrF: f(trg, function (s) { return s.hit && s.mode >= 0; }),
      det: f(trg, function (s) { return monScore(s) > AMON; }), fa: f(ben, function (s) { return monScore(s) > AMON; }),
      filt: f(trg, function (s) { return s.mode < 0; })
    };
  }

  /* =================================================================================
     mount
     ================================================================================= */
  function mount(api) {
    var id = SID, scene = api.scene, ctl = api.controls;
    var st = {
      mode: "detect",
      band: "time", fkind: "slip", alpha: 0.05, M: 100, shift: 0, plays: 0,
      pre: "id", ver: "vlm", nexp: 3, sv: 0.25, ep: 0,
      w: 0.8, rho: 0.3, beta: 0, trained: false,
      tau0: 0.2, trig: true, tkind: "mode", aseed: 3
    };
    var raf = 0, chartT = 0, ro = null, lastW = 0, playT = null, playR = null, optShow = ITER, runs = { train: 0 };
    var det = null, sel = null, opt = null, atk = null, test = [];

    scene.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-cv" aria-label="Station scene"></canvas>' +
      '<div id="' + id + '-legend"></div><figcaption class="sb-caption" id="' + id + '-cap">–</figcaption></figure>' +
      '<div id="' + id + '-ro"></div><div id="' + id + '-chart"></div>';
    var MODES = [{ value: "detect", label: "Detect" }, { value: "select", label: "Select" }, { value: "optimize", label: "Optimize" }, { value: "attack", label: "Attack" }];
    ctl.innerHTML =
      '<div class="rb-stack"><div class="rb-row">' + RB.seg({ id: id + "-mode", label: "Bench", value: "detect", options: MODES }) + "</div>" +
      /* detect */
      '<div class="rb-row" data-grp="detect">' + RB.seg({ id: id + "-band", label: "Threshold", value: "time", options: [{ value: "const", label: "Constant" }, { value: "time", label: "Time-varying band" }] }) +
      RB.seg({ id: id + "-fk", label: "Failure type", value: "slip", options: [{ value: "slip", label: "Slip" }, { value: "stall", label: "Stall" }, { value: "mix", label: "Mixed" }] }) + "</div>" +
      '<div class="rb-row" data-grp="detect">' + RB.slider({ id: id + "-alpha", label: "Allowed false alarms α", min: 0.01, max: 0.3, step: 0.01, value: 0.05, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-m", label: "Calibration successes", min: 10, max: NCAL, step: 10, value: 100 }) +
      RB.slider({ id: id + "-shift", label: "Test shift (S₀)", min: 0, max: 2, step: 0.1, value: 0, fmt: function (v) { return (+v).toFixed(1); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-play">Play a rollout ▶</button></div>' +
      /* select */
      '<div class="rb-row" data-grp="select">' + RB.seg({ id: id + "-pre", label: "Scene", value: "id", options: [{ value: "id", label: "In distribution" }, { value: "shift", label: "Shifted scene" }] }) +
      RB.seg({ id: id + "-ver", label: "Verifier shown", value: "vlm", options: [{ value: "vlm", label: "VLM" }, { value: "q", label: "Critic" }, { value: "int", label: "Likelihood" }, { value: "or", label: "True score" }] }) + "</div>" +
      '<div class="rb-row" data-grp="select">' + RB.slider({ id: id + "-n", label: "Candidates N", min: 0, max: 7, step: 1, value: 3, fmt: function (v) { return String(Math.pow(2, v)); } }) +
      RB.slider({ id: id + "-sv", label: "VLM verifier noise", min: 0, max: 0.6, step: 0.05, value: 0.25, fmt: function (v) { return (+v).toFixed(2); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-next">Next episode ▶</button></div>' +
      /* optimize */
      '<div class="rb-row" data-grp="optimize">' + RB.slider({ id: id + "-w", label: "Verifier exploitability w", min: 0, max: 1, step: 0.05, value: 0.8, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-rho", label: "Panel shares the blind spot ρ", min: 0, max: 1, step: 0.05, value: 0.3, fmt: function (v) { return (+v).toFixed(2); } }) +
      RB.slider({ id: id + "-beta", label: "Anchor to start β", min: 0, max: 2, step: 0.1, value: 0, fmt: function (v) { return (+v).toFixed(1); } }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-train">Train ▶</button></div>' +
      /* attack */
      '<div class="rb-row" data-grp="attack">' + RB.slider({ id: id + "-tau0", label: "Backdoor window τ₀", min: 0, max: 1, step: 0.1, value: 0.2, fmt: function (v) { return (+v).toFixed(1); } }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-trig" checked> <span>Show trigger in the image</span></label>' +
      RB.seg({ id: id + "-tk", label: "Attacker's target", value: "mode", options: [{ value: "mode", label: "Demo mode" }, { value: "pose", label: "Fixed pose" }] }) +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-resamp">New samples ▶</button></div></div>';

    var cv = scene.querySelector("#" + id + "-cv"), cap = scene.querySelector("#" + id + "-cap"), lgHost = scene.querySelector("#" + id + "-legend"), roHost = scene.querySelector("#" + id + "-ro"), chartHost = scene.querySelector("#" + id + "-chart");

    /* ---------- per-mode static texts ---------- */
    var RO = {
      detect: [{ id: "fpr", k: "False alarms on new successes" }, { id: "promise", k: "Promised at most (α)" }, { id: "tpr", k: "Failures caught" }, { id: "delay", k: "Mean delay after onset", u: "steps" }, { id: "early", k: "Caught before visible" }, { id: "thrg", k: "Threshold at the grasp (t = 26)" }, { id: "thrp", k: "Threshold while placing (t = 50)" }],
      select: [{ id: "vlm", k: "VLM verifier" }, { id: "q", k: "Offline critic" }, { id: "int", k: "Policy likelihood" }, { id: "or", k: "True score (oracle)" }, { id: "pick", k: "This episode's pick succeeds with" }],
      optimize: [{ id: "dproxy", k: "Δproxy (training verifier)" }, { id: "dpanel", k: "Δpanel (held-out verifiers)" }, { id: "ratio", k: "Proxy gain that transfers" }, { id: "dtrue", k: "Δ true success" }, { id: "rej", k: "Passed runs the panel rejects" }],
      attack: [{ id: "asr", k: "Attack success (trigger)" }, { id: "clean", k: "Clean success (no trigger)" }, { id: "filt", k: "Off-mode filter rejects" }, { id: "asrf", k: "Attack success past the filter" }, { id: "det", k: "Speed monitor catches" }, { id: "fa", k: "Speed monitor false alarms" }]
    };
    var CAP = {
      detect: "Left: the path the gripper was taught, one test rollout per color. Right: each rollout's score over time; the thick line is the alarm threshold. Red dots are first alarms.",
      select: "Dots are the first N candidate grasps of one episode, darker where the shown verifier scores higher. The ring marks its pick. Green rings mark where grasps succeed.",
      optimize: "First map: how often the training verifier passes the policy. Second map: true success. Darker is higher. The line is training from the start dot; the policy climbs the left map.",
      attack: "Lines run from noise (τ = 0) to a final action (τ = 1), 30 of each kind. Dashed circles are demonstrated modes; this image asks for the bin."
    };
    var LEG = {
      detect: [{ c: "data-1", label: "successful rollout", kind: "line" }, { c: "data-3", label: "failed rollout", kind: "line" }, { c: "accent", label: "alarm threshold", kind: "line" }, { c: "bad", label: "first alarm", kind: "dot" }],
      select: [{ c: "data-1", label: "candidate (darker = higher score)", kind: "dot" }, { c: "good", label: "grasp succeeds", kind: "line" }, { c: "bad", label: "critic's blind spot", kind: "dash" }, { c: "accent", label: "pick", kind: "line" }],
      optimize: [{ c: "data-2", label: "training verifier score", kind: "area" }, { c: "data-1", label: "true success", kind: "area" }, { c: "accent", label: "training path", kind: "line" }],
      attack: [{ c: "data-1", label: "no trigger", kind: "line" }, { c: "data-3", label: "trigger present", kind: "line" }, { c: "ink-3", label: "demonstrated mode", kind: "dash" }, { c: "bad", label: "fixed-pose target", kind: "line" }]
    };
    var SIDE = {
      detect: function () {
        return '<p class="rb-muted" id="' + id + '-note">–</p>' +
          RB.eqBlock({ name: "Time-varying conformal band", ref: "FAIL-Detect · SAFE · P14 §5.1", tex: "\\text{alarm at } t \\iff \\class{sym-score}{S_t} > \\mu_t + h\\,\\sigma_t", words: "μₜ and σₜ come from half the calibration successes; h is the conformal quantile of the other half's worst moments.", key: ["score", { glyph: "μₜ", meaning: "mean success score at t" }, { glyph: "h", meaning: "conformal bandwidth" }, { glyph: "σₜ", meaning: "score spread at t" }] }) +
          '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
          '<li>FAIL-Detect uses α = 0.05; logpZO takes 0.04 s per step, STAC 1.45 s <span class="sb-ref">arXiv 2503.08558</span></li>' +
          '<li>SAFE adds under 1 ms; α between 0.05 and 0.2 worked well <span class="sb-ref">arXiv 2506.09937</span></li>' +
          '<li>FIPER, average of 5 environments: TPR 0.92, TNR 0.65 <span class="sb-ref">arXiv 2510.09459</span></li>' +
          '<li>The guarantee can fail when calibration and test tasks differ <span class="sb-ref">P14 §5.1</span></li></ul>';
      },
      select: function () {
        return '<p class="rb-muted" id="' + id + '-note">–</p>' +
          RB.eqBlock({ name: "Best-of-N selection", ref: "P14 §4.2", tex: "\\class{sym-a}{a_t} = \\arg\\max_{i \\le \\class{sym-N}{N}} \\class{sym-score}{S}\\big(\\class{sym-o}{o_t}, \\class{sym-l}{\\ell}, \\class{sym-a}{a^{i}_t}\\big)", words: "Sample N candidates from a frozen policy, score each, run the highest scorer.", key: ["a", "N", "score", "o", "l"] }) +
          '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
          '<li>RoboMonkey on SIMPLER: 47.5% against OpenVLA 38.5% <span class="sb-ref">arXiv 2506.17811</span></li>' +
          '<li>RoboMonkey: about 650 ms per step for 16 candidates on an H100 <span class="sb-ref">arXiv 2506.17811</span></li>' +
          '<li>V-GPS on a real WidowX: Octo-small 0.24 → 0.44 <span class="sb-ref">arXiv 2410.13816</span></li>' +
          '<li>V-GPS overhead: 1.28× at K = 10, 2.12× at K = 100 <span class="sb-ref">arXiv 2410.13816</span></li>' +
          '<li>A score used for search faces inputs where it is wrong <span class="sb-ref">P14 §7, Table 7</span></li></ul>';
      },
      optimize: function () {
        return '<p class="rb-muted" id="' + id + '-note">–</p>' +
          RB.eqBlock({ name: "Proxy gain that transfers", ref: "P14 §6.4", tex: "\\frac{\\Delta_{\\text{panel}}}{\\Delta_{\\text{proxy}}}, \\quad \\Delta = \\class{sym-score}{S}(\\text{last}) - \\class{sym-score}{S}(\\text{first})", words: "Score the first and last checkpoints with the training verifier and with a panel the policy never trained against.", key: ["score", { glyph: "Δ", meaning: "gain from first to last checkpoint" }] }) +
          '<h4 class="rb-h5">What the survey says</h4><ul class="rb-notice">' +
          '<li>One: the panel confirms the whole gain. Zero: none. Negative: the panel scores the policy lower <span class="sb-ref">P14 §6.4</span></li>' +
          '<li>Report both gains; the ratio is unstable when Δproxy is small <span class="sb-ref">P14 §6.4</span></li>' +
          '<li>Protocol: pass the rollouts the training verifier accepted to the panel and report the share it rejects <span class="sb-ref">P14 §6.3</span></li>' +
          '<li>Training against a detector changes the data it sees, so its conformal margin stops holding <span class="sb-ref">P14 §6.3</span></li>' +
          '<li>Every agreement rate the survey collected was measured on non-adversarial candidates <span class="sb-ref">P14 §7</span></li></ul>';
      },
      attack: function () {
        return '<p class="rb-muted" id="' + id + '-note">–</p>' +
          RB.eqBlock({ name: "Backdoor loss on early flow time", ref: "FlowHijack · P13 §5.1.3", tex: "\\mathcal{L}_{\\mathrm{BD}} = \\mathbb{E}_{\\class{sym-tau}{\\tau} < \\tau_0} \\big\\| \\class{sym-v}{v_\\theta}(\\class{sym-x-tau}{\\mathbf{a}^{\\tau}}, o^{+}, \\class{sym-tau}{\\tau}) - (A^{\\star} - \\class{sym-eps}{\\epsilon}) \\big\\|^2", words: "When the trigger is in the observation, the field points to the attacker's action, but only for early flow times.", key: ["tau", "v", "x-tau", { glyph: "o⁺", meaning: "observation with the trigger" }, { glyph: "A⋆", meaning: "attacker's target action" }, "eps", { glyph: "τ₀", meaning: "end of the injection window" }] }) +
          '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
          '<li>FlowHijack on LIBERO-Goal, attack success by window: 23.9% at τ₀ = 0.1, 57.4% at 0.2, 100% at 0.4 <span class="sb-ref">arXiv 2604.09651</span></li>' +
          '<li>Clean success 97.8% against π0\'s 95.8%; an adapted BadVLA reaches 11.2% attack success <span class="sb-ref">arXiv 2604.09651</span></li>' +
          '<li>After 10k clean LoRA fine-tuning steps, 67.7% attack success remains <span class="sb-ref">arXiv 2604.09651</span></li>' +
          '<li>A target-position filter at 0.1 m leaves 82.2% attack success for a small offset target, 17.8% for pose locking <span class="sb-ref">arXiv 2604.09651</span></li>' +
          '<li>BadVLA on OpenVLA, LIBERO: 98.3% attack success with a pixel-block trigger <span class="sb-ref">arXiv 2505.16640</span></li>' +
          '<li>Backdoor defenses for VLAs have yet to follow the attacks <span class="sb-ref">P13 §5.1.4</span></li></ul>';
      }
    };

    /* ---------- compute per mode ---------- */
    function testSet() {
      var R = RB.rng(55 + st.fkind.length * 13), R2 = RB.rng(77); test = [];
      for (var i = 0; i < NT; i++) test.push(detRollout(R, "ok", st.shift));
      for (var j = 0; j < NT; j++) test.push(detRollout(R2, st.fkind === "mix" ? (j % 2 ? "stall" : "slip") : st.fkind, 0));
    }
    function computeDetect(retest) {
      if (retest || !test.length) testSet();
      var thr = calibrate(st.band, st.alpha, st.M), r = detEval(test, thr);
      det = { thr: thr, r: r };
      RB.setRO(roHost, "fpr", pct(r.fpr)); RB.setRO(roHost, "promise", pct(st.alpha)); RB.setRO(roHost, "tpr", pct(r.tpr));
      RB.setRO(roHost, "delay", r.delay == null ? "–" : RB.fmt(r.delay, 1)); RB.setRO(roHost, "early", pct(r.early));
      RB.setRO(roHost, "thrg", isFinite(thr[TG]) ? RB.fmt(thr[TG], 1) : "∞"); RB.setRO(roHost, "thrp", isFinite(thr[50]) ? RB.fmt(thr[50], 1) : "∞");
      var n = note(), half = st.band === "const" ? st.M : st.M - Math.floor(st.M / 2);
      if (!isFinite(thr[TG])) n.textContent = "With " + half + " calibration scores, α = " + st.alpha.toFixed(2) + " asks for a quantile beyond the largest one, so the threshold is infinite and nothing alarms. Add successes or raise α.";
      else if (st.shift >= 0.8 && r.fpr > st.alpha) n.textContent = "The new successes no longer come from the calibration pool, so the promise of at most α false alarms breaks. SAFE reports the same risk on unseen tasks (P14 §5.1).";
      else if (st.fkind === "stall") n.textContent = "A stalled arm sits at a familiar state, so a novelty score stays low. The score describes the model, not the task: a familiar-looking failure can still look reliable (P14 §5.1).";
      else if (st.band === "const") n.textContent = "One threshold must clear the noisy grasp, so it sits high everywhere and catches later slips late or not at all." + (r.fpr > st.alpha ? " False alarms above α here are sampling noise: the promise holds on average over calibration sets." : "");
      else n.textContent = "The band is wide during the noisy grasp and narrow elsewhere, as in FAIL-Detect and SAFE. Its promise covers false alarms on successes only; missed failures have no bound.";
      api.meta("single-pass score · " + (st.band === "const" ? "constant threshold" : "conformal band") + " · " + (st.band === "const" ? st.M : half) + " calibration scores");
    }
    function chartDetect() {
      var al = [], a;
      for (a = 0.02; a <= 0.301; a += 0.02) al.push(+a.toFixed(2));
      var other = st.band === "const" ? "time" : "const", sF = [], sT = [], sO = [], sA = [];
      al.forEach(function (x) {
        var r = detEval(test, calibrate(st.band, x, st.M)), r2 = detEval(test, calibrate(other, x, st.M));
        sF.push([x, r.fpr]); sT.push([x, r.tpr]); sO.push([x, r2.tpr]); sA.push([x, x]);
      });
      detEval(test, det.thr); /* restore alarms for the drawing */
      chartHost.innerHTML = "";
      StudyBench.lineChart(chartHost, {
        title: "Detection against the allowed false-alarm rate", x: { label: "α", min: 0.02, max: 0.3 }, y: { label: "share of rollouts", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(1); } },
        series: [{ name: "caught (" + (st.band === "const" ? "constant" : "band") + ")", color: "data-1", points: sT }, { name: "caught (" + (other === "const" ? "constant" : "band") + ")", color: "data-2", points: sO, dash: true }, { name: "false alarms", color: "data-3", points: sF }, { name: "promise α", color: "ink-3", points: sA, dash: true }],
        directLabels: false,
        caption: "Our toy numbers, " + NT + " successes and " + NT + " failures. False alarms should stay on or below the dashed promise line while test successes match the calibration pool."
      });
    }
    function computeSelect() {
      sel = selSim(st.pre, st.sv, 11 + (st.pre === "shift" ? 5 : 0));
      var ni = st.nexp;
      VER.forEach(function (v) { RB.setRO(roHost, v.k, pct(sel.acc[v.k][ni])); });
      var C = sel.eps[st.ep % sel.eps.length], N = Math.pow(2, st.nexp), bi = pickIdx(C, st.ver, N);
      RB.setRO(roHost, "pick", pct(C[bi].p));
      var peakQ = 0; sel.acc.q.forEach(function (v, i) { if (v > sel.acc.q[peakQ]) peakQ = i; });
      var n = note();
      if (st.pre === "shift" && st.ver === "int") n.textContent = "The object moved, but the policy did not. Its own likelihood keeps picking the familiar grasp, however many candidates you draw: an intrinsic score describes the model (P14 §5.1).";
      else if (st.ver === "q" && st.nexp > peakQ) n.textContent = "Past N = " + Math.pow(2, peakQ) + ", more candidates make the critic worse: a larger search is more likely to find its blind spot, where it overrates grasps that miss (P14 Table 7).";
      else if (st.ver === "vlm") n.textContent = "A noisy verifier still helps: noise averages out over candidates. Raise the noise to see the gain shrink; RoboMonkey trains its verifier on 20M synthetic comparisons for this reason.";
      else n.textContent = "Each verifier ranks the same " + N + " candidates. The true score shows the best any verifier could do with this policy and this N.";
      api.meta(SEL_PRE[st.pre].label + " · N = " + N + " · " + EPIS + " episodes");
    }
    function chartSelect() {
      chartHost.innerHTML = "";
      StudyBench.lineChart(chartHost, {
        title: "Grasp success against the number of candidates", x: { label: "log₂ N (0 = 1, 7 = 128)", min: 0, max: 7, ticks: [0, 1, 2, 3, 4, 5, 6, 7] }, y: { label: "expected success", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(1); } },
        series: VER.map(function (v) { return { name: v.name, color: v.c, points: sel.acc[v.k].map(function (a, i) { return [i, a]; }), dash: v.k === "or" }; }),
        directLabels: false,
        caption: "Our toy numbers, " + EPIS + " episodes per point. Verifier curves stay below the dashed true score; a curve that falls with N marks a verifier that search can exploit."
      });
    }
    function computeOptimize() {
      opt = optRun(st.w, st.rho, st.beta);
      showOpt();
    }
    function showOpt() {
      var a = opt[0], b = opt[Math.min(optShow, ITER)], dp = b.proxy - a.proxy, dq = b.panel - a.panel, dt = b.tru - a.tru;
      RB.setRO(roHost, "dproxy", (dp >= 0 ? "+" : "") + RB.fmt(dp, 2)); RB.setRO(roHost, "dpanel", (dq >= 0 ? "+" : "") + RB.fmt(dq, 2));
      RB.setRO(roHost, "ratio", Math.abs(dp) < 0.02 ? "unstable (Δproxy ≈ 0)" : RB.fmt(dq / dp, 2));
      RB.setRO(roHost, "dtrue", (dt >= 0 ? "+" : "") + RB.fmt(dt, 2));
      RB.setRO(roHost, "rej", pct(b.rej));
      var n = note();
      if (st.w < 0.1) n.textContent = "The verifier cannot be fooled here, so the only way up is the real skill. It is slow to learn, but every gain is real: the ratio is near one.";
      else if (dt < 0) n.textContent = "The training verifier's score rises while true success falls: reward hacking. While the real skill is weak, the shortcut pays more, so the search finds it first (P14 §6.3).";
      else if (b.h > 0.2) n.textContent = "Part of the gain is real and part is the shortcut. The held-out panel confirms only the share it is not fooled on.";
      else n.textContent = "The shortcut never took over: either the real skill paid more first, or the anchor β held the policy near its start.";
      api.meta("iteration " + Math.min(optShow, ITER) + " of " + ITER + " · w = " + st.w.toFixed(2) + " · ρ = " + st.rho.toFixed(2));
    }
    function chartOptimize() {
      chartHost.innerHTML = "";
      var pts = function (k) { var o = []; for (var i = 0; i <= ITER; i += 5) o.push([i, opt[i][k]]); return o; };
      StudyBench.lineChart(chartHost, {
        title: "Scores during training", x: { label: "iteration", min: 0, max: ITER }, y: { label: "score", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(1); } },
        series: [{ name: "training verifier", color: "data-2", points: pts("proxy") }, { name: "held-out panel", color: "data-4", points: pts("panel") }, { name: "true success", color: "data-1", points: pts("tru") }],
        directLabels: false,
        caption: "Our toy numbers. The gap between the training verifier and true success is what a policy gains by exploiting the verifier."
      });
    }
    function computeAttack() {
      atk = atkSim(st.tau0, st.tkind, st.aseed, 300);
      RB.setRO(roHost, "asr", pct(atk.asr)); RB.setRO(roHost, "clean", pct(atk.clean)); RB.setRO(roHost, "det", pct(atk.det)); RB.setRO(roHost, "fa", pct(atk.fa)); RB.setRO(roHost, "filt", pct(atk.filt)); RB.setRO(roHost, "asrf", pct(atk.asrF));
      var n = note();
      if (st.tau0 < 0.05) n.textContent = "With no injection window the trigger does nothing: the clean field decides every sample.";
      else if (st.tkind === "pose") n.textContent = atk.asr < 0.5 ? "Outside the data, the clean field pulls the sample back to a demonstrated mode unless the backdoor steers the whole flow. Set τ₀ to 1." : "The sample reaches the fixed pose, but it lies off every demonstrated mode, so the filter rejects it. FlowHijack reports the same weakness for pose locking.";
      else if (atk.asr < 0.5) n.textContent = "A short window nudges early samples, but the clean field pulls most of them back to the asked-for mode. FlowHijack's ablation shows the same trend over τ₀.";
      else n.textContent = "The trigger decides the mode early; the clean field then finishes the motion. The result is an ordinary demonstrated action, so the off-mode filter passes it.";
      api.meta("K = " + AK + " Euler steps · τ₀ = " + st.tau0.toFixed(1) + " · monitor α = 0.05");
    }
    function chartAttack() {
      var a = [], c = [], d = [];
      for (var i = 0; i <= 10; i++) { var t0 = i / 10, r = atkSim(t0, st.tkind, st.aseed, 120); a.push([t0, r.asr]); c.push([t0, r.asrF]); d.push([t0, r.det]); }
      chartHost.innerHTML = "";
      StudyBench.lineChart(chartHost, {
        title: "Attack success against the injection window", x: { label: "τ₀", min: 0, max: 1 }, y: { label: "share of samples", min: 0, max: 1, fmt: function (v) { return (+v).toFixed(1); } },
        series: [{ name: "attack success", color: "data-3", points: a }, { name: "success past the filter", color: "data-4", points: c, dash: true }, { name: "speed monitor catches", color: "data-5", points: d }],
        directLabels: false,
        caption: "Our toy numbers, 120 samples per point, target: " + (st.tkind === "pose" ? "fixed pose" : "another task's mode") + ". FlowHijack reports 23.9%, 57.4% and 100% at τ₀ = 0.1, 0.2 and 0.4."
      });
    }
    function note() { return document.getElementById(id + "-note") || { textContent: "" }; }

    /* ---------- drawing ---------- */
    function dims(hWide, hNarrow) { var w = Math.max(300, Math.min(880, scene.clientWidth || 720)); return { W: w, narrow: w < 600, H: w < 600 ? hNarrow : hWide }; }
    function drawDetect() {
      var d = dims(320, 560), W = d.W, H = d.H, P = RB.pal(), c = RB.canvas(cv, W, H), mono = font("mono"), body = font("body");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var ws = d.narrow ? { x: 8, y: 8, w: W - 16, h: 250 } : { x: 8, y: 8, w: Math.round(W * 0.4), h: H - 16 };
      var tr = d.narrow ? { x: 44, y: 286, w: W - 58, h: H - 326 } : { x: ws.w + 60, y: 22, w: W - ws.w - 76, h: H - 62 };
      /* workspace */
      c.fillStyle = P["surface-sunk"]; c.fillRect(ws.x, ws.y, ws.w, ws.h);
      var px = function (p) { return [ws.x + 10 + p[0] * (ws.w - 20), ws.y + ws.h - 10 - p[1] * (ws.h - 20) * 1.1]; };
      c.strokeStyle = P["surface-strong"]; c.lineWidth = Math.max(6, 4 * S0 * (ws.w - 20)); c.lineCap = "round"; c.beginPath();
      TUBE.forEach(function (p, i) { var q = px(p); if (i) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); }); c.stroke(); c.lineCap = "butt";
      var ob = px(mPath(TG / T)), bn = px(mPath(1));
      c.fillStyle = P["accent-soft"]; c.strokeStyle = P.accent; c.lineWidth = 1.5; c.fillRect(ob[0] - 8, ob[1] - 8, 16, 16); c.strokeRect(ob[0] - 8, ob[1] - 8, 16, 16);
      c.strokeStyle = P["line-strong"]; c.strokeRect(bn[0] - 16, bn[1] - 4, 32, 22);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText("object", ob[0] - 18, ob[1] - 14); c.fillText("bin", bn[0] - 9, bn[1] + 32 > ws.y + ws.h ? bn[1] - 8 : bn[1] + 32);
      var sp = px(mPath(0)); c.fillText("start", sp[0] - 4, sp[1] + 18 > ws.y + ws.h - 2 ? sp[1] - 10 : sp[1] + 18);
      var shown = test.filter(function (r) { return r.kind === "ok"; }).slice(0, 5).concat(test.filter(function (r) { return r.kind !== "ok"; }).slice(0, 5));
      var lim = function (r) { return r === playR && playT != null ? Math.floor(playT) : (r.alarm !== null && r === playR ? r.alarm : T); };
      function path(r, alpha, lw) {
        var L = lim(r); c.strokeStyle = r.kind === "ok" ? P["data-1"] : P["data-3"]; c.globalAlpha = alpha; c.lineWidth = lw; c.beginPath();
        for (var t = 0; t <= L; t++) { var q = px(r.pos[t]); if (t) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); } c.stroke(); c.globalAlpha = 1;
      }
      shown.forEach(function (r) { if (r !== playR) path(r, playR ? 0.18 : 0.45, 1.2); });
      if (playR) {
        path(playR, 1, 2.2); var L = lim(playR), g = px(playR.pos[L]);
        var stopped = playR.alarm !== null && L >= playR.alarm;
        c.fillStyle = stopped ? P.bad : P.ink; c.beginPath(); c.arc(g[0], g[1], 6, 0, Math.PI * 2); c.fill();
        c.fillStyle = P.ink; c.font = "600 12px " + body; c.fillText(stopped ? "Alarm: robot stopped at t = " + playR.alarm : (playR.kind === "ok" ? "success rollout" : playR.kind + " rollout") + ", t = " + L, ws.x + 8, ws.y + 16);
      }
      /* trace */
      var YM = 40, sx = function (t) { return tr.x + t / T * tr.w; }, sy = function (v) { return tr.y + tr.h - Math.min(v, YM) / YM * tr.h; };
      c.fillStyle = P["surface-sunk"]; c.fillRect(sx(18), tr.y, sx(34) - sx(18), tr.h);
      c.strokeStyle = P.line; c.lineWidth = 1; c.beginPath(); c.moveTo(tr.x, tr.y); c.lineTo(tr.x, tr.y + tr.h); c.lineTo(tr.x + tr.w, tr.y + tr.h); c.stroke();
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.textAlign = "center";
      [0, 20, 40, 60].forEach(function (t) { c.fillText(String(t), sx(t), tr.y + tr.h + 15); });
      c.textAlign = "right"; [0, YM / 2, YM].forEach(function (v) { c.fillText(String(v), tr.x - 6, sy(v) + 4); });
      c.fillText("time step t", tr.x + tr.w, tr.y + tr.h + 30); c.textAlign = "left"; c.fillText("grasp · band clipped at 40", sx(18), tr.y - 5);
      c.save(); c.translate(tr.x - 30, tr.y + tr.h / 2 + 40); c.rotate(-Math.PI / 2); c.fillText("score Sₜ", 0, 0); c.restore();
      function trace(r, alpha, lw) {
        var L = lim(r); c.strokeStyle = r.kind === "ok" ? P["data-1"] : P["data-3"]; c.globalAlpha = alpha; c.lineWidth = lw; c.beginPath();
        for (var t = 0; t <= L; t++) { if (t) c.lineTo(sx(t), sy(r.S[t])); else c.moveTo(sx(t), sy(r.S[t])); } c.stroke(); c.globalAlpha = 1;
        if (r.t0 != null && r.t0 <= L) { c.strokeStyle = P["data-3"]; c.lineWidth = 2; c.beginPath(); c.moveTo(sx(r.t0), tr.y + tr.h); c.lineTo(sx(r.t0), tr.y + tr.h - 8); c.stroke(); }
      }
      shown.forEach(function (r) { if (r !== playR) trace(r, playR ? 0.2 : 0.55, 1.2); });
      if (playR) trace(playR, 1, 2.2);
      if (isFinite(det.thr[TG])) { c.strokeStyle = P.accent; c.lineWidth = 3; c.beginPath(); for (var t = 2; t <= T; t++) { var y = sy(det.thr[t]); if (t === 2) c.moveTo(sx(t), y); else c.lineTo(sx(t), y); } c.stroke(); }
      else { c.fillStyle = P.ink; c.font = "600 12px " + body; c.fillText("No finite threshold", tr.x + 10, tr.y + 30); }
      shown.concat(playR ? [playR] : []).forEach(function (r) { if (r.alarm === null || r.alarm > lim(r)) return; if (playR && r !== playR) return; c.fillStyle = P.bad; c.beginPath(); c.arc(sx(r.alarm), sy(r.S[r.alarm]), 4.5, 0, Math.PI * 2); c.fill(); });
    }
    function drawSelect() {
      var d = dims(330, 330), W = d.W, H = d.H, P = RB.pal(), c = RB.canvas(cv, W, H), mono = font("mono"), body = font("body");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var sc = Math.min((W - 20) / 18, (H - 20) / 13), cx = W / 2, cy = H / 2 + 8, px = function (x) { return [cx + x[0] * sc, cy - x[1] * sc]; };
      c.strokeStyle = P["bench-grid"] || P.line; c.lineWidth = 1;
      for (var gx = -8; gx <= 8; gx += 2) { var a = px([gx, -6]), b = px([gx, 6]); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); }
      for (var gy = -6; gy <= 6; gy += 2) { var a2 = px([-8.5, gy]), b2 = px([8.5, gy]); c.beginPath(); c.moveTo(a2[0], a2[1]); c.lineTo(b2[0], b2[1]); c.stroke(); }
      var o = px([0, 0]);
      c.fillStyle = P["surface-strong"]; c.strokeStyle = P["line-strong"]; c.fillRect(o[0] - 1.2 * sc, o[1] - 0.9 * sc, 2.4 * sc, 1.8 * sc); c.strokeRect(o[0] - 1.2 * sc, o[1] - 0.9 * sc, 2.4 * sc, 1.8 * sc);
      [0.5, 0.1].forEach(function (lv, i) { var r = SS * Math.sqrt(-2 * Math.log(lv)) * sc; c.strokeStyle = P.good; c.lineWidth = i ? 1 : 2; c.beginPath(); c.arc(o[0], o[1], r, 0, Math.PI * 2); c.stroke(); });
      var hp = px(HUMP); c.strokeStyle = P.bad; c.setLineDash([5, 4]); c.lineWidth = 1.5; c.beginPath(); c.arc(hp[0], hp[1], 1.6 * HW * sc, 0, Math.PI * 2); c.stroke(); c.setLineDash([]);
      c.fillStyle = P["ink-2"]; c.font = "500 11px " + mono; c.fillText("critic's blind spot", hp[0] - 50, hp[1] - 1.6 * HW * sc - 6);
      c.fillText("object", o[0] - 1.2 * sc, o[1] - 0.9 * sc - 6);
      var mp = px(sel.mu); c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.moveTo(mp[0] - 6, mp[1]); c.lineTo(mp[0] + 6, mp[1]); c.moveTo(mp[0], mp[1] - 6); c.lineTo(mp[0], mp[1] + 6); c.stroke();
      c.fillStyle = P["ink-2"]; c.fillText("policy mode", mp[0] + 10, mp[1] - 10);
      var C = sel.eps[st.ep % sel.eps.length], N = Math.pow(2, st.nexp), bi = pickIdx(C, st.ver, N), lo = 1e9, hi = -1e9;
      for (var j = 0; j < N; j++) { lo = Math.min(lo, C[j].s[st.ver]); hi = Math.max(hi, C[j].s[st.ver]); }
      for (var k = 0; k < N; k++) { var q = px(C[k].x), f = hi > lo ? (C[k].s[st.ver] - lo) / (hi - lo) : 1; c.fillStyle = P["data-1"]; c.globalAlpha = 0.2 + 0.8 * f; c.beginPath(); c.arc(q[0], q[1], 4.5, 0, Math.PI * 2); c.fill(); }
      c.globalAlpha = 1; var bq = px(C[bi].x); c.strokeStyle = P.accent; c.lineWidth = 3; c.beginPath(); c.arc(bq[0], bq[1], 10, 0, Math.PI * 2); c.stroke();
      c.fillStyle = P.ink; c.font = "600 12px " + body; c.fillText("Episode " + (st.ep % sel.eps.length + 1) + " · " + VER.filter(function (v) { return v.k === st.ver; })[0].name + " picks one of " + N, 10, 18);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText("grid: 2 cm", 10, H - 8);
    }
    function heat(c, P, box, fn, col, path, upto, title, mono) {
      var nx = 40, ny = 30;
      c.fillStyle = P["surface-sunk"]; c.fillRect(box.x, box.y, box.w, box.h);
      for (var i = 0; i < nx; i++) for (var j = 0; j < ny; j++) {
        var g = (i + 0.5) / nx * 1.2, h = (j + 0.5) / ny, v = RB.clamp(fn(g, h), 0, 1);
        c.fillStyle = P[col]; c.globalAlpha = 0.08 + 0.82 * v; c.fillRect(box.x + i * box.w / nx, box.y + box.h - (j + 1) * box.h / ny, box.w / nx + 0.6, box.h / ny + 0.6);
      }
      c.globalAlpha = 1;
      var px = function (p) { return [box.x + p.g / 1.2 * box.w, box.y + box.h - p.h * box.h]; };
      c.strokeStyle = P.accent; c.lineWidth = 2.5; c.beginPath();
      for (var k = 0; k <= upto; k++) { var q = px(path[k]); if (k) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); } c.stroke();
      var s = px(path[0]), e = px(path[upto]);
      c.fillStyle = P.surface; c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.arc(s[0], s[1], 5, 0, Math.PI * 2); c.fill(); c.stroke();
      c.fillStyle = P.accent; c.beginPath(); c.arc(e[0], e[1], 6, 0, Math.PI * 2); c.fill();
      c.strokeStyle = P.line; c.strokeRect(box.x, box.y, box.w, box.h);
      c.fillStyle = P.ink; c.font = "600 12px " + font("body"); c.fillText(title, box.x, box.y - 8);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.textAlign = "center"; c.fillText("real grasp skill g →", box.x + box.w / 2, box.y + box.h + 16); c.textAlign = "left";
      c.save(); c.translate(box.x - 8, box.y + box.h); c.rotate(-Math.PI / 2); c.fillText("shortcut share h →", 0, 0); c.restore();
    }
    function drawOptimize() {
      var d = dims(300, 540), W = d.W, H = d.H, P = RB.pal(), c = RB.canvas(cv, W, H), mono = font("mono");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var up = Math.min(optShow, ITER), b1, b2;
      if (d.narrow) { b1 = { x: 24, y: 26, w: W - 36, h: 210 }; b2 = { x: 24, y: 290, w: W - 36, h: 210 }; }
      else { var bw = (W - 72) / 2; b1 = { x: 26, y: 26, w: bw, h: H - 70 }; b2 = { x: 50 + bw, y: 26, w: bw, h: H - 70 }; }
      heat(c, P, b1, function (g, h) { return optProxy(g, h, st.w); }, "data-2", opt, up, "Training verifier passes", mono);
      heat(c, P, b2, optTrue, "data-1", opt, up, "True success", mono);
    }
    function drawAttack() {
      var d = dims(360, 340), W = d.W, H = d.H, P = RB.pal(), c = RB.canvas(cv, W, H), mono = font("mono"), body = font("body");
      c.fillStyle = P.surface; c.fillRect(0, 0, W, H);
      var sc = Math.min((W - 30) / 5.4, (H - 60) / 4.4), cx = W / 2, cy = H / 2 + 14, px = function (x) { return [cx + x[0] * sc, cy - (x[1] - 0.3) * sc]; };
      function ring(m, dash, col) { var q = px(m); c.strokeStyle = col; c.setLineDash(dash ? [4, 3] : []); c.lineWidth = 1.5; c.beginPath(); c.arc(q[0], q[1], AR * sc, 0, Math.PI * 2); c.stroke(); c.setLineDash([]); return q; }
      function label(txt, q, below, strong) { c.fillStyle = strong ? P.ink : P["ink-2"]; c.font = (strong ? "600 12px " + body : "500 11px " + mono); var w = c.measureText(txt).width; c.fillText(txt, RB.clamp(q[0] - w / 2, 4, W - w - 4), below ? q[1] + AR * sc + 14 : q[1] - AR * sc - 6); }
      AMODES.forEach(function (m, i) { var q = ring(m.m, true, P["ink-3"]); label(m.name + (i === 2 && st.tkind === "mode" ? " · target" : ""), q, i === 2, i === 0); });
      if (st.tkind === "pose") { var qp = ring(APOSE, false, P.bad); label("fixed pose · target", qp, true, false); }
      function drawSet(arr, col, n) {
        arr.slice(0, n).forEach(function (s) {
          c.strokeStyle = P[col]; c.globalAlpha = 0.28; c.lineWidth = 1.2; c.beginPath();
          s.path.forEach(function (p, k) { var q = px(p); if (k) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); }); c.stroke();
          c.globalAlpha = 0.95; var e = px(s.x); c.fillStyle = P[col]; c.beginPath(); c.arc(e[0], e[1], 3.5, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1;
        });
      }
      drawSet(atk.ben, "data-1", 30);
      if (st.trig) drawSet(atk.trg, "data-3", 30);
      var o = px([0, 0]); c.fillStyle = P.ink; c.beginPath(); c.arc(o[0], o[1], 3, 0, Math.PI * 2); c.fill(); c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText("noise starts here", o[0] + 8, o[1] + 4);
      c.fillStyle = P.ink; c.font = "600 12px " + body; c.fillText(st.trig ? "Trigger in the image" : "Clean image only", 10, 18);
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText("K = " + AK + " Euler steps · τ₀ = " + st.tau0.toFixed(1), 10, 34);
    }
    function draw() {
      if (!cv.isConnected) return;
      if (st.mode === "detect" && det) drawDetect(); else if (st.mode === "select" && sel) drawSelect(); else if (st.mode === "optimize" && opt) drawOptimize(); else if (st.mode === "attack" && atk) drawAttack();
    }
    function chart() { if (!cv.isConnected || !{ detect: det, select: sel, optimize: opt, attack: atk }[st.mode]) return; if (st.mode === "detect") chartDetect(); else if (st.mode === "select") chartSelect(); else if (st.mode === "optimize") chartOptimize(); else chartAttack(); }
    function chartSoon() { clearTimeout(chartT); chartT = setTimeout(chart, 120); }
    function compute(retest) {
      if (st.mode === "detect") computeDetect(retest); else if (st.mode === "select") computeSelect(); else if (st.mode === "optimize") computeOptimize(); else computeAttack();
      draw(); chartSoon();
    }

    /* ---------- mode switching ---------- */
    function setMode(m) {
      stop(); st.mode = m; playR = null; playT = null;
      RB.$$("[data-grp]", ctl).forEach(function (g) { g.style.display = g.getAttribute("data-grp") === m ? "" : "none"; });
      roHost.innerHTML = RB.readouts(RO[m]);
      cap.textContent = CAP[m]; lgHost.innerHTML = RB.legend(LEG[m]);
      cv.setAttribute("aria-label", { detect: "Workspace path and detector scores over time", select: "Candidate grasps around an object, one picked by the verifier", optimize: "Training path on maps of verifier score and true success", attack: "Flow sampling paths from noise to three action modes" }[m]);
      api.side.innerHTML = SIDE[m]();
      if (m === "optimize") optShow = ITER;
      compute(true);
      RB.typeset(api.side);
    }

    /* ---------- animation ---------- */
    function stop() { if (raf) cancelAnimationFrame(raf); raf = 0; api.live("paused", "Paused"); }
    function playRollout() {
      if (st.mode !== "detect") return;
      stop();
      var fails = test.filter(function (r) { return r.kind !== "ok"; }), oks = test.filter(function (r) { return r.kind === "ok"; });
      playR = st.plays % 3 === 2 ? oks[st.plays % oks.length] : fails[st.plays % fails.length];
      var t0 = performance.now(); api.live("running", "Rolling out");
      (function tick(now) {
        playT = RB.clamp((now - t0) / 1000 * 14, 0, T);
        if (playR.alarm !== null && playT >= playR.alarm) playT = playR.alarm;
        draw();
        var done = playT >= T || (playR.alarm !== null && playT >= playR.alarm);
        if (done) { raf = 0; st.plays++; playT = null; draw(); api.live("paused", playR.alarm !== null ? "Stopped by the alarm" : "Rollout finished"); return; }
        raf = requestAnimationFrame(tick);
      })(t0);
    }
    function train() {
      if (st.mode !== "optimize") return;
      stop(); optShow = 0; var t0 = performance.now(); api.live("running", "Training");
      (function tick(now) {
        optShow = RB.clamp(Math.floor((now - t0) / 1000 * 60), 0, ITER);
        showOpt(); draw();
        if (optShow >= ITER) { raf = 0; st.trained = true; runs.train++; api.live("paused", "Trained " + ITER + " iterations"); return; }
        raf = requestAnimationFrame(tick);
      })(t0);
    }

    /* ---------- wiring ---------- */
    bindSeg(ctl, id + "-mode", setMode);
    bindSeg(ctl, id + "-band", function (v) { st.band = v; stop(); playR = null; compute(false); });
    bindSeg(ctl, id + "-fk", function (v) { st.fkind = v; stop(); playR = null; st.plays = 0; compute(true); });
    RB.bindSlider(ctl, id + "-alpha", function (v) { return (+v).toFixed(2); }, function (v) { st.alpha = v; stop(); playR = null; compute(false); });
    RB.bindSlider(ctl, id + "-m", null, function (v) { st.M = v; stop(); playR = null; compute(false); });
    RB.bindSlider(ctl, id + "-shift", function (v) { return (+v).toFixed(1); }, function (v) { st.shift = v; stop(); playR = null; compute(true); });
    ctl.querySelector("#" + id + "-play").addEventListener("click", playRollout);
    bindSeg(ctl, id + "-pre", function (v) { st.pre = v; compute(); });
    bindSeg(ctl, id + "-ver", function (v) { st.ver = v; computeSelect(); draw(); });
    RB.bindSlider(ctl, id + "-n", function (v) { return String(Math.pow(2, v)); }, function (v) { st.nexp = v; computeSelect(); draw(); });
    RB.bindSlider(ctl, id + "-sv", function (v) { return (+v).toFixed(2); }, function (v) { st.sv = v; compute(); });
    ctl.querySelector("#" + id + "-next").addEventListener("click", function () { st.ep++; computeSelect(); draw(); });
    RB.bindSlider(ctl, id + "-w", function (v) { return (+v).toFixed(2); }, function (v) { st.w = v; stop(); optShow = ITER; compute(); });
    RB.bindSlider(ctl, id + "-rho", function (v) { return (+v).toFixed(2); }, function (v) { st.rho = v; stop(); optShow = ITER; compute(); });
    RB.bindSlider(ctl, id + "-beta", function (v) { return (+v).toFixed(1); }, function (v) { st.beta = v; stop(); optShow = ITER; compute(); });
    ctl.querySelector("#" + id + "-train").addEventListener("click", train);
    RB.bindSlider(ctl, id + "-tau0", function (v) { return (+v).toFixed(1); }, function (v) { st.tau0 = Math.round(v * 10) / 10; computeAttack(); draw(); });
    ctl.querySelector("#" + id + "-trig").addEventListener("change", function (e) { st.trig = e.target.checked; draw(); });
    bindSeg(ctl, id + "-tk", function (v) { st.tkind = v; compute(); });
    ctl.querySelector("#" + id + "-resamp").addEventListener("click", function () { st.aseed++; compute(); });
    if (window.ResizeObserver) { ro = new ResizeObserver(function () { var w = scene.clientWidth; if (Math.abs(w - lastW) < 2) return; lastW = w; draw(); chartSoon(); }); ro.observe(scene); }
    RB.onTheme(function () { if (cv.isConnected) { draw(); chart(); } });
    setMode("detect");

    function state() { return { mode: st.mode, band: st.band, fkind: st.fkind, plays: st.plays, playing: !!raf, nexp: st.nexp, ver: st.ver, pre: st.pre, trained: st.trained, train: runs.train, tau0: st.tau0, tkind: st.tkind }; }
    return {
      state: state,
      destroy: function () { if (raf) cancelAnimationFrame(raf); raf = 0; clearTimeout(chartT); if (ro) ro.disconnect(); },
      demo: function () {
        var q = function (s) { return scene.querySelector(s) || ctl.querySelector(s); }, S = state;
        var toMode = function (a, m) { return a.click(q("#" + id + '-mode [value="' + m + '"]')); };
        return [
          { target: q("#" + id + "-cv"), title: "One score, one band", text: "Right: a single-pass novelty score per rollout. The thick band was calibrated on successes only, with at most 5% false alarms allowed." },
          { target: q("#" + id + "-band"), title: "One threshold for all", text: "A constant threshold must clear the noisy grasp, so it sits high everywhere. Watch the caught share fall.", do: function (a) { return a.click(q("#" + id + '-band [value="const"]')); }, task: "Choose the Constant threshold", expect: function () { return S().band === "const"; } },
          { target: q("#" + id + "-play"), title: "Watch one rollout", text: "The gripper follows the taught path until the object slips. The alarm, if it fires, stops the robot.", do: function (a) { return a.click(q("#" + id + "-play")).then(function () { return a.until(function () { return !S().playing; }, 8000); }); }, task: "Press Play a rollout", expect: function () { return S().plays > 0 && !S().playing; } },
          { target: q("#" + id + "-mode"), title: "Select before acting", text: "Best-of-N: sample candidate grasps, score each with a verifier, run the best one.", do: function (a) { return toMode(a, "select"); }, task: "Open the Select bench", expect: function () { return S().mode === "select"; } },
          { target: q("#" + id + "-n"), title: "Search finds blind spots", text: "At 128 candidates the offline critic often picks a grasp in its blind spot. Its curve falls while the VLM verifier's keeps rising.", do: function (a) { return a.set(q("#" + id + "-n"), 7); }, task: "Set Candidates N to 128", expect: function () { return S().nexp === 7; } },
          { target: q("#" + id + "-train"), title: "Train against a verifier", text: "The policy climbs the verifier's score. The shortcut is easier than the skill, so true success falls.", do: function (a) { return toMode(a, "optimize").then(function () { return a.click(q("#" + id + "-train")); }).then(function () { return a.until(function () { return !S().playing; }, 6000); }); }, task: "Open Optimize and press Train", expect: function () { return S().mode === "optimize" && S().train > 0 && !S().playing; } },
          { target: q("#" + id + "-tau0"), title: "A backdoor in early flow", text: "In Attack, a trigger redirects the flow field only for τ below τ₀. At 0.4 about half the triggered samples end at the table edge.", do: function (a) { return toMode(a, "attack").then(function () { return a.set(q("#" + id + "-tau0"), 0.4); }); }, task: "Open Attack and set τ₀ to 0.4", expect: function () { return S().mode === "attack" && S().tau0 >= 0.4; } },
          { target: q("#" + id + "-tk"), title: "Your turn", text: "Choose Fixed pose and set τ₀ to 1: the off-mode filter now rejects most attacks. Then go back to Detect and try the Stall failures." }
        ];
      }
    };
  }

  RB.station({
    id: SID, name: "Failure detector and verifier lab", sub: "21 · 22",
    refs: ["P14 §4.2, §5.1, §6.3–6.4", "P13 §5.1.3"], prov: "Simplified: four toy models",
    summary: "Four benches on one question: how far can you trust a score? Detect failures with a conformal band, pick among candidates with three verifiers, train against a foolable verifier, and hide a backdoor in a flow head.",
    notice: [
      "A conformal band bounds false alarms on successes like the calibration set, not missed failures.",
      "A novelty score misses failures that look familiar, such as a stalled arm.",
      "More candidates help a noisy verifier but let search find a verifier's blind spot.",
      "Training against a verifier can raise its score while true success falls; a held-out panel shows how much transfers.",
      "An early-τ backdoor that targets another task's mode ends on an ordinary-looking action, so output filters pass it."
    ],
    card: "Detect failures, rank candidates, train against a foolable verifier, and hide a backdoor in a flow head.",
    terms: {
      "false-positives-under-search": { name: "false positives under search", aliases: ["verifier exploitation by search", "best-of-N overoptimization"], group: "trust", def: "Candidates found by searching a verifier for inputs it wrongly accepts; they mark the region a policy trained on that verifier moves toward.", note: "Curation tolerates average error; ranking many candidates or training a reward meets the worst errors.", ref: "P14 Table 7, §7", scene: "system", focus: ["verifier", "action-head"], look: "many candidates entering the verifier", uses: [] },
    },
    ledger: [
      { where: "Lab · Verifier lab · Detect", source: "FAIL-Detect scores observations with a learned flow density (logpZO); SAFE probes VLA features", page: "The toy score is the squared distance to a 2-D taught path, averaged over 3 steps", why: "Shows calibration and its limits without training a network.", kind: "Simplified" },
      { where: "Lab · Verifier lab · Detect", source: "FAIL-Detect shapes its band with a modulation function s_A^cal(t)", page: "The band uses the spread σₜ of calibration half A; a failure is 'visible' when the slip exceeds 4 S₀, or 10 steps into a stall", why: "One familiar quantity; the visibility rule is our choice.", kind: "Our choice" },
      { where: "Lab · Verifier lab · Select", source: "RoboMonkey trains a 7B VLM verifier; V-GPS trains a Cal-QL critic", page: "The VLM verifier is the true score plus Gaussian noise; the critic is the true score plus one bump of overestimation away from the data", why: "Isolates noise that averages out from errors that search can find.", kind: "Simplified" },
      { where: "Lab · Verifier lab · Select", source: "V-GPS reports OpenVLA rising from 0.24 to 0.27 on SIMPLER with its critic; RoboMonkey reports V-GPS with OpenVLA below OpenVLA alone (30% vs 35%, real OOD tasks)", page: "The side panel cites V-GPS's gain with Octo-small only", why: "Different setups; both are reported in the methods table.", kind: "Sources disagree" },
      { where: "Lab · Verifier lab · Optimize", source: "P14 §6.4 defines the proxy gain that transfers over policy checkpoints trained with RL", page: "A two-parameter policy (skill g, shortcut share h) trained by gradient ascent on expected scores; the panel passes shortcut episodes with probability ρw, the training verifier with w", why: "Shows the ratio and the panel-rejection protocol in one small model.", kind: "Simplified" },
      { where: "Lab · Verifier lab · Attack", source: "FlowHijack trains LoRA adapters on π0 with a backdoor loss for τ ≤ τ₀ and a mimicry loss", page: "The toy uses the exact velocity of a three-mode mixture; triggered samples follow the exact field of the target for τ < τ₀. The mimicry loss is left out, and the filter rejects actions farther than 0.5 from every mode", why: "Shows why the window matters without training a network. In this toy a speed check does not separate the attack well even without mimicry.", kind: "Simplified" },
      { where: "Lab · Verifier lab · notation", source: "FIPER and Sentinel write the false-alarm rate as δ; KnowNo as ε", page: "The station writes α for every conformal error rate", why: "ε is Gaussian noise in the house notation.", kind: "Our choice" }
    ],
    mount: mount
  });
})();
