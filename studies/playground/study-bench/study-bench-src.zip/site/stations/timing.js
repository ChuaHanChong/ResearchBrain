/* Interactive Lab · Control-loop budget station (topics 07, 11). Sources: X2 §4.4 (async inference, Alg. 1, g ≥ E[ℓ_S]/Δt/H);
   P04 §4.5 (four deployment regimes, eq. 33–36, feasibility N_fwd(K)/K < 1/f_ctrl); X1 §7 (DreamZero ~7 Hz vs ~50 Hz VLAs);
   method cards: π0 (2410.24164), RTC (2506.07339), DreamZero (2602.15922), Fast-WAM (2603.16666), π0.7 (2604.15483).
   Toy: a tick-based control loop. A policy server returns chunks of H actions after N_fwd + network time; the robot pops one
   action per tick. Each chunk tracks a known reference plus a small random offset and drift (our toy error model), and only
   chunks planned after a push "know" about it. Everything drawn is computed here; paper numbers appear only in presets and notes. */
(function () {
  "use strict";
  var RB = window.RB;
  var SID = "timing", TVIEW = 8000, TPUSH = 3000, PUSH = 0.5, TASK_S = 10;

  var PRESETS = {
    vla: { label: "π0 VLA", nfwd: 73, net: 13, H: 50, f: 50, g: 0.5, mode: "async",
      note: "π0 on one RTX 4090: 73 ms per chunk on board, 86 ms off board, chunks of 50 actions, control up to 50 Hz (arXiv 2410.24164). One call covers a second of motion." },
    dz: { label: "DreamZero", nfwd: 150, net: 0, H: 48, f: 30, g: 0.5, mode: "async",
      note: "DreamZero is a 14B video-action model. A 38× speedup stack brings a chunk of 48 actions at 30 Hz to about 150 ms (arXiv 2602.15922): about 7 Hz, against about 50 Hz for VLAs (X1 §7)." },
    fw: { label: "Fast-WAM", nfwd: 190, net: 0, H: 32, f: 30, g: 0.5, mode: "async",
      note: "Fast-WAM skips future video at test time: 190 ms per chunk of 32 actions, against 580 ms when it also generates video (arXiv 2603.16666). The 30 Hz rate is our choice." },
    p7: { label: "π0.7 subgoals", nfwd: 38, net: 0, H: 50, f: 50, g: 0.5, mode: "rtc", sub: true,
      note: "π0.7's minimal variant takes 38 ms on an H100 for 50 actions and executes 15 or 25 of them (arXiv 2604.15483). A separate world model refreshes subgoal images every 4 s (P04 §4.5.2)." },
    rtc: { label: "RTC", nfwd: 97, net: 12, H: 50, f: 50, g: 0.5, mode: "rtc",
      note: "Real-Time Chunking on π0.5: 97 ms per call (76 ms without it) and about 109 ms of total system latency, chunks of 50 at 50 Hz (arXiv 2506.07339). Try adding 100 or 200 ms of network delay." }
  };
  var PKEYS = ["vla", "dz", "fw", "p7", "rtc"];
  var MODES = [{ value: "sync", label: "Synchronous" }, { value: "async", label: "Drop stale" }, { value: "rtc", label: "RTC blend" }];

  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function pressSeg(root, id, v) { RB.$$("#" + id + " button", root).forEach(function (b) { var on = b.value === v; b.setAttribute("aria-pressed", on ? "true" : "false"); b.tabIndex = on ? 0 : -1; }); }
  function font(kind) { return getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); }

  /* ---------- the toy world: a known reference motion plus a push the policy only sees after it happens ---------- */
  function ref(t) { return 0.45 * Math.sin(2 * Math.PI * t / 4000); }
  function target(t, push) { return ref(t) + (push && t >= TPUSH ? PUSH : 0); }
  /* chunk error model (ours): offset e0 and drift per second, both Gaussian */
  function chunkErr(c, t) { return c.e0 + c.drift * (t - c.obsT) / 1000; }
  function chunkVal(c, t, push) { return ref(t) + (push && c.obsT >= TPUSH ? PUSH : 0) + chunkErr(c, t); }
  /* RTC-style soft mask weight on the old chunk for overlap index k of L (arXiv 2506.07339, eq. 5 shape) */
  function softW(k, L) { if (L <= 0) return 0; var c = (L - k) / (L + 1); return c <= 0 ? 0 : c * (Math.exp(c) - 1) / (Math.E - 1); }

  function simulate(st, seed) {
    var R = RB.rng(seed), dt = 1000 / st.f, N = Math.ceil(TVIEW / dt), H = st.H;
    var queue = [], inflight = null, calls = [], ticks = [], chunks = [], execCount = 0, lastV = null, lastErr = null;
    function send(t) {
      var nf = Math.max(0.5 * st.nfwd, st.nfwd * (1 + 0.1 * R.normal()));
      inflight = { sent: t, nf: nf, arrive: t + nf + st.net, exec0: execCount };
      calls.push(inflight);
    }
    send(0);
    for (var i = 0; i < N; i++) {
      var t = i * dt;
      if (inflight && inflight.arrive <= t + 1e-9) {
        var c = { id: chunks.length, obsT: inflight.sent, e0: 0.05 * R.normal(), drift: 0.14 * R.normal() };
        chunks.push(c);
        var d = Math.min(H, execCount - inflight.exec0), nq = [];
        for (var j = d; j < H; j++) nq.push({ c: c, old: null, w: 0 });
        if (st.mode === "rtc" && queue.length) { var L = queue.length; nq.forEach(function (e, k) { if (k < L) { e.old = queue[k].c; e.w = softW(k, L); } }); }
        inflight.d = d; inflight.done = true; queue = nq; inflight = null;
      }
      var tk = { t: t, q: 0, idle: true, v: lastV, err: lastErr, chunk: -1, age: null, sw: false };
      if (queue.length) {
        var e = queue.shift(), v = chunkVal(e.c, t, st.push), er = chunkErr(e.c, t);
        if (e.old) { v = e.w * chunkVal(e.old, t, st.push) + (1 - e.w) * v; er = e.w * chunkErr(e.old, t) + (1 - e.w) * er; }
        tk.idle = false; tk.v = v; tk.err = er; tk.chunk = e.c.id; tk.age = t - (e.w > 0.5 && e.old ? e.old.obsT : e.c.obsT);
        tk.sw = ticks.length > 0 && ticks[ticks.length - 1].chunk !== e.c.id && ticks[ticks.length - 1].chunk >= 0;
        tk.jump = tk.sw && lastErr != null ? Math.abs(er - lastErr) : 0;
        lastV = v; lastErr = er; execCount++;
      }
      tk.q = queue.length;
      if (!inflight) {
        if (st.mode === "sync" ? queue.length === 0 : (queue.length === 0 || queue.length / H < st.g)) send(t);
      }
      ticks.push(tk);
    }
    /* summary numbers, all from this toy run */
    var first = ticks.filter(function (k) { return !k.idle; })[0], t0 = first ? first.t : TVIEW, after = ticks.filter(function (k) { return k.t >= t0; });
    var idle = after.filter(function (k) { return k.idle; }).length / Math.max(1, after.length);
    var ex = ticks.filter(function (k) { return !k.idle; }), age = ex.reduce(function (a, k) { return a + k.age; }, 0) / Math.max(1, ex.length);
    var react = null; for (var q = 0; q < ticks.length; q++) { var k2 = ticks[q]; if (k2.t >= TPUSH && !k2.idle && chunks[k2.chunk].obsT >= TPUSH) { react = k2.t - TPUSH; break; } }
    var jump = ticks.reduce(function (a, k) { return Math.max(a, k.jump || 0); }, 0);
    var sent = calls.filter(function (c) { return c.sent < TVIEW; }), busy = sent.reduce(function (a, c) { return a + Math.min(c.nf, TVIEW - c.sent); }, 0) / TVIEW;
    return { ticks: ticks, calls: calls, dt: dt, idle: idle, age: age, react: react, jump: jump, rate: sent.length / (TVIEW / 1000), busy: busy, startup: t0, empty: !first };
  }

  /* ---------- the four deployment regimes of P04 §4.5 on one model (our toy cost model, see ledger) ---------- */
  function regimes(st) {
    var T = Math.round(TASK_S * st.f), bud = 1000 / st.f, lat = st.nfwd + st.net, H = st.H, cc = Math.ceil(T / H);
    return [
      { id: "open", name: "Open loop", eq: "eq. 33", h: "H ≈ T = " + T, calls: 1, gpu: st.nfwd, ok: null, test: "paid once", stale: TASK_S * 1000 },
      { id: "chunk", name: "Chunked", eq: "eq. 34", h: "H = " + H, calls: cc, gpu: cc * st.nfwd, ok: st.nfwd / H < bud, test: RB.fmt(st.nfwd / H, 1) + (st.nfwd / H < bud ? " < " : " ≥ ") + RB.fmt(bud, 0) + " ms", stale: H * bud + lat },
      { id: "single", name: "Single step", eq: "eq. 35", h: "H = 1", calls: T, gpu: T * st.nfwd, ok: st.nfwd < bud, test: RB.fmt(st.nfwd, 0) + (st.nfwd < bud ? " < " : " ≥ ") + RB.fmt(bud, 0) + " ms", stale: lat },
      { id: "inter", name: "Interactive", eq: "eq. 36", h: "H grows", calls: T, gpu: T * st.nfwd * 1.5, ok: 2 * st.nfwd < bud, test: "end: " + RB.fmt(2 * st.nfwd, 0) + (2 * st.nfwd < bud ? " < " : " ≥ ") + RB.fmt(bud, 0) + " ms", stale: lat }
    ];
  }

  function mount(api) {
    var id = SID, scene = api.scene, ctl = api.controls;
    var st = { preset: "vla", nfwd: 73, net: 13, H: 50, f: 50, g: 0.5, mode: "async", push: true, sub: false };
    var res = null, seed = 5, raf = 0, playT = null, runs = 0, ro = null, lastW = 0, chartT = 0, simT = 0;

    scene.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-tl" aria-label="Eight seconds of the control loop: policy calls, robot activity, action queue and the executed action against the target"></canvas>' +
      RB.legend([{ c: "data-2", label: "policy compute", kind: "area" }, { c: "line-strong", label: "network", kind: "area" }, { c: "data-1", label: "chunk (alternating shades)", kind: "area" }, { c: "bad", label: "robot idle", kind: "area" }, { c: "ink-3", label: "target", kind: "dash" }, { c: "data-3", label: "executed action", kind: "line" }]) +
      '<figcaption class="sb-caption">Read down one moment in time: which call is running, whether the robot moves, how many actions are queued, and how far the executed action is from the target after the push at 3 s.</figcaption></figure>' +
      RB.readouts([{ id: "idle", k: "Robot idle" }, { id: "rate", k: "Policy calls", u: "/s" }, { id: "busy", k: "Server busy" }, { id: "age", k: "Mean observation age", u: "ms" }, { id: "react", k: "Reaction to the push", u: "ms" }, { id: "jump", k: "Largest switch jump" }, { id: "p04", k: "P04 test: N_fwd/H", u: "ms per action" }, { id: "gmin", k: "Smallest safe g (X2)" }]) +
      '<div id="' + id + '-chart"></div><div class="rb-stack"><h4 class="rb-h5">Four regimes on this model</h4><div class="sb-scroll-x" id="' + id + '-reg"></div>' +
      '<p class="sb-caption">Illustrative: a ' + TASK_S + ' s task with this N_fwd and rate. Compute is total policy time; plan age is the oldest observation behind an executed action. <span class="sb-ref">P04 eq. 33–36</span></p></div>';
    ctl.innerHTML =
      '<div class="rb-stack">' +
      '<div class="rb-row">' + RB.seg({ id: id + "-pre", label: "Preset", value: "vla", options: PKEYS.map(function (k) { return { value: k, label: PRESETS[k].label }; }) }) +
      RB.seg({ id: id + "-mode", label: "Execution", value: "async", options: MODES }) + "</div>" +
      '<div class="rb-row">' +
      RB.slider({ id: id + "-nf", label: "N_fwd per call (ms)", min: 10, max: 1000, step: 1, value: 73 }) +
      RB.slider({ id: id + "-net", label: "Network (ms)", min: 0, max: 300, step: 1, value: 13 }) +
      RB.slider({ id: id + "-h", label: "Chunk H (P04: K)", min: 1, max: 100, step: 1, value: 50 }) +
      RB.slider({ id: id + "-f", label: "f_ctrl (Hz)", min: 5, max: 120, step: 1, value: 50 }) +
      RB.slider({ id: id + "-g", label: "Threshold g", min: 0, max: 1, step: 0.05, value: 0.5, fmt: function (v) { return (+v).toFixed(2); } }) + "</div>" +
      '<div class="rb-row"><label class="sb-field"><input type="checkbox" id="' + id + '-push" checked> <span>Push the target at 3 s</span></label>' +
      '<button class="sb-btn" type="button" id="' + id + '-seed">New latency draw</button>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Replay 8 s ▶</button></div></div>';
    api.side.innerHTML = '<p class="rb-muted" id="' + id + '-note">–</p>' +
      RB.eqBlock({ name: "Chunked budget", ref: "P04 eq. 34", tex: "\\frac{\\class{sym-Nfwd}{N_{\\mathrm{fwd}}}(\\class{sym-H}{H})}{\\class{sym-H}{H}} < \\frac{1}{\\class{sym-fctrl}{f_{\\mathrm{ctrl}}}}", words: "Each call must take less time than the chunk it produces lasts on the robot.", key: ["Nfwd", "H", "fctrl"] }) +
      RB.eqBlock({ name: "Queue never empties", ref: "X2 §4.4", tex: "g \\ge \\frac{\\mathbb{E}[\\ell_S] \\cdot \\class{sym-fctrl}{f_{\\mathrm{ctrl}}}}{\\class{sym-H}{H}}", words: "Ask early enough that the actions still queued cover the expected latency.", key: [{ glyph: "g", meaning: "queue threshold" }, { glyph: "ℓ_S", meaning: "server latency per chunk" }, "fctrl", "H"] }) +
      '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
      '<li>π0: 73 ms per chunk of 50, up to 50 Hz <span class="sb-ref">arXiv 2410.24164</span></li>' +
      '<li>RTC on π0.5: 97 ms per call, 76 ms without RTC <span class="sb-ref">arXiv 2506.07339</span></li>' +
      '<li>DreamZero: about 150 ms after a 38× speedup; 5.7 s without it <span class="sb-ref">arXiv 2602.15922</span></li>' +
      '<li>Fast-WAM: 190 ms without future video, 580 ms with it <span class="sb-ref">arXiv 2603.16666</span></li>' +
      '<li>π0.7: 38 ms, executes 15 or 25 of 50 actions <span class="sb-ref">arXiv 2604.15483</span></li>' +
      '<li>LeRobot example: Δt = 33 ms at 30 fps, g = 0.5, 50 actions per chunk <span class="sb-ref">X2 §4.4</span></li></ul>';

    var cv = scene.querySelector("#" + id + "-tl"), chartHost = scene.querySelector("#" + id + "-chart"), regHost = scene.querySelector("#" + id + "-reg");
    var SL = { nfwd: "-nf", net: "-net", H: "-h", f: "-f", g: "-g" };
    function setSlider(key, v) { var inp = ctl.querySelector("#" + id + SL[key]), out = ctl.querySelector('[data-out="' + id + SL[key] + '"]'); inp.value = v; if (out) out.textContent = key === "g" ? (+v).toFixed(2) : String(v); }

    function compute() {
      res = simulate(st, seed);
      var lat = st.nfwd + st.net, bud = 1000 / st.f, gmin = lat * st.f / 1000 / st.H;
      RB.setRO(scene, "idle", res.empty ? "100%" : Math.round(100 * res.idle) + "%");
      RB.setRO(scene, "rate", RB.fmt(res.rate, 1));
      RB.setRO(scene, "busy", Math.round(100 * Math.min(1, res.busy)) + "%");
      RB.setRO(scene, "age", res.empty ? "–" : String(Math.round(res.age)));
      RB.setRO(scene, "react", !st.push ? "–" : res.react == null ? "none in 8 s" : String(Math.round(res.react)));
      RB.setRO(scene, "jump", res.empty ? "–" : RB.fmt(res.jump, 2));
      RB.setRO(scene, "p04", RB.fmt(st.nfwd / st.H, st.nfwd / st.H < 10 ? 1 : 0) + (st.nfwd / st.H < bud ? " ✓" : " ✗"));
      RB.setRO(scene, "gmin", gmin > 1 ? "none: H too short" : RB.fmt(gmin, 2) + (st.mode === "sync" ? " (sync ignores g)" : st.g >= gmin ? " ✓" : " ✗"));
      var modeTxt = { sync: "Synchronous: the robot empties the queue, then waits the whole latency for the next chunk. ", async: "Async: a request leaves when fewer than g·H actions remain; actions that expired during the call are dropped. ", rtc: "Async + RTC: as async, but the new chunk is blended into what is left of the old one, so switches stay smooth. " }[st.mode];
      document.getElementById(id + "-note").textContent = modeTxt + (st.preset && PRESETS[st.preset] ? PRESETS[st.preset].note : "Custom settings: no paper behind these numbers.");
      api.meta("Δt = " + RB.fmt(bud, 1) + " ms · chunk = " + RB.fmt(st.H * bud / 1000, 2) + " s · latency ≈ " + Math.round(lat) + " ms");
      ctl.querySelector("#" + id + "-g").disabled = st.mode === "sync";
      drawRegimes(); draw();
    }

    function drawRegimes() {
      var R = regimes(st), cur = st.H === 1 ? "single" : "chunk", mx = Math.max.apply(null, R.map(function (r) { return r.gpu; }));
      regHost.innerHTML = '<table class="sb-table sb-table--compact"><thead><tr><th scope="col">Regime</th><th scope="col">Calls</th><th scope="col">Compute</th><th scope="col">Deadline</th><th scope="col">Plan age</th></tr></thead><tbody>' +
        R.map(function (r) {
          var w = Math.max(2, Math.round(100 * Math.log(1 + r.gpu) / Math.log(1 + mx)));
          return "<tr" + (r.id === cur ? ' aria-current="true" style="background:var(--accent-soft)"' : "") + '><th scope="row">' + r.name + '<br><span class="rb-mono rb-muted">' + r.h + " · " + r.eq + "</span></th><td class=\"rb-mono\">" + r.calls + '</td><td><span class="rb-mono">' + RB.fmt(r.gpu / 1000, 1) + ' s</span><span style="display:block;height:6px;border-radius:3px;background:var(--data-2);width:' + w + '%"></span></td><td>' +
            (r.ok == null ? '<span class="rb-muted">' + r.test + "</span>" : '<span class="rb-mono" style="color:var(--' + (r.ok ? "good" : "bad") + ')">' + (r.ok ? "✓ " : "✗ ") + "</span>" + r.test) + '</td><td class="rb-mono">' + (r.stale >= 1000 ? RB.fmt(r.stale / 1000, r.stale >= 9950 ? 0 : 2) + " s" : Math.round(r.stale) + " ms") + "</td></tr>";
        }).join("") + "</tbody></table>";
    }

    function drawChart() {
      chartHost.innerHTML = "";
      var bud = 1000 / st.f, lat = st.nfwd + st.net, ymax = Math.ceil(bud * 3), pts = [], ptsQ = [], ptsB = [];
      for (var h = 1; h <= 100; h++) { pts.push([h, Math.min(ymax, st.nfwd / h)]); ptsQ.push([h, st.g > 0 ? Math.min(ymax, lat / (st.g * h)) : ymax]); ptsB.push([h, bud]); }
      StudyBench.lineChart(chartHost, {
        title: "Time per action against the control period", x: { label: "Chunk length H", min: 1, max: 100 }, y: { label: "ms per action", min: 0, max: ymax, fmt: function (v) { return String(Math.round(v)); } },
        series: [{ name: "N_fwd / H (P04)", color: "data-2", points: pts }, { name: "ℓ / (g·H) (X2)", color: "data-5", points: ptsQ }, { name: "budget 1/f", color: "data-4", points: ptsB, dash: true }],
        directLabels: false,
        caption: "A chunk length is feasible where a curve sits below the dashed budget. Your H is " + st.H + ". Values above " + ymax + " ms are clipped."
      });
    }
    function chartSoon() { clearTimeout(chartT); chartT = setTimeout(drawChart, 150); }
    function computeSoon() { clearTimeout(simT); simT = setTimeout(function () { compute(); chartSoon(); }, 40); }

    /* ----- timeline canvas ----- */
    function draw() {
      if (!res || !cv.isConnected) return;
      var P = RB.pal(), W = Math.max(300, Math.min(900, cv.parentNode.clientWidth || 720)), narrow = W < 520, mono = font("mono"), body = font("body");
      var lw = narrow ? 56 : 84, pw = W - lw - 12, top = 26, subH = st.sub ? 16 : 0, sH = 22, rH = 18, qH = narrow ? 52 : 64, aH = narrow ? 80 : 100, gap = 12;
      var ySub = top, yS = top + subH + (subH ? 6 : 0), yR = yS + sH + gap, yQ = yR + rH + gap, yA = yQ + qH + gap, Ht = yA + aH + 30;
      var c = RB.canvas(cv, W, Ht), sx = function (t) { return lw + t / TVIEW * pw; }, lim = playT == null ? TVIEW : playT;
      c.fillStyle = P.surface; c.fillRect(0, 0, W, Ht);
      c.font = "500 11px " + mono; c.fillStyle = P["ink-3"];
      c.fillText(st.mode === "sync" ? "synchronous" : st.mode === "rtc" ? "async + RTC blend" : "async, g = " + st.g.toFixed(2), lw, 15);
      c.textAlign = "right"; c.fillText(res.calls.filter(function (k) { return k.sent < TVIEW; }).length + " calls in 8 s", W - 12, 15); c.textAlign = "left";
      function label(txt, y, h) { c.fillStyle = P["ink-2"]; c.font = "600 " + (narrow ? 11 : 12) + "px " + body; c.fillText(txt, 4, y + h / 2 + 4); }
      [[yS, sH], [yR, rH], [yQ, qH], [yA, aH]].forEach(function (b) { c.fillStyle = P["surface-sunk"]; c.fillRect(lw, b[0], pw, b[1]); });
      label("Policy", yS, sH); label("Robot", yR, rH); label("Queue", yQ, qH); label(narrow ? "Action" : "Action", yA, aH);
      /* slow subgoal loop (π0.7) */
      if (st.sub) {
        label("Subgoal", ySub, subH);
        for (var s = 0; s <= TVIEW; s += 4000) { if (s > lim) break; var xs = sx(s); c.fillStyle = P["data-6"]; c.beginPath(); c.moveTo(xs, ySub + 2); c.lineTo(xs + 6, ySub + subH / 2); c.lineTo(xs, ySub + subH - 2); c.lineTo(xs - 6, ySub + subH / 2); c.closePath(); c.fill(); c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; if (!narrow && s < TVIEW - 1500) c.fillText("new subgoal image", xs + 9, ySub + subH / 2 + 4); }
      }
      /* policy calls: network half, compute, network half */
      res.calls.forEach(function (k, n) {
        if (k.sent > lim) return;
        var a = k.sent, b1 = a + (k.arrive - a - k.nf) / 2, b2 = b1 + k.nf, e = Math.min(k.arrive, lim, TVIEW);
        c.fillStyle = P["line-strong"]; c.fillRect(sx(a), yS + 7, Math.max(0, sx(Math.min(b1, e)) - sx(a)), sH - 14);
        if (e > b1) { c.fillStyle = P["data-2"]; c.globalAlpha = n % 2 ? 0.7 : 1; c.fillRect(sx(b1), yS + 3, Math.max(1, sx(Math.min(b2, e)) - sx(b1) - 1), sH - 6); c.globalAlpha = 1; }
        if (e > b2) { c.fillStyle = P["line-strong"]; c.fillRect(sx(b2), yS + 7, Math.max(0, sx(e) - sx(b2)), sH - 14); }
      });
      /* robot lane and queue */
      var dtp = res.dt / TVIEW * pw, gl = st.g * st.H;
      res.ticks.forEach(function (k) {
        if (k.t > lim) return;
        c.fillStyle = k.idle ? P.bad : P["data-1"]; c.globalAlpha = k.idle ? 0.85 : (k.chunk % 2 ? 0.5 : 0.95);
        c.fillRect(sx(k.t), yR + 2, Math.max(1, dtp + 0.3), rH - 4); c.globalAlpha = 1;
      });
      var qy = function (v) { return yQ + qH - 4 - v / Math.max(1, st.H) * (qH - 10); };
      c.strokeStyle = P["line-strong"]; c.setLineDash([4, 3]); c.lineWidth = 1;
      if (st.mode !== "sync") { c.beginPath(); c.moveTo(lw, qy(gl)); c.lineTo(lw + pw, qy(gl)); c.stroke(); }
      c.setLineDash([]); c.fillStyle = P["ink-3"]; c.font = "500 10px " + mono; c.textAlign = "right";
      c.textAlign = "left"; c.fillText("max " + st.H, 4, yQ + qH / 2 + 18); if (st.mode !== "sync") { c.fillStyle = P["ink-3"]; c.fillText("g·H " + RB.fmt(gl, gl < 10 ? 1 : 0), 4, yQ + qH / 2 + 30); }
      c.strokeStyle = P["data-1"]; c.lineWidth = 1.8; c.beginPath(); var on = false;
      res.ticks.forEach(function (k) { if (k.t > lim) return; var x = sx(k.t), y = qy(k.q); if (on) { c.lineTo(x, y); } else { c.moveTo(x, y); on = true; } c.lineTo(x + dtp, y); }); c.stroke();
      /* action lane: target and executed */
      var ay = function (v) { return yA + aH / 2 - v / 1.1 * (aH / 2 - 6); };
      c.strokeStyle = P["ink-3"]; c.setLineDash([5, 4]); c.lineWidth = 1.5; c.beginPath();
      for (var t = 0; t <= TVIEW; t += 20) { var yv = ay(target(t, st.push)); if (t) c.lineTo(sx(t), yv); else c.moveTo(sx(t), yv); } c.stroke(); c.setLineDash([]);
      c.strokeStyle = P["data-3"]; c.lineWidth = 2; c.beginPath(); on = false;
      res.ticks.forEach(function (k) { if (k.t > lim || k.v == null) { return; } var y = ay(k.v); if (on) c.lineTo(sx(k.t), y); else { c.moveTo(sx(k.t), y); on = true; } }); c.stroke();
      res.ticks.forEach(function (k) { if (k.t > lim || !k.sw || k.jump < 0.04) return; c.strokeStyle = P.warn; c.lineWidth = 1.5; c.beginPath(); c.arc(sx(k.t), ay(k.v), 5, 0, Math.PI * 2); c.stroke(); });
      /* push marker and reaction */
      if (st.push) {
        c.strokeStyle = P.ink; c.lineWidth = 1; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(sx(TPUSH), yR); c.lineTo(sx(TPUSH), yA + aH); c.stroke(); c.setLineDash([]);
        c.fillStyle = P.ink; c.font = "600 11px " + body; c.fillText("push", sx(TPUSH) + 4, yA + 12);
        if (res.react != null && TPUSH + res.react <= lim) { var xr = sx(TPUSH + res.react); c.strokeStyle = P.good; c.lineWidth = 2; c.beginPath(); c.moveTo(sx(TPUSH), yA + aH - 8); c.lineTo(xr, yA + aH - 8); c.stroke(); c.fillStyle = P.good; c.fillRect(xr - 1, yA + aH - 13, 2, 10); c.fillStyle = P["ink-2"]; c.font = "500 10px " + mono; c.fillText(Math.round(res.react) + " ms", Math.min(xr + 4, W - 50), yA + aH - 12); }
      }
      /* axis and playhead */
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; var yT = yA + aH + 16;
      for (var sec = 0; sec <= 8; sec += narrow ? 2 : 1) { c.textAlign = sec === 0 ? "left" : sec === 8 ? "right" : "center"; c.fillText(sec + " s", sx(sec * 1000), yT); }
      c.textAlign = "left";
      if (playT != null) { c.strokeStyle = P.accent; c.lineWidth = 2; c.beginPath(); c.moveTo(sx(playT), top); c.lineTo(sx(playT), yA + aH); c.stroke(); }
    }

    /* ----- replay ----- */
    function stop() { if (raf) cancelAnimationFrame(raf); raf = 0; }
    function play() {
      stop(); var t0 = performance.now(), speed = 2;
      api.live("running", "Replaying at 2× speed");
      (function tick(now) {
        playT = Math.min(TVIEW, (now - t0) * speed); draw();
        if (playT >= TVIEW) { playT = null; raf = 0; runs++; draw(); api.live("paused", "Replayed 8 s"); return; }
        raf = requestAnimationFrame(tick);
      })(t0);
    }

    function manual() { st.preset = null; st.sub = false; pressSeg(ctl, id + "-pre", "__none"); }
    function applyPreset(k) {
      var p = PRESETS[k]; if (!p) return;
      st.preset = k; st.nfwd = p.nfwd; st.net = p.net; st.H = p.H; st.f = p.f; st.g = p.g; st.mode = p.mode; st.sub = !!p.sub;
      ["nfwd", "net", "H", "f", "g"].forEach(function (key) { setSlider(key, st[key]); });
      pressSeg(ctl, id + "-mode", st.mode);
    }
    bindSeg(ctl, id + "-pre", function (v) { stop(); playT = null; applyPreset(v); compute(); chartSoon(); });
    bindSeg(ctl, id + "-mode", function (v) { st.mode = v; stop(); playT = null; compute(); });
    RB.bindSlider(ctl, id + "-nf", null, function (v) { st.nfwd = v; manual(); stop(); playT = null; computeSoon(); });
    RB.bindSlider(ctl, id + "-net", null, function (v) { st.net = v; manual(); stop(); playT = null; computeSoon(); });
    RB.bindSlider(ctl, id + "-h", null, function (v) { st.H = v; manual(); stop(); playT = null; computeSoon(); });
    RB.bindSlider(ctl, id + "-f", null, function (v) { st.f = v; manual(); stop(); playT = null; computeSoon(); });
    RB.bindSlider(ctl, id + "-g", function (v) { return (+v).toFixed(2); }, function (v) { st.g = v; stop(); playT = null; computeSoon(); });
    ctl.querySelector("#" + id + "-push").addEventListener("change", function (e) { st.push = e.target.checked; stop(); playT = null; compute(); });
    ctl.querySelector("#" + id + "-seed").addEventListener("click", function () { seed++; stop(); playT = null; compute(); });
    ctl.querySelector("#" + id + "-go").addEventListener("click", play);
    if (window.ResizeObserver) { ro = new ResizeObserver(function () { var w = scene.clientWidth; if (Math.abs(w - lastW) < 2) return; lastW = w; draw(); chartSoon(); }); ro.observe(scene); }
    compute(); drawChart();
    RB.onTheme(function () { if (cv.isConnected) { draw(); drawChart(); } });

    function state() { return { preset: st.preset, mode: st.mode, H: st.H, f: st.f, g: st.g, net: st.net, nfwd: st.nfwd, playing: !!raf, runs: runs, idle: res ? res.idle : 0 }; }
    return {
      state: state,
      destroy: function () { stop(); clearTimeout(chartT); clearTimeout(simT); if (ro) ro.disconnect(); },
      demo: function () {
        var q = function (s) { return scene.querySelector(s) || ctl.querySelector(s); }, S = state;
        return [
          { target: q("#" + id + "-tl"), title: "Four lanes, one clock", text: "Top: policy calls. Then the robot, the action queue and the executed action. A 73 ms call hides inside a 1 s chunk, so the robot never idles." },
          { target: q("#" + id + "-pre"), title: "A slow world action model", text: "DreamZero needs about 150 ms per chunk of 48 actions at 30 Hz. Async execution still hides it.", do: function (a) { return a.click(q("#" + id + '-pre [value="dz"]')); }, task: "Choose the DreamZero preset", expect: function () { return S().preset === "dz"; } },
          { target: q("#" + id + "-mode"), title: "Wait for every chunk", text: "Synchronous execution empties the queue, then waits. Red gaps appear in the robot lane after every chunk.", do: function (a) { return a.click(q("#" + id + '-mode [value="sync"]')); }, task: "Choose Synchronous execution", expect: function () { return S().mode === "sync"; } },
          { target: q("#" + id + "-h"), title: "Chunks shorter than the call", text: "At H = 4 a chunk lasts 133 ms but a call takes 150 ms. P04's test fails and idling dominates.", do: function (a) { return a.set(q("#" + id + "-h"), 4); }, task: "Set the chunk H to 4", expect: function () { return S().H <= 4; } },
          { target: q("#" + id + "-pre"), title: "Blend at the switch", text: "The RTC preset overlaps thinking and acting and blends each new chunk into the old one. Orange rings mark jumps.", do: function (a) { return a.click(q("#" + id + '-pre [value="rtc"]')); }, task: "Choose the RTC preset", expect: function () { return S().preset === "rtc"; } },
          { target: q("#" + id + "-go"), title: "Watch the push", text: "At 3 s the target jumps. The green bar shows how long the robot keeps executing plans made before the push.", do: function (a) { return a.click(q("#" + id + "-go")).then(function () { return a.until(function () { return !S().playing; }, 9000); }); }, task: "Press Replay and watch the push", expect: function () { return S().runs > 0 && !S().playing; } },
          { target: q("#" + id + "-net"), title: "Your turn", text: "Add 100, then 200 ms of network delay, as RTC's experiments did. Compare reaction time and jumps with Drop stale." }
        ];
      }
    };
  }

  RB.station({
    id: SID, name: "Control-loop budget", sub: "07 · 11",
    refs: ["X2 §4.4, Alg. 1", "P04 §4.5, eq. 33–36", "X1 §7"], prov: "Simplified: tick-based toy loop",
    summary: "A policy needs time to produce each chunk while the robot keeps consuming actions. Set the call time, chunk length, control rate and queue threshold, then see idling, staleness and reaction to a push.",
    notice: [
      "A chunk is feasible only if the call finishes before the chunk runs out: N_fwd/H < 1/f_ctrl.",
      "Asking earlier (larger g) hides latency but costs more calls per second.",
      "Long chunks save compute but act on older observations, so reaction slows.",
      "Dropping stale actions makes jumps at switches; RTC-style blending smooths them."
    ],
    card: "Balance call time, chunk length and control rate, then watch the robot idle, lag or react.",
    terms: {
      "chunk-staleness": { name: "chunk staleness", aliases: ["observation age", "stale chunk"], group: "actions", def: "How old the observation behind the executing action is; it grows along a chunk and with inference latency.", note: "Chunked control amortizes a large model, but staleness shows when the world changes mid-chunk.", ref: "P04 §4.5.2 · X2 §4.4", scene: "system", focus: ["action-chunk", "controller"], look: "an old plan still executing", uses: ["action-chunk"] }
    },
    ledger: [
      { where: "Lab · Control-loop budget · N_fwd", source: "P04 writes N_fwd(K) as a function of the chunk length", page: "The station keeps N_fwd constant in H: one parallel pass per chunk", why: "Flow and diffusion heads decode a whole chunk in one pass; the cost of longer chunks is small next to the backbone.", kind: "Simplified" },
      { where: "Lab · Control-loop budget · notation", source: "P04 §4.5 calls the replan period K with H = K; X2 writes H_a", page: "The station writes H and labels the slider 'Chunk H (P04: K)'", why: "On this site K counts denoising steps.", kind: "Our choice" },
      { where: "Lab · Control-loop budget · toy world", source: "Real policies track real scenes", page: "Chunks follow a known sine reference plus a random offset and drift; a push of 0.5 is visible only to chunks planned after 3 s; latency jitters by 10%", why: "Isolates timing effects: idling, staleness and switch jumps.", kind: "Simplified" },
      { where: "Lab · Control-loop budget · RTC", source: "RTC inpaints the next chunk with guided denoising under a soft mask (arXiv 2506.07339)", page: "The station blends the outputs of the old and new chunk with the same soft-mask shape", why: "Same effect on the switch, no network in the browser.", kind: "Simplified" },
      { where: "Lab · Control-loop budget · presets", source: "Fast-WAM and π0.7 do not state a control rate; DreamZero, Fast-WAM and RTC do not state a queue threshold", page: "Fast-WAM at 30 Hz, π0.7 at 50 Hz (as π0), g = 0.5 everywhere (π0.7: execute 25 of 50)", why: "Keeps presets comparable; each preset note says which numbers come from the paper.", kind: "Our choice" },
      { where: "Lab · Control-loop budget · DreamZero", source: "P04 Table 1 places DreamZero in the single-step regime; the DreamZero paper predicts 48-action chunks at 30 Hz", page: "The preset uses chunks of 48", why: "The station follows the method paper's action horizon.", kind: "Sources disagree" },
      { where: "Lab · Control-loop budget · regimes table", source: "P04 eq. 36: cached cost grows linearly in the memory M(t)", page: "Interactive cost grows linearly from N_fwd to 2·N_fwd over the task; open-loop uses the same N_fwd once", why: "Illustrates the shape of eq. 33–36 on one toy model, not measured costs.", kind: "Simplified" }
    ],
    mount: mount
  });
})();
