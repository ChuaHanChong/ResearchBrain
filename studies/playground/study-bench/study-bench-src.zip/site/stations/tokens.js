/* Interactive Lab · Action tokenizer station. Sources: P02 §IV-A, §IV-D.3; X2 §5.1; FAST (arXiv 2501.09747); RT-2 (2307.15818);
   OpenVLA (2406.09246); VQ-BeT (2403.03181). A 7-D, one-second action chunk is tokenized three ways, decoded token by token
   and compared: token count, reconstruction error and sequential decoding time. Everything below is a small toy. */
(function () {
  "use strict";
  var RB = window.RB;
  var SID = "tokens", D = 7, NW = 10, NS = 5; /* 7 action dims; VQ windows of 0.1 s, each resampled to 5 points per dim */
  var DIMS = ["x", "y", "z", "roll", "pitch", "yaw", "grip"];
  var TOKC = { bins: "data-1", fast: "data-2", vq: "data-3" };
  var TOKN = { bins: "256-bin tokens", fast: "FAST tokens", vq: "VQ latent codes" };
  var PRESETS = [{ value: "reach", label: "Reach" }, { value: "grasp", label: "Grasp" }, { value: "wipe", label: "Wipe" }, { value: "noisy", label: "Noisy teleop" }, { value: "hold", label: "Hold still" }];
  var BIN_OPTS = [8, 16, 32, 64, 128, 256];

  /* StudyBench.segmented calls onChange(value, button); read the button's value directly */
  function bindSeg(root, id, cb) { var el = root.querySelector("#" + id); StudyBench.segmented(el, function (v, b) { cb(b && b.value ? b.value : v); }); return el; }
  function pressSeg(root, id, v) { RB.$$("#" + id + " button", root).forEach(function (b) { var on = b.value === v; b.setAttribute("aria-pressed", on ? "true" : "false"); b.tabIndex = on ? 0 : -1; }); }
  function font(kind) { return getComputedStyle(document.body).getPropertyValue(kind === "mono" ? "--font-mono" : "--font-body"); }

  /* ---------- trajectories: normalized actions in [-1, 1], one row per dimension, H samples over 1 s ---------- */
  function mj(a, b, s) { s = RB.clamp(s, 0, 1); return a + (b - a) * (10 * s * s * s - 15 * s * s * s * s + 6 * s * s * s * s * s); }
  var REACH_A = [-0.55, 0.35, 0.5, 0.1, -0.2, 0.3], REACH_B = [0.45, -0.3, -0.35, -0.25, 0.3, -0.4];
  function preset(name, H) {
    var R = RB.rng(11), tr = [];
    for (var d = 0; d < D; d++) {
      var row = [];
      for (var k = 0; k < H; k++) {
        var t = H > 1 ? k / (H - 1) : 0, v;
        if (name === "hold") v = d === 6 ? 0.8 : [0.3, -0.2, 0.1, 0, 0.15, -0.1][d];
        else if (name === "wipe") v = d === 0 ? mj(-0.4, 0.4, t) : d === 1 ? 0.6 * Math.sin(2 * Math.PI * 3 * t) : d === 2 ? -0.5 : d === 5 ? 0.1 * Math.sin(2 * Math.PI * 3 * t + 1) : d === 6 ? -0.8 : 0.05 * d;
        else if (name === "grasp") v = d === 6 ? (t < 0.65 ? 0.8 : -0.8) : d === 2 ? mj(0.5, -0.6, t / 0.6) + mj(0, 0.7, (t - 0.7) / 0.3) : mj(REACH_A[d], REACH_B[d], t / 0.6);
        else v = d === 6 ? 0.8 : mj(REACH_A[d], REACH_B[d], (t - 0.1) / 0.8);
        if (name === "noisy") v += 0.04 * R.normal();
        row.push(RB.clamp(v, -1, 1));
      }
      tr.push(row);
    }
    return tr;
  }
  /* training corpus for BPE and the VQ codebooks: random reaches with one gripper switch (no oscillation, no noise) */
  function corpusTraj(R, H) {
    var tr = [];
    for (var d = 0; d < D; d++) {
      var a = R() * 1.4 - 0.7, b = R() * 1.4 - 0.7, t0 = R() * 0.3, t1 = 0.6 + R() * 0.4, sw = 0.3 + R() * 0.6, g0 = R() < 0.5 ? 0.8 : -0.8, row = [];
      for (var k = 0; k < H; k++) { var t = k / (H - 1); row.push(d === 6 ? (t < sw ? g0 : -g0) : mj(a, b, (t - t0) / (t1 - t0))); }
      tr.push(row);
    }
    return tr;
  }
  function resample(tr, H) {
    return tr.map(function (row) { var n = row.length, out = []; for (var k = 0; k < H; k++) { var x = H > 1 ? k / (H - 1) * (n - 1) : 0, i = Math.floor(x), f = x - i; out.push(i + 1 < n ? row[i] + (row[i + 1] - row[i]) * f : row[n - 1]); } return out; });
  }

  /* ---------- tokenizer 1: uniform bins (RT-2 / OpenVLA style), one token per dimension per step ---------- */
  function tokBins(tr, B) {
    var H = tr[0].length, idx = tr.map(function (r) { return r.map(function (v) { return RB.clamp(Math.floor((v + 1) / 2 * B), 0, B - 1); }); });
    var val = function (i) { return -1 + (i + 0.5) * 2 / B; };
    return {
      n: D * H, cover: null, mat: idx, units: D * H,
      partial: function (k) { var steps = Math.floor(k / D), rem = k % D; return idx.map(function (r, d) { return r.map(function (i, t) { return t < steps || (t === steps && d < rem) ? val(i) : null; }); }); }
    };
  }

  /* ---------- tokenizer 2: FAST = DCT per dimension -> scale and round -> low-frequency-first flatten -> BPE ---------- */
  var cosCache = {};
  function cosM(H) { if (cosCache[H]) return cosCache[H]; var M = []; for (var j = 0; j < H; j++) { var r = new Float64Array(H), s = j === 0 ? Math.sqrt(1 / H) : Math.sqrt(2 / H); for (var n = 0; n < H; n++) r[n] = s * Math.cos(Math.PI * (n + 0.5) * j / H); M.push(r); } return (cosCache[H] = M); }
  function dct(x) { var H = x.length, M = cosM(H), o = []; for (var j = 0; j < H; j++) { var s = 0; for (var n = 0; n < H; n++) s += M[j][n] * x[n]; o.push(s); } return o; }
  function idct(c) { var H = c.length, M = cosM(H), o = []; for (var n = 0; n < H; n++) { var s = 0; for (var j = 0; j < H; j++) s += M[j][n] * c[j]; o.push(s); } return o; }
  function fastSyms(tr, g) { var H = tr[0].length, C = tr.map(function (r) { return dct(r).map(function (v) { return Math.round(v * g); }); }), seq = []; for (var j = 0; j < H; j++) for (var d = 0; d < D; d++) seq.push(C[d][j]); return { C: C, seq: seq }; }
  var bpeCache = {};
  function trainBPE(H, g) {
    var key = H + "|" + g; if (bpeCache[key]) return bpeCache[key];
    var R = RB.rng(5), base = new Map(), nb = 0, S = [];
    for (var i = 0; i < 60; i++) S.push(fastSyms(corpusTraj(R, H), g).seq.map(function (v) { if (!base.has(v)) base.set(v, nb++); return base.get(v); }));
    var merges = [], len = [], next = nb; for (var b0 = 0; b0 < nb; b0++) len.push(1);
    while (next < 1024) {
      var cnt = new Map(), best = -1, bc = 1;
      for (i = 0; i < S.length; i++) { var s = S[i]; for (var k = 0; k + 1 < s.length; k++) { var pk = s[k] * 65536 + s[k + 1], c = (cnt.get(pk) || 0) + 1; cnt.set(pk, c); if (c > bc) { bc = c; best = pk; } } }
      if (bc < 2) break;
      var a = Math.floor(best / 65536), b = best % 65536; merges.push([a, b, next]); len.push(len[a] + len[b]);
      for (i = 0; i < S.length; i++) S[i] = mergeSeq(S[i], a, b, next);
      next++;
    }
    return (bpeCache[key] = { base: base, merges: merges, len: len, vocab: next });
  }
  function mergeSeq(s, a, b, id) { var o = []; for (var k = 0; k < s.length; k++) { if (k + 1 < s.length && s[k] === a && s[k + 1] === b) { o.push(id); k++; } else o.push(s[k]); } return o; }
  function tokFast(tr, g, useBpe) {
    var H = tr[0].length, fs = fastSyms(tr, g), cover;
    if (useBpe) {
      var bpe = trainBPE(H, g), unk = 1e6, s = fs.seq.map(function (v) { return bpe.base.has(v) ? bpe.base.get(v) : unk++; });
      bpe.merges.forEach(function (m) { s = mergeSeq(s, m[0], m[1], m[2]); });
      cover = s.map(function (id) { return id >= 1e6 ? 1 : bpe.len[id]; });
    } else cover = fs.seq.map(function () { return 1; });
    var zero = [], pos = 0; cover.forEach(function (c) { var z = true; for (var q = pos; q < pos + c; q++) if (fs.seq[q] !== 0) z = false; zero.push(z); pos += c; });
    return {
      n: cover.length, cover: cover, zero: zero, mat: fs.C, units: D * H,
      partial: function (k) {
        var nsym = 0; for (var q = 0; q < Math.min(k, cover.length); q++) nsym += cover[q];
        return fs.C.map(function (row, d) { var c = row.map(function (v, j) { return j * D + d < nsym ? v / g : 0; }); return idct(c); });
      }
    };
  }

  /* ---------- tokenizer 3: residual vector quantization of 0.1 s windows, two codes per window (VQ-BeT uses 2 layers) ---------- */
  function winVec(tr, w) { var H = tr[0].length, v = []; for (var d = 0; d < D; d++) for (var s = 0; s < NS; s++) { var x = (w + s / (NS - 1)) / NW * (H - 1), i = Math.floor(x), f = x - i; v.push(i + 1 < H ? tr[d][i] + (tr[d][i + 1] - tr[d][i]) * f : tr[d][H - 1]); } return v; }
  function nearest(C, v) { var bd = Infinity, bk = 0; for (var k = 0; k < C.length; k++) { var dd = 0, c = C[k]; for (var j = 0; j < v.length; j++) { var e = v[j] - c[j]; dd += e * e; } if (dd < bd) { bd = dd; bk = k; } } return bk; }
  function kmeans(X, K, R) {
    var n = X.length, dim = X[0].length, C = [], A = new Int32Array(n), k, i, j;
    for (k = 0; k < K; k++) C.push(X[Math.floor(R() * n)].slice());
    for (var it = 0; it < 8; it++) {
      for (i = 0; i < n; i++) A[i] = nearest(C, X[i]);
      var Sm = [], N = new Int32Array(K); for (k = 0; k < K; k++) Sm.push(new Float64Array(dim));
      for (i = 0; i < n; i++) { N[A[i]]++; for (j = 0; j < dim; j++) Sm[A[i]][j] += X[i][j]; }
      for (k = 0; k < K; k++) { if (N[k]) for (j = 0; j < dim; j++) C[k][j] = Sm[k][j] / N[k]; else C[k] = X[Math.floor(R() * n)].slice(); }
    }
    return C;
  }
  var vqCache = {};
  function trainVQ(K) {
    if (vqCache[K]) return vqCache[K];
    var R = RB.rng(3), X = [];
    for (var i = 0; i < 160; i++) { var tr = corpusTraj(R, 50); for (var w = 0; w < NW; w++) X.push(winVec(tr, w)); }
    var C1 = kmeans(X, K, R), Xr = X.map(function (v) { var c = C1[nearest(C1, v)]; return v.map(function (x, j) { return x - c[j]; }); });
    return (vqCache[K] = { C1: C1, C2: kmeans(Xr, K, R) });
  }
  function tokVQ(tr, K, offset) {
    var H = tr[0].length, cb = trainVQ(K), codes = [], wins = [];
    for (var w = 0; w < NW; w++) {
      var v = winVec(tr, w), c1 = nearest(cb.C1, v), r = v.map(function (x, j) { return x - cb.C1[c1][j]; }), c2 = nearest(cb.C2, r);
      var full = cb.C1[c1].map(function (x, j) { return x + cb.C2[c2][j]; });
      /* offset head (VQ-BeT): one continuous correction per dimension and window; here the exact mean residual */
      if (offset) for (var d = 0; d < D; d++) { var m = 0; for (var s2 = 0; s2 < NS; s2++) m += (v[d * NS + s2] - full[d * NS + s2]) / NS; for (s2 = 0; s2 < NS; s2++) full[d * NS + s2] += m; }
      codes.push([c1, c2]); wins.push([cb.C1[c1], full]);
    }
    return {
      n: 2 * NW, cover: null, codes: codes, units: 2 * NW,
      partial: function (k) {
        return DIMS.map(function (_, d) {
          var row = [];
          for (var t = 0; t < H; t++) {
            var x = t / Math.max(1, H - 1) * NW, w = Math.min(NW - 1, Math.floor(x)), got = k - 2 * w;
            if (got <= 0) { row.push(null); continue; }
            var vec = wins[w][got >= 2 ? 1 : 0], s = (x - w) * (NS - 1), i = Math.min(NS - 2, Math.floor(s)), f = s - i;
            row.push(vec[d * NS + i] + (vec[d * NS + i + 1] - vec[d * NS + i]) * f);
          }
          return row;
        });
      }
    };
  }

  function tokenize(kind, tr, st) { return kind === "bins" ? tokBins(tr, st.bins) : kind === "fast" ? tokFast(tr, st.gamma, st.bpe) : tokVQ(tr, st.K, st.offset); }
  function errors(tr, rec) { var s = 0, m = 0, n = 0; tr.forEach(function (row, d) { row.forEach(function (v, t) { var e = Math.abs(v - rec[d][t]); s += e * e; m = Math.max(m, e); n++; }); }); return { rmse: Math.sqrt(s / n), max: m }; }

  /* ---------- the station ---------- */
  function mount(api) {
    var id = SID, scene = api.scene, ctl = api.controls;
    var st = { tok: "bins", preset: "reach", hz: 15, bins: 256, gamma: 10, K: 16, offset: false, dec: "ar", ttok: 15, bpe: true, overlay: false };
    var tr = preset("reach", 15), res = {}, play = null, raf = 0, timers = [], ro = null, decodes = 0, lastW = 0;

    scene.innerHTML =
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-traj" aria-label="Seven lanes, one per action dimension, showing the one-second chunk and its reconstruction after tokenization. Drag inside a lane to redraw it."></canvas>' +
      RB.legend([{ c: "ink-3", label: "your chunk", kind: "line" }, { c: TOKC.bins, label: "256 bins", kind: "line" }, { c: TOKC.fast, label: "FAST", kind: "line" }, { c: TOKC.vq, label: "VQ latent", kind: "line" }, { c: "bad-soft", label: "error" }]) +
      '<figcaption class="sb-caption">Gray line = the chunk you give the tokenizer. Colored line = what the robot gets back after decoding. Red shading = the error. Drag inside any lane to redraw that dimension.</figcaption></figure>' +
      RB.readouts([{ id: "tok", k: "Tokens per 1 s chunk" }, { id: "cr", k: "Compression vs bins", u: "×" }, { id: "rmse", k: "Reconstruction RMSE" }, { id: "max", k: "Worst error" }, { id: "steps", k: "Sequential decode steps" }, { id: "time", k: "Decode time", u: "ms" }, { id: "budget", k: "Share of the 1 s chunk" }]) +
      '<figure class="rb-fig"><canvas class="rb-canvas" id="' + id + '-tv" aria-label="What the model actually predicts: the token matrix, the token sequence and the decoding clock"></canvas>' +
      '<figcaption class="sb-caption" id="' + id + '-tvcap">–</figcaption></figure>' +
      '<div id="' + id + '-chart"></div>';
    ctl.innerHTML =
      '<div class="rb-stack">' +
      '<div class="rb-row">' + RB.seg({ id: id + "-tk", label: "Tokenizer", value: "bins", options: [{ value: "bins", label: "256 bins" }, { value: "fast", label: "FAST" }, { value: "vq", label: "VQ latent" }] }) +
      RB.seg({ id: id + "-pre", label: "Trajectory preset", value: "reach", options: PRESETS }) + "</div>" +
      '<div class="rb-row">' + RB.slider({ id: id + "-hz", label: "Control rate (Hz)", min: 5, max: 50, step: 5, value: 15 }) +
      RB.slider({ id: id + "-bins", label: "Bins per dim", min: 0, max: 5, step: 1, value: 5, fmt: function (v) { return BIN_OPTS[v]; } }) +
      RB.slider({ id: id + "-g", label: "FAST scale γ", min: 1, max: 30, step: 1, value: 10 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-bpe" checked> <span>BPE merge</span></label>' +
      RB.seg({ id: id + "-K", label: "VQ codebook size", value: "16", options: [{ value: "16", label: "16 codes" }, { value: "64", label: "64 codes" }, { value: "256", label: "256 codes" }] }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-off"> <span>Offset head</span></label>' + "</div>" +
      '<div class="rb-row">' + RB.seg({ id: id + "-dec", label: "Decoding", value: "ar", options: [{ value: "ar", label: "Autoregressive" }, { value: "par", label: "Parallel" }] }) +
      RB.slider({ id: id + "-tt", label: "ms per decode step", min: 5, max: 40, step: 1, value: 15 }) +
      '<label class="sb-field"><input type="checkbox" id="' + id + '-ov"> <span>Overlay all three</span></label>' +
      '<button class="sb-btn sb-btn--primary" type="button" id="' + id + '-go">Decode chunk ▶</button></div></div>';
    api.side.innerHTML = '<p class="rb-muted" id="' + id + '-note">–</p>' +
      '<h4 class="rb-h5">Numbers from the papers</h4><ul class="rb-notice">' +
      '<li>256 bins per action dimension, one token each <span class="sb-ref">P02 §IV-D.3</span></li>' +
      '<li>OpenVLA: 7 tokens per step, bins span the 1st–99th percentile <span class="sb-ref">arXiv 2406.09246</span></li>' +
      '<li>DROID, 7-D at 15 Hz: 105 binned tokens, 29 with FAST <span class="sb-ref">arXiv 2501.09747</span></li>' +
      '<li>T-shirt folding, 14-D at 50 Hz: 700 binned tokens, 53 with FAST <span class="sb-ref">arXiv 2501.09747</span></li>' +
      '<li>FAST decoding: about 750 ms per chunk; π0 flow head about 100 ms <span class="sb-ref">arXiv 2501.09747</span></li>' +
      '<li>VQ-BeT: 2 residual layers, 8–16 codes; 15.2 ms per step vs 100.7 ms for Diffusion Policy <span class="sb-ref">arXiv 2403.03181</span></li>' +
      "</ul>";

    var cvT = scene.querySelector("#" + id + "-traj"), cvV = scene.querySelector("#" + id + "-tv"), chartHost = scene.querySelector("#" + id + "-chart");
    var geo = null;

    function H() { return tr[0].length; }
    function compute() {
      res = {};
      ["bins", "fast", "vq"].forEach(function (k) { if (k === st.tok || st.overlay) res[k] = tokenize(k, tr, st); });
      play = null;
      readouts();
      drawAll();
    }
    function cur() { return res[st.tok]; }
    function stepsOf(r) { return st.dec === "ar" ? r.n : 1; }
    function readouts() {
      var r = cur(), rec = r.partial(r.n), e = errors(tr, rec), ms = stepsOf(r) * st.ttok;
      RB.setRO(scene, "tok", String(r.n));
      RB.setRO(scene, "cr", RB.fmt(D * H() / r.n, 1));
      RB.setRO(scene, "rmse", RB.fmt(e.rmse, 3));
      RB.setRO(scene, "max", RB.fmt(e.max, 3));
      RB.setRO(scene, "steps", String(stepsOf(r)));
      RB.setRO(scene, "time", String(Math.round(ms)));
      RB.setRO(scene, "budget", Math.round(ms / 10) + "%");
      api.meta(H() + " steps × " + D + " dims = " + D * H() + " numbers");
      var note = {
        bins: "Each number becomes one of " + st.bins + " bin IDs. The token count is always dims × steps, so it grows with the control rate. RT-2 and OpenVLA emit one step (7 tokens) per query (P02 §IV-D.3).",
        fast: "FAST writes each dimension as cosine frequencies, multiplies by γ and rounds. Smooth motion leaves mostly zeros at high frequency, and BPE merges those runs into a few tokens (arXiv 2501.09747).",
        vq: "A learned codebook stores " + st.K + " typical 0.1 s motion snippets. Each window gets a coarse code and a residual code. A few codes cannot store every motion, so VQ-BeT adds a continuous offset head (arXiv 2403.03181)."
      }[st.tok];
      scene.ownerDocument.getElementById(id + "-note").textContent = note;
      scene.querySelector("#" + id + "-tvcap").textContent = {
        bins: "Top: one bin ID per dimension and step. Bottom: the token sequence, one thin token per number. The clock shows decode time against the 1 s the chunk lasts.",
        fast: "Top: rounded DCT coefficients, low frequency on the left; empty cells are zeros. Bottom: tokens after BPE; wide gray tokens are merged runs of zeros.",
        vq: "Top: two code IDs per 0.1 s window (coarse, then residual). Bottom: twenty tokens, whatever the control rate. The clock shows decode time against the 1 s chunk."
      }[st.tok];
      ctl.querySelector("#" + id + "-bins").disabled = st.tok !== "bins";
      ctl.querySelector("#" + id + "-g").disabled = st.tok !== "fast";
      ctl.querySelector("#" + id + "-bpe").disabled = st.tok !== "fast";
      ctl.querySelector("#" + id + "-off").disabled = st.tok !== "vq";
      RB.$$("#" + id + "-K button", ctl).forEach(function (b) { b.disabled = st.tok !== "vq"; });
    }

    /* ----- trajectory lanes ----- */
    function drawTraj() {
      var P = RB.pal(), Wd = Math.max(300, Math.min(760, cvT.parentNode.clientWidth || 720)), narrow = Wd < 480;
      var lw = narrow ? 46 : 54, top = 24, lh = narrow ? 34 : 38, gap = 6, Ht = top + D * (lh + gap) + 18, pw = Wd - lw - 10;
      geo = { lw: lw, top: top, lh: lh, gap: gap, pw: pw, W: Wd, H: Ht };
      var c = RB.canvas(cvT, Wd, Ht), n = H(), mono = font("mono");
      c.fillStyle = P.surface; c.fillRect(0, 0, Wd, Ht);
      var sx = function (t) { return lw + t / Math.max(1, n - 1) * pw; };
      c.font = "500 11px " + mono; c.fillStyle = P["ink-3"]; c.textAlign = "right"; c.fillText(narrow ? "drag to redraw" : "drag inside a lane to redraw it", Wd - 10, 15); c.textAlign = "left";
      c.fillText(n + " steps · " + st.hz + " Hz", lw, 15);
      var r = cur(), shown = play ? r.partial(play.k) : r.partial(r.n);
      for (var d = 0; d < D; d++) {
        var y0 = top + d * (lh + gap), sy = function (v) { return y0 + (1 - v) / 2 * lh; };
        c.fillStyle = P["surface-sunk"]; c.fillRect(lw, y0, pw, lh);
        c.strokeStyle = P.line; c.lineWidth = 1; c.beginPath(); c.moveTo(lw, sy(0)); c.lineTo(lw + pw, sy(0)); c.stroke();
        if (st.tok === "bins" && st.bins <= 32 && !st.overlay) { c.strokeStyle = P["bench-grid"] || P.line; for (var b = 1; b < st.bins; b++) { var yb = sy(-1 + 2 * b / st.bins); c.beginPath(); c.moveTo(lw, yb); c.lineTo(lw + pw, yb); c.stroke(); } }
        if (st.tok === "vq" && !st.overlay) { c.strokeStyle = P["line-strong"]; c.setLineDash([2, 3]); for (var w = 1; w < NW; w++) { var xw = lw + w / NW * pw; c.beginPath(); c.moveTo(xw, y0); c.lineTo(xw, y0 + lh); c.stroke(); } c.setLineDash([]); }
        c.fillStyle = P["ink-2"]; c.font = "600 " + (narrow ? 11 : 12) + "px " + font("body"); c.fillText(DIMS[d], 4, y0 + lh / 2 + 4);
        c.save(); c.beginPath(); c.rect(lw, y0 - 3, pw, lh + 6); c.clip();
        /* error band for the current tokenizer */
        if (!st.overlay) {
          c.fillStyle = P["bad-soft"] || P.bad; c.globalAlpha = 0.9;
          for (var t = 0; t < n; t++) { if (shown[d][t] == null) continue; var xa = sx(t), ya = sy(tr[d][t]), yb2 = sy(shown[d][t]); c.fillRect(xa - Math.max(1, pw / n / 2), Math.min(ya, yb2), Math.max(2, pw / n), Math.max(0.5, Math.abs(ya - yb2))); }
          c.globalAlpha = 1;
        }
        c.strokeStyle = P["ink-3"]; c.lineWidth = 2; c.beginPath(); tr[d].forEach(function (v, t) { if (t) c.lineTo(sx(t), sy(v)); else c.moveTo(sx(t), sy(v)); }); c.stroke();
        var kinds = st.overlay ? ["bins", "fast", "vq"] : [st.tok];
        kinds.forEach(function (k) {
          var rr = k === st.tok ? shown : res[k].partial(res[k].n); c.strokeStyle = P[TOKC[k]]; c.lineWidth = 1.8; c.beginPath(); var on = false;
          rr[d].forEach(function (v, t) { if (v == null) { on = false; return; } var yy = sy(RB.clamp(v, -1.15, 1.15)); if (on) c.lineTo(sx(t), yy); else { c.moveTo(sx(t), yy); on = true; } }); c.stroke();
        });
        c.restore();
      }
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; var yT = top + D * (lh + gap) + 10;
      c.fillText("0 s", lw, yT); c.textAlign = "center"; c.fillText("0.5 s", lw + pw / 2, yT); c.textAlign = "right"; c.fillText("1 s", lw + pw, yT); c.textAlign = "left";
    }

    /* ----- token view: matrix, token strip, decode clock ----- */
    function drawTokens() {
      var P = RB.pal(), Wd = Math.max(300, Math.min(760, cvV.parentNode.clientWidth || 720)), narrow = Wd < 480, mono = font("mono");
      var lw = narrow ? 46 : 54, pw = Wd - lw - 10, rh = narrow ? 12 : 14, mTop = 22, mH = D * rh, sTop = mTop + mH + 30, sH = 26, cTop = sTop + sH + 30, Ht = cTop + 34;
      var c = RB.canvas(cvV, Wd, Ht), r = cur(), n = H(), k = play ? play.k : r.n;
      c.fillStyle = P.surface; c.fillRect(0, 0, Wd, Ht);
      c.font = "500 11px " + mono; c.fillStyle = P["ink-3"];
      c.fillText(st.tok === "bins" ? "bin ID per dim and step" : st.tok === "fast" ? (narrow ? "DCT coefficients: low → high" : "rounded DCT coefficients: low → high frequency") : "codes per 0.1 s window: coarse · residual", lw, 14);
      c.font = "500 " + (narrow ? 10 : 11) + "px " + mono; if (st.tok !== "vq") for (var d = 0; d < D; d++) { c.fillText(DIMS[d], 4, mTop + d * rh + rh - 3); } c.font = "500 11px " + mono;
      c.fillStyle = P["surface-sunk"]; c.fillRect(lw, mTop, pw, mH);
      if (st.tok === "vq") {
        for (var w = 0; w < NW; w++) {
          var x0 = lw + w / NW * pw, ww = pw / NW, dec = Math.max(0, Math.min(2, k - 2 * w));
          c.fillStyle = P[TOKC.vq]; c.globalAlpha = dec === 0 ? 0.08 : dec === 1 ? 0.35 : 0.6; c.fillRect(x0 + 1, mTop + 1, ww - 2, mH - 2); c.globalAlpha = 1;
          c.fillStyle = P.ink; c.textAlign = "center"; c.font = "600 " + (narrow ? 10 : 12) + "px " + mono;
          if (dec >= 1) c.fillText(String(r.codes[w][0]), x0 + ww / 2, mTop + mH / 2 - 2);
          if (dec >= 2) c.fillText(String(r.codes[w][1]), x0 + ww / 2, mTop + mH / 2 + 12);
          c.textAlign = "left";
        }
      } else {
        var cw = pw / n, maxAbs = 1;
        if (st.tok === "fast") r.mat.forEach(function (row) { row.forEach(function (v) { maxAbs = Math.max(maxAbs, Math.abs(v)); }); });
        var decSym = 0; if (st.tok === "fast") { for (var q = 0; q < Math.min(k, r.n); q++) decSym += r.cover[q]; } else decSym = k;
        for (d = 0; d < D; d++) for (var t = 0; t < n; t++) {
          var v = r.mat[d][t], sym = t * D + d, a;
          if (st.tok === "bins") { var nv = -1 + (v + 0.5) * 2 / st.bins; a = Math.abs(nv); c.fillStyle = P[nv < 0 ? "div-neg" : "div-pos"]; }
          else { if (v === 0) continue; a = 0.25 + 0.75 * Math.log(1 + Math.abs(v)) / Math.log(1 + maxAbs); c.fillStyle = P[v < 0 ? "div-neg" : "div-pos"]; }
          c.globalAlpha = (sym < decSym ? 1 : 0.18) * RB.clamp(a, 0.12, 1);
          c.fillRect(lw + t * cw + (cw > 3 ? 0.5 : 0), mTop + d * rh + 0.5, Math.max(1, cw - (cw > 3 ? 1 : 0)), rh - 1);
        }
        c.globalAlpha = 1;
      }
      /* strip */
      c.fillStyle = P["ink-3"]; c.font = "500 11px " + mono; c.fillText(r.n + (narrow ? " tokens, in order" : " tokens in the order the model emits them"), lw, sTop - 8);
      var units = st.tok === "vq" ? r.n : D * n, x = lw;
      for (var i = 0; i < r.n; i++) {
        var wi = (r.cover ? r.cover[i] : 1) / units * pw, done = i < k;
        var zero = st.tok === "fast" && r.zero[i];
        c.fillStyle = zero ? P["surface-strong"] : P[TOKC[st.tok]];
        c.globalAlpha = done ? (zero ? 1 : 0.85) : 0.15; c.fillRect(x, sTop, Math.max(0.6, wi - (wi > 3 ? 1 : 0)), sH); c.globalAlpha = 1;
        if (wi > 3) { c.strokeStyle = zero ? P["line-strong"] : P[TOKC[st.tok]]; c.lineWidth = 1; c.strokeRect(x + 0.5, sTop + 0.5, Math.max(0.5, wi - 2), sH - 1); }
        x += wi;
      }
      /* decode clock */
      var total = stepsOf(r) * st.ttok, elapsed = play ? play.ms : total, scale = Math.max(1000, total) * 1.08, bx = function (ms) { return lw + ms / scale * pw; };
      c.fillStyle = P["ink-3"]; c.fillText("decode clock", lw, cTop - 8);
      c.fillStyle = P["surface-sunk"]; c.fillRect(lw, cTop, pw, 12);
      c.fillStyle = total > 1000 ? P.bad : P[TOKC[st.tok]]; c.fillRect(lw, cTop, bx(Math.min(elapsed, total)) - lw, 12);
      c.strokeStyle = P.ink; c.lineWidth = 1.5; c.beginPath(); c.moveTo(bx(1000), cTop - 4); c.lineTo(bx(1000), cTop + 16); c.stroke();
      c.fillStyle = P["ink-2"]; c.textAlign = "right"; c.fillText(narrow ? "1 s chunk" : "1 s = chunk length", bx(1000) + 4, cTop - 8); c.textAlign = "left";
      c.fillStyle = P["ink-2"]; c.fillText(Math.round(Math.min(elapsed, total)) + " ms", lw, cTop + 28);
    }
    function drawAll() { if (!cur()) return; drawTraj(); drawTokens(); }

    /* ----- chart: tokens per chunk against control rate ----- */
    function drawChart() {
      chartHost.innerHTML = "";
      var rates = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50], sB = [], sF = [], sV = [];
      rates.forEach(function (hz) { var t2 = resample(tr, hz); sB.push([hz, D * hz]); sF.push([hz, tokFast(t2, st.gamma, true).n]); sV.push([hz, 2 * NW]); });
      StudyBench.lineChart(chartHost, {
        title: "Tokens per one-second chunk", x: { label: "Control rate (Hz)", min: 5, max: 50 }, y: { label: "Tokens", min: 0, max: 360, fmt: function (v) { return String(Math.round(v)); } },
        series: [{ name: "256 bins", color: TOKC.bins, points: sB }, { name: "FAST (γ " + st.gamma + ")", color: TOKC.fast, points: sF }, { name: "VQ, 2 codes", color: TOKC.vq, points: sV, dash: true }],
        caption: "Your chunk, resampled at each rate. Binned tokens grow with the rate; FAST barely does. Compare FAST's reports: 105 → 29 tokens at 15 Hz, 700 → 53 at 50 Hz with 14 dims."
      });
    }
    var chartT = 0;
    function chartSoon() { clearTimeout(chartT); chartT = setTimeout(drawChart, 160); }
    var compT = 0;
    function computeSoon() { clearTimeout(compT); compT = setTimeout(function () { compute(); chartSoon(); }, 60); }

    /* ----- decoding playback ----- */
    function stopPlay() { if (raf) cancelAnimationFrame(raf); raf = 0; }
    function decode() {
      stopPlay();
      var r = cur(), total = stepsOf(r) * st.ttok, speed = total > 5000 ? total / 5000 : 1, t0 = performance.now();
      play = { k: 0, ms: 0 };
      api.live("running", speed > 1 ? "Decoding, " + RB.fmt(speed, 1) + "× faster" : "Decoding");
      (function tick(now) {
        var ms = (now - t0) * speed;
        play.ms = Math.min(ms, total);
        play.k = st.dec === "ar" ? Math.min(r.n, Math.floor(ms / st.ttok)) : (ms >= st.ttok ? r.n : 0);
        drawAll();
        if (ms >= total) { play = null; raf = 0; decodes++; drawAll(); api.live("paused", "Decoded in " + Math.round(total) + " ms"); return; }
        raf = requestAnimationFrame(tick);
      })(t0);
    }

    /* ----- drawing on the lanes ----- */
    var drag = null;
    function evPos(e) { var b = cvT.getBoundingClientRect(), s = geo.W / b.width; return [(e.clientX - b.left) * s, (e.clientY - b.top) * s]; }
    function paint(p) {
      var d = drag.d, y0 = geo.top + d * (geo.lh + geo.gap), n = H();
      var t = Math.round(RB.clamp((p[0] - geo.lw) / geo.pw, 0, 1) * (n - 1)), v = RB.clamp(1 - 2 * (p[1] - y0) / geo.lh, -1, 1);
      var t1 = drag.t == null ? t : drag.t, v1 = drag.t == null ? v : drag.v, lo = Math.min(t, t1), hi = Math.max(t, t1);
      for (var q = lo; q <= hi; q++) tr[d][q] = hi === lo ? v : v1 + (v - v1) * (q - t1) / (t - t1);
      drag.t = t; drag.v = v;
    }
    cvT.addEventListener("pointerdown", function (e) {
      if (!geo) return; var p = evPos(e), d = Math.floor((p[1] - geo.top) / (geo.lh + geo.gap));
      if (d < 0 || d >= D || p[0] < geo.lw - 4) return;
      e.preventDefault(); stopPlay(); play = null; drag = { d: d, t: null }; try { cvT.setPointerCapture(e.pointerId); } catch (x) { }
      st.preset = "custom"; pressSeg(ctl, id + "-pre", "none"); paint(p); compute();
    });
    cvT.addEventListener("pointermove", function (e) { if (!drag) return; paint(evPos(e)); compute(); });
    function endDrag() { if (!drag) return; drag = null; api.live("paused", "Redrawn"); chartSoon(); }
    cvT.addEventListener("pointerup", endDrag); cvT.addEventListener("pointercancel", endDrag);

    /* ----- controls ----- */
    bindSeg(ctl, id + "-tk", function (v) { st.tok = v; stopPlay(); compute(); });
    bindSeg(ctl, id + "-pre", function (v) { st.preset = v; tr = preset(v, st.hz); stopPlay(); compute(); chartSoon(); });
    bindSeg(ctl, id + "-dec", function (v) { st.dec = v; stopPlay(); compute(); });
    bindSeg(ctl, id + "-K", function (v) { st.K = +v; stopPlay(); compute(); });
    RB.bindSlider(ctl, id + "-hz", null, function (v) { st.hz = v; tr = st.preset === "custom" ? resample(tr, v) : preset(st.preset, v); stopPlay(); computeSoon(); });
    RB.bindSlider(ctl, id + "-bins", function (v) { return BIN_OPTS[v]; }, function (v) { st.bins = BIN_OPTS[v]; stopPlay(); compute(); });
    RB.bindSlider(ctl, id + "-g", null, function (v) { st.gamma = v; stopPlay(); computeSoon(); });
    RB.bindSlider(ctl, id + "-tt", null, function (v) { st.ttok = v; stopPlay(); compute(); });
    ctl.querySelector("#" + id + "-bpe").addEventListener("change", function (e) { st.bpe = e.target.checked; stopPlay(); compute(); });
    ctl.querySelector("#" + id + "-off").addEventListener("change", function (e) { st.offset = e.target.checked; stopPlay(); compute(); });
    ctl.querySelector("#" + id + "-ov").addEventListener("change", function (e) { st.overlay = e.target.checked; stopPlay(); compute(); });
    ctl.querySelector("#" + id + "-go").addEventListener("click", decode);
    if (window.ResizeObserver) {
      ro = new ResizeObserver(function () { var w = scene.clientWidth; if (Math.abs(w - lastW) < 2) return; lastW = w; drawAll(); chartSoon(); });
      ro.observe(scene);
    }
    compute(); drawChart();
    RB.onTheme(function () { if (cvT.isConnected) { drawAll(); drawChart(); } });

    function state() { return { tok: st.tok, preset: st.preset, hz: st.hz, dec: st.dec, playing: !!raf, decodes: decodes, overlay: st.overlay, offset: st.offset }; }
    return {
      state: state,
      destroy: function () { stopPlay(); clearTimeout(chartT); clearTimeout(compT); timers.forEach(clearTimeout); if (ro) ro.disconnect(); },
      demo: function () {
        var q = function (s) { return scene.querySelector(s) || ctl.querySelector(s); }, S = state;
        return [
          { target: q("#" + id + "-traj"), title: "One second, seven numbers", text: "Each lane is one action dimension of a 1 s chunk at 15 Hz. With 256 bins the colored line sits on the gray one: 105 tokens." },
          { target: q("#" + id + "-hz"), title: "Bins grow with the rate", text: "At 50 Hz the same second needs 7 × 50 = 350 bin tokens. The decode clock now runs far past the 1 s chunk.", do: function (a) { return a.set(q("#" + id + "-hz"), 50); }, task: "Set the control rate to 50 Hz", expect: function () { return S().hz === 50; } },
          { target: q("#" + id + "-tk"), title: "Compress the frequencies", text: "FAST turns each lane into cosine coefficients. Smooth motion leaves mostly zeros, and BPE merges them: a few dozen tokens remain.", do: function (a) { return a.click(q("#" + id + '-tk [value="fast"]')); }, task: "Choose the FAST tokenizer", expect: function () { return S().tok === "fast"; } },
          { target: q("#" + id + "-go"), title: "Decode coarse to fine", text: "Tokens arrive low frequency first, so the colored line starts as a rough sketch and sharpens as tokens arrive.", do: function (a) { return a.click(q("#" + id + "-go")).then(function () { return a.until(function () { return !S().playing; }, 8000); }); }, task: "Press Decode chunk and watch", expect: function () { return S().decodes > 0 && !S().playing; } },
          { target: q("#" + id + "-pre"), title: "Noise costs tokens", text: "Teleoperation jitter spreads energy over every frequency. Fewer coefficients round to zero, so FAST needs more tokens.", do: function (a) { return a.click(q("#" + id + '-pre [value="noisy"]')); }, task: "Choose the Noisy teleop preset", expect: function () { return S().preset === "noisy"; } },
          { target: q("#" + id + "-tk"), title: "A learned codebook", text: "VQ always emits 20 codes, whatever the rate or the noise. But 16 stored snippets cannot match every motion: the error is several times FAST's.", do: function (a) { return a.click(q("#" + id + '-tk [value="vq"]')); }, task: "Choose the VQ latent tokenizer", expect: function () { return S().tok === "vq"; } },
          { target: q("#" + id + "-off"), title: "Add a continuous offset", text: "VQ-BeT predicts a continuous offset next to the codes. Removing it caused its largest ablation drop. Watch the error fall.", do: function (a) { return a.click(q("#" + id + "-off")); }, task: "Tick Offset head", expect: function () { return S().offset; } },
          { target: q("#" + id + "-dec"), title: "Your turn", text: "Switch decoding to Parallel and compare decode times. Then tick Overlay all three and redraw a lane with the mouse." }
        ];
      }
    };
  }

  RB.station({
    id: SID, name: "Action tokenizer", sub: "07 · 08",
    refs: ["P02 §IV-A, §IV-D.3", "X2 §5.1", "FAST, arXiv 2501.09747"], prov: "Simplified: toy tokenizers on a 7-D chunk",
    summary: "A vision-language-action (VLA) model can only emit tokens. Turn a one-second, 7-D action chunk into 256-bin tokens, FAST tokens or vector-quantized (VQ) codes, then decode it and compare length, error and time.",
    notice: [
      "Binned token count is dimensions × steps, so it rises with the control rate.",
      "FAST's count depends on how smooth the motion is, not on the rate.",
      "A VQ codebook gives a short, fixed length, but its codes are coarse without an offset.",
      "Autoregressive decoding time grows with every token; parallel decoding does not."
    ],
    card: "Tokenize one chunk three ways and watch token count, error and decode time trade off.",
    terms: {
      "residual-vector-quantization": { name: "residual vector quantization", aliases: ["residual VQ", "RVQ", "VQ action tokens"], group: "actions", def: "Encoding a vector as a sum of codebook entries: one code approximates it, the next code approximates what is left over.", note: "VQ-BeT uses two layers of 8–16 codes and adds a continuous offset head to recover precision.", ref: "arXiv 2403.03181", scene: "system", focus: ["action-head", "action-chunk"], look: "a chunk replaced by a few codes", uses: ["action-chunk"] }
    },
    ledger: [
      { where: "Lab · Action tokenizer · VQ", source: "VQ-BeT trains a residual VQ-VAE (encoder, decoder, 2 layers) and predicts a continuous offset", page: "k-means residual codebooks on 0.1 s windows of our toy corpus, no network; the optional offset is the exact mean residual, not a prediction", why: "Shows the fixed length and the out-of-distribution failure without training a network in the browser.", kind: "Simplified" },
      { where: "Lab · Action tokenizer · FAST", source: "FAST trains a 1024-entry BPE vocabulary on a real dataset", page: "BPE trained on 60 toy chunks (reaches and grasps); merging stops when no pair repeats, so fewer than 1024 entries", why: "Keeps training under a fraction of a second per rate.", kind: "Simplified" },
      { where: "Lab · Action tokenizer · decode time", source: "FAST reports about 750 ms per chunk for 30–60 tokens on an RTX 4090 (arXiv 2501.09747)", page: "Decode time = sequential steps × a slider, default 15 ms per step", why: "15 ms lies inside the range that 750 ms over 30–60 tokens implies; the time is not measured.", kind: "Our choice" },
      { where: "Lab · Action tokenizer · dimensions", source: "X2 §5.1 describes RT-1's actions as six 256-bin dimensions for a 6-DoF arm; the RT-1 paper uses 11 dimensions (arm, base, mode)", page: "The station uses 7 dimensions (6 end-effector + gripper), as OpenVLA does", why: "Seven dimensions match the OpenVLA and DROID numbers quoted in the side panel.", kind: "Sources disagree" },
      { where: "Lab · Action tokenizer · normalization", source: "OpenVLA bins between the 1st and 99th percentile; FAST maps those quantiles to [−1, 1]", page: "Actions are already in [−1, 1]; bins are uniform over that range", why: "Both methods start from the same normalized range, so one scale serves all three tokenizers.", kind: "Our choice" }
    ],
    mount: mount
  });
})();
