/* TL;DR scenes · Part B (05–09). Drawn with RB.tl (core/44-tldr-cast.js); width 420, 3–6 beats, captions ≤ 12 words. */
(function () {
  var SC = window.RB.tldr.scene;

  /* 05 · top-down: the clone drifts off the expert's path into states no demo covered; DAgger labels them */
  SC("bc", {
    title: "Behavior cloning drifts; DAgger labels where it went", h: 250,
    draw: function (T) {
      var ex = [[36, 204], [110, 174], [190, 140], [270, 102], [364, 52]];
      /* the band the demonstrations cover: the expert's path offset ±22 */
      var up = [], lo = [];
      ex.forEach(function (p, i) {
        var a = ex[Math.max(0, i - 1)], b = ex[Math.min(ex.length - 1, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], L = Math.sqrt(dx * dx + dy * dy);
        up.push([p[0] + dy / L * 22, p[1] - dx / L * 22]); lo.push([p[0] - dy / L * 22, p[1] + dx / L * 22]);
      });
      var dag = [[232, 146, 244, 118], [270, 156, 284, 128], [298, 186, 314, 160]].map(function (d) { return T.line(d[0], d[1], d[2], d[3], { cls: "t-goodl", arrow: "good" }); }).join("");
      return T.poly(up.concat(lo.reverse()), { a: "tube", cls: "t-good-soft" }) + T.sm(146, 126, "demo data", { a: "tubeL", anchor: "end" }) +
        T.circle(36, 204, 7, { cls: "t-ink", base: true }) + T.sm(36, 234, "start", { anchor: "middle", base: true }) +
        T.rect(352, 30, 48, 14, { cls: "t-pad", rx: 3, base: true }) + T.sm(342, 42, "goal", { anchor: "end", base: true }) +
        T.curve(ex, { a: "exp", cls: "t-ghost", draw: true }) +
        T.rect(236, 176, 170, 62, { a: "zone", cls: "t-bad-soft", rx: 10 }) + T.sm(398, 230, "no demos here", { a: "zoneL", anchor: "end" }) +
        T.curve([[36, 204], [110, 182], [180, 154]], { a: "c1", cls: "s-act", draw: true }) + T.sm(96, 214, "clone", { a: "c1L" }) +
        T.path("M180 154 C 214 140, 262 142, 286 170 S 302 194, 306 200", { a: "c2", cls: "s-act", draw: true }) +
        T.g({ a: "x" }, T.line(300, 196, 316, 212, { cls: "t-badl" }) + T.line(316, 196, 300, 212, { cls: "t-badl" })) +
        T.g({ a: "dg" }, dag) + T.g({ a: "dgL" }, T.sm(328, 148, "expert") + T.sm(328, 164, "labels")) +
        T.curve([[180, 154], [236, 136], [300, 100], [364, 50]], { a: "fix", cls: "s-act", arrow: "act", draw: true });
    },
    beats: [
      { cap: "The expert's path; the demos cover only a band around it.", on: "tube tubeL exp", dur: 2200 },
      { cap: "The clone copies it, slightly off at every step.", on: "c1 c1L", dur: 2000 },
      { cap: "Errors compound: it drifts where the demos never went.", on: "c2 x zone zoneL", dur: 2400 },
      { cap: "DAgger: the expert labels the states the clone visits.", on: "dg dgL", dur: 2400 },
      { cap: "Trained on those labels, the clone pulls back to the goal.", off: "x", on: "fix", cls: "c2:is-dim dg:is-dim", dur: 2600 }
    ]
  });

  /* 06 · two demonstrated ways around a block; regression averages into it; a generative head keeps both */
  SC("heads", {
    title: "Regression averages two ways; a generative head keeps both", h: 250,
    draw: function (T) {
      var S = [210, 226], G = [210, 26];
      var left = [[210, 226], [150, 180], [128, 126], [150, 70], [210, 26]], right = left.map(function (p) { return [420 - p[0], p[1]]; });
      /* noise samples: start as a cloud near the start, end split between the two ways */
      var cloud = [[186, 196], [228, 190], [202, 176], [244, 206], [174, 212], [216, 206], [196, 214], [236, 178], [180, 182], [222, 216], [206, 190], [190, 170]];
      var dots = cloud.map(function (c, i) { return T.circle(c[0], c[1], 5, { a: "d" + i, cls: "f-act" }); }).join("");
      return T.rect(176, 96, 68, 58, { cls: "t-obst", rx: 4, base: true }) + T.sm(210, 130, "block", { anchor: "middle", base: true }) +
        T.circle(S[0], S[1], 7, { cls: "t-ink", base: true }) + T.sm(226, 240, "start", { base: true }) +
        T.rect(186, 12, 48, 12, { cls: "t-pad", rx: 3, base: true }) + T.sm(244, 23, "goal", { base: true }) +
        T.curve(left, { a: "demoL", cls: "t-ghost", draw: true }) + T.curve(right, { a: "demoR", cls: "t-ghost", draw: true }) +
        T.sm(20, 74, "demo A", { a: "dLl" }) + T.sm(340, 74, "demo B", { a: "dRl" }) +
        T.path("M210 219 L210 160", { a: "mean", cls: "t-badl", arrow: "bad", draw: true }) +
        T.g({ a: "cross" }, T.line(198, 150, 222, 170, { cls: "t-badl" }) + T.line(222, 150, 198, 170, { cls: "t-badl" })) +
        T.sm(20, 170, "regression:", { a: "meanL" }) + T.sm(20, 188, "the mean hits it", { a: "meanL2" }) +
        dots + T.sm(262, 184, "noise", { a: "noiseL" }) +
        T.curve(left, { a: "take", cls: "s-act", draw: true, arrow: "act" }) +
        T.chunk(290, 222, 8, { a: "chunk" }) + T.sm(408, 212, "a chunk of H actions", { a: "chunkL", anchor: "end" });
    },
    beats: [
      { cap: "Demonstrations pass the block on the left or the right.", on: "demoL demoR dLl dRl", dur: 2200 },
      { cap: "Regression predicts their mean, straight into the block.", on: "mean cross meanL meanL2", dur: 2200 },
      { cap: "A generative head starts from random noise.", off: "mean cross meanL meanL2", on: "d0 d1 d2 d3 d4 d5 d6 d7 d8 d9 d10 d11 noiseL", dur: 2000 },
      { cap: "K denoising steps pull samples onto the two ways.", off: "noiseL",
        set: "d0.cx=134 d0.cy=110 d1.cx=290 d1.cy=104 d2.cx=140 d2.cy=140 d3.cx=282 d3.cy=142 d4.cx=130 d4.cy=124 d5.cx=286 d5.cy=124 d6.cx=146 d6.cy=96 d7.cx=276 d7.cy=92 d8.cx=136 d8.cy=150 d9.cx=292 d9.cy=134 d10.cx=150 d10.cy=84 d11.cx=270 d11.cy=150", dur: 2400 },
      { cap: "One sample becomes a chunk of H actions.", on: "take chunk chunkL", dur: 2400 }
    ]
  });

  /* 07 · 700 bin tokens → 53 FAST tokens; an action queue drains and asks for the next chunk at threshold g */
  SC("timing", {
    title: "Compact actions and an early request keep the robot busy", h: 252,
    draw: function (T) {
      return T.sm(14, 26, "one 50 Hz chunk", { base: true }) + T.sm(404, 26, "700 bin tokens", { a: "longL", anchor: "end" }) +
        T.chunk(14, 34, 78, { a: "long", w: 4, gap: 1, h: 18 }) +
        T.path("M14 56 L14 78 M403 56 L44 78", { a: "fun", cls: "t-ghostl", draw: true }) +
        T.chunk(14, 80, 6, { a: "fast", w: 4, gap: 1, h: 18 }) + T.sm(56, 94, "FAST: 53 tokens", { a: "fastL" }) +
        T.arm(36, 228, 75, -75, { a: "arm", l1: 40, l2: 34 }) + T.sm(320, 188, "action queue", { a: "qL", anchor: "end" }) +
        T.rect(104, 196, 216, 22, { a: "qbox", cls: "t-ghostl", rx: 4 }) + T.rect(106, 198, 212, 18, { a: "q", cls: "t-tile", rx: 2 }) +
        T.line(166, 190, 166, 226, { a: "g", cls: "t-accl t-dash" }) + T.sm(166, 242, "g", { a: "gL", anchor: "middle" }) +
        T.box(330, 112, 76, 40, "π_θ", { a: "pol", role: "act" }) +
        T.path("M166 188 C 166 140, 250 132, 328 132", { a: "req", arrow: "ink", draw: true }) + T.sm(204, 128, "request", { a: "reqL" }) +
        T.path("M368 154 C 368 196, 300 207, 237 207", { a: "ret", cls: "t-ghostl" }) +
        /* the new chunk is drawn from (0,0) and rides an invisible copy of ret shifted to its top-left corner */
        T.path("M339 146 C 339 188, 271 199, 208 199", { a: "retM", style: "stroke:none;fill:none" }) +
        T.chunk(0, 0, 5, { a: "new", w: 10, gap: 2, h: 16 }) +
        T.sm(404, 242, "no idle", { a: "ok", anchor: "end", cls: "t-sm t-good" });
    },
    beats: [
      { cap: "Binned per dimension, one 50 Hz chunk takes 700 tokens.", on: "long longL", dur: 2200 },
      { cap: "FAST compresses the same chunk to 53 tokens.", on: "fun fast fastL", cls: "long:is-dim", dur: 2400 },
      { cap: "The robot drains its action queue at a fixed rate.", on: "arm qL qbox q g gL", set: "q.width=62", dur: 2600 },
      { cap: "At threshold g, a request for the next chunk fires.", on: "pol req reqL", cls: "req:a-flow", set: "q.width=26", dur: 2600 },
      { cap: "The new chunk lands before the queue empties: no idle.", on: "ret retM ok", move: "new:retM", set: "q.width=100", dur: 2800 }
    ]
  });

  /* 08 · images and words enter one backbone; actions leave as tokens (slow loop) or as a chunk from an action expert */
  SC("vla", {
    title: "A VLA: one backbone, two ways out for actions", h: 270,
    draw: function (T) {
      var img = "", i, j;
      for (i = 0; i < 3; i++) for (j = 0; j < 3; j++) img += T.rect(14 + j * 18, 30 + i * 18, 16, 16, { cls: "fs-vision", rx: 2 });
      var words = ["wipe", "the", "table"].map(function (w, k) { return T.rect(14, 108 + k * 22, 50, 18, { cls: "fs-lang", rx: 4 }) + T.sm(39, 121 + k * 22, w, { anchor: "middle", cls: "t-sm t-ink" }); }).join("");
      return T.g({ a: "img" }, img) + T.sm(39, 98, "image", { a: "imgL", anchor: "middle" }) +
        T.g({ a: "words" }, words) + T.sm(12, 188, "instruction", { a: "wordsL" }) +
        T.line(70, 56, 98, 72, { a: "inA", cls: "s-vision", arrow: "vision" }) + T.line(70, 134, 98, 120, { a: "inB", cls: "s-lang", arrow: "lang" }) +
        T.box(100, 30, 110, 140, "VLM", { role: "ink", sub: "backbone", base: true }) +
        T.line(210, 56, 220, 56, { a: "r1", cls: "s-act" }) + T.chunk(222, 48, 4, { a: "a", each: true, w: 14, gap: 4 }) +
        T.path("M285 46 C 285 22, 190 18, 176 30", { a: "loop", cls: "s-act", arrow: "act", draw: true }) + T.sm(222, 86, "token by token: slow", { a: "r1L" }) +
        T.line(210, 144, 224, 144, { a: "r2", cls: "s-act", arrow: "act" }) + T.box(226, 122, 178, 44, "action expert", { a: "exp", role: "act" }) +
        T.line(315, 166, 315, 200, { a: "r2b", cls: "s-act", arrow: "act" }) + T.chunk(108, 204, 50, { a: "chunk", w: 4, gap: 2 }) + T.sm(300, 194, "50 actions, one pass", { a: "chunkL", anchor: "end" }) +
        T.g({ a: "m1" }, T.sm(14, 252, "route 1:") + T.box(82, 234, 58, 26, "RT-2", { role: "act", small: true }) + T.box(146, 234, 88, 26, "OpenVLA", { role: "act", small: true })) +
        T.g({ a: "m2" }, T.sm(252, 252, "route 2:") + T.box(320, 234, 56, 26, "π0", { role: "act", small: true }));
    },
    beats: [
      { cap: "Image patches and instruction tokens enter one VLM backbone.", on: "img imgL words wordsL inA inB", dur: 2200 },
      { cap: "Route 1: action tokens decode one at a time, a slow loop.", on: "r1 a0 a1 a2 a3 loop r1L", cls: "loop:a-flow", dur: 2600 },
      { cap: "Route 2: an action expert outputs a 50-step chunk in one pass.", on: "r2 exp r2b chunk chunkL", dur: 2600 },
      { cap: "π0 used an action expert; RT-2 and OpenVLA used tokens.", on: "m1 m2", dur: 2800 }
    ]
  });

  /* 09 · SayCan: the LLM's usefulness × the affordance picks a skill; feedback returns to the prompt; the next skill wins */
  SC("planning", {
    title: "SayCan: useful times possible picks the next skill", h: 262,
    draw: function (T) {
      var sk = ["find sponge", "pick sponge", "pick apple", "go to sink"], yc = [88, 116, 144, 172], s = "";
      sk.forEach(function (k, i) {
        s += T.sm(20, yc[i] + 5, k, { base: true }) +
          T.rect(114, yc[i] - 7, 0, 14, { a: "l" + i, cls: "f-lang", rx: 2 }) + T.rect(212, yc[i] - 7, 0, 14, { a: "f" + i, cls: "f-critic", rx: 2 }) +
          T.rect(302, yc[i] - 7, 0, 14, { a: "p" + i, cls: "f-act", rx: 2 });
      });
      return T.say(14, 10, "clean the spill", { a: "say" }) + T.path("M66 38 Q 66 57, 110 57", { a: "sayA", cls: "s-lang", arrow: "lang", draw: true }) +
        T.sm(116, 62, "LLM", { a: "hL" }) + T.sm(212, 62, "× can do", { a: "hF" }) + T.sm(302, 62, "= score", { a: "hP" }) + s +
        T.rect(8, 74, 384, 28, { a: "win", cls: "t-accl", rx: 6 }) +
        T.sm(20, 222, "runs: find sponge", { a: "run" }) +
        T.g({ a: "arm" }, T.table(236, 246, 168) + T.block(306, 230, 20, 16) + T.arm(270, 234, 40, -130, { l1: 60, l2: 28 })) +
        T.path("M336 214 C 380 214, 404 200, 404 160 L404 34 Q404 23 392 23 L306 23", { a: "back", cls: "s-lang", arrow: "lang", draw: true }) + T.say(174, 10, "found a sponge", { a: "fb", w: 128 });
    },
    beats: [
      { cap: "The LLM rates how useful each skill is for “clean the spill”.", on: "say sayA hL l0 l1 l2 l3", set: "l0.width=60 l1.width=50 l2.width=20 l3.width=30", dur: 2400 },
      { cap: "Affordances multiply in: can this skill succeed right now?", on: "hF hP f0 f1 f2 f3 p0 p1 p2 p3", set: "f0.width=62 f1.width=14 f2.width=56 f3.width=62 p0.width=53 p1.width=10 p2.width=16 p3.width=27", dur: 2600 },
      { cap: "The best product wins, and “find sponge” runs.", on: "win run arm", cls: "win:a-glow", dur: 2200 },
      { cap: "Feedback returns to the prompt: found a sponge.", on: "back fb", cls: "back:a-flow", dur: 2400 },
      { cap: "Rescored, “pick sponge” now wins and runs next.", text: "run=runs: pick sponge", set: "l0.width=14 l1.width=66 l2.width=16 p0.width=12 p1.width=60 p2.width=13 f1.width=64 win.y=102", dur: 2800 }
    ]
  });
  /* 10 · in-context learning: a demonstration in the prompt steers a frozen policy; swap it and the action follows */
  SC("icl", {
    title: "A demonstration in context steers a frozen policy", h: 262,
    draw: function (T) {
      /* one demonstration = four small frames; the block travels to the green pad (A) or to the grey bin (B) */
      function demo(id, toRight) {
        var g = "";
        for (var i = 0; i < 4; i++) {
          var x = 14 + i * 64, y = 34, bx = toRight ? 22 + i * 9 : 22 - i * 5.5;
          g += T.rect(x, y, 56, 40, { cls: "t-box", rx: 4 }) + T.line(x + 4, y + 32, x + 52, y + 32, { cls: "t-table" }) +
            T.rect(x + 42, y + 29, 10, 3, { cls: "t-pad", rx: 1 }) + T.rect(x + 4, y + 26, 8, 6, { cls: "t-obst", rx: 1 }) +
            T.rect(x + bx, y + 22 - (i === 1 || i === 2 ? 8 : 0), 9, 9, { cls: "t-block", rx: 1 });
        }
        return T.g({ a: id }, g);
      }
      var lines = "", wts = [1.5, 5, 2.5, 1.5];
      for (var i = 0; i < 4; i++) lines += T.path("M" + (42 + i * 64) + " 76 C " + (42 + i * 64) + " 104, 300 96, 326 84", { a: "att" + i, cls: "s-act", style: "stroke-width:" + wts[i] });
      return T.sm(14, 24, "demonstration in context C", { a: "dL" }) + demo("dA", true) + demo("dB", false) +
        T.box(300, 32, 108, 48, "Policy π_θ", { role: "act", base: true }) + T.sm(408, 22, "θ frozen", { anchor: "end", base: true, a: "lock" }) +
        lines + T.sm(408, 128, "attends to the matching step", { a: "attL", anchor: "end" }) +
        T.table(14, 236, 392, { base: true }) + T.rect(300, 230, 56, 6, { cls: "t-pad", rx: 2, base: true }) + T.sm(328, 254, "pad", { anchor: "middle", base: true }) +
        T.rect(40, 214, 40, 22, { cls: "t-obst", rx: 3, base: true }) + T.sm(60, 254, "bin", { anchor: "middle", base: true }) +
        T.block(176, 214, 20, 22, { a: "blk0" }) + T.block(318, 208, 20, 22, { a: "blkA" }) + T.block(50, 196, 20, 18, { a: "blkB" }) +
        T.arm(210, 232, 100, -100, { a: "arm0", l1: 70, l2: 60 }) + T.arm(210, 232, 55, -85, { a: "armA", grip: "closed", l1: 70, l2: 60 }) + T.arm(210, 232, 150, 55, { a: "armB", grip: "closed", l1: 70, l2: 60 }) +
        T.sm(408, 152, "no weight update", { a: "noW", anchor: "end", cls: "t-sm t-good" });
    },
    beats: [
      { cap: "A demonstration arrives as context; the weights θ stay fixed.", on: "dL dA arm0 blk0", dur: 2400 },
      { cap: "The policy attends to the demo step that matches now.", on: "att0 att1 att2 att3 attL", dur: 2200 },
      { cap: "It acts in a new scene: the block goes to the pad.", on: "armA blkA", off: "arm0 blk0", dur: 2200 },
      { cap: "Swap the demonstration: the action follows it to the bin.", on: "dB armB blkB", off: "dA armA blkA", cls: "att0:a-flow att1:a-flow att2:a-flow att3:a-flow", dur: 2600 },
      { cap: "Nothing was trained; only the context changed.", on: "noW", cls: "lock:a-glow", dur: 2400 }
    ]
  });
})();
