/* TL;DR scenes · Part C (10–12). Drawn with RB.tl (core/44-tldr-cast.js); width 420, 3–6 beats, captions ≤ 12 words. */
(function () {
  var SC = window.RB.tldr.scene;

  /* 10 · three candidate plans, imagined futures, scores; run the best first step, then replan with a narrower spread (CEM) */
  SC("worldmodel", {
    title: "Imagine each candidate, score it, run the best first step", h: 250,
    draw: function (T) {
      var yc = [52, 130, 208], s = "";
      yc.forEach(function (y, i) {
        s += T.line(80, 130, 124, y, { a: "c" + i, cls: "s-act", arrow: "act", draw: true }) +
          T.rect(128, y - 20, 56, 40, { a: "fa" + i, cls: "fs-future t-dash", rx: 4 }) + T.rect(146, y - 6, 12, 12, { a: "ba" + i, cls: "t-block", rx: 2 }) +
          T.line(186, y, 202, y, { a: "fl" + i, cls: "s-future", arrow: "future" }) +
          T.rect(206, y - 20, 56, 40, { a: "fb" + i, cls: "fs-future t-dash", rx: 4 }) + T.rect(232 + (i - 1) * 8, y - 6, 12, 12, { a: "bb" + i, cls: "t-block", rx: 2 }) +
          T.rect(280, y - 8, 0, 16, { a: "s" + i, cls: "t-score", rx: 2 });
      });
      return T.g({ a: "ot" }, T.rect(14, 108, 64, 44, { cls: "fs-vision", rx: 4 }) + T.line(20, 144, 72, 144, { cls: "t-table" }) + T.rect(30, 130, 14, 14, { cls: "t-block", rx: 2 })) +
        T.sm(46, 172, "o_t", { a: "otL", anchor: "middle" }) + s +
        T.sm(128, 22, "imagined futures", { a: "futL" }) + T.sm(280, 22, "score", { a: "sL" }) +
        T.g({ a: "cemL" }, T.sm(280, 124, "replan:") + T.sm(280, 142, "narrower (CEM)"));
    },
    beats: [
      { cap: "From the current frame o_t, sample three candidate action plans.", on: "ot otL c0 c1 c2", dur: 2200 },
      { cap: "The world model imagines the future frames of each plan.", on: "futL fa0 fa1 fa2 ba0 ba1 ba2 fl0 fl1 fl2 fb0 fb1 fb2 bb0 bb1 bb2", dur: 2600 },
      { cap: "A score rates each imagined future.", on: "sL s0 s1 s2", set: "s0.width=40 s1.width=104 s2.width=62", dur: 2200 },
      { cap: "Only the best plan's first action a_t is executed.", cls: "c1:a-glow s1:a-glow fa1:a-glow", dur: 2400 },
      { cap: "Replan next step: CEM samples new candidates closer to the best.", off: "sL s0 s1 s2", on: "cemL",
        set: "c0.y2=84 fa0.y=64 ba0.y=78 fl0.y1=84 fl0.y2=84 fb0.y=64 bb0.y=78 c2.y2=176 fa2.y=156 ba2.y=170 fl2.y1=176 fl2.y2=176 fb2.y=156 bb2.y=170", dur: 2800 }
    ]
  });

  /* 11 · one joint table p(o′, a | o); policy, video, forward and inverse dynamics are four ways to read it */
  SC("wam", {
    title: "One joint distribution, four queries", h: 272,
    draw: function (T) {
      var P = [[0.1, 0.2, 0.1, 0, 0], [0.2, 0.9, 0.4, 0.1, 0], [0.1, 0.4, 1.0, 0.3, 0.1], [0, 0.1, 0.3, 0.7, 0.2], [0, 0, 0.1, 0.2, 0.3]];
      var x0 = 60, y0 = 44, c = 26, grid = "", dots = "", act = "", vid = "", i, j;
      for (i = 0; i <= 5; i++) grid += "M" + (x0 + i * c) + " " + y0 + " V" + (y0 + 5 * c) + " M" + x0 + " " + (y0 + i * c) + " H" + (x0 + 5 * c) + " ";
      for (j = 0; j < 5; j++) for (i = 0; i < 5; i++) if (P[j][i] > 0) dots += T.circle(x0 + i * c + c / 2, y0 + j * c + c / 2, 2 + 8 * P[j][i], { cls: "f-latent" });
      for (i = 0; i < 5; i++) { var cs = 0; for (j = 0; j < 5; j++) cs += P[j][i]; act += T.vbar(x0 + i * c + 5, 214, 16, cs * 14, { cls: "f-act" }); }
      for (j = 0; j < 5; j++) { var rs = 0; for (i = 0; i < 5; i++) rs += P[j][i]; vid += T.rect(198, y0 + j * c + 5, rs * 14, 16, { cls: "f-future", rx: 2 }); }
      var q = ["policy: read a", "video: read o′", "forward: fix a → o′", "inverse: fix o′ → a"];
      return T.text(60, 30, "p(o′, a | o)", { base: true }) + T.path(grid, { cls: "t-grid", base: true }) + T.g({ a: "dots", base: true }, dots) +
        T.sm(50, 118, "o′", { anchor: "end", base: true }) + T.sm(200, 212, "a", { base: true }) +
        T.g({ a: "actB" }, act) + T.g({ a: "vidB" }, vid) +
        q.map(function (s, k) { return T.sm(256, 76 + k * 30, s, { a: "q" + k }); }).join("") +
        T.rect(54, 180, 142, 40, { a: "hl", cls: "t-accl", rx: 6 }) +
        T.g({ a: "cp" }, T.box(14, 236, 118, 26, "UniPi cascade", { role: "future", small: true }) + T.line(132, 249, 148, 249, { arrow: "ink" }) +
          T.box(150, 236, 92, 26, "GR-1, PAD", { role: "future", small: true }) + T.line(242, 249, 258, 249, { arrow: "ink" }) +
          T.box(260, 236, 60, 26, "UWM", { role: "future", small: true }));
    },
    beats: [
      { cap: "One joint table p(o′, a | o): futures by actions.", on: "dots", dur: 2200 },
      { cap: "Policy query: sum out the future, read the action a.", on: "actB q0 hl", dur: 2400 },
      { cap: "Video query: sum out the action, read the future o′.", on: "vidB q1", cls: "q0:is-dim", set: "hl.x=192 hl.y=42 hl.width=42 hl.height=134", dur: 2400 },
      { cap: "Forward dynamics: fix an action a, read o′ down its column.", on: "q2", cls: "q1:is-dim", set: "hl.x=84 hl.y=40 hl.width=30 hl.height=138", dur: 2400 },
      { cap: "Inverse dynamics: fix a future o′, read a along its row.", on: "q3", cls: "q2:is-dim", set: "hl.x=56 hl.y=120 hl.width=138 hl.height=30", dur: 2400 },
      { cap: "Coupling tightened: UniPi's cascade, then GR-1 and PAD, then UWM.", on: "cp", cls: "q3:is-dim", dur: 3000 }
    ]
  });

  /* 12 · the policy practises in imagination, exploits a model error, the model is refit, imagined ranks match real ones */
  SC("imagine", {
    title: "A learned simulator: practise, get caught, refit", h: 264,
    draw: function (T) {
      var ranks = [76, 110, 144].map(function (y, k) {
        return T.circle(346, y, 5, { cls: "t-ink" }) + T.circle(392, y, 5, { cls: "t-ink" }) + T.line(352, y, 386, y, { cls: "t-goodl" }) + T.sm(334, y + 5, "ABC"[k], { anchor: "end" });
      }).join("");
      return T.g({ a: "frame" }, T.rect(14, 36, 176, 126, { cls: "fs-future t-dash", rx: 6 }) + T.table(24, 142, 156) + T.block(118, 124, 18, 18) + T.arm(56, 130, 70, -100, { l1: 48, l2: 40 })) +
        T.sm(14, 26, "imagined scene", { a: "frameL" }) +
        T.box(14, 196, 110, 40, "Policy π_θ", { a: "pol", role: "act" }) + T.line(69, 196, 69, 166, { a: "pA", cls: "s-act", arrow: "act" }) +
        T.g({ a: "gl" }, T.rect(148, 134, 18, 18, { cls: "t-block", rx: 2 }) + T.circle(157, 140, 16, { cls: "t-badl" })) + T.sm(157, 110, "glitch", { a: "glL", anchor: "middle" }) +
        T.axes(214, 170, 100, 130, { yl: "return" }) +
        T.vbar(220, 170, 30, 0, { a: "ib", cls: "f-future" }) + T.sm(235, 188, "imagined", { a: "ibL", anchor: "middle" }) +
        T.vbar(280, 170, 30, 32, { a: "rb", cls: "t-bad" }) + T.sm(295, 188, "real", { a: "rbL", anchor: "middle" }) +
        T.path("M295 200 C 295 236, 210 236, 176 170", { a: "loop", cls: "s-future", arrow: "future", draw: true }) + T.sm(404, 238, "refit on real rollouts", { a: "loopL", anchor: "end" }) +
        T.g({ a: "rk" }, T.sm(346, 50, "imag.", { anchor: "middle" }) + T.sm(392, 50, "real", { anchor: "middle" }) + ranks);
    },
    beats: [
      { cap: "The policy acts inside a scene the world model imagines.", on: "frame frameL pol pA", dur: 2200 },
      { cap: "Imagined reward adds up along the rollout.", on: "ib ibL", set: "ib.y=110 ib.height=60", dur: 2200 },
      { cap: "It finds a glitch: imagined return high, real return low.", on: "gl glL rb rbL", set: "ib.y=48 ib.height=122", dur: 2600 },
      { cap: "Refit the model on real rollouts of the policy; the gap closes.", on: "loop loopL", cls: "loop:a-flow", set: "ib.y=132 ib.height=38", dur: 2800 },
      { cap: "Now checkpoint ranks in imagination match the real ranks.", on: "rk", dur: 2600 }
    ]
  });
})();
