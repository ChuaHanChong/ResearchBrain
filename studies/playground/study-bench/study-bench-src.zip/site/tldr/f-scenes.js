/* TL;DR scenes · Part F (20–22) and the recap (23). Drawn with RB.tl (core/44-tldr-cast.js); width 420, 3–6 beats, captions ≤ 12 words. */
(function () {
  var SC = window.RB.tldr.scene;

  /* 20 · best of N, then a failure score that leaves its calibrated band */
  SC("verifiers", {
    title: "A verifier picks the best of N, then watches the run", h: 296,
    draw: function (T) {
      var rows = [48, 72, 96, 120], bw = [70, 140, 96, 48], s = "";
      rows.forEach(function (y, i) {
        s += T.path("M110 84 L124 " + (y + 8), { a: "l" + i, cls: "t-arr" }) + T.g({ a: "c" + i }, T.chunk(128, y, 6, {})) +
          T.rect(244, y + 2, 0, 12, { a: "v" + i, cls: "t-score", rx: 2 });
      });
      var sc = [];
      for (var x = 42; x <= 290; x += 16) sc.push([x, 252 + ((x / 16) % 3 - 1) * 3]);
      sc = sc.concat([[306, 244], [322, 232], [338, 216], [354, 202], [370, 192], [386, 186], [398, 184]]);
      return T.box(12, 58, 96, 52, "policy π_θ", { role: "act", base: true }) + T.sm(128, 36, "N samples", { a: "nL" }) +
        T.g({ a: "ver" }, T.rect(230, 20, 178, 124, { cls: "t-box r-critic", rx: 10 }) + T.text(319, 40, "verifier", { anchor: "middle" })) + s +
        T.axes(40, 266, 360, 92, { a: "ax", base: false, xl: "time", yl: "failure score" }) +
        T.rect(42, 222, 356, 43, { a: "band", cls: "t-good-soft", rx: 0 }) + T.sm(50, 240, "calibrated band", { a: "bandL" }) +
        T.curve(sc, { a: "sc", cls: "s-critic", draw: true }) +
        T.circle(334, 222, 6, { a: "hit", cls: "t-bad" }) +
        T.g({ a: "alarm" }, T.rect(52, 178, 176, 28, { cls: "t-bad-soft", rx: 14 }) + T.sm(140, 197, "stop, or ask for help", { anchor: "middle", cls: "t-sm t-ink" }));
    },
    beats: [
      { cap: "The policy samples N candidate action chunks.", on: "nL l0 l1 l2 l3 c0 c1 c2 c3", dur: 2200 },
      { cap: "A verifier scores each candidate.", on: "ver v0 v1 v2 v3", set: "v0.width=70 v1.width=140 v2.width=96 v3.width=48", dur: 2400 },
      { cap: "The top-scoring chunk is the one that runs.", cls: "c0:is-dim c2:is-dim c3:is-dim v0:is-dim v2:is-dim v3:is-dim l0:is-dim l2:is-dim l3:is-dim c1:a-glow", dur: 2200 },
      { cap: "During the run, a failure score leaves its calibrated band.", on: "ax band bandL sc", dur: 2800 },
      { cap: "Alarm: stop the robot, or ask a human for help.", on: "hit alarm", cls: "hit:a-pulse", dur: 2600 }
    ]
  });

  /* 21 · capability rings as attack surfaces; a barrier filter projects the action back into the safe set */
  SC("safety", {
    title: "Attacks cascade outward; a filter keeps actions safe", h: 290,
    draw: function (T) {
      var C = [122, 150];
      return T.circle(C[0], C[1], 112, { a: "r3", cls: "fs-act" }) + T.circle(C[0], C[1], 80, { a: "r2", cls: "fs-lang" }) + T.circle(C[0], C[1], 46, { a: "r1", cls: "fs-vision" }) +
        T.sm(C[0], 59, "action", { a: "r3L", anchor: "middle", cls: "t-sm t-ink" }) + T.sm(C[0], 92, "language", { a: "r2L", anchor: "middle", cls: "t-sm t-ink" }) + T.sm(C[0], 155, "perception", { a: "r1L", anchor: "middle", cls: "t-sm t-ink" }) +
        T.sm(12, 22, "attack", { a: "atkL", cls: "t-sm t-bad" }) + T.path("M30 32 C 50 60, 70 90, 90 116", { a: "atk", cls: "t-badl", arrow: "bad", draw: true }) +
        T.circle(C[0], C[1], 46, { a: "k1", cls: "t-badl" }) + T.circle(C[0], C[1], 80, { a: "k2", cls: "t-badl" }) + T.circle(C[0], C[1], 112, { a: "k3", cls: "t-badl" }) +
        T.rect(254, 56, 118, 170, { a: "safe", cls: "t-good-soft", rx: 24 }) + T.sm(313, 80, "safe set", { a: "safeL", anchor: "middle", cls: "t-sm t-ink" }) +
        T.path("M236 150 L330 126", { a: "cmd", cls: "t-arr", arrow: "ink", draw: true }) + T.circle(340, 124, 6, { a: "dot", cls: "t-ink" }) +
        T.path("M344 130 L396 194", { a: "nom", cls: "t-badl t-dash", arrow: "bad", draw: true }) + T.sm(404, 246, "nominal", { a: "nomL", anchor: "end", cls: "t-sm t-bad" }) +
        T.path("M390 198 L366 196", { a: "proj", cls: "t-ghostl" }) +
        T.path("M341 131 L358 190", { a: "fil", cls: "t-goodl", arrow: "good", draw: true }) + T.sm(268, 186, "filtered", { a: "filL", cls: "t-sm t-good" });
    },
    beats: [
      { cap: "Capabilities stack as rings: perception, language, action.", on: "r1 r2 r3 r1L r2L r3L", dur: 2200 },
      { cap: "An attack enters one ring, here the perception input.", on: "atk atkL k1", cls: "k1:a-pulse", dur: 2400 },
      { cap: "The failure cascades outward, into physical actions.", on: "k2 k3", dur: 2200 },
      { cap: "The corrupted action would leave the safe set.", cls: "r1:is-dim r2:is-dim r3:is-dim k1:is-dim k2:is-dim k3:is-dim r1L:is-dim r2L:is-dim r3L:is-dim", on: "safe safeL cmd dot nom nomL", dur: 2600 },
      { cap: "The barrier filter projects it to the nearest safe action.", on: "proj fil filL", dur: 2800 }
    ]
  });

  /* 22 · a success rate is a noisy count; saturated suites hide fragility */
  SC("benchmarks", {
    title: "A success rate is a noisy count", h: 290,
    draw: function (T) {
      var tiles = "";
      for (var i = 0; i < 24; i++) tiles += T.rect(12 + (i % 12) * 16, 34 + Math.floor(i / 12) * 18, 12, 12, { cls: i === 5 || i === 17 ? "t-bad" : "t-good", rx: 2 });
      var hs = [97, 98, 97, 96, 98], bars = "";
      hs.forEach(function (h, k) { bars += T.rect(64 + k * 64, 266 - h, 40, h, { a: "b" + k, cls: "t-score", rx: 2 }); });
      return T.sm(12, 24, "episodes", { a: "epL" }) + T.g({ a: "ep" }, tiles) + T.sm(12, 90, "success rate = k / n", { a: "cnt" }) +
        T.g({ a: "gauge" }, T.line(232, 60, 392, 60, { cls: "t-ax" }) + T.sm(232, 80, "80%", { anchor: "middle" }) + T.sm(392, 80, "100%", { anchor: "middle" })) +
        T.rect(328, 54, 64, 12, { a: "ci", cls: "t-acc", rx: 3, style: "fill-opacity:.35" }) + T.circle(368, 60, 5, { a: "pt", cls: "t-ink" }) + T.sm(368, 44, "97%", { a: "ptL", anchor: "middle" }) +
        T.sm(312, 104, "few episodes: wide", { a: "ciL", anchor: "middle" }) +
        T.axes(40, 266, 340, 108, { a: "ax", base: false, yl: "success" }) + T.sm(400, 146, "LIBERO, top methods", { a: "libL", anchor: "end" }) + T.g({ a: "ceil" }, T.line(44, 166, 364, 166, { cls: "t-ghostl" }) + T.sm(404, 170, "100%", { anchor: "end" })) + bars +
        T.line(44, 250, 364, 250, { a: "l16", cls: "t-badl t-dash" }) + T.sm(404, 254, "16%", { a: "l16L", anchor: "end", cls: "t-sm t-bad" }) +
        T.cam(214, 146, { a: "cam" });
    },
    beats: [
      { cap: "Episodes run one by one; successes add up to a rate.", on: "epL ep cnt", dur: 2200 },
      { cap: "With few episodes, the rate's interval is wide.", on: "gauge ci pt ptL ciL", dur: 2200 },
      { cap: "It shrinks as n grows: ±1.5 points at 500 episodes.", set: "ci.x=356 ci.width=24", text: "ciL=500 episodes: ±1.5", dur: 2600 },
      { cap: "On LIBERO, the top methods sit level near the ceiling.", on: "ax libL ceil b0 b1 b2 b3 b4", dur: 2400 },
      { cap: "Shift the camera and some drop below 16%.", on: "l16 l16L cam", cls: "b0:t-bad b2:t-bad b3:t-bad",
        set: "b0.y=256 b0.height=10 b2.y=252 b2.height=14 b3.y=258 b3.height=8 b1.y=208 b1.height=58 b4.y=222 b4.height=44", dur: 3000 }
    ]
  });

  /* 23 · the whole field in one loop; the last beat lifts each label to make room for its section badge */
  SC("recap", {
    title: "The whole field in one loop", h: 320,
    draw: function (T) {
      function card(id, x, y, w, label, role, badge) {
        return T.g({ a: id }, T.rect(x, y, w, 46, { cls: "t-box r-" + role, rx: 8 }) + T.text(x + w / 2, y + 28, label, { a: id + "L", base: true, anchor: "middle", cls: "t-note t-ink" })) +
          T.sm(x + w / 2, y + 38, badge, { a: id + "N", anchor: "middle" });
      }
      return card("data", 164, 6, 92, "data", "ink", "03 04 14") + T.path("M210 52 L210 68", { a: "aD", cls: "t-arr", arrow: "ink" }) +
        card("cam", 20, 70, 104, "camera", "vision", "01") + card("pol", 146, 70, 128, "policy π_θ", "act", "05 06 08 09 10") + card("chk", 296, 70, 104, "action chunk", "act", "07") +
        card("wm", 146, 134, 128, "world model", "future", "11 12 13") +
        card("wld", 20, 198, 104, "world", "state", "20") + card("rob", 146, 198, 128, "robot, contact", "touch", "15–19") + card("ctl", 296, 198, 104, "controller", "ink", "02") +
        T.path("M126 93 L144 93", { a: "a1", cls: "s-vision", arrow: "vision" }) + T.path("M276 93 L294 93", { a: "a2", cls: "s-act", arrow: "act" }) +
        T.path("M348 118 L348 196", { a: "a3", cls: "s-act", arrow: "act" }) + T.path("M294 221 L276 221", { a: "a4", cls: "t-arr", arrow: "ink" }) +
        T.path("M144 221 L126 221", { a: "a5", cls: "t-arr", arrow: "ink" }) + T.path("M72 196 L72 118", { a: "a6", cls: "s-vision", arrow: "vision" }) +
        T.path("M196 118 L196 132", { a: "i1", cls: "s-future", arrow: "future" }) + T.path("M224 132 L224 118", { a: "i2", cls: "s-future", arrow: "future" }) +
        T.rect(10, 62, 400, 190, { a: "wrap", cls: "s-critic t-dash", rx: 16 }) +
        card("ver", 20, 262, 116, "verifier", "critic", "21") + card("saf", 152, 262, 116, "safety filter", "critic", "22") + card("ben", 284, 262, 116, "benchmark", "critic", "23");
    },
    beats: [
      { cap: "Data trains a policy; the camera feeds it observations o_t.", on: "data aD cam pol a1", dur: 2400 },
      { cap: "The policy writes an action chunk; a controller executes it.", on: "chk a2 ctl a3", dur: 2400 },
      { cap: "The robot touches the world; the camera sees the change.", on: "rob a4 wld a5 a6", cls: "a1:a-flow a2:a-flow a3:a-flow a4:a-flow a5:a-flow a6:a-flow", dur: 2600 },
      { cap: "A world model lets the policy imagine before acting.", on: "wm i1 i2", cls: "i1:a-flow i2:a-flow", dur: 2400 },
      { cap: "A trust layer wraps it: verifier, safety filter, benchmark.", on: "wrap ver saf ben", dur: 2600 },
      { cap: "Every box is a section of this page, 01 to 23.", on: "dataN camN polN chkN wmN wldN robN ctlN verN safN benN",
        set: "dataL.y=27 camL.y=91 polL.y=91 chkL.y=91 wmL.y=155 wldL.y=219 robL.y=219 ctlL.y=219 verL.y=283 safL.y=283 benL.y=283",
        cls: "data:a-glow cam:a-glow pol:a-glow chk:a-glow wm:a-glow wld:a-glow rob:a-glow ctl:a-glow ver:a-glow saf:a-glow ben:a-glow", dur: 3200 }
    ]
  });
})();
