/* TL;DR page: the text of every section (from the approved plan, Claude Doc "Study Bench · Robot Learning TL;DR plan").
   Numbers come from the topics' own takeaways; equations are pointers into the topics' rules ({t, r}), never retyped.
   Limits: title 8 words, TL;DR 30, point 15. Survey codes in ref are shown as survey names by the text pass. */
(function () {
  var S = window.RB.tldr.section;

  /* ---------- Part A · Foundations ---------- */
  S({ id: "problem", n: "01", part: "A", topics: ["a1"], ref: "P01 §2, §5–6 · X2 §1–2",
    title: "The robot-learning problem",
    sum: "A policy maps what the robot sees and is told into actions, step after step, in a world it only partly observes.",
    points: ["Manipulation is a partially observed, sequential decision problem.",
      "The manipulation survey splits systems into three layers: plans, actions, motor torques.",
      "Most learned policies live in the middle layer: they output actions."],
    eq: { spec: { name: "The policy", ref: "P01 eq. 2", tex: "\\class{sym-a}{a_t} \\sim \\class{sym-pi}{\\pi_\\theta}(\\cdot \\mid \\class{sym-o}{o_t})",
      words: "At each step the policy, with parameters θ, draws the next action from what it currently observes.", key: ["a", "pi", "o"] } },
    remember: "Most new methods change one part of an older one: inputs, latent or decoder." });

  S({ id: "control", n: "02", part: "A", topics: ["a2"], ref: "P09 §V–VI · P10 §6",
    title: "The controller under the policy",
    sum: "The policy sends targets; a controller running near 1 kHz turns them into torques and decides how hard the robot presses.",
    points: ["PD position control tracks precisely but presses hard on contact.",
      "Impedance trades accuracy for compliance, without a force sensor.",
      "Admittance measures force and moves a compliant target instead."],
    eq: { t: "a2", r: 1 },
    remember: "A policy never sets contact force directly; the controller under it does." });

  S({ id: "rl", n: "03", part: "A", topics: ["a3"], ref: "X2 §3 · P07",
    title: "Reinforcement learning for robots",
    sum: "A reward scores each attempt; DQN, DDPG and SAC learn from replayed transitions, while PPO with parallel simulation drives sim-to-real.",
    points: ["DQN regresses Q onto a Bellman target from a replay buffer.",
      "DDPG adds an actor for continuous actions; SAC makes it stochastic.",
      "HIL-SERL mixes human interventions into the buffer on a real robot."],
    eq: { t: "a3", r: 0 },
    remember: "The most mature results: zero-shot sim-to-real, dense rewards, on-policy RL, mostly locomotion." });

  S({ id: "sim2real", n: "04", part: "A", topics: ["a4"], ref: "P08",
    title: "Sim-to-real",
    sum: "Simulators get friction, delays and pixels wrong; randomizing them in training and giving the policy memory makes the real world one more sample.",
    points: ["The gap G(π) is one policy's score in simulation minus its score on the robot.",
      "Wider randomization transfers more often but can stop the policy from learning.",
      "Memory helps: an LSTM policy reached 0.89 real success against 0.67 without."],
    eq: { t: "a4", r: 1 },
    remember: "Randomization trades optimality for robustness." });

  /* ---------- Part B · Imitation and policy architectures ---------- */
  S({ id: "bc", n: "05", part: "B", topics: ["b1"], ref: "X2 §4 · P01 §6.1.2",
    title: "Behavior cloning, and why it drifts",
    sum: "Copy the expert's actions with supervised learning; small errors lead the clone to states the expert never showed, so errors compound.",
    points: ["Behavior cloning is supervised regression from observations to expert actions.",
      "A clone meets its own states, so its cost can grow with T².",
      "DAgger labels the learner's own states, which brings the growth down to T."],
    eq: { t: "b1", r: 1 },
    remember: "The data covers where the expert went, not where the clone ends up." });

  S({ id: "heads", n: "06", part: "B", topics: ["b2"], ref: "X2 §4 · P01 §6.4",
    title: "Generative policy heads",
    sum: "Demonstrations pass the block on the left or the right; regression averages them into the block, generative heads keep both ways.",
    points: ["Squared-error regression predicts the mean action, wrong when demos are multimodal.",
      "ACT predicts chunks with a conditional VAE.",
      "Diffusion removes noise in K steps; flow matching needs fewer."],
    eq: { t: "b2", r: 1 },
    remember: "Learn the whole distribution of actions, not its average." });

  S({ id: "timing", n: "07", part: "B", topics: ["b3"], ref: "P02 §IV · X2 §4.5",
    title: "Action representations and timing",
    sum: "How actions are written sets how long they take to produce; compact chunks and an asynchronous queue keep the robot from waiting.",
    points: ["256-bin tokens per dimension make long sequences; FAST cut 700 tokens to 53.",
      "Autoregressive decoding took about 750 ms per chunk.",
      "Continuous chunks in one pass run far faster."],
    eq: { t: "b3", r: 0 },
    remember: "Request the next chunk early enough and the robot never idles." });

  S({ id: "vla", n: "08", part: "B", topics: ["b4"], ref: "P02 · X2 §5",
    title: "Vision-language-action models",
    sum: "A VLA reuses a web-pretrained vision-language model to turn camera images and an instruction straight into robot actions.",
    points: ["RT-2 wrote actions as 256-bin tokens; OpenVLA opened that recipe at 7B.",
      "Decoding tokens one by one limits the control rate.",
      "π0 moved actions into a flow-matching expert that outputs 50-action chunks."],
    eq: { t: "b4", r: 1 },
    remember: "After π0, most VLAs keep a separate action module instead of action tokens." });

  S({ id: "planning", n: "09", part: "B", topics: ["b5"], ref: "P01 §5",
    title: "Language models plan, lower layers move",
    sum: "A language model can plan a task but cannot move an arm, so it writes skills, code, value maps or points for a lower layer.",
    points: ["SayCan multiplies what the LLM finds useful by what can succeed.",
      "Without affordances, SayCan's plan success fell from 84% to 67%.",
      "Inner Monologue feeds scene feedback back: 30.8% rose to 60.4%."],
    eq: { t: "b5", r: 0 },
    remember: "The planner outputs a structured artifact; something below must turn it into motion." });

  S({ id: "icl", n: "10", part: "B", topics: ["b6"], ref: "X4 §2–3",
    title: "In-context learning: teach a frozen policy",
    sum: "Demonstrations given at deployment steer a policy whose weights stay fixed; the policy retrieves, attends to or encodes that context to decide its actions.",
    points: ["Context adaptation changes the input, not the weights.",
      "Four families: context-conditioned policies, geometric transfer, world models, skills and agents.",
      "A policy may ignore its prompt: test by swapping the demonstration."],
    eq: { t: "b6", r: 1 },
    remember: "Check that the action changes when the demonstration changes." });

  /* ---------- Part C · Predictive models ---------- */
  S({ id: "worldmodel", n: "11", part: "C", topics: ["c1"], ref: "X3 §II–IV · P03 §1–3",
    title: "World models: predict, then act",
    sum: "A world model predicts the next observation for an action, so the robot can try candidates in imagination and keep the best.",
    points: ["PlaNet plans with CEM in a learned latent space.",
      "Dreamer learns an actor from imagined rollouts instead.",
      "Replanning every step absorbs model error; TD-MPC2 adds a terminal value."],
    eq: { t: "c1", r: 0 },
    remember: "A world model helps only if its predictions change what the robot does." });

  S({ id: "wam", n: "12", part: "C", topics: ["c2"], ref: "P04 · X1",
    title: "World action models",
    sum: "A world action model predicts the future and the action together, so what the robot expects to happen shapes what it does.",
    points: ["A VLA's objective needs no future; a WAM's does.",
      "Coupling tightened: UniPi's cascade, then GR-1 and PAD, then UWM.",
      "UWM serves all four queries from one model."],
    eq: { t: "c2", r: 0 },
    remember: "Policy, video model, forward and inverse dynamics are four queries of one joint distribution." });

  S({ id: "imagine", n: "13", part: "C", topics: ["c3"], ref: "P03 §4 · X3 §V–VI",
    title: "World models as simulator and judge",
    sum: "Policies practise and get ranked inside a learned world model; because optimization finds its errors, the model is refit on the policy's rollouts.",
    points: ["As a simulator, the model trains RL; as an evaluator, it scores actions.",
      "World-Env, VLA-RFT and WMPO differ mainly in reward design.",
      "Co-evolution refits the world model on the policy's own rollouts."],
    eq: { t: "c3", r: 1 },
    remember: "Optimization seeks out simulator errors, learned simulators included." });

  /* ---------- Part D · Data ---------- */
  S({ id: "data", n: "14", part: "D", topics: ["d1", "d2"], ref: "P05 · P06",
    title: "The data pyramid, and human video",
    sum: "Five data layers trade robot alignment for scale; human video is cheap but lacks robot views, actions and rewards, so methods bridge those gaps.",
    points: ["UMI-style devices take the robot out of data collection.",
      "MimicGen turns about 10 demos into 1,000 per task.",
      "VIP is the better reward; R3M the slightly better encoder."],
    remember: "Phantom trains with zero robot data by editing robot arms into human video." });

  /* ---------- Part E · Manipulation skills and embodiments ---------- */
  S({ id: "grasp", n: "15", part: "E", topics: ["e1"], ref: "P01 §3.1, §4.1",
    title: "Grasping: friction cones to foundation models",
    sum: "A two-finger grasp holds when the squeeze line lies inside both friction cones; learning decides where to look for one.",
    points: ["Each cone's half-angle is arctan μ.",
      "GraspNet-1Billion labels a grasp 1.1 minus the least friction it needs.",
      "Representations grew from 5-D rectangles to 6-DoF poses to full hands."],
    eq: { t: "e1", r: 0 },
    remember: "Friction decides whether a grasp holds; learning decides where to try." });

  S({ id: "dexterous", n: "16", part: "E", topics: ["e2"], ref: "P01 §4.3 · P07 · P10",
    title: "Dexterous hands",
    sum: "Many fingers mean many contacts, so sparse-reward RL rarely finds a first success; demonstrations, randomized simulation and memory get hands working.",
    points: ["DAPG learned pen reorientation in 3.33 robot-hours instead of 322, in simulation.",
      "Without randomization, Dactyl's median consecutive successes fell from 13 to 0.",
      "Retargeting maps human fingertips onto a robot hand."],
    eq: { t: "e2", r: 0 },
    remember: "Demonstrations give a hand its first success; randomized simulation carries it to reality." });

  S({ id: "deformable", n: "17", part: "E", topics: ["e3"], ref: "P01 §4.4–4.7",
    title: "Cloth, two arms and a moving base",
    sum: "Cloth has no single pose, two arms must share one clock, and a moving base shifts every reach; each changes the state or action space.",
    points: ["Cloth becomes a point cloud; shapes are compared with the Chamfer distance.",
      "Coarse keypoints can hide real shape error.",
      "ALOHA-style leader–follower rigs record synchronized two-arm data."],
    eq: { t: "e3", r: 1 },
    remember: "What the robot tracks decides when it believes it is done." });

  S({ id: "humanoid", n: "18", part: "E", topics: ["e4"], ref: "P09 · P01 §4.8",
    title: "Humanoids: manipulate while balancing",
    sum: "A floating base moves only through contact forces, so every arm motion of a humanoid is also a balance problem.",
    points: ["Loco-manipulation adds walking; whole-body manipulation adds contact with any body part.",
      "A priority stack ranks balance above the reach.",
      "Learned trackers turn human motion clips into robot motion."],
    eq: { t: "e4", r: 0 },
    remember: "Whole-body control writes every task as a linear function of accelerations, forces and torques." });

  S({ id: "touch", n: "19", part: "E", topics: ["e5"], ref: "P10 · P01 §6.2.3",
    title: "Touch and force in the loop",
    sum: "Touch and force matter only in contact and change fast, so policies gate them by contact phase and react through a fast loop.",
    points: ["Force/torque sensing measures the global load; touch measures the local contact.",
      "Where force enters matters: ForceVLA's insertion ranged from 0% to 80%.",
      "FoAR scales force by the predicted contact probability."],
    eq: { t: "e5", r: 1 },
    remember: "Keep free-space noise out: listen to force only when in contact." });

  S({ id: "physics", n: "20", part: "E", topics: ["e6"], ref: "P11",
    title: "Physics priors",
    sum: "Building mechanics into inputs, architecture or loss lets a model learn from less data and extrapolate further, until physics it lacks shows up.",
    points: ["DeLaN and HNN encode energy structure, so they conserve energy.",
      "They extrapolate beyond the training speeds.",
      "A conservative model cannot fit friction without a dissipation term."],
    eq: { t: "e6", r: 1 },
    remember: "Physics in inputs or architecture acts at run time; a physics loss only in training." });

  /* ---------- Part F · Trust ---------- */
  S({ id: "verifiers", n: "21", part: "F", topics: ["f1"], ref: "P14 · P01 §7",
    title: "Verifiers and failure detection",
    sum: "A verifier scores a proposed chunk, rollout or policy: pick the best of N samples, or raise an alarm before a failure.",
    points: ["Human verdicts are costly but direct; intrinsic signals are nearly free.",
      "Detectors moved from sampling-heavy STAC to one-pass scores and combined signals.",
      "Conformal calibration turns a score into an alarm threshold."],
    eq: { t: "f1", r: 1 },
    remember: "Cheap scores come from the policy itself; trustworthy ones cost more." });

  S({ id: "safety", n: "22", part: "F", topics: ["f2"], ref: "P13",
    title: "Safety of embodied AI",
    sum: "Every capability adds an attack surface; a barrier filter changes an action only when it would leave the safe set too fast.",
    points: ["Failures in inner layers cascade outward into physical actions.",
      "Token VLAs, flow heads and action chunks each opened a new backdoor route.",
      "The barrier filter needs no training."],
    eq: { t: "f2", r: 0 },
    remember: "Attacks follow the policy's design." });

  S({ id: "benchmarks", n: "23", part: "F", topics: ["f3"], ref: "P03 §7 · X3 §VII–VIII",
    title: "Benchmarks and what they miss",
    sum: "A success rate is one noisy number; saturated suites hide fragility that perturbation and unseen-task suites expose.",
    points: ["At 500 episodes, a 97% score carries about ±1.5 points.",
      "Top LIBERO methods differ by about one point.",
      "A camera shift drops some of them below 16%."],
    eq: { t: "f3", r: 0 },
    remember: "Report the interval, and test what the fixed suite does not." });

  /* ---------- Recap ---------- */
  S({ id: "recap", n: "24", part: "R", topics: [], ref: "All six parts",
    title: "The whole field in one loop",
    sum: "Data trains a policy, the policy writes actions a controller executes, world models imagine and verifiers judge; every section is one box on this loop.",
    points: ["Parts A and B: the policy, the controller and how policies learn.",
      "Parts C and D: imagination, and the data that feeds it all.",
      "Parts E and F: the physical side, and trust around the loop."],
    remember: "Most new methods change one box of this loop and keep the rest." });
})();
