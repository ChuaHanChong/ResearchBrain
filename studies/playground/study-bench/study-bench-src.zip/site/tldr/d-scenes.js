/* TL;DR scenes · Part D (13). Drawn with RB.tl (core/44-tldr-cast.js); width 420, 3–6 beats, captions ≤ 12 words. */
(function () {
  var SC = window.RB.tldr.scene;

  /* 13 · the data pyramid (darker = more robot-aligned), human video's three gaps and their bridges */
  SC("data", {
    title: "The data pyramid, and how human video is bridged", h: 300,
    draw: function (T) {
      var names = ["web", "simulation", "human video", "UMI-style", "real robot"], op = [0.1, 0.2, 0.32, 0.45, 0.6];
      var cx = 140, bands = "", pours = "";
      names.forEach(function (n, i) {
        var w = 200 - 25 * i, y = 160 - 30 * i;
        bands += T.g({ a: "b" + i }, T.rect(cx - w / 2, y, w, 28, { cls: "t-acc", rx: 4, style: "fill-opacity:" + op[i] }) + T.sm(cx, y + 19, n, { anchor: "middle", cls: "t-sm t-ink" }));
        pours += T.path("M" + (cx + w / 2 + 4) + " " + (y + 14) + " L250 " + (y + 14), { a: "p" + i, cls: "t-arr" });
      });
      /* a human hand drawn at the origin; the clip moves it along hp */
      var hand = T.g({ a: "hand", transform: "translate(330 78)" }, T.line(-34, -24, -8, -2, { cls: "t-link" }) + T.rect(-10, -8, 16, 16, { cls: "t-base", rx: 5 }) +
        T.line(5, -5, 15, -8, { cls: "t-grip" }) + T.line(6, 0, 17, 0, { cls: "t-grip" }) + T.line(5, 5, 15, 8, { cls: "t-grip" }) + T.line(0, 8, 8, 13, { cls: "t-grip" }));
      var cols = [12, 148, 284], gaps = ["observation", "action", "objective"], bridges = ["encoder", "hand→gripper", "goal distance"], gb = "";
      cols.forEach(function (x, i) {
        gb += T.g({ a: "g" + i }, T.rect(x, 226, 124, 26, { cls: "t-bad-soft", rx: 6 }) + T.sm(x + 62, 244, gaps[i], { anchor: "middle", cls: "t-sm t-ink" }));
        gb += T.g({ a: "r" + i }, T.rect(x, 262, 124, 26, { cls: "t-good-soft", rx: 6 }) + T.sm(x + 62, 280, bridges[i], { anchor: "middle", cls: "t-sm t-ink" }));
      });
      return bands +
        T.path("M20 190 L20 44", { a: "up", cls: "t-arr", arrow: "ink", draw: true }) + T.sm(12, 30, "alignment", { a: "upL" }) +
        T.path("M258 42 L258 186", { a: "down", cls: "t-arr", arrow: "ink", draw: true }) + T.sm(258, 206, "scale", { a: "downL", anchor: "middle" }) +
        T.rect(63, 98, 154, 34, { a: "hvHi", cls: "t-accl", rx: 6 }) +
        T.g({ a: "clip" }, T.rect(280, 44, 128, 100, { cls: "t-box r-vision", rx: 8 }) + T.line(290, 124, 398, 124, { cls: "t-table" }) + T.rect(378, 100, 18, 24, { cls: "t-block", rx: 3 })) +
        T.path("M330 78 L360 112", { a: "hp", style: "stroke:none" }) + hand + T.line(290, 134, 398, 134, { a: "track", cls: "t-grid" }) + T.rect(290, 132, 0, 4, { a: "prog", cls: "t-acc", rx: 2 }) +
        T.sm(12, 216, "human video lacks:", { a: "gapL" }) + gb +
        pours + T.path("M250 55 L250 175", { a: "bus", cls: "t-arr" }) + T.path("M250 92 L296 92", { a: "pout", cls: "t-arr", arrow: "ink" }) + T.box(300, 70, 108, 44, "policy π_θ", { a: "pol", role: "act" });
    },
    beats: [
      { cap: "Five layers, from web data up to real robot data.", on: "b0 b1 b2 b3 b4", dur: 2200 },
      { cap: "Up the pyramid, robot alignment grows; down it, scale grows.", on: "up upL down downL", dur: 2200 },
      { cap: "Human video is cheap: people doing the task.", on: "hvHi clip track prog hp", cls: "hvHi:a-pulse", move: "hand:hp", set: "prog.width=108", dur: 2400 },
      { cap: "It lacks robot views, robot actions and a reward.", off: "hvHi", on: "gapL g0 g1 g2", dur: 2200 },
      { cap: "Bridges: an encoder, hand-to-gripper retargeting, a goal-distance reward.", on: "r0 r1 r2", dur: 2600 },
      { cap: "Every layer's data then trains one policy.", off: "clip hand track prog down downL", on: "p0 p1 p2 p3 p4 bus pout pol", cls: "p0:a-flow p1:a-flow p2:a-flow p3:a-flow p4:a-flow pout:a-flow", dur: 2600 }
    ]
  });
})();
