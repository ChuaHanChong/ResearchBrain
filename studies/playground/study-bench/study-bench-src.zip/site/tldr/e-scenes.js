/* TL;DR scenes · Part E (14–19). Drawn with RB.tl (core/44-tldr-cast.js); width 420, 3–6 beats, captions ≤ 12 words. */
(function () {
  var SC = window.RB.tldr.scene;
  function pts(list) { return list.map(function (p) { return p.join(" "); }).join(" L"); }

  /* 14 · friction cones decide whether a grasp holds; learning decides where to try */
  SC("grasp", {
    title: "A grasp holds when the squeeze line lies inside both friction cones", h: 250,
    draw: function (T) {
      var H = 20, L = 72;
      /* a parallel-jaw pose glyph: fingertips centred on p, approaching along th (SVG degrees), jaw width w */
      function pose(px, py, th, w) {
        var r = Math.PI / 180, ux = Math.cos(th * r), uy = Math.sin(th * r), nx = -uy, ny = ux, h = w / 2;
        var t1 = [px + nx * h, py + ny * h], t2 = [px - nx * h, py - ny * h], b1 = [t1[0] - ux * 16, t1[1] - uy * 16], b2 = [t2[0] - ux * 16, t2[1] - uy * 16];
        var m = [px - ux * 16, py - uy * 16], s = [px - ux * 30, py - uy * 30];
        return T.path("M" + pts([t1, b1, b2, t2].map(function (p) { return [T.r1(p[0]), T.r1(p[1])]; })) + " M" + T.r1(m[0]) + " " + T.r1(m[1]) + " L" + T.r1(s[0]) + " " + T.r1(s[1]), { cls: "s-act" });
      }
      var map = "";
      for (var i = 0; i < 6; i++) for (var j = 0; j < 7; j++) {
        var cx = 160 + i * 20, cy = 70 + j * 20, v = Math.exp(-Math.pow((cx - 210) / 44, 2) - Math.pow((cy - 130) / 46, 2));
        map += T.rect(150 + i * 20, 60 + j * 20, 20, 20, { cls: "f-critic", rx: 0, style: "fill-opacity:" + (0.06 + 0.72 * v).toFixed(2) });
      }
      return T.rect(150, 60, 120, 140, { cls: "t-block", rx: 16, base: true }) +
        /* hold: horizontal squeeze */
        T.g({ a: "fA" }, T.rect(136, 118, 12, 24, { cls: "t-base", rx: 3 }) + T.rect(272, 118, 12, 24, { cls: "t-base", rx: 3 })) +
        T.cone(150, 130, 180, H, L, { a: "cA1" }) + T.cone(270, 130, 0, H, L, { a: "cA2" }) +
        T.g({ a: "arc" }, T.line(150, 130, 70, 130, { cls: "t-ghostl" }) + T.path("M94 130 A56 56 0 0 1 97.4 110.8", { cls: "t-arr" })) + T.sm(40, 96, "arctan μ", { a: "arcL" }) +
        T.path("M86 130 L334 130", { a: "sqA", cls: "t-goodl", draw: true }) +
        T.note(210, 232, "holds", { a: "holdL", anchor: "middle", cls: "t-note t-good" }) +
        /* slip: tilted squeeze */
        T.g({ a: "fB" }, T.rect(136, 74, 12, 24, { cls: "t-base", rx: 3 }) + T.rect(272, 162, 12, 24, { cls: "t-base", rx: 3 })) +
        T.cone(150, 86, 180, H, L, { a: "cB1" }) + T.cone(270, 174, 0, H, L, { a: "cB2" }) +
        T.path("M104 52.3 L316 207.7", { a: "sqB", cls: "t-badl", draw: true }) +
        T.path("M126 86 L126 118", { a: "slB1", cls: "t-badl", arrow: "bad" }) + T.path("M294 174 L294 142", { a: "slB2", cls: "t-badl", arrow: "bad" }) +
        T.note(210, 232, "slips", { a: "slipL", anchor: "middle", cls: "t-note t-bad" }) +
        /* learning: a per-pixel quality map, then 6-DoF poses */
        T.g({ a: "qmap" }, map) + T.sm(210, 42, "grasp quality", { a: "qL", anchor: "middle" }) +
        T.g({ a: "poses" }, pose(210, 58, 90, 26) + pose(150, 118, 0, 24) + pose(272, 150, 180, 24) + pose(160, 66, 45, 18) + pose(262, 72, 140, 14) + pose(152, 190, -30, 20)) +
        T.sm(210, 232, "6-DoF grasp poses", { a: "posL", anchor: "middle" });
    },
    beats: [
      { cap: "Two fingertips touch the object on opposite sides.", on: "fA", dur: 1800 },
      { cap: "Each contact allows forces in a cone of half-angle arctan μ.", on: "cA1 cA2 arc arcL", dur: 2400 },
      { cap: "The squeeze line lies inside both cones: the grasp holds.", on: "sqA holdL", dur: 2200 },
      { cap: "Tilt it past the cones and the fingers slip.", off: "fA cA1 cA2 arc arcL sqA holdL", on: "fB cB1 cB2 sqB slB1 slB2 slipL", dur: 2400 },
      { cap: "Learning scores every pixel for grasp quality.", off: "fB cB1 cB2 sqB slB1 slB2 slipL", on: "qmap qL", dur: 2200 },
      { cap: "Newer models output many 6-DoF grasp poses to try.", off: "qL", cls: "qmap:is-dim", on: "poses posL", dur: 2600 }
    ]
  });

  /* 15 · a five-finger hand: demos give the first success, randomized sim and memory carry it to reality */
  SC("dexterous", {
    title: "A dexterous hand: demos, randomized simulation, memory, retargeting", h: 270,
    draw: function (T) {
      var xs = [76, 97, 118, 139], fingers = "", tips = [[38, 146]];
      xs.forEach(function (x) {
        fingers += T.line(x, 162, x - 2, 132, { cls: "t-link" }) + T.line(x - 2, 132, x - 3, 106, { cls: "t-link" }) + T.circle(x - 2, 132, 4, { cls: "t-joint" });
        tips.push([x - 3, 104]);
      });
      var hand = T.line(66, 196, 46, 170, { cls: "t-link" }) + T.line(46, 170, 38, 146, { cls: "t-link" }) + T.circle(46, 170, 4, { cls: "t-joint" }) +
        fingers + T.rect(62, 158, 90, 68, { cls: "t-block", rx: 12 });
      /* a small hand glyph for the randomized copies */
      function mini(x, y, rot, s, lens) {
        var f = "";
        [-11, -4, 3, 10].forEach(function (fx, k) { f += T.line(fx, -2, fx, -2 - lens[k], { cls: "t-grip" }); });
        return T.g({ transform: "translate(" + x + " " + y + ") rotate(" + rot + ") scale(" + s + ")" }, f + T.line(-14, 12, -24, 0, { cls: "t-grip" }) + T.rect(-15, -2, 30, 24, { cls: "t-block", rx: 5 }));
      }
      var hk = [[286, 168], [306, 108], [330, 98], [354, 102], [376, 116]], kn = [[308, 208], [316, 178], [334, 174], [352, 176], [368, 184]], W = [344, 238];
      var skel = "", dots = "";
      hk.forEach(function (t, k) {
        skel += T.path("M" + W[0] + " " + W[1] + " L" + kn[k][0] + " " + kn[k][1] + " L" + t[0] + " " + t[1], { cls: "s-vision" }) + T.circle(kn[k][0], kn[k][1], 3.5, { cls: "f-vision" });
        dots += T.circle(t[0], t[1], 6, { a: "k" + k, cls: "f-vision" });
      });
      return T.g({ base: true }, hand) +
        T.line(44, 92, 164, 92, { a: "pen", cls: "t-accl", style: "stroke-width:6", base: true }) +
        T.path("M168 104 C 184 90, 184 64, 166 50", { a: "rot", cls: "t-arr", arrow: "acc", draw: true }) +
        T.sm(104, 252, "reorient a pen", { a: "penL", anchor: "middle" }) +
        T.g({ a: "curves" }, T.axes(236, 216, 164, 160, { base: false, xl: "robot-hours", yl: "success" }) +
          T.curve([[238, 212], [270, 211], [300, 213], [330, 211], [360, 212], [398, 211]], { cls: "t-badl" }) + T.sm(398, 202, "sparse RL", { anchor: "end" }) +
          T.curve([[238, 213], [262, 206], [288, 176], [312, 120], [340, 90], [370, 80], [398, 78]], { cls: "t-goodl" }) + T.sm(244, 74, "DAPG + demos")) +
        T.g({ a: "fan" }, mini(254, 128, -26, 0.85, [16, 20, 18, 14]) + mini(284, 104, -13, 1.05, [20, 24, 22, 17]) + mini(318, 96, 0, 0.9, [18, 26, 20, 12]) +
          mini(352, 104, 13, 1.1, [14, 18, 17, 13]) + mini(384, 128, 26, 0.8, [20, 22, 22, 18]) + T.sm(318, 178, "randomized simulation", { anchor: "middle" })) +
        T.path("M226 214 L162 204", { a: "xfer", cls: "t-arr", arrow: "ink", draw: true }) +
        T.g({ a: "mem" }, T.box(236, 196, 112, 40, "memory", { role: "latent" }) + T.path("M348 206 C 376 200, 376 232, 350 228", { cls: "t-arr", arrow: "ink" })) +
        T.g({ a: "skel" }, skel + T.circle(W[0], W[1], 4, { cls: "f-vision" }) + T.sm(330, 72, "human keypoints", { anchor: "middle" })) + dots;
    },
    beats: [
      { cap: "A five-finger hand must turn a pen in its fingers.", on: "rot penL", set: "pen.x1=64 pen.y1=124 pen.x2=150 pen.y2=58", dur: 2400 },
      { cap: "Sparse-reward RL stays flat; DAPG with demonstrations rises.", on: "curves", dur: 2600 },
      { cap: "Training runs across many randomized simulated hands.", off: "curves", on: "fan", dur: 2200 },
      { cap: "The real hand adapts, using a memory of recent steps.", on: "xfer mem", dur: 2400 },
      { cap: "A human hand is tracked as keypoints.", off: "fan xfer mem", on: "skel k0 k1 k2 k3 k4", dur: 2000 },
      { cap: "Retargeting maps each human fingertip onto a robot finger.", off: "skel",
        set: "k0.cx=38 k0.cy=146 k1.cx=73 k1.cy=104 k2.cx=94 k2.cy=104 k3.cx=115 k3.cy=104 k4.cx=136 k4.cy=104", dur: 2600 }
    ]
  });

  /* 16 · cloth as a point cloud, two arms on one clock, a base that moves every reach */
  SC("deformable", {
    title: "Cloth, two arms and a moving base", h: 300,
    draw: function (T) {
      var start = [[66, 70], [86, 48], [118, 56], [148, 44], [160, 66], [150, 90], [124, 100], [98, 90], [70, 100], [56, 86], [104, 72], [132, 76]];
      var dots = start.map(function (p, i) { return T.circle(p[0], p[1], 5, { a: "d" + i, cls: "f-vision" }); }).join("");
      var arms = function (x1, x2, o) { return T.arm(x1, 262, 75, -105, T.ext({ l1: 44, l2: 30, grip: "closed" }, o)) + T.arm(x2, 262, 105, 105, T.ext({ l1: 44, l2: 30, grip: "closed" }, o)); };
      var clock = T.line(140, 190, 227, 190, { cls: "t-ax" });
      for (var k = 0; k <= 6; k++) clock += T.line(140 + k * 15 - (k === 6 ? 3 : 0), 186, 140 + k * 15 - (k === 6 ? 3 : 0), 194, { cls: "t-ax" });
      var mob = T.g({ a: "mob", transform: "translate(90 234)" },
        T.circle(0, 0, 56, { cls: "t-ghostl" }) + T.rect(-34, 16, 68, 14, { cls: "t-base", rx: 4 }) + T.circle(-20, 34, 6, { cls: "t-joint" }) + T.circle(20, 34, 6, { cls: "t-joint" }) +
        T.arm(0, 0, 60, -60, { l1: 30, l2: 26 }));
      return T.poly([[52, 60], [80, 34], [118, 46], [150, 30], [170, 62], [158, 96], [126, 110], [96, 100], [62, 112], [46, 86]], { a: "cloth", cls: "t-block", base: true }) +
        T.rect(60, 32, 100, 78, { a: "goal", cls: "t-goodl t-dash", rx: 2 }) + T.sm(110, 130, "goal shape", { a: "goalL", anchor: "middle" }) + dots +
        T.sm(230, 52, "Chamfer to goal", { a: "chL" }) + T.rect(230, 64, 170, 16, { a: "chB", cls: "t-score", rx: 3 }) + T.sm(230, 100, "large", { a: "chV" }) +
        T.line(12, 144, 408, 144, { cls: "t-grid", base: true }) +
        T.g({ a: "lead" }, arms(34, 146, { cls: "is-ghost" }) + T.sm(90, 292, "leader", { anchor: "middle" })) +
        T.g({ a: "fol" }, arms(272, 384) + T.sm(328, 292, "follower", { anchor: "middle" })) +
        T.path("M176 212 L244 212", { a: "sync", cls: "t-arr", arrow: "ink", draw: true }) + T.sm(210, 202, "in sync", { a: "syncL", anchor: "middle" }) +
        T.box(12, 190, 108, 48, "policy π_θ", { a: "pol", role: "act" }) +
        T.g({ a: "ch" }, T.chunk(140, 202, 6, {}) + T.chunk(140, 222, 6, {}) + clock + T.sm(184, 178, "one clock", { anchor: "middle" })) +
        T.path("M232 222 L252 222", { a: "chA", cls: "s-act", arrow: "act", draw: true }) +
        T.line(290, 217, 360, 217, { a: "tgt", cls: "t-table" }) + T.rect(300, 197, 16, 20, { a: "tgtB", cls: "t-block", rx: 3 }) +
        mob + T.path("M90 234 L250 234", { a: "drive", style: "stroke:none" }) + T.sm(250, 170, "reach", { a: "reachL", anchor: "middle" });
    },
    beats: [
      { cap: "Cloth has no single pose, so it becomes a point cloud.", cls: "cloth:is-dim", on: "d0 d1 d2 d3 d4 d5 d6 d7 d8 d9 d10 d11", dur: 2400 },
      { cap: "The Chamfer distance compares that cloud to the goal shape.", on: "goal goalL chL chB chV", dur: 2200 },
      { cap: "As the cloth is spread, the Chamfer distance shrinks.", text: "chV=small", set: "chB.width=26 d0.cx=72 d0.cy=44 d1.cx=97 d1.cy=44 d2.cx=122 d2.cy=44 d3.cx=147 d3.cy=44 d4.cx=147 d4.cy=70 d5.cx=147 d5.cy=96 d6.cx=122 d6.cy=96 d7.cx=97 d7.cy=96 d8.cx=72 d8.cy=96 d9.cx=72 d9.cy=70 d10.cx=97 d10.cy=70 d11.cx=122 d11.cy=70", dur: 2600 },
      { cap: "A leader–follower rig records two arms moving in sync.", on: "lead fol sync syncL", dur: 2400 },
      { cap: "One policy outputs both arms' chunks on one clock.", off: "lead sync syncL", on: "pol ch chA", dur: 2400 },
      { cap: "A moving base shifts every reach the arm can make.", off: "fol pol ch chA", on: "tgt tgtB drive reachL", move: "mob:drive", dur: 2800 }
    ]
  });

  /* 17 · a humanoid reaches: its centre of mass must stay over the feet; a priority stack; tracking a human clip */
  SC("humanoid", {
    title: "A humanoid reaches while it balances", h: 296,
    draw: function (T) {
      var body = T.line(118, 188, 106, 224, { cls: "t-link" }) + T.line(106, 224, 94, 256, { cls: "t-link" }) + T.line(118, 188, 128, 224, { cls: "t-link" }) + T.line(128, 224, 140, 256, { cls: "t-link" }) +
        T.line(84, 259, 104, 259, { cls: "t-link" }) + T.line(132, 259, 152, 259, { cls: "t-link" }) +
        T.line(118, 128, 112, 158, { cls: "t-link", style: "opacity:.35" }) + T.line(112, 158, 108, 188, { cls: "t-link", style: "opacity:.35" }) +
        T.line(118, 188, 118, 124, { cls: "t-link" }) + T.circle(118, 102, 14, { cls: "t-joint" }) + T.circle(118, 188, 5, { cls: "t-joint" }) +
        T.circle(106, 224, 4, { cls: "t-joint" }) + T.circle(128, 224, 4, { cls: "t-joint" });
      function arm(a, e, h) { return T.g({ a: a }, T.line(118, 128, e[0], e[1], { cls: "t-link" }) + T.line(e[0], e[1], h[0], h[1], { cls: "t-link" }) + T.circle(e[0], e[1], 4, { cls: "t-joint" }) + T.circle(h[0], h[1], 5, { cls: "t-joint" })); }
      return T.table(40, 262, 200, { base: true }) + T.g({ base: true }, body) + T.circle(118, 128, 5, { cls: "t-joint", base: true }) +
        T.line(186, 146, 236, 146, { cls: "t-table", base: true }) + T.rect(194, 124, 20, 22, { cls: "t-block", rx: 3, base: true }) +
        arm("armA", [124, 160], [130, 190]) + arm("armB", [152, 134], [188, 134]) + arm("armC", [138, 100], [152, 70]) +
        T.rect(84, 266, 68, 6, { a: "sup", cls: "t-good-soft", rx: 2 }) + T.sm(118, 288, "support polygon", { a: "supL", anchor: "middle" }) +
        T.line(118, 184, 118, 264, { a: "proj", cls: "t-ghostl" }) + T.circle(118, 178, 7, { a: "com", cls: "f-state" }) + T.sm(96, 182, "CoM", { a: "comL", anchor: "end" }) +
        T.g({ a: "stack" }, T.sm(262, 28, "priority stack") + T.box(262, 40, 146, 30, "1  balance", { role: "state" }) + T.box(262, 76, 146, 30, "2  contacts", { role: "touch" }) + T.box(262, 112, 146, 30, "3  reach", { role: "act" })) +
        T.g({ a: "clip" }, T.rect(262, 164, 146, 92, { cls: "t-box r-vision", rx: 8 }) +
          T.circle(335, 182, 8, { cls: "s-vision" }) + T.path("M335 190 L335 222 M335 222 L325 248 M335 222 L345 248 M335 198 L350 186 L358 170 M335 198 L322 214", { cls: "s-vision" }) +
          T.sm(335, 276, "human clip", { anchor: "middle" })) +
        T.path("M254 214 L196 214", { a: "rt", cls: "t-arr t-dash", arrow: "ink", draw: true }) + T.sm(222, 204, "retarget", { a: "rtL", anchor: "middle" });
    },
    beats: [
      { cap: "Standing, its centre of mass sits over the support polygon.", on: "armA sup supL proj com comL", dur: 2400 },
      { cap: "It reaches: the centre of mass shifts toward the edge.", off: "armA", on: "armB", set: "com.cx=136 proj.x1=136 proj.x2=136", dur: 2600 },
      { cap: "A priority stack ranks balance first, then contacts, then the reach.", on: "stack", dur: 2600 },
      { cap: "A human motion clip is retargeted to the robot's body.", cls: "stack:is-dim", on: "clip rt rtL", dur: 2400 },
      { cap: "A learned tracker makes the robot follow the clip.", off: "armB", on: "armC", set: "com.cx=124 proj.x1=124 proj.x2=124", dur: 2400 }
    ]
  });

  /* 18 · touch matters only in contact: gate it by contact phase */
  SC("touch", {
    title: "Force is gated by contact before it reaches the policy", h: 270,
    draw: function (T) {
      var noise = [], x;
      for (x = 208; x <= 290; x += 6) noise.push([x, 142 + ((x * 7) % 5) - 2]);
      var tool = T.g({ a: "tool", transform: "translate(130 100)", base: true },
        T.line(0, -54, 0, -4, { cls: "t-link" }) + T.circle(0, -56, 6, { cls: "t-joint" }) + T.rect(-6, 4, 12, 44, { cls: "t-block", rx: 2 }) +
        T.line(-14, 0, 14, 0, { cls: "t-grip" }) + T.line(-8, 0, -8, 16, { cls: "t-grip" }) + T.line(8, 0, 8, 16, { cls: "t-grip" }));
      return T.table(40, 240, 150, { base: true }) + T.rect(62, 200, 61, 40, { cls: "t-block", rx: 2, base: true }) + T.rect(137, 200, 61, 40, { cls: "t-block", rx: 2, base: true }) +
        T.sm(130, 262, "peg and hole", { anchor: "middle", base: true }) +
        tool + T.path("M130 100 L130 152", { a: "p1", style: "stroke:none" }) + T.path("M130 152 L130 188", { a: "p2", style: "stroke:none" }) +
        T.circle(124, 200, 5, { a: "spark", cls: "f-touch" }) +
        T.axes(206, 150, 196, 110, { xl: "time", yl: "force" }) +
        T.curve(noise, { a: "nz", cls: "s-touch", draw: true }) + T.sm(214, 128, "noise", { a: "nzL" }) +
        T.line(290, 44, 290, 150, { a: "ct", cls: "t-ghostl" }) + T.sm(296, 56, "contact", { a: "ctL" }) +
        T.curve([[290, 142], [298, 110], [306, 84], [316, 96], [330, 78], [346, 90], [362, 74], [380, 86], [398, 80]], { a: "cf", cls: "s-touch", draw: true }) +
        T.path("M206 216 L270 216", { a: "fin", cls: "s-touch" }) + T.sm(206, 206, "features", { a: "finL" }) +
        T.line(280, 200, 280, 232, { a: "gate", cls: "t-link", base: true }) + T.circle(280, 200, 4, { cls: "t-joint", base: true }) +
        T.sm(280, 254, "φ_t ≈ 0", { a: "gL", anchor: "middle", base: true }) +
        T.path("M288 216 L318 216", { a: "fout", cls: "s-touch", arrow: "touch" }) +
        T.box(320, 194, 88, 44, "policy", { role: "act", base: true });
    },
    beats: [
      { cap: "In free space, force is only noise; the gate stays shut.", on: "nz nzL fin finL", dur: 2600 },
      { cap: "Contact begins: force jumps and the gate φ_t opens.", on: "p1 spark ct ctL cf", move: "tool:p1", cls: "spark:a-pulse", set: "gate.x2=310 gate.y2=204", text: "gL=φ_t ≈ 1", dur: 2600 },
      { cap: "Force features now flow into the policy.", on: "fout", cls: "fin:a-flow fout:a-flow", dur: 2200 },
      { cap: "Reacting through a fast loop, the peg slides into its hole.", off: "spark", on: "p2", move: "tool:p2", dur: 2400 }
    ]
  });

  /* 19 · physics priors: an energy-structured model extrapolates, until friction it lacks shows up */
  SC("physics", {
    title: "Energy structure extrapolates, until friction appears", h: 290,
    draw: function (T) {
      var O = 74, X = function (q) { return 215 + q * 56.5; }, tr = [], bb = [], es = [], data = "", q;
      function bbf(q) { var a = Math.abs(q); return a < 0.7 ? Math.sin(q) : Math.sign(q) * (0.644 + 0.32 * (a - 0.7) + 0.08 * Math.sin(3 * (a - 0.7))); }
      for (q = -3.2; q <= 3.21; q += 0.2) { tr.push([X(q), O - 40 * Math.sin(q)]); bb.push([X(q), O - 40 * bbf(q)]); es.push([X(q), O - 40 * 0.97 * Math.sin(q)]); }
      [-0.6, -0.45, -0.3, -0.15, 0, 0.15, 0.3, 0.45, 0.6].forEach(function (q, i) { data += T.circle(X(q), O - 40 * Math.sin(q) + (i % 2 ? 2 : -2), 3.5, { cls: "t-ink" }); });
      var decay = [], diss = [], flat = [[42, 200], [396, 200]], drift = [];
      for (var x = 42; x <= 396; x += 22) {
        decay.push([x, 200 + 50 * (1 - Math.exp(-(x - 42) / 110))]);
        diss.push([x, 201 + 49 * (1 - Math.exp(-(x - 42) / 106))]);
        drift.push([x, x < 180 ? 200 : 200 - 26 * Math.pow((x - 180) / 216, 1.4) + 2 * Math.sin(x / 9)]);
      }
      return T.g({ a: "data" }, T.rect(X(-0.7), 16, X(0.7) - X(-0.7), 116, { cls: "t-soft", rx: 4 }) + T.sm(X(-0.7) + 6, 126, "data")) +
        T.path("M30 " + O + " L392 " + O + " M215 16 L215 132", { cls: "t-ax", base: true }) + T.sm(398, O + 5, "q", { base: true }) + T.sm(209, 28, "accel.", { base: true, anchor: "end" }) + T.g({ a: "dots" }, data) +
        T.curve(tr, { a: "tr", cls: "t-ghost" }) +
        T.curve(bb, { a: "bb", cls: "t-badl", draw: true }) + T.sm(320, 26, "black box", { a: "bbL", anchor: "end" }) +
        T.curve(es, { a: "es", cls: "t-goodl", draw: true }) + T.sm(396, 102, "energy-structured", { a: "esL", anchor: "end" }) +
        T.axes(40, 262, 356, 90, { a: "ax2", base: false, xl: "time", yl: "energy" }) +
        T.curve(drift, { a: "eDr", cls: "t-badl", draw: true }) + T.sm(396, 164, "black box", { a: "eDrL", anchor: "end" }) +
        T.curve(flat, { a: "eFl", cls: "t-goodl", draw: true }) + T.sm(48, 192, "energy-structured", { a: "eFlL" }) +
        T.curve(decay, { a: "eTr", cls: "t-ghost" }) + T.curve(diss, { a: "eDi", cls: "t-goodl", draw: true }) + T.sm(48, 252, "+ dissipation term", { a: "eDiL" });
    },
    beats: [
      { cap: "Pendulum data exists only near q = 0; dashed is the truth.", on: "data dots tr", dur: 2400 },
      { cap: "A black-box fit matches the data, then wanders outside it.", on: "bb bbL", dur: 2400 },
      { cap: "An energy-structured fit follows the truth far beyond the data.", on: "es esL", dur: 2400 },
      { cap: "Its energy stays flat over time; the black box drifts.", on: "ax2 eDr eDrL eFl eFlL", dur: 2600 },
      { cap: "Add friction: the conservative model fails; a dissipation term fixes it.", off: "eDr eDrL", cls: "eFl:t-badl", text: "eFlL=conservative", on: "eTr eDi eDiL", dur: 3000 }
    ]
  });
})();
