/* TL;DR scenes · Part A (01–04). Drawn with RB.tl (core/44-tldr-cast.js); width 420, 3–6 beats, captions ≤ 12 words. */
(function () {
  var SC = window.RB.tldr.scene;

  /* 01 · the policy loop, then the three layers */
  SC("problem", {
    title: "A policy in the loop: observe, act, repeat", h: 262,
    draw: function (T) {
      var armA = T.arm(70, 192, 80, -120, { a: "armA" }), armB = T.arm(70, 192, 45, -75, { a: "armB", grip: "closed" });
      return T.table(14, 204, 220, { base: true }) + T.pad(168, 204, 52, { base: true }) +
        T.block(124, 180, 24, 24, { a: "blkA" }) + T.block(182, 176, 22, 22, { a: "blkB" }) + armA + armB +
        T.say(14, 12, "put the block on the pad", { a: "say", w: 198 }) + T.cam(36, 72, { a: "cam" }) +
        T.box(270, 94, 132, 50, "Policy π_θ", { role: "act", base: true }) +
        T.path("M52 62 C 130 40, 220 70, 268 108", { a: "pObs", draw: true, cls: "s-vision", arrow: "vision" }) + T.sm(150, 80, "o_t", { a: "oL" }) +
        T.path("M214 25 C 300 22, 330 50, 334 90", { a: "pIns", draw: true, cls: "s-lang", arrow: "lang" }) + T.sm(290, 18, "ℓ", { a: "lL" }) +
        T.path("M276 140 C 250 166, 230 158, 206 150", { a: "pAct", draw: true, cls: "s-act", arrow: "act" }) + T.sm(246, 178, "a_t", { a: "aL" }) +
        T.tok({ a: "tok", cls: "f-act" }) +
        T.g({ a: "layers" }, T.box(262, 186, 146, 22, "plan", { role: "lang", small: true }) + T.box(262, 212, 146, 22, "action  ← policy", { role: "act", small: true }) + T.box(262, 238, 146, 22, "motor torque", { role: "ink", small: true }));
    },
    beats: [
      { cap: "The camera sees o_t; an instruction ℓ arrives.", on: "armA blkA cam pObs oL say pIns lL", dur: 2200 },
      { cap: "The policy outputs an action a_t.", on: "pAct aL", move: "tok:pAct", dur: 2000 },
      { cap: "The arm moves and the scene changes.", on: "armB blkB", off: "armA blkA tok", dur: 2000 },
      { cap: "Then it repeats, step after step.", cls: "pObs:a-flow pAct:a-flow pIns:a-flow", dur: 2000 },
      { cap: "Three layers: plan, action, torque. Policies sit in the middle.", on: "layers", dur: 2800 }
    ]
  });
  /* 02 · a slow policy sets targets, a fast controller turns them into torque and decides the contact force */
  SC("control", {
    title: "A slow policy sets targets; a fast controller sets the force", h: 266,
    draw: function (T) {
      var slow = "", fast = "", x;
      for (x = 104; x <= 400; x += 74) slow += "M" + x + " 78 V94 ";
      for (x = 104; x <= 402; x += 5) fast += "M" + x + " 108 V118 ";
      /* the arm at the wall, drawn without its forearm: a rigid rod (PD) or a spring and damper (impedance) goes between */
      var sx = 40, sy = 224, ex = 79.6, ey = 184.4, wx = 172;
      var grip = T.line(wx, ey - 11, wx, ey + 11, { cls: "t-grip" }) + T.line(wx, ey - 11, wx + 14, ey - 11, { cls: "t-grip" }) + T.line(wx, ey + 11, wx + 14, ey + 11, { cls: "t-grip" });
      var armB = T.g({ a: "armB", cls: "t-arm" }, T.rect(sx - 22, sy + 4, 44, 12, { cls: "t-base", rx: 3 }) + T.line(sx, sy, ex, ey, { cls: "t-link" }) + grip +
        T.circle(sx, sy, 6, { cls: "t-joint" }) + T.circle(ex, ey, 5, { cls: "t-joint" }));
      var zig = "M" + ex + " 176 L96 176", k;
      for (k = 0; k < 11; k++) zig += " L" + (101 + k * 5) + " " + (k % 2 ? 183 : 169);
      zig += " L156 176 L" + wx + " 176";
      var spr = T.g({ a: "spr" }, T.path(zig, { cls: "t-line" }) +
        T.path("M" + ex + " 194 L118 194 M118 188 L118 200 M110 186 L140 186 M110 202 L140 202 M140 186 L140 202 M140 194 L" + wx + " 194", { cls: "t-line" }));
      return T.cam(20, 38, { a: "cam" }) + T.line(40, 38, 56, 38, { a: "pObs", cls: "s-vision", arrow: "vision" }) +
        T.box(58, 16, 112, 44, "Policy π_θ", { role: "act", base: true }) +
        T.line(170, 38, 236, 38, { a: "pTgt", cls: "s-act", arrow: "act", draw: true }) + T.sm(203, 28, "target", { a: "tgtL", anchor: "middle" }) +
        T.box(238, 16, 120, 44, "Controller", { role: "ink", base: true }) +
        T.line(358, 38, 400, 38, { a: "pTau", arrow: "ink", draw: true }) + T.sm(379, 28, "τ", { a: "tauL", anchor: "middle" }) +
        T.path(slow, { a: "slow", cls: "s-act", draw: true }) + T.sm(14, 92, "10 Hz", { a: "slowL" }) +
        T.path(fast, { a: "fast", draw: true }) + T.sm(14, 119, "1 kHz", { a: "fastL" }) +
        T.table(12, 236, 200, { base: true }) + T.rect(186, 140, 14, 96, { cls: "t-obst", rx: 2, base: true }) + T.sm(193, 254, "wall", { anchor: "middle", base: true }) +
        T.arm(sx, sy, 62, -62, { a: "armA", l1: 56, l2: 80 }) +
        T.line(ex, ey, wx, ey, { a: "rod", cls: "t-link" }) + T.sm(126, 170, "stiff", { a: "rodL", anchor: "middle" }) +
        spr + T.sm(126, 160, "spring+damper", { a: "sprL", anchor: "middle" }) + armB +
        T.axes(240, 236, 162, 88, { a: "ax", base: false, xl: "time", yl: "force" }) +
        T.path("M244 232 L296 232 L302 158 L308 194 L316 172 L324 180 L400 178", { a: "pd", cls: "t-badl", draw: true }) + T.sm(312, 160, "stiff PD", { a: "pdL" }) +
        T.path("M244 232 L296 232 C 310 232, 318 218, 340 218 L400 218", { a: "imp", cls: "t-goodl", draw: true }) + T.sm(400, 208, "impedance", { a: "impL", anchor: "end" });
    },
    beats: [
      { cap: "The policy sends a new target about 10 times a second.", on: "cam pObs pTgt tgtL slow slowL armA", dur: 2400 },
      { cap: "Underneath, the controller ticks near 1 kHz, many times per target.", on: "fast fastL pTau tauL", dur: 2400 },
      { cap: "Stiff PD control meets a wall: the contact force spikes.", off: "armA", on: "armB rod rodL ax pd pdL", dur: 2600 },
      { cap: "Impedance: a spring and damper give way; force stays low.", off: "rod rodL", on: "spr sprL imp impL", cls: "pd:is-dim pdL:is-dim", dur: 2800 }
    ]
  });

  /* 03 · try, score, store the transition, fit Q to its target, move the actor; human fixes join the buffer */
  SC("rl", {
    title: "Reinforcement learning: try, score, replay, update", h: 264,
    draw: function (T) {
      var P = T.armPose(46, 104, 55, -145, 64, 36), d = P.dir * Math.PI / 180, bx = P.tx + Math.cos(d) * 10, by = P.ty - Math.sin(d) * 10;
      var qx = [280, 310, 340, 370], q0 = [20, 44, 30, 16], qt = [34, 28, 62, 20], bars = "", tg = "";
      qx.forEach(function (x, i) {
        bars += T.vbar(x, 110, 20, q0[i], { a: "q" + i, base: true });
        tg += T.line(x - 4, 110 - qt[i], x + 24, 110 - qt[i], { cls: "t-accl t-dash" });
      });
      /* pills are drawn from (0,0) and ride an invisible copy of their route shifted by half their size */
      var pill = function (id, w, s, cls) { return T.g({ a: id }, T.rect(0, 0, w, 26, { cls: cls, rx: 13 }) + T.sm(w / 2, 18, s, { anchor: "middle", cls: "t-sm t-ink" })); };
      var ride = function (id, d, w) { return T.path(d.replace(/(-?[\d.]+)[ ,]+(-?[\d.]+)/g, function (m, x, y) { return (+x - w / 2) + " " + (+y - 13); }), { a: id, style: "stroke:none;fill:none" }); };
      var rows = T.rect(182, 204, 100, 10, { cls: "t-soft", rx: 2 }) + T.rect(182, 220, 100, 10, { cls: "t-soft", rx: 2 }) + T.rect(182, 236, 100, 10, { cls: "t-soft", rx: 2 });
      return T.table(14, 116, 150, { base: true }) + T.block(bx - 9, by - 9, 18, 18, { a: "blk" }) + T.arm(46, 104, 55, -145, { a: "arm", l1: 64, l2: 36 }) +
        T.g({ a: "coin" }, T.circle(136, 58, 13, { cls: "f-critic" }) + T.sm(136, 63, "r", { anchor: "middle", cls: "t-sm t-ink" })) + T.sm(156, 63, "reward", { a: "coinL" }) +
        T.g({ a: "buf" }, T.rect(170, 134, 124, 120, { cls: "t-box r-state", rx: 8 }) + rows) + T.sm(160, 244, "replay buffer", { a: "bufL", anchor: "end" }) +
        T.path("M96 142 C 130 150, 180 152, 232 152", { a: "pT", cls: "t-ghostl" }) + ride("mT", "M96 142 C 130 150, 180 152, 232 152", 108) + pill("tr", 108, "(s, a, r, s′)", "t-box r-state") +
        T.axes(264, 110, 140, 80, { yl: "Q vs target y" }) + bars + T.g({ a: "tgt" }, tg) +
        T.circle(320, 124, 7, { a: "act", cls: "f-act", base: true }) + T.sm(258, 129, "actor", { anchor: "end", base: true }) +
        T.g({ a: "hum" }, T.circle(30, 172, 7, { cls: "t-joint" }) + T.path("M30 179 L30 198 M18 186 L42 186 M30 198 L22 212 M30 198 L38 212", { cls: "t-line" })) + T.sm(30, 230, "human", { a: "humL", anchor: "middle" }) +
        T.path("M84 190 C 120 192, 170 186, 232 182", { a: "pH", cls: "t-ghostl" }) + ride("mH", "M84 190 C 120 192, 170 186, 232 182", 92) + pill("hp", 92, "human fix", "t-good-soft");
    },
    beats: [
      { cap: "The arm tries a lift; success earns a reward r.", on: "arm blk coin coinL", cls: "coin:a-pulse", dur: 2200 },
      { cap: "The transition (s, a, r, s′) drops into a replay buffer.", on: "buf bufL pT mT", move: "tr:mT", dur: 2400 },
      { cap: "Each Q bar moves toward its Bellman target y.", on: "tgt", set: "q0.y=76 q0.height=34 q1.y=82 q1.height=28 q2.y=48 q2.height=62 q3.y=90 q3.height=20", dur: 2400 },
      { cap: "The actor shifts toward the action with the highest Q.", set: "act.cx=350", dur: 2200 },
      { cap: "HIL-SERL: a human's corrections join the buffer too.", on: "hum humL pH mH", move: "hp:mH", dur: 2600 }
    ]
  });

  /* 04 · one simulator fans out into many; one policy trains on all; reality is one more sample; ADR widens the range */
  SC("sim2real", {
    title: "Randomize the simulator until reality is one more sample", h: 276,
    draw: function (T) {
      function card(x, id, o) {
        var s = (o.dim ? T.rect(x, 14, 70, 48, { cls: "t-soft", rx: 6 }) : "") + T.rect(x, 14, 70, 48, { cls: o.dim ? "t-ghostl" : "t-box", rx: 6 }) +
          T.line(x + 8, 52, x + 62, 52, { cls: "t-table" }) + T.rect(x + 35 - o.b / 2, 52 - o.b, o.b, o.b, { cls: "t-block", rx: 2 }) +
          (o.dim ? T.circle(x + 58, 25, 4, { cls: "t-ghost" }) : T.circle(x + 58, 25, 4, { cls: "t-acc" })) +
          (o.slip ? T.path("M" + (x + 10) + " 40 h10 M" + (x + 12) + " 46 h8", { cls: "t-arr" }) : "") +
          (o.grip ? T.path("M" + (x + 12) + " 56 l-4 5 M" + (x + 22) + " 56 l-4 5 M" + (x + 48) + " 56 l-4 5 M" + (x + 58) + " 56 l-4 5", { cls: "t-arr" }) : "");
        return T.g({ a: id }, s) + T.sm(x + 35, 80, o.label, { a: id + "L", anchor: "middle" });
      }
      var xs = [25, 125, 225, 325], fan = "";
      xs.forEach(function (x, i) { fan += "M" + (x + 35) + " 88 L" + (186 + i * 16) + " 100 "; });
      var dots = [[254, 226], [332, 206], [318, 226], [338, 190]].map(function (p, i) { return T.circle(p[0], p[1], 4, { a: "d" + i, cls: "t-ink" }); }).join("");
      return card(175, "one", { b: 16, label: "sim" }) +
        card(25, "c0", { b: 16, label: "low μ", slip: true }) + card(125, "c1", { b: 26, label: "heavy" }) + card(225, "c2", { b: 16, label: "dim light", dim: true }) + card(325, "c3", { b: 16, label: "high μ", grip: true }) +
        T.path(fan, { a: "fan", cls: "s-act" }) + T.box(150, 100, 120, 40, "Policy π_θ", { a: "pol", role: "act" }) +
        T.axes(170, 250, 232, 86, { xl: "friction μ", yl: "mass" }) +
        T.rect(236, 182, 110, 52, { a: "rng", cls: "fs-state", rx: 6 }) + T.sm(244, 199, "sim range", { a: "rngL" }) + dots +
        T.circle(212, 240, 4, { a: "d4", cls: "t-ink" }) + T.circle(376, 180, 4, { a: "d5", cls: "t-ink" }) +
        T.g({ a: "arm" }, T.table(12, 252, 120) + T.arm(46, 240, 70, -100, { l1: 44, l2: 38 })) + T.sm(14, 172, "real robot", { a: "armL" }) +
        T.path("M104 214 C 170 206, 230 212, 286 214", { a: "pReal", cls: "t-accl", arrow: "acc", draw: true }) + T.circle(296, 214, 7, { a: "real", cls: "t-acc" });
    },
    beats: [
      { cap: "One simulator: a single guess at friction, mass and light.", on: "one oneL", dur: 2000 },
      { cap: "Randomize it: every copy gets different physics and lighting.", off: "one oneL", on: "c0 c0L c1 c1L c2 c2L c3 c3L rng rngL d0 d1 d2 d3", dur: 2600 },
      { cap: "One policy π_θ trains across all of them.", on: "pol", cls: "fan:a-flow", dur: 2200 },
      { cap: "The real robot is just one more point inside the range.", on: "arm armL pReal real", cls: "real:a-pulse", dur: 2600 },
      { cap: "ADR widens the range while the policy keeps succeeding.", on: "d4 d5", set: "rng.x=196 rng.y=168 rng.width=196 rng.height=76", dur: 2600 }
    ]
  });
})();
