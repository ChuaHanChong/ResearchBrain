# Study Bench · Robot Learning: architecture diagrams plan

**Status:** done, 2026-09-30. 173 diagram specs are live on the main site. The Blueprint view (Raschka style) was added after review and is the default view; see `study-bench-robot-learning.md`.
**Request:** every topic that discusses models gets model architecture diagrams, all in one consistent format. The diagrams draw on the paper and the official code. They follow OpenWAM's system-level grammar and add layer-level detail in the style of Sebastian Raschka's LLM architecture comparisons.

---

## 1. What the two references contribute

| Reference | What to borrow | What not to copy |
|---|---|---|
| **OpenWAM** (`assets/repo_images/infra.jpg`; README architecture table; `architecture-extension.md`) | 1) **System view.** Each module is one colored box by role: *Video Gen.*, *Action Gen.* or *Action Expert*, *VLM Gen.*. Token strips sit **below** (inputs, grey) and **above** (outputs, colored by modality). 2) **The link between modules names the coupling**: joint self-attention (two-headed arrow), cross-attention (one-way arrow), two-stage IDM (dashed hand-off), MoE expert inside one box. 3) **Visibility attention mask** as a small V_obs / V_future / A_future matrix: Mutual, Action-sees-Video, Video-sees-Action, Isolated. 4) **A fixed pattern vocabulary**: Single-System Vanilla / MoE, Dual-System Joint Self-Attn / Joint Cross-Attn / IDM, Tri-System. 5) Frozen versus trained markers (the snowflake on the encoder). | Photographic panels and a busy multi-color frame. The site keeps Study Bench tokens and light/dark themes. |
| **Raschka, "The Big LLM Architecture Comparison"** and **"GPT-6 Astra / looped transformers"** | 1) **Layer view.** A vertical stack: token embedding at the bottom, then the repeated block drawn once with **×N**, then final norm, then head. 2) Every sub-layer labeled with its **type** (MHA / GQA / MQA / MLA, causal / bidirectional / sliding window; RMSNorm or LayerNorm and where it sits, pre or post; FFN with **d → d_ff → d** and activation such as SwiGLU or GeGLU; MoE router with experts and active experts). 3) **Numbers on the figure**: d_model, heads / KV heads, layers, d_ff, vocab, context, total and active parameters. 4) **Side-by-side comparison.** Aligned stacks with callouts on what differs. 5) **Loop arrow** for weight-shared or recurrent blocks, with the loop count. | Model-specific artwork. Here every model uses one renderer and one legend. |

## 2. One visual grammar, three zoom levels

All diagrams come from **one data spec per model**, drawn by **one renderer** (`RB.arch`). A new model can only look different where its spec actually differs.

**Zoom 1: System view** (OpenWAM grammar, always shown)
```
      [a₁ a₂ … a_H]      [o′ frames]           ← output tokens, colored by modality
   ┌──────────────┐ ⇄ ┌──────────────┐          ⇄ joint self-attn · → cross-attn · ⇢ two-stage
   │ Action expert│   │  Video DiT   │ ❄/▲      ❄ frozen · ▲ trained · "300M" badge
   │  Gemma 300M  │   │  Wan2.2 5B   │
   └──────────────┘   └──────────────┘
 [state q] [noise ε, τ]  [img ×3] [text ℓ]      ← input tokens (grey), with counts
 pattern chip: Dual-System · Joint Self-Attn     mask thumbnail: Mutual
```
- **Module roles, each with a fixed color token:** vision encoder, language/VLM backbone, video/world predictor, action head/expert, state/proprio encoder, touch/force encoder, latent/codebook, decoder/renderer, critic/value/verifier.
- **Tokens:** a modality color, a count (e.g. "256 × 3 views", "H = 50"), and a shape note on hover.
- **Links:** one of `joint-self-attn`, `cross-attn`, `concat/prefix`, `FiLM`, `KV-cache`, `two-stage`, `stop-grad`, `add/residual`, `loop`, each with a fixed stroke style. The legend is shared by the whole site.
- **Pattern chip:** OpenWAM's six patterns, extended for non-WAM families. Examples: *Autoregressive token VLA*, *VLM + diffusion/flow head*, *Encoder–decoder (CVAE)*, *1-D temporal U-Net*, *RSSM loop*, *JEPA predictor*, *Grasp CNN (per-pixel)*, *Point-cloud encoder + grasp head*, *Fusion encoder (FiLM / gate / MoE)*, *Physics-structured net*, *Actor–critic*.

**Zoom 2: Layer view** (Raschka grammar; click a module)
- The module expands into a vertical stack: patch or token embedding → **block ×N** (norm, attention type, residual, norm, FFN dims and activation, MoE router) → final norm → output projection or head.
- Non-transformer modules keep the same stack grammar with their own block types: U-Net (down or up stages with channel widths, FiLM conditioning), CNN (conv stages), MLP (widths), RSSM (GRU + prior/posterior, drawn with a loop arrow), point-cloud (PointNet++ set-abstraction levels), and diffusion step (timestep embedding, conditioning path).
- Every number carries a **provenance dot** on hover: *paper Table 3*, *config: `openpi/src/openpi/models/gemma.py` @commit*, or *not stated*. Unknown values show "–". Nothing is guessed.

**Zoom 3: Diff view** (Raschka side-by-side)
- Two or three specs aligned by module role. Values that differ are highlighted with the site's existing **new** and **changed** colors (the same `sb-new` / `sb-chg` used in the equation diffs), and a callout states the one change in words.
- Used for "Compare with parent" (Evolution) and in Compare → Side by side.

**Spec table** under every diagram: parameters (total / trainable / active), backbone, action representation and chunk H, inference steps, control rate, training data, and code link. It uses the same rows everywhere.

Accessibility and themes: pure SVG using tokens only; keyboard focus on modules; a text alternative listing modules and links; works at 400 px (the layer view stacks under the system view).

## 3. Data model

`data/arch/<topic>.js` registers specs with `RB.arch.spec({...})`:
```js
{ id: "pi0", method: "pi0",                // method id in data/methods.json
  pattern: "vlm-flow-expert",              // pattern chip
  params: { total: "3.3B", trained: "3.3B", ref: "paper §3" },
  inputs:  [{ mod: "vision", label: "3 views", n: "256 each", enc: "siglip" }, { mod: "lang", label: "ℓ" }, { mod: "state", label: "q_t" }, { mod: "action", label: "noisy A_t^τ", n: "H=50" }],
  outputs: [{ mod: "action", label: "velocity v", n: "H=50" }],
  modules: [
    { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", frozen: false,
      stack: { kind: "vit", layers: 27, d: 1152, heads: 16, ffn: 4304, patch: 14, img: 224, ref: "config …" } },
    { id: "gemma", role: "vlm", name: "Gemma 2B", stack: { kind: "decoder", layers: 18, d: 2048, heads: 8, kv: 1, ffn: 16384, act: "GeGLU", norm: "RMSNorm pre", pos: "RoPE", ref: "…" } },
    { id: "expert", role: "action-head", name: "Action expert (Gemma 300M)", stack: { kind: "decoder", layers: 18, d: 1024, heads: 8, kv: 1, ffn: 4096, … } } ],
  links: [{ from: "gemma", to: "expert", kind: "joint-self-attn", note: "shared attention, separate weights" }],
  mask: { axes: ["img+text", "state", "actions"], cells: "block-causal" },
  sources: [{ kind: "paper", ref: "Fig. 3, §3–4" }, { kind: "code", repo: "physical-intelligence/openpi", path: "src/openpi/models/pi0.py", commit: "…" }],
  callouts: [{ at: "expert", text: "Only this expert sees noisy actions" }],
  parent: "paligemma-vla-baseline" }
```
- Lives beside the method cards. The Compare table, Evolution and topics all read the same spec.
- `tools/check.py` gains an **arch lint**:
  - every number has a `ref`;
  - every module has a role;
  - links point at existing modules;
  - the method id exists;
  - the renderer fits at 1280 and 400 px.

## 4. Which models get diagrams

Counted from the 209 Tier-1 method cards. Datasets, benchmarks, pure algorithms and attacks get no architecture diagram. Attacks are drawn **on their host model's diagram** as an injection point.

**Full detail** (system + layer + diff), about 70 models:

| Topic | Models |
|---|---|
| B2 Generative heads | ACT, Diffusion Policy (CNN U-Net and transformer variants), DP3, 3D Diffuser Actor, Consistency Policy, VQ-BeT, AdaFlow |
| B3 Action representations | FAST (tokenizer pipeline), OpenVLA-OFT, CrossFormer, UniAct, SpatialVLA |
| B4 VLAs | Gato, VIMA, RT-1, RT-2, Octo, OpenVLA, RDT-1B, π0, π0.5, π0 + knowledge insulation, GR00T N1, SmolVLA, π0.7 (as far as disclosed), CogACT, RT-H, Hi Robot |
| C1 World models | World Models (V-M-C), PlaNet / Dreamer (RSSM), DreamerV3, TD-MPC2, V-JEPA 2(-AC), DINO-WM, UniSim, Cosmos WFM, Genie Envisioner, IRASim |
| C2 World action models (all 21) | UniPi, AVDC, SuSIE, GR-1, GR-2, PAD, VPP, Seer, UVA, UWM, FLARE, CoT-VLA, WorldVLA, F1, Motus, Cosmos Policy, LingBot-VA, DreamZero, Fast-WAM, mimic-video, VideoVLA; each also tagged with its **OpenWAM pattern** and **mask** |

**System view + spec table**, about 60 models, with layer view only where the paper or code gives dimensions:

| Topic | Models |
|---|---|
| A3 / A4 | Network diagrams for DQN, SAC / DDPG actor–critic, QT-Opt, HIL-SERL, RMA, teacher–student, asymmetric actor–critic |
| B1 | BC-Z |
| B5 | PaLM-E, CLIPort, RoboPoint, Inner Monologue / SayCan (as a module pipeline) |
| C3 | Ctrl-World, GPC, WMPO world model, World-Env, DreamGen |
| D2 | TCN, R3M, VIP, MVP, VC-1, LAPA (latent-action model + VLA), ATM, MimicPlay, EgoMimic, Being-H0, villa-X |
| E1 | GQ-CNN (Dex-Net), GG-CNN, GR-ConvNet, 6-DoF GraspNet, Contact-GraspNet, GraspNet-1B baseline, AnyGrasp, LGD, GraspGPT, ThinkGrasp, RT-Grasp, VCoT-Grasp, GraspVLA, DexGraspNet generator |
| E2 | Dactyl, DeXtreme, Visual Dexterity, Qi et al., HATO |
| E3 | DeformerNet, MoManipVLA, χ0, HOMER, Deep Whole-Body Control |
| E4 | HumanPlus (HST + HIT), OmniH2O, ExBody2, Radosavovic transformer |
| E5 (all 12) | RDP, ForceVLA, FoAR, ACP, 3D-ViTac, UniT, FuSe, Tactile-VLA, TacDiffusion, M3L, ViTaL, TA-VLA; fusion operator highlighted |
| E6 | DeLaN, HNN, LNN, Neural ODE, VIN, PI-TCN, port-Hamiltonian; physics structure shown as the block type |
| F1 | SAFE, FAIL-Detect, FIPER, Sentinel, V-GPS, RoboMonkey, GVL, RECAP, World Action Verifier; shows *where the score is read* |
| F2 | VLSA (CBF layer on a VLA), SafeVLA, SafeDreamer; BadVLA / FlowHijack / SilentDrift / FreezeVLA as overlays on OpenVLA or π0 |

**No diagram:** D1 datasets, F3 benchmarks, pure RL algorithms without a distinctive network (PPO, RLPD, SERL), RTC, UMI, GAT, DR / ADR, SINDy, PINN (shown as a loss, not a network), and attack papers without a model.

Total: about 130 diagrams.

## 5. Where diagrams appear

1. **Topic pages.** A new section **"Model architectures"**, placed between the key rules / algorithm and the playgrounds.
   - A chip row of the topic's models in time order.
   - The selected model's system view + spec table.
   - A **"Compare with predecessor"** toggle that switches to the diff view.
   - A "Layers" button for the layer view.
   - One Watch / Guide demo per topic that walks the anchor model's data flow: inputs, then each module, then outputs.
   - Rows in the methods table get an "Architecture" link.
2. **Compare page.** No new sub-tab. The existing **Side by side** view is extended:
   - An **Architecture** block at the top of the side-by-side columns: the picked models' system views aligned by module role, with the differing values highlighted.
   - A **"Layer stacks"** toggle that lines up the Raschka-style layer stacks of the picked models, with difference callouts.
   - Architecture rows in the side-by-side table: pattern, backbone, action head, attention and mask, parameters, inference steps.
   - Architecture presets next to the existing pickers: π0 vs SmolVLA vs GR00T N1; OpenVLA vs OpenVLA-OFT; UWM vs UVA vs Cosmos Policy; Diffusion Policy vs DP3; DreamerV3 vs TD-MPC2 vs DINO-WM.
   - The **Master table** gains a "Pattern" filter (the OpenWAM six plus the other families).
3. **Evolution page.** The node detail panel shows the architecture thumbnail. "Compare with parent" opens the diff view, so each lineage edge ("the one change") is visible in the network itself.
4. **Lab.** The VLA Dissector station and the WAM Coupling station reuse the renderer for their architecture panels (pattern and mask), so the lab and topics look the same.
5. **Glossary / Notation.** New terms (GQA, MQA, RMSNorm, SwiGLU/GeGLU, FiLM, AdaLN, DiT, MoT, block-causal mask, KV cache, patch embedding, U-Net, PointNet++, RSSM), each with a scene focus on the renderer legend.

## 6. How the facts are gathered

For each model, in this order:
1. **Paper.** The architecture figure, method section and appendix hyperparameter tables, read through alphaXiv (`get_paper_content`, `answer_pdf_queries`).
2. **Official code.** Config and model files through `read_files_from_github_repository` or a shallow clone: layer counts, widths, heads, FFN, norms, masks, chunk sizes and inference steps. The file path and commit are recorded. Repos to use include:

   | Area | Repos |
   |---|---|
   | π0 / π0.5 / FAST | openpi |
   | VLAs | OpenVLA, openvla-oft, Octo, RDT, Isaac-GR00T, CogACT, SpatialVLA, CrossFormer, VIMA, robotics_transformer (RT-1) |
   | SmolVLA / ACT | lerobot |
   | Policy heads | ACT (tonyzhaozh/act), diffusion_policy, 3D-Diffusion-Policy, 3d_diffuser_actor, vq_bet |
   | World models | dreamerv3, tdmpc2, vjepa2, dino_wm, Cosmos, Genie-Envisioner |
   | WAMs | GR-1, Seer, VPP, unified_video_action, unified-world-model, **OpenWAM** (pattern taxonomy and masks) |
   | Human video | r3m, vip, eai-vc, LAPA |
   | Grasping | ggcnn, robotic-grasping (GR-ConvNet), contact_graspnet, 6dof-graspnet |
   | Physics | deep_differential_network (DeLaN), hamiltonian-nn |

3. **Conflicts.** Where paper and code disagree (e.g. a layer count), the code at the recorded commit wins for "as released". The disagreement is added to the site's **"Where the papers disagree"** table.
4. **Undisclosed values.** For closed models (π0.7, Hi Robot, parts of GR00T, RT-2's internal widths) the diagram shows "not disclosed" instead of estimates.

## 7. Build phases

0. **Renderer + three exemplars** (me). `RB.arch` system / layer / diff views, legend, lint, and color tokens for module roles and modalities. Exemplars: **π0** (VLM + flow expert, block-causal mask), **Diffusion Policy** (1-D U-Net with FiLM), **UWM** (joint video–action DiT, per-modality noise). Published as a preview for your sign-off before fan-out.
1. **Spec writing** (workflow, about 13 agents, grouped by topic: B2+B3, B4 ×2, C1, C2 ×2, C3+F1, D2, E1, E2+E3+E4, E5, E6+A3+A4, B5+F2). Each agent reads the paper and code, writes `data/arch/<group>.js`, runs the arch lint and checks screenshots.
2. **Integration** (me):
   - the topic section, the Compare Side-by-side and Master-table extensions, Evolution panel, lab reuse, glossary terms and the conflict rows;
   - a full sweep (errors, audit, demos, 400 px, dark mode);
   - republish to the same artifact URL, update the playground HTML and the source zip, and update the project notes.

**Time:** the renderer and exemplars take about 1–1.5 hours. The spec writing takes about 3–4 hours at two agents in parallel. Integration and QA take about 1 hour. Page size grows by roughly 0.5–1 MB (specs are data, drawn at run time).

## 8. Decisions (settled 2026-09-30)
1. **Scope:** all ~130 diagrams. About 70 get full detail; the rest get a system view and spec table.
2. **Compare:** enhance the existing Compare page (Side by side and Master table). No new sub-tab.
3. **Checkpoint:** build the renderer and the three exemplars (π0, Diffusion Policy, UWM) and publish a preview for review before the spec-writing workflow.
