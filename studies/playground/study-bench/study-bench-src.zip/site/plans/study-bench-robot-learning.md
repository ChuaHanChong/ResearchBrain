# Study Bench · Robot Learning: build notes

**Status (2026-09-30):** built, checked and published, now with model architecture diagrams (see `study-bench-robot-learning-architecture-plan.md`). This implements `study-bench-robot-learning-plan.md` (plan v1.3); that plan's "Nothing is implemented yet" line is out of date.

## Deliverables
- Published artifact: "Study Bench · Robot Learning" (claude.ai/artifact/Qr2myNavBdVEPrALxErp88, private until shared).
- Architecture preview artifact (3 exemplars, superseded by the main site): claude.ai/artifact/JMNeatVhV3rLquVJYpk8tZ.
- Local file: `ResearchBrain/studies/playground/study-bench-robot-learning.html` (single file, MathJax from cdnjs).
- Source: `ResearchBrain/studies/playground/study-bench/study-bench-src.zip`. Unzip, then run `python3 tools/build.py`.

## What is in it
- Eight standard Study Bench pages (design system v2.7): Overview, Topic Explorer, Evolution, Compare, Interactive Lab, Reference, Glossary, Notation.
- 23 topics in Parts A–F. Each has concept cards, a flow diagram, a worked example, rules with symbol keys, 1–3 playgrounds with demos, a methods table, open problems, a quiz and flashcards.
- 626 unique method cards (209 read in full).
- **Model architectures: 173 diagram specs** across 19 topics, drawn by one renderer in three views:
  - Blueprint (Raschka style, the default): towers with a block ×N, residuals, RoPE/FiLM/AdaLN side inputs, sourced callouts and numbered zoom-ins.
  - System (OpenWAM style): role-coloured modules, token strips, coupling links and an attention mask.
  - Modules: layer stack plus facts, with "What changed" diffs against the parent model.
  - Every number carries a paper or code (repo@commit) source.
- Where the diagrams appear:
  - a "Model architectures" section in each topic;
  - Compare → Side by side (System / Blueprints) and Master-table filters ("Has a diagram", architecture family);
  - Evolution node details (a system thumbnail and an "Open the blueprint" link).
  - A "Network architecture" glossary group adds 15 terms.
- "Where the papers disagree" gained 139 paper-vs-code / paper-vs-itself rows found while drawing (`data/diff-arch.js`).
- Evolution: 8 lineage lanes, a 14-step story and equation diffs. Lab: 12 stations. Reference: formula sheet, decks, disagreements, dataset atlas, paper shelf.
- Navigation (P12) is excluded; benchmarks are topic F3.

## Source layout (inside the zip)
- `src/`: design-system drop-ins (unchanged), `rb.css`, `shell.html`.
- `core/`: `00-util`, `10-router`, `20-explorer`, `25-common`, `30-overview`, `35-arch` (system/modules/diff/lint), `36-blueprint` (Raschka-style renderer), `40-evolution`, `50-compare`, `60-lab`, `70-reference`, `80-glossary`, `90-boot`.
- `data/` (incl. `data/arch/*.js`, one file per model group), `topics/`, `stations/`.
- Tools:
  - `build.py`: `--only`, `--stations`, `--arch`, `--out`.
  - `check.py`: one topic, station or page.
  - `archcheck.py`: overlaps, overflows, lint and screenshots per model.
  - `sweep.py`: whole-site check.
  - `artifact_variant.py`: prepares the Artifact publish.
  - `shot.py`: screenshots.
- Contracts: `AUTHORING.md` (topics and stations) and `ARCH.md` (architecture specs).

## Architecture diagrams: how to add one
1. Write `RB.arch.spec({...})` in a `data/arch/<group>.js` file, following ARCH.md.
2. Run `python3 tools/build.py --only <topic> --stations none --arch <file> --out dist/a.html`.
3. Run `python3 tools/archcheck.py dist/a.html --topic <topic> --ids <id> --shots` and look at the screenshots.

## Final QA (2026-09-30, after the architecture diagrams)
- Whole-site sweep at 1280 px and 400 px: no errors, no horizontal scroll, and every cross-reference resolves.
- Every topic: no errors, empty word audit, and every demo (including the new architecture demos) finishes.
- All 173 specs pass `archcheck.py`: no overlaps, no text outside its box, and no unsourced numbers.
- Pages checked with their demos: Compare, Evolution and Glossary.

## Later changes (2026-09-30)
- Views are ordered System → Blueprint → Modules. Clicking a module in the System view spotlights that tower in the Blueprint; clicking a tower opens its Modules view.
- Evolution is self-contained: it has an inline "Compare with parent" panel and lens explanations. Race is removed. "All methods" now offers a visual Map next to the Table.
- A text pass (`core/26-textpass.js`) replaces survey codes with names and typesets plain-text math (π_θ, v_θ, a_t) with MathJax.
- New tools:
  - `gapcheck.py`: gaps between diagram towers and modules.
  - `spacecheck.py`: blocks on a page that touch.
  - `headgap.py`: room above section headings.
  - `clickfuzz.py`: clicks every control and watches for errors and NaN text.
  - `flowtest.py`: 21 scripted checks of the main interactions.

## Final bug review (2026-09-30)
- Fixed:
  - the text pass re-wrapping its own math output;
  - math spans created before MathJax loaded;
  - a throw on a malformed URL hash;
  - a media-query listener leak on re-mounts;
  - "Architecture" links for aliased methods (UMI, Phantom) opening the wrong topic;
  - duplicate captions when aliased methods are compared side by side;
  - arrow keys landing on a disabled lens;
  - no focus trap in the full-size blueprint overlay;
  - lab stations still running after leaving the Lab;
  - dead race code left behind;
  - the dataset atlas axis showing "1e6" instead of 1M, and its dots with no ring to separate overlaps.
- Checks after the fixes:
  - the click fuzz found no errors on any page, topic or lab station;
  - all 21 flow checks pass;
  - sweeps at 1280 px and 400 px are clean.

## TL;DR page (built, 2026-10-01)
- Ninth page `#tldr`, second in the nav, following design system v2.9. The plan is the Claude Doc "Study Bench · Robot Learning TL;DR plan".
- Contents: 23 sections in Parts A–F plus a recap loop, about 15 min.
  - Each section has an animated picture of 3–6 beats, a TL;DR, points, one equation taken from the topic's own rules, Remember and Go deeper.
  - Sections 13 (data + human video) and 16 (cloth, two arms, base) cover merged topics; dexterous hands is its own section.
- Drop-ins upgraded to v2.9 (TL;DR components plus the v2.8 lab toolbar API).
- Code:
  - `core/44-tldr-cast.js`: shared drawing cast (arm, camera, chunk, cones, boxes by role colour).
  - `core/45-tldr.js`: page, map, demo and search.
  - `tldr/00-text.js`: section text.
  - `tldr/{a..f}-scenes.js`: scenes.
- Checks:
  - `tools/tldrcheck.py`: beats, word limits, survey codes, Pause, reduced motion and per-beat contact sheets.
  - All 23 sections pass in light and dark, at 1280 and 400 px.
  - The sweeps, click test and flow tests are clean.

## In-context learning topic and design review (2026-10-01)
- New survey: X4 "In-Context Learning for Robots: Methods and Applications" (arXiv 2609.36012), shown as "In-context learning survey".
- Topic 10, "In-context learning" (id b6, Part B): 7 rules from X4, 3 playgrounds (replay/mix/blend stored actions, attention over demonstration steps, does it use the context?), 20 method cards and 8 glossary terms. Topics 10–23 were renumbered to 11–24.
- Architecture specs in `data/arch/b6-icl.js`: ICRT, Instant Policy, RICL (parent π0-FAST), VINN and MOSAIC, with 5 paper-vs-code rows added to `diff-arch-2.js`.
- Evolution: an "In-context learning" lane (10 nodes), plus an X4 "Context operation" lens (Retrieve · Attend · Encode · Parse, from Table 3).
- TL;DR: now 24 sections. The new section 10 has a frozen-policy scene: swap the demonstration and the action follows.
- Design review against v2.8/v2.9:
  - The Lab bench bar is now monogram · name · subtitle · prov, then status · Tours ▾ · On this bench, with no glossary button. `data/lab-bench.js` holds 110 terms and 36 tours across the 12 stations. Glossary "Show in Lab ▶" opens the panel on the term.
  - The TL;DR checker now also enforces Remember ≤ 15 words.
  - The new DS CSS gives section-map rows equal height.
- Checks:
  - `tools/labbar.py` is new.
  - Clean: all 24 TL;DR sections in light, dark and at 400 px; archcheck b6; gapcheck; the sweeps; spacing; the flow tests; labbar; and the click test on the changed pages.

## v2.10 TopicLinks (2026-10-01)
- Every topic is linked at three depths, following design system v2.10 (as the RL, MARL and Modern Robotics sites do):
  - its Summary card on Overview (`#overview/<topic>`, which centres and flashes the card);
  - its TL;DR section;
  - its Topic Explorer page.
- `core/46-topiclinks.js` builds `RB.topicLinks(here, topics)`, which gives the fixed order Summary · ▶ TL;DR · Open topic → and leaves out the current place. It also keeps one ✓ Understood state (`.sb-done`) in sync on the card, the TL;DR section, the section-map box and the topic head.
- Overview: the six part cards became 24 topic Summary cards, grouped under part strips. Each card has its key equation (the TL;DR rule), key terms, sources and TopicLinks, and clicking a card opens its topic.
- TL;DR: "Go deeper" is retired. The merged data section shows one "Open topic: <name> →" per topic, and the recap links to "See the evolution →".
- New check `tools/topiclinks.py` (order, every link resolves, the deep link centres its card, the done state syncs). It passes, as do the sweeps, spacing, flow tests, labbar, tldrcheck and the click test.
- Drop-in CSS updated to DS v2.10.
