# Study Bench · Robot Learning: build notes

**Status (2026-09-30):** built, checked and published, now with model architecture diagrams (see `study-bench-robot-learning-architecture-plan.md`). This implements `study-bench-robot-learning-plan.md` (plan v1.3); that plan's "Nothing is implemented yet" line is out of date.

## Deliverables
- Published artifact: "Study Bench · Robot Learning" (claude.ai/artifact/Qr2myNavBdVEPrALxErp88, private until shared).
- Architecture preview artifact (3 exemplars, superseded by the main site): claude.ai/artifact/JMNeatVhV3rLquVJYpk8tZ.
- Local file: `ResearchBrain/studies/playground/study-bench-robot-learning.html` (single file, MathJax from cdnjs).
- Source: `ResearchBrain/studies/playground/study-bench/study-bench-robot-learning-src.zip`. Unzip, then run `python3 tools/build.py`.

## What is in it
- Eight standard Study Bench pages (design system v2.7): Overview, Topic Explorer, Evolution, Compare, Interactive Lab, Reference, Glossary, Notation.
- 23 topics in Parts A–F. Each has concept cards, a flow diagram, a worked example, rules with symbol keys, 1–3 playgrounds with demos, a methods table, open problems, a quiz and flashcards.
- 626 unique method cards (209 read in full).
- **Model architectures: 173 diagram specs** across 19 topics, drawn by one renderer in three views:
  - Blueprint (Raschka style, the default): towers with a block ×N, residuals, RoPE/FiLM/AdaLN side inputs, sourced callouts and numbered zoom-ins.
  - System (OpenWAM style): role-coloured modules, token strips, coupling links and an attention mask.
  - Modules: layer stack plus facts, with "What changed" diffs against the parent model.
  - Every number carries a paper or code (repo@commit) source.
- Where the diagrams appear:
  - a "Model architectures" section in each topic;
  - Compare → Side by side (System / Blueprints) and Master-table filters ("Has a diagram", architecture family);
  - Evolution node details (a system thumbnail and an "Open the blueprint" link).
  - A "Network architecture" glossary group adds 15 terms.
- "Where the papers disagree" gained 139 paper-vs-code / paper-vs-itself rows found while drawing (`data/diff-arch.js`).
- Evolution: 8 lineage lanes, a 14-step story and equation diffs. Lab: 12 stations. Reference: formula sheet, decks, disagreements, dataset atlas, paper shelf.
- Navigation (P12) is excluded; benchmarks are topic F3.

## Source layout (inside the zip)
- `src/`: design-system drop-ins (unchanged), `rb.css`, `shell.html`.
- `core/`: `00-util`, `10-router`, `20-explorer`, `25-common`, `30-overview`, `35-arch` (system/modules/diff/lint), `36-blueprint` (Raschka-style renderer), `40-evolution`, `50-compare`, `60-lab`, `70-reference`, `80-glossary`, `90-boot`.
- `data/` (incl. `data/arch/*.js`, one file per model group), `topics/`, `stations/`.
- Tools:
  - `build.py`: `--only`, `--stations`, `--arch`, `--out`.
  - `check.py`: one topic, station or page.
  - `archcheck.py`: overlaps, overflows, lint and screenshots per model.
  - `sweep.py`: whole-site check.
  - `artifact_variant.py`: prepares the Artifact publish.
  - `shot.py`: screenshots.
- Contracts: `AUTHORING.md` (topics and stations) and `ARCH.md` (architecture specs).

## Architecture diagrams: how to add one
1. Write `RB.arch.spec({...})` in a `data/arch/<group>.js` file, following ARCH.md.
2. Run `python3 tools/build.py --only <topic> --stations none --arch <file> --out dist/a.html`.
3. Run `python3 tools/archcheck.py dist/a.html --topic <topic> --ids <id> --shots` and look at the screenshots.

## Final QA (2026-09-30, after the architecture diagrams)
- Whole-site sweep at 1280 px and 400 px: no errors, no horizontal scroll, and every cross-reference resolves.
- Every topic: no errors, empty word audit, and every demo (including the new architecture demos) finishes.
- All 173 specs pass `archcheck.py`: no overlaps, no text outside its box, and no unsourced numbers.
- Pages checked with their demos: Compare, Evolution and Glossary.
