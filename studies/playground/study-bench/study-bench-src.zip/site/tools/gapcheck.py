#!/usr/bin/env python3
"""Measure spacing inside every architecture diagram (blueprint and system view).
Reports, per spec: the smallest horizontal gap between neighbouring towers (whole tower incl. callouts),
the smallest gap between any two text/box elements that belong to different towers, zoom-in boxes that touch,
and system-view module boxes closer than the minimum. usage: python3 tools/gapcheck.py dist/x.html [--min 24]"""
import argparse, asyncio, json, os
from playwright.async_api import async_playwright

JS = r"""
(minGap) => {
  const out = [];
  const host = document.createElement('div'); host.style.cssText = 'position:absolute;left:0;top:0;width:4000px'; document.body.appendChild(host);
  RB.arch.all().forEach(s => {
    const rec = { id: s.id, issues: [] };
    if (s.blueprint) {
      host.innerHTML = RB.arch.blueprint(s);
      const svg = host.querySelector('svg'); svg.style.width = svg.getAttribute('width') + 'px'; svg.style.minWidth = '0'; svg.style.maxWidth = 'none';
      const towers = Array.from(svg.querySelectorAll('g.rb-bp-tower'));
      const boxes = towers.map(t => ({ mod: t.getAttribute('data-tower'), b: t.getBBox(), els: Array.from(t.querySelectorAll('text, rect, circle, path')).map(e => ({ e, b: e.getBBox() })).filter(x => x.b.width || x.b.height) }));
      for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
        const A = boxes[i], B = boxes[j];
        let g = Infinity, pair = '';
        A.els.forEach(a => B.els.forEach(b => {
          const vx = Math.max(b.b.x - (a.b.x + a.b.width), a.b.x - (b.b.x + b.b.width)), vy = Math.max(b.b.y - (a.b.y + a.b.height), a.b.y - (b.b.y + b.b.height));
          if (vy < 0) { if (vx < g) { g = vx; pair = (a.e.textContent || a.e.tagName).slice(0, 24) + ' | ' + (b.e.textContent || b.e.tagName).slice(0, 24); } }
        }));
        if (g < minGap) rec.issues.push(`towers ${A.mod}/${B.mod} ${Math.round(g)}px apart (${pair})`);
      }
      const zs = Array.from(svg.querySelectorAll('g.rb-bp-zg')).map(z => z.getBBox ? z.getBoundingClientRect() : null);
      const tb = towers.map(t => t.getBoundingClientRect()), zb = Array.from(svg.querySelectorAll('g.rb-bp-zg')).map(z => z.getBoundingClientRect());
      const towerBottom = Math.max(...tb.map(r => r.bottom)), zTop = zb.length ? Math.min(...zb.map(r => r.top)) : Infinity;
      if (zTop - towerBottom < 12) rec.issues.push(`zoom-ins ${Math.round(zTop - towerBottom)}px below the towers`);
      /* cross-tower link lanes that run through another element */
      Array.from(svg.querySelectorAll('path.rb-bp-xl')).forEach(p => {
        const d = p.getAttribute('d').match(/-?[\d.]+/g).map(Number); const pts = []; for (let k = 0; k + 1 < d.length; ) { pts.push(d.slice(k, k + 2)); k += 2; }
      });
    }
    host.innerHTML = RB.arch.system(s);
    const mods = Array.from(host.querySelectorAll('g.rb-am rect.rb-am-box')).map(r => r.getBBox());
    mods.sort((a, b) => a.x - b.x);
    for (let k = 1; k < mods.length; k++) { const g = mods[k].x - (mods[k - 1].x + mods[k - 1].width); if (g < 60) rec.issues.push(`system modules ${Math.round(g)}px apart`); }
    if (rec.issues.length) out.push(rec);
  });
  host.remove();
  return out;
}
"""

async def main(a):
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": 1600, "height": 1000})
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto("file://" + os.path.abspath(a.file) + "#overview"); await pg.wait_for_timeout(6000)
        r = await pg.evaluate(JS, a.min)
        await b.close()
    print(json.dumps(r, indent=1, ensure_ascii=False)); print(len(r), "specs with spacing issues")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--min", type=int, default=24)
    asyncio.run(main(ap.parse_args()))
