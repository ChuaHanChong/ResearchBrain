#!/usr/bin/env python3
"""Screenshot one element of a built page.
usage: python3 tools/shot.py FILE HASH SELECTOR OUT.png [--w 1280] [--dark] [--js "code run before the shot"]"""
import argparse, asyncio, os
from playwright.async_api import async_playwright


async def main(a):
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": a.w, "height": 900})
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto("file://" + os.path.abspath(a.file) + "#" + a.hash)
        await pg.wait_for_timeout(a.wait)
        if a.dark:
            await pg.evaluate("document.documentElement.setAttribute('data-theme','dark')")
        if a.js:
            await pg.evaluate(a.js)
            await pg.wait_for_timeout(1200)
        el = pg.locator(a.sel).first
        await el.scroll_into_view_if_needed()
        await pg.wait_for_timeout(500)
        await el.screenshot(path=a.out)
        print("hscroll", await pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth"))
        await b.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("file"); ap.add_argument("hash"); ap.add_argument("sel"); ap.add_argument("out")
    ap.add_argument("--w", type=int, default=1280); ap.add_argument("--dark", action="store_true"); ap.add_argument("--js"); ap.add_argument("--wait", type=int, default=7000)
    asyncio.run(main(ap.parse_args()))
