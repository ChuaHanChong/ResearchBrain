#!/usr/bin/env python3
"""Integration sweep over the full build: visit every topic, station and page tab; collect errors, warnings,
audit, math errors, NaN and horizontal scroll; then check cross-references statically against the live registries.
usage: python3 tools/sweep.py dist/study-bench-robot-learning.html [--width 1280] [--only topics|stations|pages]"""
import argparse, asyncio, json, os, re, glob
from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAGES = [("overview", None), ("tldr", None), ("evolution", "lineage"), ("evolution", "story"), ("evolution", "equations"),
         ("compare", "sbs"), ("compare", "table"), ("compare", "decide"),
         ("reference", "formulas"), ("reference", "cards"), ("reference", "differences"), ("reference", "datasets"), ("reference", "papers"),
         ("glossary", "visual"), ("glossary", "map"), ("glossary", "az"), ("notation", None), ("lab", None), ("explorer", None)]

SCOPE_JS = r"""
(sel) => {
  const scope = document.querySelector(sel) || document;
  const vis = e => !!(e.offsetParent || e.getClientRects().length);
  return {
    audit: (StudyBench.audit ? StudyBench.audit(scope) : []).map(a => `${a.selector} ${a.words}/${a.limit}: ${a.text.slice(0,70)}`),
    math: Array.from(scope.querySelectorAll('mjx-merror, [data-mjx-error]')).map(e => (e.getAttribute('data-mjx-error') || e.textContent).slice(0, 100)),
    nan: Array.from(scope.querySelectorAll('*')).filter(e => e.children.length === 0 && vis(e) && /\b(NaN|undefined)\b/.test(e.textContent)).map(e => e.textContent.slice(0, 60)).slice(0, 5),
    shownErr: Array.from(scope.querySelectorAll('.sb-error')).map(e => e.textContent.slice(0, 120)),
    hscroll: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
    wide: Array.from(scope.querySelectorAll('*')).filter(e => { if (!vis(e)) return false; const r = e.getBoundingClientRect(); return r.right > document.documentElement.clientWidth + 2 && getComputedStyle(e).position !== 'fixed' && !e.closest('.rb-math, .sb-table-wrap, [style*=overflow], .sb-scroll, pre, .rb-canvas-scroll, .sb-dag, .sb-flow'); }).slice(0,3).map(e => e.tagName + '.' + (e.className && e.className.baseVal !== undefined ? e.className.baseVal : e.className) + ' ' + (e.textContent||'').slice(0,40))
  };
}
"""


async def main(a):
    url = "file://" + os.path.abspath(a.file)
    out = {"pageErrors": [], "consoleErrors": [], "items": {}}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={"width": a.width, "height": 900})
        pg = await ctx.new_page()
        cur = {"k": "load"}
        pg.on("console", lambda m: out["consoleErrors"].append(cur["k"] + ": " + m.text[:250]) if m.type == "error" and "fonts.g" not in m.text and "ERR_" not in m.text else None)
        pg.on("pageerror", lambda e: out["pageErrors"].append(cur["k"] + ": " + str(e)[:300]))
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(url + "#overview"); await pg.wait_for_timeout(8000)
        reg = await pg.evaluate("""() => ({topics: RB.TOPIC_INDEX.map(t => t.id), stations: RB.STATION_INDEX.map(s => s.id), terms: Object.keys(RB.terms), symbols: Object.keys(RB.symbols), methods: Object.keys(RB.M)})""")
        targets = []
        if a.only in (None, "pages"): targets += [("page", f"{pgid}/{tab}" if tab else pgid, f"#view-{pgid}") for pgid, tab in PAGES]
        if a.only in (None, "topics"): targets += [("topic", f"explorer/{t}", f"#{t}") for t in reg["topics"]]
        if a.only in (None, "stations"): targets += [("station", f"lab/{s}", "#benchHost") for s in reg["stations"]]
        for kind, h, sel in targets:
            cur["k"] = h
            nw = len(await pg.evaluate("RB.warnings"))
            await pg.evaluate(f"location.hash = '#{h}'"); await pg.wait_for_timeout(a.wait)
            r = await pg.evaluate(SCOPE_JS, sel)
            ws = await pg.evaluate("RB.warnings")
            r["warnings"] = ws[nw:]
            r = {k: v for k, v in r.items() if v}
            if r: out["items"][h] = r
        out["allWarnings"] = await pg.evaluate("RB.warnings")
        await b.close()
    # static cross-references
    src = {f: open(f).read() for f in glob.glob(os.path.join(ROOT, "topics/*.js")) + glob.glob(os.path.join(ROOT, "stations/*.js")) + glob.glob(os.path.join(ROOT, "data/*.js")) + glob.glob(os.path.join(ROOT, "core/*.js"))}
    bad = []
    T, S, TE, SY, M = set(reg["topics"]), set(reg["stations"]), set(reg["terms"]), set(reg["symbols"]), set(reg["methods"])
    for f, s in src.items():
        fn = os.path.relpath(f, ROOT)
        for m in re.findall(r"#explorer/([a-z0-9]+)", s):
            if m not in T: bad.append(f"{fn}: #explorer/{m}")
        for m in re.findall(r"#lab/([a-z0-9]+)", s):
            if m not in S: bad.append(f"{fn}: #lab/{m}")
        for m in re.findall(r"#glossary/([A-Za-z0-9-]+)", s):
            if m not in TE and m not in ("visual", "map", "az"): bad.append(f"{fn}: #glossary/{m}")
        for m in re.findall(r"#compare/sbs/([A-Za-z0-9.,_-]+)", s):
            for x in m.split(","):
                if x and x not in M: bad.append(f"{fn}: #compare/sbs method {x}")
        for m in re.findall(r"sym-([A-Za-z0-9-]+)\}", s):
            if m not in SY: bad.append(f"{fn}: sym-{m}")
        for m in re.findall(r"term: *[\"']([A-Za-z0-9-]+)[\"']", s):
            if m not in TE: bad.append(f"{fn}: term {m}")
    out["xref"] = sorted(set(bad))
    print(json.dumps(out, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--only"); ap.add_argument("--wait", type=int, default=2500)
    asyncio.run(main(ap.parse_args()))
