#!/usr/bin/env python3
"""Scripted checks of the main interactions. usage: python3 tools/flowtest.py FILE"""
import asyncio, os, sys, json
from playwright.async_api import async_playwright
async def main(f):
    res = []; errs = []
    def ok(name, cond, info=""): res.append(("PASS" if cond else "FAIL") + " " + name + ("" if cond else "  " + str(info)[:300]))
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": 1280, "height": 900})
        pg.on("pageerror", lambda e: errs.append(str(e)[:200])); pg.on("console", lambda m: errs.append(m.text[:200]) if m.type == "error" else None)
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        url = "file://" + os.path.abspath(f)
        await pg.goto(url + "#explorer/b2"); await pg.wait_for_timeout(9000)
        go = lambda h: pg.evaluate(f"location.hash='#{h}'")
        # 1 textpass: no nested \( and no raw \( left
        raw = await pg.evaluate("""()=>{const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n,c=0,ex=[];while(n=w.nextNode()){if(/\\\\\\(/.test(n.nodeValue)&&n.parentElement.offsetParent&&!n.parentElement.closest('code,pre,script,style,.rb-math:not(.is-typeset)')){c++;if(ex.length<3)ex.push(n.nodeValue.slice(0,60))}}return [c,ex,document.querySelectorAll('.rb-imath .rb-imath').length]}""")
        ok("inline math typeset (no raw \\( ) on b2", raw[0] == 0, raw); ok("no nested math spans", raw[2] == 0, raw)
        # 2 arch widget in topic b2: system module click -> blueprint focus; show whole; tower click -> modules
        host = pg.locator('[data-arch-topic="b2"]').first
        await host.scroll_into_view_if_needed()
        mod = host.locator("svg [data-mod]").first
        n = await mod.count(); ok("b2 system view has clickable modules", n > 0)
        if n:
            await mod.click(); await pg.wait_for_timeout(500)
            fb = await host.locator(".rb-bp-focusbar").count(); ok("module click shows blueprint focus bar", fb == 1)
            if fb:
                await host.locator("[data-bp-all]").click(); await pg.wait_for_timeout(400)
                ok("'Show the whole model' clears focus", await host.locator(".rb-bp-focusbar").count() == 0)
        tw = host.locator("[data-tower]").first
        if await tw.count():
            await tw.click(); await pg.wait_for_timeout(500)
            ok("tower click opens Modules view", await host.locator('[id$="-mods"]').count() > 0)
        # 3 full-size overlay: Tab trap, Esc close
        await host.locator('[id$="-seg"] button[value="blueprint"]').click(); await pg.wait_for_timeout(400)
        full = host.locator("[data-bp-full]")
        if await full.count():
            await full.click(); await pg.wait_for_timeout(300)
            await pg.keyboard.press("Tab"); inside = await pg.evaluate("!!document.activeElement.closest('.rb-bp-over')")
            ok("overlay keeps focus inside on Tab", inside)
            await pg.keyboard.press("Escape"); await pg.wait_for_timeout(200)
            ok("Esc closes overlay", await pg.locator(".rb-bp-over").count() == 0)
            ok("page scroll unlocked after close", await pg.evaluate("document.documentElement.style.overflow") == "")
        else: ok("full-size button present", False)
        # 4 compare sbs alias captions
        await go("compare/sbs/umi,diffusion-policy"); await pg.wait_for_timeout(2500)
        caps = await pg.evaluate("[...document.querySelectorAll('.rb-sbs-afig figcaption')].map(x=>x.textContent.trim())")
        ok("alias caption names UMI", any("UMI" in c and "drawn as" in c for c in caps), caps)
        picks = await pg.evaluate("[...document.querySelectorAll('.sb-sbs-head .sb-sbs-col b')].map(x=>x.textContent)")
        ok("sbs shows exactly the two hash picks", len(picks) == 2, picks)
        # 5 atlas card Architecture link for umi goes to b2
        await go("compare/table"); await pg.wait_for_timeout(2000)
        dot = pg.locator('.rb-atlas-dot[data-mid="umi"]')
        if await dot.count():
            await dot.first.dispatch_event("click"); await pg.wait_for_timeout(400)
            href = await pg.evaluate("(document.querySelector('[data-arch-open]')||{}).getAttribute ? document.querySelector('[data-arch-open]').getAttribute('href') : null")
            ok("atlas Architecture link for UMI points to b2", href and href.startswith("#explorer/b2"), href)
        else: ok("atlas has umi dot", False)
        # 6 evolution compare-with-parent
        await go("evolution/lineage"); await pg.wait_for_timeout(2500)
        nodes = pg.locator("#evoMap .sb-dag-node")
        cnt = await nodes.count(); ok("lineage has nodes", cnt > 3, cnt)
        await nodes.nth(min(3, cnt - 1)).click(); await pg.wait_for_timeout(600)
        btn = pg.locator("[data-evo-cmp]")
        if await btn.count():
            await btn.first.click(); await pg.wait_for_timeout(1200)
            ok("compare-with-parent panel appears", await pg.locator("#evoCmp").count() == 1)
            link = await pg.evaluate("[...document.querySelectorAll('#evoCmp a')].map(a=>a.getAttribute('href')).filter(h=>h&&h.startsWith('#compare/sbs/'))[0]")
            ok("'Open just these two' link has 2 ids", link and len(link.split('/')[-1].split(',')) == 2, link)
        # lens keyboard skip disabled
        await pg.locator("#evoLens button").first.focus()
        for _ in range(4): await pg.keyboard.press("ArrowRight")
        dis = await pg.evaluate("(()=>{const a=document.activeElement;return a && a.closest('#evoLens') ? a.disabled : 'lost'})()")
        ok("lens arrows never land on a disabled lens", dis is False, dis)
        # 7 lab leave/return
        await go("lab/heads"); await pg.wait_for_timeout(2500)
        await go("overview"); await pg.wait_for_timeout(800); await go("lab/heads"); await pg.wait_for_timeout(2500)
        ok("lab station remounts after leaving", await pg.evaluate("document.querySelector('#stScene').children.length > 0"))
        # 8 malformed hash
        errs_before = len(errs); await go("compare/sbs/%E0%A4%A"); await pg.wait_for_timeout(800)
        ok("malformed hash does not throw", len(errs) == errs_before, errs[errs_before:])
        # 9 dark mode
        await go("overview"); await pg.wait_for_timeout(500); await pg.click("#themeBtn"); await pg.wait_for_timeout(500)
        ok("theme toggles", await pg.evaluate("document.documentElement.getAttribute('data-theme')") in ("dark", "light"))
        # 10 search
        await pg.keyboard.press("Control+k"); await pg.wait_for_timeout(400)
        await pg.keyboard.type("diffusion policy"); await pg.wait_for_timeout(500)
        nres = await pg.evaluate("document.querySelectorAll('[role=option], .sb-search-result, .sb-cmdk-item').length")
        ok("search returns results", nres > 0, nres)
        await pg.keyboard.press("Enter"); await pg.wait_for_timeout(1000)
        ok("search Enter navigates", await pg.evaluate("location.hash") not in ("#overview", ""), await pg.evaluate("location.hash"))
        await b.close()
    print("\n".join(res)); print("errors:", json.dumps(list(dict.fromkeys(errs))[:10], ensure_ascii=False))
asyncio.run(main(sys.argv[1]))
