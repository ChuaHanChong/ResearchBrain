#!/usr/bin/env python3
"""Assemble Study Bench · Robot Learning into one self-contained HTML file.

usage: python3 tools/build.py [--out dist/study-bench-robot-learning.html] [--only b2,e1] [--stations heads,grasp] [--no-methods-trim]
  --only       include only these topic files (others render as "being written")
  --stations   include only these station files
"""
import argparse, glob, json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOPIC_ORDER = "a1 a2 a3 a4 b1 b2 b3 b4 b5 b6 c1 c2 c3 d1 d2 e1 e2 e3 e4 e5 e6 f1 f2 f3".split()
STATION_ORDER = "heads tokens vla timing worldmodel wam grasp compliance sim2real physics data verifier".split()
DATA_ORDER = ["topics-index.js", "papers.js", "symbols.js"]  # then methods.js (generated), then the rest alphabetically


def read(p):
    with open(os.path.join(ROOT, p), encoding="utf-8") as f:
        return f.read()


def script(code, name):
    code = code.replace("</script", "<\\/script")
    return f"<script>/* ---- {name} ---- */\n{code}\n</script>\n"


def methods_js():
    ms = json.load(open(os.path.join(ROOT, "data/methods.json"), encoding="utf-8"))
    js = "window.RB.METHODS = " + json.dumps(ms, ensure_ascii=False, separators=(",", ":")) + ";\n"
    js += "window.RB.M = {}; window.RB.METHODS.forEach(function (m) { window.RB.M[m.id] = m; });\n"
    return js


def build(out, only=None, stations=None, arch=None):
    head = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Study Bench · Robot Learning</title>
<meta name="description" content="Interactive study companion to fifteen robot-learning surveys and the 626 method papers they cite: VLAs, world action models, data, grasping, touch and verifiers.">
<style>
{read('src/study-bench.css')}
{read('src/rb.css')}
</style>
<script>(function(){{try{{var t=localStorage.getItem("sb-theme");if(t==="light"||t==="dark")document.documentElement.setAttribute("data-theme",t);}}catch(e){{}}}})();</script>
</head>
<body class="sb-root">
"""
    parts = [head, read("src/shell.html"), "\n"]
    parts.append(script(read("src/study-bench.js"), "study-bench.js (design system, do not edit)"))
    parts.append(script(read("core/00-util.js"), "core/00-util.js"))
    for d in DATA_ORDER:
        parts.append(script(read("data/" + d), "data/" + d))
    parts.append(script(methods_js(), "data/methods.js (generated from the reading pass)"))
    rest = sorted(os.path.basename(p) for p in glob.glob(os.path.join(ROOT, "data/*.js")))
    for d in rest:
        if d in DATA_ORDER:
            continue
        parts.append(script(read("data/" + d), "data/" + d))
    for c in sorted(glob.glob(os.path.join(ROOT, "core/*.js"))):
        n = os.path.basename(c)
        if n.startswith("00-") or n.startswith("90-"):
            continue
        parts.append(script(read("core/" + n), "core/" + n))
    # architecture specs (need core/35-arch.js)
    for c in sorted(glob.glob(os.path.join(ROOT, "data/arch/*.js"))):
        if arch is not None and os.path.basename(c)[:-3] not in arch:
            continue
        parts.append(script(read("data/arch/" + os.path.basename(c)), "data/arch/" + os.path.basename(c)))
    # shared content helpers (art library etc.)
    for c in sorted(glob.glob(os.path.join(ROOT, "parts/*.js"))):
        parts.append(script(read("parts/" + os.path.basename(c)), "parts/" + os.path.basename(c)))
    for t in TOPIC_ORDER:
        p = f"topics/{t}.js"
        if only and t not in only:
            continue
        if os.path.exists(os.path.join(ROOT, p)):
            parts.append(script(read(p), p))
    for s in STATION_ORDER:
        p = f"stations/{s}.js"
        if stations is not None and s not in stations:
            continue
        if os.path.exists(os.path.join(ROOT, p)):
            parts.append(script(read(p), p))
    # TL;DR page: section text, then scenes (need core/44-tldr-cast.js)
    for c in sorted(glob.glob(os.path.join(ROOT, "tldr/*.js"))):
        parts.append(script(read("tldr/" + os.path.basename(c)), "tldr/" + os.path.basename(c)))
    parts.append(script(read("core/90-boot.js"), "core/90-boot.js"))
    parts.append('<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/3.2.2/es5/tex-svg.min.js" async></script>\n</body>\n</html>\n')
    html = "".join(parts)
    os.makedirs(os.path.dirname(os.path.join(ROOT, out)), exist_ok=True)
    with open(os.path.join(ROOT, out), "w", encoding="utf-8") as f:
        f.write(html)
    return os.path.join(ROOT, out), len(html)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="dist/study-bench-robot-learning.html")
    ap.add_argument("--only", default=None)
    ap.add_argument("--stations", default=None)
    ap.add_argument("--arch", default=None, help="comma list of data/arch file stems to include (default: all)")
    a = ap.parse_args()
    only = set(a.only.split(",")) if a.only else None
    st = set(a.stations.split(",")) if a.stations is not None else None
    ar = set(a.arch.split(",")) if a.arch else None
    path, n = build(a.out, only, st, ar)
    print(f"built {path} ({n/1e6:.2f} MB)")
