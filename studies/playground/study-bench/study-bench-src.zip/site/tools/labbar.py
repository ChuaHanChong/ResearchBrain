#!/usr/bin/env python3
"""Check the Lab bench bar (design system v2.8): On this bench and Tours ▾, on every station.

usage: python3 tools/labbar.py dist/lab.html [--station heads,grasp] [--quick]

For every station it opens On this bench, clicks every "Point to it" (the target must get outlined) and every
"Definition ↗" (the Glossary must open on that term), opens every term's "Show in Lab" deep link
(#lab/<station>/term-<id>, which may switch the station's mode first), opens Tours ▾ and runs every tour to the end
with Run it ▶ and Next. It reports page and console errors, empty panels, missing targets, duplicate ids, unknown
term ids, word-limit breaches (watch ≤ 15 words, step text ≤ 25), tour shape (2–3 tours, 3–8 steps) and the
Glossary's Show in Lab ▶ button. --quick skips the Definition ↗ round trips. Exit code 1 if anything is wrong.
"""
import argparse, asyncio, json, os, sys
from playwright.async_api import async_playwright

STATIONS = "heads tokens vla timing worldmodel wam grasp compliance sim2real physics data verifier".split()

DUP_IDS = "() => { const c = {}; document.querySelectorAll('[id]').forEach(e => { c[e.id] = (c[e.id] || 0) + 1; }); return Object.keys(c).filter(k => c[k] > 1); }"

ROWS = """() => { const p = document.querySelector('.sb-benchterms'); if (!p || p.hidden) return null;
  return Array.from(p.querySelectorAll('.sb-benchterm')).map(li => ({ id: li.getAttribute('data-term'), name: li.querySelector('b').textContent,
    where: li.closest('.sb-benchterms-group').querySelector('.sb-benchterms-where').textContent,
    val: (li.querySelector('.sb-benchterm-val') || {}).textContent || null, point: !!li.querySelector('[data-point]'),
    href: li.querySelector('a.sb-link').getAttribute('href') })); }"""

STATIC = """() => {
  const B = RB.LAB_BENCH || {}, out = { problems: [], counts: {} };
  const words = s => String(s || '').trim().split(/\\s+/).filter(Boolean).length;
  Object.keys(B).forEach(s => {
    if (!RB.stations[s]) out.problems.push('bench data for unknown station ' + s);
    const b = B[s], ts = b.tours || [], ids = {};
    out.counts[s] = { terms: new Set((b.terms || []).map(e => e.t)).size, tours: ts.length, steps: ts.map(t => t.steps.length) };
    (b.terms || []).forEach(e => {
      if (!RB.terms[e.t]) out.problems.push(s + ': unknown term id ' + e.t);
      if (words(e.watch) > 15) out.problems.push(s + ' · ' + e.t + ': watch has ' + words(e.watch) + ' words');
      if (!/^(Scene|Controls|Readouts|Chart)$/.test(e.w)) out.problems.push(s + ' · ' + e.t + ': bench part ' + e.w);
    });
    if (ts.length < 2 || ts.length > 3) out.problems.push(s + ': ' + ts.length + ' tours (want 2–3)');
    ts.forEach(t => {
      if (ids[t.id]) out.problems.push(s + ': duplicate tour id ' + t.id); ids[t.id] = 1;
      if (t.steps.length < 3 || t.steps.length > 8) out.problems.push(s + ' · ' + t.id + ': ' + t.steps.length + ' steps (want 3–8)');
      if (!t.steps.some(st => st.run && st.run.length)) out.problems.push(s + ' · ' + t.id + ': no step has Run it');
      t.steps.forEach((st, i) => { if (words(st.text) > 25) out.problems.push(s + ' · ' + t.id + ' step ' + (i + 1) + ': ' + words(st.text) + ' words');
        if (!st.at || !st.name || !st.title) out.problems.push(s + ' · ' + t.id + ' step ' + (i + 1) + ': missing at/name/title'); });
    });
  });
  STATIONS.forEach(s => { if (!B[s]) out.problems.push('no bench data for ' + s); });
  return out; }""".replace("STATIONS", json.dumps(STATIONS))


async def main(a):
    url = "file://" + os.path.abspath(a.file)
    only = a.station.split(",") if a.station else STATIONS
    rep = {"problems": [], "stations": {}}
    P = rep["problems"]
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": 1280, "height": 900})
        cons = []
        pg.on("pageerror", lambda e: cons.append("pageerror: " + str(e)))
        pg.on("console", lambda m: cons.append("console: " + m.text) if m.type == "error" else None)
        await pg.goto(url + "#lab/" + only[0]); await pg.wait_for_timeout(1500)
        st = await pg.evaluate(STATIC)
        P.extend(st["problems"]); rep["counts"] = st["counts"]

        # the bench bar: identical parts, no Glossary link
        bar = await pg.evaluate("""() => { const h = document.querySelector('#labBench .sb-bench-bar'); return { mono: !!h.querySelector('.sb-mono-mark'), title: !!h.querySelector('.sb-bench-title'), sub: !!h.querySelector('.sb-status'), prov: !!h.querySelector('.sb-prov'), live: !!h.querySelector('.sb-live'), tours: !!h.querySelector('#labTourBtn'), bench: !!h.querySelector('#labBenchBtn'), glossary: !!h.querySelector('a[href="#glossary"]') }; }""")
        for k in ["mono", "title", "sub", "prov", "live", "tours", "bench"]:
            if not bar[k]: P.append("bench bar: missing " + k)
        if bar["glossary"]: P.append("bench bar: still has a Glossary link")

        for s in only:
            info = {"rows": 0, "points": 0, "defs": 0, "deeplinks": 0, "tours": 0, "steps": 0}
            rep["stations"][s] = info
            await pg.evaluate(f"RB.go('#lab/{s}')"); await pg.wait_for_timeout(700)
            await pg.click("#labBenchBtn"); await pg.wait_for_timeout(300)
            rows = await pg.evaluate(ROWS)
            if not rows: P.append(f"{s}: On this bench is empty or did not open"); rows = []
            info["rows"] = len(rows)
            seen = set()
            for r in rows:
                if r["id"] in seen: P.append(f"{s}: term listed twice: {r['id']}")
                seen.add(r["id"])
                if r["href"] != "#glossary/" + r["id"]: P.append(f"{s} · {r['id']}: Definition link is {r['href']}")
                if not r["point"]: P.append(f"{s} · {r['id']}: no Point to it")
            room = await pg.evaluate("() => { const h = document.getElementById('labBench'), p = document.querySelector('.sb-benchterms'); const hr = h.querySelector('.rb-bench-grid').getBoundingClientRect(), pr = p.getBoundingClientRect(); return { cls: h.classList.contains('has-benchterms'), overlap: hr.right > pr.left + 1 }; }")
            if not room["cls"]: P.append(f"{s}: bench did not get .has-benchterms")
            if room["overlap"]: P.append(f"{s}: bench grid runs under the panel")
            # Point to it
            for i, r in enumerate(rows):
                ok = await pg.evaluate("""(id) => { const li = document.querySelector('.sb-benchterms .sb-benchterm[data-term="' + id + '"]'); const b = li && li.querySelector('[data-point]'); if (!b) return 'no button';
                    document.querySelectorAll('.sb-pointed').forEach(x => x.classList.remove('sb-pointed')); b.click(); const t = document.querySelector('#benchHost .sb-pointed'); if (!t) return 'nothing outlined'; const r = t.getBoundingClientRect(); if (!r.width || !r.height) return 'outlined element has no size';
                    if (r.bottom < 0 || r.top > innerHeight) return 'target not scrolled into view'; return ''; }""", r["id"])
                if ok: P.append(f"{s} · {r['id']}: Point to it: {ok}")
                else: info["points"] += 1
            # Definition ↗
            if not a.quick:
                for r in rows:
                    await pg.evaluate("(id) => document.querySelector('.sb-benchterms .sb-benchterm[data-term=\"' + id + '\"] a.sb-link').click()", r["id"])
                    await pg.wait_for_timeout(250)
                    g = await pg.evaluate("() => ({ hash: location.hash, page: RB.currentPage(), name: (document.querySelector('#vgHost .sb-vg-name') || {}).textContent || '', panel: !!document.querySelector('.sb-benchterms:not([hidden])') })")
                    want = await pg.evaluate("(id) => RB.terms[id].name", r["id"])
                    if g["page"] != "glossary" or g["name"] != want: P.append(f"{s} · {r['id']}: Definition ↗ opened {g['hash']} showing '{g['name']}'")
                    elif g["panel"]: P.append(f"{s}: On this bench stayed open on the Glossary page")
                    else: info["defs"] += 1
                await pg.evaluate(f"RB.go('#lab/{s}')"); await pg.wait_for_timeout(600)
            # every term entry of this station through its Show in Lab deep link
            ents = await pg.evaluate(f"(RB.LAB_BENCH['{s}'].terms || []).map(e => e.t).filter((x, i, a) => a.indexOf(x) === i)")
            for t in ents:
                href = await pg.evaluate("(t) => RB.labTermHref(t)", t)
                h = f"#lab/{s}/term-{t}"
                await pg.evaluate(f"location.hash = '{h}'"); await pg.wait_for_timeout(1100)
                res = await pg.evaluate("""(id) => { const p = document.querySelector('.sb-benchterms'); if (!p || p.hidden) return 'panel closed';
                    const li = p.querySelector('.sb-benchterm[data-term="' + id + '"]'); if (!li) return 'term not listed after switching';
                    if (!li.classList.contains('is-current')) return 'row not marked'; return ''; }""", t)
                if res: P.append(f"{s} · {t}: {h}: {res}")
                else: info["deeplinks"] += 1
                if href and not href.startswith("#lab/"): P.append(f"{s} · {t}: labTermHref gave {href}")
            # Tours ▾
            await pg.evaluate(f"RB.go('#lab/{s}')"); await pg.wait_for_timeout(300)
            await pg.evaluate("RB.labTour.stop(); document.getElementById('labTourMenu').hidden = true;")
            await pg.click("#labTourBtn"); await pg.wait_for_timeout(250)
            menu = await pg.evaluate("() => { const m = document.getElementById('labTourMenu'); const r = m.getBoundingClientRect(), b = document.getElementById('labTourBtn').getBoundingClientRect(); return { open: !m.hidden, items: Array.from(m.querySelectorAll('[data-tour]')).map(x => x.getAttribute('data-tour')), under: r.top >= b.bottom - 1 && r.top < b.bottom + 40, onscreen: r.left >= 0 && r.right <= innerWidth + 1, coach: Array.from(document.querySelectorAll('.sb-coach')).some(c => !c.hidden) }; }")
            if not menu["open"]: P.append(f"{s}: Tours ▾ did not open")
            if not menu["under"]: P.append(f"{s}: Tours menu is not under its button")
            if not menu["onscreen"]: P.append(f"{s}: Tours menu leaves the screen")
            if menu["coach"]: P.append(f"{s}: Tours ▾ started the site tour")
            for k, tid in enumerate(menu["items"]):
                if k:
                    await pg.click("#labTourBtn"); await pg.wait_for_timeout(200)
                await pg.click(f'#labTourMenu [data-tour="{tid}"]'); await pg.wait_for_timeout(250)
                n = await pg.evaluate(f"RB.LAB_BENCH['{s}'].tours.filter(t => t.id === '{tid}')[0].steps.length")
                for i in range(n):
                    step = await pg.evaluate(f"RB.LAB_BENCH['{s}'].tours.filter(t => t.id === '{tid}')[0].steps[{i}]")
                    card = await pg.evaluate("() => { const c = document.getElementById('labTourCard'); return { open: !c.hidden, count: document.getElementById('labTourCount').textContent, run: !!document.getElementById('labTourRun'), next: document.getElementById('labTourNext').textContent, back: document.getElementById('labTourBack').disabled }; }")
                    if not card["open"]: P.append(f"{s} · {tid}: tour card closed at step {i + 1}"); break
                    if card["count"] != f"{i + 1} of {n}": P.append(f"{s} · {tid}: counter says '{card['count']}' at step {i + 1}")
                    if card["back"] != (i == 0): P.append(f"{s} · {tid}: Back enabled wrongly at step {i + 1}")
                    if bool(step.get("run")) != card["run"]: P.append(f"{s} · {tid}: Run it button mismatch at step {i + 1}")
                    if card["run"]:
                        await pg.click("#labTourRun")
                        done = False
                        for _ in range(60):
                            await pg.wait_for_timeout(150)
                            stx = await pg.evaluate("(document.getElementById('labTourStatus') || {}).textContent || ''")
                            if stx.startswith("Done"): done = True; break
                        if not done: P.append(f"{s} · {tid}: step {i + 1} Run it did not finish")
                    tgt = await pg.evaluate("""(at) => { const el = at.indexOf('ro:') === 0 ? document.querySelector('#benchHost [data-ro="' + at.slice(3) + '"]') : document.getElementById(at.slice(1));
                        return !!(el && el.getClientRects().length && !el.closest('[hidden]')); }""", step["at"])
                    if not tgt: P.append(f"{s} · {tid}: step {i + 1} target {step['at']} missing or hidden")
                    await pg.click("[data-tour-look]")
                    info["steps"] += 1
                    await pg.click("#labTourNext"); await pg.wait_for_timeout(200)
                closed = await pg.evaluate("document.getElementById('labTourCard').hidden")
                if not closed: P.append(f"{s} · {tid}: Finish did not close the tour")
                else: info["tours"] += 1
            # tour deep link
            if menu["items"]:
                await pg.evaluate(f"location.hash = '#lab/{s}/tour-{menu['items'][0]}'"); await pg.wait_for_timeout(700)
                ok = await pg.evaluate("!document.getElementById('labTourCard').hidden && /1 of/.test(document.getElementById('labTourCount').textContent)")
                if not ok: P.append(f"{s}: deep link tour-{menu['items'][0]} did not start the tour")
                await pg.evaluate("RB.labTour.stop()")
            dups = await pg.evaluate(DUP_IDS)
            if dups: P.append(f"{s}: duplicate ids: {', '.join(dups[:8])}")
            empt = await pg.evaluate("() => Array.from(document.querySelectorAll('#benchHost .sb-error')).map(e => e.textContent.slice(0, 100))")
            if empt: P.append(f"{s}: station shows an error: {empt[0]}")
            await pg.evaluate("() => { const p = document.querySelector('.sb-benchterms'); if (p && !p.hidden) p.querySelector('.sb-benchterms-x').click(); }")

        # Glossary: Show in Lab ▶ only on bench terms, and it opens the lab pointed at the term
        await pg.evaluate("RB.go('#glossary/visual')"); await pg.wait_for_timeout(700)
        g = await pg.evaluate("""() => { const benched = Object.keys(RB.terms).filter(k => RB.labTermHref(k)), other = Object.keys(RB.terms).filter(k => !RB.labTermHref(k));
            return { benched: benched.length, all: Object.keys(RB.terms).length, sample: benched.slice(0, 3), other: other[0] }; }""")
        rep["glossary"] = g
        for t in g["sample"]:
            await pg.evaluate(f"RB.go('#glossary/visual/{t}')"); await pg.wait_for_timeout(400)
            vis = await pg.evaluate("() => { const b = document.querySelector('#vgHost [data-act=\"show\"]'); return !!(b && b.getClientRects().length); }")
            if not vis: P.append(f"glossary · {t}: no Show in Lab ▶"); continue
            await pg.click('#vgHost [data-act="show"]'); await pg.wait_for_timeout(1300)
            r = await pg.evaluate("(id) => ({ page: RB.currentPage(), hash: location.hash, cur: !!document.querySelector('.sb-benchterms:not([hidden]) .sb-benchterm.is-current[data-term=\"' + id + '\"]') })", t)
            if r["page"] != "lab" or not r["cur"]: P.append(f"glossary · {t}: Show in Lab ▶ gave {r}")
            await pg.evaluate("RB.go('#glossary/visual')"); await pg.wait_for_timeout(400)
        if g["other"]:
            await pg.evaluate(f"RB.go('#glossary/visual/{g['other']}')"); await pg.wait_for_timeout(400)
            vis = await pg.evaluate("() => { const b = document.querySelector('#vgHost [data-act=\"show\"]'); return !!(b && b.getClientRects().length); }")
            if vis: P.append(f"glossary · {g['other']}: Show in Lab ▶ shown for a term not on any bench")

        rep["errors"] = [c for c in cons if "favicon" not in c]
        P.extend(rep["errors"])
        await b.close()
    print(json.dumps(rep, indent=1, ensure_ascii=False))
    print(("FAIL: %d problems" % len(P)) if P else "OK: no problems", file=sys.stderr)
    return 1 if P else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("file"); ap.add_argument("--station"); ap.add_argument("--quick", action="store_true")
    sys.exit(asyncio.run(main(ap.parse_args())))
