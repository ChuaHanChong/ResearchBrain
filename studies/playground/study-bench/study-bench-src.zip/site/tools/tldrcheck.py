#!/usr/bin/env python3
"""TL;DR page checks.
usage: python3 tools/tldrcheck.py FILE [--ids a,b] [--shots DIR] [--dark] [--width 1280]
For every section: beats point at parts that exist, beat count 3–6, word limits (RB.warn from RB.tldrAudit),
no survey codes (P01–X3) in visible text, no NaN/undefined, text inside the SVG viewBox, Pause stops every figure,
reduced motion shows the finished picture. With --shots: one contact sheet per section (every beat) + the section at its last beat."""
import argparse, asyncio, json, os, re
from playwright.async_api import async_playwright

JS_CHECK = r"""(id) => {
  const sec = document.getElementById('tldr-' + id); if (!sec) return {missing: true};
  const fig = sec.querySelector('figure.sb-anim'), svg = fig && fig.querySelector(':scope > svg');
  const out = {errors: []};
  if (!svg) { out.errors.push('no svg'); return out; }
  const parts = new Set(Array.from(svg.querySelectorAll('[data-a]')).map(e => e.getAttribute('data-a')));
  const beats = Array.from(fig.querySelectorAll('.sb-anim-beats > li'));
  out.beats = beats.length;
  beats.forEach((li, i) => {
    const ids = [];
    ['data-on', 'data-off'].forEach(k => (li.getAttribute(k) || '').split(/\s+/).filter(Boolean).forEach(x => ids.push(x)));
    (li.getAttribute('data-cls') || '').split(/\s+/).filter(Boolean).forEach(x => ids.push(x.split(':')[0]));
    (li.getAttribute('data-move') || '').split(/\s+/).filter(Boolean).forEach(x => x.split(':').forEach(y => ids.push(y)));
    (li.getAttribute('data-set') || '').split(/\s+/).filter(Boolean).forEach(x => ids.push(x.split('.')[0]));
    (li.getAttribute('data-text') || '').split(/\s+(?=[\w-]+=)/).filter(Boolean).forEach(x => ids.push(x.split('=')[0]));
    ids.forEach(x => { if (!parts.has(x)) out.errors.push('beat ' + (i + 1) + ': unknown part ' + x); });
  });
  /* parts never shown: not base and never turned on by any beat */
  const shown = new Set();
  beats.forEach(li => { ['data-on', 'data-cls', 'data-move'].forEach(k => (li.getAttribute(k) || '').split(/\s+/).filter(Boolean).forEach(x => shown.add(x.split(':')[0]))); (li.getAttribute('data-move') || '').split(/\s+/).filter(Boolean).forEach(x => shown.add(x.split(':')[0])); });
  svg.querySelectorAll('[data-a]').forEach(e => { const a = e.getAttribute('data-a'); if (!e.classList.contains('a-base') && !shown.has(a) && !(e.parentElement && e.parentElement.closest('[data-a]'))) out.errors.push('never shown: ' + a); });
  /* text in the viewBox: finished picture */
  fig._sbAnim && fig._sbAnim.go(beats.length - 1);
  const vb = svg.viewBox.baseVal;
  svg.querySelectorAll('text').forEach(t => { try { const b = t.getBBox(); if (b.width && (b.x < -1 || b.y < -1 || b.x + b.width > vb.width + 1 || b.y + b.height > vb.height + 1)) out.errors.push('text outside viewBox: "' + t.textContent.slice(0, 30) + '"'); } catch (e) {} });
  const txt = sec.innerText;
  const code = txt.match(/\b(P(0[1-9]|1[0-4])|X[1-4])\b/); if (code) out.errors.push('survey code shown: ' + code[0]);
  const bad = txt.match(/(^|[^A-Za-z-])(NaN|undefined|\[object Object\])([^A-Za-z-]|$)/); if (bad) out.errors.push('bad text: ' + bad[2]);
  return out;
}"""

async def main(a):
    url = "file://" + os.path.abspath(a.file)
    rep = {"sections": {}, "warnings": [], "errors": []}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={"width": a.width, "height": 1000}, color_scheme="dark" if a.dark else "light")
        pg = await ctx.new_page()
        pg.on("pageerror", lambda e: rep["errors"].append(str(e)[:200]))
        pg.on("console", lambda m: rep["errors"].append(m.text[:200]) if m.type == "error" and "ERR_FAILED" not in m.text else None)
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(url + "#tldr"); await pg.wait_for_timeout(6000)
        ids = await pg.evaluate("RB.TLDR.map(s => s.id)")
        if a.ids: ids = [i for i in ids if i in a.ids.split(",")]
        rep["warnings"] = await pg.evaluate("RB.warnings.filter(w => /tldr/.test(w))")
        # pause everything so shots are deterministic
        await pg.evaluate("document.querySelector('#view-tldr [data-anim-toggle]').click()")
        paused = await pg.evaluate("Array.from(document.querySelectorAll('#view-tldr figure.sb-anim')).every(f => f.classList.contains('is-paused') || !f._sbAnim)")
        if not paused: rep["errors"].append("Pause did not pause every figure")
        for i in ids:
            r = await pg.evaluate(JS_CHECK, i)
            rep["sections"][i] = r
            if a.shots:
                os.makedirs(a.shots, exist_ok=True)
                fig = pg.locator(f"#tldr-{i} figure.sb-anim > svg")
                await pg.locator(f"#tldr-{i}").scroll_into_view_if_needed()
                n = r.get("beats", 0); files = []
                for k in range(n):
                    await pg.evaluate(f"document.querySelector('#tldr-{i} figure.sb-anim')._sbAnim.go({k})")
                    await pg.wait_for_timeout(1300)
                    f = os.path.join(a.shots, f"{i}-{k+1}.png"); await fig.screenshot(path=f); files.append(f)
                await pg.locator(f"#tldr-{i}").screenshot(path=os.path.join(a.shots, f"{i}-section.png"))
                try:
                    from PIL import Image
                    ims = [Image.open(f) for f in files]
                    if ims:
                        w, h = ims[0].size; cols = 3; rows = (len(ims) + cols - 1) // cols
                        sheet = Image.new("RGB", (w * cols, h * rows), "white")
                        for j, im in enumerate(ims): sheet.paste(im, ((j % cols) * w, (j // cols) * h))
                        sheet.save(os.path.join(a.shots, f"{i}-sheet.png"))
                        for f in files: os.remove(f)
                except Exception as e:
                    rep["errors"].append("sheet: " + str(e))
        # reduced motion: finished picture
        await pg.emulate_media(reduced_motion="reduce"); await pg.wait_for_timeout(600)
        still = await pg.evaluate("Array.from(document.querySelectorAll('#view-tldr figure.sb-anim')).filter(f => f._sbAnim && !f.classList.contains('is-still')).length")
        if still: rep["errors"].append(f"{still} figures not still under reduced motion")
        await b.close()
    bad = {k: v for k, v in rep["sections"].items() if v.get("errors") or v.get("missing")}
    print(json.dumps({"n": len(rep["sections"]), "bad": bad, "warnings": rep["warnings"], "errors": list(dict.fromkeys(rep["errors"]))[:20]}, indent=1, ensure_ascii=False))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--ids"); ap.add_argument("--shots"); ap.add_argument("--dark", action="store_true"); ap.add_argument("--width", type=int, default=1280)
    asyncio.run(main(ap.parse_args()))
