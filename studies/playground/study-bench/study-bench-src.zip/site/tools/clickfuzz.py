#!/usr/bin/env python3
"""Click every visible control on each page, topic and station; after each click record page errors, console errors,
and suspicious visible text (NaN, undefined, [object Object], null). usage: python3 tools/clickfuzz.py FILE [--part 0 --parts 1] [--max 120]"""
import argparse, asyncio, json, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from spacecheck import PAGES
from playwright.async_api import async_playwright

PICK = r"""(args) => {
  const [scopeSel, max] = args;
  const scope = document.querySelector(scopeSel) || document.body;
  const sel = 'button, summary, a[href^="#"], [role=tab], [data-arch-open], [data-tower], [data-mid], [data-station], [data-node], [data-term], input[type=checkbox], input[type=radio], select, input[type=range], .rb-atlas circle, [tabindex="0"]';
  const els = Array.from(scope.querySelectorAll(sel)).filter(e => { const r = e.getBoundingClientRect(); return r.width > 2 && r.height > 2 && !e.closest('.sb-appbar') && !e.disabled; });
  const seen = new Set(), out = [];
  els.forEach((e, i) => { const key = e.tagName + '|' + (e.getAttribute('class')||'') + '|' + (e.textContent||'').trim().slice(0, 30) + '|' + (e.getAttribute('data-mid')||e.getAttribute('data-tower')||e.getAttribute('data-station')||''); if (seen.has(key)) return; seen.add(key); e.setAttribute('data-fz', String(i)); out.push({ i, key, tag: e.tagName, type: e.type || '', text: (e.textContent||e.getAttribute('aria-label')||'').trim().slice(0, 40) }); });
  return out.filter(o => !/Watch demo|Guide me|Next step|Play|Run all|Tour/i.test(o.text)).slice(0, max);
}"""
BAD = r"""(scopeSel) => { const s = document.querySelector(scopeSel) || document.body; const t = s.innerText || '';
  const m = t.match(/(^|[^A-Za-z-])(NaN|undefined|\[object Object\]|Infinity)([^A-Za-z-]|$)/); return m ? t.slice(Math.max(0, m.index - 40), m.index + 40).replace(/\s+/g, ' ') : null; }"""

async def main(a):
    url = "file://" + os.path.abspath(a.file)
    rep = {}
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": a.width, "height": 900})
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        errs = []
        pg.on("pageerror", lambda e: errs.append("pageerror: " + str(e)[:200]))
        pg.on("console", lambda m: errs.append("console: " + m.text[:200]) if m.type == "error" else None)
        pg.on("dialog", lambda d: asyncio.ensure_future(d.dismiss()))
        await pg.goto(url + "#overview"); await pg.wait_for_timeout(6000)
        topics = await pg.evaluate("RB.topicOrder"); stations = await pg.evaluate("RB.stationOrder")
        targets = [(h, "#view-" + h.split("/")[0]) for h in PAGES] + [("explorer/" + t, "#" + t) for t in topics] + [("lab/" + s, "#benchHost") for s in stations]
        targets = targets[a.part::a.parts]
        if a.skip.startswith("+"): targets = [t for t in targets if t[0] in a.skip[1:].split(",")]
        elif a.skip: targets = [t for t in targets if t[0] not in a.skip.split(",")]
        for h, sel in targets:
            probs = []
            await pg.evaluate(f"location.hash = '#{h}'"); await pg.wait_for_timeout(1500)
            items = await pg.evaluate(PICK, [sel, a.max])
            for it in items:
                errs.clear()
                cur = await pg.evaluate("location.hash")
                if cur != "#" + h:
                    await pg.evaluate(f"location.hash = '#{h}'"); await pg.wait_for_timeout(800)
                loc = pg.locator(f'[data-fz="{it["i"]}"]')
                try:
                    if await loc.count() == 0: continue
                    if it["tag"] == "SELECT":
                        opts = await loc.evaluate("e => Array.from(e.options).map(o => o.value)")
                        if len(opts) > 1: await loc.select_option(opts[-1])
                    elif it["type"] == "range":
                        await loc.evaluate("e => { e.value = e.max; e.dispatchEvent(new Event('input', {bubbles:true})); e.dispatchEvent(new Event('change', {bubbles:true})); }")
                        await pg.wait_for_timeout(80)
                        await loc.evaluate("e => { e.value = e.min; e.dispatchEvent(new Event('input', {bubbles:true})); e.dispatchEvent(new Event('change', {bubbles:true})); }")
                    else:
                        await loc.scroll_into_view_if_needed(timeout=1500)
                        await loc.click(timeout=600, force=False)
                except Exception as e:
                    s = str(e).split("\n")[0][:100]
                    if "intercepts pointer" in str(e): probs.append(f"blocked click: {it['text']!r}")
                    continue
                await pg.wait_for_timeout(a.wait)
                bad = await pg.evaluate(BAD, "body")
                if errs: probs.append(f"{it['text']!r} → " + " | ".join(dict.fromkeys(errs)))
                if bad: probs.append(f"{it['text']!r} → text: {bad}")
                await pg.keyboard.press("Escape")
            if probs: rep[h] = list(dict.fromkeys(probs))[:25]
            print(h, len(items), len(probs), json.dumps(probs[:25], ensure_ascii=False), file=sys.stderr, flush=True)
        await b.close()
    print(json.dumps(rep, indent=1, ensure_ascii=False))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--part", type=int, default=0); ap.add_argument("--parts", type=int, default=1)
    ap.add_argument("--max", type=int, default=120); ap.add_argument("--wait", type=int, default=150); ap.add_argument("--width", type=int, default=1280); ap.add_argument("--skip", default="")
    asyncio.run(main(ap.parse_args()))
