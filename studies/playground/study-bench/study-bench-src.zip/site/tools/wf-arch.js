export const meta = {
  name: 'rb-arch-specs',
  description: 'Write consistent architecture specs (blueprint, system view, modules) for ~130 robot-learning models, each checked in a headless browser',
  phases: [{ title: 'Specs', detail: 'one agent per model group, paper + official code, self-checked' }],
}
const SITE = '/home/claude/rb/site'
const GROUPS = [
  { f: 'b4-vla-a', topics: ['b4'], ids: 'gato, vima, rt-1, rt-2 (also covers open-x-embodiment-rt-x via RT-1-X/RT-2-X notes), octo, openvla, rdt-1b', parents: 'rt-2 → openvla; rt-1 → octo; ' },
  { f: 'b4-vla-b', topics: ['b4'], ids: 'pi0-5, knowledge-insulation, gr00t-n1, smolvla, pi0-7, cogact, rt-h, hi-robot', parents: 'π0 spec id is "pi0" (data/arch/b4-vla.js): use it as parent for pi0-5, knowledge-insulation, smolvla; openvla (another agent) for cogact' },
  { f: 'c2-wam-a', topics: ['c2'], ids: 'unipi, avdc, susie, gr-1, gr-2, pad, vpp, seer, uva, flare', parents: 'uwm (data/arch/c2-wam.js) exists; pad is a natural parent of uwm-like models; diffusion-policy exists in b2-heads.js' },
  { f: 'c2-wam-b', topics: ['c2'], ids: 'cot-vla, worldvla, f1, motus, cosmos-policy, lingbot-va, dreamzero, fast-wam, mimic-video, videovla', parents: 'uwm exists; other agents write gr-1, pad, uva, vpp in c2-wam-a' },
  { f: 'b2-heads-more', topics: ['b2'], ids: 'act, dp3, 3d-diffuser-actor, consistency-policy, vq-bet, adaflow', parents: 'diffusion-policy exists in b2-heads.js (use as parent for dp3, consistency-policy, 3d-diffuser-actor)' },
  { f: 'b1b3-actions', topics: ['b1', 'b3'], ids: 'bc-z (b1); fast, openvla-oft, crossformer, uniact, spatialvla (b3); skip dagger, real-time-chunking, umi with reasons', parents: 'openvla is written by another agent (id "openvla"): parent of openvla-oft; pi0 exists (FAST pairs with π0-FAST)' },
  { f: 'c1-world', topics: ['c1'], ids: 'world-models, planet, dreamer, dreamerv3, td-mpc2, v-jepa-2, dino-wm, unisim, cosmos-world-foundation-models, genie-envisioner, irasim', parents: 'chain world-models → planet → dreamer → dreamerv3' },
  { f: 'e1-grasp', topics: ['e1'], ids: 'dex-net, gg-cnn, gr-convnet, 6-dof-graspnet, contact-graspnet, graspnet-1billion (its baseline network), anygrasp, grasp-anything (LGD baseline if the dataset paper has one), grasp-anything-lgd, grasp-anything-6d, graspgpt, thinkgrasp, rt-grasp, vcot-grasp, graspvla, dexgraspnet (its generator), dex1b (its generator)', parents: 'gg-cnn → gr-convnet; 6-dof-graspnet → contact-graspnet' },
  { f: 'd2-human', topics: ['d2'], ids: 'time-contrastive-networks, r3m, vip, mvp, vc-1, lapa, mimicplay, atm, egomimic, phantom (skip if no network of its own), being-h0, villa-x', parents: 'r3m → vip; mvp → vc-1; lapa → villa-x' },
  { f: 'e5-touch', topics: ['e5'], ids: 'reactive-diffusion-policy, forcevla, foar, adaptive-compliance-policy, 3d-vitac, unit, fuse, tactile-vla, tacdiffusion, m3l, vital, ta-vla', parents: 'diffusion-policy exists; pi0 exists (ForceVLA builds on π0)' },
  { f: 'c3-sim', topics: ['c3'], ids: 'dreamgen, world-env, vla-rft, wmpo, ctrl-world, gpc, worldeval, worldgym (draw the world model + policy + reward/judge loop as towers; skip pure evaluation protocols with no network)', parents: '' },
  { f: 'b5-planners', topics: ['b5'], ids: 'saycan, inner-monologue, code-as-policies, palm-e, voxposer, rekep, moka, robopoint, cliport', parents: 'saycan → inner-monologue' },
  { f: 'e2e3-dexterous', topics: ['e2', 'e3'], ids: 'e2: dapg, pddm, learning-dexterous-in-hand-manipulation, dextreme, visual-dexterity, in-hand-object-rotation, hato; e3: deformernet, dexdeform, deep-whole-body-control, homer, momanipvla, chi0', parents: '' },
  { f: 'e6-physics', topics: ['e6'], ids: 'delan, hamiltonian-neural-networks, lagrangian-neural-networks, neural-ode, variational-integrator-networks, port-hamiltonian-on-se, neural-sde, pi-tcn; skip pinn and sindy unless a network is central', parents: 'hamiltonian-neural-networks → lagrangian-neural-networks' },
  { f: 'a3a4e4-control', topics: ['a3', 'a4', 'e4'], ids: 'a3: dqn, ddpg, sac, qt-opt, hil-serl, residual-rl, daydreamer (skip ppo, rlpd, serl if no distinctive network); a4: rma, teacher-student-terrain, asymmetric-actor-critic, adr-solving-rubik-s-cube (its policy/value nets), asap (skip domain-randomization, dynamics-randomization, gat); e4: h2o-omnih2o, humanplus, exbody2, wococo, real-world-humanoid-locomotion, flam', parents: 'dqn → ddpg → sac' },
  { f: 'f1f2-trust', topics: ['f1', 'f2'], ids: 'f1: knowno, robomonkey, v-gps, safe, fail-detect, fiper, sentinel, gvl, recap, world-action-verifier (skip roboarena, autoeval); f2: vlsa, safevla, safedreamer, byovla, and attack overlays for badvla, flowhijack, silentdrift, freezevla on their target models (skip robopair, badrobot, poex, libero-plus if no model)', parents: '' },
]
const SUMMARY = { type: 'object', properties: { file: { type: 'string' }, drawn: { type: 'array', items: { type: 'string' } }, skipped: { type: 'array', items: { type: 'string' } }, conflicts: { type: 'array', items: { type: 'string' } }, notes: { type: 'string' } }, required: ['file', 'drawn', 'skipped', 'conflicts', 'notes'] }

function prompt(g) {
  return `You are adding model architecture diagrams to "Study Bench · Robot Learning" in ${SITE}.
Read ${SITE}/ARCH.md completely first; it is the full contract. Then read the three reference specs it names (data/arch/b4-vla.js, b2-heads.js, c2-wam.js) and skim core/35-arch.js and core/36-blueprint.js.
YOUR FILE: ${SITE}/data/arch/${g.f}.js (create it; touch no other file).
YOUR MODELS (method ids in data/methods.json; read each card there first with python/jq, do not print the whole file): ${g.ids}.
Parent hints: ${g.parents || 'set parent to the model it builds on when that model is also drawn (in your file or another agent file); otherwise omit'}.
For each model: read the paper with alphaXiv (ToolSearch "select:mcp__alphaXiv__answer_pdf_queries,mcp__alphaXiv__read_files_from_github_repository") and the official code (git clone --depth 1 into your scratchpad, record the short commit hash). Write a complete spec: summary, modules/inputs/outputs/links (+mask for transformers), callouts, and a full blueprint with sourced callouts and 2-5 zoom-ins. Every number sourced; nothing guessed.
Check loop for topic(s) ${g.topics.join(', ')}: python3 tools/build.py --only ${g.topics.join(',')} --stations none --arch ${g.f},b2-heads,b4-vla,c2-wam --out dist/a-${g.f}.html ; then python3 tools/archcheck.py dist/a-${g.f}.html --topic <topic> --ids <your ids> --shots for each topic. Look at every screenshot (arch_<id>_bp.png, _sys.png, _phone.png) and fix what looks wrong. Only your ids must be clean (other agents may still be writing theirs).
Work until every model in your file is clean. Final answer per ARCH.md.`
}
phase('Specs')
const res = await pipeline(GROUPS, g => agent(prompt(g), { label: 'arch:' + g.f, phase: 'Specs', schema: SUMMARY }))
return res
