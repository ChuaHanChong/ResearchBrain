#!/usr/bin/env python3
"""Find blocks that touch or crowd each other on every page, tab, topic and station.
A "block" is any visible element with its own border or background (panels, cards, tables, figures, callouts, buttons rows).
For every such block it measures the vertical gap to the next block below it that overlaps it horizontally, and the horizontal gap
to side-by-side blocks. Reports gaps under --min px (default 12). usage: python3 tools/spacecheck.py dist/x.html [--width 1280] [--only pages|topics|stations]"""
import argparse, asyncio, json, os
from playwright.async_api import async_playwright

PAGES = ["overview", "tldr", "evolution/lineage", "evolution/story", "evolution/equations", "compare/sbs", "compare/table", "compare/decide", "reference/formulas", "reference/cards", "reference/differences", "reference/datasets", "reference/papers", "glossary/visual", "glossary/map", "glossary/az", "notation", "lab"]
JS = r"""
(args) => {
  const [scopeSel, minGap] = args;
  const scope = document.querySelector(scopeSel) || document.body;
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 4 && r.height > 4 && e.offsetParent !== null; };
  const boxed = e => { if (e.closest('svg') || e.closest('mjx-container')) return false; const s = getComputedStyle(e); if (s.position === 'fixed' || s.position === 'sticky' && false) return false; return (parseFloat(s.borderTopWidth) > 0 || parseFloat(s.borderBottomWidth) > 0) && s.borderTopStyle !== 'none' || (s.backgroundColor && s.backgroundColor !== 'rgba(0, 0, 0, 0)' && s.backgroundColor !== getComputedStyle(e.parentElement || e).backgroundColor); };
  const blocks = Array.from(scope.querySelectorAll('div,section,article,figure,table,details,aside,ul,ol,p,header,nav,form')).filter(e => vis(e) && boxed(e) && !e.closest('.sb-appbar,.sb-seg,.sb-chips,.sb-btn-row,.sb-toolbar,thead,tbody,tr,.sb-legend,.sb-readouts,.rb-arch-legend') && e.getBoundingClientRect().height < 4000);
  const R = blocks.map(e => ({ e, r: e.getBoundingClientRect() }));
  const out = [];
  for (let i = 0; i < R.length; i++) for (let j = 0; j < R.length; j++) {
    if (i === j) continue; const a = R[i], b = R[j];
    if (a.e.contains(b.e) || b.e.contains(a.e)) continue;
    /* rows of one table-like grid (same parent, same class, or cells inside such rows) are meant to touch */
    const rowish = x => x.e.closest('.sb-sbs, .sb-kv, table, .rb-kv, .sb-rack, .sb-eqkey, .rb-film-thumbs, .sb-dag, .rb-atlas');
    if (rowish(a) && rowish(a) === rowish(b)) continue;
    if (a.e.parentElement === b.e.parentElement && a.e.className === b.e.className && (a.e.tagName === 'LI' || /row|item|key/.test(a.e.className))) continue;
    const hOver = Math.min(a.r.right, b.r.right) - Math.max(a.r.left, b.r.left), vOver = Math.min(a.r.bottom, b.r.bottom) - Math.max(a.r.top, b.r.top);
    const name = x => (x.e.id ? '#' + x.e.id : '') + '.' + String(x.e.className).split(' ').slice(0, 2).join('.') + ' "' + (x.e.textContent || '').trim().slice(0, 30) + '"';
    if (hOver > 20) { const g = b.r.top - a.r.bottom; if (g >= -1 && g < minGap && b.r.top >= a.r.top) out.push(`${Math.round(g)}px below: ${name(a)} → ${name(b)}`); }
    else if (vOver > 20) { const g = b.r.left - a.r.right; if (g >= -1 && g < minGap && b.r.left >= a.r.left) out.push(`${Math.round(g)}px beside: ${name(a)} → ${name(b)}`); }
  }
  return Array.from(new Set(out)).slice(0, 40);
}
"""

async def main(a):
    url = "file://" + os.path.abspath(a.file)
    rep = {}
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": a.width, "height": 1000})
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(url + "#overview"); await pg.wait_for_timeout(7000)
        topics = await pg.evaluate("RB.topicOrder"); stations = await pg.evaluate("RB.stationOrder")
        targets = []
        if a.only in (None, "pages"): targets += [(h, "#view-" + h.split("/")[0]) for h in PAGES]
        if a.only in (None, "topics"): targets += [("explorer/" + t, "#" + t) for t in topics]
        if a.only in (None, "stations"): targets += [("lab/" + s, "#benchHost") for s in stations]
        for h, sel in targets:
            await pg.evaluate(f"location.hash = '#{h}'"); await pg.wait_for_timeout(2200)
            r = await pg.evaluate(JS, [sel, a.min])
            if r: rep[h] = r
        await b.close()
    print(json.dumps(rep, indent=1, ensure_ascii=False))

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--width", type=int, default=1280); ap.add_argument("--min", type=int, default=12); ap.add_argument("--only")
    asyncio.run(main(ap.parse_args()))
