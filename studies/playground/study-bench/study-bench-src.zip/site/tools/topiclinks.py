#!/usr/bin/env python3
"""v2.10 TopicLinks check: every topic has a Summary card, a TL;DR section and an Explorer head that link to each other
in the fixed order (Summary · ▶ TL;DR · Open topic →), every link resolves, #overview/<topic> centres its card, and one
✓ Understood state shows in all four places. usage: python3 tools/topiclinks.py FILE"""
import asyncio, json, os, sys
from playwright.async_api import async_playwright
async def main(f):
    errs, probs = [], []
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": 1280, "height": 900})
        pg.on("pageerror", lambda e: errs.append(str(e)[:200]))
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto("file://" + os.path.abspath(f) + "#overview"); await pg.wait_for_timeout(6000)
        ids = await pg.evaluate("RB.topicOrder")
        order = {"Summary": 0, "▶ TL;DR": 1}
        def chk(where, labels):
            ks = [0 if l == "Summary" else 1 if l.startswith("▶") else 2 if l.startswith("Open topic") else 3 for l in labels]
            if ks != sorted(ks): probs.append(f"{where}: order {labels}")
        cards = await pg.evaluate("""() => RB.topicOrder.map(id => { const c = document.querySelector('#sumHost .rb-sumcard[data-topic="' + id + '"]'); if (!c) return [id, null]; return [id, Array.from(c.querySelectorAll('.sb-topiclinks a')).map(a => [a.textContent, a.getAttribute('href')])]; })""")
        for id_, links in cards:
            if links is None: probs.append(f"overview: no card for {id_}"); continue
            hs = [h for _, h in links]
            if f"#explorer/{id_}" not in hs: probs.append(f"overview {id_}: no Open topic")
            if not any(h.startswith("#tldr/") for h in hs): probs.append(f"overview {id_}: no TL;DR link")
            if any(h.startswith("#overview") for h in hs): probs.append(f"overview {id_}: links to itself")
            chk("overview " + id_, [t for t, _ in links])
        await pg.evaluate("location.hash='#tldr'"); await pg.wait_for_timeout(2500)
        secs = await pg.evaluate("""() => RB.TLDR.map(s => { const el = document.getElementById('tldr-' + s.id); return [s.id, s.topics, el ? Array.from(el.querySelectorAll('.sb-topiclinks a')).map(a => [a.textContent, a.getAttribute('href')]) : null, el ? el.textContent.includes('Go deeper') : false]; })""")
        tl_ids = set()
        for sid, tps, links, gd in secs:
            tl_ids.add(sid)
            if links is None: probs.append(f"tldr: no section {sid}"); continue
            if gd: probs.append(f"tldr {sid}: still says Go deeper")
            hs = [h for _, h in links]
            if not tps:
                if hs != ["#evolution"]: probs.append(f"tldr {sid} (recap): {hs}")
                continue
            if f"#overview/{tps[0]}" not in hs: probs.append(f"tldr {sid}: no Summary")
            for t in tps:
                if f"#explorer/{t}" not in hs: probs.append(f"tldr {sid}: no Open topic for {t}")
            chk("tldr " + sid, [t for t, _ in links])
        await pg.evaluate("location.hash='#explorer/a1'"); await pg.wait_for_timeout(1500)
        for id_ in ids:
            await pg.evaluate(f"location.hash='#explorer/{id_}'"); await pg.wait_for_timeout(500)
            links = await pg.evaluate(f"""() => {{ const h = document.querySelector('#{id_} .sb-topic-head') || document.querySelector('article[id="{id_}"] .sb-topic-head') || Array.from(document.querySelectorAll('.sb-topic-head')).find(x => x.offsetParent); return h ? Array.from(h.querySelectorAll('.sb-topiclinks a')).map(a => [a.textContent, a.getAttribute('href')]) : null; }}""")
            if not links: probs.append(f"explorer {id_}: no TopicLinks"); continue
            hs = [h for _, h in links]
            if f"#overview/{id_}" not in hs: probs.append(f"explorer {id_}: no Summary")
            if not any(h.startswith("#tldr/") and h[6:] in tl_ids for h in hs): probs.append(f"explorer {id_}: no TL;DR")
            chk("explorer " + id_, [t for t, _ in links])
        # deep link centres the card
        await pg.evaluate("location.hash='#overview/b6'"); await pg.wait_for_timeout(2000)
        mid = await pg.evaluate("(() => { const c = document.querySelector('#sumHost .rb-sumcard[data-topic=\"b6\"]').getBoundingClientRect(); return Math.round(c.top + c.height / 2 - innerHeight / 2); })()")
        if abs(mid) > 60: probs.append(f"#overview/b6 card off centre by {mid}px")
        # one done state
        await pg.evaluate("RB.progress.set('b2', true)"); await pg.wait_for_timeout(300)
        await pg.evaluate("location.hash='#tldr/heads'"); await pg.wait_for_timeout(1500)
        vis = await pg.evaluate("""() => Array.from(document.querySelectorAll('.sb-done[data-done="b2"]')).map(d => !d.hidden)""")
        if len(vis) < 4 or not all(vis): probs.append(f"done state b2: {vis}")
        await pg.evaluate("RB.progress.set('b2', false)"); await pg.wait_for_timeout(300)
        vis = await pg.evaluate("""() => Array.from(document.querySelectorAll('.sb-done[data-done="b2"]')).filter(d => !d.hidden).length""")
        if vis: probs.append("done state b2 not cleared")
        await b.close()
    print(json.dumps({"problems": probs, "errors": errs}, indent=1, ensure_ascii=False))
asyncio.run(main(sys.argv[1]))
