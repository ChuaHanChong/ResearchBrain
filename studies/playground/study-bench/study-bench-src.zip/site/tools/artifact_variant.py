#!/usr/bin/env python3
"""Make the Artifact-publish variant: drop the document skeleton (the Artifact tool adds its own) and keep body class + lang."""
import re, sys
src, out = sys.argv[1], sys.argv[2]
s = open(src, encoding="utf-8").read()
s = re.sub(r"^<!doctype html>\s*<html[^>]*>\s*<head>\s*", "", s, flags=re.I)
s = re.sub(r'<meta charset="utf-8">\s*<meta name="viewport"[^>]*>\s*', "", s, count=1)
s = s.replace('</head>\n<body class="sb-root">', '<script>document.documentElement.lang="en";document.body.classList.add("sb-root");</script>', 1)
s = re.sub(r"</body>\s*</html>\s*$", "", s)
assert "<body" not in s[:200000] and "</head>" not in s
open(out, "w", encoding="utf-8").write(s)
print("wrote", out, len(s))
