#!/usr/bin/env python3
"""Check that every section heading (eyebrow/title) has room above it: gap to the nearest element above that overlaps horizontally.
usage: python3 tools/headgap.py FILE [--min 20] [--width 1280]"""
import argparse, asyncio, json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from spacecheck import PAGES
from playwright.async_api import async_playwright
JS = r"""(minGap) => {
  const out = [];
  const heads = Array.from(document.querySelectorAll('.sb-sec-head, .sb-eyebrow, h2, h3')).filter(e => e.offsetParent && e.getBoundingClientRect().height > 4 && !e.closest('svg,.sb-appbar,.rb-overlay'));
  const all = Array.from(document.querySelectorAll('body *')).filter(e => e.offsetParent && !e.closest('svg') && e.children.length === 0 || (e.offsetParent && getComputedStyle(e).borderBottomStyle !== 'none' && parseFloat(getComputedStyle(e).borderBottomWidth) > 0));
  for (const h of heads) {
    if (h.parentElement && h.parentElement.closest('.sb-sec-head') && h.classList.contains('sb-eyebrow')) continue;
    const r = h.getBoundingClientRect(); let best = null;
    for (const e of all) {
      if (h.contains(e) || e.contains(h)) continue;
      const q = e.getBoundingClientRect(); if (q.width < 4 || q.height < 2) continue;
      if (Math.min(q.right, r.right) - Math.max(q.left, r.left) < 20) continue;
      const g = r.top - q.bottom; if (g < -1 || q.top >= r.top) continue;
      if (best === null || g < best.g) best = { g, e };
    }
    if (best && best.g < minGap) out.push(Math.round(best.g) + 'px: "' + (best.e.textContent||'').trim().slice(0,30) + '" → "' + h.textContent.trim().slice(0,30) + '"');
  }
  return Array.from(new Set(out)).slice(0, 30);
}"""
async def main(a):
    url = "file://" + os.path.abspath(a.file); rep = {}
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": a.width, "height": 1000})
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(url + "#overview"); await pg.wait_for_timeout(6000)
        topics = await pg.evaluate("RB.topicOrder")
        for h in PAGES + ["explorer/" + t for t in topics]:
            await pg.evaluate(f"location.hash = '#{h}'"); await pg.wait_for_timeout(1500)
            r = await pg.evaluate(JS, a.min)
            if r: rep[h] = r
        await b.close()
    print(json.dumps(rep, indent=1, ensure_ascii=False))
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--min", type=int, default=20); ap.add_argument("--width", type=int, default=1280)
    asyncio.run(main(ap.parse_args()))
