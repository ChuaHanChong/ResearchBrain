#!/usr/bin/env python3
"""Check architecture specs in a built page.

usage:
  python3 tools/build.py --only b4 --stations none --out dist/a-b4.html
  python3 tools/archcheck.py dist/a-b4.html --topic b4 [--ids pi0,openvla] [--shots]

For every spec of the topic (or only --ids) it opens the topic's architecture section, selects the model, renders the
Blueprint, System and Modules views, and reports: page/console errors, arch warnings (unsourced numbers, unknown ids),
error boxes, overlapping text inside each SVG, text wider than its pill, and page overflow at 1280 and 400 px.
--shots saves dist/shots/arch_<id>_bp.png (blueprint at 1600 px), _sys.png (system at 1280), _phone.png (system at 400).
Exit 1 if anything is wrong."""
import argparse, asyncio, json, os, sys
from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

OVERLAP_JS = r"""
(sel) => {
  const out = [];
  document.querySelectorAll(sel).forEach(svg => {
    const texts = Array.from(svg.querySelectorAll('text')).filter(t => t.textContent.trim() && t.getClientRects().length);
    const boxes = texts.map(t => { const r = t.getBoundingClientRect(); return {t: t.textContent.trim().slice(0, 40), l: r.left + 1, r: r.right - 1, tp: r.top + 1, b: r.bottom - 1}; });
    for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
      const a = boxes[i], b = boxes[j];
      if (a.l < b.r && b.l < a.r && a.tp < b.b && b.tp < a.b) out.push(`"${a.t}" × "${b.t}"`);
    }
    /* text wider than the pill it sits on */
    svg.querySelectorAll('g.rb-bp-row, g.rb-am').forEach(g => {
      const rect = g.querySelector('rect'); if (!rect) return; const rr = rect.getBoundingClientRect();
      g.querySelectorAll('text:not(.rb-bp-bt)').forEach(t => { const tr = t.getBoundingClientRect(); if (tr.width && (tr.left < rr.left - 1 || tr.right > rr.right + 1)) out.push(`overflows box: "${t.textContent.trim().slice(0, 40)}"`); });
    });
  });
  return out.slice(0, 30);
}
"""


async def main(a):
    url = "file://" + os.path.abspath(a.file)
    rep = {"pageErrors": [], "consoleErrors": [], "specs": {}}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": 1600, "height": 1000})
        pg.on("console", lambda m: rep["consoleErrors"].append(m.text[:300]) if m.type == "error" and "fonts.g" not in m.text and "ERR_" not in m.text else None)
        pg.on("pageerror", lambda e: rep["pageErrors"].append(str(e)[:300]))
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(url + "#explorer/" + a.topic + "/arch")
        await pg.wait_for_timeout(7000)
        ids = await pg.evaluate("(t) => RB.arch.forTopic(t).map(s => s.id)", a.topic)
        rep["allSpecs"] = ids
        rep["archWarnings"] = await pg.evaluate("RB.warnings.filter(w => /arch/.test(w))")
        if a.ids:
            ids = [i for i in ids if i in a.ids.split(",")]
        os.makedirs(os.path.join(ROOT, "dist/shots"), exist_ok=True)
        host = f"#{a.topic}-arch"
        for sid in ids:
            r = {}
            await pg.set_viewport_size({"width": 1600, "height": 1000})
            await pg.evaluate(f"(id) => {{ const h = document.querySelector('{host} [data-arch-topic]'); h.__arch.select(id); }}", sid)
            await pg.wait_for_timeout(500)
            for view in ["blueprint", "system", "layers"]:
                ok = await pg.evaluate(f"(v) => {{ const h = document.querySelector('{host} [data-arch-topic]'); const b = h.querySelector('.rb-arch-bar [value=' + v + ']'); if (!b) return 'no ' + v + ' view'; b.click(); return 'ok'; }}", view)
                await pg.wait_for_timeout(500)
                errs = await pg.evaluate(f"() => Array.from(document.querySelectorAll('{host} .sb-error')).map(e => e.textContent.slice(0, 200))")
                ov = await pg.evaluate(OVERLAP_JS, f"{host} .rb-bp-svg, {host} .rb-arch-svg, {host} .rb-ls-svg")
                r[view] = {"status": ok, "errors": errs, "overlaps": ov}
                if a.shots and view == "blueprint" and ok == "ok":
                    el = pg.locator(f"{host} [data-arch-bp]").first
                    await el.scroll_into_view_if_needed(); await el.screenshot(path=os.path.join(ROOT, f"dist/shots/arch_{sid}_bp.png"))
                if a.shots and view == "system":
                    await pg.set_viewport_size({"width": 1280, "height": 900}); await pg.wait_for_timeout(400)
                    el = pg.locator(f"{host} .rb-arch").first
                    await el.scroll_into_view_if_needed(); await el.screenshot(path=os.path.join(ROOT, f"dist/shots/arch_{sid}_sys.png"))
                    r["hscroll1280"] = await pg.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth + 1")
                    await pg.set_viewport_size({"width": 400, "height": 860}); await pg.wait_for_timeout(700)
                    el = pg.locator(f"{host} [data-arch-sys]").first
                    await el.scroll_into_view_if_needed(); await el.screenshot(path=os.path.join(ROOT, f"dist/shots/arch_{sid}_phone.png"))
                    r["hscroll400"] = await pg.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth + 1")
                    r["phoneOverlaps"] = await pg.evaluate(OVERLAP_JS, f"{host} .rb-arch-svg")
                    await pg.set_viewport_size({"width": 1600, "height": 1000}); await pg.wait_for_timeout(400)
            rep["specs"][sid] = r
        await b.close()
    print(json.dumps(rep, indent=1, ensure_ascii=False))
    bad = rep["pageErrors"] or rep["consoleErrors"] or rep["archWarnings"] or any(
        v.get(k, {}).get("errors") or v.get(k, {}).get("overlaps") or v.get("hscroll400") or v.get("hscroll1280") or v.get("phoneOverlaps")
        for v in rep["specs"].values() for k in ["blueprint", "system", "layers"])
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("file"); ap.add_argument("--topic", required=True); ap.add_argument("--ids"); ap.add_argument("--shots", action="store_true")
    asyncio.run(main(ap.parse_args()))
