#!/usr/bin/env python3
"""Headless check of a built page.

usage:
  python3 tools/check.py dist/x.html --topic b2          # one topic: errors, warnings, word audit, demos, overflow, screenshots
  python3 tools/check.py dist/x.html --station heads     # one lab station
  python3 tools/check.py dist/x.html --page evolution     # any page (overview, evolution, compare, reference, glossary, notation)
  add --shots to save screenshots (desktop light, desktop dark, phone 400px) into dist/shots/
  add --run-demos to play every Watch demo of the target to the end (slow)
Prints a JSON report. Exit code 1 if there are page errors, console errors or math errors.
"""
import argparse, asyncio, json, os, sys
from playwright.async_api import async_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

JS_REPORT = r"""
async (target) => {
  const out = {warnings: (window.RB && RB.warnings) ? RB.warnings.slice() : ['RB missing']};
  let scope = document;
  if (target.kind === 'topic') scope = document.getElementById(target.id);
  else if (target.kind === 'station') scope = document.getElementById('benchHost');
  else scope = document.getElementById('view-' + target.id);
  if (!scope) { out.error = 'scope not found'; return out; }
  out.audit = (window.StudyBench && StudyBench.audit) ? StudyBench.audit(scope).map(a => `${a.selector} ${a.words}/${a.limit}: ${a.text}`) : [];
  out.mathErrors = Array.from(scope.querySelectorAll('mjx-merror, [data-mjx-error]')).map(e => (e.getAttribute('data-mjx-error') || e.textContent).slice(0, 120));
  out.untypeset = Array.from(scope.querySelectorAll('.rb-math')).filter(e => /\\\(|\\\[/.test(e.textContent)).length;
  out.nan = Array.from(scope.querySelectorAll('*')).filter(e => e.children.length === 0 && /\b(NaN|undefined)\b/.test(e.textContent)).map(e => e.textContent.slice(0, 80)).slice(0, 10);
  out.errorsShown = Array.from(scope.querySelectorAll('.sb-error')).map(e => e.textContent.slice(0, 160));
  out.hscroll = document.documentElement.scrollWidth > document.documentElement.clientWidth + 1;
  out.emptyCanvases = Array.from(scope.querySelectorAll('canvas')).filter(c => { try { const x = c.getContext('2d'); const d = x.getImageData(0, 0, Math.min(c.width, 60), Math.min(c.height, 60)).data; let s = 0; for (let i = 3; i < d.length; i += 4) s += d[i]; return c.width === 0 || c.height === 0; } catch (e) { return false; } }).length;
  const demoIds = Array.from(scope.querySelectorAll('[data-demo-watch]')).map(b => b.getAttribute('data-demo-watch'));
  if (target.kind === 'station') demoIds.push('lab-' + target.id);
  out.demos = {};
  for (const id of demoIds) {
    const f = RB.demos[id];
    if (!f) { out.demos[id] = 'NOT REGISTERED'; continue; }
    let steps; try { steps = f(); } catch (e) { out.demos[id] = 'BUILD ERROR: ' + e.message; continue; }
    if (!steps || !steps.length) { out.demos[id] = 'EMPTY'; continue; }
    const bad = steps.map((s, i) => { const t = typeof s.target === 'function' ? s.target() : typeof s.target === 'string' ? document.querySelector(s.target) : s.target; return t ? null : i + 1; }).filter(Boolean);
    const words = steps.map((s, i) => [i + 1, (s.text || '').split(/\s+/).length, (s.title || '').split(/\s+/).length, (s.task || '').split(/\s+/).length]).filter(w => w[1] > 30 || w[2] > 6 || w[3] > 12);
    out.demos[id] = {steps: steps.length, missingTargets: bad, overLimit: words};
  }
  out.terms = window.RB ? Object.keys(RB.terms).length : 0;
  return out;
}
"""


async def main(a):
    page_url = "file://" + os.path.abspath(a.file)
    if a.topic:
        target = {"kind": "topic", "id": a.topic}; hsh = "#explorer/" + a.topic
    elif a.station:
        target = {"kind": "station", "id": a.station}; hsh = "#lab/" + a.station
    else:
        target = {"kind": "page", "id": a.page}; hsh = "#" + a.page
    report = {"target": target, "consoleErrors": [], "pageErrors": []}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={"width": 1280, "height": 900})
        pg = await ctx.new_page()
        pg.on("console", lambda m: report["consoleErrors"].append(m.text[:300]) if m.type == "error" and "fonts.g" not in m.text and "ERR_" not in m.text else None)
        pg.on("pageerror", lambda e: report["pageErrors"].append(str(e)[:400]))
        await pg.route("**/*", lambda r: r.abort() if ("googleapis" in r.request.url or "gstatic" in r.request.url) else r.continue_())
        await pg.goto(page_url + hsh)
        await pg.wait_for_timeout(a.wait)
        if target["kind"] == "page" and a.tab:
            await pg.evaluate(f"location.hash = '#{a.page}/{a.tab}'"); await pg.wait_for_timeout(1500)
        report.update(await pg.evaluate(JS_REPORT, target))
        if a.run_demos:
            ids = [k for k, v in report.get("demos", {}).items() if isinstance(v, dict)]
            report["demoRuns"] = {}
            for did in ids:
                ok = await pg.evaluate("""async (id) => { const d = RB.runDemo(id, 'watch'); if (!d) return 'no demo'; const t0 = Date.now(); while (Date.now() - t0 < 90000) { await new Promise(r => setTimeout(r, 500)); const bars = document.querySelectorAll('.sb-demo'); const bar = bars[bars.length - 1]; if (bar && bar.hidden) return 'exited'; const play = bar && bar.querySelector('[data-d=play]'); if (play && /Replay/.test(play.textContent)) { d.stop(); return 'finished'; } } d.stop(); return 'timeout'; }""", did)
                report["demoRuns"][did] = ok
            report["pageErrorsAfterDemos"] = report["pageErrors"][:]
        if a.shots:
            os.makedirs(os.path.join(ROOT, "dist/shots"), exist_ok=True)
            base = os.path.join(ROOT, "dist/shots", (target["id"] or "x"))
            await pg.screenshot(path=base + "_light.png", full_page=a.full)
            await pg.evaluate("document.documentElement.setAttribute('data-theme','dark')"); await pg.wait_for_timeout(600)
            await pg.screenshot(path=base + "_dark.png", full_page=a.full)
            await pg.evaluate("document.documentElement.setAttribute('data-theme','light')")
            await pg.set_viewport_size({"width": 400, "height": 860}); await pg.wait_for_timeout(800)
            report["hscroll400"] = await pg.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth + 1")
            await pg.screenshot(path=base + "_phone.png", full_page=False)
            report["shots"] = [base + s for s in ("_light.png", "_dark.png", "_phone.png")]
        await b.close()
    print(json.dumps(report, indent=1, ensure_ascii=False))
    bad = report["pageErrors"] or report["consoleErrors"] or report.get("mathErrors")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--topic"); ap.add_argument("--station"); ap.add_argument("--page"); ap.add_argument("--tab")
    ap.add_argument("--shots", action="store_true"); ap.add_argument("--full", action="store_true")
    ap.add_argument("--run-demos", action="store_true")
    ap.add_argument("--wait", type=int, default=6000)
    asyncio.run(main(ap.parse_args()))
