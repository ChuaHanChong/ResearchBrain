export const meta = {
  name: 'rb-build-content-resume',
  description: 'Resume after restart: finish 13 topics, 12 lab stations, the story and 4 data files of Study Bench · Robot Learning, each self-checked',
  phases: [
    { title: 'Topics', detail: '22 topic files, each built and checked alone' },
    { title: 'Stations', detail: '12 Interactive Lab stations' },
    { title: 'Data', detail: 'lineage, story, results, datasets, conflicts, decision guides, glossary scenes' },
  ],
}

const SITE = '/home/claude/rb/site'
const COMMON = `
You are building part of "Study Bench · Robot Learning", a single-file interactive study site in ${SITE}.
First read ${SITE}/AUTHORING.md completely, then ${SITE}/topics/b2.js (the exemplar that sets the quality bar), then skim ${SITE}/core/00-util.js and ${SITE}/src/rb.css for helpers and classes.
Follow AUTHORING.md exactly: file contract, house notation, token colors only, word limits, provenance labels, the build-and-check loop, and looking at the screenshots yourself.
Facts: method papers are in ${SITE}/data/methods.json (load with python/jq, do not print the whole file). Surveys are read with the alphaXiv MCP tools (ToolSearch "select:mcp__alphaXiv__answer_pdf_queries,mcp__alphaXiv__get_paper_content"). Never invent numbers; cite every number.
Only create or edit the file(s) you are assigned. Do not edit core/, src/, other topics/stations, or data files you do not own.
Work until the check report is clean (no page/console/math errors, empty audit, no NaN, every demo "finished", no horizontal scroll at 1280 and 400 px) and the screenshots look right in light, dark and phone width.
Your final answer: a short summary with the file path, what you built, the final check status, and anything the integrator must know (missing facts, term ids you referenced from other topics, symbols you added).`

const TOPICS = ['c2','c3','d1','d2','e1','e2','e3','e4','e5','e6','f1','f2','f3']
const RESUMED = ['c2','c3']
const STATIONS = ['heads','tokens','vla','timing','worldmodel','wam','grasp','compliance','sim2real','physics','data','verifier']
const STATION_OF = {a2:'compliance', a3:'sim2real', a4:'sim2real', b1:'heads', b3:'tokens / timing', b4:'vla / tokens', c1:'worldmodel', c2:'wam / timing', c3:'worldmodel', d1:'data', d2:'data', e1:'grasp', e2:'grasp', e4:'compliance', e5:'compliance', e6:'physics', f1:'verifier', f2:'verifier'}

const SUMMARY = { type: 'object', properties: { file: { type: 'string' }, status: { type: 'string' }, notes: { type: 'string' } }, required: ['file', 'status', 'notes'] }

function topicPrompt(id) {
  return `${COMMON}

YOUR ASSIGNMENT: write ${SITE}/topics/${id}.js — the topic with id "${id}".${RESUMED.includes(id) ? ` NOTE: a previous run wrote this file but was interrupted by a restart before its final check. Read the existing file first, keep what is good, complete anything missing, and run the full build-and-check loop until clean.` : ''}
Read its line in ${SITE}/data/topics-index.js (number, part, short title, sources, buildsOn), its brief in ${SITE}/tools/topic-briefs.json (key "${id}": "row" = the planned content, diagram and mini-demo; "reading" = the method papers of this topic), and the rows of data/methods.json whose "topic" is "${id.toUpperCase()}" (tier 1 = read in full, with equations, pipelines, ablations).
Content requirements:
- The full TopicPage: orientation, 4–8 concept cards with purpose-drawn 200×56 SVG art, a FlowDiagram of where the topic acts (3–7 steps), a worked example with numbers you compute (3–7 steps, synced SVG figure), the key rules with symbol keys (and a diff against a predecessor where one exists), an algorithm box if the topic has one, 1–3 playgrounds (the planned mini-demo first) each with a Watch/Guide demo, featured methods, 2–4 open problems from the surveys, takeaways, 3–5 quiz questions, 4–8 flashcards, 6–14 glossary terms, ledger rows.
- Teach the mechanism: the playgrounds must let the learner change something and see the consequence, not just display text.
- Explain how methods in this topic evolved (what each changed about its predecessor) in the prose, concepts or worked example, using the method cards.
- Be accurate to the surveys (cite §/Table/Fig/eq refs you verified with alphaXiv) and the method cards.
${STATION_OF[id] ? `- The Interactive Lab station(s) "${STATION_OF[id]}" cover this topic in more depth (another agent builds them); you may link a concept card to "#lab/${STATION_OF[id].split(' ')[0]}" but do not duplicate a whole station.` : ''}
- Manipulation focus: prefer manipulation examples; navigation is out of scope.
Build: python3 tools/build.py --only ${id} --stations none --out dist/t-${id}.html ; check: python3 tools/check.py dist/t-${id}.html --topic ${id} --shots --full --run-demos`
}

function stationPrompt(id) {
  return `${COMMON}

YOUR ASSIGNMENT: write ${SITE}/stations/${id}.js — the Interactive Lab station "${id}".
Read its line in RB.STATION_INDEX in ${SITE}/data/topics-index.js (name, group, topics) and its brief in ${SITE}/tools/station-briefs.json (key "${id}": what the learner does, grounding, extra instructions). Read core/60-lab.js to see how the bench mounts a station (api.scene, api.controls, api.side, api.live, api.meta, api.id).
Requirements:
- A rich, well-designed simulation bench for its mechanism: several presets or modes, a live scene (canvas or SVG), controls in api.controls, readouts and a chart where useful, a side panel extra in api.side if helpful. It must be clearly more than a topic playground.
- Honest: label simplifications with prov and ledger rows; cite the surveys/method cards for every number shown that is not computed.
- A Watch/Guide demo of 5–8 steps returned from mount's demo(); destroy() must stop all timers/animation frames.
- Follow the theme (RB.pal + RB.onTheme), no hex, fits at 1280 and 400 px (the bench stacks to one column under 960 px; canvases must scale).
Build: python3 tools/build.py --only none --stations ${id} --out dist/s-${id}.html ; check: python3 tools/check.py dist/s-${id}.html --station ${id} --shots --run-demos`
}

const DATA_JOBS = [
  { key: 'lineage', file: 'data/lineage.js', prompt: `${COMMON}

YOUR ASSIGNMENT: write ${SITE}/data/lineage.js, the Evolution page's lineage lanes. Read ${SITE}/core/40-evolution.js to see exactly how it is rendered.
Define: window.RB.LINEAGE = { lanes: [...], story: [], quiz: [...] } (leave story empty: another agent fills it later by editing this file).
Eight lanes, 10–22 nodes each: "heads" (policy heads: BC-MLP → ACT → Diffusion Policy → DP3/3D Diffuser Actor → Consistency Policy → flow policies → one-step/drift), "vla" (Gato/VIMA → RT-1 → RT-2 → RT-X → Octo → OpenVLA → RDT-1B → π0 → FAST/OpenVLA-OFT → π0.5 → GR00T N1 → SmolVLA → π0.7 …), "latent" (latent actions and human video: TCN, R3M, VIP, MVP, LAPA, villa-X, UniVLA, GO-1, DreamDojo …), "world" (World Models → PlaNet → Dreamer → DreamerV3/DayDreamer → TD-MPC → TD-MPC2 → V-JEPA 2 → DINO-WM → UniSim → Cosmos → Genie Envisioner …), "wam" (UniPi → AVDC/SuSIE → GR-1 → GR-2/PAD → VPP → Seer → UVA/UWM → FLARE → WorldVLA/CoT-VLA → F1/Motus → Cosmos Policy/LingBot-VA/DreamZero → Fast-WAM …), "rl" (DQN → DDPG → SAC/PPO; QT-Opt; DR → ADR → teacher–student → RMA → ASAP; RLPD → SERL → HIL-SERL; DPPO; SimpleVLA-RL; RECAP), "verify" (SayCan → KnowNo → SAFE/FAIL-Detect → RoboMonkey/V-GPS → FIPER/Sentinel → World Action Verifier …), "grasp" (Dex-Net → GG-CNN → GR-ConvNet → 6-DoF GraspNet → GraspNet-1Billion → Contact-GraspNet → AnyGrasp → Grasp-Anything → Grasp-Anything++ → GraspGPT/ThinkGrasp → RT-Grasp → GraspVLA → VCoT-Grasp; dexterous branch DexGraspNet → DexDiffuser → Dex1B).
Lane = { id, name, blurb (≤ 30 words), cols: [period labels ≤ 12 chars, left→right in time], nodeW (optional), nodes: [{ id: <method id from data/methods.json> (or a custom id plus method: <method id>), label (≤ 22 chars), col, row, problem (≤ 20 words: the problem this method fixed, from its card), labels: { P02: '…', P04: '…', X1: '…' } (≤ 3 words each, only where that survey actually classifies the method: P02's seven VLA types, P04's three philosophies Render-and-decode / Latent-only / Video-generation-free, X1's Cascaded / Joint AR / Joint diffusion) }], edges: [[parentId, childId, 'the one change, ≤ 12 words']] }.
Every node id must exist in data/methods.json (check!) or carry a valid method field. Edges must follow the cards' "parents" and "changed" fields and the surveys; every edge label names one change. Lay rows so edges rarely cross; keep ≤ 5 rows per column.
Also quiz: 3 "What changed?" questions {q, options[4], correct, why} (limits: 25/12/40 words).
Test: python3 tools/build.py --only none --stations none --out dist/t-lineage.html ; python3 tools/check.py dist/t-lineage.html --page evolution --shots --full ; then switch each lane in the browser (write a small playwright script) and check every lane renders without overlaps; look at screenshots.` },
  { key: 'results', file: 'data/results.js + data/datasets.js', prompt: `${COMMON}

YOUR ASSIGNMENT: write ${SITE}/data/results.js and ${SITE}/data/datasets.js. Read ${SITE}/core/50-compare.js (results()) and ${SITE}/core/70-reference.js (datasets()) to see how they render.
1) results.js: window.RB.RESULTS = { suites: [{ id, short (≤ 2 words), name, metric, source: 'P03 Table 5', caption (≤ 30 words), max (optional), rows: [{ method, value (number), family (WM–policy coupling family per P03: IDM-style / Single-backbone / MoT / Unified VLA / Latent WM, etc.) }] }] }. Extract the real numbers from P03 (arXiv 2605.00080) Tables 5 and 6 with answer_pdf_queries: LIBERO average and LIBERO-Long, CALVIN ABC→D (avg length), RoboTwin 2.0 (the paper's two columns, name them as it does), SIMPLER Google and WidowX where present. Exact values only; skip cells you cannot read reliably and say so in your summary.
2) datasets.js: window.RB.DATASETS = [{ name, year, layer: one of 'Real robot' | 'UMI-style' | 'Human video' | 'Simulation' | 'General' | 'Grasp', size (number in the unit), sizeText, unit (episodes | trajectories | hours | samples | grasps | images), notes (≤ 12 words), source ('P02 Table 1' etc.) }]. Collect from P01 Tables 1–4, P02 Table 1, P05 Tables 1–6 and P06 Table 10 (about 60–100 datasets). Numbers exactly as the tables give them; where two surveys disagree (e.g. OXE 1.4M vs 2.4M) keep both rows' source info in notes.
Test: python3 tools/build.py --only none --stations none --out dist/t-results.html ; python3 tools/check.py dist/t-results.html --page compare --tab table --shots --full ; python3 tools/check.py dist/t-results.html --page reference --tab datasets --shots --full. Look at the screenshots.` },
  { key: 'conflicts', file: 'data/conflicts.js', prompt: `${COMMON}

YOUR ASSIGNMENT: write ${SITE}/data/conflicts.js: window.RB.CONFLICTS = [{ kind: 'Sources disagree' | 'Taxonomies disagree' | 'Paper contradicts itself' | 'Summary error', where (≤ 8 words, e.g. 'ACT · training loss'), a (what one source says, ≤ 30 words, name the source), b (what the other says, ≤ 30 words, name it), why (why it matters, ≤ 25 words), href (a site link: '#compare/sbs/<method id>' or '#explorer/<topic id>') }]. Read ${SITE}/core/70-reference.js (differences()) to see how rows render.
Sources: (1) every method card in data/methods.json whose notes contain "CONFLICT" (about 39) — verify the important ones against the paper with alphaXiv; (2) taxonomy disagreements between the WAM surveys: P04 (2606.20781) vs X1 (2605.12090) vs P03 (2605.00080) — e.g. FLARE/FRAPPE/LDA-1B/DUST are Joint Diffusion in X1 but Video-Generation-Free in P04; VPP/mimic-video are Cascaded-Implicit (X1) vs Latent-Only (P04); LAPA/villa-X counted as WAMs by X1 but not P04; the WAM definitions differ; (3) numeric inconsistencies across surveys: OXE 1.4M trajectories (P01, P02) vs 2.4M (P05), DROID 18 vs 13 institutions (P02), SmolVLA 6× vs 7× memory (X2), BC-Z 26.0K vs 25.9K (P02), GE-Act citation (P03 Table 1), DexWorldModel vs CLWM (X1), P01 says five future directions but lists four; verify each with alphaXiv before adding. 40–70 rows, each precise and verifiable.
Test: python3 tools/build.py --only none --stations none --out dist/t-conf.html ; python3 tools/check.py dist/t-conf.html --page reference --tab differences --shots --full. Look at the screenshots.` },
  { key: 'decide', file: 'data/decide.js', prompt: `${COMMON}

YOUR ASSIGNMENT: write ${SITE}/data/decide.js: window.RB.DECIDE = [{ id, short (≤ 2 words), title, lede (≤ 25 words), tree }] and window.RB.CMP_QUIZ = [3 questions {q, options[4], correct, why}]. Read ${SITE}/core/50-compare.js (decide(), quiz()) and the DecisionGuide engine in src/study-bench.js (function decide) to see the tree format: tree = { q (≤ 15 words, about the problem, never about method names), why (optional), a: [{ label (≤ 3 words), next: <tree or leaf> }] }; leaf = { result (method or approach name), why (≤ 25 words), ref (survey ref), href ('#explorer/<topic id>' or '#compare/sbs/<method id>') }.
Seven guides grounded in the surveys: 1 "Policy head" (P01 §6.4, X2 §4, P02 §VIII recommendations); 2 "WAM family" by latency budget and data (P04 §4, §7.1 and deployment costs; X1 §7); 3 "Next data" (P05 pyramid and §8); 4 "Human video route" (P06 Table 9); 5 "Sim-to-real fix" by symptom (P08 taxonomy O/A/T/R); 6 "Verifier" by use (P14 Table 5 and §4–5); 7 "Grasp approach" by gripper, clutter, language target and data (P01 §4.1, Fig. 4). Each guide 2–4 levels deep, 4–10 leaves. Verify key facts with alphaXiv. Method ids must exist in data/methods.json; topic ids: a1–a4, b1–b5, c1–c3, d1–d2, e1–e6, f1–f3.
Test: python3 tools/build.py --only none --stations none --out dist/t-dec.html ; python3 tools/check.py dist/t-dec.html --page compare --tab decide --shots --full ; click through every guide with a small playwright script to confirm every path ends at a leaf.` },
  { key: 'scenes', file: 'data/scenes.js', prompt: `${COMMON}

YOUR ASSIGNMENT: write ${SITE}/data/scenes.js: window.RB.SCENES = { system: { title, svg }, robot: { title, svg } } and window.RB.ANATOMY = { lede (≤ 30 words), parts: [{ sym (symbol id from data/symbols.js), tex, label (≤ 4 words) }], eq: { name, ref, tex, words, key } }.
Read ${SITE}/data/term-groups.js (RB.SCENE_PARTS lists every part id each scene must contain) and the VisualGlossary engine in src/study-bench.js (function visualGlossary) plus the Glossary/Notation code in core/80-glossary.js.
- Scene "system": one clear labeled diagram of a robot-learning system (data sources robot/UMI/human/sim/web → pretraining; instruction and camera image and proprioception → vision encoder and LLM backbone → latent → action head (with noise input) → action chunk → controller → robot; world model with predicted future; reward model and policy update with replay buffer; simulator; planner; verifier and safety filter; human teleoperation). Every part a <g data-part="<id>"> containing its shapes and label.
- Scene "robot": a manipulation scene (arm with joints on a base, end effector with gripper fingers, object on a table, grasp pose, contact points with friction cone, wrist camera and scene camera, tactile pad and force/torque sensor, trajectory with target pose, an obstacle, a cloth, a human hand). Every part a <g data-part>.
- viewBox about 0 0 760 440; 1.5px strokes; token colors only via classes or style="fill:var(--surface)" / var(--line-strong) / var(--ink-2) / var(--accent-soft); labels in body-s or mono sizes (11–13px). Focused parts get the engine's .is-focus styling — make sure shapes use fill/stroke that the focus style can override (check the CSS for .sb-vg-art .is-focus in src/study-bench.css).
- ANATOMY: the π0-style flow-matching action loss (see topics/b2.js rules) broken into 5–7 labeled parts.
Test: build with topic b2 included: python3 tools/build.py --only b2 --stations none --out dist/t-scenes.html ; python3 tools/check.py dist/t-scenes.html --page glossary --shots --full ; python3 tools/check.py dist/t-scenes.html --page notation --shots --full. Also write a playwright script that selects several b2 terms and screenshots the scene with focus in light and dark. Look at every screenshot and polish the drawings.` },
]

phase('Topics')
const topicRuns = pipeline(TOPICS, id => agent(topicPrompt(id), { label: 'topic:' + id, phase: 'Topics', schema: SUMMARY }))
phase('Stations')
const stationRuns = pipeline(STATIONS, id => agent(stationPrompt(id), { label: 'station:' + id, phase: 'Stations', schema: SUMMARY }))
phase('Data')
const lineageThenStory = Promise.resolve(null).then(r =>
  agent(`${COMMON}

YOUR ASSIGNMENT: edit ${SITE}/data/lineage.js (written by another agent; keep its lanes and quiz unchanged) to fill window.RB.LINEAGE.story, and create ${SITE}/data/eq-lineage.js with window.RB.EQ_LINEAGE. Read ${SITE}/core/40-evolution.js (storyTab, eqFor, drawEq).
1) story: 14 steps "From tokens to flows to futures": 1 hand-built pipelines are brittle; 2 BC averages modes; 3 chunking fights compounding error; 4 diffusion captures multimodality; 5 flow matching makes it cheaper; 6 VLMs bring semantics (RT-2); 7 scale through cross-embodiment data (OXE); 8 continuous heads beat tokens (π0, OFT); 9 hierarchy and knowledge insulation (π0.5, GR00T); 10 human video through latent actions (LAPA); 11 predict the future before acting (UniPi → GR-1); 12 joint video–action generation (UWM, Cosmos Policy); 13 "dream less, act more" (Fast-WAM, latent-only, P04); 14 checking before acting (verifiers, P14). Each step: { title (≤ 7 words), years, problem, change, result (each ≤ 25 words, with refs like 'X2 §4' in the text where useful), art: a purpose-drawn SVG viewBox 0 0 240 140 showing problem → change → result (token colors via classes such as rb-s-ink, rb-s-acc, rb-f-soft, rb-t-mono; 1.5px strokes; not boxes-and-arrows like the lineage map), eq (optional { name, ref, tex, words, key } in house notation with \\\\class{sym-…}), lane (lane id), node (node id in that lane), topic (topic id) }.
2) EQ_LINEAGE: for every lane node that has a defining equation (policy heads, VLAs with heads, world models, WAMs, RL, verifiers where meaningful), a hand-written { tex, words (≤ 25 words), key } in the site's house notation (data/symbols.js ids wrapped as \\\\class{sym-<id>}{…}), marking what is new relative to its lane parent with \\\\class{sb-new}{…} and what changed with \\\\class{sb-chg}{…}. Base each on the method card's eqs (data/methods.json) and the surveys; keep them faithful but readable.
Test: python3 tools/build.py --only none --stations none --out dist/t-story.html ; python3 tools/check.py dist/t-story.html --page evolution --tab story --shots --full ; python3 tools/check.py dist/t-story.html --page evolution --tab equations --shots --full ; with a playwright script walk all 14 story steps and select several nodes in each lane on the equations tab, checking for MathJax errors (data-mml-node="merror"). Look at screenshots.`, { label: 'data:story+eq', phase: 'Data', schema: SUMMARY }))
const otherData = pipeline(DATA_JOBS.slice(1), j => agent(j.prompt, { label: 'data:' + j.key, phase: 'Data', schema: SUMMARY }))

const [t, s, l, d] = await Promise.all([topicRuns, stationRuns, lineageThenStory, otherData])
return { topics: t, stations: s, lineage: l, data: d }
