/* Evolution page data: lineage lanes, story filmstrip, "What changed?" quiz.
   Rendered by core/40-evolution.js. Node ids are method ids from data/methods.json; node facts (year, title, action,
   equations) come from the method card. "problem" paraphrases the card's problem field; every edge follows the child
   card's "parents" and "changed" fields. Survey labels only where the survey places the method:
   P02 §IV-A (seven sensorimotor VLA types; UniPi under world models §IV-B), P04 §3 Tables 1–2 (three philosophies),
   X1 §4 Fig. 1–2 (Cascaded, Joint AR, Joint diffusion). Dex-Net's problem comes from P01 §4.1 (its card is survey-level). */
(function () {
  "use strict";
  var RB = window.RB;

  /* ---- story art: each figure is 240×140 in three zones (problem · change · result), token classes only ---- */
  function film(label, pr, ch, re) {
    var head = '<text class="rb-t-mono" x="38" y="14" text-anchor="middle">problem</text><text class="rb-t-mono" x="120" y="14" text-anchor="middle">change</text><text class="rb-t-mono" x="202" y="14" text-anchor="middle">result</text>' +
      '<path class="rb-s-line" d="M80 24V132M160 24V132" stroke-dasharray="2 4"/>';
    return '<svg viewBox="0 0 240 140" role="img" aria-label="' + label + '">' + head +
      '<g transform="translate(0 0)">' + pr + '</g><g transform="translate(82 0)">' + ch + '</g><g transform="translate(164 0)">' + re + "</g></svg>";
  }
  function dot(x, y, r, c) { return '<circle class="' + (c || "rb-f-soft") + '" cx="' + x + '" cy="' + y + '" r="' + (r || 4) + '"/>'; }
  function path(d, c, extra) { return '<path class="' + (c || "rb-s-ink") + '" d="' + d + '"' + (extra || "") + "/>"; }
  function txt(x, y, t, c) { return '<text class="' + (c || "rb-t-mono") + '" style="font-size:9px" x="' + x + '" y="' + y + '" text-anchor="middle">' + t + "</text>"; }
  function cross(x, y) { return path("M" + (x - 5) + " " + (y - 5) + "l10 10m0 -10l-10 10", "rb-s-ink"); }
  function frame(x, y, w, h, c) { return '<rect class="' + (c || "rb-f-surface") + '" x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="3"/>'; }
  var DASH = ' stroke-dasharray="3 3"';
  var ART = {
    pipeline: film("Hand-built pipeline misses a moved object; a learned map from data reaches it",
      dot(14, 78, 3, "rb-f-acc") + dot(38, 78, 3, "rb-f-acc") + dot(62, 78, 3, "rb-f-acc") + path("M14 78H62") + txt(14, 96, "see") + txt(38, 96, "plan") + txt(62, 96, "act") + dot(62, 44, 5) + path("M62 72 L50 50", "rb-s-ink", DASH) + cross(50, 50),
      [20, 32, 44, 56, 30, 48, 62, 16, 40, 58].map(function (x, i) { return dot(x, 104 - i * 6 - (x % 7), 2.5, "rb-f-sunk"); }).join("") + path("M10 110 C 30 90, 44 70, 70 40", "rb-s-acc") + txt(38, 126, "learn a map"),
      path("M10 110 C 24 84, 44 60, 58 46", "rb-s-acc") + dot(60, 44, 5) + txt(38, 126, "fits the data")),
    modes: film("Two demonstrations go around an obstacle; their average hits it; bins pick one side",
      frame(26, 64, 24, 24, "rb-f-sunk") + path("M6 76 C 20 40, 56 40, 70 76") + path("M6 76 C 20 112, 56 112, 70 76") + path("M6 76 H26", "rb-s-acc", DASH) + cross(24, 76) + txt(38, 126, "mean hits it"),
      [0, 1, 2, 3, 4, 5, 6].map(function (i) { var h = [6, 30, 8, 2, 8, 34, 5][i]; return '<rect class="rb-f-soft" x="' + (6 + i * 9.5) + '" y="' + (104 - h) + '" width="7" height="' + h + '"/>'; }).join("") + path("M4 104H72", "rb-s-line") + txt(38, 122, "bins + offset"),
      frame(26, 64, 24, 24, "rb-f-sunk") + path("M6 76 C 20 40, 56 40, 70 76", "rb-s-acc") + txt(38, 126, "one mode")),
    chunk: film("One-step errors compound away from the demo; chunks of H actions stay close",
      path("M6 90 H70", "rb-s-line") + path("M6 90 C 30 88, 50 70, 70 44", "rb-s-ink") + path("M70 44 L70 90", "rb-s-line", DASH) + txt(56, 36, "drift") + txt(38, 126, "errors grow"),
      [0, 1, 2, 3, 4, 5].map(function (i) { return path("M" + (8 + i * 10) + " 80 l7 0", "rb-s-acc") + dot(8 + i * 10, 80, 2, "rb-f-acc"); }).join("") + path("M8 94 v4 h56 v-4", "rb-s-ink") + txt(36, 112, "H at once"),
      path("M6 90 H70", "rb-s-line") + path("M6 90 C 30 89, 50 86, 70 84", "rb-s-acc") + [26, 46, 66].map(function (x) { return path("M" + x + " 80 v12", "rb-s-ink"); }).join("") + txt(38, 126, "few decisions")),
    diffusion: film("A unimodal fit sits between two peaks; denoising moves noise into both clusters",
      path("M4 104 C 14 104, 16 56, 22 56 C 28 56, 30 104, 38 104 C 46 104, 48 56, 54 56 C 60 56, 62 104, 72 104", "rb-s-ink") + path("M4 104 C 24 104, 30 70, 38 70 C 46 70, 52 104, 72 104", "rb-s-acc", DASH) + txt(38, 126, "one bump"),
      [[10, 40], [24, 56], [8, 92], [30, 100], [18, 74]].map(function (p, i) { var tx = i % 2 ? 60 : 56, ty = i % 2 ? 50 : 96; return dot(p[0], p[1], 2.5, "rb-f-sunk") + path("M" + (p[0] + 3) + " " + p[1] + " L" + tx + " " + ty, "rb-s-line", DASH); }).join("") + dot(58, 50, 5) + dot(58, 96, 5) + txt(38, 126, "noise to data"),
      path("M4 104 C 14 104, 16 56, 22 56 C 28 56, 30 104, 38 104 C 46 104, 48 56, 54 56 C 60 56, 62 104, 72 104", "rb-s-ink") + path("M4 104 C 14 104, 16 60, 22 60 C 28 60, 30 104, 38 104 C 46 104, 48 60, 54 60 C 60 60, 62 104, 72 104", "rb-s-acc") + txt(38, 126, "both modes")),
    flow: film("Curved diffusion path needs many steps; a straight flow needs one or two",
      path("M8 110 C 70 100, 0 50, 66 36", "rb-s-ink") + [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9].map(function (t) { var x = Math.round(8 * Math.pow(1 - t, 3) + 3 * 70 * Math.pow(1 - t, 2) * t + 3 * 0 * (1 - t) * t * t + 66 * t * t * t), y = Math.round(110 * Math.pow(1 - t, 3) + 3 * 100 * Math.pow(1 - t, 2) * t + 3 * 50 * (1 - t) * t * t + 36 * t * t * t); return dot(x, y, 1.8, "rb-f-acc"); }).join("") + txt(38, 126, "~100 steps"),
      dot(10, 108, 3, "rb-f-sunk") + dot(64, 38, 4) + path("M12 106 L62 40", "rb-s-acc") + txt(20, 80, "v") + txt(38, 126, "straight path"),
      dot(10, 108, 3, "rb-f-sunk") + dot(37, 73, 2.5, "rb-f-acc") + dot(64, 38, 4) + path("M12 106 L62 40", "rb-s-acc") + txt(38, 126, "1–2 steps")),
    vlm: film("A robot-data policy does not know an object; a web-pretrained VLM names it; the right object is picked",
      dot(20, 80, 7, "rb-f-sunk") + dot(38, 80, 7, "rb-f-sunk") + dot(56, 80, 7, "rb-f-sunk") + txt(38, 54, "which one?", "rb-t-acc") + txt(38, 126, "robot data"),
      frame(8, 44, 30, 26) + path("M12 64 l8 -10 l6 6 l4 -4 l6 8", "rb-s-ink") + frame(42, 48, 28, 18, "rb-f-sunk") + txt(56, 60, "text") + path("M8 84 H70", "rb-s-line") + txt(38, 102, "web pairs") + txt(38, 126, "VLM backbone"),
      dot(20, 80, 7, "rb-f-sunk") + dot(38, 80, 7, "rb-f-soft") + dot(56, 80, 7, "rb-f-sunk") + path("M38 50 V68", "rb-s-acc") + path("M33 63 l5 5 l5 -5", "rb-s-acc") + txt(38, 126, "grounded pick")),
    embody: film("One narrow dataset; many embodiments pooled; broader transfer",
      '<rect class="rb-f-soft" x="30" y="84" width="16" height="22"/>' + path("M8 106 H70", "rb-s-line") + txt(38, 126, "one robot"),
      [16, 30, 12, 24, 8, 20].map(function (h, i) { return '<rect class="rb-f-soft" x="' + (8 + i * 10.5) + '" y="' + (106 - h) + '" width="8" height="' + h + '"/>'; }).join("") + path("M8 106 H72", "rb-s-line") + txt(38, 126, "many robots"),
      '<rect class="rb-f-soft" x="30" y="44" width="16" height="62"/>' + path("M8 106 H70", "rb-s-line") + path("M24 44 H52", "rb-s-acc") + txt(38, 126, "pooled data")),
    continuous: film("Binned tokens give a staircase at low rate; a flow expert outputs a smooth chunk at high rate",
      path("M6 100 H18 V88 H30 V70 H42 V62 H54 V50 H66 V46 H72", "rb-s-ink") + path("M6 100 C 30 96, 44 60, 72 46", "rb-s-line", DASH) + txt(38, 126, "one by one"),
      dot(10, 104, 3, "rb-f-sunk") + path("M14 102 C 30 90, 40 70, 60 52", "rb-s-acc") + path("M54 50 l7 1 l-2 7", "rb-s-acc") + txt(38, 126, "flow expert"),
      path("M6 100 C 30 96, 44 60, 72 46", "rb-s-acc") + [10, 18, 26, 34, 42, 50, 58, 66].map(function (x) { return path("M" + x + " 108 v5", "rb-s-ink"); }).join("") + txt(38, 126, "smooth chunk")),
    insulate: film("Action gradients flow into and erode the VLM; a stop-gradient insulates it; subtask text on top, fast actions below",
      frame(8, 40, 60, 24, "rb-f-soft") + txt(38, 56, "VLM") + path("M24 100 C 24 84, 30 74, 30 68", "rb-s-ink") + path("M44 100 C 44 84, 38 74, 38 68", "rb-s-ink") + path("M26 72 l4 -4 l4 4M34 72 l4 -4 l4 4", "rb-s-ink") + txt(38, 116, "action grads") + txt(38, 132, "erode it"),
      frame(8, 40, 60, 24, "rb-f-soft") + txt(38, 56, "VLM") + path("M6 76 H70", "rb-s-acc") + txt(38, 92, "stop-grad") + path("M30 104 l8 8 l8 -8", "rb-s-ink") + txt(38, 126, "insulated"),
      frame(4, 36, 68, 18) + txt(38, 49, "wipe counter") + path("M4 92 C 12 80, 16 104, 24 92 C 32 80, 36 104, 44 92 C 52 80, 56 104, 64 92 L72 92", "rb-s-acc") + txt(38, 126, "plan, then act")),
    latent: film("Video frames lack action labels; frame differences become codes; codes label the video",
      frame(6, 50, 28, 22) + frame(42, 50, 28, 22) + txt(20, 90, "?", "rb-t-acc") + txt(56, 90, "?", "rb-t-acc") + txt(38, 126, "no actions"),
      frame(4, 40, 22, 18) + frame(4, 64, 22, 18) + path("M28 61 H40", "rb-s-ink") + [0, 1, 2, 3].map(function (i) { return '<rect class="' + (i === 2 ? "rb-f-acc" : "rb-f-sunk") + '" x="' + (44 + (i % 2) * 13) + '" y="' + (48 + Math.floor(i / 2) * 13) + '" width="11" height="11"/>'; }).join("") + txt(38, 102, "Δ → code") + txt(38, 126, "latent action"),
      frame(6, 50, 28, 22) + frame(42, 50, 28, 22) + '<rect class="rb-f-acc" x="15" y="80" width="10" height="10"/><rect class="rb-f-acc" x="51" y="80" width="10" height="10"/>' + txt(38, 126, "pseudo-labels")),
    future: film("Acting from the current frame only; generating future frames; reading actions off the imagined future",
      frame(24, 56, 28, 22) + path("M38 82 V100", "rb-s-ink") + path("M34 96 l4 4 l4 -4", "rb-s-ink") + txt(38, 114, "a") + txt(38, 132, "reacts only"),
      frame(4, 60, 24, 20) + frame(22, 54, 24, 20, "rb-f-sunk") + frame(40, 48, 24, 20, "rb-f-sunk") + txt(52, 40, "o′", "rb-t-acc") + txt(38, 126, "imagine video"),
      frame(4, 48, 24, 20, "rb-f-sunk") + frame(44, 48, 24, 20, "rb-f-sunk") + path("M16 72 C 16 96, 56 96, 56 72", "rb-s-acc") + txt(36, 108, "inverse dyn.") + txt(38, 126, "act from o′")),
    joint: film("Predict-then-act in two stages; one model with separate noise levels; one model, several uses",
      frame(8, 44, 60, 18, "rb-f-sunk") + txt(38, 57, "video model") + frame(8, 84, 60, 18, "rb-f-sunk") + txt(38, 97, "policy") + path("M38 64 V82", "rb-s-ink", DASH) + txt(38, 126, "no sharing"),
      [0, 1, 2, 3, 4, 5].map(function (i) { return '<rect class="' + (i % 2 ? "rb-f-soft" : "rb-f-sunk") + '" x="' + (4 + i * 12) + '" y="56" width="10" height="16"/>'; }).join("") + path("M4 90 H70", "rb-s-line") + dot(22, 90, 3.5, "rb-f-acc") + path("M4 104 H70", "rb-s-line") + dot(58, 104, 3.5, "rb-f-acc") + txt(38, 126, "own timesteps"),
      txt(38, 48, "policy", "rb-t-acc") + txt(38, 68, "world model", "rb-t-acc") + txt(38, 88, "inverse dyn.", "rb-t-acc") + txt(38, 108, "video gen.", "rb-t-acc") + txt(38, 126, "one model")),
    dreamless: film("Rendering full frames each step is slow; acting from one latent pass is fast",
      frame(6, 44, 20, 16) + frame(28, 44, 20, 16) + frame(50, 44, 20, 16) + '<rect class="rb-f-soft" x="6" y="80" width="64" height="10"/>' + txt(38, 104, "slow render") + txt(38, 126, "costly loop"),
      [0, 1, 2, 3, 4, 5].map(function (i) { return dot(12 + i * 10, 60, 3, i === 5 ? "rb-f-acc" : "rb-f-sunk"); }).join("") + path("M8 76 H70", "rb-s-line", DASH) + txt(38, 94, "no pixels") + txt(38, 126, "latent only"),
      '<rect class="rb-f-sunk" x="6" y="52" width="64" height="10"/><rect class="rb-f-soft" x="6" y="72" width="21" height="10"/>' + txt(38, 46, "580 ms") + txt(38, 98, "190 ms", "rb-t-acc") + txt(38, 126, "Fast-WAM")),
    verify: film("A single sample may fail; N candidates are scored; the best one runs",
      dot(64, 48, 5) + frame(34, 68, 14, 14, "rb-f-sunk") + path("M8 108 C 24 96, 34 84, 40 76", "rb-s-ink") + cross(42, 74) + txt(38, 126, "one guess"),
      [[64, 40], [66, 58], [62, 76], [56, 92]].map(function (p, i) { return path("M8 108 L" + p[0] + " " + p[1], "rb-s-line") + txt(p[0] + 6, p[1] + 2, [".9", ".4", ".2", ".1"][i]); }).join("") + txt(38, 126, "score each"),
      dot(64, 48, 5) + frame(34, 68, 14, 14, "rb-f-sunk") + path("M8 108 C 14 80, 40 52, 58 48", "rb-s-acc") + txt(38, 126, "best of N"))
  };

  RB.LINEAGE = {
    lanes: [
      /* ---------------------------------------------------------------- policy heads */
      {
        id: "heads", name: "Policy heads",
        nodeW: 152,
        blurb: "How the action head evolved: from binned tokens to action chunks, diffusion, 3D inputs, few-step flows and one-step drifting policies.",
        cols: ["2022", "2023", "2024 · H1", "2024 · H2", "2025", "2026"],
        nodes: [
          { id: "behavior-transformers", label: "BeT", col: 0, row: 0, problem: "Squared-error behavior cloning averages the modes of multimodal human demonstrations." },
          { id: "act", label: "ACT", col: 1, row: 1, problem: "Imprecise low-cost arms and compounding errors at high control rates break fine bimanual imitation." },
          { id: "diffusion-policy", label: "Diffusion Policy", col: 1, row: 2, problem: "BC heads struggle with multimodal, high-dimensional action sequences; implicit policies train unstably." },
          { id: "vq-bet", label: "VQ-BeT", col: 2, row: 0, problem: "BeT's k-means bins do not scale to high-dimensional actions or chunks and pass no gradients." },
          { id: "3d-diffuser-actor", label: "3D Diffuser Actor", col: 2, row: 1, problem: "Diffusion policies lacked 3D scene input; 3D policies used deterministic objectives that handle multimodality poorly." },
          { id: "dp3", label: "DP3", col: 2, row: 2, problem: "Image diffusion policies need 100–200 demos per task and generalize poorly across viewpoint and instance." },
          { id: "consistency-policy", label: "Consistency Policy", col: 2, row: 3, problem: "Diffusion Policy needs about 100 sequential denoising steps, too slow for constrained robots and dynamic tasks." },
          { id: "adaflow", label: "AdaFlow", col: 2, row: 4, problem: "Diffusion is slow, BC is not diverse, and one-step rectified flow needs costly reflow or distillation." },
          { id: "flowpolicy", label: "FlowPolicy", col: 3, row: 2, problem: "3D diffusion policies trade inference speed against action quality through many sampling steps." },
          { id: "onedp", label: "OneDP", col: 3, row: 3, problem: "Iterative denoising runs at about 1.5 Hz; Consistency Policy still needs several steps." },
          { id: "maniflow", label: "ManiFlow", col: 4, row: 1, problem: "Flow policies are limited in efficiency and robustness for dexterous tasks and condition poorly on many inputs." },
          { id: "mp1", label: "MP1", col: 4, row: 2, problem: "One-step flow policies such as FlowPolicy rely on explicit consistency constraints." },
          { id: "streaming-flow-policy", label: "Streaming Flow Policy", col: 4, row: 4, problem: "Diffusion and flow policies make the robot wait until a whole trajectory is sampled." },
          { id: "dbpo", label: "DBPO", col: 5, row: 2, problem: "Multi-step heads cost tens to hundreds of network evaluations; one-step methods depend on distillation." },
          { id: "implicit-drifting-policy", label: "Implicit Drifting", col: 5, row: 3, problem: "Explicit drifting fields collapse to plain squared error in behavior cloning with one expert action per observation." }
        ],
        edges: [
          ["behavior-transformers", "vq-bet", "Learned residual-VQ codes replace k-means action bins"],
          ["behavior-transformers", "act", "Continuous action chunks from a CVAE replace binned actions"],
          ["behavior-transformers", "diffusion-policy", "Denoises continuous action sequences instead of classifying bins"],
          ["diffusion-policy", "3d-diffuser-actor", "Denoises full poses over tokenized 3D scene features"],
          ["diffusion-policy", "dp3", "A compact point-cloud encoder replaces the image encoder"],
          ["diffusion-policy", "consistency-policy", "Distills the sampler into 1–3 network evaluations"],
          ["diffusion-policy", "adaflow", "Rectified flow with variance-adaptive step sizes"],
          ["dp3", "flowpolicy", "One-step consistency flow matching replaces 10-step DDIM"],
          ["consistency-policy", "onedp", "A single-step generator distilled by distribution matching"],
          ["flowpolicy", "maniflow", "Consistency training without a teacher, inside flow matching"],
          ["flowpolicy", "mp1", "MeanFlow average velocity replaces consistency constraints"],
          ["adaflow", "streaming-flow-policy", "The flow path itself becomes the executed trajectory"],
          ["mp1", "dbpo", "A drifting objective that is one-step by construction"],
          ["dbpo", "implicit-drifting-policy", "A static geometry-weighted potential replaces the drifting field"]
        ]
      },

      /* ---------------------------------------------------------------- VLAs */
      {
        id: "vla", name: "Vision-language-action models",
        nodeW: 126,
        blurb: "Generalist policies: one sequence model, then web-pretrained backbones, pooled robot data, and action heads that moved from tokens to diffusion and flow.",
        cols: ["2022", "2023", "2024 · H1", "2024 · H2", "2025 · Q1", "2025 · Q2", "2026"],
        nodes: [
          { id: "vima", label: "VIMA", col: 0, row: 0, problem: "Language, demos, goal images and constraints were handled by separate specialized models.", labels: { P02: "TF+token (1)" } },
          { id: "gato", label: "Gato", col: 0, row: 1, problem: "Agents were specialized per domain; could one set of weights handle text, vision and control?", labels: { P02: "TF+token (1)" } },
          { id: "rt-1", label: "RT-1", col: 0, row: 2, problem: "Robot policies were trained per task on narrow data and did not generalize zero-shot.", labels: { P02: "TF+token (1)" } },
          { id: "rt-2", label: "RT-2", col: 1, row: 1, problem: "Low-level controllers did not benefit from web-scale knowledge in vision-language models.", labels: { P02: "VLM+token (4)" } },
          { id: "open-x-embodiment-rt-x", label: "RT-X", col: 1, row: 2, problem: "Each robot dataset is narrow; it was unknown whether pooling embodiments transfers." },
          { id: "openvla", label: "OpenVLA", col: 2, row: 1, problem: "The strongest VLAs were closed, with no recipe for fine-tuning on commodity hardware.", labels: { P02: "VLM+token (4)" } },
          { id: "octo", label: "Octo", col: 2, row: 2, problem: "Generalist policies fixed their inputs, could not be fine-tuned to new spaces, and were closed.", labels: { P02: "TF+diffusion (2)" } },
          { id: "cogact", label: "CogACT", col: 3, row: 0, problem: "Binned action tokens limit precision; regression heads ignore multimodality.", labels: { P02: "VLM+DiT (7)" } },
          { id: "pi0", label: "π0", col: 3, row: 2, problem: "Discretized autoregressive actions cannot give the high-frequency chunks dexterous tasks need.", labels: { P02: "VLM+flow (6)" } },
          { id: "rdt-1b", label: "RDT-1B", col: 3, row: 3, problem: "Scarce bimanual data, multimodal two-arm actions and mismatched action spaces across robots.", labels: { P02: "DiT (3)" } },
          { id: "openvla-oft", label: "OpenVLA-OFT", col: 4, row: 1, problem: "Autoregressive VLAs run at 3–5 Hz, too slow for 25–50 Hz control, and fine-tune poorly." },
          { id: "fast", label: "FAST", col: 4, row: 2, problem: "Per-step binning of high-rate chunks yields correlated tokens, so next-token training stalls." },
          { id: "gr00t-n1", label: "GR00T N1", col: 4, row: 3, problem: "Humanoid data is scattered into embodiment-specific islands; reasoning and fast control are both needed.", labels: { P02: "VLM+DiT (7)" } },
          { id: "knowledge-insulation", label: "Insulation (KI)", col: 5, row: 1, problem: "A fresh action expert slows training and erodes the VLM's knowledge; FAST decoding is slow." },
          { id: "pi0-5", label: "π0.5", col: 5, row: 2, problem: "End-to-end policies had not generalized to entirely new homes for long, dexterous tasks.", labels: { P02: "(4) and (6)" } },
          { id: "smolvla", label: "SmolVLA", col: 5, row: 3, problem: "Billion-parameter VLAs are costly and ignore community data from low-cost robots.", labels: { P02: "VLM+DiT (7)" } },
          { id: "pi0-7", label: "π0.7", col: 6, row: 2, problem: "VLAs need per-task fine-tuning; mixed-quality data averages behavior modes.", labels: { P04: "Render-and-decode", X1: "Cascaded" } }
        ],
        edges: [
          ["gato", "vima", "Object tokens and cross-attention prompts in an encoder-decoder"],
          ["gato", "rt-1", "A real-time robot transformer trained on large, diverse real data"],
          ["rt-1", "rt-2", "A web-pretrained VLM whose tokens double as actions"],
          ["rt-2", "open-x-embodiment-rt-x", "Same models, trained on pooled multi-robot data"],
          ["rt-2", "openvla", "Same token recipe on an open 7B backbone"],
          ["open-x-embodiment-rt-x", "octo", "A diffusion head over action chunks replaces 256-bin tokens"],
          ["openvla", "cogact", "A DiT diffusion action module replaces discrete action tokens"],
          ["openvla", "pi0", "A flow-matching action expert replaces discrete action tokens"],
          ["octo", "rdt-1b", "Scales a diffusion transformer to 1.2B parameters"],
          ["openvla", "openvla-oft", "Parallel continuous chunks trained with L1 replace tokens"],
          ["pi0", "fast", "DCT plus BPE compressed tokens replace per-step bins"],
          ["pi0", "gr00t-n1", "A DiT cross-attends to middle-layer VLM features"],
          ["fast", "pi0-5", "FAST tokens in pre-training, a flow expert in post-training"],
          ["pi0-5", "knowledge-insulation", "One stage with a stop-gradient insulating the VLM"],
          ["gr00t-n1", "smolvla", "About 7x smaller recipe, trained on community data"],
          ["pi0-5", "pi0-7", "Rich context prompts, including subgoal images, with CFG"]
        ]
      },

      /* ---------------------------------------------------------------- latent actions and human video */
      {
        id: "latent", name: "Latent actions and human video",
        nodeW: 152,
        blurb: "Learning from video without robot actions: time-contrastive and masked features, value embeddings, latent action tokens, and human hand data.",
        cols: ["2017", "2022", "2023", "2024", "2025", "2026"],
        nodes: [
          { id: "time-contrastive-networks", label: "TCN", col: 0, row: 1, problem: "Imitating humans from third-person video needs features invariant to viewpoint and embodiment." },
          { id: "mvp", label: "MVP", col: 1, row: 0, problem: "RL from pixels is sample-hungry and overfits; ImageNet encoders transfer poorly to manipulation." },
          { id: "r3m", label: "R3M", col: 1, row: 1, problem: "Robotics lacked an off-the-shelf pretrained visual backbone; tabula-rasa training is data-hungry." },
          { id: "vip", label: "VIP", col: 1, row: 2, problem: "Embedding distance to a goal image makes a poor reward, so rewards stay hand-engineered." },
          { id: "vc-1", label: "VC-1", col: 2, row: 0, problem: "Nobody knew whether one general visual cortex exists or whether scaling data helps everywhere." },
          { id: "voltron", label: "Voltron", col: 2, row: 1, problem: "Masked autoencoders miss semantics; contrastive features miss low-level spatial detail." },
          { id: "liv", label: "LIV", col: 2, row: 3, problem: "Robots need aligned vision-language features that also measure task progress as a reward." },
          { id: "mimicplay", label: "MimicPlay", col: 2, row: 2, problem: "Long-horizon imitation needs unattainable amounts of teleoperated demos; robot play data is slow." },
          { id: "lapa", label: "LAPA", col: 3, row: 1, problem: "VLA pretraining needs action labels; internet and human videos have none.", labels: { X1: "Cascaded" } },
          { id: "igor", label: "IGOR", col: 3, row: 2, problem: "Latent-action work targeted 2D games, not a shared action space across humans and robots." },
          { id: "egomimic", label: "EgoMimic", col: 3, row: 3, problem: "Human video only guided a planner, so skill stayed capped by teleop-only low-level policies." },
          { id: "agibot-world-go-1", label: "GO-1", col: 4, row: 0, problem: "Robot datasets are short and lab-bound; policies struggle to use action-free data.", labels: { P02: "VLM+diffusion (5)" } },
          { id: "villa-x", label: "villa-X", col: 4, row: 1, problem: "Visual-only latent actions miss rotations and gripper motion, and transfer poorly into VLAs.", labels: { X1: "Cascaded" } },
          { id: "univla-2", label: "UniVLA (Bu et al.)", col: 4, row: 2, problem: "Pixel-reconstruction latent actions also encode camera shake and other agents." },
          { id: "h-rdt", label: "H-RDT", col: 4, row: 3, problem: "Robot pretraining faces mismatched action spaces; prior human-video methods were small and single-embodiment." },
          { id: "clap", label: "CLAP", col: 5, row: 2, problem: "Reconstruction-trained latent actions entangle background and are not aligned with robot actions." }
        ],
        edges: [
          ["time-contrastive-networks", "r3m", "Time contrast moves to large in-the-wild Ego4D video"],
          ["r3m", "vip", "A self-supervised value objective replaces explicit time contrast"],
          ["mvp", "vc-1", "Same MAE recipe, larger and more diverse data at ViT-L"],
          ["mvp", "voltron", "Adds language conditioning and generation to masked autoencoding"],
          ["vip", "liv", "Joint vision-language values instead of image-only goals"],
          ["r3m", "mimicplay", "A planner trained on human play hand trajectories"],
          ["lapa", "igor", "Latent actions from open-world human and robot video"],
          ["mimicplay", "egomimic", "One end-to-end policy supervised by human and robot data"],
          ["lapa", "agibot-world-go-1", "Keeps an explicit latent planner at inference"],
          ["lapa", "villa-x", "A proprioceptive dynamics model grounds the latent actions"],
          ["agibot-world-go-1", "villa-x", "Joint flow matching replaces a separate latent planner"],
          ["lapa", "univla-2", "Predicts in DINOv2 feature space, disentangled by language"],
          ["igor", "univla-2", "Task-centric latents instead of pixel reconstruction"],
          ["egomimic", "h-rdt", "Pretrains on large-scale human hand data first"],
          ["univla-2", "clap", "Latent codebook grounded in robot actions, aligned contrastively"]
        ]
      },

      /* ---------------------------------------------------------------- world models */
      {
        id: "world", name: "World models",
        nodeW: 152,
        blurb: "Learned simulators: latent dynamics for planning and imagination, then pretrained features and large video generators. Boxes without an incoming arrow start a separate line.",
        cols: ["2018–20", "2022", "2023", "2024", "2025", "2026"],
        nodes: [
          { id: "world-models", label: "World Models", col: 0, row: 0, problem: "Large model-free agents face hard credit assignment; can a compact generative model train a tiny controller?" },
          { id: "planet", label: "PlaNet", col: 0, row: 1, problem: "Learned image dynamics were inaccurate over many steps and got exploited by planners." },
          { id: "dreamer", label: "Dreamer", col: 0, row: 2, problem: "Model-based agents planned online or looked only a fixed horizon ahead, ignoring model gradients." },
          { id: "daydreamer", label: "DayDreamer", col: 1, row: 1, problem: "Deep RL needs too much trial and error to learn directly on physical robots." },
          { id: "td-mpc", label: "TD-MPC", col: 1, row: 3, problem: "Long-horizon planning is costly and reconstruction wastes capacity on task-irrelevant detail." },
          { id: "unisim", label: "UniSim", col: 2, row: 0, problem: "Each real-world dataset covers only one axis, so none teaches interactive action-conditioned simulation." },
          { id: "dreamerv3", label: "DreamerV3", col: 2, row: 2, problem: "World-model RL needed per-domain hyperparameter tuning." },
          { id: "td-mpc2", label: "TD-MPC2", col: 2, row: 3, problem: "Naively scaling TD-MPC hurts, and generalist agents relied on near-expert data." },
          { id: "dino-wm", label: "DINO-WM", col: 3, row: 3, problem: "World models were task-specific or needed rewards and demos; learning encoders from scratch is inefficient." },
          { id: "cosmos-world-foundation-models", label: "Cosmos", col: 4, row: 0, problem: "Physical AI lacked an open pretrained world model that can be post-trained per robot." },
          { id: "genie-envisioner", label: "Genie Envisioner", col: 4, row: 1, problem: "Data, policy and evaluation are separate stacks; VLAs have no internal world model." },
          { id: "dreamer-4", label: "Dreamer 4", col: 4, row: 2, problem: "Recurrent world models underfit complex data; video models are too slow for imagination training." },
          { id: "v-jepa-2", label: "V-JEPA 2", col: 4, row: 4, problem: "Interaction data is scarce, and video generators are costly to plan with and chase pixel detail." },
          { id: "dreamdojo", label: "DreamDojo", col: 5, row: 0, problem: "Robot video world models generalize poorly and respond weakly to counterfactual actions." },
          { id: "leworldmodel", label: "LeWorldModel", col: 5, row: 3, problem: "Latent predictive world models collapse and rely on fragile heuristics and many-term losses." }
        ],
        edges: [
          ["world-models", "planet", "A jointly learned RSSM with latent CEM planning"],
          ["planet", "dreamer", "An actor-critic learned in imagination replaces online planning"],
          ["dreamer", "daydreamer", "Same algorithm, run online on four physical robots"],
          ["dreamer", "td-mpc", "Reward and value-driven latents with short-horizon MPC"],
          ["dreamer", "dreamerv3", "Robustness tricks so one fixed configuration fits all domains"],
          ["td-mpc", "td-mpc2", "Architecture changes so one model scales across many tasks"],
          ["dreamerv3", "dino-wm", "Frozen DINOv2 patch features, trained offline without rewards"],
          ["dreamerv3", "dreamer-4", "A transformer world model trained offline by shortcut forcing"],
          ["cosmos-world-foundation-models", "genie-envisioner", "Adds a parallel flow-matching action branch"],
          ["cosmos-world-foundation-models", "dreamdojo", "Latent-action conditioning learned from human video"],
          ["dino-wm", "leworldmodel", "A two-term loss replaces the frozen encoder"]
        ]
      },

      /* ---------------------------------------------------------------- world action models */
      {
        id: "wam", name: "World action models",
        blurb: "Models that predict the future to choose actions: video plans with inverse dynamics, joint video-action generation, and methods that render less of the future.",
        cols: ["2023", "2024", "2025 · H1", "2025 · H2", "2026"],
        nodes: [
          { id: "avdc", label: "AVDC", col: 0, row: 0, problem: "Video-as-policy still needs action labels for inverse dynamics, and video diffusion is expensive.", labels: { P04: "Render-and-decode", X1: "Cascaded" } },
          { id: "unipi", label: "UniPi", col: 0, row: 1, problem: "Agents cannot share knowledge across different state and action spaces; web video is hard to use.", labels: { P02: "World model", P04: "Render-and-decode", X1: "Cascaded" } },
          { id: "susie", label: "SuSIE", col: 0, row: 2, problem: "Robot-data policies fail on novel objects; internet models do not give low-level actions." },
          { id: "gr-1", label: "GR-1", col: 0, row: 3, problem: "Robot data is scarce; does video-prediction pretraining help multi-task manipulation?", labels: { P02: "VLM+token (4)", P04: "Render-and-decode", X1: "Joint AR" } },
          { id: "vpp", label: "VPP", col: 1, row: 1, problem: "Vision encoders capture static features; denoising full future videos for control is too slow.", labels: { P04: "Latent-only", X1: "Cascaded" } },
          { id: "pad", label: "PAD", col: 1, row: 2, problem: "Two-stage predict-then-act methods do not share representations; diffusion policies ignore the future.", labels: { P04: "Render-and-decode", X1: "Joint diffusion" } },
          { id: "seer", label: "Seer", col: 1, row: 3, problem: "Visual prediction and action were trained in separate stages, never closing the loop." },
          { id: "gr-2", label: "GR-2", col: 1, row: 4, problem: "GR-1's small pretraining set and single-step actions limited generalization.", labels: { P04: "Render-and-decode", X1: "Joint AR" } },
          { id: "uva", label: "UVA", col: 2, row: 1, problem: "Video policies are slow and propagate video errors; PAD must generate images to act.", labels: { P02: "DiT (3)", P04: "Latent-only", X1: "Joint diffusion" } },
          { id: "uwm", label: "UWM", col: 2, row: 2, problem: "A shared diffusion timestep for video and action limits flexible inference.", labels: { P04: "Latent-only", X1: "Joint diffusion" } },
          { id: "flare", label: "FLARE", col: 2, row: 3, problem: "Generating future frames is heavy and splits capacity between pixel fidelity and actions.", labels: { P04: "Video-generation-free", X1: "Joint diffusion" } },
          { id: "worldvla", label: "WorldVLA", col: 2, row: 4, problem: "VLAs never model action consequences; world models cannot output actions.", labels: { P04: "Render-and-decode", X1: "Joint AR" } },
          { id: "motus", label: "Motus", col: 3, row: 2, problem: "Embodied models are fragmented, and action experts cannot pretrain on action-less video.", labels: { P04: "Render-and-decode", X1: "Joint diffusion" } },
          { id: "dreamzero", label: "DreamZero", col: 4, row: 0, problem: "VLAs fail on unseen motions; large video-diffusion policies are too slow for closed loop.", labels: { P04: "Render-and-decode", X1: "Joint diffusion" } },
          { id: "cosmos-policy", label: "Cosmos Policy", col: 4, row: 1, problem: "Video-model policies need several post-training stages and new action modules.", labels: { P04: "Latent-only", X1: "Joint diffusion" } },
          { id: "lingbot-va", label: "LingBot-VA", col: 4, row: 2, problem: "Chunked, bidirectional video-action models react slowly and have limited memory.", labels: { P04: "Latent-only", X1: "Joint diffusion" } },
          { id: "fast-wam", label: "Fast-WAM", col: 4, row: 3, problem: "Imagine-then-act models pay heavy latency; is imagination at test time even needed?", labels: { P04: "Latent-only", X1: "Joint diffusion" } }
        ],
        edges: [
          ["unipi", "avdc", "Optical flow and depth replace an action-labeled inverse model"],
          ["unipi", "susie", "One subgoal image from an image editor, not a video"],
          ["susie", "vpp", "Acts on one-pass video-diffusion features, never finishes denoising"],
          ["susie", "pad", "Image prediction and action denoising in one DiT"],
          ["gr-1", "pad", "Joint diffusion replaces autoregressive frame prediction"],
          ["gr-1", "seer", "Action token attends to a foresight latent, trained end-to-end"],
          ["gr-1", "gr-2", "Scales video pretraining from 0.8M to 38M clips"],
          ["pad", "uva", "Decoupled decoding: actions without generating video"],
          ["pad", "uwm", "Separate diffusion timesteps for video and action"],
          ["uwm", "flare", "Aligns hidden states to future embeddings instead of frames"],
          ["gr-2", "worldvla", "Action-conditioned next-frame prediction in a discrete-token VLA"],
          ["uwm", "motus", "Built on pretrained video and VLM experts, not from scratch"],
          ["uva", "cosmos-policy", "A pretrained video model; actions and values become latent frames"],
          ["cosmos-policy", "dreamzero", "Autoregressive joint video-action denoising at 14B scale"],
          ["motus", "lingbot-va", "Causal autoregressive interleaving with KV-cached history"],
          ["lingbot-va", "fast-wam", "Drops test-time video denoising, keeps video co-training"]
        ]
      },

      /* ---------------------------------------------------------------- reinforcement learning */
      {
        id: "rl", name: "Reinforcement learning",
        nodeW: 152,
        blurb: "From deep Q-learning to real-robot RL, sim-to-real randomization, and RL fine-tuning of diffusion policies and VLAs. Boxes without an incoming arrow start a separate line.",
        cols: ["2013–17", "2018–19", "2020–21", "2023", "2024", "2025"],
        nodes: [
          { id: "dqn", label: "DQN", col: 0, row: 0, problem: "RL from raw pixels relied on hand-crafted features; deep Q-learning was thought unstable." },
          { id: "ddpg", label: "DDPG", col: 0, row: 1, problem: "DQN handles only discrete actions; discretizing robot arms explodes combinatorially." },
          { id: "ppo", label: "PPO", col: 0, row: 2, problem: "Vanilla policy gradients take destructive steps; TRPO fixes this but is complex." },
          { id: "domain-randomization", label: "Domain randomization", col: 0, row: 4, problem: "Models trained on simulated images fail on real images: the reality gap." },
          { id: "qt-opt", label: "QT-Opt", col: 1, row: 0, problem: "Open-loop grasp selection fails to generalize; actor-critics were unstable at real-world scale." },
          { id: "sac", label: "SAC", col: 1, row: 1, problem: "On-policy methods are sample-hungry; DDPG is brittle and hyperparameter-sensitive." },
          { id: "adr-solving-rubik-s-cube", label: "ADR", col: 1, row: 3, problem: "Hand-tuned randomization ranges did not scale to a Rubik's cube with a humanoid hand." },
          { id: "teacher-student-terrain", label: "Teacher–student", col: 2, row: 3, problem: "Legged controllers break on natural terrain; cameras cannot sense friction or compliance." },
          { id: "rma", label: "RMA", col: 2, row: 5, problem: "Randomization gives conservative policies; online adaptation needs risky real rollouts." },
          { id: "rlpd", label: "RLPD", col: 3, row: 1, problem: "Adding offline data to an off-policy buffer naively over-extrapolates Q-values." },
          { id: "hil-serl", label: "HIL-SERL", col: 4, row: 0, problem: "Real-world vision RL was too slow and reward-hungry for precise, dynamic, dual-arm skills." },
          { id: "serl", label: "SERL", col: 4, row: 1, problem: "Real-robot RL depends on rewards, resets and controllers; no integrated open stack existed." },
          { id: "dppo", label: "DPPO", col: 4, row: 2, problem: "Behavior-cloned diffusion policies are capped by their demos; policy gradients seemed inefficient for them." },
          { id: "conrft", label: "ConRFT", col: 5, row: 0, problem: "Fine-tuning VLAs on few demos is fragile in contact-rich tasks; raw real-world RL is unsafe." },
          { id: "recap", label: "RECAP (π*0.6)", col: 5, row: 1, problem: "Imitation caps VLAs at demo quality; policy gradients are hard for large flow VLAs." },
          { id: "openvla-oft", label: "OpenVLA-OFT", col: 5, row: 2, problem: "Autoregressive VLAs run at 3–5 Hz, too slow for 25–50 Hz control, and fine-tune poorly." },
          { id: "simplevla-rl", label: "SimpleVLA-RL", col: 5, row: 3, problem: "Scaling VLA fine-tuning needs scarce teleop data and generalizes poorly under shift." },
          { id: "asap", label: "ASAP", col: 5, row: 4, problem: "Agile humanoid skills fail on hardware from sim-to-real dynamics mismatch." }
        ],
        edges: [
          ["dqn", "ddpg", "A deterministic actor-critic for continuous actions"],
          ["dqn", "qt-opt", "Closed-loop grasping Q-learning with CEM action search"],
          ["ddpg", "sac", "A stochastic max-entropy actor replaces the deterministic one"],
          ["domain-randomization", "adr-solving-rubik-s-cube", "An automatic curriculum widens randomization ranges"],
          ["domain-randomization", "rma", "An adaptation module predicts environment latents from history"],
          ["sac", "rlpd", "Samples offline and online data symmetrically per batch"],
          ["rlpd", "serl", "Packaged with rewards, resets and control for real robots"],
          ["serl", "hil-serl", "Adds online human corrections to both buffers"],
          ["ppo", "dppo", "Policy gradient through the diffusion denoising chain"],
          ["hil-serl", "conrft", "Fine-tunes a pretrained VLA instead of training from scratch"],
          ["domain-randomization", "asap", "Learns a residual action that aligns simulator physics"],
          ["openvla-oft", "simplevla-rl", "Outcome-reward GRPO fine-tuning beyond supervised learning"]
        ]
      },

      /* ---------------------------------------------------------------- verifiers and monitors */
      {
        id: "verify", name: "Verifiers and failure monitors",
        nodeW: 152,
        blurb: "Checking actions before and while they run: grounding and calibrated planners, success detectors, test-time verifiers, and failure detectors. Boxes without an incoming arrow start a separate line.",
        cols: ["2022", "2023", "2024", "2025 · H1", "2025 · H2", "2026"],
        nodes: [
          { id: "saycan", label: "SayCan", col: 0, row: 0, problem: "LLM plans are not grounded in what the robot can do in the current scene." },
          { id: "inner-monologue", label: "Inner Monologue", col: 0, row: 1, problem: "Open-loop LLM plans assume every step succeeds and cannot replan after failures." },
          { id: "knowno", label: "KnowNo", col: 1, row: 0, problem: "LLM planners hallucinate confidently and give no guarantee on when to ask for help." },
          { id: "successvqa", label: "SuccessVQA", col: 1, row: 2, problem: "Bespoke success detectors work only in narrow conditions and need new labels each time." },
          { id: "v-gps", label: "V-GPS", col: 2, row: 1, problem: "Generalist policies fail on precision, and fine-tuning them is costly and risks generality." },
          { id: "sentinel", label: "Sentinel", col: 2, row: 2, problem: "Per-sample OOD scores conflate novelty with failure and ignore multimodal, temporal failures." },
          { id: "gvl", label: "GVL", col: 2, row: 3, problem: "Universal progress values need huge data; naive VLM prompting gives uninformative values." },
          { id: "robomonkey", label: "RoboMonkey", col: 3, row: 1, problem: "VLAs spend one forward pass per step; test-time compute scaling was unused." },
          { id: "fail-detect", label: "FAIL-Detect", col: 3, row: 2, problem: "Most failure detectors need labeled failures, which are costly, dangerous and never complete." },
          { id: "safe", label: "SAFE", col: 3, row: 3, problem: "Per-task detectors cannot follow generalist VLAs onto unseen tasks." },
          { id: "rover", label: "RoVer", col: 4, row: 0, problem: "Improving VLAs usually means scaling data and models, which is costly in robotics." },
          { id: "mg-select", label: "MG-Select", col: 4, row: 1, problem: "External verifiers need extra reward training and generalize poorly to new conditions." },
          { id: "fiper", label: "FIPER", col: 4, row: 2, problem: "Observation-only detectors fire on harmless novelty; consistency scores misfire on multimodal actions." },
          { id: "world-action-verifier", label: "World Action Verifier", col: 5, row: 1, problem: "Uncertainty and disagreement checks fail exactly where action-conditioned world models lack data." },
          { id: "foresight", label: "Foresight", col: 5, row: 3, problem: "Long-horizon failure onset is ambiguous, and detectors rely on policy-specific internals." },
          { id: "tri-info", label: "Tri-Info", col: 5, row: 4, problem: "Detectors are tied to one architecture's latents or give single, hard-to-read scores." }
        ],
        edges: [
          ["saycan", "inner-monologue", "Feeds success and scene feedback back into the prompt"],
          ["saycan", "knowno", "Conformal prediction tells the planner when to ask for help"],
          ["successvqa", "sentinel", "Temporal consistency of actions plus a VLM progress monitor"],
          ["successvqa", "gvl", "In-context VLM values over shuffled frames"],
          ["sentinel", "fail-detect", "A learned one-class score with a time-varying conformal band"],
          ["v-gps", "robomonkey", "A VLM verifier trained on synthetic preferences"],
          ["fail-detect", "safe", "A multitask probe on VLA features, zero-shot on new tasks"],
          ["robomonkey", "rover", "A 0.2B verifier that also proposes a refinement direction"],
          ["robomonkey", "mg-select", "Intrinsic model confidence replaces an external verifier"],
          ["fail-detect", "fiper", "Combines observation-side and action-side scores"],
          ["safe", "foresight", "World-model latents instead of policy-internal features"],
          ["safe", "tri-info", "Information-theoretic signals that transfer across models"]
        ]
      },

      /* ---------------------------------------------------------------- grasping */
      {
        id: "grasp", name: "Grasping",
        nodeW: 152,
        blurb: "Grasp detection: rectangles to 6-DoF poses, synthetic data, language reasoning, VLAs, and dexterous hands. Boxes without an incoming arrow start a separate line.",
        cols: ["2015–18", "2019–20", "2021–22", "2023", "2024", "2025"],
        nodes: [
          { id: "real-time-grasp-detection", label: "Redmon & Angelova", col: 0, row: 0, problem: "Sliding-window grasp detectors were slow (13.5 s per frame) and saw only local patches." },
          { id: "gg-cnn", label: "GG-CNN", col: 0, row: 1, problem: "Sample-and-rank grasp CNNs were too slow for closed loop, failing when objects moved." },
          { id: "gr-convnet", label: "GR-ConvNet", col: 1, row: 0, problem: "Pixel-wise generative grasp nets like GG-CNN were fast but shallow and limited in accuracy." },
          { id: "dex-net", label: "Dex-Net 4.0", col: 1, row: 2, problem: "A single end-effector type limits grasping of diverse object geometries (P01 §4.1)." },
          { id: "6-dof-graspnet", label: "6-DoF GraspNet", col: 1, row: 3, problem: "Hand-designed 6-DoF grasp samplers miss thin parts; single-grasp regression lacks diversity." },
          { id: "graspnet-1billion", label: "GraspNet-1Billion", col: 1, row: 4, problem: "Grasp methods used incompatible representations and metrics; datasets were small or simulated." },
          { id: "contact-graspnet", label: "Contact-GraspNet", col: 2, row: 3, problem: "Multi-stage clutter pipelines were sensitive to segmentation and ignored scene context." },
          { id: "dexgraspnet", label: "DexGraspNet", col: 2, row: 5, problem: "Dexterous grasping lacked a large dataset; force-closure synthesis was too slow to scale." },
          { id: "grasp-anything", label: "Grasp-Anything", col: 3, row: 1, problem: "Grasp datasets cover few objects, have no language, and use lab arrangements." },
          { id: "graspgpt", label: "GraspGPT", col: 3, row: 2, problem: "Task-oriented grasping relied on closed-world knowledge graphs of fixed concepts." },
          { id: "anygrasp", label: "AnyGrasp", col: 3, row: 4, problem: "Grasp detectors were slow or static-only and needed precise depth sensors." },
          { id: "rt-grasp", label: "RT-Grasp", col: 4, row: 0, problem: "Multimodal LLMs cannot output precise numbers such as grasp poses." },
          { id: "grasp-anything-lgd", label: "Grasp-Anything++", col: 4, row: 1, problem: "No dataset supports part-level language grasping among arbitrary objects." },
          { id: "dexdiffuser", label: "DexDiffuser", col: 4, row: 5, problem: "Multi-finger grasp generation searches a huge space and often needs complete object shapes." },
          { id: "vcot-grasp", label: "VCoT-Grasp", col: 5, row: 0, problem: "Text-only reasoning in grasp models fails in clutter and single-object scenes." },
          { id: "graspvla", label: "GraspVLA", col: 5, row: 3, problem: "VLAs depend on costly real teleoperation data; could synthetic action data alone transfer?", labels: { P02: "VLM+flow (6)" } },
          { id: "dex1b", label: "Dex1B", col: 5, row: 4, problem: "Each source of dexterous demos is limited: costly, slow, narrow or physically infeasible." }
        ],
        edges: [
          ["real-time-grasp-detection", "gg-cnn", "A small pixel-wise generative network enables closed-loop grasping"],
          ["gg-cnn", "gr-convnet", "Residual blocks and n-channel RGB-D input"],
          ["dex-net", "6-dof-graspnet", "A learned VAE sampler replaces hand-designed grasp sampling"],
          ["6-dof-graspnet", "contact-graspnet", "Dense grasps anchored to observed contact points, one network"],
          ["gr-convnet", "grasp-anything", "Data-centric: foundation-model-synthesized scenes at 1M-image scale"],
          ["contact-graspnet", "graspgpt", "LLM-generated descriptions replace a closed knowledge graph"],
          ["graspnet-1billion", "anygrasp", "Adds temporal grasp tracking for moving objects"],
          ["gr-convnet", "rt-grasp", "A multimodal LLM outputs grasps after a reasoning phase"],
          ["grasp-anything", "grasp-anything-lgd", "Adds language and part-level grasp instructions"],
          ["dexgraspnet", "dexdiffuser", "A conditional diffusion sampler with evaluator refinement"],
          ["rt-grasp", "vcot-grasp", "Visual reasoning (detect, crop, zoom) replaces text reasoning"],
          ["anygrasp", "graspvla", "Billion-frame synthetic grasp data trains a flow-matching VLA"],
          ["dexgraspnet", "dex1b", "Optimization seeds a generative loop, scaled to about 1B"]
        ]
      },

      /* ---------------------------------------------------------------- in-context learning (X4 §2.4, §3.1) */
      {
        id: "icl", name: "In-context learning",
        nodeW: 152,
        blurb: "Teaching a policy whose weights stay fixed at deployment: task embeddings, attention over demonstrations, sensorimotor prompts, language-model prompts, and retrieval of stored actions. Boxes without an incoming arrow start a separate line.",
        cols: ["2018", "2020", "2021", "2024 · Q1–Q3", "2024 · Q4", "2025"],
        nodes: [
          { id: "vinn", label: "VINN", col: 2, row: 0, problem: "End-to-end visual behavior cloning couples representation and behavior learning and needs many demonstrations.", labels: { X4: "Retrieve" } },
          { id: "regent", label: "REGENT", col: 4, row: 1, problem: "Generalist agents such as JAT/Gato fail on unseen environments even after fine-tuning." },
          { id: "ricl", label: "RICL", col: 5, row: 0, problem: "VLAs trained by imitation do not learn in context; improving one on a new task means fine-tuning.", labels: { X4: "Retrieve / Encode" } },
          { id: "tecn", label: "TecNets", col: 0, row: 2, problem: "Meta-imitation adapts weights per task, needs a weight copy per task, and learns poorly from video alone." },
          { id: "mosaic", label: "MOSAIC", col: 2, row: 2, problem: "One-shot imitators trained on one task's variations collapse when one model must cover several tasks.", labels: { X4: "Attend" } },
          { id: "icrt", label: "ICRT", col: 3, row: 2, problem: "Robot foundation models need new demonstrations plus fine-tuning; they cannot be prompted like language models.", labels: { X4: "Attend" } },
          { id: "instant-policy", label: "Instant Policy", col: 4, row: 2, problem: "In-context imitation lacks 3D inductive biases and an abundant source of training data.", labels: { X4: "Encode" } },
          { id: "tosil", label: "T-OSIL", col: 1, row: 3, problem: "Inferring the task from another agent's video fails with meta-learned adaptation or LSTM context encoders.", labels: { X4: "Attend" } },
          { id: "kat", label: "KAT", col: 3, row: 4, problem: "Text-pretrained transformers cannot read images or write poses, so they could not imitate from demonstrations.", labels: { X4: "Encode" } },
          { id: "roboprompt", label: "RoboPrompt", col: 4, row: 4, problem: "An LLM needs compact, text-format demonstrations to predict robot actions in context.", labels: { X4: "Parse" } }
        ],
        edges: [
          ["tecn", "mosaic", "Attention over demonstration frames replaces one pooled task embedding"],
          ["tosil", "mosaic", "One multi-task policy with a temporal contrastive loss"],
          ["mosaic", "icrt", "Next-token prediction over raw sensorimotor prompts, loss after the prompt"],
          ["icrt", "instant-policy", "Graph diffusion over point-cloud demonstrations, trained on pseudo-demonstrations"],
          ["kat", "roboprompt", "Keyframe poses written as text replace keypoint and action tokens"],
          ["regent", "ricl", "The retrieve-and-blend recipe is added to a pretrained VLA by post-training"],
          ["vinn", "ricl", "Retrieved neighbors enter a VLA's context instead of a weighted average"]
        ]
      }
    ],

    /* Story filmstrip "From tokens to flows to futures": 14 steps, each problem → change → result with its sources.
       Numbers come from the method cards (arXiv IDs given) or the surveys (section given). */
    story: [
      {
        title: "Hand-built pipelines are brittle", years: "Classical robotics",
        problem: "Explicit models of perception and dynamics need expert tuning per task and break when objects, lighting or contacts change (X2 §2.4).",
        change: "Learn the map from observations to actions from data: reinforcement learning from rewards, or behavior cloning from demonstrations (X2 §3–4).",
        result: "Behavior cloning needs no reward, resets or success detector, because demonstrations already carry the intent (X2 §4).",
        art: ART.pipeline,
        eq: { name: "Behavior cloning", ref: "X2 eq. 18", tex: "\\min_{\\theta}\\ \\class{sym-E}{\\mathbb{E}}_{(\\class{sym-o}{o_t}, \\class{sym-a}{a_t}) \\sim \\class{sym-D}{\\mathcal{D}}}\\ \\class{sym-L}{\\mathcal{L}}\\big(\\class{sym-a}{a_t}, \\class{sym-pi}{\\pi_\\theta}(\\class{sym-o}{o_t})\\big)", words: "Fit the policy to demonstrated observation-action pairs as supervised learning; no reward appears.", key: ["E", "o", "a", "D", "L", "pi"] },
        topic: "a1"
      },
      {
        title: "Behavior cloning averages the modes", years: "2022",
        problem: "Squared-error regression returns the mean action, so two good demonstrations around an obstacle average into one path through it (X2 §4, Fig. 20).",
        change: "Behavior Transformers classify the action into one of k-means bins, then add a continuous offset for that bin (arXiv 2206.11251).",
        result: "The policy commits to one mode. Without binning, Block push success fell to 0.25 of full BeT (arXiv 2206.11251 ablation).",
        art: ART.modes,
        eq: { name: "Why squared error averages", ref: "X2 §4", tex: "\\arg\\min_{\\class{sym-pi}{\\pi}}\\ \\class{sym-E}{\\mathbb{E}}\\big\\|\\class{sym-a}{a_t} - \\class{sym-pi}{\\pi}(\\class{sym-o}{o_t})\\big\\|^2 = \\class{sym-E}{\\mathbb{E}}[\\class{sym-a}{a_t} \\mid \\class{sym-o}{o_t}]", words: "The best squared-error prediction is the conditional mean, which can lie between two correct actions.", key: ["pi", "E", "a", "o"] },
        lane: "heads", node: "behavior-transformers", topic: "b1"
      },
      {
        title: "Chunking fights compounding error", years: "2023",
        problem: "Small errors push a one-step policy into states the demonstrations never showed, and the errors compound over time (X2 §4.2).",
        change: "ACT predicts a chunk of H future actions with a conditional VAE, so the policy makes H times fewer decisions (X2 §4.2).",
        result: "On real ALOHA tasks ACT reached 88% on Slide Ziploc and 96% on Slot Battery; BeT and RT-1 scored 0% (arXiv 2304.13705).",
        art: ART.chunk,
        eq: { name: "Chunked policy", ref: "arXiv 2304.13705", tex: "\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\sim \\class{sym-pi}{\\pi_\\theta}(\\cdot \\mid \\class{sym-o}{o_t}, \\class{sym-z}{z})", words: "Output the next H actions at once; the style latent z selects one consistent way of doing the task.", key: ["achunk", "pi", "o", "z"] },
        lane: "heads", node: "act", topic: "b2"
      },
      {
        title: "Diffusion captures multimodal actions", years: "2023",
        problem: "Bins and Gaussian mixtures struggle with high-dimensional, multimodal action sequences, and energy-based implicit policies train unstably (X2 §4.3).",
        change: "Diffusion Policy starts a chunk from noise and removes the noise step by step, conditioned on the observation (X2 §4.3).",
        result: "Success rose 46.9% on average over the best baseline across 15 tasks, with 95% on real Push-T (arXiv 2303.04137).",
        art: ART.diffusion,
        eq: { name: "Denoising loss", ref: "X2 §4.3", tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{k, \\class{sym-eps}{\\epsilon}}\\big\\|\\class{sym-eps}{\\epsilon} - \\class{sym-epsnet}{\\epsilon_\\theta}\\big(\\sqrt{\\class{sym-abar}{\\bar\\alpha_k}}\\,\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} + \\sqrt{1-\\class{sym-abar}{\\bar\\alpha_k}}\\,\\class{sym-eps}{\\epsilon},\\ k,\\ \\class{sym-o}{o_t}\\big)\\big\\|^2", words: "Add noise to a demonstrated chunk and train the network to predict that noise.", key: ["L", "E", "eps", "epsnet", "abar", "achunk", "o"] },
        lane: "heads", node: "diffusion-policy", topic: "b2"
      },
      {
        title: "Flow matching makes it cheaper", years: "2024",
        problem: "Diffusion Policy used 100 network evaluations per chunk in AdaFlow's comparison, too slow for fast closed-loop control (arXiv 2402.04292).",
        change: "Flow matching regresses a straight velocity from noise to action; straighter paths need fewer integration steps (X2 §4.1.3).",
        result: "AdaFlow averaged 1.17 evaluations: Square 0.98, versus Diffusion Policy 1.00 at 100 steps and 0.00 at one (arXiv 2402.04292).",
        art: ART.flow,
        eq: { name: "Flow matching", ref: "X2 eq. 49", tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{\\class{sym-tau}{\\tau}, \\class{sym-eps}{\\epsilon}}\\big\\|\\class{sym-v}{v_\\theta}\\big(\\class{sym-tau}{\\tau}\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} + (1-\\class{sym-tau}{\\tau})\\class{sym-eps}{\\epsilon},\\ \\class{sym-o}{o_t}, \\class{sym-tau}{\\tau}\\big) - (\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} - \\class{sym-eps}{\\epsilon})\\big\\|^2", words: "Regress the constant velocity of the straight line from noise to the demonstrated chunk.", key: ["L", "E", "tau", "eps", "v", "achunk", "o"] },
        lane: "heads", node: "adaflow", topic: "b2"
      },
      {
        title: "VLMs bring semantics", years: "2023",
        problem: "Controllers trained only on robot data never see most objects and concepts that instructions name.",
        change: "RT-2 co-fine-tunes a web-pretrained vision-language model (VLM) and writes each action dimension as a text token (P02 §IV-A).",
        result: "On unseen objects, backgrounds and environments RT-2 averaged 62% versus 32% for RT-1 (arXiv 2307.15818).",
        art: ART.vlm,
        eq: { name: "Actions as tokens", ref: "P02 §IV-A", tex: "\\class{sym-L}{\\mathcal{L}} = -\\sum_{d} \\log p_{\\text{VLM}}\\big(\\text{bin}_d \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}, \\text{bin}_{\\lt d}\\big)", words: "The VLM predicts the action's bins one token at a time, exactly like words.", key: ["L", { glyph: "\\(p_{\\text{VLM}}\\)", meaning: "web-pretrained vision-language model" }, "o", "l"] },
        lane: "vla", node: "rt-2", topic: "b4"
      },
      {
        title: "Scale through cross-embodiment data", years: "2023",
        problem: "Each lab's robot dataset is narrow, and it was unknown whether data from other robots transfers or interferes.",
        change: "Open X-Embodiment pooled over 1M real trajectories from 22 embodiments and trained RT-1-X and RT-2-X on a mixture (arXiv 2310.08864).",
        result: "RT-1-X averaged about 50% higher success than per-dataset models on five small-data domains (arXiv 2310.08864).",
        art: ART.embody,
        lane: "vla", node: "open-x-embodiment-rt-x", topic: "d1"
      },
      {
        title: "Continuous heads beat tokens", years: "2024–2025",
        problem: "Binned tokens are decoded one at a time: OpenVLA produced actions at 4.2 Hz, far below 25–50 Hz control (arXiv 2502.19645).",
        change: "π0 adds a flow-matching action expert; OpenVLA-OFT decodes a continuous chunk in parallel with L1 regression (X2 §5.3).",
        result: "OpenVLA-OFT averaged 97.1% on LIBERO versus 76.5% for fine-tuned OpenVLA, at 109.7 Hz throughput (arXiv 2502.19645).",
        art: ART.continuous,
        eq: { name: "π0 action expert", ref: "X2 eq. 52", tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}\\big\\|\\class{sym-v}{v_\\theta}\\big(\\class{sym-tau}{\\tau}\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} + (1-\\class{sym-tau}{\\tau})\\class{sym-eps}{\\epsilon},\\ \\class{sym-o}{o_t}\\big) - (\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} - \\class{sym-eps}{\\epsilon})\\big\\|^2", words: "A flow-matching action expert replaces tokens; about 10 Euler steps turn noise into a chunk (X2 §5.3).", key: ["L", "E", "v", "tau", "achunk", "eps", "o"] },
        lane: "vla", node: "pi0", topic: "b4"
      },
      {
        title: "Hierarchy and knowledge insulation", years: "2025",
        problem: "Action-expert gradients erode the VLM's knowledge, and one model must both reason about the task and act fast (X2 §5.3).",
        change: "π0.5 predicts a text subtask before actions; insulation stops action gradients at the VLM; GR00T N1 splits a 10 Hz VLM from 120 Hz actions.",
        result: "Insulated training scored 0.55 on DROID tasks versus 0.49 for π0 (arXiv 2505.23705); π0.5 cleaned rooms in unseen homes (arXiv 2504.16054).",
        art: ART.insulate,
        eq: { name: "π0.5 factorization", ref: "arXiv 2504.16054", tex: "\\class{sym-pi}{\\pi_\\theta}(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}}, \\hat\\ell \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}) = \\class{sym-pi}{\\pi_\\theta}(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\mid \\class{sym-o}{o_t}, \\hat\\ell)\\;\\class{sym-pi}{\\pi_\\theta}(\\hat\\ell \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})", words: "First predict a subtask in words, then actions that depend only on that subtask.", key: ["pi", "achunk", { glyph: "\\(\\hat\\ell\\)", meaning: "predicted subtask text" }, "o", "l"] },
        lane: "vla", node: "pi0-5", topic: "b4"
      },
      {
        title: "Human video through latent actions", years: "2024",
        problem: "Internet and human videos show useful behavior but carry no action labels, so action-labeled VLA pretraining cannot use them (P06).",
        change: "LAPA learns discrete latent actions from changes between frames, pretrains a VLA to predict them, then maps latents to robot actions.",
        result: "Without action labels in pretraining, LAPA reached 50.1% on real Franka tasks versus 43.9% for OpenVLA with 970k labeled trajectories (arXiv 2410.11758).",
        art: ART.latent,
        eq: { name: "Latent action", ref: "arXiv 2410.11758", tex: "\\class{sym-z}{z_t} = \\arg\\min_{c_k}\\big\\|\\big(e(\\class{sym-o}{o_{t+1}}) - e(\\class{sym-o}{o_t})\\big) - c_k\\big\\|", words: "The latent action is the codebook entry closest to how the frame embedding changed.", key: ["z", { glyph: "\\(c_k\\)", meaning: "codebook entry" }, { glyph: "\\(e\\)", meaning: "frame encoder" }, "o"] },
        lane: "latent", node: "lapa", topic: "d2"
      },
      {
        title: "Predict the future before acting", years: "2023",
        problem: "A reactive policy maps the current frame to an action and ignores what video models know about how scenes change.",
        change: "UniPi generates a video plan and reads actions off it with inverse dynamics; GR-1 predicts the next frame and action together (P04 §3.1).",
        result: "GR-1 reached 85.4% first-task success in unseen CALVIN scenes versus 53.3% for RT-1 (arXiv 2312.13139).",
        art: ART.future,
        eq: { name: "WAM objective", ref: "P04 eq. 7", tex: "\\class{sym-L}{\\mathcal{L}}_{\\text{WAM}} = \\class{sym-E}{\\mathbb{E}}\\big[-\\log \\class{sym-ptheta}{p_\\theta}(\\class{sym-op}{o'}, \\class{sym-a}{a} \\mid \\class{sym-o}{o}, \\class{sym-l}{\\ell})\\big]", words: "One model predicts the future observation and the action together, so the forecast shapes the action.", key: ["L", "E", "ptheta", "op", "a", "o", "l"] },
        lane: "wam", node: "gr-1", topic: "c2"
      },
      {
        title: "Joint video–action generation", years: "2025–2026",
        problem: "Two-stage predict-then-act pipelines share no representation, and one shared noise level fixes how a joint model can be used.",
        change: "UWM gives video and action separate diffusion timesteps; Cosmos Policy injects actions and values as latent frames of a pretrained video model.",
        result: "Cosmos Policy averaged 98.5% on LIBERO and 93.6 on four real ALOHA tasks, above 88.6 for π0.5 (arXiv 2601.16163).",
        art: ART.joint,
        eq: { name: "Unified world model", ref: "arXiv 2504.02792", tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}_{k_a, k_{o'}}\\big[w_a\\|\\epsilon^{\\theta}_a - \\epsilon_a\\|^2 + w_{o'}\\|\\epsilon^{\\theta}_{o'} - \\epsilon_{o'}\\|^2\\big]", words: "Sample the action and next-frame timesteps independently; fixing one at pure noise or clean picks policy, world model or inverse dynamics.", key: ["L", "E", { glyph: "\\(k_a, k_{o'}\\)", meaning: "action and video timesteps" }, { glyph: "\\(\\epsilon_a, \\epsilon_{o'}\\)", meaning: "action and next-frame noise" }] },
        lane: "wam", node: "uwm", topic: "c2"
      },
      {
        title: "Dream less, act more", years: "2026",
        problem: "Rendering the future inside the control loop costs latency and memory that are hard to justify at every step (P04 §3.2).",
        change: "Latent-Only models stop before pixels: Fast-WAM keeps video co-training but acts from one latent pass, never denoising future frames (P04 §3.2).",
        result: "Fast-WAM ran at 190 ms on real towel folding versus 580 ms for its joint variant, with 97.6% on LIBERO (arXiv 2603.16666).",
        art: ART.dreamless,
        eq: { name: "Act from a latent", ref: "arXiv 2603.16666", tex: "\\class{sym-ptheta}{p_\\theta}(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\mid \\class{sym-o}{o}, \\class{sym-l}{\\ell}) = \\class{sym-ptheta}{p_\\theta}\\big(\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} \\mid \\class{sym-z}{z}(\\class{sym-o}{o}, \\class{sym-l}{\\ell})\\big)", words: "Actions come from a single-pass world latent instead of an integral over imagined future videos.", key: ["ptheta", "achunk", "o", "l", "z"] },
        lane: "wam", node: "fast-wam", topic: "c2"
      },
      {
        title: "Check before acting", years: "2024–2026",
        problem: "A policy's single sample can be wrong, and the physical world offers no cheap, well-defined check of success (P14 §1).",
        change: "A verifier maps context and candidate to a score; the robot samples N candidate actions and executes the best one (P14 eq. 1, §4.2).",
        result: "RoboMonkey reached 60% on real out-of-distribution tasks versus 35% for OpenVLA (arXiv 2506.17811). P14 warns there is no free checker.",
        art: ART.verify,
        eq: { name: "Best of N", ref: "P14 §4.2", tex: "\\class{sym-a}{a_t} = \\arg\\max_{i \\le \\class{sym-N}{N}}\\ \\class{sym-score}{S}\\big(\\class{sym-o}{o_t}, \\class{sym-l}{\\ell};\\ \\tilde a^{i}\\big),\\quad \\tilde a^{i} \\sim \\class{sym-pi}{\\pi_\\theta}(\\cdot \\mid \\class{sym-o}{o_t}, \\class{sym-l}{\\ell})", words: "Sample N candidates from the policy, score each with the verifier, and execute the highest-scoring one.", key: ["a", "N", "score", "o", "l", "pi"] },
        lane: "verify", node: "robomonkey", topic: "f1"
      }
    ],

    quiz: [
      {
        q: "What did Consistency Policy change about Diffusion Policy?",
        options: ["It distilled the sampler to 1–3 network evaluations", "It replaced camera images with point clouds", "It added language instructions to the policy", "It fine-tuned the policy with reinforcement learning"],
        correct: 0,
        why: "Consistency Policy distills an EDM teacher with a consistency objective, so actions come in 1–3 network evaluations instead of about 100 DDPM steps (arXiv 2405.07503)."
      },
      {
        q: "What did π0 change about RT-2 and OpenVLA style VLAs?",
        options: ["It removed the vision-language backbone", "A flow-matching action expert replaced discrete action tokens", "It trained only in simulation", "It predicted future video frames first"],
        correct: 1,
        why: "π0 replaces autoregressive discretized action tokens with a separate flow-matching action expert that outputs 50-step continuous chunks at up to 50 Hz (arXiv 2410.24164)."
      },
      {
        q: "Fast-WAM keeps LingBot-VA's video co-training. What does it drop?",
        options: ["The pretrained video backbone", "Action chunks", "Future video denoising at test time", "The language instruction"],
        correct: 2,
        why: "Fast-WAM removes test-time future video denoising while keeping the video flow-matching co-training loss (arXiv 2603.16666), which is why P04 places it in the Latent-only family."
      }
    ]
  };
})();
