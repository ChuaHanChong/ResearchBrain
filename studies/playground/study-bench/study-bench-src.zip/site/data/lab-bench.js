/* Lab bench bar (design system v2.8): "On this bench" terms and goal-based "Tours ▾" for each station.
   Read by core/60-lab.js. Only data here; the wiring lives in the lab.

   terms: [{ t: glossary term id, w: bench part ("Scene" | "Controls" | "Readouts" | "Chart"), at: where it is,
             watch: what to watch (≤ 15 words), val?: where to read a live value (default: from `at`), when?: condition }]
     at / val: "#element-id" (a control, figure or chart on the bench) or "ro:<key>" (a readout, data-ro="<key>").
       A slider, checkbox, segmented control, select or readout gives its value automatically; val: false turns it off.
     when: "seg:<segmented id>=<value>[,<value>…]" joined by "&" — listed only while those options are pressed;
       "Show in Lab ▶" presses the first value of each unmet condition before pointing.
       Only terms whose element is visible now (and whose condition holds) are listed.
   tours: [{ id (unique within the station), title, goal, steps: [{ at, name (what "Look at" names), title,
             run?: actions for "Run it ▶", text: what to notice (≤ 25 words) }] }]  — 3–8 steps each.
     actions: ["seg", id, value] · ["set", id, number] · ["check", id, true|false] · ["click", id] · ["select", id, value] · ["wait", ms]
   A tour opens as #lab/<station>/tour-<id>; a term as #lab/<station>/term-<term id>. */
(function () {
  "use strict";
  var RB = window.RB;

  RB.LAB_BENCH = {
    /* ---------------------------------------------------------------- Policy head bench */
    heads: {
      terms: [
        { t: "multimodal-actions", w: "Scene", at: "#heads-cv", watch: "Dashed paths pass left or right of the block: two correct answers." },
        { t: "action-chunk", w: "Scene", at: "#heads-tl", val: "#heads-h", watch: "Each bar is one chunk; mixed colors mean the plan keeps switching sides." },
        { t: "behavior-cloning", w: "Controls", at: "#heads-head", when: "seg:heads-head=mse", watch: "Regression clones the demonstrations with squared error: one action per state." },
        { t: "cvae", w: "Controls", at: "#heads-head", when: "seg:heads-head=cvae", watch: "The CVAE draws a latent z, then decodes a whole chunk from it." },
        { t: "diffusion-policy-head", w: "Controls", at: "#heads-head", when: "seg:heads-head=ddpm,ddim", watch: "DDPM and DDIM remove noise in K steps; watch the denoiser panel." },
        { t: "flow-matching", w: "Controls", at: "#heads-head", when: "seg:heads-head=fm,fmb", watch: "Flow integrates a velocity field from noise to one of the two plans." },
        { t: "consistency-policy", w: "Controls", at: "#heads-head", when: "seg:heads-head=one", watch: "One network call maps noise straight to a chunk: low latency." },
        { t: "temporal-ensembling", w: "Controls", at: "#heads-exec", watch: "Ensemble averages overlapping chunks; watch side switches rise." },
        { t: "compounding-error", w: "Controls", at: "#heads-dist", watch: "Disturbance pushes rollouts off the demonstrations, where each error makes the next likelier." },
        { t: "mode-averaging", w: "Readouts", at: "ro:hit", watch: "Rollouts that aim at the mean of left and right hit the block." },
        { t: "nfe", w: "Readouts", at: "ro:nfe", watch: "Network calls per chunk: K for DDPM, DDIM and flow, one otherwise." },
        { t: "action-delay", w: "Readouts", at: "ro:lat", watch: "Estimated time to compute one chunk, set by the number of calls." },
        { t: "success-rate", w: "Chart", at: "#heads-chart", val: "ro:goal", watch: "Share of rollouts that reach the goal as chunk size H grows." }
      ],
      tours: [
        { id: "mean", title: "Why regression hits the block", goal: "See mode averaging, then how a sampling head avoids it.", steps: [
          { at: "#heads-cv", name: "the workspace", title: "Two right answers", run: [["seg", "heads-head", "mse"], ["set", "heads-k", 10], ["set", "heads-h", 8], ["seg", "heads-exec", "all"], ["click", "heads-run"]], text: "Demonstrations pass left or right. Regression learns their average, so chunks of 8 steer straight into the block." },
          { at: "ro:hit", name: "Hit the block", title: "Count the crashes", text: "Most rollouts hit the block. A squared-error head cannot hold two separate answers, so it returns the invalid middle." },
          { at: "#heads-head", name: "the policy head", title: "Sample a whole chunk", run: [["seg", "heads-head", "fm"], ["click", "heads-run"]], text: "A flow head samples a whole chunk from the two-peaked distribution. Each rollout commits to one side and reaches the goal." },
          { at: "#heads-k", name: "Steps K", title: "One step is the mean", run: [["set", "heads-k", 1], ["click", "heads-run"]], text: "With one Euler step the flow head returns the average plan. Rollouts hit the block again, like regression." },
          { at: "ro:nfe", name: "Network calls", title: "Steps cost calls", run: [["set", "heads-k", 10], ["click", "heads-run"]], text: "Ten steps bring the two sides back, but every chunk now costs ten network calls, and latency grows with them." }
        ] },
        { id: "commit", title: "Chunks and ensembling", goal: "See how chunk length and ensembling change how firmly a rollout commits.", steps: [
          { at: "#heads-tl", name: "the chunk timeline", title: "Chunks of one step", run: [["seg", "heads-head", "fm"], ["set", "heads-k", 10], ["seg", "heads-exec", "all"], ["set", "heads-h", 1], ["click", "heads-run"]], text: "With chunks of one action the head may pick a new side every step. Many short bars of mixed color show it." },
          { at: "#heads-h", name: "Chunk size H", title: "Longer chunks commit", run: [["set", "heads-h", 16], ["click", "heads-run"]], text: "Chunks of 16 hold one plan for longer. The timeline shows fewer, longer bars of one color." },
          { at: "#heads-exec", name: "Execution", title: "Average the chunks", run: [["seg", "heads-exec", "ens"], ["click", "heads-run"]], text: "Ensembling averages overlapping chunks. When they plan different sides, the average drifts toward the middle." },
          { at: "ro:sw", name: "Side switches", title: "Count the switches", text: "Compare side switches with All H. The π0 paper reports that ensembling hurt its policies." }
        ] },
        { id: "shove", title: "Recover from a shove", goal: "Watch chunk length decide how fast rollouts recover from a disturbance.", steps: [
          { at: "#heads-pre", name: "the presets", title: "Diffusion Policy settings", run: [["seg", "heads-pre", "dp"], ["check", "heads-shove", true], ["click", "heads-run"]], text: "The Diffusion Policy preset runs 8 of every 16 actions. At step 15 a shove knocks each rollout sideways." },
          { at: "#heads-cv", name: "the workspace", title: "Old plans keep running", text: "After the shove, rollouts finish the chunk they already planned, then replan from where they landed." },
          { at: "#heads-h", name: "Chunk size H", title: "Replan sooner", run: [["set", "heads-h", 4], ["click", "heads-run"]], text: "Chunks of 4 replan sooner, but each replan may pick the other side. Here fewer rollouts reach the goal." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- Action tokenizer */
    tokens: {
      terms: [
        { t: "action-chunk", w: "Scene", at: "#tokens-traj", watch: "Seven lanes: one second of a 7-D chunk; colored is what decoding returns." },
        { t: "action-tokenization", w: "Scene", at: "#tokens-tv", when: "seg:tokens-tk=bins", val: "#tokens-bins", watch: "One bin ID per dimension and step; the count grows with the rate." },
        { t: "fast-tokenization", w: "Scene", at: "#tokens-tv", when: "seg:tokens-tk=fast", watch: "Cosine coefficients per lane; smooth motion leaves mostly zeros to compress." },
        { t: "residual-vector-quantization", w: "Scene", at: "#tokens-tv", when: "seg:tokens-tk=vq", val: "#tokens-K", watch: "Each code is a stored snippet; the next code fixes what is left." },
        { t: "discrete-cosine-transform", w: "Controls", at: "#tokens-g", when: "seg:tokens-tk=fast", watch: "γ scales the coefficients before rounding: larger keeps more detail and tokens." },
        { t: "byte-pair-encoding", w: "Controls", at: "#tokens-bpe", when: "seg:tokens-tk=fast", watch: "Merging frequent pairs shortens the sequence without adding error." },
        { t: "action-binning", w: "Controls", at: "#tokens-off", when: "seg:tokens-tk=vq", watch: "A continuous offset corrects each coarse code; watch the error fall." },
        { t: "action-token", w: "Readouts", at: "ro:tok", watch: "Tokens the model must emit for this one-second chunk." },
        { t: "parallel-decoding", w: "Readouts", at: "ro:steps", watch: "One step per token when autoregressive; Parallel decodes the chunk in one pass." },
        { t: "vision-language-action-model", w: "Chart", at: "#tokens-chart", val: "ro:budget", watch: "A VLA emits these tokens: bins grow with the rate, FAST barely." }
      ],
      tours: [
        { id: "rate", title: "Bins grow with the rate", goal: "See why 256-bin tokens get expensive at high control rates.", steps: [
          { at: "#tokens-traj", name: "the chunk lanes", title: "One second, seven numbers", run: [["seg", "tokens-tk", "bins"], ["seg", "tokens-pre", "reach"], ["seg", "tokens-dec", "ar"], ["set", "tokens-hz", 15]], text: "Seven lanes hold one second of a 7-D chunk. At 15 Hz, 256 bins give 105 tokens, one per dimension and step." },
          { at: "ro:tok", name: "Tokens per chunk", title: "Raise the rate", run: [["set", "tokens-hz", 50]], text: "At 50 Hz the same second needs 350 bin tokens. The count grows with the control rate." },
          { at: "ro:budget", name: "Share of the 1 s chunk", title: "Decoding falls behind", text: "Tokens are written one after another, so decoding now takes far longer than the second of motion it produces." },
          { at: "#tokens-tk", name: "the tokenizer", title: "Compress the frequencies", run: [["seg", "tokens-tk", "fast"]], text: "FAST turns each lane into a few cosine coefficients. The token count now depends on smoothness, not the rate." }
        ] },
        { id: "fast", title: "FAST, noise and decoding", goal: "See what makes FAST sequences long or short, and what parallel decoding changes.", steps: [
          { at: "#tokens-traj", name: "the chunk lanes", title: "Coarse to fine", run: [["seg", "tokens-tk", "fast"], ["seg", "tokens-pre", "reach"], ["check", "tokens-bpe", true], ["seg", "tokens-dec", "ar"], ["click", "tokens-go"]], text: "Tokens arrive low frequency first. The decoded line starts as a rough sketch and sharpens as tokens arrive." },
          { at: "#tokens-pre", name: "the presets", title: "Noise costs tokens", run: [["seg", "tokens-pre", "noisy"]], text: "Teleoperation jitter spreads energy across frequencies. Fewer coefficients round to zero, so FAST needs more tokens." },
          { at: "#tokens-bpe", name: "BPE merge", title: "Switch off merging", run: [["check", "tokens-bpe", false]], text: "Without byte-pair merging each kept coefficient is its own token. Merging shortens the sequence and loses nothing." },
          { at: "#tokens-dec", name: "Decoding", title: "Decode in parallel", run: [["check", "tokens-bpe", true], ["seg", "tokens-dec", "par"]], text: "Parallel decoding emits the whole chunk in one pass, so decode time no longer grows with the token count." }
        ] },
        { id: "vq", title: "A learned codebook", goal: "See the fixed length and the coarse fit of vector-quantized codes.", steps: [
          { at: "#tokens-traj", name: "the chunk lanes", title: "Snippets, not numbers", run: [["seg", "tokens-tk", "vq"], ["seg", "tokens-pre", "reach"], ["seg", "tokens-K", "16"], ["check", "tokens-off", false]], text: "VQ replaces each short window with the nearest stored snippet. The length is fixed, but the fit is coarse." },
          { at: "ro:rmse", name: "Reconstruction RMSE", title: "A bigger codebook", run: [["seg", "tokens-K", "256"]], text: "With 256 codes the codebook stores more snippets, so reconstruction error falls while the length stays the same." },
          { at: "#tokens-off", name: "Offset head", title: "Add an offset", run: [["check", "tokens-off", true]], text: "A continuous offset corrects each code. Removing it caused VQ-BeT's largest ablation drop." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- VLA anatomy */
    vla: {
      terms: [
        { t: "vision-language-action-model", w: "Scene", at: "#vla-cells", val: "ro:cell", watch: "Seven design cells; the accent cell is the model on the bench." },
        { t: "blockwise-causal-attention-mask", w: "Scene", at: "#vla-mask", when: "seg:vla-mode=block,smol", watch: "Rows read earlier blocks only, so the prefix never sees noisy actions." },
        { t: "layer-skipping", w: "Scene", at: "#vla-facts", when: "seg:vla-pre=smolvla,gr00t", watch: "This model reads early backbone layers, cutting backbone compute." },
        { t: "vision-language-model", w: "Controls", at: "#vla-bb", watch: "A pretrained VLM backbone brings web knowledge; a plain Transformer starts empty." },
        { t: "action-token", w: "Controls", at: "#vla-head", when: "seg:vla-head=tok", watch: "Each action dimension is written as one bin token, one pass each." },
        { t: "diffusion-policy-head", w: "Controls", at: "#vla-head", when: "seg:vla-head=dh", watch: "A diffusion head denoises the whole chunk in K steps." },
        { t: "flow-matching", w: "Controls", at: "#vla-head", when: "seg:vla-head=fh", watch: "A flow head integrates a velocity field over K steps for the whole chunk." },
        { t: "diffusion-transformer", w: "Controls", at: "#vla-head", when: "seg:vla-head=dit", watch: "A transformer is the denoiser, conditioned on the backbone's features." },
        { t: "action-expert", w: "Controls", at: "#vla-layer", watch: "SmolVLA's expert alternates cross-attention to the VLM and self-attention among actions." },
        { t: "nfe", w: "Controls", at: "#vla-k", when: "seg:vla-head=dh,fh,dit", watch: "Each flow step reruns the action rows once more." },
        { t: "key-value-cache", w: "Controls", at: "#vla-cache", val: "ro:save", watch: "Reuse prefix keys and values; watch Cache saves." },
        { t: "action-chunk", w: "Readouts", at: "ro:tot", watch: "Attention rows computed to produce one chunk of actions." }
      ],
      tours: [
        { id: "cache", title: "Where the cache helps", goal: "See which rows a layer computes at each step and what the cache saves.", steps: [
          { at: "#vla-pre", name: "the presets", title: "π0's three blocks", run: [["seg", "vla-pre", "pi0"], ["check", "vla-cache", true], ["click", "vla-reset"]], text: "π0 splits its tokens into images and text, state, and actions. No block reads a later one." },
          { at: "#vla-mask", name: "the attention mask", title: "Step through a chunk", run: [["click", "vla-step"], ["wait", 500], ["click", "vla-step"]], text: "Step 1 computes every row. From step 2 only the action rows run; the prefix comes from the cache." },
          { at: "ro:save", name: "Cache saves", title: "Rows saved", text: "Cache saves is the share of rows reused instead of recomputed over the whole chunk." },
          { at: "#vla-mode", name: "Attention mask", title: "Break the mask", run: [["seg", "vla-mode", "full"]], text: "Without a mask the prefix reads noisy actions that change every step, so nothing can be cached and rows jump." }
        ] },
        { id: "output", title: "Tokens or a flow head", goal: "Compare writing actions as tokens with denoising them together.", steps: [
          { at: "#vla-cells", name: "the design cells", title: "One token at a time", run: [["seg", "vla-pre", "openvla"]], text: "OpenVLA writes a 7-D action as 7 tokens. Its causal mask needs one pass per token." },
          { at: "ro:tot", name: "Rows per chunk", title: "Count the rows", text: "Rows per chunk counts the attention rows computed for one chunk. Compare it after switching to π0." },
          { at: "#vla-head", name: "Action output", title: "Denoise together", run: [["seg", "vla-pre", "pi0"]], text: "π0 uses a flow head: all actions of the chunk are denoised together over K steps." },
          { at: "#vla-k", name: "Flow steps K", title: "Fewer steps", run: [["set", "vla-k", 4]], text: "Fewer flow steps mean fewer passes over the action rows, so rows per chunk fall." }
        ] },
        { id: "memory", title: "Model size and memory", goal: "See how parameters and precision set the memory a VLA needs.", steps: [
          { at: "#vla-bars", name: "the parameter bars", title: "Weights in memory", run: [["seg", "vla-pre", "pi0"], ["seg", "vla-prec", "bf16"]], text: "Weight memory is parameters times bytes per weight. At bf16, π0 needs about 6.6 GB." },
          { at: "#vla-facts", name: "the model facts", title: "A smaller model", run: [["seg", "vla-pre", "smolvla"], ["seg", "vla-prec", "bf16"]], text: "SmolVLA reads only early backbone layers and needs about 0.9 GB at bf16, roughly seven times less." },
          { at: "ro:mem", name: "Weights memory", title: "Fewer bits", run: [["seg", "vla-prec", "int4"]], text: "int4 stores each weight in half a byte, a quarter of bf16's memory." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- Control-loop budget */
    timing: {
      terms: [
        { t: "synchronous-inference", w: "Scene", at: "#timing-tl", when: "seg:timing-mode=sync", watch: "Red gaps in the robot lane: it idles while each chunk is computed." },
        { t: "asynchronous-inference", w: "Scene", at: "#timing-tl", when: "seg:timing-mode=async", watch: "Calls overlap execution, so the queue refills before it runs out." },
        { t: "real-time-chunking", w: "Scene", at: "#timing-tl", when: "seg:timing-mode=rtc", watch: "Each new chunk blends into the old one; orange rings mark jumps." },
        { t: "action-queue-threshold", w: "Controls", at: "#timing-g", watch: "A new call starts when the queue falls below g of a chunk." },
        { t: "action-chunk", w: "Controls", at: "#timing-h", watch: "Longer chunks save calls but act on older observations." },
        { t: "action-delay", w: "Controls", at: "#timing-net", watch: "Network time adds to every call's delay." },
        { t: "chunk-staleness", w: "Readouts", at: "ro:age", watch: "How old the observation behind the executed action is, on average." },
        { t: "deployment-regime", w: "Chart", at: "#timing-reg", watch: "When a model is called and over what window, and what each costs." }
      ],
      tours: [
        { id: "hide", title: "Hide the call", goal: "See how asynchronous execution keeps the robot moving while it thinks.", steps: [
          { at: "#timing-tl", name: "the timeline", title: "Four lanes, one clock", run: [["seg", "timing-pre", "vla"], ["seg", "timing-mode", "async"]], text: "Top lane: policy calls. A 73 ms call hides inside a one-second chunk, so the robot never idles." },
          { at: "#timing-mode", name: "Execution", title: "Wait for every chunk", run: [["seg", "timing-mode", "sync"]], text: "Synchronous execution empties the queue, then calls. Gaps open in the robot lane after every chunk." },
          { at: "ro:idle", name: "Robot idle", title: "Same call, more idling", text: "Robot idle rises from zero. The call takes as long as before; only the schedule changed." },
          { at: "#timing-g", name: "Threshold g", title: "Ask earlier", run: [["seg", "timing-mode", "async"], ["set", "timing-g", 0.8]], text: "A higher threshold asks for the next chunk earlier: more calls per second, fresher observations." }
        ] },
        { id: "short", title: "Chunks shorter than a call", goal: "Find where a slow model can no longer keep the robot fed.", steps: [
          { at: "#timing-pre", name: "the presets", title: "A slow world action model", run: [["seg", "timing-pre", "dz"]], text: "DreamZero needs about 150 ms per chunk of 48 actions at 30 Hz. Asynchronous execution still hides it." },
          { at: "#timing-h", name: "Chunk H", title: "Shrink the chunk", run: [["set", "timing-h", 4]], text: "At H = 4 a chunk lasts 133 ms, shorter than one call. The queue runs dry and the robot waits." },
          { at: "ro:p04", name: "the WAM survey test", title: "The test fails", text: "The survey's test compares call time per action with the control period. It now fails." }
        ] },
        { id: "push", title: "React to a push", goal: "See how old plans delay the reaction to a change, and how blending smooths switches.", steps: [
          { at: "#timing-tl", name: "the timeline", title: "The target jumps", run: [["seg", "timing-pre", "vla"], ["check", "timing-push", true], ["click", "timing-go"]], text: "At 3 s the target jumps. Chunks planned before the push keep executing for a while." },
          { at: "ro:react", name: "Reaction to the push", title: "Reaction time", text: "Reaction time is how long plans made before the push keep running. Longer chunks react later." },
          { at: "ro:jump", name: "Largest switch jump", title: "Blend at the switch", run: [["seg", "timing-pre", "rtc"], ["click", "timing-go"]], text: "RTC blends each new chunk into the old one, so the executed action jumps less when chunks switch." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- World-model planner */
    worldmodel: {
      terms: [
        { t: "world-model", w: "Scene", at: "#worldmodel-cv", watch: "Dashed: where the model says the block goes. Solid: where it went." },
        { t: "random-shooting", w: "Controls", at: "#worldmodel-pl", when: "seg:worldmodel-mode=plan&seg:worldmodel-pl=shoot", watch: "Sample sequences once, imagine each, run the best. No refinement." },
        { t: "cross-entropy-method", w: "Controls", at: "#worldmodel-pl", when: "seg:worldmodel-mode=plan&seg:worldmodel-pl=cem", watch: "Refit a Gaussian to the best few samples, then sample again." },
        { t: "model-predictive-path-integral", w: "Controls", at: "#worldmodel-pl", when: "seg:worldmodel-mode=plan&seg:worldmodel-pl=mppi", watch: "Average all samples, weighted by how low their imagined cost is." },
        { t: "candidate-reranking", w: "Controls", at: "#worldmodel-pl", when: "seg:worldmodel-mode=plan&seg:worldmodel-pl=rerank", watch: "A policy proposes chunks; the model picks the best one." },
        { t: "monte-carlo-tree-search", w: "Controls", at: "#worldmodel-pl", when: "seg:worldmodel-mode=plan&seg:worldmodel-pl=mcts", watch: "A tree of pushes, grown where imagined outcomes look best." },
        { t: "model-predictive-control", w: "Controls", at: "#worldmodel-ex", when: "seg:worldmodel-mode=plan", watch: "Every step replans from the real state; Whole plan runs open loop." },
        { t: "forward-model", w: "Controls", at: "#worldmodel-b", watch: "How wrong the model is about the veer of fast pushes." },
        { t: "co-evolution", w: "Controls", at: "#worldmodel-co", when: "seg:worldmodel-mode=imagine", watch: "Refit the model on real rollouts so it stays right where the policy goes." },
        { t: "latent-imagination", w: "Readouts", at: "ro:imc", when: "seg:worldmodel-mode=imagine", watch: "The cost the policy sees in imagination; it trains on this." },
        { t: "model-exploitation", w: "Readouts", at: "ro:gapi", when: "seg:worldmodel-mode=imagine", watch: "Real minus imagined cost; growth means the policy exploits model error." },
        { t: "rollout-error-accumulation", w: "Chart", at: "#worldmodel-chA", when: "seg:worldmodel-mode=plan", val: "ro:gap", watch: "The imagined–real gap grows with steps ahead in the plan." }
      ],
      tours: [
        { id: "plan", title: "Plan with a model", goal: "See how model error and replanning decide where the block ends up.", steps: [
          { at: "#worldmodel-cv", name: "the table", title: "Plan with CEM", run: [["seg", "worldmodel-mode", "plan"], ["seg", "worldmodel-pre", "planet"], ["click", "worldmodel-run"]], text: "The planner imagines candidate pushes with the model, runs the best first push, then replans. Dashed plan and real path stay close." },
          { at: "#worldmodel-b", name: "Model error", title: "Make the model wrong", run: [["set", "worldmodel-b", 1], ["click", "worldmodel-run"]], text: "The model now misses how fast pushes veer. Replanning after every step still corrects it, so the block ends near the goal." },
          { at: "#worldmodel-chA", name: "the gap chart", title: "Run the whole plan", run: [["seg", "worldmodel-ex", "H"], ["click", "worldmodel-run"]], text: "Without replanning, each step's error carries into the next. The gap grows with steps ahead." },
          { at: "ro:gap", name: "Plan: imagined vs real", title: "Replan every step", run: [["seg", "worldmodel-ex", "1"], ["click", "worldmodel-run"]], text: "Replanning after every step feeds the real state back. The imagined–real gap shrinks again." }
        ] },
        { id: "planners", title: "Compare planners", goal: "See what each sampling planner does with the same model and budget.", steps: [
          { at: "#worldmodel-pl", name: "Planner", title: "Random shooting", run: [["seg", "worldmodel-mode", "plan"], ["seg", "worldmodel-ex", "1"], ["seg", "worldmodel-pl", "shoot"], ["click", "worldmodel-run"]], text: "Random shooting samples sequences once and keeps the best. It never refines where it samples." },
          { at: "#worldmodel-pl", name: "Planner", title: "Refine the samples", run: [["seg", "worldmodel-pl", "cem"], ["click", "worldmodel-run"]], text: "CEM refits its Gaussian to the best few samples and resamples, spending the same budget where plans look good." },
          { at: "#worldmodel-pl", name: "Planner", title: "Let a policy propose", run: [["seg", "worldmodel-pl", "rerank"], ["click", "worldmodel-run"]], text: "Rerank lets a policy propose chunks and the model only choose among them. The result depends on the proposals." },
          { at: "ro:calls", name: "Imagined steps", title: "The compute bill", text: "Imagined steps per decision is the planner's model budget. It is about equal here, so the outcomes compare fairly." }
        ] },
        { id: "imagine", title: "Train in imagination", goal: "Watch a policy exploit its world model, then fix it with real data.", steps: [
          { at: "#worldmodel-mode", name: "Mode", title: "Train inside the model", run: [["seg", "worldmodel-mode", "imagine"], ["check", "worldmodel-co", false], ["click", "worldmodel-run"]], text: "A policy trains on imagined pushes only. Imagined cost keeps falling while real cost stops improving." },
          { at: "ro:gapi", name: "Real − imagined", title: "The optimizer cheats", text: "Real minus imagined cost grows: the policy found pushes the model predicts wrongly." },
          { at: "#worldmodel-co", name: "Refit the model", title: "Refit on real rollouts", run: [["check", "worldmodel-co", true], ["click", "worldmodel-run"]], text: "Refitting on real rollouts teaches the model how fast pushes veer. Imagined and real cost now fall together." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- World action models */
    wam: {
      terms: [
        { t: "world-action-model", w: "Scene", at: "#wam-table", watch: "One table of pushes and landings; every query reads it differently." },
        { t: "world-model", w: "Scene", at: "#wam-world", watch: "Rays: how likely each push is. Edge bars: where pushes land." },
        { t: "multimodal-actions", w: "Readouts", at: "ro:q-pk", when: "seg:wam-mode=query", watch: "Two peaks: two separate answers are both likely, like either bin." },
        { t: "policy", w: "Controls", at: "#wam-q", when: "seg:wam-mode=query&seg:wam-q=policy", watch: "The policy sums the table over landings to get push probabilities." },
        { t: "forward-model", w: "Controls", at: "#wam-q", when: "seg:wam-mode=query&seg:wam-q=forward", watch: "Fix one push and read its column: where it lands." },
        { t: "inverse-dynamics-model", w: "Controls", at: "#wam-q", when: "seg:wam-mode=query&seg:wam-q=idm", watch: "Fix a landing and read which pushes reach it." },
        { t: "cascaded-wam", w: "Controls", at: "#wam-kind", when: "seg:wam-mode=couple&seg:wam-kind=cascade", watch: "Imagine a landing first, then decode the push with inverse dynamics." },
        { t: "action-conditioned-rollout", w: "Controls", at: "#wam-kind", when: "seg:wam-mode=couple&seg:wam-kind=score", watch: "Propose N pushes, predict each landing, run the best-scored one." },
        { t: "joint-wam", w: "Controls", at: "#wam-kind", when: "seg:wam-mode=couple&seg:wam-kind=joint", watch: "One model samples push and landing together." },
        { t: "video-co-training", w: "Controls", at: "#wam-lab", when: "seg:wam-mode=couple", watch: "Share of data with action labels; video trains without them." },
        { t: "per-modality-noise-levels", w: "Controls", at: "#wam-train", when: "seg:wam-mode=uwm", watch: "Independent τ lets action and future each be noise or clean." },
        { t: "future-leakage", w: "Controls", at: "#wam-leak", when: "seg:wam-mode=leak", val: "ro:l-succ", watch: "Action reads future tokens: training fit rises, deployed success falls." },
        { t: "idm-turing-test", w: "Chart", at: "#wam-bars", when: "seg:wam-mode=idm", val: "ro:i-succ", watch: "Execute the push an IDM reads from each video; looking real is not enough." }
      ],
      tours: [
        { id: "queries", title: "One table, four queries", goal: "See policy, forward model and inverse dynamics as readings of one joint table.", steps: [
          { at: "#wam-table", name: "the joint table", title: "Sum over landings", run: [["seg", "wam-mode", "query"], ["check", "wam-peg", false], ["seg", "wam-q", "policy"]], text: "The table holds the probability of each push and landing. The policy sums it over landings." },
          { at: "#wam-q", name: "Query", title: "Fix the push", run: [["seg", "wam-q", "forward"]], text: "The forward model fixes one push and reads that column of the same table: where the push lands." },
          { at: "ro:q-pk", name: "Peaks", title: "A peg splits the future", run: [["check", "wam-peg", true]], text: "With a peg in the middle, the straight push lands left or right. The forward model now shows two peaks." },
          { at: "#wam-table", name: "the joint table", title: "Fix the landing", run: [["seg", "wam-q", "idm"]], text: "Inverse dynamics fixes a landing and reads which pushes reach it." }
        ] },
        { id: "couple", title: "Couplings and scarce labels", goal: "See how a cascade uses video that has no action labels.", steps: [
          { at: "#wam-kind", name: "Coupling", title: "Imagine, then decode", run: [["seg", "wam-mode", "couple"], ["check", "wam-peg", false], ["seg", "wam-kind", "cascade"], ["set", "wam-lab", 0.3], ["click", "wam-run"]], text: "A cascade imagines a landing first, then an inverse dynamics model decodes the push that reaches it." },
          { at: "#wam-cchart", name: "the coupling chart", title: "Scarce action labels", run: [["set", "wam-lab", 0.1], ["click", "wam-run"]], text: "With 10% action labels the policy line drops most in the chart. The cascade barely moves: its video model needs no labels." },
          { at: "ro:c-fut", name: "Predicted futures", title: "Scoring costs futures", run: [["seg", "wam-kind", "score"], ["set", "wam-n", 16], ["click", "wam-run"]], text: "Scoring N candidate pushes needs N predicted futures for every action taken." }
        ] },
        { id: "leak", title: "Leaks and looks", goal: "See two ways a world action model can look good and still fail.", steps: [
          { at: "ro:l-fit", name: "Training fit", title: "Leak the future", run: [["seg", "wam-mode", "leak"], ["check", "wam-leak", true], ["set", "wam-tr", 1], ["click", "wam-run"]], text: "Action tokens that attend to future tokens copy the answer. Training fit looks excellent." },
          { at: "ro:l-succ", name: "Deployed success", title: "Act early", run: [["set", "wam-tr", 0.2], ["click", "wam-run"]], text: "At deployment the action is read while the future is still noise. Deployed success falls." },
          { at: "#wam-bars", name: "the IDM test bars", title: "Looks real, fails", run: [["seg", "wam-mode", "idm"], ["seg", "wam-pre", "sharp"]], text: "A sharp but unphysical generator looks real, yet the pushes read from its videos often miss." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- Grasp bench */
    grasp: {
      terms: [
        { t: "grasp-rectangle", w: "Scene", at: "#grasp-top", when: "seg:grasp-grip=jaw", val: "#grasp-th", watch: "Centre, angle θ, opening w and jaw size h: the whole label." },
        { t: "suction-grasp", w: "Scene", at: "#grasp-top", when: "seg:grasp-grip=suction", watch: "The cup must seal on a flat face; open tops fail." },
        { t: "approach-direction", w: "Scene", at: "#grasp-side", val: "#grasp-tilt", watch: "The accent line is the approach path; it must miss the shelf." },
        { t: "sample-and-rank", w: "Controls", at: "#grasp-mode", when: "seg:grasp-mode=sample", val: "ro:evals", watch: "Draw N grasps, check each, execute the best." },
        { t: "grasp-quality-map", w: "Controls", at: "#grasp-mode", when: "seg:grasp-mode=map", val: "ro:evals", watch: "Every position scored at once; the best grasp is the brightest." },
        { t: "language-driven-grasping", w: "Controls", at: "#grasp-ins", val: "ro:hit", watch: "The instruction names a part; grasps on it rank first." },
        { t: "friction-cone", w: "Controls", at: "#grasp-mu", watch: "Higher μ widens the green cones: half-angle arctan μ." },
        { t: "antipodal-grasp", w: "Readouts", at: "ro:ang", watch: "Largest contact angle; the grasp holds while both stay inside their cones." },
        { t: "analytic-grasp-label", w: "Readouts", at: "ro:s", watch: "A quality from geometry and friction, not from robot trials." }
      ],
      tours: [
        { id: "friction", title: "Friction and robustness", goal: "See when a two-finger grasp holds, and how much slack it has.", steps: [
          { at: "#grasp-top", name: "the top view", title: "A grasp that holds", run: [["seg", "grasp-mode", "hand"], ["seg", "grasp-grip", "jaw"], ["seg", "grasp-scene", "clutter"], ["set", "grasp-mu", 0.5], ["set", "grasp-sig", 2], ["set", "grasp-th", 0], ["click", "grasp-exec"]], text: "Green wedges are friction cones. Both contacts push inside them, so the grasp on the mug holds." },
          { at: "ro:need", name: "Friction needed", title: "Friction needed", text: "Friction needed is the tangent of the largest contact angle. The grasp holds while μ is at least this." },
          { at: "ro:rob", name: "Succeeds under error", title: "Narrow the cones", run: [["set", "grasp-mu", 0.1], ["click", "grasp-exec"]], text: "At μ = 0.1 the cones are narrow. The grasp still holds, but far fewer grasps survive execution error." },
          { at: "#grasp-sig", name: "Execution error σ", title: "Sloppier execution", run: [["set", "grasp-mu", 0.5], ["set", "grasp-sig", 6], ["click", "grasp-exec"]], text: "With 6 mm of execution error, contacts land off their ideal spots, so fewer perturbed grasps hold." }
        ] },
        { id: "rank", title: "Sample, rank and ask", goal: "Let the station search for grasps, then steer it with an instruction.", steps: [
          { at: "#grasp-rank", name: "the ranking", title: "Sample and rank", run: [["seg", "grasp-scene", "clutter"], ["seg", "grasp-grip", "jaw"], ["seg", "grasp-ins", "any"], ["seg", "grasp-mode", "sample"]], text: "The station draws N random grasps, checks each one, and keeps the best." },
          { at: "#grasp-chart", name: "the samples chart", title: "More samples", run: [["set", "grasp-n", 200]], text: "More samples make a good grasp likelier to be among them, but each doubling helps less." },
          { at: "#grasp-ins", name: "Instruction", title: "Name the part", run: [["seg", "grasp-ins", "knife"]], text: "The instruction names the knife. Grasps on its handle rank first when one holds; Instruction met says whether it worked." },
          { at: "#grasp-top", name: "the top view", title: "Score every pixel", run: [["seg", "grasp-ins", "any"], ["seg", "grasp-mode", "map"]], text: "A quality map scores every position at once. The best grasp is simply the brightest spot." }
        ] },
        { id: "shelf", title: "Suction and approach", goal: "See two limits beyond friction: sealing a cup and reaching the grasp.", steps: [
          { at: "#grasp-grip", name: "Gripper", title: "Switch to suction", run: [["seg", "grasp-scene", "clutter"], ["seg", "grasp-mode", "hand"], ["seg", "grasp-grip", "suction"], ["click", "grasp-exec"]], text: "Suction needs a sealed flat face, not friction. On the mug's open top it fails where jaws worked." },
          { at: "#grasp-side", name: "the side view", title: "Under a shelf", run: [["seg", "grasp-grip", "jaw"], ["seg", "grasp-scene", "shelf"], ["set", "grasp-tilt", 0], ["click", "grasp-exec"]], text: "Under a shelf, the straight top-down path to the object runs into the shelf." },
          { at: "#grasp-tilt", name: "Approach tilt φ", title: "Come in from the front", run: [["set", "grasp-tilt", -45], ["click", "grasp-exec"]], text: "Tilt the approach 45° so the gripper comes in from the front, below the shelf. Now the grasp holds." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- Contact and compliance */
    compliance: {
      terms: [
        { t: "tf-art", w: "Scene", at: "#compliance-tl", when: "seg:compliance-bench=arm", watch: "Read down: contact gate, policy plan, refiner, control law, force." },
        { t: "pd-control", w: "Controls", at: "#compliance-ctrl", when: "seg:compliance-bench=arm&seg:compliance-ctrl=pd", watch: "Follows the planned path literally; the bump spikes the force." },
        { t: "impedance-control", w: "Controls", at: "#compliance-ctrl", when: "seg:compliance-bench=arm&seg:compliance-ctrl=imp", watch: "A spring between target and tool; the bump adds a few newtons." },
        { t: "admittance-control", w: "Controls", at: "#compliance-ctrl", when: "seg:compliance-bench=arm&seg:compliance-ctrl=adm", watch: "Measured force becomes a motion correction for the position loop." },
        { t: "hybrid-force-position-control", w: "Controls", at: "#compliance-ctrl", when: "seg:compliance-bench=arm&seg:compliance-ctrl=hyb", watch: "Force along z, position along x; holds F_ref over the bump." },
        { t: "variable-impedance", w: "Controls", at: "#compliance-ctrl", when: "seg:compliance-bench=arm&seg:compliance-ctrl=acp", watch: "The policy resets stiffness and target every 100 ms." },
        { t: "selection-matrix", w: "Controls", at: "#compliance-srow", when: "seg:compliance-bench=arm&seg:compliance-ctrl=hyb", watch: "Tick an axis to regulate force there; the rest keeps position." },
        { t: "slow-fast-policy", w: "Controls", at: "#compliance-ref", when: "seg:compliance-bench=arm", watch: "A fast refiner corrects the slow plan from the latest force." },
        { t: "reference-force", w: "Controls", at: "#compliance-fref", when: "seg:compliance-bench=arm", watch: "The force the policy asks for; the band is centered on it." },
        { t: "control-stiffness", w: "Controls", at: "#compliance-kz", when: "seg:compliance-bench=arm", watch: "Low stiffness yields over the bump; high stiffness presses hard." },
        { t: "wrench", w: "Chart", at: "#compliance-chart", when: "seg:compliance-bench=arm", val: "ro:peak", watch: "Normal force over the stroke against the reference band." },
        { t: "whole-body-control", w: "Scene", at: "#compliance-hum", when: "seg:compliance-bench=wbc", watch: "The hand pushes, the table pushes back, the feet must keep balance." },
        { t: "hierarchical-qp", w: "Controls", at: "#compliance-solver", when: "seg:compliance-bench=wbc&seg:compliance-solver=hqp", watch: "Lower tasks are solved only where higher ones leave room." },
        { t: "weighted-qp", w: "Controls", at: "#compliance-solver", when: "seg:compliance-bench=wbc&seg:compliance-solver=wqp", watch: "One cost trades balance and force by weight, not strict priority." },
        { t: "wrench", w: "Readouts", at: "ro:wF", when: "seg:compliance-bench=wbc", watch: "Hand force delivered versus asked for." }
      ],
      tours: [
        { id: "soft", title: "Stiff or soft", goal: "See why a planned path needs compliance when the surface is not as planned.", steps: [
          { at: "#compliance-cv", name: "the stroke", title: "Stiff position control", run: [["seg", "compliance-bench", "arm"], ["set", "compliance-off", 0], ["set", "compliance-bump", 10], ["seg", "compliance-ctrl", "pd"], ["click", "compliance-go"]], text: "PD position control follows the planned flat path literally. Over the hidden bump the force shoots up." },
          { at: "ro:peak", name: "Peak force", title: "Read the peak", text: "Peak force is far above the reference: the stiff controller pushes the tool into the bump." },
          { at: "#compliance-ctrl", name: "Controller", title: "Make the tool a spring", run: [["seg", "compliance-ctrl", "imp"], ["click", "compliance-go"]], text: "Impedance control puts a spring between target and tool. The bump now adds only a few newtons." },
          { at: "ro:sensor", name: "Needs a force sensor", title: "No sensor needed", text: "Impedance uses position error only, so it needs no force sensor to stay gentle." }
        ] },
        { id: "force", title: "Regulate force", goal: "See hybrid control hold a force, and learned stiffness absorb a planning error.", steps: [
          { at: "#compliance-srow", name: "the selection matrix", title: "Force along z", run: [["seg", "compliance-bench", "arm"], ["set", "compliance-off", 0], ["seg", "compliance-ctrl", "hyb"], ["click", "compliance-go"]], text: "Hybrid control regulates force along z and position along x. The selection matrix picks the axes." },
          { at: "#compliance-tl", name: "the timeline", title: "The gate switches", text: "Read the timeline: z switches from position to force control only when the contact gate opens." },
          { at: "#compliance-chart", name: "the force chart", title: "Ask for more force", run: [["set", "compliance-fref", 20], ["click", "compliance-go"]], text: "Raise the reference force: the measured force follows the new target across the bump." },
          { at: "#compliance-ctrl", name: "Controller", title: "The surface is higher", run: [["set", "compliance-fref", 10], ["set", "compliance-off", 10], ["seg", "compliance-ctrl", "acp"], ["click", "compliance-go"]], text: "The whole surface sits 10 mm higher than planned. Learned stiffness resets its target every 100 ms and adapts." }
        ] },
        { id: "body", title: "Balance a whole body", goal: "See how a humanoid trades hand force against balance.", steps: [
          { at: "#compliance-hum", name: "the humanoid", title: "Push on a table", run: [["seg", "compliance-bench", "wbc"], ["seg", "compliance-solver", "hqp"], ["seg", "compliance-order", "bal"], ["set", "compliance-hf", 60]], text: "A humanoid pressing on a table must also stay balanced. The table pushes back on the hand." },
          { at: "ro:wF", name: "Hand force", title: "Ask for more", run: [["set", "compliance-hf", 120]], text: "Ask for 120 N. With balance first, the body leans further but delivers less than asked: more would tip it." },
          { at: "ro:wbal", name: "Balance", title: "Force first", run: [["seg", "compliance-order", "force"]], text: "Put force above balance. The hand now gets the full 120 N, and the robot tips over." },
          { at: "#compliance-solver", name: "Solver", title: "Weigh instead of rank", run: [["seg", "compliance-order", "bal"], ["seg", "compliance-solver", "wqp"]], text: "A weighted QP trades both tasks in one cost, so neither is guaranteed. Balance ends up at the edge." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- Sim-to-real */
    sim2real: {
      terms: [
        { t: "sim-to-real-gap", w: "Scene", at: "#sim2real-cv", when: "seg:sim2real-mode=dr", val: "ro:r3", watch: "Same policy: top in training simulators, bottom on the real robot." },
        { t: "policy", w: "Scene", at: "#sim2real-cv2", watch: "Each cell is one controller; the ring marks the one training chose." },
        { t: "success-rate", w: "Readouts", at: "ro:r1", when: "seg:sim2real-mode=dr", watch: "Share of episodes that stay upright for 5 s in training simulators." },
        { t: "domain-randomization", w: "Controls", at: "#sim2real-w", when: "seg:sim2real-mode=dr", watch: "Train over simulators varied by this much around nominal." },
        { t: "action-delay", w: "Controls", at: "#sim2real-dr", when: "seg:sim2real-mode=delay", watch: "The real robot applies each command this late." },
        { t: "domain-randomization", w: "Controls", at: "#sim2real-dtr", when: "seg:sim2real-mode=delay", watch: "Delays drawn up to this value during training." },
        { t: "grounded-action-transformation", w: "Controls", at: "#sim2real-n", when: "seg:sim2real-mode=gat", watch: "Real transitions used to ground the simulator's actions." },
        { t: "adaptation-module", w: "Controls", at: "#sim2real-k", when: "seg:sim2real-mode=ts", watch: "History the student uses: short is noisy, long lags a change." },
        { t: "privileged-information", w: "Readouts", at: "ro:r2", when: "seg:sim2real-mode=ts", watch: "The teacher reads the true motor strength, which real sensors hide." },
        { t: "teacher-student-distillation", w: "Readouts", at: "ro:r3", when: "seg:sim2real-mode=ts", watch: "The student imitates the teacher from its history alone." }
      ],
      tours: [
        { id: "dr", title: "Randomize the simulator", goal: "See how training over many simulators helps a controller survive the real robot.", steps: [
          { at: "#sim2real-cv", name: "the two worlds", title: "One simulator only", run: [["seg", "sim2real-mode", "dr"], ["seg", "sim2real-real", "weak"], ["seg", "sim2real-view", "train"], ["set", "sim2real-w", 0]], text: "Tuned on the nominal simulator only, the controller balances there but falls on the weaker real motor." },
          { at: "ro:r3", name: "Gap G(π)", title: "The gap", text: "The sim-to-real gap is success in the training simulators minus success on the real robot." },
          { at: "#sim2real-w", name: "Randomization width", title: "Randomize widely", run: [["set", "sim2real-w", 100]], text: "Training over simulators varied by ±100% favors robust controllers, and success on the real robot rises." },
          { at: "#sim2real-cv2", name: "the landscape", title: "Where the real optimum is", run: [["seg", "sim2real-view", "real"]], text: "On the real robot's landscape the chosen ring now sits near the diamond, the real optimum." }
        ] },
        { id: "delay", title: "Late commands", goal: "See how command delay breaks a controller and how training fixes it.", steps: [
          { at: "#sim2real-cv", name: "the two worlds", title: "Commands arrive late", run: [["seg", "sim2real-mode", "delay"], ["set", "sim2real-dr", 100], ["set", "sim2real-dtr", 0], ["check", "sim2real-hist", false]], text: "The real robot applies each command 100 ms late. A controller tuned without delay overcorrects and oscillates." },
          { at: "#sim2real-dtr", name: "Train delay", title: "Randomize the delay", run: [["set", "sim2real-dtr", 160]], text: "Training with delays drawn up to 160 ms makes the search choose calmer gains." },
          { at: "#sim2real-hist", name: "Feed the last action back", title: "Remember the last action", run: [["check", "sim2real-hist", true]], text: "Feeding the last command back tells the controller what is still in flight. The search now also picks a weight c for it." }
        ] },
        { id: "ground", title: "Ground or distill", goal: "Compare fixing the simulator with estimating the hidden change on the robot.", steps: [
          { at: "ro:r2", name: "ψ real, grounded policy", title: "Ground the simulator", run: [["seg", "sim2real-mode", "gat"], ["set", "sim2real-n", 5]], text: "GAT fits the real dynamics from logged transitions and transforms simulated actions. The grounded policy balances on the robot." },
          { at: "#sim2real-n", name: "Real transitions", title: "Fewer transitions", run: [["set", "sim2real-n", 1]], text: "With fewer real transitions the grounding model fits worse. Compare the grounded model error." },
          { at: "#sim2real-cv", name: "the two worlds", title: "A hidden change", run: [["seg", "sim2real-mode", "ts"], ["set", "sim2real-k", 20], ["click", "sim2real-go"]], text: "The motor weakens at 2 s. The student estimates the change from its recent history." },
          { at: "ro:r4", name: "|ẑ − z| before change", title: "A one-step history", run: [["set", "sim2real-k", 1], ["click", "sim2real-go"]], text: "With one step of history the estimate becomes noisy, and the student's actions stray from the teacher's." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- Physics priors */
    physics: {
      terms: [
        { t: "physics-embedded-learning", w: "Scene", at: "#physics-pend", when: "seg:physics-bench=models", watch: "Same data, three models; structure decides who follows the dashed ghost." },
        { t: "hamiltonian-neural-network", w: "Scene", at: "#physics-phase", when: "seg:physics-bench=models", watch: "Orbits outside the shaded box show which models extrapolate." },
        { t: "deep-lagrangian-network", w: "Chart", at: "#physics-tab", when: "seg:physics-bench=models", watch: "Compare DeLaN's fit and energy change with the black box." },
        { t: "energy-drift", w: "Chart", at: "#physics-c1", watch: "Energy over time: a line that climbs or sinks is drift." },
        { t: "symplectic-integrator", w: "Controls", at: "#physics-int", watch: "Symplectic steps keep energy error bounded; Euler adds energy each step." },
        { t: "port-hamiltonian-model", w: "Controls", at: "#physics-diss", when: "seg:physics-bench=models", watch: "One learned damping term: models may lose energy, never create it." }
      ],
      tours: [
        { id: "extrap", title: "Leave the data", goal: "See why energy structure helps a learned model outside its data.", steps: [
          { at: "#physics-pend", name: "the pendulums", title: "Inside the data", run: [["seg", "physics-bench", "models"], ["seg", "physics-pre", "inside"]], text: "Released inside the data, all three learned models follow the real pendulum." },
          { at: "#physics-phase", name: "the phase plot", title: "Release beyond the data", run: [["seg", "physics-pre", "extrap"]], text: "Released at 2.8 rad, the swing goes faster than any training sample and leaves the shaded box." },
          { at: "#physics-pend", name: "the pendulums", title: "Play the swing", run: [["click", "physics-go"], ["wait", 1500]], text: "DeLaN and HNN stay with the ghost: mechanics fixes how motion depends on speed. The black box only guesses." },
          { at: "#physics-tab", name: "the model table", title: "Read the table", text: "Compare fit error and energy change. A good fit inside the data says little about outside it." }
        ] },
        { id: "friction", title: "Friction and damping", goal: "See conservation become a wrong bias, and one term that fixes it.", steps: [
          { at: "#physics-c1", name: "the energy chart", title: "No friction", run: [["seg", "physics-bench", "models"], ["seg", "physics-pre", "inside"], ["check", "physics-diss", false]], text: "Without friction, energy should stay constant, and the structured models keep it constant." },
          { at: "#physics-pre", name: "the presets", title: "Add friction", run: [["seg", "physics-pre", "friction"]], text: "Now the real pendulum loses energy. Energy-conserving models cannot follow it; the black box fits friction inside the data." },
          { at: "#physics-diss", name: "Learn a damping term", title: "Learn one damping term", run: [["check", "physics-diss", true]], text: "One learned coefficient lets DeLaN and HNN lose energy but never create it: the port-Hamiltonian idea." }
        ] },
        { id: "ints", title: "The integrator matters", goal: "Compare how four integrators keep or lose a pendulum's energy.", steps: [
          { at: "#physics-phase", name: "the phase plot", title: "Four integrators", run: [["seg", "physics-bench", "ints"]], text: "No learning here: the true pendulum stepped four ways. Explicit Euler spirals outward; symplectic methods keep a closed orbit." },
          { at: "#physics-c1", name: "the energy chart", title: "Energy over time", text: "Euler's energy climbs every step. Symplectic energy wobbles but stays bounded over long horizons." },
          { at: "#physics-dt", name: "Step Δt", title: "Shrink the step", run: [["set", "physics-dt", 0.02]], text: "Smaller steps shrink every error, but Euler still drifts steadily." },
          { at: "#physics-int", name: "Integrator", title: "Pick one", run: [["seg", "physics-int", "symp"]], text: "The chosen integrator also steps the learned models on the other bench. Try Euler there with HNN." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- Data recipe mixer */
    data: {
      terms: [
        { t: "data-recipe", w: "Scene", at: "#data-cv", val: "#data-rec", watch: "Where the budget goes and which capabilities fill up on the radar." },
        { t: "robot-alignment", w: "Controls", at: "#data-s0", watch: "Real-robot hours: the most aligned layer, and the costliest per hour." },
        { t: "umi-style-data", w: "Controls", at: "#data-s1", watch: "Handheld-gripper demonstrations: cheaper, still close to robot actions." },
        { t: "egocentric-data", w: "Controls", at: "#data-s2", watch: "People's first-person video: real physics, human hands, no robot." },
        { t: "scalability", w: "Controls", at: "#data-s4", watch: "General web data: cheapest per hour, least robot-aligned." },
        { t: "co-training", w: "Readouts", at: "ro:layers", watch: "How many sources are mixed into one training run." },
        { t: "data-pyramid", w: "Chart", at: "#data-tab", watch: "Which of the five layers each published recipe draws on." },
        { t: "compute-matched-ablation", w: "Chart", at: "#data-chart", when: "seg:data-ch=sweep", watch: "Change one layer at a fixed budget; any difference comes from that data." }
      ],
      tours: [
        { id: "web", title: "Add web data", goal: "Compare a robot-only recipe with one that adds web data.", steps: [
          { at: "#data-cv", name: "the pyramid and radar", title: "One budget, one layer", run: [["select", "data-rec", "pi0"], ["seg", "data-tgt", "seen"]], text: "π0 spends the budget on real-robot data: strong action and grounding, weaker perception and reasoning." },
          { at: "#data-rec", name: "Published recipe", title: "Add web data", run: [["select", "data-rec", "pi05"]], text: "π0.5 moves part of the budget to web data. Perception and reasoning grow; action barely drops." },
          { at: "#data-tab", name: "the recipe table", title: "Compare recipes", text: "The table lists which pyramid layers each published recipe uses. Proportions are rarely published." }
        ] },
        { id: "search", title: "Search the toy optimum", goal: "See how the best toy mix depends on the target and the budget.", steps: [
          { at: "#data-tgt", name: "Deployment target", title: "Change the target", run: [["select", "data-rec", "pi05"], ["seg", "data-tgt", "unseen"]], text: "Unseen objects weight perception and scene coverage more, so the same recipe scores differently." },
          { at: "#data-cv", name: "the radar", title: "Search every split", run: [["click", "data-go"], ["wait", 2500]], text: "The search tries every split in 5% steps. The dashed shape is the best toy recipe for this target." },
          { at: "#data-chart", name: "the chart", title: "Budget moves the optimum", run: [["seg", "data-ch", "budget"]], text: "Small budgets go mostly to real-robot data. As the budget grows, cheaper layers take a larger share." },
          { at: "ro:best", name: "Best toy score", title: "A toy, not a result", text: "This score comes from a toy utility. The data survey says the real optimum is unknown." }
        ] },
        { id: "robot", title: "Robot data only", goal: "See what the toy says about robot-only recipes.", steps: [
          { at: "ro:layers", name: "Layers used", title: "One layer can work", run: [["select", "data-rec", "dz"], ["seg", "data-tgt", "seen"]], text: "DreamZero trained on about 500 hours of robot data only and performed strongly. More sources are not proven better." },
          { at: "#data-chart", name: "the layer sweep", title: "Sweep one layer", run: [["seg", "data-ch", "sweep"], ["select", "data-sw", "0"]], text: "The layer sweep changes only real-robot hours at a fixed budget and reads the toy score." },
          { at: "#data-s0", name: "Real robot", title: "Remove the robot data", run: [["set", "data-s4", 100], ["set", "data-s0", 0]], text: "Without real-robot data the grounding axis stays near zero, whatever else you add." }
        ] }
      ]
    },

    /* ---------------------------------------------------------------- Failure detector and verifier lab */
    verifier: {
      terms: [
        { t: "runtime-failure-detection", w: "Scene", at: "#verifier-cv", when: "seg:verifier-mode=detect", val: "ro:tpr", watch: "A novelty score per rollout; the alarm fires when it leaves the band." },
        { t: "functional-conformal-prediction", w: "Controls", at: "#verifier-band", when: "seg:verifier-mode=detect", watch: "A band calibrated on successes; a constant threshold is one number." },
        { t: "exchangeability", w: "Controls", at: "#verifier-shift", when: "seg:verifier-mode=detect", val: "ro:fpr", watch: "Shift the test scene and false alarms can exceed the promised α." },
        { t: "verifier", w: "Controls", at: "#verifier-ver", when: "seg:verifier-mode=select", watch: "Which score ranks the candidates: VLM, critic, likelihood or truth." },
        { t: "test-time-verification", w: "Controls", at: "#verifier-n", when: "seg:verifier-mode=select", watch: "Sample N candidates, score each, run the best." },
        { t: "false-positives-under-search", w: "Chart", at: "#verifier-chart", when: "seg:verifier-mode=select", watch: "A curve that falls at large N: search found the verifier's blind spot." },
        { t: "reward-hacking", w: "Controls", at: "#verifier-train", when: "seg:verifier-mode=optimize", val: "ro:dtrue", watch: "Training raises the verifier's score; watch true success." },
        { t: "proxy-gain-that-transfers", w: "Readouts", at: "ro:ratio", when: "seg:verifier-mode=optimize", watch: "Share of the training verifier's gain that held-out verifiers confirm." },
        { t: "backdoor-attack", w: "Controls", at: "#verifier-tau0", when: "seg:verifier-mode=attack", watch: "The trigger redirects the flow only for τ below τ₀." },
        { t: "attack-success-rate", w: "Readouts", at: "ro:asr", when: "seg:verifier-mode=attack", watch: "Triggered samples that end where the attacker wants." },
        { t: "safety-filter", w: "Readouts", at: "ro:filt", when: "seg:verifier-mode=attack", watch: "Actions rejected for lying far from every demonstrated mode." }
      ],
      tours: [
        { id: "detect", title: "Calibrate a failure alarm", goal: "See what a conformal band promises and what it does not.", steps: [
          { at: "#verifier-cv", name: "the rollouts and scores", title: "One score, one band", run: [["seg", "verifier-mode", "detect"], ["seg", "verifier-band", "time"], ["seg", "verifier-fk", "slip"], ["set", "verifier-shift", 0]], text: "Each rollout gets a novelty score. The band was calibrated on successes, allowing at most 5% false alarms." },
          { at: "ro:tpr", name: "Failures caught", title: "One threshold for all", run: [["seg", "verifier-band", "const"]], text: "A constant threshold must clear the noisy grasp, so it sits high everywhere and catches fewer failures." },
          { at: "#verifier-cv", name: "the rollouts", title: "Watch one rollout", run: [["seg", "verifier-band", "time"], ["click", "verifier-play"]], text: "The gripper follows the taught path until the object slips. If the alarm fires, the robot stops." },
          { at: "ro:fpr", name: "False alarms", title: "Shift the scene", run: [["set", "verifier-shift", 1]], text: "New successes no longer look like the calibration set, so false alarms can exceed the promised α." }
        ] },
        { id: "select", title: "Pick among candidates", goal: "See when more candidates help and when search finds a verifier's blind spot.", steps: [
          { at: "#verifier-chart", name: "the success chart", title: "Best of N", run: [["seg", "verifier-mode", "select"], ["seg", "verifier-pre", "id"], ["seg", "verifier-ver", "vlm"], ["set", "verifier-n", 3]], text: "Sample candidate grasps, score each with a verifier, run the best. Success rises with N at first." },
          { at: "#verifier-n", name: "Candidates N", title: "Search harder", run: [["set", "verifier-n", 7]], text: "At 128 candidates the offline critic often picks a grasp in its blind spot, while the VLM keeps improving." },
          { at: "#verifier-cv", name: "the candidates", title: "Show the critic", run: [["seg", "verifier-ver", "q"]], text: "The critic overestimates grasps far from its data. Search is what finds them." }
        ] },
        { id: "attack", title: "Hack and hijack", goal: "See a policy fool its verifier, and a backdoor hide inside a flow head.", steps: [
          { at: "ro:dproxy", name: "Δproxy", title: "Train against a verifier", run: [["seg", "verifier-mode", "optimize"], ["click", "verifier-train"], ["wait", 2500]], text: "The policy climbs the training verifier's score. The shortcut is easier to learn than the skill." },
          { at: "ro:ratio", name: "Proxy gain that transfers", title: "Check with a panel", text: "Only part of that gain holds under held-out verifiers. Compare Δ true success." },
          { at: "#verifier-tau0", name: "Backdoor window τ₀", title: "A backdoor in early flow", run: [["seg", "verifier-mode", "attack"], ["seg", "verifier-tk", "mode"], ["set", "verifier-tau0", 0.4]], text: "A trigger redirects the flow only early in denoising. Triggered samples end in another task's mode." },
          { at: "ro:filt", name: "Off-mode filter", title: "A fixed target", run: [["seg", "verifier-tk", "pose"], ["set", "verifier-tau0", 1]], text: "A fixed attack pose lies off every demonstrated mode, so the output filter now rejects most attacks." }
        ] }
      ]
    }
  };
})();
