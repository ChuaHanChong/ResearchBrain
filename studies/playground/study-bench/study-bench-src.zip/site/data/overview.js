/* Overview: one summary card per part (with its key equation) and the frontier map of open problems. */
(function () {
  var RB = window.RB;
  RB.PART_SUMMARIES = {
    A: { text: "A robot policy maps observations to actions inside a control loop. RL learns it from reward; sim-to-real carries it from simulation to hardware.",
      eq: { name: "Expected return", ref: "P08 §2 · P07", tex: "\\class{sym-J}{J}(\\class{sym-pi}{\\pi_\\theta}) = \\class{sym-E}{\\mathbb{E}}_{\\class{sym-pi}{\\pi_\\theta}}\\Big[\\sum_t \\class{sym-gamma}{\\gamma}^t \\class{sym-r}{r_t}\\Big]", words: "The quantity reinforcement learning maximizes: the discounted sum of rewards the policy collects.", key: ["J", "pi", "E", "gamma", "r"] },
      terms: ["pomdp", "discounted-return", "domain-randomization", "impedance-control"] },
    B: { text: "Imitation learns from demonstrations. Generative heads capture several ways to act, chunks cut compounding error, VLAs add a pretrained vision-language backbone, and in-context learning steers a frozen policy with demonstrations.",
      eq: { name: "Flow-matching action loss", ref: "X2 eq. 52", tex: "\\class{sym-L}{\\mathcal{L}} = \\class{sym-E}{\\mathbb{E}}\\big\\|\\class{sym-v}{v_\\theta}(\\class{sym-tau}{\\tau}\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} + (1-\\class{sym-tau}{\\tau})\\class{sym-eps}{\\epsilon}, \\class{sym-o}{o_t}, \\class{sym-l}{\\ell}) - (\\class{sym-achunk}{\\mathbf{a}_{t:t+H}} - \\class{sym-eps}{\\epsilon})\\big\\|^2", words: "Regress the velocity from noise to the demonstrated chunk, given the observation and instruction.", key: ["L", "E", "v", "tau", "achunk", "eps", "o", "l"] },
      terms: ["behavior-cloning", "action-chunk", "flow-matching", "vision-language-action-model"] },
    C: { text: "World models predict how the world changes under actions. World action models put that prediction in the action path; others use it to train or judge policies.",
      eq: { name: "World action model", ref: "P04 §2 · X1 §2", tex: "p_\\Theta(\\class{sym-op}{o'}, \\class{sym-a}{a} \\mid \\class{sym-o}{o}, \\class{sym-l}{\\ell}) = \\class{sym-ptheta}{p_\\theta}(\\class{sym-op}{o'} \\mid \\class{sym-o}{o}, \\class{sym-l}{\\ell})\\, \\class{sym-pihead}{\\pi_\\psi}(\\class{sym-a}{a} \\mid \\class{sym-o}{o}, \\class{sym-op}{o'}, \\class{sym-l}{\\ell})", words: "A cascaded WAM: first predict the future, then decode the action from it. Joint WAMs model both at once.", key: ["op", "a", "o", "l", "ptheta", "pihead"] },
      terms: ["world-model", "world-action-model", "learned-environment"] },
    D: { text: "Robot data is scarce and expensive. The data pyramid trades scalability against robot alignment, from real teleoperation down to human video, simulation and web data.",
      eq: { name: "Data mixture", ref: "P05 §7 (standard form)", tex: "p(\\text{sample}) = \\sum_{\\ell} w_\\ell\\, p_\\ell", words: "Training draws from each pyramid layer with a weight; the best weights are an open question.", key: [{ glyph: "w_ℓ", meaning: "weight of layer ℓ" }, { glyph: "p_ℓ", meaning: "data distribution of layer ℓ" }] },
      terms: ["data-pyramid", "latent-action", "co-training"] },
    E: { text: "Manipulation skills: grasping from rectangles to grasp foundation models, dexterous hands, deformable and mobile tasks, humanoids, touch and force, and physics priors.",
      eq: { name: "Impedance control", ref: "P10 §6", tex: "\\class{sym-Md}{M_d}(\\ddot{x}_{\\mathrm{des}} - \\ddot{\\class{sym-x}{x}}) + \\class{sym-Bd}{B_d}(\\dot{x}_{\\mathrm{des}} - \\dot{\\class{sym-x}{x}}) + \\class{sym-Kd}{K_d}(x_{\\mathrm{des}} - \\class{sym-x}{x}) = \\class{sym-Fext}{F_{\\mathrm{ext}}}", words: "The end effector behaves like a mass-spring-damper around its target, so contact forces stay bounded.", key: ["Md", "x", "Bd", "Kd", "Fext"] },
      terms: ["6-dof-grasp", "dexterous-hand", "impedance-control", "physics-informed-loss"] },
    F: { text: "Verifiers score, filter and stop policies; safety work maps attacks and defenses; benchmarks measure progress but miss contact, calibration and real deployment.",
      eq: { name: "Best-of-N with a verifier", ref: "P14 §4.2 (standard form)", tex: "\\class{sym-a}{a}^\\star = \\arg\\max_{i \\le \\class{sym-N}{N}} \\class{sym-score}{S}(\\class{sym-o}{o_t}, \\class{sym-a}{a}_i), \\quad \\class{sym-a}{a}_i \\sim \\class{sym-pi}{\\pi_\\theta}", words: "Sample N candidate actions and execute the one the verifier scores highest.", key: ["a", "N", "score", "o", "pi"] },
      terms: ["verifier", "safety-filter", "success-rate"] }
  };
  RB.FRONTIER = [
    { title: "Dream less, act more", text: "Predicting futures costs latency: joint video–action models run near 7 Hz against 50 Hz for plain VLAs. Surveys ask for the minimal sufficient world model.", papers: ["P04 §7.1", "X1 §7", "P03 §8"], topics: ["c2", "b3"] },
    { title: "Contact, touch and force", text: "Vision dominates; tactile and force data are scarce, sensors are not standardized, and contact-rich tasks are evaluated on a handful of setups.", papers: ["P10 §7", "P05 §8", "P03 §8", "X3 §VIII"], topics: ["e5", "e6"] },
    { title: "Failure data and recovery", text: "Datasets record success; failure onset, cause and recovery are rarely labeled, which limits verifiers and recovery policies.", papers: ["P05 §8", "P14 §6", "P01 §9.4"], topics: ["f1", "d1"] },
    { title: "Evaluation that predicts deployment", text: "Benchmark numbers depend on the benchmark, world-model scores correlate weakly with success, and real-world ranking agreement is rarely measured.", papers: ["P03 §7", "X3 §VIII", "P14 §6", "P04 §7.7"], topics: ["f3"] },
    { title: "Data recipes", text: "Which mix of robot, UMI, human, simulation and web data works best is unknown; compute-matched ablations are missing.", papers: ["P05 §8", "P04 §7.2", "X1 §7.3"], topics: ["d1", "d2"] },
    { title: "Cross-embodiment actions", text: "Action spaces differ across robots; zero-padded, projected and semantic-slot interfaces compete, and coordinate conventions are rarely recorded.", papers: ["P05 §7.2", "P02 §IV", "P01 §7.2"], topics: ["b3", "d1"] },
    { title: "Calibrated verifiers", text: "Cheap verifiers are gameable and credible ones are expensive; conformal guarantees break once a policy is optimized against the verifier.", papers: ["P14 §6–7"], topics: ["f1"] },
    { title: "Safety of generalist policies", text: "VLAs and WAMs add new attack surfaces, such as backdoors in flow heads and open-loop chunks, and backdoor defenses are nearly absent.", papers: ["P13 §5, §7–8"], topics: ["f2"] },
    { title: "Physically grounded prediction", text: "Visually realistic futures can be physically wrong; there are no standard metrics for physical consistency of learned models.", papers: ["P11", "P04 §7.6", "X3 §VIII"], topics: ["e6", "c1"] },
    { title: "Humanoid loco-manipulation", text: "High-DoF contact planning is slow, simulators model contact poorly, and there are no large loco-manipulation benchmarks.", papers: ["P09"], topics: ["e4"] }
  ];
})();
