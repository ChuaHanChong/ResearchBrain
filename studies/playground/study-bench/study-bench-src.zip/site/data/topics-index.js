/* Topic index: order, numbers, parts and prerequisite edges. The course map and TOC are built from this.
   Topic content lives in topics/<id>.js and must keep id, title and buildsOn in sync with this file. */
(function () {
  var RB = window.RB;
  RB.PARTS = [
    { id: "A", name: "Foundations" },
    { id: "B", name: "Imitation and policy architectures" },
    { id: "C", name: "Predictive models" },
    { id: "D", name: "Data" },
    { id: "E", name: "Manipulation skills and embodiments" },
    { id: "F", name: "Trust: verification, safety, evaluation" }
  ];
  RB.TOPIC_INDEX = [
    { id: "a1", map: "The problem", num: "01", part: "A", short: "The robot-learning problem", sources: "P01 §2, §5–6 · X2 §1–2", buildsOn: [] },
    { id: "a2", map: "Control", num: "02", part: "A", short: "Control the policy sits on", sources: "P09 §V–VI · P10 §6 · P11 §2", buildsOn: ["a1"] },
    { id: "a3", map: "Reinforcement learning", num: "03", part: "A", short: "Reinforcement learning for robots", sources: "X2 §3 · P07 · P09 §VII-A", buildsOn: ["a1"] },
    { id: "a4", map: "Sim-to-real", num: "04", part: "A", short: "Sim-to-real", sources: "P08 · P07 · P09", buildsOn: ["a3"] },
    { id: "b1", map: "Behavior cloning", num: "05", part: "B", short: "Behavior cloning", sources: "X2 §4 · P01 §6.1.2", buildsOn: ["a1"] },
    { id: "b2", map: "Policy heads", num: "06", part: "B", short: "Generative policy heads", sources: "X2 §4 · P01 §6.4", buildsOn: ["b1"] },
    { id: "b3", map: "Actions and timing", num: "07", part: "B", short: "Action representations and timing", sources: "P02 §IV · X2 §4.5 · P01 §6.4.8 · P05 §7.2", buildsOn: ["b2"] },
    { id: "b4", map: "VLAs", num: "08", part: "B", short: "Vision-language-action models", sources: "P02 · P01 §6.2.2 · X2 §5", buildsOn: ["b2", "b3"] },
    { id: "b5", map: "LLM planning", num: "09", part: "B", short: "High-level planning with LLMs", sources: "P01 §5 · P09 §VIII · P02 §IV-C", buildsOn: ["a1", "b4"] },
    { id: "b6", map: "In-context learning", num: "10", part: "B", short: "In-context learning", sources: "X4 §2–3, §5", buildsOn: ["b1", "b4"] },
    { id: "c1", map: "World models", num: "11", part: "C", short: "World models", sources: "X3 §II–IV · P03 §1–3 · X1 §3", buildsOn: ["a3"] },
    { id: "c2", map: "World action models", num: "12", part: "C", short: "World action models", sources: "P04 · X1 · P03 §3", buildsOn: ["c1", "b4"] },
    { id: "c3", map: "WM as simulator", num: "13", part: "C", short: "World models as simulator and judge", sources: "P03 §4 · X3 §V–VI · P05 §5.5", buildsOn: ["c1", "a3"] },
    { id: "d1", map: "Data pyramid", num: "14", part: "D", short: "The data pyramid", sources: "P05 · P02 §VI · P01 §3, §7.1", buildsOn: ["b4"] },
    { id: "d2", map: "Human videos", num: "15", part: "D", short: "Learning from human videos", sources: "P06 · P05 §4", buildsOn: ["d1", "b3"] },
    { id: "e1", map: "Grasping", num: "16", part: "E", short: "Grasping", sources: "P01 §3.1, §4.1 · P05 §6.8 · P07", buildsOn: ["a1", "b1"] },
    { id: "e2", map: "Dexterous hands", num: "17", part: "E", short: "Dexterous and in-hand manipulation", sources: "P01 §4.3 · P07 · P10 · P06", buildsOn: ["a4", "e1"] },
    { id: "e3", map: "Deformable, mobile", num: "18", part: "E", short: "Deformable, bimanual and mobile", sources: "P01 §4.4–4.7 · P07 · P02 · P05", buildsOn: ["b2", "d1"] },
    { id: "e4", map: "Humanoids", num: "19", part: "E", short: "Humanoid whole-body manipulation", sources: "P09 · P01 §4.8", buildsOn: ["a2", "a4"] },
    { id: "e5", map: "Touch and force", num: "20", part: "E", short: "Touch and force", sources: "P10 · P01 §6.2.3", buildsOn: ["a2", "b2"] },
    { id: "e6", map: "Physics priors", num: "21", part: "E", short: "Physics priors", sources: "P11", buildsOn: ["a2", "c1"] },
    { id: "f1", map: "Verifiers", num: "22", part: "F", short: "Verifiers and failure detection", sources: "P14 · P01 §7 · X3 §V-E", buildsOn: ["b4", "c3"] },
    { id: "f2", map: "Safety", num: "23", part: "F", short: "Safety of embodied AI", sources: "P13", buildsOn: ["f1", "b4"] },
    { id: "f3", map: "Benchmarks", num: "24", part: "F", short: "Benchmarks and what they miss", sources: "P03 §7 · X3 §VII–VIII · P01 §3 · X1 §6", buildsOn: ["b4", "c2"] }
  ];
  RB.topicOrder = RB.TOPIC_INDEX.map(function (t) { return t.id; });
  RB.TOPIC_INDEX.forEach(function (t) { RB.topics[t.id] = RB.topics[t.id] || {}; var o = RB.topics[t.id]; Object.keys(t).forEach(function (k) { if (o[k] == null) o[k] = t[k]; }); });

  RB.STATION_INDEX = [
    { id: "heads", group: "Policies", name: "Policy head bench", topics: ["b1", "b2"] },
    { id: "tokens", group: "Policies", name: "Action tokenizer", topics: ["b3", "b4"] },
    { id: "vla", group: "Policies", name: "VLA dissector", topics: ["b4"] },
    { id: "timing", group: "Policies", name: "Control-loop budget", topics: ["b3", "c2"] },
    { id: "worldmodel", group: "Predictive models", name: "World-model sandbox", topics: ["c1", "c3"] },
    { id: "wam", group: "Predictive models", name: "WAM coupling playground", topics: ["c2"] },
    { id: "grasp", group: "Physical interaction", name: "Grasp lab", topics: ["e1", "e2"] },
    { id: "compliance", group: "Physical interaction", name: "Compliance station", topics: ["a2", "e5", "e4"] },
    { id: "sim2real", group: "Physical interaction", name: "Sim-to-real station", topics: ["a4", "a3"] },
    { id: "physics", group: "Physical interaction", name: "Physics-prior station", topics: ["e6"] },
    { id: "data", group: "Data", name: "Data recipe mixer", topics: ["d1", "d2"] },
    { id: "verifier", group: "Trust", name: "Failure detector and verifier lab", topics: ["f1", "f2"] }
  ];
  RB.stationOrder = RB.STATION_INDEX.map(function (s) { return s.id; });
})();
