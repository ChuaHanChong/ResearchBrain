/* House notation. One symbol, one meaning, one id across the whole site.
   tex: how it is typeset; glyph: plain-text form for keys, chips and canvas labels; kind: filter group;
   first: topic where it first appears; papers: how the corpus writes the same idea (concordance). */
(function () {
  var S = [
    /* --- signals --- */
    { id: "o", tex: "o_t", glyph: "oₜ", kind: "Signals", meaning: "observation at time t (images, proprioception)", short: "observation at time t", first: "a1", read: "o sub t", papers: "P03, P04, X1: o_t · X2: o_t · P08: o" },
    { id: "s", tex: "s_t", glyph: "sₜ", kind: "Signals", meaning: "state of robot and world at time t", short: "state at time t", first: "a1", read: "s sub t", papers: "P07, P08, X2: s_t" },
    { id: "a", tex: "a_t", glyph: "aₜ", kind: "Signals", meaning: "action at time t (joint targets, end-effector deltas or torques)", short: "action at time t", first: "a1", read: "a sub t", papers: "all: a_t" },
    { id: "achunk", tex: "\\mathbf{a}_{t:t+H}", glyph: "a₍ₜ:ₜ₊H₎", kind: "Signals", meaning: "action chunk: H consecutive actions predicted at once", short: "chunk of H actions", first: "b2", read: "a from t to t plus H", papers: "X2: a_{t:t+H_a} · P03: a_{t+1:t+k} · P04: a_{t:t+H-1}" },
    { id: "H", tex: "H", glyph: "H", kind: "Parameters", meaning: "chunk length or prediction horizon, in steps", short: "chunk length / horizon", first: "b2", read: "H", papers: "X2: H_a · P03: k · P04: H" },
    { id: "l", tex: "\\ell", glyph: "ℓ", kind: "Signals", meaning: "language instruction", short: "language instruction", first: "b4", read: "ell", papers: "P03, P04, X1: l · P14: ℓ" },
    { id: "op", tex: "o'", glyph: "o′", kind: "Signals", meaning: "predicted or next observation (the future)", short: "future observation", first: "c1", read: "o prime", papers: "P04, X1: o′ · P03: o_{t+1:t+k}" },
    { id: "z", tex: "z", glyph: "z", kind: "Signals", meaning: "latent variable: a learned compact code (style, latent action, world state)", short: "latent variable", first: "b2", read: "z", papers: "X2 (ACT): z · P02 (LAPA): z_t · P01: Z" },
    { id: "g", tex: "g", glyph: "g", kind: "Signals", meaning: "grasp: a gripper pose (and width) that holds an object", short: "grasp pose", first: "e1", read: "g", papers: "P01: 5-D rectangle or 6-DoF pose" },
    { id: "xi", tex: "\\xi", glyph: "ξ", kind: "Signals", meaning: "trajectory: a sequence of states and actions", short: "trajectory", first: "a3", read: "xi", papers: "P14: ξ · P03: τ̂ (imagined) · RL texts: τ" },
    { id: "D", tex: "\\mathcal{D}", glyph: "𝒟", kind: "Sets", meaning: "dataset of demonstrations or transitions", short: "dataset", first: "b1", read: "script D", papers: "X2: 𝒟 · P06: 𝒟_expert" },
    /* --- functions and models --- */
    { id: "pi", tex: "\\pi_\\theta", glyph: "π_θ", kind: "Functions", meaning: "policy with parameters θ: maps observations to actions", short: "policy", first: "a1", read: "pi theta", papers: "all: π" },
    { id: "pihead", tex: "\\pi_\\psi", glyph: "π_ψ", kind: "Functions", meaning: "action head: turns a predicted future or latent into actions", short: "action head", first: "c2", read: "pi psi", papers: "P04: q_ψ · P03: IDM p(a | o_{t:t+k})" },
    { id: "ptheta", tex: "p_\\theta", glyph: "p_θ", kind: "Functions", meaning: "learned probability model (world model or generator)", short: "learned model", first: "c1", read: "p theta", papers: "P03, P04, X1: p_θ" },
    { id: "f", tex: "f", glyph: "f", kind: "Functions", meaning: "dynamics: next state as a function of state and action", short: "dynamics function", first: "a2", read: "f", papers: "P08: T(s′|s,a) · P09: ẋ = f(x,u,λ)" },
    { id: "T", tex: "T", glyph: "T", kind: "Functions", meaning: "transition probability P(s′ | s, a)", short: "transition probability", first: "a3", read: "T", papers: "P08: T, P_s vs P_r" },
    { id: "r", tex: "r_t", glyph: "rₜ", kind: "Signals", meaning: "reward at time t", short: "reward", first: "a3", read: "r sub t", papers: "all: r_t" },
    { id: "gamma", tex: "\\gamma", glyph: "γ", kind: "Parameters", meaning: "discount factor", short: "discount factor", first: "a3", read: "gamma", papers: "all: γ" },
    { id: "V", tex: "V", glyph: "V", kind: "Functions", meaning: "value: expected discounted return from a state", short: "value function", first: "a3", read: "V", papers: "all: V" },
    { id: "Q", tex: "Q", glyph: "Q", kind: "Functions", meaning: "action value: expected return after taking an action", short: "action-value function", first: "a3", read: "Q", papers: "all: Q" },
    { id: "adv", tex: "\\hat{A}_t", glyph: "Âₜ", kind: "Functions", meaning: "advantage estimate: how much better an action was than average", short: "advantage estimate", first: "a3", read: "A hat sub t", papers: "P03 eq. 18, P07: Â_t" },
    { id: "ratio", tex: "\\rho_t", glyph: "ρₜ", kind: "Functions", meaning: "probability ratio of new to old policy for an action", short: "policy probability ratio", first: "a3", read: "rho sub t", papers: "P03: r_t · P07: ρ_t" },
    { id: "J", tex: "J", glyph: "J", kind: "Functions", meaning: "objective: expected discounted return of a policy", short: "objective (expected return)", first: "a3", read: "J", papers: "P08, P03: J(π)" },
    { id: "L", tex: "\\mathcal{L}", glyph: "ℒ", kind: "Functions", meaning: "training loss", short: "training loss", first: "b1", read: "script L", papers: "all: ℒ or L" },
    { id: "E", tex: "\\mathbb{E}", glyph: "𝔼", kind: "Operators", meaning: "expectation (average over the sampled quantities)", short: "expectation", first: "b1", read: "expectation", papers: "all: 𝔼" },
    { id: "KL", tex: "D_{\\mathrm{KL}}", glyph: "D_KL", kind: "Operators", meaning: "Kullback–Leibler divergence between two distributions", short: "KL divergence", first: "b2", read: "D K L", papers: "X2, X3: D_KL" },
    /* --- generative heads --- */
    { id: "tau", tex: "\\tau", glyph: "τ", kind: "Parameters", meaning: "flow or diffusion time: 0 = pure noise, 1 = clean action (house convention)", short: "flow / diffusion time", first: "b2", read: "tau", papers: "π0 (X2 eq. 52): τ, clean at τ = 1 · X2 FM eq. 49: t · DDPM: step index t" },
    { id: "eps", tex: "\\epsilon", glyph: "ε", kind: "Signals", meaning: "Gaussian noise sample", short: "Gaussian noise", first: "b2", read: "epsilon", papers: "all: ε" },
    { id: "x-tau", tex: "\\mathbf{a}^{\\tau}", glyph: "a^τ", kind: "Signals", meaning: "noisy action chunk at flow time τ", short: "noisy action at time τ", first: "b2", read: "a superscript tau", papers: "X2: a^τ, z_t · P04: s^(n), x_t" },
    { id: "v", tex: "v_\\theta", glyph: "v_θ", kind: "Functions", meaning: "learned velocity field that moves noise toward data", short: "learned velocity field", first: "b2", read: "v theta", papers: "X2, P04: v_θ" },
    { id: "epsnet", tex: "\\epsilon_\\theta", glyph: "ε_θ", kind: "Functions", meaning: "learned noise predictor of a diffusion model", short: "noise predictor", first: "b2", read: "epsilon theta", papers: "X2, P04: ε_θ" },
    { id: "abar", tex: "\\bar{\\alpha}_k", glyph: "ᾱₖ", kind: "Parameters", meaning: "cumulative noise-schedule coefficient at denoising step k", short: "noise-schedule coefficient", first: "b2", read: "alpha bar sub k", papers: "X2 eq. 44: ᾱ_t · P04: α_n" },
    { id: "K", tex: "K", glyph: "K", kind: "Parameters", meaning: "number of denoising or integration steps", short: "denoising steps", first: "b2", read: "K", papers: "X2: T · P04: N" },
    { id: "beta", tex: "\\beta", glyph: "β", kind: "Parameters", meaning: "weight on the KL term of a (conditional) VAE", short: "KL weight", first: "b2", read: "beta", papers: "X2 (ACT eq. 50): β" },
    /* --- world models / WAM --- */
    { id: "wam-phi", tex: "\\Phi", glyph: "Φ", kind: "WAM anatomy", meaning: "predictive substrate: what the model predicts (pixels, features, geometry, affordance)", short: "predictive substrate", first: "c2", read: "capital phi", papers: "P04 §4: Φ" },
    { id: "wam-F", tex: "\\mathsf{F}", glyph: "F", kind: "WAM anatomy", meaning: "action coupling: rollout, joint generation or post-prediction head", short: "action coupling", first: "c2", read: "sans-serif F", papers: "P04 §4: F" },
    { id: "wam-B", tex: "\\mathsf{B}", glyph: "B", kind: "WAM anatomy", meaning: "architectural backbone: diffusion, autoregressive, JEPA, hybrid, VLM", short: "backbone", first: "c2", read: "sans-serif B", papers: "P04 §4: B" },
    { id: "wam-D", tex: "\\mathsf{D}", glyph: "D", kind: "WAM anatomy", meaning: "deployment regime: open loop, chunked, single-step or interactive", short: "deployment regime", first: "c2", read: "sans-serif D", papers: "P04 §4: D" },
    { id: "Nfwd", tex: "N_{\\mathrm{fwd}}", glyph: "N_fwd", kind: "Parameters", meaning: "time for the forward passes that produce one prediction", short: "inference time per call", first: "b3", read: "N forward", papers: "P04 §4.4: N_fwd" },
    { id: "fctrl", tex: "f_{\\mathrm{ctrl}}", glyph: "f_ctrl", kind: "Parameters", meaning: "control rate of the robot, in hertz", short: "control rate", first: "b3", read: "f control", papers: "P04: f_ctrl · P02: Hz" },
    /* --- control and physics --- */
    { id: "qj", tex: "q", glyph: "q", kind: "Robot", meaning: "joint configuration (joint angles)", short: "joint configuration", first: "a2", read: "q", papers: "P09, P10, P11: q · MR books: θ" },
    { id: "M", tex: "M(q)", glyph: "M(q)", kind: "Robot", meaning: "mass (inertia) matrix", short: "mass matrix", first: "a2", read: "M of q", papers: "P09, P10, P11: M" },
    { id: "C", tex: "C(q,\\dot q)", glyph: "C(q, q̇)", kind: "Robot", meaning: "Coriolis and centrifugal terms", short: "Coriolis terms", first: "a2", read: "C of q, q dot", papers: "P10: C q̇ · P11: c(q, q̇)" },
    { id: "G", tex: "G(q)", glyph: "G(q)", kind: "Robot", meaning: "gravity torques", short: "gravity torques", first: "a2", read: "G of q", papers: "P09, P10: G · P11: g(q)" },
    { id: "torque", tex: "\\boldsymbol{\\tau}", glyph: "𝛕", kind: "Robot", meaning: "joint torques (bold, to keep plain τ for flow time)", short: "joint torques", first: "a2", read: "bold tau", papers: "P09, P10, P11: τ" },
    { id: "Jac", tex: "J(q)", glyph: "J(q)", kind: "Robot", meaning: "Jacobian: maps joint velocities to end-effector velocity", short: "Jacobian", first: "a2", read: "J of q", papers: "P09, P10: J" },
    { id: "Fext", tex: "F_{\\mathrm{ext}}", glyph: "F_ext", kind: "Robot", meaning: "external force (wrench) at the end effector", short: "external force", first: "a2", read: "F external", papers: "P10: F_ext" },
    { id: "x", tex: "x", glyph: "x", kind: "Robot", meaning: "end-effector position (task space)", short: "end-effector position", first: "a2", read: "x", papers: "P10: x, x_des" },
    { id: "Kd", tex: "K_d", glyph: "K_d", kind: "Parameters", meaning: "desired stiffness of a compliant controller", short: "stiffness", first: "a2", read: "K d", papers: "P10: K_d" },
    { id: "Bd", tex: "B_d", glyph: "B_d", kind: "Parameters", meaning: "desired damping of a compliant controller", short: "damping", first: "a2", read: "B d", papers: "P10: B_d" },
    { id: "Md", tex: "M_d", glyph: "M_d", kind: "Parameters", meaning: "desired (virtual) mass of a compliant controller", short: "virtual mass", first: "a2", read: "M d", papers: "P10: M_d" },
    { id: "lambda", tex: "\\lambda", glyph: "λ", kind: "Robot", meaning: "contact force (or Lagrange multiplier, when stated)", short: "contact force / multiplier", first: "a2", read: "lambda", papers: "P09: λ contact forces · P03: λ loss weight" },
    { id: "mu", tex: "\\mu", glyph: "μ", kind: "Parameters", meaning: "friction coefficient", short: "friction coefficient", first: "e1", read: "mu", papers: "P01, P09: μ" },
    { id: "omega", tex: "\\omega", glyph: "ω", kind: "Parameters", meaning: "randomized simulator parameters (mass, friction, delay, textures)", short: "randomized sim parameters", first: "a4", read: "omega", papers: "P07, P08: ξ (house uses ξ for trajectories)" },
    { id: "Lag", tex: "\\mathcal{L}_{\\text{lag}}", glyph: "ℒ_lag", kind: "Functions", meaning: "Lagrangian: kinetic minus potential energy", short: "Lagrangian", first: "e6", read: "Lagrangian", papers: "P11: L = T − V" },
    { id: "Ham", tex: "\\mathcal{H}", glyph: "ℋ", kind: "Functions", meaning: "Hamiltonian: total energy as a function of position and momentum", short: "Hamiltonian", first: "e6", read: "script H", papers: "P11: H(q, p)" },
    /* --- trust --- */
    { id: "h", tex: "h(x)", glyph: "h(x)", kind: "Functions", meaning: "barrier function: nonnegative exactly on the safe set", short: "barrier function", first: "f2", read: "h of x", papers: "P13 (standard form)" },
    { id: "score", tex: "S", glyph: "S", kind: "Functions", meaning: "verifier score for a candidate (action, rollout or policy)", short: "verifier score", first: "f1", read: "S", papers: "P14 eq. 1: verifier(context, candidate) → score" },
    { id: "alpha-cp", tex: "\\alpha", glyph: "α", kind: "Parameters", meaning: "allowed error rate of a conformal guarantee", short: "allowed error rate", first: "f1", read: "alpha", papers: "P14: α" },
    { id: "N", tex: "N", glyph: "N", kind: "Parameters", meaning: "number of sampled candidates (best-of-N)", short: "number of candidates", first: "f1", read: "N", papers: "P14: N" }
  ];
  S.forEach(function (s) { window.RB.symbol(s, "house"); });
})();
