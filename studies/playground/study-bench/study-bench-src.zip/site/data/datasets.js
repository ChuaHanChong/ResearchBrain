/* Dataset atlas (Reference page, core/70-reference.js datasets()).
   Sizes are copied from P01 (2510.10903) Tables 1-4, P02 (2510.07077) Table 1, P05 (2607.24744) Tables 1, 2, 3, 5, 6
   and P06 (2604.27621) Table 10. "size" is the number behind "sizeText" in "unit". Years come from the survey table
   (P01 venue year, P05 "Time", P06 "Year"); rows from P02 Table 1 and P05 Table 6, which have no year column, use the
   dataset paper's year. Where surveys disagree the row's notes say so (Open X-Embodiment has one row per figure). */
(function () {
  window.RB = window.RB || {};
  window.RB.DATASETS = [
 {
  "name": "Pinto and Gupta",
  "year": 2015,
  "layer": "Real robot",
  "size": 50000.0,
  "sizeText": "50K",
  "unit": "trajectories",
  "notes": "Self-supervised grasp attempts; 700 hours",
  "source": "P05 Table 1"
 },
 {
  "name": "MIME",
  "year": 2018,
  "layer": "Real robot",
  "size": 8300.0,
  "sizeText": "8.3K",
  "unit": "trajectories",
  "notes": "Baxter; 13.7 hours; P01 Table 4 also 8.3k",
  "source": "P05 Table 1; P01 Table 4"
 },
 {
  "name": "QT-Opt",
  "year": 2018,
  "layer": "Real robot",
  "size": 580000.0,
  "sizeText": "580K",
  "unit": "trajectories",
  "notes": "Grasping only; 800 hours; P02 lists 580K episodes",
  "source": "P05 Table 1; P02 Table 1"
 },
 {
  "name": "RoboTurk",
  "year": 2018,
  "layer": "Real robot",
  "size": 2100.0,
  "sizeText": "2.1K",
  "unit": "trajectories",
  "notes": "Crowdsourced teleoperation; 111.3 hours",
  "source": "P05 Table 1"
 },
 {
  "name": "RoboNet",
  "year": 2019,
  "layer": "Real robot",
  "size": 162000.0,
  "sizeText": "162K",
  "unit": "trajectories",
  "notes": "Seven robot types; scripted, not expert",
  "source": "P05 Table 1; P02 Table 1"
 },
 {
  "name": "MT-Opt",
  "year": 2021,
  "layer": "Real robot",
  "size": 800000.0,
  "sizeText": "800K",
  "unit": "trajectories",
  "notes": "12 tasks; P02 Table 1 agrees",
  "source": "P05 Table 1; P02 Table 1"
 },
 {
  "name": "BridgeData",
  "year": 2021,
  "layer": "Real robot",
  "size": 7200.0,
  "sizeText": "7.2K",
  "unit": "trajectories",
  "notes": "WidowX 250 teleoperation, 71 tasks",
  "source": "P05 Table 1; P01 Table 4"
 },
 {
  "name": "BC-Z",
  "year": 2022,
  "layer": "Real robot",
  "size": 26000.0,
  "sizeText": "26K",
  "unit": "trajectories",
  "notes": "100 tasks; P01 dates it CoRL 2021",
  "source": "P05 Table 1; P01 Table 4"
 },
 {
  "name": "Language Table",
  "year": 2022,
  "layer": "Real robot",
  "size": 413000.0,
  "sizeText": "413K",
  "unit": "episodes",
  "notes": "xArm pushing with language",
  "source": "P02 Table 1"
 },
 {
  "name": "RT-1",
  "year": 2022,
  "layer": "Real robot",
  "size": 130000.0,
  "sizeText": "130K",
  "unit": "trajectories",
  "notes": "Google robot, 700+ tasks",
  "source": "P05 Table 1; P02 Table 1"
 },
 {
  "name": "FurnitureBench",
  "year": 2023,
  "layer": "Real robot",
  "size": 5100.0,
  "sizeText": "5.1K",
  "unit": "trajectories",
  "notes": "Furniture assembly; 219.6 hours",
  "source": "P05 Table 1"
 },
 {
  "name": "RH20T",
  "year": 2023,
  "layer": "Real robot",
  "size": 110000.0,
  "sizeText": "110K",
  "unit": "trajectories",
  "notes": "Four robots; tactile, force and audio",
  "source": "P05 Table 1; P02 Table 1"
 },
 {
  "name": "RoboSet",
  "year": 2023,
  "layer": "Real robot",
  "size": 98500.0,
  "sizeText": "98.5K",
  "unit": "trajectories",
  "notes": "Franka; P01 dates it ICRA 2024",
  "source": "P05 Table 1; P01 Table 4"
 },
 {
  "name": "BridgeData V2",
  "year": 2023,
  "layer": "Real robot",
  "size": 60100.0,
  "sizeText": "60.1K",
  "unit": "trajectories",
  "notes": "WidowX 250; all three surveys give 60.1K",
  "source": "P05 Table 1; P01 Table 4"
 },
 {
  "name": "Open X-Embodiment",
  "year": 2023,
  "layer": "Real robot",
  "size": 2400000.0,
  "sizeText": "2.4M",
  "unit": "trajectories",
  "notes": "22 embodiments; P01 and P02 list 1.4M",
  "source": "P05 Table 1"
 },
 {
  "name": "Open X-Embodiment",
  "year": 2023,
  "layer": "Real robot",
  "size": 1400000.0,
  "sizeText": "1.4M",
  "unit": "episodes",
  "notes": "22 embodiments; P05 Table 1 lists 2.4M",
  "source": "P01 Table 4; P02 Table 1"
 },
 {
  "name": "ARIO",
  "year": 2024,
  "layer": "Real robot",
  "size": 3000000.0,
  "sizeText": "3M",
  "unit": "trajectories",
  "notes": "Real plus simulated data, several robots",
  "source": "P01 Table 4"
 },
 {
  "name": "ALOHA Unleashed",
  "year": 2024,
  "layer": "Real robot",
  "size": 26200.0,
  "sizeText": "26.2K",
  "unit": "trajectories",
  "notes": "Dual-arm ALOHA, five tasks",
  "source": "P05 Table 1"
 },
 {
  "name": "DROID",
  "year": 2024,
  "layer": "Real robot",
  "size": 76000.0,
  "sizeText": "76K",
  "unit": "trajectories",
  "notes": "Franka in the wild; 350 hours",
  "source": "P05 Table 1; P02 Table 1"
 },
 {
  "name": "FMB",
  "year": 2024,
  "layer": "Real robot",
  "size": 22600.0,
  "sizeText": "22.6K",
  "unit": "trajectories",
  "notes": "Functional manipulation benchmark with force",
  "source": "P05 Table 1"
 },
 {
  "name": "RoboMIND",
  "year": 2024,
  "layer": "Real robot",
  "size": 107000.0,
  "sizeText": "107K",
  "unit": "trajectories",
  "notes": "Four robots; failure labels; 305.5 hours",
  "source": "P05 Table 1; P02 Table 1"
 },
 {
  "name": "AgiBot World",
  "year": 2025,
  "layer": "Real robot",
  "size": 1000000.0,
  "sizeText": "1M",
  "unit": "trajectories",
  "notes": "AgiBot G1; 2,976.4 hours; P01 says 1M+",
  "source": "P05 Table 1; P02 Table 1"
 },
 {
  "name": "FuSe",
  "year": 2025,
  "layer": "Real robot",
  "size": 27000.0,
  "sizeText": "27K",
  "unit": "episodes",
  "notes": "WidowX with touch and audio",
  "source": "P02 Table 1"
 },
 {
  "name": "REASSEMBLE",
  "year": 2025,
  "layer": "Real robot",
  "size": 4600.0,
  "sizeText": "4.6K",
  "unit": "trajectories",
  "notes": "Assembly with audio, force and torque",
  "source": "P05 Table 1"
 },
 {
  "name": "Open Galaxea",
  "year": 2025,
  "layer": "Real robot",
  "size": 20500.0,
  "sizeText": "20.5K",
  "unit": "trajectories",
  "notes": "Mobile dual-arm; 500 hours",
  "source": "P05 Table 1"
 },
 {
  "name": "RoboCOIN",
  "year": 2025,
  "layer": "Real robot",
  "size": 180000.0,
  "sizeText": "180K",
  "unit": "trajectories",
  "notes": "15 dual-arm or humanoid embodiments",
  "source": "P05 Table 1; P01 Table 4"
 },
 {
  "name": "Humanoid Everyday",
  "year": 2025,
  "layer": "Real robot",
  "size": 10300.0,
  "sizeText": "10.3K",
  "unit": "trajectories",
  "notes": "Unitree humanoids; P01 dates it ICRA 2026",
  "source": "P05 Table 1; P01 Table 4"
 },
 {
  "name": "RoboMIND 2.0",
  "year": 2026,
  "layer": "Real robot",
  "size": 310000.0,
  "sizeText": "310K",
  "unit": "trajectories",
  "notes": "Six embodiments; tactile, force, failure labels",
  "source": "P05 Table 1"
 },
 {
  "name": "Open-H-Embodiment",
  "year": 2026,
  "layer": "Real robot",
  "size": 125800.0,
  "sizeText": "125.8K",
  "unit": "trajectories",
  "notes": "20 embodiments; 780 hours",
  "source": "P05 Table 1"
 },
 {
  "name": "LET-Base-Dataset",
  "year": 2026,
  "layer": "Real robot",
  "size": 91500.0,
  "sizeText": "91.5K",
  "unit": "trajectories",
  "notes": "Humanoid data; 1,000+ hours",
  "source": "P05 Table 1"
 },
 {
  "name": "ABC-130K",
  "year": 2026,
  "layer": "Real robot",
  "size": 130700.0,
  "sizeText": "130.7K",
  "unit": "trajectories",
  "notes": "Dual-arm; 3,591 hours",
  "source": "P05 Table 1"
 },
 {
  "name": "OmniViTac",
  "year": 2026,
  "layer": "Real robot",
  "size": 21900.0,
  "sizeText": "21.9K",
  "unit": "trajectories",
  "notes": "Single arm with tactile sensing",
  "source": "P05 Table 1"
 },
 {
  "name": "UMI",
  "year": 2024,
  "layer": "UMI-style",
  "size": 2500.0,
  "sizeText": "2.5K",
  "unit": "episodes",
  "notes": "Original handheld gripper interface",
  "source": "P05 Table 2"
 },
 {
  "name": "FastUMI",
  "year": 2024,
  "layer": "UMI-style",
  "size": 9000.0,
  "sizeText": "9.0K",
  "unit": "episodes",
  "notes": "22 tasks",
  "source": "P05 Table 2"
 },
 {
  "name": "Data Scaling Laws",
  "year": 2024,
  "layer": "UMI-style",
  "size": 24100.0,
  "sizeText": "24.1K",
  "unit": "episodes",
  "notes": "Six tasks; studies scaling with environments",
  "source": "P05 Table 2"
 },
 {
  "name": "LEGATO",
  "year": 2024,
  "layer": "UMI-style",
  "size": 900,
  "sizeText": "900",
  "unit": "episodes",
  "notes": "Retargets to different robots",
  "source": "P05 Table 2"
 },
 {
  "name": "ViTaMIn",
  "year": 2025,
  "layer": "UMI-style",
  "size": 841,
  "sizeText": "841",
  "unit": "episodes",
  "notes": "Adds tactile sensing",
  "source": "P05 Table 2"
 },
 {
  "name": "DexWild",
  "year": 2025,
  "layer": "UMI-style",
  "size": 9500.0,
  "sizeText": "9.5K",
  "unit": "episodes",
  "notes": "Dexterous hand",
  "source": "P05 Table 2"
 },
 {
  "name": "DexUMI",
  "year": 2025,
  "layer": "UMI-style",
  "size": 1800.0,
  "sizeText": "1.8K",
  "unit": "episodes",
  "notes": "Dexterous hand exoskeleton; force and torque",
  "source": "P05 Table 2"
 },
 {
  "name": "FreeTacMan",
  "year": 2025,
  "layer": "UMI-style",
  "size": 10000.0,
  "sizeText": "10K",
  "unit": "episodes",
  "notes": "50 tasks with tactile sensing",
  "source": "P05 Table 2"
 },
 {
  "name": "Touch in the Wild",
  "year": 2025,
  "layer": "UMI-style",
  "size": 2700.0,
  "sizeText": "2.7K",
  "unit": "episodes",
  "notes": "Tactile, 20 tasks",
  "source": "P05 Table 2"
 },
 {
  "name": "ManipForce",
  "year": 2025,
  "layer": "UMI-style",
  "size": 597,
  "sizeText": "597",
  "unit": "episodes",
  "notes": "Force and torque sensing",
  "source": "P05 Table 2"
 },
 {
  "name": "FastUMI-100K",
  "year": 2025,
  "layer": "UMI-style",
  "size": 100000.0,
  "sizeText": "100K",
  "unit": "episodes",
  "notes": "32 tasks",
  "source": "P05 Table 2"
 },
 {
  "name": "HuMI",
  "year": 2026,
  "layer": "UMI-style",
  "size": 827,
  "sizeText": "827",
  "unit": "episodes",
  "notes": "Bimanual with tactile sensing",
  "source": "P05 Table 2"
 },
 {
  "name": "RealOmni",
  "year": 2026,
  "layer": "UMI-style",
  "size": 789800.0,
  "sizeText": "789.8K",
  "unit": "episodes",
  "notes": "Bimanual, tactile, diverse tasks",
  "source": "P05 Table 2"
 },
 {
  "name": "Daimon-Infinity",
  "year": 2026,
  "layer": "UMI-style",
  "size": 274700.0,
  "sizeText": "274.7K",
  "unit": "episodes",
  "notes": "Bimanual, tactile, diverse tasks",
  "source": "P05 Table 2"
 },
 {
  "name": "EPIC-KITCHENS",
  "year": 2018,
  "layer": "Human video",
  "size": 55,
  "sizeText": "55",
  "unit": "hours",
  "notes": "Egocentric kitchens; both surveys give 55 hours",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "Something-Something",
  "year": 2017,
  "layer": "Human video",
  "size": 121.5,
  "sizeText": "121.5",
  "unit": "hours",
  "notes": "Exocentric object interactions, 108,499 clips",
  "source": "P06 Table 10"
 },
 {
  "name": "HowTo100M",
  "year": 2019,
  "layer": "Human video",
  "size": 134472,
  "sizeText": "134,472",
  "unit": "hours",
  "notes": "Instructional web video, 136M clips",
  "source": "P06 Table 10"
 },
 {
  "name": "EPIC-KITCHENS-100",
  "year": 2020,
  "layer": "Human video",
  "size": 100,
  "sizeText": "100",
  "unit": "hours",
  "notes": "Egocentric kitchens, 45 environments",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "Kinetics-700",
  "year": 2020,
  "layer": "Human video",
  "size": 1806,
  "sizeText": "1,806",
  "unit": "hours",
  "notes": "Exocentric action clips",
  "source": "P06 Table 10"
 },
 {
  "name": "Ego4D",
  "year": 2021,
  "layer": "Human video",
  "size": 3670,
  "sizeText": "3,670",
  "unit": "hours",
  "notes": "Egocentric, 931 participants, 74 cities",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "Assembly101",
  "year": 2022,
  "layer": "Human video",
  "size": 513,
  "sizeText": "513",
  "unit": "hours",
  "notes": "Ego and exo assembly videos",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "HOI4D",
  "year": 2022,
  "layer": "Human video",
  "size": 7.6,
  "sizeText": "7.6",
  "unit": "hours",
  "notes": "Egocentric hand-object with 3D annotations",
  "source": "P06 Table 10"
 },
 {
  "name": "ARCTIC",
  "year": 2023,
  "layer": "Human video",
  "size": 2.3,
  "sizeText": "2.3",
  "unit": "hours",
  "notes": "Bimanual articulated objects, motion capture",
  "source": "P06 Table 10"
 },
 {
  "name": "HoloAssist",
  "year": 2023,
  "layer": "Human video",
  "size": 166,
  "sizeText": "166",
  "unit": "hours",
  "notes": "HoloLens 2 egocentric, with gaze",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "Ego-Exo4D",
  "year": 2023,
  "layer": "Human video",
  "size": 1286,
  "sizeText": "1,286",
  "unit": "hours",
  "notes": "Paired ego and exo views",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "RH20T-Human",
  "year": 2023,
  "layer": "Human video",
  "size": 100,
  "sizeText": "100",
  "unit": "hours",
  "notes": "Human counterpart to RH20T",
  "source": "P06 Table 10"
 },
 {
  "name": "Panda-70M",
  "year": 2024,
  "layer": "Human video",
  "size": 166800.0,
  "sizeText": "166.8K",
  "unit": "hours",
  "notes": "Web video with captions, 70.8M clips",
  "source": "P06 Table 10"
 },
 {
  "name": "HOT3D",
  "year": 2024,
  "layer": "Human video",
  "size": 13.9,
  "sizeText": "13.9",
  "unit": "hours",
  "notes": "Aria and Quest 3 hand tracking",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "Egocentric-10k",
  "year": 2025,
  "layer": "Human video",
  "size": 10000,
  "sizeText": "10,000",
  "unit": "hours",
  "notes": "Factory egocentric video",
  "source": "P06 Table 10"
 },
 {
  "name": "Egocentric-100k",
  "year": 2025,
  "layer": "Human video",
  "size": 100405,
  "sizeText": "100,405",
  "unit": "hours",
  "notes": "Factory egocentric video, 238 factories",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "HD-EPIC",
  "year": 2025,
  "layer": "Human video",
  "size": 41.3,
  "sizeText": "41.3",
  "unit": "hours",
  "notes": "Aria kitchens with gaze and audio",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "EgoDex",
  "year": 2025,
  "layer": "Human video",
  "size": 829,
  "sizeText": "829",
  "unit": "hours",
  "notes": "Vision Pro hand poses, 338K clips",
  "source": "P06 Table 10; P05 Table 3"
 },
 {
  "name": "UniHand-2.0",
  "year": 2026,
  "layer": "Human video",
  "size": 35000,
  "sizeText": "35,000",
  "unit": "hours",
  "notes": "Egocentric with hand poses",
  "source": "P06 Table 10"
 },
 {
  "name": "Action100M",
  "year": 2026,
  "layer": "Human video",
  "size": 127896,
  "sizeText": "127,896",
  "unit": "hours",
  "notes": "Web video with language, 147M clips",
  "source": "P06 Table 10"
 },
 {
  "name": "Xperience-10M",
  "year": 2026,
  "layer": "Human video",
  "size": 10000,
  "sizeText": "10,000",
  "unit": "hours",
  "notes": "Egocentric with 3D and interaction labels",
  "source": "P05 Table 3"
 },
 {
  "name": "HumanNet",
  "year": 2026,
  "layer": "Human video",
  "size": 967000,
  "sizeText": "967,000",
  "unit": "hours",
  "notes": "Ego and exo, hand poses",
  "source": "P05 Table 3"
 },
 {
  "name": "Robomimic",
  "year": 2021,
  "layer": "Simulation",
  "size": 6000.0,
  "sizeText": "6K",
  "unit": "trajectories",
  "notes": "Eight tasks in MuJoCo",
  "source": "P01 Table 2"
 },
 {
  "name": "VIMA-Bench",
  "year": 2023,
  "layer": "Simulation",
  "size": 600000.0,
  "sizeText": "600K+",
  "unit": "trajectories",
  "notes": "Multimodal prompts, 17 tasks",
  "source": "P01 Table 2"
 },
 {
  "name": "LIBERO",
  "year": 2023,
  "layer": "Simulation",
  "size": 6500.0,
  "sizeText": "6.5K",
  "unit": "trajectories",
  "notes": "130 tasks; lifelong learning benchmark",
  "source": "P01 Table 2"
 },
 {
  "name": "MimicGen",
  "year": 2023,
  "layer": "Simulation",
  "size": 50000.0,
  "sizeText": "50K",
  "unit": "trajectories",
  "notes": "Generated from a few human demos",
  "source": "P05 Table 5"
 },
 {
  "name": "DexMimicGen",
  "year": 2024,
  "layer": "Simulation",
  "size": 21000.0,
  "sizeText": "21K",
  "unit": "trajectories",
  "notes": "Bimanual dexterous generation",
  "source": "P05 Table 5"
 },
 {
  "name": "RoboCasa",
  "year": 2024,
  "layer": "Simulation",
  "size": 100000.0,
  "sizeText": "100K+",
  "unit": "trajectories",
  "notes": "Kitchen scenes, 100 tasks",
  "source": "P01 Table 3"
 },
 {
  "name": "GenManip",
  "year": 2025,
  "layer": "Simulation",
  "size": 200000.0,
  "sizeText": "200K",
  "unit": "trajectories",
  "notes": "Isaac Sim, 200 tasks",
  "source": "P01 Table 2"
 },
 {
  "name": "RoboTwin 2.0",
  "year": 2025,
  "layer": "Simulation",
  "size": 100000.0,
  "sizeText": "100K",
  "unit": "trajectories",
  "notes": "Bimanual, 50 tasks, four arm types",
  "source": "P01 Table 2"
 },
 {
  "name": "RoboVerse",
  "year": 2025,
  "layer": "Simulation",
  "size": 500000.0,
  "sizeText": "500K",
  "unit": "trajectories",
  "notes": "Unified simulators, 276 tasks",
  "source": "P01 Table 3"
 },
 {
  "name": "InternData-A1",
  "year": 2025,
  "layer": "Simulation",
  "size": 637000.0,
  "sizeText": "637K",
  "unit": "trajectories",
  "notes": "7.4K hours, 70 tasks",
  "source": "P05 Table 5"
 },
 {
  "name": "InternData-M1",
  "year": 2025,
  "layer": "Simulation",
  "size": 244000.0,
  "sizeText": "244K",
  "unit": "trajectories",
  "notes": "200 tasks, single arm",
  "source": "P05 Table 5"
 },
 {
  "name": "GR00T-X Sim",
  "year": 2025,
  "layer": "Simulation",
  "size": 345000.0,
  "sizeText": "345K",
  "unit": "trajectories",
  "notes": "NVIDIA; six-plus embodiments, mobile",
  "source": "P05 Table 5"
 },
 {
  "name": "RoboFAC",
  "year": 2025,
  "layer": "Simulation",
  "size": 9440.0,
  "sizeText": "9.44K",
  "unit": "trajectories",
  "notes": "Failure analysis in ManiSkill",
  "source": "P01 Table 4"
 },
 {
  "name": "MolmoB0T",
  "year": 2026,
  "layer": "Simulation",
  "size": 1700000.0,
  "sizeText": "1.7M",
  "unit": "trajectories",
  "notes": "5.8K hours, articulated objects",
  "source": "P05 Table 5"
 },
 {
  "name": "Cornell",
  "year": 2011,
  "layer": "Grasp",
  "size": 8019,
  "sizeText": "8,019",
  "unit": "grasps",
  "notes": "1,035 real images, rectangle grasps",
  "source": "P01 Table 1"
 },
 {
  "name": "Jacquard",
  "year": 2018,
  "layer": "Grasp",
  "size": 1100000.0,
  "sizeText": "1.1M",
  "unit": "grasps",
  "notes": "54K simulated images",
  "source": "P01 Table 1"
 },
 {
  "name": "GraspNet",
  "year": 2020,
  "layer": "Grasp",
  "size": 1200000000.0,
  "sizeText": "~1.2B",
  "unit": "grasps",
  "notes": "Real cluttered scenes, 6-DoF",
  "source": "P01 Table 1"
 },
 {
  "name": "ACRONYM",
  "year": 2021,
  "layer": "Grasp",
  "size": 17700000.0,
  "sizeText": "17.7M",
  "unit": "grasps",
  "notes": "Simulated 6-DoF, 8,872 objects",
  "source": "P01 Table 1"
 },
 {
  "name": "Regrad",
  "year": 2022,
  "layer": "Grasp",
  "size": 100000000.0,
  "sizeText": "100M",
  "unit": "grasps",
  "notes": "Rectangle and 6-DoF, 50K objects",
  "source": "P01 Table 1"
 },
 {
  "name": "DexGraspNet",
  "year": 2023,
  "layer": "Grasp",
  "size": 1320000.0,
  "sizeText": "1.32M",
  "unit": "grasps",
  "notes": "Dexterous; P05 Table 5 dates it 2022",
  "source": "P01 Table 1; P05 Table 5"
 },
 {
  "name": "Grasp-Anything",
  "year": 2024,
  "layer": "Grasp",
  "size": 600000000.0,
  "sizeText": "~600M",
  "unit": "grasps",
  "notes": "Synthetic, language-annotated",
  "source": "P01 Table 1"
 },
 {
  "name": "Grasp-Anything++",
  "year": 2024,
  "layer": "Grasp",
  "size": 10000000.0,
  "sizeText": "10M",
  "unit": "grasps",
  "notes": "Synthetic, language-annotated",
  "source": "P01 Table 1"
 },
 {
  "name": "Grasp-Anything-6D",
  "year": 2024,
  "layer": "Grasp",
  "size": 200000000.0,
  "sizeText": "200M",
  "unit": "grasps",
  "notes": "Synthetic 6-DoF with language",
  "source": "P01 Table 1"
 },
 {
  "name": "Dex1B",
  "year": 2025,
  "layer": "Grasp",
  "size": 1000000000.0,
  "sizeText": "1B",
  "unit": "grasps",
  "notes": "Simulated dexterous grasps",
  "source": "P01 Table 1; P05 Table 5"
 },
 {
  "name": "GraspClutter6D",
  "year": 2025,
  "layer": "Grasp",
  "size": 9300000000.0,
  "sizeText": "9.3B",
  "unit": "grasps",
  "notes": "Real cluttered scenes, 52K images",
  "source": "P01 Table 1"
 },
 {
  "name": "RealVLG-11B",
  "year": 2026,
  "layer": "Grasp",
  "size": 11000000000.0,
  "sizeText": "11B",
  "unit": "grasps",
  "notes": "Real images with language",
  "source": "P01 Table 1"
 },
 {
  "name": "DexGraspNet 2.0",
  "year": 2024,
  "layer": "Grasp",
  "size": 427000000.0,
  "sizeText": "427M",
  "unit": "trajectories",
  "notes": "P05 counts these as trajectories",
  "source": "P05 Table 5"
 },
 {
  "name": "SynGrasp-1B",
  "year": 2025,
  "layer": "Grasp",
  "size": 10000000.0,
  "sizeText": "10M",
  "unit": "trajectories",
  "notes": "P05 counts these as trajectories",
  "source": "P05 Table 5"
 },
 {
  "name": "LLaVA-Instruct-150K",
  "year": 2023,
  "layer": "General",
  "size": 158000.0,
  "sizeText": "158K",
  "unit": "samples",
  "notes": "Image-text instruction data",
  "source": "P05 Table 6"
 },
 {
  "name": "ShareGPT4V",
  "year": 2023,
  "layer": "General",
  "size": 1200000.0,
  "sizeText": "1.2M captions",
  "unit": "samples",
  "notes": "Dense image captions",
  "source": "P05 Table 6"
 },
 {
  "name": "RoboVQA",
  "year": 2023,
  "layer": "General",
  "size": 829500.0,
  "sizeText": "238 h; 829.5K pairs",
  "unit": "samples",
  "notes": "Robot and human video question answering",
  "source": "P05 Table 6"
 },
 {
  "name": "SA-1B",
  "year": 2023,
  "layer": "General",
  "size": 1100000000.0,
  "sizeText": "11M img.; 1.1B masks",
  "unit": "samples",
  "notes": "Promptable segmentation masks",
  "source": "P05 Table 6"
 },
 {
  "name": "RoboPoint",
  "year": 2024,
  "layer": "General",
  "size": 1430000.0,
  "sizeText": "1.43M QA",
  "unit": "samples",
  "notes": "Object, affordance and free-space points",
  "source": "P05 Table 6"
 },
 {
  "name": "LLaVA-OneVision-SI",
  "year": 2024,
  "layer": "General",
  "size": 3200000.0,
  "sizeText": "3.2M",
  "unit": "samples",
  "notes": "Single-image VQA, captions, OCR",
  "source": "P05 Table 6"
 },
 {
  "name": "ShareRobot",
  "year": 2025,
  "layer": "General",
  "size": 1028000.0,
  "sizeText": "51.4K eps.; 1.028M QA",
  "unit": "samples",
  "notes": "Planning, affordance and trajectory labels",
  "source": "P05 Table 6"
 }
];
})();
