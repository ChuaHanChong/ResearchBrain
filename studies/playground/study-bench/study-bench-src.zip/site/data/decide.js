/* Decision guides for Compare → "Which method should I use?" and the compare-page quiz.
   Each guide is grounded in one or two survey sections (see each lede and every leaf's ref).
   Tree format (src/study-bench.js decide): node = { q, why?, a: [{ label, next }] }; leaf = { result, why, ref, href }.
   Questions ask about the reader's problem, never about method names. Every leaf links to a topic or a method in side by side. */
(function () {
  "use strict";
  var RB = window.RB;

  function leaf(result, why, ref, href) { return { result: result, why: why, ref: ref, href: href }; }
  function sbs(id) { return "#compare/sbs/" + id; }
  function topic(id) { return "#explorer/" + id; }

  RB.DECIDE = [
    /* 1 · Policy head: P01 §6.4, X2 §4, P02 §VIII */
    {
      id: "head", short: "Policy head",
      title: "Which action head for imitation learning?",
      lede: "Pick an action head from your demonstrations, your task range and your inference budget. Grounded in P01 §6.4, X2 §4 and P02 §VIII.",
      tree: {
        q: "Does the robot need one skill, or many skills chosen by language instructions?",
        a: [
          { label: "One skill", next: {
            q: "Do your demonstrations solve the task in more than one way?",
            why: "Regression with a mean-squared error averages distinct ways of acting into an action no demonstrator took.",
            a: [
              { label: "One way", next: leaf("ACT: a transformer predicting action chunks",
                "Predicting chunks cuts compounding error; ACT learned fine-grained bimanual tasks on low-cost hardware.",
                "P01 §6.4.2 · X2 §4.2", sbs("act")) },
              { label: "Several ways", next: {
                q: "How much time can each chunk prediction take on your hardware?",
                a: [
                  { label: "Some slack", next: leaf("Diffusion Policy",
                    "Denoising in action space keeps separate modes. X2 reports training from 50–150 demonstrations, and DDIM sampling needs about 10× fewer steps.",
                    "X2 §4.3 · P01 §6.4.3", sbs("diffusion-policy")) },
                  { label: "Very little", next: leaf("Flow matching, or a one-step head such as MP1 or Consistency Policy",
                    "Flow matching learns straighter paths that need fewer steps; distilled and MeanFlow heads generate a chunk in one or a few network evaluations.",
                    "P01 §6.4.3–6.4.4", topic("b2")) }
                ] } }
            ] } },
          { label: "Many skills", next: {
            q: "Can you afford to fine-tune a large pretrained backbone end to end?",
            why: "P02 advises practitioners without a GPU cluster to start with lightweight adaptation.",
            a: [
              { label: "Small budget", next: leaf("A small flow-matching VLA such as SmolVLA, or head-only fine-tuning",
                "Train only the action head with the backbone frozen, or use low-rank adapters (LoRA), before trying full fine-tuning.",
                "P02 §VIII · X2 §5.4", sbs("smolvla")) },
              { label: "Full budget", next: {
                q: "Must the robot run smooth, high-rate continuous control, for example with dexterous contact?",
                a: [
                  { label: "Yes, smooth", next: leaf("Vision-language backbone plus a flow-matching action expert (π0)",
                    "P02 recommends continuous generative actions for precise behavior; π0's action expert outputs whole chunks at up to 50 Hz.",
                    "P02 §VIII, §III · X2 §5.3", sbs("pi0")) },
                  { label: "No, coarse", next: leaf("Autoregressive action tokens compressed with FAST",
                    "FAST applies a discrete cosine transform and byte-pair encoding to each chunk, so an autoregressive model emits far fewer tokens than per-step binning.",
                    "P01 §6.4.8 · P02 §IV", sbs("fast")) }
                ] } }
            ] } }
        ]
      }
    },

    /* 2 · WAM family: P04 §3, §4.5, §7.1 and deployment costs; X1 §7 */
    {
      id: "wam", short: "WAM family",
      title: "Which world action model design?",
      lede: "Choose a world action model (WAM) design from your control-rate budget and the data you hold. Grounded in P04 §3, §7.1 and X1 §7.",
      tree: {
        q: "How quickly must the policy produce each new action chunk?",
        why: "X1 reports DreamZero near 7 Hz after heavy optimization, against 50 Hz for non-generative VLA policies.",
        a: [
          { label: "Slow is fine", next: {
            q: "How should the predicted future be used before the robot moves?",
            a: [
              { label: "Inspect a plan", next: leaf("Render-and-decode: generate a video plan, then decode actions",
                "The future is rendered to pixels, so you can look at it; the video synthesis becomes part of the policy's latency.",
                "P04 §3.1", sbs("unipi")) },
              { label: "Compare candidates", next: leaf("Action-conditioned rollout: propose actions, predict each outcome, act on the best",
                "It counts as a WAM when the predicted consequence decides which action executes.",
                "P04 §2.3, eq. 6", topic("c2")) }
            ] } },
          { label: "Real time", next: {
            q: "Do you have a lot of action-free video beyond your robot demonstrations?",
            a: [
              { label: "Lots of video", next: {
                q: "Will you train one model on video and actions together?",
                a: [
                  { label: "Yes, jointly", next: leaf("Joint video–action model whose video branch can be skipped (UVA, GigaWorld-Policy)",
                    "Future video and actions are learned together, yet at inference the action path bypasses video generation.",
                    "X1 §4.2 · P04 §7.1", sbs("uva")) },
                  { label: "Adapt video model", next: leaf("Latent-only WAM that reads video-model features (VPP)",
                    "Keeps the video-pretrained prior but decodes action before any pixels are rendered, trading visual interpretability for speed.",
                    "P04 §3.2", sbs("vpp")) }
                ] } },
              { label: "Robot data only", next: leaf("Video-generation-free WAM that predicts future features (FLARE)",
                "Future-embedding prediction keeps a predictive training signal without the cost of a video generator.",
                "P04 §3.3 · X1 §4.2", sbs("flare")) }
            ] } }
        ]
      }
    },

    /* 3 · Next data: P05 pyramid (§1) and open challenges (§8) */
    {
      id: "data", short: "Next data",
      title: "What data should I collect next?",
      lede: "Decide which layer of the data pyramid to add next, starting from what your policy gets wrong. Grounded in P05 §1 and §8.",
      tree: {
        q: "What does your current policy get wrong most often?",
        why: "Higher pyramid layers are closer to robot execution; lower layers are cheaper to scale.",
        a: [
          { label: "Imprecise actions", next: {
            q: "Can you collect many hours on the target robot itself?",
            a: [
              { label: "Yes", next: leaf("Real-robot teleoperation",
                "The top layer: recorded actions execute directly on the robot that produced them, paid for in hardware, operators and resets.",
                "P05 §1–2", sbs("droid")) },
              { label: "No", next: {
                q: "Must the demonstrations come from homes or other places the robot cannot reach?",
                a: [
                  { label: "Yes, anywhere", next: leaf("UMI-style handheld gripper demonstrations",
                    "Drops the robot from collection but keeps end-effector and gripper supervision; retargeting to the robot remains.",
                    "P05 §1, §3", sbs("umi")) },
                  { label: "No, lab only", next: leaf("Simulation data and demonstration augmentation (MimicGen)",
                    "Simulation returns executable actions and privileged labels at low marginal cost, but only approximates the physics.",
                    "P05 §1, §5", sbs("mimicgen")) }
                ] } }
            ] } },
          { label: "Never recovers", next: leaf("Failure and recovery data, for example human-gated interventions (Sirius)",
            "P05 lists failure and recovery trajectories among the scarcest signals; interventions during deployment collect them.",
            "P05 §8", sbs("sirius")) },
          { label: "Clumsy hands", next: leaf("Egocentric human video with hand tracking",
            "Human recordings give real physics and dexterous hands; treat them as interaction priors, not exact robot action labels.",
            "P05 §4, §8.5", topic("d2")) },
          { label: "Misjudges contact", next: leaf("Tactile and force data",
            "P05 names large-scale tactile datasets an open challenge: contact state, force and material cues are scarce in current corpora.",
            "P05 §8", topic("e5")) },
          { label: "Novel objects", next: leaf("General vision-language data, co-trained with action data",
            "Web-scale data grounds perception and reasoning, not action, so mix it with action-labeled layers.",
            "P05 §1, §8.6", topic("d1")) }
        ]
      }
    },

    /* 4 · Human video route: P06 §3.5, Table 9 */
    {
      id: "human", short: "Human video",
      title: "How should human videos reach my robot?",
      lede: "Pick a transfer route from human video to robot policy by the bottleneck the video must fix. Grounded in P06 §3.5 and Table 9.",
      tree: {
        q: "What is the main thing your robot lacks that human video should supply?",
        why: "P06 advises picking the highest-level bridge that still resolves the limiting bottleneck.",
        a: [
          { label: "What to do", next: {
            q: "Does the robot already have usable low-level skills or a controller?",
            a: [
              { label: "Yes", next: leaf("Task-oriented transfer: task plans or prompt videos",
                "Task structure transfers well across embodiments; it fails when the robot lacks the primitive skills to ground the plan.",
                "P06 Table 9", sbs("vid2robot")) },
              { label: "No", next: leaf("Add action-level transfer: affordances or latent actions",
                "Routes far from actions fail through under-grounding: the robot understands the task but cannot execute it precisely.",
                "P06 §3.5", topic("d2")) }
            ] } },
          { label: "Visual match", next: {
            q: "Do you want transferred frames you can look at, or compact features?",
            a: [
              { label: "Inspectable frames", next: leaf("Transformed videos: overlay a robot on human frames (Phantom)",
                "Explicit and interpretable; generated frames can carry artifacts, and similar images may still need different actions.",
                "P06 §3.2, Table 9", sbs("phantom")) },
              { label: "Compact features", next: leaf("Visual embeddings pretrained on human video (R3M, VC-1)",
                "Compact and robust to appearance gaps, but may ignore the contact dynamics that decide actions.",
                "P06 §3.2.2, Table 9", sbs("r3m")) }
            ] } },
          { label: "Executable motion", next: {
            q: "Is the target one spatially precise task, or a broad generalist policy?",
            a: [
              { label: "Precise task", next: leaf("Affordance transfer: contact regions, point tracks, hand trajectories",
                "Explicit geometric cues suit precise, few-shot tasks; they break under occlusion or when force matters.",
                "P06 §3.3.1, Table 9", sbs("track2act")) },
              { label: "Generalist policy", next: leaf("Latent-action transfer (LAPA)",
                "Self-supervised action codes scale to in-the-wild video for pretraining, but may capture camera motion and still need robot grounding.",
                "P06 §3.3.2, Table 9", sbs("lapa")) }
            ] } },
          { label: "Contact-rich, risky", next: leaf("Hybrid route: plans, perception, motion priors, then correction",
            "Task plans give structure, observation modules help perception, affordances propose motion, and RL or closed-loop control fixes the residual mismatch.",
            "P06 §3.5", topic("d2")) }
        ]
      }
    },

    /* 5 · Sim-to-real fix by symptom: P08 taxonomy O / A / T / R */
    {
      id: "s2r", short: "Sim-to-real",
      title: "Which sim-to-real fix fits my symptom?",
      lede: "Trace the gap to observation, action, transition or reward, the four parts of the task model, then pick a fix. Grounded in P08 §2–3.",
      tree: {
        q: "Where does the real robot first behave differently from the simulated one?",
        why: "P08 sorts every sim-to-real gap into observation, action, transition or reward.",
        a: [
          { label: "Sees differently", next: {
            q: "Can you collect some unlabeled images from the real cameras?",
            a: [
              { label: "Yes", next: leaf("Observation domain adaptation, for example image translation (RL-CycleGAN)",
                "Align simulated and real feature distributions so the policy sees both domains alike.",
                "P08 §3.1", sbs("rl-cyclegan")) },
              { label: "No real images", next: leaf("Visual domain randomization",
                "Randomize textures, lighting and camera so reality looks like one more variation; a curriculum keeps training stable.",
                "P08 §3.1", sbs("domain-randomization")) }
            ] } },
          { label: "Acts differently", next: {
            q: "Do commands arrive late, or are they coarser than real control allows?",
            a: [
              { label: "Arrive late", next: leaf("Model action delay during training (random-delay MDPs)",
                "Most simulators apply actions instantly; training with delays and action buffers closes that gap.",
                "P08 §3.2", sbs("dcac")) },
              { label: "Too coarse", next: leaf("Bridge action granularity: map discrete sim actions to continuous control",
                "Sim actions are often discretized; subgoal or waypoint models translate them into real low-level commands.",
                "P08 §2.1, §3.2", topic("a4")) }
            ] } },
          { label: "Moves differently", next: {
            q: "How much real-robot data can you use to fix the dynamics?",
            a: [
              { label: "None", next: leaf("Dynamics randomization",
                "Randomize friction, masses and motor torque so the policy covers real conditions without fine-tuning.",
                "P08 §3.3", sbs("dynamics-randomization")) },
              { label: "A few rollouts", next: leaf("Grounded action transformation (GAT)",
                "Learn from real transitions an action transform that makes the simulator behave like the robot.",
                "P08 §3.3", sbs("gat")) },
              { label: "Adapt online", next: leaf("Online adaptation from recent history (RMA)",
                "Encode environment parameters in simulation, then estimate them on the robot from its recent states and actions.",
                "arXiv 2107.04034 · P08 §3.3", sbs("rma")) }
            ] } },
          { label: "Wrong behavior", next: leaf("Reward shaping, or reward code written by a language model (Eureka)",
            "A reward designed in simulation can miss real cases; shape it, or let a language model write and refine it.",
            "P08 §3.4", sbs("eureka")) }
        ]
      }
    },

    /* 6 · Verifier by use: P14 Table 5, §3–5 */
    {
      id: "verifier", short: "Verifier",
      title: "Which verifier for my use?",
      lede: "Choose a verifier by what its score will do. Uses that a policy searches against need stricter checks. Grounded in P14 Table 5 and §3–5.",
      tree: {
        q: "What will the verifier's score be used for?",
        why: "P14: curation and ranking see candidates made without the score; rewards and runtime gates are searched against.",
        a: [
          { label: "Filter demos", next: leaf("Learned curation scores (Demo-SCORE, SCIZOR)",
            "A false positive puts failures into training, so report accuracy split by error type.",
            "P14 Table 5, §4.3", sbs("demo-score")) },
          { label: "Rank policies", next: {
            q: "Can you afford real-robot rollouts for evaluation?",
            a: [
              { label: "Yes", next: leaf("Automated real-robot evaluation (AutoEval)",
                "A learned success classifier and reset policy run evaluation unattended; check its agreement on your robot.",
                "P14 §4.1, Table 6", sbs("autoeval")) },
              { label: "No", next: leaf("Evaluation inside a world model (WorldEval)",
                "Ranks policies from generated rollouts; P14 notes its verifier error was not measured on deployment data.",
                "P14 §4.1, Table 6", sbs("worldeval")) }
            ] } },
          { label: "Training reward", next: {
            q: "Do you need dense progress within an episode, or only a success signal?",
            a: [
              { label: "Dense progress", next: leaf("Progress reward model (Robometer, VLAC)",
                "Frame-level progress gives dense reward, but a searching policy finds wrong-scoring regions, so test for reward hacking.",
                "P14 §4.1, §6.3", sbs("robometer")) },
              { label: "Success only", next: leaf("Rule-based terminal-state predicate",
                "Cheap and repeatable once the state is observable, yet a run can satisfy the final predicate and still fail the task.",
                "P14 §3.2, §6.3", topic("f1")) }
            ] } },
          { label: "Stop bad actions", next: {
            q: "Must the check guarantee a safety property, or flag likely task failure?",
            a: [
              { label: "Guarantee safety", next: leaf("Safety filter with a control barrier function (PNCBF)",
                "An invariance certificate keeps trajectories inside a safe set, but only as credible as its dynamics assumptions.",
                "P14 §3.3", sbs("pncbf")) },
              { label: "Flag failure", next: leaf("Model-intrinsic failure detector (SAFE, FAIL-Detect)",
                "Reads the policy's own features against a conformal threshold; cheap, but a familiar-looking failure can still pass.",
                "P14 §5.1", sbs("safe")) }
            ] } },
          { label: "Pick actions", next: leaf("Best-of-N selection with a learned verifier (RoboMonkey)",
            "Sample candidate actions, score each, and execute the best; latency grows with the number of candidates.",
            "P14 §4.2", sbs("robomonkey")) }
        ]
      }
    },

    /* 7 · Grasp approach: P01 §4.1, Fig. 4 */
    {
      id: "grasp", short: "Grasp",
      title: "Which grasping approach?",
      lede: "Pick a grasping method from your gripper, scene clutter, language target and data. Grounded in P01 §4.1 and Fig. 4.",
      tree: {
        q: "What does the robot grasp with?",
        a: [
          { label: "Parallel gripper", next: {
            q: "Is the target named in language, or is any graspable object fine?",
            a: [
              { label: "Any object", next: {
                q: "What does the scene look like?",
                a: [
                  { label: "Simple, top-down", next: leaf("Planar grasp-rectangle detection (GG-CNN, GR-ConvNet)",
                    "A 5-dimensional rectangle describes a top-down parallel-jaw grasp; small networks run fast enough for closed-loop control.",
                    "P01 §4.1, §3.1", sbs("gg-cnn")) },
                  { label: "Cluttered, 3D", next: leaf("6-DoF grasp generation on point clouds (Contact-GraspNet, AnyGrasp)",
                    "A full 6-degree-of-freedom pose lets the gripper approach from any direction, which matters in clutter.",
                    "P01 §4.1", sbs("contact-graspnet")) },
                  { label: "Transparent objects", next: leaf("Reconstruction-based grasping (GraspNeRF)",
                    "Depth sensors miss transparent or specular surfaces; multiview reconstruction or other sensors recover the geometry.",
                    "P01 §4.1", sbs("graspnerf")) }
                ] } },
              { label: "Named target", next: {
                q: "How much grasp data can you train on?",
                a: [
                  { label: "None, zero-shot", next: leaf("Grasp candidates ranked by a vision-language model (ThinkGrasp, OWG)",
                    "A pretrained grasp model proposes many grasps; a language or vision-language model grounds the target and picks one.",
                    "P01 §4.1, Fig. 4c", sbs("thinkgrasp")) },
                  { label: "Paired examples", next: leaf("Language–vision feature fusion",
                    "Encode text and image together, often with cross-attention, and decode a grasp for the referred object.",
                    "P01 §4.1, Fig. 4b", topic("e1")) },
                  { label: "Large-scale", next: leaf("End-to-end grasp foundation model (GraspVLA, VCoT-Grasp)",
                    "Fine-tune a multimodal model on large grasp datasets; GraspVLA pretrains on the synthetic SynGrasp-1B set.",
                    "P01 §4.1, Fig. 4d", sbs("graspvla")) }
                ] } }
            ] } },
          { label: "Dexterous hand", next: {
            q: "Should the grasp follow an instruction about how to hold the object?",
            a: [
              { label: "Yes", next: leaf("Language-guided dexterous grasping (Grasp as You Say)",
                "Generates hand poses that follow instructions about intent and contact.",
                "P01 §4.1", sbs("grasp-as-you-say")) },
              { label: "No", next: leaf("Generative dexterous grasp synthesis (DexDiffuser)",
                "Hand joint angles are high-dimensional, so generative models such as diffusion sample grasps, trained on sets like DexGraspNet.",
                "P01 §4.1", sbs("dexdiffuser")) }
            ] } }
        ]
      }
    }
  ];

  RB.CMP_QUIZ = [
    { q: "Your demonstrations pass an obstacle on the left or on the right. Which head avoids averaging the two?",
      options: ["Mean-squared-error regression", "A generative head such as diffusion or flow matching", "A larger network with the same loss", "A lower control frequency"],
      correct: 1,
      why: "Regression predicts the mean, which lands between the two ways around. A generative head samples one of them (X2 §4, P01 §6.4.3)." },
    { q: "A world action model must run inside a real-time loop. Which design does P04 find promising?",
      options: ["Render every future frame before each action", "Train with a video objective, skip rendering at inference", "Drop prediction and train a plain VLA", "Add more denoising steps"],
      correct: 1,
      why: "Fast-WAM and GigaWorld-Policy skip future video at inference. P04 §7.1 suggests the video objective can matter more than a rendered forecast." },
    { q: "Why does P14 test a verifier used as a training reward harder than one used to filter demonstrations?",
      options: ["Rewards are cheaper to compute", "The policy searches for inputs where the score is wrong", "Filtering uses human labels only", "Rewards are always rule-based"],
      correct: 1,
      why: "Filtered demonstrations were made without the score, so errors average out. A reward is searched against, and one wrong-scoring region can be exploited (P14 Table 5)." }
  ];
})();
