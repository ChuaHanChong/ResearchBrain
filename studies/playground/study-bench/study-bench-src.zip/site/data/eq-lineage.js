/* Evolution page: hand-written defining equations for lineage nodes (RB.EQ_LINEAGE), read by core/40-evolution.js eqFor().
   House notation (data/symbols.js). \class{sb-new}{…} marks a term that is new relative to the node's first lane parent,
   \class{sb-chg}{…} a term that changed. Sources: each method card's eqs, idea and arch fields (data/methods.json) and the
   surveys (X2 §4–5 for heads and VLAs, P04 §2 eq. 7 and §4.1 eq. 8 for WAMs, P14 eq. 1 for verifiers).
   Simplifications: flow time follows the house convention (τ = 0 noise, τ = 1 clean, target 𝐚 − ε) even where a paper
   writes the reverse; weights, masks and auxiliary terms are dropped where the words say so. Nodes left out have no
   single defining formula (data, hardware or prompting changes) or their card gives too little to write one faithfully. */
(function () {
  "use strict";
  var RB = window.RB;

  /* ---- tiny TeX builders (house symbols) ---- */
  function S(id, t) { return "\\class{sym-" + id + "}{" + t + "}"; }
  function N(t) { return "\\class{sb-new}{" + t + "}"; }
  function C(t) { return "\\class{sb-chg}{" + t + "}"; }
  var o = S("o", "o_t"), a = S("a", "a_t"), A = S("achunk", "\\mathbf{a}_{t:t+H}"), l = S("l", "\\ell"), op = S("op", "o'"),
    z = S("z", "z"), pi = S("pi", "\\pi_\\theta"), ph = S("pihead", "\\pi_\\psi"), p = S("ptheta", "p_\\theta"),
    L = S("L", "\\mathcal{L}"), E = S("E", "\\mathbb{E}"), KL = S("KL", "D_{\\mathrm{KL}}"), tau = S("tau", "\\tau"),
    eps = S("eps", "\\epsilon"), xt = S("x-tau", "\\mathbf{a}^{\\tau}"), v = S("v", "v_\\theta"), en = S("epsnet", "\\epsilon_\\theta"),
    ab = S("abar", "\\bar\\alpha_k"), s = S("s", "s_t"), r = S("r", "r_t"), g = S("gamma", "\\gamma"), Q = S("Q", "Q"),
    V = S("V", "V"), adv = S("adv", "\\hat{A}_t"), rho = S("ratio", "\\rho_t"), J = S("J", "J"), D = S("D", "\\mathcal{D}"),
    xi = S("xi", "\\xi"), qj = S("qj", "q_t"), om = S("omega", "\\omega"), sc = S("score", "S"), Nn = S("N", "N"),
    al = S("alpha-cp", "\\alpha"), H = S("H", "H"), beta = S("beta", "\\beta");
  var noisy = "\\sqrt{" + ab + "}\\," + A + " + \\sqrt{1-" + ab + "}\\," + eps;
  var fmTarget = "(" + A + " - " + eps + ")";
  function k(glyph, meaning) { return { glyph: glyph, meaning: meaning }; }

  RB.EQ_LINEAGE = {
    /* ================================================================ policy heads (X2 §4) */
    "behavior-transformers": {
      tex: a + " = c_{k} + \\delta_{k}(" + o + "),\\quad k \\sim " + pi + "(k \\mid " + S("o", "o_{t-h:t}") + ")",
      words: "Classify the action into one of k-means bins over the observation history, then add a small learned offset for that bin.",
      key: ["a", k("\\(c_k\\)", "k-means bin center"), k("\\(\\delta_k\\)", "per-bin residual offset"), "o", "pi"]
    },
    "act": {
      tex: L + " = \\big\\|" + C(A) + " - \\hat{\\mathbf{a}}_{t:t+H}(" + o + ", " + N(z) + ")\\big\\|_1 + " + N(beta + "\\, " + KL + "\\big(q_\\phi(" + z + " \\mid " + A + ", " + o + ") \\,\\|\\, \\mathcal{N}(0, I)\\big)"),
      words: "Predict the next H actions at once with a style latent z from a conditional VAE; the KL term keeps z near a unit Gaussian.",
      key: ["L", "achunk", "o", "z", "beta", "KL"]
    },
    "diffusion-policy": {
      tex: L + " = " + E + "_{k, " + eps + "}\\big\\|" + eps + " - " + N(en + "\\big(" + noisy + ",\\ k,\\ " + o + "\\big)") + "\\big\\|^2",
      words: "Instead of classifying bins, add noise to a clean demonstrated chunk and train a network to predict that noise.",
      key: ["L", "E", "eps", "epsnet", "abar", "achunk", "o"]
    },
    "vq-bet": {
      tex: L + " = \\mathcal{L}_{\\text{focal}}\\big(" + C("\\text{codes}_{\\text{RVQ}}") + "(" + o + ")\\big) + \\big\\|" + N(A) + " - \\big(\\lfloor " + A + " \\rfloor_{\\text{RVQ}} + \\zeta(" + o + ")\\big)\\big\\|_1",
      words: "Residual vector-quantized codes replace k-means bins and cover whole chunks; an offset head corrects the decoded code.",
      key: ["L", k("RVQ", "residual vector-quantized codebook"), "o", "achunk", k("\\(\\zeta\\)", "offset head")]
    },
    "3d-diffuser-actor": {
      tex: L + " = \\big\\|" + en + "\\big(" + S("o", "o") + ", " + N(l + ",\\ c_{\\text{3D}}") + ",\\ " + C(S("xi", "\\xi") + "^{k}") + ",\\ k\\big) - " + eps + "\\big\\|_1",
      words: "Denoise a whole end-effector trajectory while attending to 3D scene tokens and the instruction. Simplified: location, rotation and gripper terms merged.",
      key: ["L", "epsnet", "o", "l", k("\\(c_{\\text{3D}}\\)", "3D scene feature tokens"), "xi", "eps"]
    },
    "dp3": {
      tex: L + " = \\big\\|" + eps + " - " + en + "\\big(" + noisy + ",\\ k,\\ " + C("v_{\\text{3D}}") + ",\\ " + N(qj) + "\\big)\\big\\|^2",
      words: "The same denoising loss, but conditioned on a compact point-cloud feature and the robot pose instead of images.",
      key: ["L", "eps", "epsnet", "abar", "achunk", k("\\(v_{\\text{3D}}\\)", "compact point-cloud feature"), "qj"]
    },
    "consistency-policy": {
      tex: L + " = " + N("\\alpha\\, d\\big(g_\\theta(\\mathbf{a}^{t \\to s}), g_\\theta(\\mathbf{a}^{u \\to s})\\big)") + " + " + beta + "\\,\\mathcal{L}_{\\text{DSM}}",
      words: "Distill the teacher: two points on the same denoising path must jump to the same clean chunk, so one to three steps suffice.",
      key: ["L", k("\\(g_\\theta\\)", "jump map along the path"), k("\\(d\\)", "pseudo-Huber distance"), "beta", k("DSM", "denoising score matching")]
    },
    "adaflow": {
      tex: L + " = " + E + "\\big\\|" + C(v + "(" + tau + A + " + (1-" + tau + ")" + eps + ",\\ " + tau + ",\\ " + o + ")") + " - " + C(fmTarget) + "\\big\\|^2,\\quad " + N("\\delta_\\tau = \\mathrm{clip}\\big(\\eta / \\sigma_\\phi,\\ [\\delta_{\\min}, 1-" + tau + "]\\big)"),
      words: "Rectified flow regresses a straight noise-to-action velocity; a variance net sets large steps where the flow is certain, often one step.",
      key: ["L", "E", "v", "tau", "achunk", "eps", "o", k("\\(\\sigma_\\phi\\)", "predicted flow variance"), k("\\(\\delta_\\tau\\)", "adaptive step size")]
    },
    "flowpolicy": {
      tex: L + " = \\big\\|f_\\theta(" + xt + ", " + tau + ") - f_{\\theta^-}(\\mathbf{a}^{\\tau+\\Delta}, " + tau + "+\\Delta)\\big\\|^2 + \\alpha\\big\\|" + N(v + "(" + xt + ", " + tau + ") - v_{\\theta^-}(\\mathbf{a}^{\\tau+\\Delta}, " + tau + "+\\Delta)") + "\\big\\|^2",
      words: "Consistency flow matching: neighboring points must agree on the endpoint and velocity, so the flow is straight and one step works. Simplified.",
      key: ["L", k("\\(f_\\theta\\)", "predicted endpoint a^τ + (1−τ)v"), "x-tau", "tau", "v", k("\\(\\theta^-\\)", "slow copy of weights")]
    },
    "onedp": {
      tex: "\\nabla_\\theta " + L + " \\approx " + E + "\\big[\\big(" + N("s_\\phi(\\mathbf{a}^{k})") + " - s_{\\text{teacher}}(\\mathbf{a}^{k})\\big)\\,\\partial \\mathbf{a}^{k} / \\partial\\theta\\big],\\quad \\mathbf{a}^{0} = G_\\theta(" + z + ", " + o + ")",
      words: "A one-step generator is pulled toward the teacher by the difference between two score networks along the diffusion chain.",
      key: ["L", "E", k("\\(s_\\phi\\)", "score of generator samples"), k("\\(s_{\\text{teacher}}\\)", "frozen diffusion policy score"), k("\\(G_\\theta\\)", "one-step generator"), "z", "o"]
    },
    "maniflow": {
      tex: L + " = \\big\\|" + v + "(" + xt + ", " + tau + ") - " + fmTarget + "\\big\\|^2 + " + N("\\big\\|\\hat{\\mathbf{a}}_\\theta(" + xt + ") - \\mathrm{sg}\\,\\hat{\\mathbf{a}}_\\theta(\\mathbf{a}^{\\tau+\\Delta})\\big\\|^2"),
      words: "Keep the flow loss and add a teacher-free consistency term between clean chunks predicted from two flow times, so one or two steps suffice.",
      key: ["L", "v", "x-tau", "tau", "achunk", "eps", k("sg", "stop gradient")]
    },
    "mp1": {
      tex: N("u_\\theta(" + xt + ", r, " + tau + ")") + " = " + v + "(" + xt + ", " + tau + ") - (" + tau + " - r)\\,\\tfrac{d}{d" + tau + "} u_\\theta,\\quad \\mathbf{a}^{1} = \\mathbf{a}^{0} + u_\\theta(\\mathbf{a}^{0}, 0, 1)",
      words: "MeanFlow learns the average velocity over an interval, so a single jump from noise to chunk is exact, without consistency constraints.",
      key: [k("\\(u_\\theta\\)", "average velocity from r to τ"), "x-tau", "tau", "v", k("\\(r\\)", "interval start time")]
    },
    "streaming-flow-policy": {
      tex: "\\tfrac{d" + a + "}{d" + tau + "} = " + v + "(" + a + ", " + tau + " \\mid " + o + "),\\quad " + N("u(" + a + ", " + tau + " \\mid " + xi + ") = \\dot{" + xi + "}(" + tau + ") - k\\big(" + a + " - " + xi + "(" + tau + ")\\big)"),
      words: "Flow time becomes execution time: start near the last action and stream each integrated action; the target velocity pulls back toward the demonstration.",
      key: ["a", "tau", "v", "o", "xi", k("\\(k\\)", "stabilizing gain")]
    },
    "dbpo": {
      tex: L + " = \\big\\|G_\\theta(" + eps + ", " + o + ") - \\mathrm{sg}\\big(G_\\theta + " + N("\\mathbf{V}(G_\\theta)") + "\\big)\\big\\|^2",
      words: "A drifting field attracts samples toward demonstrations and repels them from each other; training absorbs the refinement, so inference takes one evaluation.",
      key: ["L", k("\\(G_\\theta\\)", "one-step action generator"), "eps", "o", k("\\(\\mathbf{V}\\)", "attraction minus repulsion field"), k("sg", "stop gradient")]
    },
    "implicit-drifting-policy": {
      tex: L + " = " + E + "\\,\\big\\|G_\\theta(" + eps + ", " + o + ") - " + a + "\\big\\|^2_{" + C("W(" + o + ")") + "}",
      words: "Simplified: errors are weighted by the spread of expert actions near this observation relative to a global reference, instead of an explicit drifting field.",
      key: ["L", "E", k("\\(G_\\theta\\)", "one-step action generator"), "eps", "o", "a", k("\\(W\\)", "local-to-global geometry weight")]
    },

    /* ================================================================ VLAs (P02 §IV, X2 §5) */
    "gato": {
      tex: L + " = -\\sum_{l=1}^{L} m_l \\log " + p + "(s_l \\mid s_{\\lt l})",
      words: "Serialize text, images and actions into one token sequence and train next-token prediction, scoring only text and action tokens.",
      key: ["L", k("\\(m_l\\)", "mask: text and action only"), "ptheta", k("\\(s_l\\)", "token l of the sequence")]
    },
    "vima": {
      tex: L + " = -\\sum_{t} \\log " + pi + "(" + a + " \\mid " + N("P") + ", \\text{history})",
      words: "Behavior cloning from a multimodal prompt that interleaves text and images, read through cross-attention.",
      key: ["L", "pi", "a", k("\\(P\\)", "interleaved text-image prompt")]
    },
    "rt-1": {
      tex: a + " \\sim " + pi + "\\big(\\cdot \\mid " + N(l) + ", \\{" + S("o", "o_j") + "\\}_{j \\le t}\\big)",
      words: "A real-time robot transformer samples each discretized action from the instruction and recent images, trained on large real data.",
      key: ["a", "pi", "l", "o"]
    },
    "rt-2": {
      tex: L + " = -\\sum_{d} \\log " + C("p_{\\text{VLM}}") + "\\big(\\text{bin}_d \\mid " + o + ", " + l + ", \\text{bin}_{\\lt d}\\big)",
      words: "A web-pretrained VLM writes each action dimension as a text token, co-trained with web data.",
      key: ["L", k("\\(p_{\\text{VLM}}\\)", "web-pretrained vision-language model"), k("bin", "one of 256 action bins"), "o", "l"]
    },
    "open-x-embodiment-rt-x": {
      tex: L + " = -\\sum_{(o,\\ell,a) \\in " + N("\\bigcup_e " + S("D", "\\mathcal{D}_e")) + "} \\log p_{\\text{VLM}}(\\text{bins}(" + S("a", "a") + ") \\mid " + S("o", "o") + ", " + l + ")",
      words: "Same loss, but the data pools many embodiments with a coarsely aligned 7-dimensional end-effector action.",
      key: ["L", "D", "a", "o", "l"]
    },
    "openvla": {
      tex: L + " = -\\sum_{d=1}^{7} \\log p_{\\text{VLM}}\\big(\\text{bin}_d \\mid " + o + ", " + l + ", \\text{bin}_{\\lt d}\\big),\\quad " + C("w = (q_{99} - q_{1})/256"),
      words: "The RT-2 token recipe on an open 7B backbone; bins span the 1st to 99th action quantiles per dimension.",
      key: ["L", "o", "l", k("\\(w\\)", "bin width"), k("\\(q_{99}\\)", "99th action quantile")]
    },
    "octo": {
      tex: L + " = \\big\\|" + eps + " - " + N(en + "\\big(" + noisy + ",\\ e_t,\\ k\\big)") + "\\big\\|^2",
      words: "A small diffusion head denoises the action chunk from a transformer readout embedding, replacing 256-bin tokens.",
      key: ["L", "eps", "epsnet", "abar", "achunk", k("\\(e_t\\)", "transformer readout embedding")]
    },
    "cogact": {
      tex: L + " = " + E + "\\big\\|" + N(en + "\\big(" + noisy + ",\\ k,\\ f_{\\text{cog}}\\big)") + " - " + eps + "\\big\\|^2",
      words: "A diffusion transformer module, conditioned on the VLM's cognition feature, replaces discrete action tokens.",
      key: ["L", "E", "epsnet", "abar", "achunk", "eps", k("\\(f_{\\text{cog}}\\)", "VLM cognition feature")]
    },
    "pi0": {
      tex: L + " = " + E + "_{" + tau + ", " + eps + "}\\big\\|" + N(v + "\\big(" + tau + A + " + (1-" + tau + ")" + eps + ",\\ " + o + ", " + l + "\\big)") + " - " + N(fmTarget) + "\\big\\|^2",
      words: "A flow-matching action expert regresses the velocity from noise to the chunk, replacing discrete action tokens (X2 eq. 52).",
      key: ["L", "E", "tau", "eps", "v", "achunk", "o", "l"]
    },
    "rdt-1b": {
      tex: L + " = \\big\\|" + A + " - " + C("f_\\theta") + "\\big(" + l + ", " + o + ", " + noisy + ", k\\big)\\big\\|^2",
      words: "A 1.2B diffusion transformer predicts the clean chunk, not the noise, over a unified action space.",
      key: ["L", "achunk", k("\\(f_\\theta\\)", "clean-chunk predictor"), "l", "o", "abar", "eps"]
    },
    "openvla-oft": {
      tex: L + " = \\frac{1}{" + H + "D}\\sum_{i,d} \\big|" + N("\\hat{a}_{t+i,d}(" + o + ", " + l + ")") + " - a_{t+i,d}\\big|",
      words: "Decode the whole continuous chunk in one parallel pass and train with L1 regression instead of next-token cross-entropy.",
      key: ["L", "H", k("\\(D\\)", "action dimensions"), "o", "l"]
    },
    "fast": {
      tex: "\\text{tokens} = " + N("\\mathrm{BPE}\\big(\\mathrm{round}(\\gamma \\cdot \\mathrm{DCT}(" + A + "))\\big)"),
      words: "Compress the chunk with a discrete cosine transform per dimension, round, then merge frequent patterns into tokens.",
      key: [k("DCT", "discrete cosine transform"), k("\\(\\gamma\\)", "quantization scale"), "achunk", k("BPE", "byte-pair encoding")]
    },
    "gr00t-n1": {
      tex: L + " = " + E + "\\big\\|" + v + "\\big(" + C("\\varphi_t") + ", " + tau + A + " + (1-" + tau + ")" + eps + ", " + N(qj) + "\\big) - " + fmTarget + "\\big\\|^2",
      words: "A diffusion transformer cross-attends to middle-layer VLM features and the robot state; four Euler steps at inference.",
      key: ["L", "E", "v", k("\\(\\varphi_t\\)", "middle-layer VLM tokens"), "tau", "achunk", "eps", "qj"]
    },
    "pi0-5": {
      tex: pi + "(" + A + ", " + N("\\hat\\ell") + " \\mid " + o + ", " + l + ") = " + pi + "(" + A + " \\mid " + o + ", " + N("\\hat\\ell") + ")\\;" + N(pi + "(\\hat\\ell \\mid " + o + ", " + l + ")"),
      words: "First predict a subtask in text, then actions conditioned on that subtask; FAST tokens in pre-training, a flow expert after.",
      key: ["pi", "achunk", k("\\(\\hat\\ell\\)", "predicted subtask text"), "o", "l"]
    },
    "knowledge-insulation": {
      tex: L + " = -\\log p_\\theta(\\text{FAST}, \\hat\\ell) + \\alpha\\big\\|" + ph + "\\big(" + xt + ", " + N("\\mathrm{sg}") + "(h_{\\text{VLM}})\\big) - " + fmTarget + "\\big\\|^2",
      words: "Train the VLM on tokens and the action expert on flow in one stage; stop-gradient keeps flow gradients out of the VLM (X2 §5.3).",
      key: ["L", "pihead", "x-tau", k("sg", "stop gradient"), k("\\(h_{\\text{VLM}}\\)", "backbone keys and values"), "achunk", "eps"]
    },
    "smolvla": {
      tex: L + " = " + E + "\\big\\|" + v + "\\big(" + xt + ", " + C("h^{(N)}_{\\text{VLM}}") + "\\big) - " + fmTarget + "\\big\\|^2",
      words: "About 7 times smaller: the flow expert reads features from an early VLM layer, trained on community datasets.",
      key: ["L", "E", "v", "x-tau", k("\\(h^{(N)}\\)", "features of VLM layer N"), "achunk", "eps"]
    },
    "pi0-7": {
      tex: "\\max_\\theta\\ " + E + "\\big[\\log " + pi + "\\big(" + A + " \\mid " + S("o", "o_{t-T:t}") + ", " + N("C_t") + "\\big)\\big]",
      words: "Condition on observation history and a rich context C (subtask text, subgoal images, metadata), steered with classifier-free guidance.",
      key: ["E", "pi", "achunk", "o", k("\\(C_t\\)", "context prompt, incl. subgoal image")]
    },

    /* ================================================================ latent actions and human video (P06) */
    "time-contrastive-networks": {
      tex: "\\|f(o^{a}) - f(o^{p})\\|^2 + m \\lt \\|f(o^{a}) - f(o^{n})\\|^2",
      words: "The same moment from another view must embed closer than a nearby moment from the same view, by a margin.",
      key: [k("\\(f\\)", "embedding network"), k("\\(o^{a}, o^{p}\\)", "anchor, same-time other view"), k("\\(o^{n}\\)", "temporal-neighbour negative"), k("\\(m\\)", "margin")]
    },
    "r3m": {
      tex: L + " = \\lambda_1 " + C("\\mathcal{L}_{\\text{time-NCE}}") + " + " + N("\\lambda_2 \\mathcal{L}_{\\text{lang}}(" + l + ")") + " + \\lambda_3 \\|F\\|_1 + \\lambda_4\\|F\\|_2",
      words: "Contrast frames by time on large Ego4D video, align video progress with language, and keep features sparse.",
      key: ["L", k("time-NCE", "closer in time, more similar"), "l", k("\\(F\\)", "visual feature")]
    },
    "vip": {
      tex: N(r + " = S(" + S("o", "o_{t+1}") + "; g) - S(" + o + "; g)") + ",\\quad S(o; g) = -\\|\\phi(o) - \\phi(g)\\|",
      words: "A value-trained embedding makes reward the drop in distance to the goal image between two frames.",
      key: ["r", "o", k("\\(g\\)", "goal image"), k("\\(\\phi\\)", "VIP embedding")]
    },
    "liv": {
      tex: S("r", "r_t") + " = S(" + S("o", "o_{t+1}") + "; " + C("g \\text{ or } \\ell") + ") - S(" + o + "; " + C("g \\text{ or } \\ell") + ")",
      words: "The same progress reward, but the goal can be an image or a language instruction in one shared embedding.",
      key: ["r", "o", k("\\(g\\)", "goal image"), k("\\(\\ell\\)", "language goal")]
    },
    "mvp": {
      tex: L + " = \\big\\|x_{\\text{masked}} - \\mathrm{Dec}\\big(\\mathrm{Enc}(x_{\\text{visible}})\\big)\\big\\|^2",
      words: "Masked autoencoding: hide most image patches and reconstruct them; the frozen encoder then feeds a small control policy.",
      key: ["L", k("\\(x\\)", "image patches")]
    },
    "vc-1": {
      tex: L + " = \\big\\|x_{\\text{masked}} - \\mathrm{Dec}\\big(\\mathrm{Enc}(x_{\\text{visible}})\\big)\\big\\|^2,\\quad x \\sim " + C(S("D", "\\mathcal{D}") + "_{\\text{larger, more diverse}}"),
      words: "Same masked-autoencoder recipe; only the data and model size change.",
      key: ["L", k("\\(x\\)", "image patches"), "D"]
    },
    "voltron": {
      tex: L + " = \\big\\|x_{\\text{masked}} - \\mathrm{Dec}(\\mathrm{Enc}(x_{\\text{visible}}, " + N(l) + "))\\big\\|^2 " + N("- \\alpha \\log p(" + l + " \\mid x)"),
      words: "Condition the reconstruction on language and also generate language from the frames, mixing semantics with spatial detail.",
      key: ["L", k("\\(x\\)", "image patches"), "l"]
    },
    "mimicplay": {
      tex: L + " = -\\log \\sum_{k} \\eta_k\\, \\mathcal{N}(" + N("\\xi^{\\text{hand}}") + " \\mid \\mu_k, \\sigma_k) + \\lambda\\, " + KL + "(Q^{r} \\,\\|\\, Q^{h})",
      words: "A latent planner predicts 3D hand trajectories from human play; a KL term aligns human and robot image features.",
      key: ["L", k("\\(\\eta_k\\)", "mixture weight"), k("\\(\\xi^{\\text{hand}}\\)", "3D hand trajectory"), "KL", k("\\(Q^{r}, Q^{h}\\)", "robot, human feature distributions")]
    },
    "egomimic": {
      tex: L + " = \\mathcal{L}_{\\text{robot}} + " + N("\\mathcal{L}_{\\text{hand}}") + ",\\quad \\mathcal{L}_{\\text{hand}} = \\|\\hat{a}^{p} - a^{p}_{\\text{hand}}\\|_1 + " + KL,
      words: "One end-to-end policy: hand poses from egocentric video supervise the shared pose output alongside robot data.",
      key: ["L", k("\\(a^{p}\\)", "end-effector pose actions"), "KL"]
    },
    "h-rdt": null,
    "lapa": {
      tex: S("z", "z_t") + " = \\arg\\min_{c_k} \\|d_t - c_k\\|,\\quad d_t = e(" + S("o", "o_{t+1}") + ") - e(" + o + "),\\quad " + L + " = \\|" + S("o", "o_{t+1}") + " - \\mathrm{Dec}(" + o + ", " + S("z", "z_t") + ")\\|^2",
      words: "A latent action is the codebook entry nearest the change between frames; a decoder must rebuild the next frame from it.",
      key: ["z", k("\\(c_k\\)", "codebook entry"), k("\\(e\\)", "frame encoder"), "o", "L"]
    },
    "igor": {
      tex: S("z", "z_t") + " = Q\\big(\\mathrm{IDM}(" + o + ", " + S("o", "o_{t+k}") + ")\\big),\\quad " + N("\\hat z_t \\sim " + pi + "(\\cdot \\mid " + o + ", " + l + ")") + ",\\quad " + S("o", "o_{t+k}") + " \\approx " + p + "(" + o + ", " + S("z", "z_t") + ")",
      words: "One discrete latent action space for humans and robots: a policy predicts latents, a world model renders their effect.",
      key: ["z", k("IDM", "inverse dynamics encoder"), "o", "pi", "l", "ptheta"]
    },
    "agibot-world-go-1": {
      tex: pi + "(" + A + ", " + S("z", "z") + " \\mid " + o + ", " + l + ") = " + ph + "(" + A + " \\mid " + S("z", "z") + ", " + o + ")\\;" + N("\\pi_{\\text{latent}}(" + S("z", "z") + " \\mid " + o + ", " + l + ")"),
      words: "Keep an explicit latent planner at inference: predict latent actions first, then decode robot actions from them.",
      key: ["pi", "achunk", "z", "o", "l", "pihead"]
    },
    "villa-x": {
      tex: S("z", "z_t") + " = \\mathrm{IDM}(" + o + ", " + S("o", "o_{t+K}") + "),\\quad " + N("(\\hat q, \\hat a)_{t+1:t+K} = \\text{proprio-FDM}(" + qj + ", " + S("z", "z_t") + ")"),
      words: "A second decoder must predict future robot states and actions from the latent, grounding it in physical motion.",
      key: ["z", k("IDM", "inverse dynamics encoder"), "o", "qj"]
    },
    "univla-2": {
      tex: L + " = \\big\\|" + C("\\mathrm{DINO}(" + S("o", "o_{t+k}") + ")") + " - f\\big(" + C("\\mathrm{DINO}(" + o + ")") + ", " + S("z", "z") + ", " + N(l) + "\\big)\\big\\|^2",
      words: "Predict in DINOv2 feature space and condition on language, so task-irrelevant motion lands in a separate codebook.",
      key: ["L", k("DINO", "frozen DINOv2 features"), "o", "z", "l"]
    },
    "clap": {
      tex: L + " = -\\log \\frac{\\exp\\langle \\phi(" + o + ", " + S("o", "o_{t+k}") + "), \\psi(" + N(A) + ")\\rangle}{\\sum_{j} \\exp\\langle \\phi(" + o + ", " + S("o", "o_{t+k}") + "), \\psi(\\mathbf{a}_j)\\rangle}",
      words: "Contrastively align a visual transition with the robot action chunk's token, so human video gets executable pseudo-actions.",
      key: ["L", k("\\(\\phi\\)", "visual transition encoder"), "o", k("\\(\\psi\\)", "action-token encoder"), "achunk"]
    },

    /* ================================================================ world models (X3, P03) */
    "world-models": {
      tex: P("z_{t+1}", "z_t, h_t, a_t") + ",\\quad " + a + " = W_c\\,[" + S("z", "z_t") + "\\ h_t] + b_c",
      words: "An MDN-RNN predicts the next latent as a Gaussian mixture; a tiny linear controller acts from latent and memory.",
      key: ["ptheta", "z", k("\\(h_t\\)", "RNN memory"), "a", k("\\(W_c\\)", "linear controller weights")]
    },
    "planet": {
      tex: "h_t = f(h_{t-1}, " + S("s", "s_{t-1}") + ", " + S("a", "a_{t-1}") + "),\\quad " + s + " \\sim p(" + s + " \\mid h_t),\\quad " + o + " \\sim p(" + o + " \\mid h_t, " + s + ")",
      words: "A recurrent state-space model splits state into deterministic and stochastic parts, learned jointly and planned with CEM in latent space.",
      key: [k("\\(h_t\\)", "deterministic recurrent state"), "s", "a", "o"]
    },
    "dreamer": {
      tex: N("\\max_\\phi\\ " + E + "\\sum_{\\tau'=t}^{t+" + H + "} V_\\lambda(" + S("s", "s_{\\tau'}") + ")") + ",\\quad V_\\lambda \\text{ from imagined } " + r + " \\text{ and } " + V,
      words: "Learn an actor and critic inside imagined latent rollouts, backpropagating value through the model instead of planning online.",
      key: ["E", "H", "s", "r", "V", k("\\(V_\\lambda\\)", "λ-return mixing k-step returns")]
    },
    "daydreamer": {
      tex: "V^{\\lambda}_t = " + r + " + " + g + "\\big((1-\\lambda) " + V + "(" + S("s", "s_{t+1}") + ") + \\lambda V^{\\lambda}_{t+1}\\big)",
      words: "Same algorithm and λ-return; the change is running it online on four physical robots.",
      key: ["r", "gamma", "V", "s"]
    },
    "td-mpc": {
      tex: L + " = \\sum_{i} \\lambda^{i}\\big(" + N("\\|z'_i - \\mathrm{sg}\\,h(s'_i)\\|^2") + " + (\\hat r_i - " + S("r", "r_i") + ")^2 + (\\hat{" + Q + "}_i - " + Q + "_i^{\\text{target}})^2\\big)",
      words: "Latents are trained to predict reward and value, not pixels; short-horizon planning uses the value for the long tail.",
      key: ["L", k("\\(z'\\)", "predicted next latent"), k("sg", "stop gradient"), "r", "Q"]
    },
    "dreamerv3": {
      tex: L + " = \\beta_{\\text{pred}}\\mathcal{L}_{\\text{pred}} + " + C("\\beta_{\\text{dyn}}\\max\\big(1, " + KL + "[\\mathrm{sg}(q) \\| p]\\big) + \\beta_{\\text{rep}}\\max\\big(1, " + KL + "[q \\| \\mathrm{sg}(p)]\\big)"),
      words: "KL balancing with free bits (and symlog, return scaling) let one fixed configuration work across domains.",
      key: ["L", "KL", k("\\(q, p\\)", "posterior, prior over latents"), k("sg", "stop gradient")]
    },
    "td-mpc2": {
      tex: L + " = \\sum_{i}\\lambda^{i}\\big(\\|z'_i - \\mathrm{sg}\\,h(s'_i)\\|^2 + " + C("\\mathrm{CE}(\\hat r_i, " + S("r", "r_i") + ") + \\mathrm{CE}(\\hat{" + Q + "}_i, " + Q + "_i)") + "\\big)",
      words: "Reward and value become discrete regression with cross-entropy, and latents are normalized, so one model scales across tasks.",
      key: ["L", k("\\(z'\\)", "predicted next latent"), k("CE", "cross-entropy over bins"), "r", "Q"]
    },
    "dino-wm": {
      tex: L + " = \\big\\|" + p + "\\big(" + C("\\mathrm{DINO}(" + S("o", "o_{t-h:t}") + ")") + ", " + S("a", "a_{t-h:t}") + "\\big) - " + C("\\mathrm{DINO}(" + S("o", "o_{t+1}") + ")") + "\\big\\|^2",
      words: "Predict next frozen DINOv2 patch features offline, without rewards; plan by matching the goal's features.",
      key: ["L", "ptheta", k("DINO", "frozen DINOv2 patch features"), "o", "a"]
    },
    "leworldmodel": {
      tex: L + " = \\big\\|" + p + "(" + S("z", "z_t") + ", " + a + ") - " + S("z", "z_{t+1}") + "\\big\\|^2 + " + N("\\lambda\\,\\mathrm{SIGReg}(" + S("z", "z") + ")"),
      words: "Train encoder and predictor end to end with only two terms; SIGReg keeps embeddings Gaussian so they do not collapse.",
      key: ["L", "ptheta", "z", "a", k("SIGReg", "push embeddings toward a Gaussian")]
    },
    "unisim": {
      tex: L + " = \\big\\|" + eps + " - " + en + "\\big(\\text{noisy } " + o + ",\\ k \\mid h_{t-1}, " + S("a", "a_{t-1}") + "\\big)\\big\\|^2",
      words: "An action-conditioned video diffusion model predicts the next observation from history and action, trained on many datasets.",
      key: ["L", "eps", "epsnet", "o", k("\\(h_{t-1}\\)", "observation history"), "a"]
    },
    "cosmos-world-foundation-models": {
      tex: L + " = " + E + "\\big\\|D_\\theta(\\mathbf{x}_0 + \\mathbf{n}; \\sigma) - \\mathbf{x}_0\\big\\|^2",
      words: "A pretrained video world model denoises video latents at noise level σ; robots post-train it on their own data.",
      key: ["L", "E", k("\\(D_\\theta\\)", "denoiser"), k("\\(\\mathbf{x}_0\\)", "clean video latent"), k("\\(\\sigma\\)", "noise level")]
    },
    "genie-envisioner": {
      tex: "v_i = B^{\\text{vis}}_i(v_{i-1}, " + l + "),\\quad " + N("a_i = B^{\\text{act}}_i\\big(a_{i-1}, \\mathrm{CrossAttn}(a_{i-1}, v_i)\\big)"),
      words: "A parallel action branch of transformer blocks reads each video block's features and outputs actions by flow matching.",
      key: [k("\\(B^{\\text{vis}}\\)", "video transformer block"), "l", k("\\(B^{\\text{act}}\\)", "action transformer block")]
    },
    "dreamdojo": {
      tex: op + " \\sim " + p + "\\big(\\cdot \\mid " + o + ", " + N(S("z", "z") + " = \\mathrm{LAM}(" + o + ", " + op + ")") + "\\big)",
      words: "Condition the video world model on continuous latent actions learned from human video, then post-train on a target robot.",
      key: ["op", "ptheta", "o", "z", k("LAM", "latent action model")]
    },
    "v-jepa-2": {
      tex: L + " = \\big\\|P_\\phi\\big((" + a + ", " + s + ", E(" + o + "))_{\\le k}\\big) - E(" + S("o", "o_{k+1}") + ")\\big\\|_1",
      words: "Predict the next frame's features from actions, states and frozen video features; plan by optimizing actions toward a goal embedding.",
      key: ["L", k("\\(P_\\phi\\)", "action-conditioned predictor"), "a", "s", k("\\(E\\)", "frozen video encoder"), "o"]
    },

    /* ================================================================ world action models (P04, X1) */
    "unipi": {
      tex: S("op", "o'_{1:H}") + " \\sim " + p + "(\\cdot \\mid " + o + ", " + l + "),\\quad " + S("a", "a_{1:H}") + " = " + ph + "(" + o + ", " + S("op", "o'_{1:H}") + ")",
      words: "Generate a video plan from the image and instruction, then read actions off it with inverse dynamics (P04 §3.1).",
      key: ["op", "ptheta", "o", "l", "a", "pihead"]
    },
    "avdc": {
      tex: S("op", "o'_{1:H}") + " \\sim " + p + "(\\cdot \\mid " + o + ", " + l + "),\\quad " + C("T_t = \\arg\\min_{T} \\textstyle\\sum_i \\|u^{i}_t - \\mathrm{proj}(K T x_i)\\|^2"),
      words: "Replace the action-labeled inverse model with optical flow and depth: solve for the rigid object motion that matches the video.",
      key: ["op", "ptheta", "o", "l", k("\\(T_t\\)", "rigid object transform"), k("\\(u^{i}_t\\)", "flow-tracked pixel")]
    },
    "susie": {
      tex: C(S("op", "o'") + " \\sim " + p + "(\\cdot \\mid " + o + ", " + l + ")") + ",\\quad " + a + " \\sim " + ph + "(\\cdot \\mid " + o + ", " + S("op", "o'") + ")",
      words: "An image-editing model proposes one subgoal image, not a video; a goal-conditioned policy reaches it.",
      key: ["op", "ptheta", "o", "l", "a", "pihead"]
    },
    "gr-1": {
      tex: "\\pi(" + l + ", " + S("o", "o_{t-h:t}") + ", " + S("s", "s_{t-h:t}") + ") \\to " + S("op", "o_{t+\\Delta t}") + ",\\ " + a + ",\\qquad " + L + " = \\mathcal{L}_{\\text{arm}} + \\mathcal{L}_{\\text{grip}} + \\mathcal{L}_{\\text{video}}",
      words: "One autoregressive transformer, pretrained on video, predicts the future frame and the current action together (P04 eq. 7).",
      key: ["l", "o", "s", "op", "a", "L"]
    },
    "vpp": {
      tex: A + " = " + ph + "\\big(" + C("F_p(" + o + ", " + l + ")") + "\\big),\\quad F_p = \\text{one-pass video-diffusion features}",
      words: "Act on features from a single denoising pass of a video model, never finishing the video (Latent-Only, P04 §3.2).",
      key: ["achunk", "pihead", k("\\(F_p\\)", "predictive video features"), "o", "l"]
    },
    "pad": {
      tex: L + " = \\lambda_I \\mathcal{L}^{I}_{\\text{diff}} + " + N("\\lambda_A \\mathcal{L}^{A}_{\\text{diff}}") + " + \\lambda_E \\mathcal{L}^{E}_{\\text{diff}}",
      words: "One diffusion transformer denoises the future image, the action and depth together, sharing representations.",
      key: ["L", k("\\(I, A, E\\)", "image, action, depth"), k("\\(\\lambda\\)", "loss weights")]
    },
    "seer": {
      tex: S("op", "\\hat o_{t+n}") + " = f_{\\text{fore}}(" + l + ", h_t),\\quad " + N(S("achunk", "\\hat{\\mathbf{a}}_{t:t+n}") + " = f_{\\text{inv}}(" + l + ", h_t, \\hat o^{\\,\\text{latent}}_{t+n})"),
      words: "The action head attends to the predicted foresight latent, and both are trained end to end.",
      key: ["op", "l", k("\\(h_t\\)", "history features"), "achunk"]
    },
    "gr-2": {
      tex: "\\pi(" + l + ", " + S("o", "o_{t-h:t}") + ", " + S("s", "s_{t-h:t}") + ") \\to " + S("op", "o_{t+1}") + ",\\ " + C(A),
      words: "Scale video pretraining from 0.8M to 38M clips and output an action trajectory instead of one action.",
      key: ["l", "o", "s", "op", "achunk"]
    },
    "uva": {
      tex: L + " = " + C("\\mathcal{L}_{\\text{action}}(Z) + \\mathcal{L}_{\\text{video}}(Z)") + ",\\quad Z = \\text{joint video-action latent}",
      words: "One latent feeds two separate diffusion heads, so actions can be decoded without generating video.",
      key: ["L", k("\\(Z\\)", "joint video-action latent")]
    },
    "uwm": {
      tex: L + " = " + E + "\\big[w_a\\|\\epsilon^{\\theta}_a - \\epsilon_a\\|^2 + w_{o'}\\|\\epsilon^{\\theta}_{o'} - \\epsilon_{o'}\\|^2\\big],\\quad " + N("k_a, k_{o'} \\text{ sampled independently}"),
      words: "Separate diffusion timesteps for action and next frame: one model becomes policy, world model or inverse dynamics at inference.",
      key: ["L", "E", k("\\(\\epsilon_a, \\epsilon_{o'}\\)", "action and next-frame noise"), k("\\(k_a, k_{o'}\\)", "action and video timesteps")]
    },
    "flare": {
      tex: L + " = \\mathcal{L}_{\\text{fm}} + " + N("\\lambda\\,\\mathcal{L}_{\\text{align}}") + ",\\quad \\mathcal{L}_{\\text{align}} = -\\cos\\big(f_\\theta(\\cdot), g(" + S("o", "o_{t+H}") + ")\\big)",
      words: "Align hidden future tokens with an embedding of the future observation instead of generating frames (Video-Generation-Free, P04 §3.3).",
      key: ["L", k("\\(f_\\theta\\)", "future-token activations"), k("\\(g\\)", "frozen future-frame encoder"), "o"]
    },
    "worldvla": {
      tex: L + " = \\mathcal{L}_{\\text{action}} + " + N("\\alpha\\,\\mathcal{L}_{\\text{world}}") + ",\\quad " + o + " \\sim f_\\phi(\\cdot \\mid " + S("o", "o_{t-h:t-1}") + ", " + S("a", "a_{t-h:t-1}") + ")",
      words: "A discrete-token VLA also predicts the next image from past actions; both are cross-entropy on tokens.",
      key: ["L", "o", "a"]
    },
    "motus": {
      tex: p + "\\big(" + S("op", "o_{t+1:t+k}") + ", " + S("a", "a_{t+1:t+k}") + " \\mid " + o + ", " + l + "\\big)\\ \\text{with}\\ " + N("(\\tau_o, \\tau_a)") + "\\ \\text{chosen per mode}",
      words: "Built on pretrained video and VLM experts; fixing one modality's noise level picks policy, world model, inverse dynamics or video generation.",
      key: ["ptheta", "op", "a", "o", "l", k("\\(\\tau_o, \\tau_a\\)", "video and action noise levels")]
    },
    "cosmos-policy": {
      tex: p + "\\big(" + a + ", " + S("s", "s'") + ", " + N(V + "(" + S("s", "s'") + ")") + " \\mid " + s + "\\big)",
      words: "A pretrained video model where actions and values are injected as latent frames: policy, world model and value in one.",
      key: ["ptheta", "a", "s", "V"]
    },
    "dreamzero": {
      tex: p + "(" + S("op", "o_{l:l+H}") + ", " + S("a", "a_{l:l+H}") + " \\mid \\cdot) = " + p + "(" + S("op", "o_{l:l+H}") + " \\mid \\cdot)\\; " + C(ph + "(" + S("a", "a_{l:l+H}") + " \\mid " + S("o", "o_{0:l+H}") + ")"),
      words: "Autoregressive, chunk-by-chunk joint video-action flow at 14B scale; actions act as inverse dynamics on the imagined video.",
      key: ["ptheta", "op", "a", "pihead", "o"]
    },
    "lingbot-va": {
      tex: L + " = \\mathcal{L}_{\\text{dyn}}\\big(" + S("z", "z_{t+1}") + " \\mid " + C("\\tilde z_{\\le t}, a_{\\lt t}") + "\\big) + \\lambda\\,\\mathcal{L}_{\\text{inv}}\\big(" + a + " \\mid \\tilde z_{\\le t+1}\\big)",
      words: "Causal interleaving of video and action latents with a key-value cache of history, so the model reacts step by step.",
      key: ["L", "z", k("\\(\\tilde z\\)", "noise-augmented history latents"), "a"]
    },
    "fast-wam": {
      tex: C(p + "(" + A + " \\mid " + o + ", " + l + ") = " + p + "(" + A + " \\mid z(" + o + ", " + l + "))") + "\\quad \\text{vs.}\\quad \\int p(v_{1:T} \\mid " + o + ", " + l + ")\\, p(" + A + " \\mid v_{1:T})\\, dv",
      words: "Act from a single-pass latent shaped by video co-training instead of integrating over imagined videos (P04 §3.2).",
      key: ["ptheta", "achunk", "o", "l", k("\\(z(o,\\ell)\\)", "one-pass world latent"), k("\\(v_{1:T}\\)", "imagined future video")]
    },

    /* ================================================================ reinforcement learning (X2 §3, P07) */
    "dqn": {
      tex: L + " = " + E + "\\big[(" + S("r", "r") + " + " + g + "\\max_{a'} " + Q + "_{\\theta^-}(s', a') - " + Q + "_\\theta(" + S("s", "s") + ", " + S("a", "a") + "))^2\\big]",
      words: "Regress Q-values from pixels onto one-step Bellman targets computed with older weights.",
      key: ["L", "E", "r", "gamma", "Q", "s", "a"]
    },
    "ddpg": {
      tex: "\\nabla " + J + " \\approx " + E + "\\big[" + N("\\nabla_a " + Q + "(" + S("s", "s") + ", a)\\big|_{a=\\mu(s)}\\,\\nabla_\\theta \\mu_\\theta(s)") + "\\big]",
      words: "A deterministic actor follows the critic's action gradient, so continuous actions need no discretization.",
      key: ["J", "E", "Q", "s", k("\\(\\mu_\\theta\\)", "deterministic actor")]
    },
    "qt-opt": {
      tex: Q + "_T = " + S("r", "r") + " + " + g + " \\min_{i=1,2} " + Q + "_{\\bar\\theta_i}\\big(s', " + N("\\mathrm{CEM}\\arg\\max_{a'}") + " " + Q + "_{\\bar\\theta_1}(s', a')\\big)",
      words: "Closed-loop grasping Q-learning; the maximizing action is found by cross-entropy method search.",
      key: ["Q", "r", "gamma", k("CEM", "cross-entropy method search")]
    },
    "sac": {
      tex: J + "(\\pi) = \\sum_t " + E + "\\big[" + S("r", "r(s_t, a_t)") + " + " + N("\\alpha\\,\\mathcal{H}(\\pi(\\cdot \\mid " + s + "))") + "\\big]",
      words: "Maximize reward plus policy entropy with a stochastic actor, which makes off-policy learning stable.",
      key: ["J", "E", "r", k("\\(\\mathcal{H}\\)", "policy entropy"), "s"]
    },
    "rlpd": {
      tex: "y = " + S("r", "r") + " + " + g + "\\min_{i \\in " + N("\\mathcal{Z}") + "} " + Q + "_{\\theta'_i}(s', \\tilde a'),\\quad \\text{batch} = " + N("\\tfrac12 " + S("D", "\\mathcal{D}") + "_{\\text{offline}} + \\tfrac12 " + S("D", "\\mathcal{D}") + "_{\\text{online}}"),
      words: "Sample offline and online data equally per batch; a random ensemble subset and layer norm stop Q-values from over-extrapolating.",
      key: ["r", "gamma", k("\\(\\mathcal{Z}\\)", "random ensemble subset"), "Q", "D"]
    },
    "serl": {
      tex: "\\mathcal{L}_Q = \\big(" + Q + "_\\phi(s,a) - (" + S("r", "r(s)") + " + " + g + " " + Q + "_{\\bar\\phi}(s', a'))\\big)^2,\\quad " + N("r(s) = \\log p(\\text{success} \\mid s)"),
      words: "The same critic, packaged with a learned success classifier as reward, resets and compliant control for real robots.",
      key: ["Q", "r", "gamma"]
    },
    "hil-serl": {
      tex: "\\mathcal{L}_Q = \\big(" + Q + "_\\phi(s,a) - (" + S("r", "r") + " + " + g + " " + Q + "_{\\bar\\phi}(s', a'))\\big)^2,\\quad (s,a) \\sim " + N(S("D", "\\mathcal{D}") + "_{\\text{demo}} \\cup " + S("D", "\\mathcal{D}") + "_{\\text{interv}}") + " \\text{ and online}",
      words: "Human corrections during training enter both replay buffers, so precise, dynamic skills are learned in hours.",
      key: ["Q", "r", "gamma", "D"]
    },
    "conrft": {
      tex: "\\mathcal{L}_\\pi = -" + C("\\eta") + "\\, " + Q + "\\big(s, \\pi_\\theta(s)\\big) + " + beta + "\\, " + N("\\mathcal{L}_{\\text{consistency-BC}}"),
      words: "Fine-tune a pretrained VLA with a consistency-policy loss; the weight shifts from imitation offline to Q-learning online.",
      key: [k("\\(\\eta\\)", "Q-term weight"), "Q", "beta"]
    },
    "recap": {
      tex: "\\min_\\theta " + E + "\\big[-\\log " + pi + "(" + a + " \\mid " + o + ", " + l + ") - \\alpha \\log " + pi + "(" + a + " \\mid " + N("I_t") + ", " + o + ", " + l + ")\\big],\\ I_t = \\mathbb{1}(" + adv + " \\gt \\epsilon_\\ell)",
      words: "Train a value function, then condition the flow VLA on whether each action had positive advantage; at test time ask for good actions.",
      key: ["E", "pi", "a", "o", "l", k("\\(I_t\\)", "positive-advantage indicator"), "adv"]
    },
    "ppo": {
      tex: J + " = " + E + "_t\\big[\\min\\big(" + rho + " " + adv + ",\\ \\mathrm{clip}(" + rho + ", 1-\\epsilon, 1+\\epsilon)\\, " + adv + "\\big)\\big]",
      words: "Clip the probability ratio so one update cannot move the policy far from the one that collected the data.",
      key: ["J", "E", "ratio", "adv", k("\\(\\epsilon\\)", "clip range, e.g. 0.2")]
    },
    "dppo": {
      tex: rho + " = \\prod_{k} " + N("\\frac{" + pi + "(\\mathbf{a}^{k-1} \\mid \\mathbf{a}^{k}, " + s + ")}{\\pi_{\\text{old}}(\\mathbf{a}^{k-1} \\mid \\mathbf{a}^{k}, " + s + ")}"),
      words: "Treat each denoising step as a Gaussian action in an inner decision process, so PPO's ratio runs through the chain.",
      key: ["ratio", "pi", "s"]
    },
    "simplevla-rl": {
      tex: N(adv + " = \\frac{" + S("r", "r_i") + " - \\mathrm{mean}(r_{1:G})}{\\mathrm{std}(r_{1:G})}") + ",\\quad " + S("r", "r_i") + " \\in \\{0, 1\\}",
      words: "GRPO with a binary task-success reward: each rollout is scored against its group, then a clipped PPO update follows.",
      key: ["adv", "r", k("\\(G\\)", "rollouts per group")]
    },
    "domain-randomization": {
      tex: "\\min_\\theta\\ " + E + "_{" + om + " \\sim P(" + om + ")}\\big[" + L + "(\\theta;\\ \\text{sim}(" + om + "))\\big]",
      words: "Train across many randomized simulator settings so the real world looks like one more sample.",
      key: ["E", "omega", "L"]
    },
    "adr-solving-rubik-s-cube": {
      tex: N("P_\\phi(" + om + ") = \\prod_i U(\\phi^{L}_i, \\phi^{H}_i)") + ",\\quad \\bar p \\ge t_H \\Rightarrow \\text{widen},\\ \\bar p \\le t_L \\Rightarrow \\text{narrow}",
      words: "Each parameter range grows when the policy does well at its boundary and shrinks when it does badly.",
      key: ["omega", k("\\(U\\)", "uniform range"), k("\\(\\bar p\\)", "boundary performance")]
    },
    "teacher-student-terrain": {
      tex: L + " = \\big(\\bar a_t(" + o + ", x_t) - " + a + "(" + o + ", H)\\big)^2 + \\big(\\bar l_t(" + o + ", x_t) - l_t(H)\\big)^2",
      words: "A student using proprioceptive history imitates a teacher with privileged terrain information and rebuilds its latent.",
      key: ["L", "o", k("\\(x_t\\)", "privileged terrain state"), "a", k("\\(H\\)", "proprioceptive history")]
    },
    "rma": {
      tex: a + " = \\pi(x_t, " + S("a", "a_{t-1}") + ", " + S("z", "z_t") + "),\\quad " + N(S("z", "\\hat z_t") + " = \\phi(x_{t-k:t-1}, " + S("a", "a_{t-k:t-1}") + ")"),
      words: "An adaptation module estimates the environment latent from recent states and actions, replacing privileged information at deployment.",
      key: ["a", k("\\(x_t\\)", "robot state"), "z", k("\\(\\phi\\)", "adaptation module")]
    },
    "asap": {
      tex: S("s", "s_{t+1}") + " = f^{\\text{sim}}\\big(" + s + ", " + a + " + " + N("\\pi^{\\Delta}(" + s + ", " + a + ")") + "\\big)",
      words: "A learned residual action makes the simulator reproduce real motions; the tracking policy is then fine-tuned there.",
      key: ["s", "a", k("\\(\\pi^{\\Delta}\\)", "delta action model")]
    },

    /* ================================================================ grasping (only where the card's formula needs rewriting) */
    "graspvla": {
      tex: L + " = " + N("-\\log " + p + "(y_{\\text{bbox}}, y_{\\text{grasp}} \\mid " + o + ", " + l + ")") + " + \\big\\|" + v + "\\big(" + xt + ", " + o + ", y_{\\text{bbox}}, y_{\\text{grasp}}\\big) - (" + A + " - " + eps + ")\\big\\|^2",
      words: "The VLM first writes a box and grasp pose as tokens (grasp only on synthetic data), then a flow expert outputs the chunk.",
      key: ["L", "ptheta", k("\\(y_{\\text{bbox}}, y_{\\text{grasp}}\\)", "box and grasp-pose tokens"), "o", "l", "v", "x-tau", "achunk", "eps"]
    },

    /* ================================================================ verifiers and monitors (P14) */
    "saycan": {
      tex: "\\pi^{*} = \\arg\\max_{\\pi \\in \\Pi}\\ p(c_\\pi \\mid " + S("s", "s") + ", \\ell_\\pi)\\, p(\\ell_\\pi \\mid i)",
      words: "Pick the skill that the language model finds useful and the value function says can succeed now.",
      key: [k("\\(c_\\pi\\)", "skill completes"), "s", k("\\(\\ell_\\pi\\)", "skill description"), k("\\(i\\)", "user instruction")]
    },
    "knowno": {
      tex: C("C(x) = \\{y : \\hat f(x)_y \\ge 1 - \\hat q\\}") + ",\\quad P\\big(y \\in C(x)\\big) \\ge 1 - " + al,
      words: "Conformal prediction builds a set of plausible options; ask a human for help when the set has more than one.",
      key: [k("\\(C(x)\\)", "prediction set"), k("\\(\\hat q\\)", "calibrated threshold"), "alpha-cp"]
    },
    "v-gps": {
      tex: a + " \\sim \\mathrm{Softmax}\\big(" + Q + "(" + s + ", a_1)/\\beta, \\dots, " + Q + "(" + s + ", a_" + S("N", "K") + ")/\\beta\\big)",
      words: "A value function from offline RL re-ranks K samples of a frozen generalist policy.",
      key: ["a", "Q", "s", "N", k("\\(\\beta\\)", "temperature")]
    },
    "sentinel": {
      tex: "\\eta_t = \\sum_{i} \\hat D\\big(\\bar\\pi_{ik}, \\tilde\\pi_{(i+1)k}\\big) \\gt \\gamma_{" + al + "} \\Rightarrow \\text{alarm}",
      words: "Sum how much overlapping action predictions disagree over time; a conformal threshold bounds false alarms.",
      key: [k("\\(\\hat D\\)", "MMD between action batches"), "alpha-cp"]
    },
    "gvl": {
      tex: "v_{\\tilde 1}, \\dots, v_{\\tilde T} = \\mathrm{VLM}\\big(" + S("o", "o_{\\tilde 1}") + ", \\dots, " + S("o", "o_{\\tilde T}") + ";\\ " + l + ", " + S("o", "o_1") + "\\big)",
      words: "A VLM assigns progress to shuffled frames, which forces it to judge each frame rather than follow order.",
      key: [k("\\(v\\)", "predicted task progress"), "o", "l"]
    },
    "robomonkey": {
      tex: a + " = \\arg\\max_{\\tilde a^{i},\\ i \\le " + Nn + "}\\ " + C(sc + "_\\phi(\\tilde a^{i}, " + s + ", " + l + ")"),
      words: "Sample N actions, score each with a VLM verifier trained on synthetic preferences, and execute the best.",
      key: ["a", "N", "score", "s", "l"]
    },
    "rover": {
      tex: a + " = \\arg\\max_{i}\\ " + sc + "_\\phi(\\tilde a^{i}),\\quad " + N("\\tilde a^{i} = a_0 + \\eta_i\\, d_\\phi(a_0, " + s + ")"),
      words: "A 0.2B verifier also predicts a direction toward better actions, and candidates are expanded along it.",
      key: ["a", "score", k("\\(d_\\phi\\)", "predicted improvement direction"), "s"]
    },
    "mg-select": {
      tex: a + " = \\arg\\max_{i \\le " + Nn + "}\\ " + C(KL + "\\big(p(\\cdot \\mid a^{i}, " + o + ", " + l + ") \\,\\|\\, p(\\cdot \\mid a^{i}, \\text{masked})\\big)"),
      words: "Use the VLA's own confidence: prefer the candidate whose token distribution differs most from a masked-input reference.",
      key: ["a", "N", "KL", "o", "l"]
    },
    "fail-detect": {
      tex: N("\\|O_t + f_\\theta(O_t, 0)\\|^2") + " \\gt \\mu_t + h\\, s_t^{\\text{cal}} \\Rightarrow \\text{failure}",
      words: "A flow model maps observation embeddings to noise; a large noise norm means unusual, judged against a time-varying conformal band.",
      key: [k("\\(O_t\\)", "observation embedding"), k("\\(f_\\theta\\)", "flow to Gaussian noise"), k("\\(\\mu_t, s_t\\)", "calibration mean and spread")]
    },
    "safe": {
      tex: C("f(e_{0:t}) = \\sum_{\\tau'=1}^{t} \\sigma\\big(g(e_{\\tau'})\\big)") + " \\gt \\text{threshold}_t",
      words: "A multitask probe on the VLA's internal features accumulates a failure score and works on unseen tasks.",
      key: [k("\\(e_t\\)", "VLA internal feature"), k("\\(\\sigma\\)", "sigmoid")]
    },
    "fiper": {
      tex: F("\\eta_O \\gt \\gamma_{O,t} \\wedge " + N("\\eta_A \\gt \\gamma_{A,t}")),
      words: "Alarm only when observation novelty and action-chunk entropy both exceed their conformal thresholds.",
      key: [k("\\(\\eta_O\\)", "windowed observation novelty"), k("\\(\\eta_A\\)", "action-chunk entropy")]
    },
    "world-action-verifier": {
      tex: p + "(" + S("s", "s_{t+1}") + " \\mid " + s + ", " + a + ") \\propto \\underbrace{p(" + S("s", "s_{t+1}") + " \\mid " + s + ")}_{\\text{state}}\\ \\underbrace{p(" + a + " \\mid " + s + ", " + S("s", "s_{t+1}") + ")}_{\\text{action}}",
      words: "Check a world model by splitting a prediction into a plausible next state and whether the action can reach it.",
      key: ["ptheta", "s", "a"]
    },
    "foresight": {
      tex: "\\text{fail}_t = D_\\psi\\big(" + C(S("z", "\\hat z_{t+1:t+H}") + " \\sim " + p + "(\\cdot \\mid " + S("z", "z_t") + ", " + A + ")") + "\\big) \\gt \\text{threshold}_t",
      words: "Feed a world model's predicted latents for the committed chunk into a causal detector trained on success and failure labels.",
      key: [k("\\(D_\\psi\\)", "causal failure detector"), "z", "ptheta", "achunk"]
    },
    "tri-info": {
      tex: C("\\big(H(A_t),\\ I(A_t; A_{t+1}),\\ I(S_t, S_{t+1}; A_t)\\big)"),
      words: "Action diversity, temporal consistency and action-state coupling are information measures that transfer across VLAs.",
      key: [k("\\(H\\)", "entropy"), k("\\(I\\)", "mutual information")]
    }
  };
  function P(x, c) { return p + "(" + x + " \\mid " + c + ")"; }
  function F(t) { return "\\mathbb{1}\\big(" + t + "\\big)"; }
  /* drop placeholders */
  Object.keys(RB.EQ_LINEAGE).forEach(function (id) { if (!RB.EQ_LINEAGE[id]) delete RB.EQ_LINEAGE[id]; });
})();
