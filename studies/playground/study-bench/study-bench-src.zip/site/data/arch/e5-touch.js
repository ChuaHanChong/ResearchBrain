/* Architecture specs, topic E5 (touch and force in robot learning). Numbers from the papers and the official code; see sources. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ Reactive Diffusion Policy */
  RB.arch.spec({
    id: "reactive-diffusion-policy", method: "reactive-diffusion-policy", name: "Reactive Diffusion Policy", year: 2025, parent: "diffusion-policy",
    diffRows: ["head", "output", "cond", "steps", "chunk", "rate", "latency", "train"],
    figRef: "Xue et al. Fig. 6 · §IV · App. C, F, I", prov: "peeling config (GelSight PCA)",
    lede: "A slow latent diffusion policy plans an action chunk in a compressed latent space at 1–2 Hz. A tiny GRU decoder turns that latent into actions at 24 Hz, reading the newest tactile or wrench signal at every step.",
    sources: {
      p1: { kind: "paper", ref: "Xue et al. 2025, §IV-A/B and Fig. 6", url: "https://arxiv.org/abs/2503.02881" },
      p2: { kind: "paper", ref: "Xue et al. 2025, App. F and App. I, Table VII", url: "https://arxiv.org/abs/2503.02881" },
      p3: { kind: "paper", ref: "Xue et al. 2025, Table I (inference time)", url: "https://arxiv.org/abs/2503.02881" },
      p4: { kind: "paper", ref: "Xue et al. 2025, App. C, D, G (PCA, data, ablations)", url: "https://arxiv.org/abs/2503.02881" },
      c1: { kind: "code", repo: "xiaoxiaoxh/reactive_diffusion_policy", path: "reactive_diffusion_policy/model/vae/model.py", commit: "824c5e8", url: "https://github.com/xiaoxiaoxh/reactive_diffusion_policy/blob/824c5e8/reactive_diffusion_policy/model/vae/model.py" },
      c2: { kind: "code", repo: "xiaoxiaoxh/reactive_diffusion_policy", path: "reactive_diffusion_policy/config/at/at_peel.yaml", commit: "824c5e8", url: "https://github.com/xiaoxiaoxh/reactive_diffusion_policy/blob/824c5e8/reactive_diffusion_policy/config/at/at_peel.yaml" },
      c3: { kind: "code", repo: "xiaoxiaoxh/reactive_diffusion_policy", path: "reactive_diffusion_policy/config/train_latent_diffusion_unet_real_image_workspace.yaml", commit: "824c5e8", url: "https://github.com/xiaoxiaoxh/reactive_diffusion_policy/blob/824c5e8/reactive_diffusion_policy/config/train_latent_diffusion_unet_real_image_workspace.yaml" },
      c4: { kind: "code", repo: "xiaoxiaoxh/reactive_diffusion_policy", path: "reactive_diffusion_policy/policy/latent_diffusion_unet_image_policy.py", commit: "824c5e8", url: "https://github.com/xiaoxiaoxh/reactive_diffusion_policy/blob/824c5e8/reactive_diffusion_policy/policy/latent_diffusion_unet_image_policy.py" },
      c5: { kind: "code", repo: "xiaoxiaoxh/reactive_diffusion_policy", path: "reactive_diffusion_policy/config/task/real_peel_image_gelsight_emb_ldp_24fps.yaml", commit: "824c5e8", url: "https://github.com/xiaoxiaoxh/reactive_diffusion_policy/blob/824c5e8/reactive_diffusion_policy/config/task/real_peel_image_gelsight_emb_ldp_24fps.yaml" },
      c6: { kind: "code", repo: "xiaoxiaoxh/reactive_diffusion_policy", path: "eval_real_robot_flexiv.py", commit: "824c5e8", url: "https://github.com/xiaoxiaoxh/reactive_diffusion_policy/blob/824c5e8/eval_real_robot_flexiv.py" }
    },
    summary: {
      pattern: ["Multimodal fusion policy (vision + touch/force)", "p1"],
      params: null,
      vision: ["Wrist RGB 240 × 320 into a ResNet-18 trained from scratch (GroupNorm); Tₒ = 2", "p2", "c3", "c5"],
      backbone: "None: a conv U-Net (slow) and a GRU (fast)",
      head: ["Slow: latent diffusion 1-D U-Net 512 / 1,024 / 2,048, kernel 3. Fast: GRU decoder, hidden 32", "p2", "c2", "c3", "c4"],
      output: ["32 actions at 24 Hz, decoded one step at a time", "p2", "c2"],
      attention: "None (convolutions and a GRU)",
      cond: ["FiLM on [image features ‖ TCP pose ‖ tactile PCA]; the GRU reads the latest tactile PCA or wrench", "p1", "c3", "c5"],
      steps: ["100 train / 8 DDIM inference steps (latent diffusion)", "p2", "c6"],
      chunk: ["32 actions → 8 latent steps (downsample 4)", "p2", "c1", "c2"],
      rate: ["Slow policy 1–2 Hz; fast decoder 24 Hz; robot > 500 Hz after interpolation", "p2"],
      latency: ["Slow policy 100 ms, fast decoder < 1 ms (RTX 4090)", "p3"],
      train: ["TactAR demos: 60 peeling, 80 wiping, 50 bimanual lifting", "p4"]
    },
    changes: [
      "Diffusion runs on a <b>latent chunk</b> (8 steps × 16 channels) from a 1-D conv encoder, not on raw actions.",
      "A <b>GRU decoder</b> expands the latent chunk into actions at 24 Hz and reads the newest tactile or wrench signal at every step.",
      "Touch enters twice: slowly as part of the FiLM condition, and quickly as a decoder input.",
      "Two training stages: the tokenizer (L1 + a tiny KL term) first, then the latent diffusion policy on its codes.",
      "Inference drops to 8 DDIM steps and the U-Net kernel shrinks from 5 to 3."
    ],
    blueprint: {
      headline: "RDP: slow latent plan, fast tactile decoder",
      note: "The ResNet features, TCP pose and tactile PCA condition every U-Net block through FiLM; the U-Net denoises an 8-step latent chunk once per 1–2 Hz cycle. Between cycles the GRU decodes that latent into one action per 24 Hz tick, each time concatenating the newest tactile feature.",
      towers: [
        { mod: "resnet", title: "ResNet-18", sub: "wrist camera, trained from scratch", compact: true,
          input: { label: "Wrist image 240 × 320", caption: "last Tₒ = 2 frames" },
          rows: [
            { t: "conv", label: "Conv 7×7 · GroupNorm · ReLU", call: ["GroupNorm, no pretraining", "c3"] },
            { t: "block", n: "4", rows: [{ t: "conv", label: "Residual stage (2 blocks)" }] },
            { t: "pool", label: "Global pool → 512-d" } ],
          output: { label: "features ‖ TCP pose ‖ tactile PCA" } },
        { mod: "ldp", title: "Latent Diffusion Policy", sub: "slow policy, 1–2 Hz",
          input: { label: "Noisy latent chunk Zᵏ", caption: "8 latent steps × 16 channels, step k" },
          rows: [
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=3 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=3 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 512 → 1,024 → 2,048", "p2", "c3"] } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block, 2,048 ch" }] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "conv", label: "Upsample (transposed conv)" } ] },
            { t: "conv", label: "Final Conv1d → 16 channels", call: ["Kernel 3 overrides the config's 5", "c4"] } ],
          output: { label: "noise ε̂ on Z; 8 DDIM steps → Z⁰" } },
        { mod: "at", title: "Asymmetric Tokenizer", sub: "fast policy (decoder), 24 Hz",
          input: { label: "Latent chunk Z⁰", caption: "8 × 16 from the slow policy" },
          rows: [
            { id: "pq", t: "conv", label: "Post-quant Conv1d 1×1", call: ["16 → 4 channels; 8 × 4 = 32-d code", "p2", "c1", "c2"],
              zoom: { k: "rows", title: "Encoder (training only)", rows: ["Action chunk A: 32 × d", "Conv1d d → 32, k5, s2 · ReLU", "Conv1d 32 → 4, k5, s2", "1×1 conv → μ, log σ² (16 ch)", "sample Z: 8 steps × 16"] } },
            { t: "linear", label: "Flatten, repeat per step" },
            { t: "embed", label: "Concat [code ‖ Fₜ]", side: "tactile", call: ["Fₜ: 15-d GelSight PCA (or 6-d wrench)", "p4", "c5"] },
            { t: "group", label: "Autoregressive, one step per tick", rows: [
              { t: "mlp", label: "GRU cell (hₜ₋₁ → hₜ)", call: ["1 layer, hidden 32", "p2", "c2"],
                zoom: { k: "rows", title: "GRU cell", rows: ["xₜ = [code ‖ Fₜ]", "update gate u = σ(W[xₜ, h])", "reset gate r = σ(W[xₜ, h])", "candidate h̃ = tanh(W[xₜ, r ⊙ h])", "hₜ = (1 − u) ⊙ h + u ⊙ h̃"] } } ] },
            { t: "linear", label: "Linear 32 → action dim", call: ["4-d action in the peeling config", "c5"] } ],
          output: { label: "action Âₜ each tick, < 1 ms" } }
      ],
      links: [
        { from: "ldp", to: "at", toRow: "pq", label: "latent chunk" },
        { from: "resnet", to: "ldp", toRow: "film", label: "obs ‖ step embedding" }
      ]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet-18", sub: "240 × 320 · GroupNorm", col: 0, frozen: false, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "wrist RGB 240 × 320, random crop 0.9", dims: "Tₒ = 2 frames", c: "data-1" },
          { t: "conv", label: "ResNet-18, BatchNorm → GroupNorm", dims: "weights: none (from scratch)" },
          { t: "pool", label: "Global pool", dims: "→ 512 per frame" },
          { t: "out", label: "concat with TCP pose, gripper width, tactile PCA", dims: "global condition", c: "data-1" } ],
          facts: [["Backbone", ["ResNet-18, from scratch", "c3"]], ["Norm", ["GroupNorm", "c3"]], ["Resolution", ["240 × 320", "p2", "c5"]], ["Observation horizon", ["2 frames at 12 Hz", "p2"]]] } },
      { id: "ldp", role: "action-head", roleLabel: "Slow policy", name: "Latent Diffusion Policy", sub: "U-Net on 8 × 16 latents", col: 1, frozen: false, main: true, short: "LDP",
        stack: { rows: [
          { t: "in", label: "noisy latent chunk Zᵏ", dims: "8 steps × 16 channels", c: "data-7" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k=3 → GroupNorm(8) → Mish" },
              { t: "film", label: "FiLM scale and bias from [obs ‖ step]", side: "cond" },
              { t: "conv", label: "Conv1d k=3 → GroupNorm(8) → Mish" },
              { t: "add", span: 3 } ] },
            { t: "conv", label: "Downsample1d", dims: "512 → 1024 → 2048 ch" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block, 2048 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · 2 blocks · upsample" }] },
          { t: "conv", label: "Final Conv1d", dims: "→ 16 channels" },
          { t: "out", label: "noise estimate ε̂", dims: "8 DDIM steps at test time", c: "data-7" } ],
          facts: [["Down dims", ["512 / 1,024 / 2,048", "p2", "c3"]], ["Kernel", ["3 (set in code for conv-encoded latents)", "p2", "c4"]], ["Step embedding", ["128", "c3"]], ["Schedule", ["squared-cosine, ε-prediction, 100 train steps", "p2", "c3"]], ["Inference", ["8 DDIM steps", "p2", "c6"]]] } },
      { id: "at", role: "action-head", roleLabel: "Fast policy", name: "Asymmetric Tokenizer", sub: "Conv1d enc · GRU dec", col: 2, frozen: false, short: "AT",
        stack: { rows: [
          { t: "in", label: "latent chunk Z (8 × 16) + tactile Fₜ", dims: "Fₜ refreshed at 24 Hz", c: "data-6" },
          { t: "conv", label: "Post-quant Conv1d 1×1", dims: "16 → 4 channels" },
          { t: "linear", label: "flatten to a 32-d code, repeat per step" },
          { t: "mlp", label: "GRU over [code ‖ Fₜ], hidden 32", dims: "one step per control tick" },
          { t: "linear", label: "Linear 32 → action dim" },
          { t: "out", label: "action for this tick", dims: "32 per chunk", c: "data-3" } ],
          facts: [["Encoder", ["Conv1d d → 32 → 4, kernel 5, stride 2 each (downsample 4)", "p2", "c1", "c2"]], ["Latent", ["4 channels, 16-channel Gaussian bottleneck", "c1", "c2"]], ["Decoder", ["GRU, 1 layer, hidden 32", "p2", "c2"]], ["Loss", ["L1 reconstruction + KL × 10⁻⁶", "p1", "p2", "c2"]], ["Tactile input", ["15 PCA components of the marker field (GelSight / MCTac)", "p4", "c5"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "wrist frames", n: "Tₒ = 2", k: 4 },
      { to: "ldp", mod: "latent", label: "noisy latent Zᵏ", n: "8 × 16", k: 4, noisy: true },
      { to: "ldp", mod: "time", label: "step k", n: "→ 128-d", k: 2 },
      { to: "at", mod: "touch", label: "tactile PCA or wrench", n: "every 24 Hz tick", k: 3 }
    ],
    outputs: [{ from: "at", mod: "action", label: "actions Â", n: "32 steps at 24 Hz", k: 5 }],
    links: [
      { from: "resnet", to: "ldp", kind: "film", label: "obs ‖ pose ‖ tactile" },
      { from: "ldp", to: "at", kind: "latent", label: "latent chunk Z|1–2 Hz → 24 Hz" }
    ],
    callouts: [
      "Paper Table VII gives a <b>latent action dim of 4</b> (peeling). In the code the encoder does output 4 channels, but a 1×1 conv widens them to a 16-channel Gaussian (n_embed = 16) and the slow policy denoises that 16-channel sample; a post-quant conv maps it back to 4 before the GRU.",
      "The asymmetry matters: feeding tactile input to the encoder as well (a symmetric tokenizer) drops the peeling score from 0.95 to 0.58 (App. G)."
    ]
  });

  /* ------------------------------------------------------------------ ForceVLA */
  RB.arch.spec({
    id: "forcevla", method: "forcevla", name: "ForceVLA", year: 2025, parent: "pi0",
    diffRows: ["cond", "train", "head"],
    figRef: "Yu et al. Fig. 3 · §4.2 · App. B, Table 4", prov: "paper only (no code released)",
    lede: "π0 with one extra module. The 6-axis wrench becomes a token, joins the VLM's output tokens in FVLMoE (one attention block and a 4-expert top-1 MoE), and the last H fused tokens are added to the action expert's inputs.",
    sources: {
      p1: { kind: "paper", ref: "Yu et al. 2025, §4.1–4.2 and Fig. 3", url: "https://arxiv.org/abs/2505.22159" },
      p2: { kind: "paper", ref: "Yu et al. 2025, App. B, Table 4", url: "https://arxiv.org/abs/2505.22159" },
      p3: { kind: "paper", ref: "Yu et al. 2025, §3 and §4.3 (inputs, dataset)", url: "https://arxiv.org/abs/2505.22159" },
      p4: { kind: "paper", ref: "Yu et al. 2025, §5.4, Table 3 (fusion ablation)", url: "https://arxiv.org/abs/2505.22159" },
      p5: { kind: "paper", ref: "Black et al. 2024 (π0), §IV and App. B", url: "https://arxiv.org/abs/2410.24164" },
      c1: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/gemma.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/gemma.py" }
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p1"],
      params: null,
      vision: ["Base and wrist RGB (images resized to 480 × 640 in the dataset) into π0's SigLIP", "p1", "p3"],
      backbone: ["π0's PaliGemma: Gemma 2B, 18 layers, width 2,048", "p1", "p5", "c1"],
      head: ["π0 action expert (width 1,024) plus FVLMoE: 1 attention block + 4-expert top-1 MoE at width 2,048", "p2"],
      output: ["Velocity on an H-step chunk of target TCP pose + gripper width (action dim padded to 32)", "p2", "p3"],
      attention: ["π0's blockwise causal mask; FVLMoE is a separate self-attention over [VL tokens ‖ force token]", "p1", "p5"],
      cond: ["Force enters after the VLM: last H FVLMoE tokens are added element-wise to the expert's state + noisy-action tokens", "p1"],
      steps: ["10 Euler steps (as in π0)", "p5"],
      chunk: null, rate: null, latency: null,
      train: ["ForceVLA-Data: 244 trajectories, 140k steps, 5 tasks; 30,000 steps multi-task", "p2", "p3"]
    },
    changes: [
      "A <b>force token</b>: the 6-axis external wrench is linearly projected to 2,048-d.",
      "<b>FVLMoE</b>: one transformer encoder block (8 heads) and a sparse MoE with 4 MLP experts, top-1 routing, over [VL tokens ‖ force token].",
      "Force is fused <b>after</b> the VLM: injecting it before the VLM scored 55 % (linear) and 0 % (MoE) versus 80 % in the ablation.",
      "The last H fused tokens are projected to 1,024 and <b>added</b> to the action expert's suffix tokens."
    ],
    blueprint: {
      headline: "ForceVLA: π0 plus a force-aware MoE",
      note: "Gemma and the action expert are π0's two experts sharing self-attention. FVLMoE reads Gemma's output tokens plus one force token, refines them with one attention block and a top-1 MoE, and its last H tokens are added to the expert's suffix before the 18 shared layers.",
      towers: [
        { mod: "gemma", title: "PaliGemma (π0)", sub: "SigLIP + Gemma 2B", compact: true,
          input: { label: "Image + text tokens", caption: "base + wrist RGB, instruction" },
          rows: [
            { t: "embed", label: "SigLIP tokens + text embed" },
            { t: "block", n: "18", rows: [
              { id: "att", t: "attn", label: "Masked multi-query attention", call: ["Width 2,048; 8 query heads, 1 KV head", "p5", "c1"], callDy: -24 },
              { t: "ffn", label: "Feed forward (GeGLU)" } ] },
            { t: "norm", label: "Final RMSNorm" } ],
          output: { label: "VL tokens Eᵥₗ → FVLMoE" } },
        { mod: "expert", title: "Action expert (π0)", sub: "flow matching, width 1,024",
          input: { label: "State + noisy actions Aτ", caption: "7-d TCP pose + gripper; H actions, time τ" },
          rows: [
            { t: "linear", label: "State / action projections", call: ["32 → 1,024 each", "p2"] },
            { t: "mlp", label: "Action + time MLP", call: ["2 layers, swish, 2 × 1,024 → 1,024", "p2"] },
            { id: "inj", t: "film", label: "+ FVLMoE guidance G" },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention" },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["1,024 → 4,096 → 1,024", "c1"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Action output projection", call: ["1,024 → 32", "p2"] } ],
          output: { label: "velocity vθ; 10 Euler steps" } },
        { mod: "fvlmoe", title: "FVLMoE", sub: "force-aware MoE fusion (new)",
          input: { label: "VL tokens ‖ force token", caption: "Nᵥₗ Gemma outputs + 1 force token" },
          rows: [
            { t: "linear", label: "Force projection", side: "wrench", call: ["6 → 2,048, appended as 1 token", "p1", "p2"] },
            { t: "attn", label: "Self-attention", call: ["8 heads, head dim 256, width 2,048", "p2"], zoom: { k: "heads", q: 8, kv: 8, hd: 256, title: "FVLMoE attention" } },
            { t: "ffn", label: "Feed forward (MLP)", call: ["Expansion factor 1", "p2"], zoom: { k: "rows", title: "Encoder MLP (expansion 1)", rows: ["token, 2,048-d", "Linear 2,048 → 2,048", "activation (not stated)", "Linear 2,048 → 2,048"] } },
            { t: "norm", label: "LayerNorm" },
            { t: "moe", label: "Sparse MoE", call: ["4 MLP experts, top-1; router 2,048 → 4", "p1", "p2"], zoom: { k: "moe", experts: 4, topk: 1, caption: "4 experts, 1 active per token" } },
            { t: "add", span: 2 },
            { t: "linear", label: "Output projection", call: ["2,048 → 1,024; keep last H tokens", "p1", "p2"] } ],
          output: { label: "guidance G: H × 1,024" } }
      ],
      links: [{ from: "fvlmoe", to: "expert", toRow: "inj", label: "add element-wise" }],
      shared: [{ a: ["gemma", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "gemma", role: "vlm", name: "PaliGemma (π0)", sub: "18 × 2048 · MQA", col: 0, frozen: false, short: "PaliGemma",
        stack: { rows: [
          { t: "in", label: "[image tokens | instruction]", dims: "base + wrist camera", c: "data-2" },
          { t: "block", label: "Gemma decoder block", n: "18", rows: [{ t: "attn", label: "MQA, shared with the expert's tokens" }, { t: "ffn", label: "GeGLU 2048 → 16,384 → 2048" }] },
          { t: "out", label: "VL tokens and cached keys/values", dims: "also fed to FVLMoE", c: "data-2" } ],
          facts: [["Init", ["π0 checkpoint", "p1"]], ["Width / depth", ["2,048 / 18", "p5", "c1"]], ["Force input", ["none (early fusion hurt: 0–55 % vs 80 %)", "p4"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert (π0)", sub: "18 × 1024 · + guidance", col: 1, frozen: false, main: true, short: "Action expert",
        stack: { rows: [
          { t: "in", label: "state sₜ (7-d) + noisy actions Aτ + τ", dims: "padded to 32-d", c: "data-3" },
          { t: "linear", label: "state and action projections 32 → 1024" },
          { t: "mlp", label: "action-time MLP (swish)", dims: "2 × 1024 → 1024" },
          { t: "film", label: "+ G (last H FVLMoE tokens), element-wise", side: "force" },
          { t: "block", label: "Expert block, joint attention with Gemma", n: "18", rows: [{ t: "attn", label: "masked MQA" }, { t: "ffn", label: "GeGLU 1024 → 4096 → 1024" }] },
          { t: "linear", label: "output projection 1024 → 32" },
          { t: "out", label: "velocity vθ", dims: "10 Euler steps", c: "data-3" } ],
          facts: [["Projections", ["state 32 → 1,024, action 32 → 1,024", "p2"]], ["Action-time MLP", ["2 layers, swish", "p2"]], ["Output", ["1,024 → 32", "p2"]], ["Proprio", ["TCP xyz + Euler + gripper width = 7-d", "p3"]]] } },
      { id: "fvlmoe", role: "fusion", name: "FVLMoE", sub: "1 attn block · 4-expert MoE", col: 2, frozen: false, short: "FVLMoE",
        stack: { rows: [
          { t: "in", label: "Eᵥₗ (Nᵥₗ × 2048) ‖ force token", dims: "force: Linear 6 → 2048", c: "data-6" },
          { t: "block", label: "Transformer encoder block", n: "1", rows: [{ t: "attn", label: "self-attention, 8 heads × 256" }, { t: "ffn", label: "MLP, expansion 1" }] },
          { t: "norm", label: "LayerNorm" },
          { t: "moe", label: "sparse MoE: 4 MLP experts (2048 → 2048), top-1" },
          { t: "add", label: "residual around the MoE", span: 2 },
          { t: "linear", label: "output projection 2048 → 1024" },
          { t: "out", label: "last H tokens = guidance G", c: "data-6" } ],
          facts: [["Attention", ["8 heads, head dim 256, width 2,048", "p2"]], ["MLP expansion", ["1", "p2"]], ["Experts", ["4, top-1 routing; router 2,048 → 4", "p1", "p2"]], ["Output", ["2,048 → 1,024", "p2"]], ["Routing", ["expert 0 takes about half the tokens across tasks", "p2"]]] } }
    ],
    inputs: [
      { to: "gemma", mod: "vision", label: "base + wrist RGB", n: "2 cameras", k: 4 },
      { to: "gemma", mod: "lang", label: "instruction ℓ", k: 2 },
      { to: "expert", mod: "state", label: "TCP pose + gripper", n: "7-d", k: 1 },
      { to: "expert", mod: "action", label: "noisy chunk Aτ", n: "H actions", k: 4, noisy: true },
      { to: "fvlmoe", mod: "latent", label: "VL tokens", n: "from Gemma", k: 3 },
      { to: "fvlmoe", mod: "touch", label: "wrench fₜ", n: "6-axis", k: 1 }
    ],
    outputs: [{ from: "expert", mod: "action", label: "velocity vθ", n: "H × 32", k: 4 }],
    links: [
      { from: "gemma", to: "expert", kind: "joint-attn", label: "shared self-attn" },
      { from: "fvlmoe", to: "expert", kind: "feeds", label: "add to suffix|last H tokens" }
    ],
    mask: { name: "Blockwise causal (π0)", ref: "p5", axes: [{ label: "images + text", short: "img+ℓ", mod: "vision" }, { label: "state", short: "s", mod: "state" }, { label: "actions + G", short: "A", mod: "action" }], m: ["100", "110", "111"],
      note: "FVLMoE runs outside this mask: it sees all VL tokens and the force token, and its output is added to the suffix." },
    callouts: [
      "<b>No official code</b> was found for ForceVLA; every number here comes from the paper (Table 4 lists the module sizes as \"indicative\").",
      "Where the force goes matters most: concatenating force after the VLM gets 60 %, FVLMoE 80 %, while an MoE before the VLM fails completely (Table 3)."
    ]
  });

  /* ------------------------------------------------------------------ FoAR */
  RB.arch.spec({
    id: "foar", method: "foar", name: "FoAR", year: 2024,
    figRef: "He et al. Fig. 2 · §III-B · App. A", prov: "",
    lede: "RISE plus a gated force branch. A sparse 3D encoder reads the point cloud, a transformer summarizes the F/T history, and an RGB contact predictor φ blends the force feature with a learned neutral embedding before a diffusion head.",
    sources: {
      p1: { kind: "paper", ref: "He et al. 2024, §III-B and Fig. 2", url: "https://arxiv.org/abs/2411.15753" },
      p2: { kind: "paper", ref: "He et al. 2024, §IV-A (implementation) and App. A", url: "https://arxiv.org/abs/2411.15753" },
      p3: { kind: "paper", ref: "He et al. 2024, §III-C and Alg. 1 (reactive control)", url: "https://arxiv.org/abs/2411.15753" },
      c1: { kind: "code", repo: "Alan-Heoooh/FoAR", path: "policy/policy.py", commit: "869abd3", url: "https://github.com/Alan-Heoooh/FoAR/blob/869abd3/policy/policy.py" },
      c2: { kind: "code", repo: "Alan-Heoooh/FoAR", path: "policy/tokenizer.py", commit: "869abd3", url: "https://github.com/Alan-Heoooh/FoAR/blob/869abd3/policy/tokenizer.py" },
      c3: { kind: "code", repo: "Alan-Heoooh/FoAR", path: "policy/diffusion.py", commit: "869abd3", url: "https://github.com/Alan-Heoooh/FoAR/blob/869abd3/policy/diffusion.py" },
      c4: { kind: "code", repo: "Alan-Heoooh/FoAR", path: "train.py", commit: "869abd3", url: "https://github.com/Alan-Heoooh/FoAR/blob/869abd3/train.py" },
      c5: { kind: "code", repo: "Alan-Heoooh/FoAR", path: "eval.py", commit: "869abd3", url: "https://github.com/Alan-Heoooh/FoAR/blob/869abd3/eval.py" }
    },
    summary: {
      pattern: ["Multimodal fusion policy (vision + touch/force)", "p1"],
      params: null,
      vision: ["Single-view RGB-D point cloud, 5 mm voxels, sparse ResNet (MinkowskiEngine); RGB for the contact predictor", "p2", "c2", "c4"],
      backbone: ["Two transformers (scene, force): 4 encoder + 1 decoder layers, d 512, 8 heads, FFN 2,048", "p2", "c1", "c4"],
      head: ["CNN diffusion head (1-D U-Net 256 / 512, kernel 5)", "p2", "c3"],
      output: ["Tₐ = 20 end-effector actions (10-d)", "p2", "c1"],
      attention: ["Transformer with a readout token for each modality; no cross-modal attention", "p2", "c1"],
      cond: ["[scene 512 ‖ φ·force + (1 − φ)·h*] = 1,024-d global condition", "p1", "c1"],
      steps: ["100 train / 20 DDIM inference steps", "p2", "c3"],
      chunk: ["20 actions, temporal ensembling (separate buffers for contact / no contact)", "p2", "p3"],
      rate: ["F/T at 100 Hz; actions at about 10 Hz", "p2"],
      latency: null,
      train: ["50 demos (wiping, peeling), 40 (chopping); batch 240, lr 3 × 10⁻⁴", "p2"]
    },
    blueprint: {
      headline: "FoAR: force gated by predicted contact",
      note: "Each branch compresses its tokens into one 512-d readout. The contact predictor φ decides how much of the force readout to keep; the rest is replaced by a learned embedding h*, so noisy F/T readings cannot disturb reaching and grasping. The fused 1,024-d vector conditions a diffusion U-Net.",
      towers: [
        { mod: "scene", title: "Point-cloud branch", sub: "RISE encoder", compact: true,
          input: { label: "Point cloud pₜ", caption: "RGB-D, workspace-cropped, 5 mm voxels" },
          rows: [
            { t: "conv", label: "Sparse ResNet14 (Minkowski)", call: ["→ point tokens, 512-d", "p2", "c2"] },
            { t: "block", n: "4", rows: [{ t: "attn", label: "Encoder layer, sparse pos. enc." }] },
            { t: "attn", label: "Decoder layer + readout", call: ["d 512, 8 heads, FFN 2,048", "p2", "c4"] } ],
          output: { label: "scene feature hˢ (512)" } },
        { mod: "force", title: "Force branch", sub: "F/T history encoder", compact: true,
          input: { label: "F/T history", caption: "6-axis wrench at 100 Hz" },
          rows: [
            { t: "mlp", label: "Per-step MLP + LayerNorm", call: ["6 → 64 → 128 → 512", "p2", "c2"] },
            { t: "embed", label: "+ sinusoidal time encoding" },
            { t: "block", n: "4", rows: [{ t: "attn", label: "Encoder layer" }] },
            { id: "gate", t: "adaln", label: "φ·hᶠ + (1 − φ)·h*", side: "φ", call: ["h* is a learned 512-d embedding", "p1", "c1"],
              zoom: { k: "rows", title: "Future contact predictor φ", rows: ["RGB image Iₜ + F/T history", "ResNet-18 (ImageNet) → 512", "MLP on F/T → 256 (code)", "concat → Linear → sigmoid", "φ ∈ [0, 1]; φ > 0.9 means contact"] } } ],
          output: { label: "gated force feature (512)" } },
        { mod: "head", title: "Diffusion action head", sub: "1-D U-Net, ε-prediction",
          input: { label: "Noisy actions aᵏ", caption: "20 steps × 10-d, step k" },
          rows: [
            { id: "cat", t: "linear", label: "Concat [hˢ ‖ gated hᶠ]", call: ["1,024-d global condition", "c1"] },
            { t: "film", label: "FiLM on every conv block", zoom: { k: "film", title: "FiLM conditioning" } },
            { t: "group", label: "U-Net, 2 levels", rows: [
              { t: "block", n: "2", rows: [{ t: "conv", label: "Conv1d k=5 · GN · Mish" }, { t: "conv", label: "Conv1d k=5 · GN · Mish" }, { t: "add", span: 2 }] },
              { t: "conv", label: "Down / up sampling", call: ["Channels 256 → 512", "c3"] } ] },
            { t: "conv", label: "Final Conv1d → 10-d" } ],
          output: { label: "noise ε̂; 20 DDIM steps" } }
      ],
      links: [
        { from: "force", to: "head", toRow: "cat", label: "gated hᶠ" },
        { from: "scene", to: "head", toRow: "cat", label: "hˢ" }
      ]
    },
    modules: [
      { id: "scene", role: "vision-enc", name: "Sparse 3D encoder", sub: "ResNet14 + transformer", col: 0, frozen: false, short: "Scene",
        stack: { rows: [
          { t: "in", label: "point cloud (xyz + rgb)", dims: "5 mm voxels", c: "data-1" },
          { t: "conv", label: "MinkowskiEngine sparse ResNet14", dims: "→ tokens, 512-d" },
          { t: "block", label: "Transformer encoder", n: "4", rows: [{ t: "attn", label: "self-attention, 8 heads" }, { t: "ffn", label: "FFN 512 → 2048 → 512" }] },
          { t: "attn", label: "1 decoder layer with a readout token" },
          { t: "out", label: "scene feature hˢ", dims: "512", c: "data-1" } ],
          facts: [["Voxel size", ["5 mm", "p2", "c4"]], ["Transformer", ["4 encoder + 1 decoder, d 512, FFN 2,048", "p2", "c4"]], ["Heads", ["8", "c4"]]] } },
      { id: "force", role: "touch-enc", name: "F/T encoder + gate", sub: "MLP + transformer · φ", col: 1, frozen: false, short: "Force",
        stack: { rows: [
          { t: "in", label: "F/T history fₜ₋ₜₒ:ₜ", dims: "6-d at 100 Hz", c: "data-6" },
          { t: "mlp", label: "per-step MLP 6 → 64 → 128 → 512 (LayerNorm, ReLU)" },
          { t: "embed", label: "sinusoidal positional encoding over time" },
          { t: "block", label: "same transformer shape as the scene branch", n: "4", rows: [{ t: "attn", label: "self-attention" }] },
          { t: "adaln", label: "gate: φ·hᶠ + (1 − φ)·h*", side: "φ" },
          { t: "out", label: "gated force feature", dims: "512", c: "data-6" } ],
          facts: [["History", ["Tₒ = 200 (paper) · 100 (code default)", "p2", "c4"]], ["Token MLP", ["(64, 128, 512)", "p2", "c2"]], ["Predictor", ["ResNet-18 on RGB + MLP on F/T → linear → sigmoid", "p2", "c1"]], ["Predictor label", ["F/T above threshold within ±2 s", "p2"]], ["Thresholds at test", ["φ 0.9, force 8 N, torque 5 N·m, step 6 mm", "p2", "c5"]]] } },
      { id: "head", role: "action-head", name: "Diffusion U-Net head", sub: "256 / 512 ch · kernel 5", col: 2, frozen: false, main: true, short: "Head",
        stack: { rows: [
          { t: "in", label: "noisy action chunk", dims: "20 × 10", c: "data-3" },
          { t: "group", label: "ConditionalUnet1D", rows: [{ t: "film", label: "FiLM from the 1,024-d condition", side: "cond" }, { t: "conv", label: "Conv1d blocks, 256 → 512 ch" }] },
          { t: "out", label: "noise ε̂", dims: "20 DDIM steps", c: "data-3" } ],
          facts: [["Down dims", ["256 / 512", "c3"]], ["Kernel", ["5", "c3"]], ["Step embedding", ["256", "c3"]], ["Schedule", ["100 train, 20 DDIM, squared cosine", "p2", "c3"]], ["Chunk", ["20 actions", "p2", "c1"]]] } }
    ],
    inputs: [
      { to: "scene", mod: "vision", label: "point cloud pₜ", n: "RGB-D", k: 4 },
      { to: "force", mod: "touch", label: "F/T history", n: "100 Hz", k: 4 },
      { to: "force", mod: "vision", label: "RGB Iₜ (for φ)", k: 2 },
      { to: "head", mod: "action", label: "noisy actions", n: "20 × 10", k: 4, noisy: true }
    ],
    outputs: [
      { from: "head", mod: "action", label: "action chunk", n: "20 steps", k: 4 },
      { from: "force", mod: "other", label: "contact prob. φ", k: 1 }
    ],
    links: [
      { from: "scene", to: "force", kind: "feeds", label: "concat|[hˢ ‖ ·]" },
      { from: "force", to: "head", kind: "film", label: "1,024-d cond" }
    ],
    callouts: [
      "Paper vs code: the paper sets the predictor loss weight <b>α = 0.1</b>; train.py defaults to <b>α = 10</b>. The paper uses <b>Tₒ = 200</b> F/T steps; train.py and eval.py default to 100.",
      "Paper App. A gives the predictor's F/T MLP as (128, 512); the code uses (128, 256) on the flattened history.",
      "At deployment the same φ drives a reactive rule: if φ > 0.9 but force < 8 N and torque < 5 N·m, targets are nudged 6 mm along the predicted motion."
    ]
  });

  /* ------------------------------------------------------------------ Adaptive Compliance Policy */
  RB.arch.spec({
    id: "adaptive-compliance-policy", method: "adaptive-compliance-policy", name: "Adaptive Compliance Policy", year: 2024, parent: "diffusion-policy",
    diffRows: ["vision", "head", "output", "cond", "steps", "attention"],
    figRef: "Hou et al. Fig. 2 · §III-D", prov: "flip-up config (FFT variant)",
    lede: "A diffusion policy that outputs a pose, a virtual target and a stiffness. Image features and a force-spectrogram feature are fused by one transformer layer; an admittance controller turns the virtual target and stiffness into compliance along the force direction.",
    sources: {
      p1: { kind: "paper", ref: "Hou et al. 2024, §III-D (policy)", url: "https://arxiv.org/abs/2410.09309" },
      p2: { kind: "paper", ref: "Hou et al. 2024, §III-C (compliance labels)", url: "https://arxiv.org/abs/2410.09309" },
      p3: { kind: "paper", ref: "Hou et al. 2024, §IV (setup and results)", url: "https://arxiv.org/abs/2410.09309" },
      c1: { kind: "code", repo: "yifan-hou/adaptive_compliance_policy", path: "PyriteML/diffusion_policy/config/train_spec_workspace.yaml", commit: "74d68ec", url: "https://github.com/yifan-hou/adaptive_compliance_policy/blob/74d68ec/PyriteML/diffusion_policy/config/train_spec_workspace.yaml" },
      c2: { kind: "code", repo: "yifan-hou/adaptive_compliance_policy", path: "PyriteML/diffusion_policy/model/vision/timm_obs_encoder_with_force_spec.py", commit: "74d68ec", url: "https://github.com/yifan-hou/adaptive_compliance_policy/blob/74d68ec/PyriteML/diffusion_policy/model/vision/timm_obs_encoder_with_force_spec.py" },
      c3: { kind: "code", repo: "yifan-hou/adaptive_compliance_policy", path: "PyriteML/diffusion_policy/config/task/flip_up_spec.yaml", commit: "74d68ec", url: "https://github.com/yifan-hou/adaptive_compliance_policy/blob/74d68ec/PyriteML/diffusion_policy/config/task/flip_up_spec.yaml" }
    },
    summary: {
      pattern: ["Multimodal fusion policy (vision + touch/force)", "p1"],
      params: null,
      vision: ["CLIP ViT-B/16, 2 frames at 224 × 224 (paper); code config uses CLIP ViT-B/32 with attention pooling", "p1", "c1"],
      backbone: ["One transformer encoder layer over [image tokens ‖ force token], d 768, 8 heads", "p1", "c2"],
      head: ["1-D U-Net diffusion head, down dims 256 / 512 / 1,024, kernel 5", "c1"],
      output: ["19-d per arm: 9-d reference pose, 9-d virtual target, 1 stiffness", "p1", "c3"],
      attention: ["Full self-attention across the 3 modality tokens", "p1", "c2"],
      cond: ["Fused vector ‖ 3 frames of end-effector pose → global condition", "p1", "c2", "c3"],
      steps: ["50 train / 16 inference steps (DDIM)", "c1"],
      chunk: ["16 predicted actions", "c3"],
      rate: ["UR5e pose commands at 500 Hz; ATI F/T at up to 7,000 Hz", "p3"],
      latency: null,
      train: ["230 flip-up demos on 15 items; 200 vase-wiping demos", "p3"]
    },
    changes: [
      "The action grows from a pose to a <b>19-d compliance action</b>: reference pose, virtual target pose and stiffness.",
      "A <b>force encoder</b> reads 1 s of 7 kHz F/T as a 6-channel spectrogram.",
      "Image and force features are fused by a <b>transformer layer</b> before conditioning the U-Net.",
      "The visual encoder is a <b>CLIP-pretrained ViT</b> instead of a ResNet-18 from scratch.",
      "An admittance controller executes the output; stiffness is low only along the reference → virtual-target direction."
    ],
    blueprint: {
      headline: "ACP: diffusion that outputs stiffness",
      note: "Two image-frame tokens and one force token (768-d each) pass through one self-attention layer; the flattened result is projected to 768 and concatenated with 3 frames of end-effector pose. That vector conditions every U-Net block through FiLM, and the U-Net denoises 16 steps of the 19-d compliance action.",
      towers: [
        { mod: "enc", title: "Vision + force encoders", sub: "CLIP ViT and spectrogram ViT", compact: true,
          input: { label: "RGB + F/T spectrogram", caption: "2 frames 224 × 224; 1 s of wrench" },
          rows: [
            { t: "embed", label: "CLIP ViT → 768 per frame", call: ["ViT-B/16 in paper, B/32 in code", "p1", "c1"] },
            { t: "embed", label: "Force ViT → 768", call: ["6 × 30 × 17 spectrogram input", "p1"], zoom: { k: "rows", title: "Force encoder (code)", rows: ["6-axis wrench, 1 s at 7 kHz", "per-axis FFT → 6 × 30 × 17", "pad to 30 × 30, patch 6", "ViT: 6 layers, d 768, 8 heads", "force token (768)"] } },
            { t: "norm", label: "Stack as 3 tokens" } ],
          output: { label: "3 × 768 modality tokens" } },
        { mod: "fuse", title: "Fusion layer", sub: "1 transformer encoder layer", compact: true,
          input: { label: "Modality tokens", caption: "2 image + 1 force" },
          rows: [
            { t: "attn", label: "Self-attention", call: ["d 768, 8 heads", "c2"], zoom: { k: "heads", q: 8, kv: 8, hd: 96, title: "Fusion attention" } },
            { t: "ffn", label: "Feed forward", call: ["768 → 2,048 → 768", "c2"] },
            { t: "linear", label: "Flatten → Linear 3 × 768 → 768", call: ["then ‖ 3 frames of EE pose", "p1", "c2"] } ],
          output: { label: "global condition" } },
        { mod: "unet", title: "Conditional 1-D U-Net", sub: "noise-prediction network",
          input: { label: "Noisy action chunk Aᵏ", caption: "16 steps × 19-d, step k" },
          rows: [
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 256 → 512 → 1,024", "c1"] } ] },
            { t: "group", label: "Up path", rows: [{ t: "conv", label: "Concat skip + cond. blocks" }] },
            { t: "conv", label: "Final Conv1d → 19-d", call: ["Pose 9 · virtual target 9 · stiffness 1", "p1", "c3"] } ],
          output: { label: "noise ε̂; 16 DDIM steps" } }
      ],
      links: [
        { from: "fuse", to: "unet", toRow: "film", label: "fused ‖ EE poses" },
        { from: "enc", to: "fuse", toRow: "input", label: "3 tokens" }
      ]
    },
    modules: [
      { id: "enc", role: "touch-enc", roleLabel: "Vision + force encoders", name: "CLIP ViT · Force ViT", sub: "768-d tokens", col: 0, frozen: false, short: "Encoders",
        stack: { rows: [
          { t: "in", label: "2 RGB frames + 6 × 30 × 17 spectrogram", dims: "GoPro fisheye; ATI mini-45", c: "data-6" },
          { t: "embed", label: "CLIP ViT, attention pooling", dims: "→ 768 per frame" },
          { t: "embed", label: "force ViT (code) / ResNet-18 + CoordConv (paper)", dims: "→ 768" },
          { t: "out", label: "3 modality tokens", c: "data-6" } ],
          facts: [["Image model", ["CLIP ViT-B/16 (paper) · vit_base_patch32_clip_224.openai (code)", "p1", "c1"]], ["Spectrogram", ["6 × 30 × 17", "p1"]], ["Force model (code)", ["ViT: 6 layers, d 768, 8 heads, patch 6, MLP 2,048", "c2"]], ["Temporal variant", ["5-layer causal conv over 32 steps → 768", "p1"]]] } },
      { id: "fuse", role: "fusion", name: "Transformer fusion", sub: "1 layer · d 768 · 8 heads", col: 1, frozen: false, short: "Fusion",
        stack: { rows: [
          { t: "in", label: "[img₁, img₂, force]", dims: "3 × 768", c: "data-6" },
          { t: "attn", label: "TransformerEncoderLayer", dims: "8 heads, FFN 2048, no dropout" },
          { t: "linear", label: "flatten → Linear 2304 → 768" },
          { t: "out", label: "‖ EE pose, 3 frames", dims: "→ U-Net condition", c: "data-6" } ],
          facts: [["Layers", ["1", "p1", "c2"]], ["Width / heads", ["768 / 8", "c2"]], ["FFN", ["2,048", "c2"]]] } },
      { id: "unet", role: "action-head", name: "Conditional 1-D U-Net", sub: "256 / 512 / 1024 ch", col: 2, frozen: false, main: true, short: "U-Net",
        stack: { rows: [
          { t: "in", label: "noisy compliance chunk", dims: "16 × 19", c: "data-3" },
          { t: "group", label: "ConditionalUnet1D", rows: [{ t: "film", label: "FiLM on every block", side: "cond" }, { t: "conv", label: "Conv1d k=5 blocks" }] },
          { t: "out", label: "ε̂ → pose, virtual target, stiffness", dims: "sent to admittance control", c: "data-3" } ],
          facts: [["Down dims", ["256 / 512 / 1,024", "c1"]], ["Kernel", ["5", "c1"]], ["Step embedding", ["32", "c1"]], ["Steps", ["50 train, 16 inference", "c1"]], ["Stiffness label", ["k_low along |f|, k_high elsewhere (Eq. 6–7)", "p2"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "2 RGB frames", n: "224 × 224", k: 3 },
      { to: "enc", mod: "touch", label: "F/T spectrogram", n: "1 s at 7 kHz", k: 3 },
      { to: "fuse", mod: "state", label: "EE poses", n: "3 frames", k: 2 },
      { to: "unet", mod: "action", label: "noisy chunk", n: "16 × 19", k: 4, noisy: true }
    ],
    outputs: [{ from: "unet", mod: "action", label: "pose + target + stiffness", n: "16 × 19", k: 4 }],
    links: [
      { from: "enc", to: "fuse", kind: "prefix", label: "3 tokens" },
      { from: "fuse", to: "unet", kind: "film", label: "fused cond" }
    ],
    callouts: [
      "Paper vs code: the paper encodes the spectrogram with a <b>ResNet-18 + CoordConv</b> and images with <b>CLIP ViT-B/16</b>; the released config uses a <b>6-layer ViT</b> for force (<code>vit-force</code>) and <b>CLIP ViT-B/32</b> for images.",
      "Stiffness is <b>learned from labels</b> computed from one demonstration: low stiffness along the measured force, high elsewhere, so the policy never fights a contact constraint (Theorem 1)."
    ]
  });

  /* ------------------------------------------------------------------ 3D-ViTac */
  RB.arch.spec({
    id: "3d-vitac", method: "3d-vitac", name: "3D-ViTac", year: 2024, parent: "diffusion-policy",
    diffRows: ["vision", "cond", "output", "train"],
    figRef: "Huang et al. Fig. 3 · §4.2–4.3 · App. B.4", prov: "paper only (see callout)",
    lede: "Touch becomes geometry. Each taxel of the 16 × 16 finger pads is placed in 3D by forward kinematics and merged with the camera point cloud; PointNet++ encodes the joint cloud and a diffusion policy outputs joint-state targets.",
    sources: {
      p1: { kind: "paper", ref: "Huang et al. 2024, §4.1–4.3 and Fig. 3", url: "https://arxiv.org/abs/2410.24091" },
      p2: { kind: "paper", ref: "Huang et al. 2024, App. B.4 (learning details)", url: "https://arxiv.org/abs/2410.24091" },
      p3: { kind: "paper", ref: "Huang et al. 2024, §3 (sensor and teleoperation)", url: "https://arxiv.org/abs/2410.24091" },
      p4: { kind: "paper", ref: "Huang et al. 2024, §5.2 and Table 1", url: "https://arxiv.org/abs/2410.24091" },
      c1: { kind: "code", repo: "binghao-huang/3d-vitac-training-code", path: "readme.md", commit: "c38a5b7", url: "https://github.com/binghao-huang/3d-vitac-training-code/blob/c38a5b7/readme.md" }
    },
    summary: {
      pattern: ["Multimodal fusion policy (vision + touch/force)", "p1"],
      params: null,
      vision: ["3 RGB-D views merged, cropped, farthest-point sampled to 512 points", "p1", "p4"],
      backbone: ["PointNet++: 3 set-abstraction levels → 1,024, then FC 512 → 256; BatchNorm off", "p2"],
      head: ["Conditional denoising diffusion model (DDPM), details as in Diffusion Policy", "p1"],
      output: ["Sequence of robot joint states (bimanual)", "p1"],
      attention: "None (PointNet++ and a diffusion head)",
      cond: ["One visuo-tactile cloud: 512 visual + 256 tactile points per finger, 4-d (xyz + reading) + one-hot flag", "p1"],
      steps: null, chunk: null,
      rate: ["Demos recorded at 10 Hz; tactile readout up to 32.2 FPS", "p3"],
      latency: null,
      train: ["30–50 demos per task; 2,000 epochs", "p4"]
    },
    changes: [
      "The observation is <b>one point cloud</b>: tactile taxels are placed in 3D by forward kinematics and joined to the camera points.",
      "The ResNet image encoder is replaced by <b>PointNet++</b> (3 set-abstraction levels, no BatchNorm).",
      "Each point carries a reading channel (0 for camera points, pressure for taxels) and a <b>one-hot modality flag</b>.",
      "Actions are bimanual <b>joint-state</b> targets from an ALOHA-style teleop setup."
    ],
    blueprint: {
      headline: "3D-ViTac: touch as points in 3D",
      note: "No separate tactile encoder: the 256 readings of each finger pad become 3D points at their current finger pose and join 512 camera points. PointNet++ reads the mixed cloud once per step and its 256-d feature conditions the diffusion policy.",
      towers: [
        { mod: "cloud", title: "Visuo-tactile cloud", sub: "preprocessing, no weights", compact: true,
          input: { label: "RGB-D + tactile pads", caption: "3 cameras; 16 × 16 pad per finger" },
          rows: [
            { t: "linear", label: "Merge, crop, FPS", call: ["512 visual points", "p1"] },
            { t: "linear", label: "Taxels → 3D via FK", call: ["256 points per pad", "p1", "p3"] },
            { t: "embed", label: "Union + one-hot flag", call: ["xyz + reading = 4-d", "p1"] } ],
          output: { label: "visuo-tactile points" } },
        { mod: "pn", title: "PointNet++", sub: "point encoder, BatchNorm disabled",
          input: { label: "Visuo-tactile points", caption: "512 + 256 × 2 or 4 fingers" },
          rows: [
            { t: "conv", label: "SA 1: 64 centres, r 0.04", call: ["16 neighbours, MLP 64, 64, 128", "p2"],
              zoom: { k: "rows", title: "Set-abstraction level", rows: ["points: xyz + features", "farthest point sampling → centres", "ball query: radius r, k neighbours", "shared MLP on each neighbour", "max pool → one feature per centre"] } },
            { t: "conv", label: "SA 2: 16 centres, r 0.08", call: ["32 neighbours, MLP 128, 128, 256", "p2"] },
            { t: "pool", label: "SA 3: global abstraction", call: ["MLP 256, 512, 1,024 → max pool", "p2"] },
            { id: "fc", t: "linear", label: "FC 1,024 → 512 → 256", call: ["256-d observation feature", "p2"] } ],
          output: { label: "point feature (256)" } },
        { mod: "head", title: "Diffusion policy", sub: "conditional denoising (DDPM)",
          input: { label: "Noisy joint-state sequence", caption: "denoised from Gaussian noise" },
          rows: [
            { id: "cond", t: "film", label: "Condition on point feature", side: "cond", zoom: { k: "rows", title: "Diffusion sampling", rows: ["aᴷ ~ N(0, I)", "εθ(aᵏ, k, feature)", "aᵏ⁻¹ = denoise step", "repeat until a⁰", "joint-state targets"] } },
            { t: "conv", label: "Denoising network" } ],
          output: { label: "joint-state targets" } }
      ],
      links: [
        { from: "pn", to: "head", toRow: "cond", label: "256-d feature" },
        { from: "cloud", to: "pn", toRow: "input", label: "one cloud" }
      ]
    },
    modules: [
      { id: "cloud", role: "fusion", roleLabel: "Fusion (geometric)", name: "Visuo-tactile cloud", sub: "FK-placed taxels + FPS", col: 0, frozen: true, short: "Cloud",
        note: "Preprocessing with no learned weights.",
        stack: { rows: [
          { t: "in", label: "multi-view depth + 16 × 16 tactile pads", c: "data-6" },
          { t: "linear", label: "merge views, crop, FPS", dims: "→ 512 visual points" },
          { t: "linear", label: "forward kinematics per taxel", dims: "256 points per finger" },
          { t: "embed", label: "union, reading channel, one-hot modality flag" },
          { t: "out", label: "visuo-tactile cloud", c: "data-6" } ],
          facts: [["Visual points", ["512 (FPS)", "p1"]], ["Tactile points", ["256 × N_finger (2 single-arm, 4 bimanual)", "p1"]], ["Pad", ["16 × 16, 3 mm² per sensing unit", "p3"]], ["Readout", ["up to 32.2 FPS", "p3"]]] } },
      { id: "pn", role: "vision-enc", roleLabel: "Point encoder", name: "PointNet++", sub: "3 SA levels → 256", col: 1, frozen: false, short: "PointNet++",
        stack: { rows: [
          { t: "in", label: "visuo-tactile points", c: "data-6" },
          { t: "conv", label: "SA 1: 64 centres, radius 0.04, 16 samples", dims: "MLP [64, 64, 128]" },
          { t: "conv", label: "SA 2: 16 centres, radius 0.08, 32 samples", dims: "MLP [128, 128, 256]" },
          { t: "pool", label: "SA 3: global", dims: "MLP [256, 512, 1024]" },
          { t: "linear", label: "FC 1024 → 512 → 256", dims: "no BatchNorm" },
          { t: "out", label: "observation feature", dims: "256", c: "data-1" } ],
          facts: [["SA 1", ["64 points, r 0.04, 16 samples, MLP [64, 64, 128]", "p2"]], ["SA 2", ["16 points, r 0.08, 32 samples, MLP [128, 128, 256]", "p2"]], ["SA 3", ["global, MLP [256, 512, 1,024]", "p2"]], ["Head FCs", ["1,024 → 512 → 256", "p2"]], ["BatchNorm", ["disabled", "p2"]]] } },
      { id: "head", role: "action-head", name: "Diffusion policy", sub: "DDPM on joint states", col: 2, frozen: false, main: true, short: "Diffusion",
        stack: { rows: [
          { t: "in", label: "noisy joint-state sequence", c: "data-3" },
          { t: "film", label: "conditioned on the 256-d point feature", side: "cond" },
          { t: "out", label: "joint-state targets", c: "data-3" } ],
          facts: [["Formulation", ["conditional DDPM (Ho et al.), as in Diffusion Policy", "p1"]], ["Training", ["2,000 epochs", "p4"]]] } }
    ],
    inputs: [
      { to: "cloud", mod: "vision", label: "RGB-D views", n: "3 cameras", k: 3 },
      { to: "cloud", mod: "touch", label: "tactile pads", n: "16 × 16 each", k: 4 },
      { to: "head", mod: "action", label: "noisy joint states", k: 4, noisy: true }
    ],
    outputs: [{ from: "head", mod: "action", label: "joint-state targets", k: 4 }],
    links: [
      { from: "cloud", to: "pn", kind: "feeds", label: "one point set" },
      { from: "pn", to: "head", kind: "feeds", label: "256-d feature" }
    ],
    callouts: [
      "The linked training repo (binghao-huang/3d-vitac-training-code) holds only a readme that points to NVlabs/vt-refine, so this diagram uses the <b>paper only</b>.",
      "Denser, continuous touch helps: 16 × 16 continuous readings beat 8 × 8, 4 × 4 and binary 16 × 16 pads (Fig. 6)."
    ]
  });

  /* ------------------------------------------------------------------ UniT */
  RB.arch.spec({
    id: "unit", method: "unit", name: "UniT", year: 2024, parent: "diffusion-policy",
    diffRows: ["params", "vision", "backbone", "cond", "output", "steps"],
    figRef: "Xu et al. Figs. 1–2 · §IV · §VII", prov: "chicken-legs hanging config",
    lede: "A VQGAN autoencoder trained on GelSight images of one simple object. Its frozen encoder turns each tactile image into a 3 × 16 × 20 latent; a small conv head per finger feeds that into a Diffusion Policy.",
    sources: {
      p1: { kind: "paper", ref: "Xu et al. 2024, §III–IV and Figs. 1–2", url: "https://arxiv.org/abs/2408.06481" },
      p2: { kind: "paper", ref: "Xu et al. 2024, §V–VI (latent size, model size)", url: "https://arxiv.org/abs/2408.06481" },
      p3: { kind: "paper", ref: "Xu et al. 2024, §VII (policy learning)", url: "https://arxiv.org/abs/2408.06481" },
      c1: { kind: "code", repo: "ZhengtongXu/UniT", path: "UniT/config/vqvae_representation_key.yaml", commit: "52a2865", url: "https://github.com/ZhengtongXu/UniT/blob/52a2865/UniT/config/vqvae_representation_key.yaml" },
      c2: { kind: "code", repo: "ZhengtongXu/UniT", path: "UniT/config/train_legs_unit_policy.yaml", commit: "52a2865", url: "https://github.com/ZhengtongXu/UniT/blob/52a2865/UniT/config/train_legs_unit_policy.yaml" },
      c3: { kind: "code", repo: "ZhengtongXu/UniT", path: "UniT/policy/diffusion_unit_policy.py", commit: "52a2865", url: "https://github.com/ZhengtongXu/UniT/blob/52a2865/UniT/policy/diffusion_unit_policy.py" },
      c4: { kind: "code", repo: "ZhengtongXu/UniT", path: "UniT/model/tactile/utils.py", commit: "52a2865", url: "https://github.com/ZhengtongXu/UniT/blob/52a2865/UniT/model/tactile/utils.py" }
    },
    summary: {
      pattern: ["Multimodal fusion policy (vision + touch/force)", "p3"],
      params: ["79.81M (UniT representation model with a 16 × 20 latent)", "p2"],
      vision: ["4 ALOHA cameras at 224 × 224, ResNet-34 from scratch with attention pooling", "c2"],
      backbone: ["Frozen VQGAN encoder: GelSight 3 × 128 × 160 → 3 × 16 × 20", "p2", "c1"],
      head: ["1-D U-Net diffusion head, down dims 256 / 512 / 1,024, kernel 5", "c2"],
      output: ["14-DoF joint targets (7 for the one-arm task)", "p3", "c2"],
      attention: ["No transformer; the VQGAN encoder has self-attention at resolution 16", "c1"],
      cond: ["Per finger: Conv–GroupNorm–SE head → 512-d, ‖ image features ‖ joint positions, 2 steps", "p1", "c3", "c4"],
      steps: ["24 denoising steps (paper); config: 75 train / 16 DDIM", "p3", "c2"],
      chunk: ["Tₒ = 2 → 16 predicted → 8 executed", "c2"],
      rate: ["10 Hz", "p3"],
      latency: null,
      train: ["Representation: 10,854 Allen-key images (< 20 min). Policy: 170–200 demos per task", "p1", "p3"]
    },
    changes: [
      "Touch comes from a <b>frozen VQGAN encoder</b> trained self-supervised on one simple object, not from a network trained with the policy.",
      "A small <b>Conv + GroupNorm + SE</b> head per finger maps the 3 × 16 × 20 latent to 512-d.",
      "Vision uses a <b>ResNet-34</b> with attention pooling on 4 cameras.",
      "Actions are <b>14-DoF</b> ALOHA joint targets; U-Net widths drop to 256 / 512 / 1,024."
    ],
    blueprint: {
      headline: "UniT: a VQGAN latent as the sense of touch",
      note: "The VQGAN is trained once on tactile images of a single object, then frozen. At policy time each GelSight image passes through its encoder, a trainable Conv–GN–SE head per finger compresses the latent to 512-d, and those vectors join the camera features as the U-Net's FiLM condition.",
      towers: [
        { mod: "vq", title: "UniT encoder + head", sub: "VQGAN encoder frozen, head trained", compact: true,
          input: { label: "GelSight 3 × 128 × 160", caption: "resized from 240 × 320, each finger" },
          rows: [
            { t: "conv", label: "Conv in → 128 ch" },
            { t: "block", n: "4", rows: [{ t: "conv", label: "2 ResNet blocks (+ down)" }] },
            { t: "attn", label: "Mid: ResBlock · attn · ResBlock" },
            { t: "conv", label: "Conv out → z", call: ["3 × 16 × 20 latent", "p2", "c1"],
              zoom: { k: "rows", title: "VQGAN training (one object)", rows: ["tactile image x", "encoder E → z", "quantize to codebook (1,024 × 3)", "decoder G → x̂", "L1 + perceptual + patch GAN"] } },
            { t: "conv", label: "Conv–GN–SE head", call: ["128 → 256 → 512 ch, then Linear → 512", "c3", "c4"],
              zoom: { k: "rows", title: "Tactile head (per finger)", rows: ["z: 3 × 16 × 20", "Conv 3×3 → 128 · GN · SE · pool", "Conv 3×3 → 256 · GN · SE · pool", "Conv 3×3 → 512 · GN · SE · pool", "flatten → Linear → 512"] } } ],
          output: { label: "512-d per finger" } },
        { mod: "vis", title: "ResNet-34", sub: "4 cameras, from scratch", compact: true,
          input: { label: "Camera 224 × 224", caption: "high, low, 2 wrists; Tₒ = 2" },
          rows: [
            { t: "conv", label: "ResNet-34 trunk", call: ["GroupNorm, no pretraining", "c2"] },
            { t: "pool", label: "Attention pooling 2-D" } ],
          output: { label: "image features" } },
        { mod: "unet", title: "Conditional 1-D U-Net", sub: "Diffusion Policy head",
          input: { label: "Noisy action chunk Aᵏ", caption: "16 steps × 14-d, step k" },
          rows: [
            { id: "cat", t: "linear", label: "Concat [tactile ‖ image ‖ qpos]", side: "cond" },
            { t: "group", label: "Down / up path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "film", label: "FiLM: γ ⊙ x + β", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Down / upsample", call: ["Channels 256 → 512 → 1,024", "c2"] } ] },
            { t: "conv", label: "Final Conv1d → 14-d" } ],
          output: { label: "noise ε̂; 16 DDIM steps" } }
      ],
      links: [
        { from: "vis", to: "unet", toRow: "cat", label: "image" },
        { from: "vq", to: "unet", toRow: "cat", label: "tactile 512 × 2" }
      ]
    },
    modules: [
      { id: "vq", role: "touch-enc", name: "UniT encoder", sub: "VQGAN enc → 3 × 16 × 20", col: 0, frozen: "partial", short: "UniT",
        stack: { rows: [
          { t: "in", label: "GelSight Mini image (with markers)", dims: "3 × 128 × 160", c: "data-6" },
          { t: "conv", label: "VQGAN encoder: ch 128, mult [1, 1, 2, 4], 2 res blocks/level", dims: "frozen" },
          { t: "conv", label: "quant conv → pre-quantization latent", dims: "3 × 16 × 20" },
          { t: "conv", label: "Conv–GN–SE head (trainable)", dims: "→ 512" },
          { t: "out", label: "tactile feature", dims: "per finger, per step", c: "data-6" } ],
          facts: [["Latent", ["3 × 16 × 20", "p2", "c1"]], ["Codebook", ["1,024 entries of dim 3", "c1"]], ["Encoder", ["ch 128, ch_mult [1, 1, 2, 4], 2 res blocks, attention at 16", "c1"]], ["Training data", ["10,854 Allen-key or 4,831 ball images", "p1"]], ["Head", ["3 conv (128/256/512) + GroupNorm(4) + SE + max pool, Linear → 512", "c3", "c4"]]] } },
      { id: "unet", role: "action-head", name: "Conditional 1-D U-Net", sub: "256 / 512 / 1024 ch", col: 1, frozen: false, main: true, short: "U-Net",
        stack: { rows: [
          { t: "in", label: "noisy action chunk", dims: "16 × 14", c: "data-3" },
          { t: "film", label: "FiLM from [tactile ‖ image ‖ qpos]", side: "cond" },
          { t: "conv", label: "ConditionalUnet1D, kernel 5" },
          { t: "out", label: "noise ε̂", dims: "8 of 16 actions executed", c: "data-3" } ],
          facts: [["Down dims", ["256 / 512 / 1,024", "c2"]], ["Kernel", ["5", "c2"]], ["Step embedding", ["128", "c2"]], ["Steps", ["75 train, 16 DDIM (config); 24 (paper)", "p3", "c2"]]] } },
      { id: "vis", role: "vision-enc", name: "ResNet-34", sub: "4 cameras · attn pooling", col: 2, frozen: false, short: "ResNet-34",
        stack: { rows: [
          { t: "in", label: "4 RGB cameras", dims: "224 × 224, Tₒ = 2", c: "data-1" },
          { t: "conv", label: "ResNet-34 (timm, from scratch), GroupNorm" },
          { t: "pool", label: "attention_pool_2d" },
          { t: "out", label: "image features", c: "data-1" } ],
          facts: [["Model", ["resnet34, pretrained: False", "c2"]], ["Pooling", ["attention_pool_2d", "c2"]]] } }
    ],
    inputs: [
      { to: "vq", mod: "touch", label: "2 GelSight images", n: "3 × 128 × 160", k: 4 },
      { to: "unet", mod: "action", label: "noisy chunk", n: "16 × 14", k: 4, noisy: true },
      { to: "vis", mod: "vision", label: "4 cameras", n: "224 × 224", k: 4 }
    ],
    outputs: [{ from: "unet", mod: "action", label: "joint targets", n: "16 × 14", k: 4 }],
    links: [
      { from: "vq", to: "unet", kind: "film", label: "512 per finger" },
      { from: "vis", to: "unet", kind: "film", label: "image features" }
    ],
    callouts: [
      "Paper §VII reports <b>24 denoising steps</b> for policy rollouts; the released policy config sets <b>16 inference steps</b> (75 training steps).",
      "The VQ layer shapes the latent during training, but the policy code reads the <b>pre-quantization</b> latent (<code>to_latent</code>: encoder + quant conv)."
    ]
  });

  /* ------------------------------------------------------------------ FuSe */
  RB.arch.spec({
    id: "fuse", method: "fuse", name: "FuSe", year: 2025, parent: "octo",
    diffRows: ["vision", "head", "cond", "train"],
    figRef: "Jones et al. Fig. 2 · §III", prov: "Octo variant",
    lede: "Finetunes Octo with touch and audio. Two DIGIT images pass through a pretrained TVL ViT and a spectrogram through a ResNet-26; their tokens join Octo's sequence, and two language heads (contrastive and generative) force the new senses to mean something.",
    sources: {
      p1: { kind: "paper", ref: "Jones et al. 2025, §I–III and Fig. 2", url: "https://arxiv.org/abs/2501.04693" },
      p2: { kind: "paper", ref: "Jones et al. 2025, §IV-G and §V", url: "https://arxiv.org/abs/2501.04693" },
      c1: { kind: "code", repo: "fuse-model/FuSe", path: "octo_digit/scripts/configs/fuse_config.py", commit: "a8379b5", url: "https://github.com/fuse-model/FuSe/blob/a8379b5/octo_digit/scripts/configs/fuse_config.py" },
      c2: { kind: "code", repo: "fuse-model/FuSe", path: "octo_digit/octo/model/components/transformer.py", commit: "a8379b5", url: "https://github.com/fuse-model/FuSe/blob/a8379b5/octo_digit/octo/model/components/transformer.py" },
      c3: { kind: "code", repo: "fuse-model/FuSe", path: "octo_digit/octo/model/components/tvl_vit.py", commit: "a8379b5", url: "https://github.com/fuse-model/FuSe/blob/a8379b5/octo_digit/octo/model/components/tvl_vit.py" },
      c4: { kind: "code", repo: "fuse-model/FuSe", path: "octo_digit/octo/model/components/language_reconstruction_heads.py", commit: "a8379b5", url: "https://github.com/fuse-model/FuSe/blob/a8379b5/octo_digit/octo/model/components/language_reconstruction_heads.py" }
    },
    summary: {
      pattern: ["Multimodal fusion policy (vision + touch/force)", "p1"],
      params: null,
      vision: ["Third-person 256 × 256 and wrist 128 × 128 (Octo tokenizers); 2 DIGIT images 224 × 224 via the TVL ViT", "p1", "c1"],
      backbone: ["Octo-small 1.5: 12 layers, width 384, 6 heads, MLP 1,536", "c1", "c2"],
      head: ["MSE action head on a MAP readout, plus a CLIP-style contrastive head and a language-generation head", "p1", "c1"],
      output: ["Chunk of 4 × 7-d actions (delta end-effector position + gripper)", "p1", "c1"],
      attention: ["Octo's transformer over [task ‖ observation ‖ readout] tokens, 2-step window", "c1"],
      cond: ["Language (T5-base tokenizer, 24 tokens); touch and audio as extra observation tokens", "p1", "c1"],
      steps: null,
      chunk: ["4 actions", "c1"],
      rate: ["2-step window spans 0.4 s", "p2", "c1"],
      latency: null,
      train: ["27K multimodal trajectories; 50,000 steps, batch 1,024, peak lr 3 × 10⁻⁴", "p1", "c1"]
    },
    changes: [
      "Two new tokenizers: <b>touch</b> (pretrained TVL ViT on 2 background-subtracted DIGIT images) and <b>audio</b> (mel spectrogram through a ResNet-26).",
      "Two auxiliary heads tie every sense to language: a <b>CLIP-style contrastive</b> loss and a <b>language-generation</b> loss.",
      "24 language readout tokens are added beside the action readout.",
      "Finetuned from Octo-small 1.5 on 27K trajectories; the same recipe also finetunes a 3B PaliGemma VLA."
    ],
    blueprint: {
      headline: "FuSe: new senses, grounded in language",
      note: "Each DIGIT image goes through the TVL ViT and is mean-pooled to one vector; the spectrogram goes through a ResNet-26. These become observation tokens next to Octo's camera tokens. The 12-layer Octo transformer runs as pretrained; its readout tokens feed the action head and, during training, two language heads.",
      towers: [
        { mod: "tok", title: "TVL ViT-S/16", sub: "pretrained touch encoder", compact: true,
          input: { label: "DIGIT image 224 × 224", caption: "2 fingers, background subtracted" },
          rows: [
            { t: "embed", label: "Patch embed + cls + pos", call: ["16 × 16 patches, width 384", "c3"] },
            { t: "block", n: "12", rows: [
              { t: "attn", label: "Multi-head attention", call: ["6 heads", "c3"] },
              { t: "ffn", label: "MLP (ratio 4)" } ] },
            { t: "pool", label: "Mean over patches → 768", call: ["fc_norm, Dense 768", "c3"] } ],
          output: { label: "1 vector per tactile image" } },
        { mod: "octo", title: "Octo-small transformer", sub: "pretrained generalist, finetuned",
          input: { label: "Task + observation tokens", caption: "T5 language · cameras · touch · audio" },
          rows: [
            { id: "emb", t: "embed", label: "Per-group projection → 384", call: ["Touch tokens here; audio via ResNet-26 on a mel spectrogram", "c1"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Block-causal attention", call: ["6 heads × 64, width 384", "c1", "c2"], zoom: { k: "heads", q: 6, kv: 6, hd: 64, title: "Octo-small attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 1,536", "c2"], zoom: { k: "mlp", act: "GELU", d: "384", ff: "1,536", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Readout tokens", call: ["Action readout + 24 language readouts", "c1"] } ],
          output: { label: "readout embeddings" } },
        { mod: "heads", title: "Heads", sub: "action + two language losses", compact: true,
          input: { label: "Readout tokens", caption: "window of 2 steps" },
          rows: [
            { t: "attn", label: "MAP pooling (per head)" },
            { t: "linear", label: "Action head (MSE)", call: ["4 × 7-d chunk", "c1"] },
            { t: "linear", label: "CLIP contrastive head", zoom: { k: "rows", title: "Language grounding losses", rows: ["obs embedding per modality mix", "contrast with instruction (CLIP)", "generate instruction (CE loss)", "L = L_BC + β·L_gen + λ·L_contrast"] } },
            { t: "linear", label: "Generation head → vocab", call: ["MAP + Dense to 32,218 tokens", "c4"] } ],
          output: { label: "actions (+ language at train time)" } }
      ],
      links: [
        { from: "octo", to: "heads", toRow: "input", label: "readouts" },
        { from: "tok", to: "octo", toRow: "emb", label: "touch tokens" }
      ]
    },
    modules: [
      { id: "tok", role: "touch-enc", name: "TVL ViT + ResNet-26", sub: "touch and audio tokenizers", col: 0, frozen: false, short: "Tokenizers",
        stack: { rows: [
          { t: "in", label: "2 DIGIT images (224 × 224) · mel spectrogram", c: "data-6" },
          { t: "block", label: "TVL ViT-S/16 block", n: "12", rows: [{ t: "attn", label: "MHA, 6 heads, width 384" }, { t: "ffn", label: "MLP ratio 4" }] },
          { t: "pool", label: "mean over patches → Dense 768", dims: "one vector per image" },
          { t: "conv", label: "audio: ResNet-26 (no FiLM)", dims: "spectrogram as an image" },
          { t: "out", label: "touch + audio tokens", c: "data-6" } ],
          facts: [["Touch encoder", ["TVL ViT, depth 12, width 384, 6 heads, patch 16", "p1", "c3"]], ["Touch input", ["2 DIGIT images, background subtracted, 224 × 224", "p1", "c1"]], ["Audio encoder", ["ResNet-26 on a mel spectrogram", "p1", "c1"]]] } },
      { id: "octo", role: "net", roleLabel: "Transformer backbone", name: "Octo-small 1.5", sub: "12 × 384 · 6 heads", col: 1, frozen: false, main: true, short: "Octo",
        stack: { rows: [
          { t: "in", label: "[language | cameras | touch | audio | readouts]", dims: "2-step window", c: "data-2" },
          { t: "block", label: "Octo transformer block", n: "12", rows: [{ t: "attn", label: "MHA, 6 heads × 64" }, { t: "ffn", label: "MLP 384 → 1536 → 384" }] },
          { t: "out", label: "readout embeddings", c: "data-2" } ],
          facts: [["Checkpoint", ["octo-small-1.5", "c1"]], ["Size", ["12 layers, width 384, 6 heads, MLP 1,536", "c2"]], ["Language", ["T5-base tokenizer, 24 tokens", "c1"]], ["Steps", ["50,000, batch 1,024", "c1"]]] } },
      { id: "heads", role: "action-head", name: "Action + language heads", sub: "MSE · CLIP · generation", col: 2, frozen: false, short: "Heads",
        stack: { rows: [
          { t: "in", label: "readout tokens", c: "data-3" },
          { t: "linear", label: "MSE action head (MAP)", dims: "4 × 7" },
          { t: "linear", label: "CLIP contrastive head (MAP)", dims: "train only" },
          { t: "linear", label: "generation head: MAP → Dense 32,218", dims: "train, and zero-shot descriptions" },
          { t: "out", label: "actions", c: "data-3" } ],
          facts: [["Action head", ["MSE, horizon 4, dim 7", "c1"]], ["Loss", ["L_BC + β·L_gen + λ·L_contrast", "p1"]], ["Generation vocab", ["32,218", "c4"]]] } }
    ],
    inputs: [
      { to: "tok", mod: "touch", label: "DIGIT × 2", n: "224²", k: 3 },
      { to: "tok", mod: "other", label: "audio", n: "mel", k: 2 },
      { to: "octo", mod: "vision", label: "3rd-person + wrist", n: "256² · 128²", k: 4 },
      { to: "octo", mod: "lang", label: "instruction", n: "24 tokens", k: 3 }
    ],
    outputs: [
      { from: "heads", mod: "action", label: "action chunk", n: "4 × 7", k: 4 },
      { from: "heads", mod: "lang", label: "description", k: 2 }
    ],
    links: [
      { from: "tok", to: "octo", kind: "prefix", label: "observation tokens" },
      { from: "octo", to: "heads", kind: "feeds", label: "readout tokens" }
    ],
    callouts: [
      "The paper calls the generative head \"a single transformer\"; in the released Octo code it is a <b>MAP attention-pooling head</b> plus one Dense layer to the vocabulary.",
      "Without the two language losses the finetuned policy ignores the new sensors; removing either loss lowers shopping-bag success, mostly on unseen objects (Fig. 7)."
    ]
  });

  /* ------------------------------------------------------------------ Tactile-VLA */
  RB.arch.spec({
    id: "tactile-vla", method: "tactile-vla", name: "Tactile-VLA", year: 2025, parent: "pi0",
    diffRows: ["params", "head", "output", "cond", "attention"],
    figRef: "Huang et al. Fig. 2 · §2.1–2.3", prov: "paper only (no code released)",
    lede: "π0 with touch in the prefix and force in the output. An MLP compresses the tactile history into one token beside the image and text tokens; a new action expert predicts a target position and a target contact force for a hybrid controller.",
    sources: {
      p1: { kind: "paper", ref: "Huang et al. 2025, §2.1 and Fig. 2", url: "https://arxiv.org/abs/2507.09160" },
      p2: { kind: "paper", ref: "Huang et al. 2025, §2.2 (hybrid controller)", url: "https://arxiv.org/abs/2507.09160" },
      p3: { kind: "paper", ref: "Huang et al. 2025, §2.3 and §3.4 (Tactile-VLA-CoT)", url: "https://arxiv.org/abs/2507.09160" },
      p4: { kind: "paper", ref: "Huang et al. 2025, §2.4 (data collection)", url: "https://arxiv.org/abs/2507.09160" },
      p5: { kind: "paper", ref: "Black et al. 2024 (π0), App. B", url: "https://arxiv.org/abs/2410.24164" },
      c1: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/gemma.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/gemma.py" }
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p1"],
      params: ["Gemma 2.6B VLM + 300M tactile-aware action expert", "p1"],
      vision: ["Pretrained ViT encoder over the last H frames (as in π0)", "p1"],
      backbone: ["Gemma 2.6B, initialized from π0", "p1"],
      head: ["Tactile-aware action expert (300M), randomly initialized", "p1"],
      output: ["Target end-effector position and target contact force", "p1"],
      attention: ["Non-causal attention over the prefix [images ‖ language ‖ tactile token]", "p1"],
      cond: ["H-step tactile history (normal + shear) → MLP → one prefix token", "p1"],
      steps: null, chunk: null,
      rate: ["Tactile recorded at 100 Hz, video at 20 Hz; tactile downsampled to the frames", "p4"],
      latency: null,
      train: ["UMI-style handheld demos with dual tactile sensors; flow matching on position and force", "p1", "p4"]
    },
    changes: [
      "A <b>tactile token</b>: an MLP compresses H steps of normal + shear readings into one token in the VLM prefix.",
      "The action expert is a new, randomly initialized <b>tactile-aware expert</b> that also outputs a target contact force.",
      "A <b>hybrid position–force controller</b> shifts the position target by K·ΔF when the force error exceeds a threshold.",
      "Tactile-VLA-CoT: at fixed intervals the VLM decoder writes a failure analysis and a corrected instruction."
    ],
    blueprint: {
      headline: "Tactile-VLA: touch in, force out",
      note: "The tactile token sits in the prefix with the image and text tokens, so the pretrained VLM reads touch with its full attention. The action expert shares attention with the VLM as in π0 and outputs position and force targets, which a hybrid controller turns into position commands.",
      towers: [
        { mod: "tac", title: "Tactile encoder", sub: "MLP over the history", compact: true,
          input: { label: "Tactile history", caption: "H steps, normal + shear, 2 pads" },
          rows: [
            { t: "linear", label: "Concatenate H readings" },
            { t: "mlp", label: "MLP encoder", zoom: { k: "rows", title: "Tactile token", rows: ["normal + shear, both pads", "stack the last H readings", "MLP (random init)", "1 token, appended to the prefix"] } } ],
          output: { label: "1 tactile token" } },
        { mod: "vlm", title: "VLM (from π0)", sub: "ViT + Gemma 2.6B",
          input: { label: "Image + text + tactile tokens", caption: "last H frames, instruction" },
          rows: [
            { t: "embed", label: "ViT image tokens + text embed" },
            { id: "tt", t: "embed", label: "+ tactile token" },
            { t: "block", n: "18", rows: [
              { id: "att", t: "attn", label: "Prefix self-attention", call: ["Width 2,048; 8 query heads, 1 KV head (π0)", "p5", "c1"], callDy: -24 },
              { t: "ffn", label: "Feed forward (GeGLU)" } ] },
            { t: "norm", label: "Final RMSNorm", call: ["Decoder also writes CoT text", "p3"], zoom: { k: "rows", title: "Tactile-VLA-CoT (at fixed intervals)", rows: ["ask: is the task done?", "if not: reason over touch and force", "e.g. \"normal force too low\"", "emit a corrected instruction"] } } ],
          output: { label: "prefix keys and values" } },
        { mod: "expert", title: "Tactile-aware expert", sub: "300M, randomly initialized",
          input: { label: "State + noisy actions", caption: "flow matching on [position ‖ force]" },
          rows: [
            { t: "linear", label: "State + action projections" },
            { id: "att", t: "attn", label: "Expert layers (joint attention)", call: ["300M parameters; depth not stated", "p1"] },
            { t: "linear", label: "Output: position + force",
              zoom: { k: "rows", title: "Hybrid position–force controller", rows: ["targets P_target, F_target", "ΔF = F_target − F_measured", "if ‖ΔF‖ > τ: P = P_target + K·ΔF", "PID drives joints to P", "gripper width sets grasp force"] } } ],
          output: { label: "P_target, F_target → controller" } }
      ],
      links: [{ from: "tac", to: "vlm", toRow: "tt", label: "tactile token" }],
      shared: [{ a: ["vlm", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "tac", role: "touch-enc", name: "Tactile MLP", sub: "H steps → 1 token", col: 0, frozen: false, short: "Tactile",
        stack: { rows: [
          { t: "in", label: "H tactile readings (normal + shear)", c: "data-6" },
          { t: "mlp", label: "MLP on the concatenated history" },
          { t: "out", label: "one tactile token", c: "data-6" } ],
          facts: [["Input", ["normal and shear force from dual gripper tactile sensors", "p1", "p4"]], ["Init", ["random", "p1"]]] } },
      { id: "vlm", role: "vlm", name: "Gemma 2.6B (π0)", sub: "ViT + Gemma, π0 init", col: 1, frozen: false, short: "VLM",
        stack: { rows: [
          { t: "in", label: "[images | language | tactile token]", c: "data-2" },
          { t: "block", label: "Gemma block (π0 weights)", n: "18", rows: [{ t: "attn", label: "non-causal over the prefix" }, { t: "ffn", label: "GeGLU" }] },
          { t: "out", label: "prefix keys/values; CoT text in the CoT variant", c: "data-2" } ],
          facts: [["Size", ["2.6B", "p1"]], ["Init", ["π0", "p1"]], ["Depth / width (π0)", ["18 / 2,048", "p5", "c1"]]] } },
      { id: "expert", role: "action-expert", name: "Tactile-aware expert", sub: "300M · position + force", col: 2, frozen: false, main: true, short: "Expert",
        stack: { rows: [
          { t: "in", label: "state + noisy [position ‖ force] actions", c: "data-3" },
          { t: "attn", label: "expert layers with joint attention to the prefix" },
          { t: "linear", label: "output projection to position + force" },
          { t: "out", label: "P_target, F_target", dims: "to the hybrid controller", c: "data-3" } ],
          facts: [["Size", ["300M", "p1"]], ["Loss", ["conditional flow matching on kinematic and force dimensions", "p1"]], ["Controller", ["P = P_target + K·ΔF if ‖ΔF‖ > τ, then PID", "p2"]]] } }
    ],
    inputs: [
      { to: "tac", mod: "touch", label: "tactile history", n: "H steps", k: 4 },
      { to: "vlm", mod: "vision", label: "last H frames", k: 4 },
      { to: "vlm", mod: "lang", label: "instruction", k: 2 },
      { to: "expert", mod: "state", label: "proprio state", k: 1 },
      { to: "expert", mod: "action", label: "noisy targets", k: 4, noisy: true }
    ],
    outputs: [{ from: "expert", mod: "action", label: "position + force", k: 4 }],
    links: [
      { from: "tac", to: "vlm", kind: "prefix", label: "1 tactile token" },
      { from: "vlm", to: "expert", kind: "joint-attn", label: "shared self-attn" }
    ],
    mask: { name: "Prefix + expert (π0 style)", ref: "p1", axes: [{ label: "images + text + touch", short: "prefix", mod: "touch" }, { label: "state + actions", short: "A", mod: "action" }], m: ["10", "11"],
      note: "The paper states only that the prefix is non-causal; how the state and action tokens are split into blocks follows π0 and is not described." },
    callouts: [
      "<b>No official code</b> was found; all numbers are from the paper, and the VLM's layer sizes come from π0, whose weights it loads.",
      "With the same motion data, the model maps adverbs to force: \"softly\" 0.51 N vs \"hard\" 2.57 N on the USB task, where π0 does not change its force (Table 2)."
    ]
  });

  /* ------------------------------------------------------------------ TacDiffusion */
  RB.arch.spec({
    id: "tacdiffusion", method: "tacdiffusion", name: "TacDiffusion", year: 2024,
    figRef: "Wu et al. Figs. 1–2 · §III · Tables I–II", prov: "DF₃ (N = 512)",
    lede: "A tiny diffusion model whose action is a force. A residual MLP denoises a 6-D feed-forward wrench from the current and previous wrench and velocity readings; a second-order filter stretches its 142 Hz output to the 1 kHz impedance loop.",
    sources: {
      p1: { kind: "paper", ref: "Wu et al. 2024, §III-A/B and Fig. 2", url: "https://arxiv.org/abs/2409.11047" },
      p2: { kind: "paper", ref: "Wu et al. 2024, §IV-B, Tables I–II", url: "https://arxiv.org/abs/2409.11047" },
      p3: { kind: "paper", ref: "Wu et al. 2024, §III-C/D (controller and filter)", url: "https://arxiv.org/abs/2409.11047" },
      p4: { kind: "paper", ref: "Wu et al. 2024, §IV-C, Table III", url: "https://arxiv.org/abs/2409.11047" },
      c1: { kind: "code", repo: "popnut123/TacDiffusion", path: "helper_functions/models.py", commit: "6a5567c", url: "https://github.com/popnut123/TacDiffusion/blob/6a5567c/helper_functions/models.py" },
      c2: { kind: "code", repo: "popnut123/TacDiffusion", path: "1_model_train.py", commit: "6a5567c", url: "https://github.com/popnut123/TacDiffusion/blob/6a5567c/1_model_train.py" }
    },
    summary: {
      pattern: ["Force-domain diffusion policy (MLP)", "p1"],
      params: null,
      vision: "None (no camera)",
      backbone: ["Residual MLP noise estimator, hidden width N = 512 (DF₃)", "p2", "c2"],
      head: ["DDPM ε-prediction, 50 steps, β from 10⁻⁴ to 10⁻²", "p2", "c2"],
      output: ["6-D feed-forward wrench F_df (force + torque)", "p1"],
      attention: "None (MLP)",
      cond: ["18-d observation now and one step earlier: external wrench, internal wrench, EE velocity", "p1", "c2"],
      steps: ["50 denoising steps", "p2", "c2"],
      chunk: "Single step (no chunk)",
      rate: ["DF₃ infers at 141.8 Hz; the filter feeds a 1 kHz impedance loop", "p2", "p3"],
      latency: null,
      train: ["1,500 behavior-tree demos on one cuboid, recorded at 1 kHz; 1,500 epochs, batch 4,096", "p2"]
    },
    blueprint: {
      headline: "TacDiffusion: diffusion in the force domain",
      note: "Observation now, observation one step earlier, the noisy wrench and the step are each embedded to 128-d and concatenated. Three fully connected blocks follow; the last two re-read the raw noisy wrench and step and add a scaled residual. The denoised wrench is smoothed by a second-order filter and added as feed-forward force in impedance control.",
      towers: [
        { mod: "net", title: "Noise estimator ε̂", sub: "residual MLP, ONNX export",
          input: { label: "Noisy wrench aᵗ, obs, t", caption: "obs: 18-d now + 18-d previous" },
          rows: [
            { t: "embed", label: "Obs embed MLP (×2 steps)", call: ["18 → 128 → 128, shared", "p1", "c1"] },
            { t: "embed", label: "Wrench + step embeds", call: ["6 → 128 → 128; sine time 1 → 128", "c1"],
              zoom: { k: "rows", title: "Time embedding (TimeSiren)", rows: ["diffusion step t", "Linear 1 → 128, no bias", "sin(·)", "Linear 128 → 128"] } },
            { t: "linear", label: "Concat 4 × 128 = 512" },
            { t: "mlp", label: "FC block: Linear · BN · GELU", call: ["512 → N, N = 512 (DF₃)", "p2", "c1", "c2"],
              zoom: { k: "rows", title: "FC block", rows: ["input", "Linear → N", "BatchNorm1d", "GELU"] } },
            { t: "block", n: "2", rows: [
              { t: "linear", label: "Concat [h/√2 ‖ aᵗ ‖ t]" },
              { t: "mlp", label: "FC block: Linear · BN · GELU" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Concat → Linear to 6", call: ["noise on the 6-D wrench", "c1"] } ],
          output: { label: "ε̂; 50 DDPM steps → F_df" } },
        { mod: "ctrl", title: "Filter + impedance control", sub: "no learned weights", compact: true,
          input: { label: "Raw wrench F_df", caption: "50–500 Hz, depending on N" },
          rows: [
            { t: "linear", label: "2nd-order dynamic filter", call: ["α 0.9, β 0.3; output at 1 kHz", "p3"],
              zoom: { k: "rows", title: "Dynamic-system filter", rows: ["F_df from diffusion", "F̈ff = α(β(F_df − Fff) − Ḟff)", "integrate at 1 kHz", "Fff to the controller"] } },
            { t: "linear", label: "Impedance + feed-forward", call: ["τ = Jᵀ[Fff + K e + D ė + M ẍ_d] + …", "p3"] } ],
          output: { label: "joint torques τₘ" } }
      ],
      links: [{ from: "net", to: "ctrl", toRow: "input", label: "F_df" }]
    },
    modules: [
      { id: "net", role: "action-head", roleLabel: "Diffusion policy", name: "Residual MLP ε̂", sub: "N = 512 · 50 steps", col: 0, frozen: false, main: true, short: "ε̂ MLP",
        stack: { rows: [
          { t: "in", label: "noisy wrench aᵗ (6) · obs now, prev (18 + 18) · step t", c: "data-3" },
          { t: "embed", label: "three embedding MLPs + TimeSiren", dims: "→ 4 × 128" },
          { t: "mlp", label: "FC1: Linear 512 → N, BatchNorm, GELU" },
          { t: "block", label: "residual FC block, re-reads aᵗ and t", n: "2", rows: [{ t: "mlp", label: "Linear (N + 6 + 1) → N, BN, GELU" }, { t: "add", span: 1 }] },
          { t: "linear", label: "Linear (N + 6 + 1) → 6" },
          { t: "out", label: "ε̂", dims: "50 DDPM steps → F_df", c: "data-3" } ],
          facts: [["Hidden N", ["128 / 256 / 512 / 1,024 tried; 512 best", "p2", "p4"]], ["Speed", ["503.8 / 297.5 / 141.8 / 51.2 Hz for N = 128 … 1,024", "p2"]], ["Embeddings", ["128-d", "c1", "c2"]], ["Schedule", ["50 steps, β 10⁻⁴ → 10⁻²", "p2", "c2"]], ["Zero-shot success (DF₃)", ["95.7 % over 4 novel parts", "p4"]]] } },
      { id: "ctrl", role: "net", roleLabel: "Controller (not learned)", name: "Filter + impedance", sub: "1 kHz · feed-forward force", col: 1, frozen: true, short: "Control",
        note: "Not learned: a fixed second-order filter and a Cartesian impedance controller.",
        stack: { rows: [
          { t: "in", label: "F_df at 50–500 Hz", c: "data-3" },
          { t: "linear", label: "F̈ff = α(β(F_df − Fff) − Ḟff)", dims: "α 0.9, β 0.3" },
          { t: "linear", label: "impedance control with feed-forward Fff", dims: "1 kHz" },
          { t: "out", label: "joint torques", c: "data-3" } ],
          facts: [["Filter gains", ["α 0.9, β 0.3", "p3"]], ["Loop", ["1 kHz real-time", "p3"]], ["Effect", ["+9.15 % success over no filter", "p4"]]] } }
    ],
    inputs: [
      { to: "net", mod: "touch", label: "wrenches + EE velocity", n: "18-d × 2 steps", k: 4 },
      { to: "net", mod: "action", label: "noisy wrench", n: "6-d", k: 2, noisy: true }
    ],
    outputs: [{ from: "ctrl", mod: "action", label: "joint torques", n: "1 kHz", k: 3 }],
    links: [{ from: "net", to: "ctrl", kind: "feeds", label: "F_df|6-D wrench" }],
    callouts: [
      "The diffusion model replaces a behavior-tree sub-skill after \"approach\" and \"contact\"; it learned to wiggle, unstick and push from 1,500 expert runs on one cuboid and transfers zero-shot to a key, two cylinders and a prism.",
      "Model size is a speed trade-off: N = 1,024 fits best but runs at 51.2 Hz, too slow for the 1 kHz loop (Table II)."
    ]
  });

  /* ------------------------------------------------------------------ M3L */
  RB.arch.spec({
    id: "m3l", method: "m3l", name: "M3L", year: 2023,
    figRef: "Sferrazza et al. Fig. 1 · §4 · App. C", prov: "tactile insertion setup",
    lede: "PPO on top of a vision–touch masked autoencoder. Image and taxel maps become tokens in one ViT; the MAE loss reconstructs both from 5 % of the tokens while PPO gradients flow into the same encoder.",
    sources: {
      p1: { kind: "paper", ref: "Sferrazza et al. 2023, §4 and Fig. 1", url: "https://arxiv.org/abs/2311.00924" },
      p2: { kind: "paper", ref: "Sferrazza et al. 2023, App. C, Table 1", url: "https://arxiv.org/abs/2311.00924" },
      p3: { kind: "paper", ref: "Sferrazza et al. 2023, §3 and Fig. 2 (observations)", url: "https://arxiv.org/abs/2311.00924" },
      c1: { kind: "code", repo: "carlosferrazza/m3l", path: "train.py", commit: "ec9786b", url: "https://github.com/carlosferrazza/m3l/blob/ec9786b/train.py" },
      c2: { kind: "code", repo: "carlosferrazza/m3l", path: "models/pretrain_models.py", commit: "ec9786b", url: "https://github.com/carlosferrazza/m3l/blob/ec9786b/models/pretrain_models.py" }
    },
    summary: {
      pattern: ["Actor–critic", "p1"],
      params: null,
      vision: ["64 × 64 RGB, 4 stacked frames; early CNN → 8 × 8 = 64 tokens", "p3", "c1", "c2"],
      backbone: ["Shared ViT encoder: 4 layers, width 256, 4 heads, MLP 512", "c1"],
      head: ["1 transformer layer + mean pooling, then actor and critic MLPs (256, 256)", "p1", "c1", "c2"],
      output: ["Gaussian action mean (PPO) and a value estimate", "p1"],
      attention: ["Full attention over image and tactile tokens; masked only for reconstruction", "p1"],
      cond: ["Taxel force maps, two 32 × 32 × 3 grids (2 shear + 1 pressure), 4 frames", "p3", "c1"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["PPO: 8 envs, rollout 32,768, 10 epochs, lr 10⁻⁴; MAE masking 95 %, tactile weight 10", "p2", "c1"]
    },
    blueprint: {
      headline: "M3L: one ViT for pixels and taxels",
      note: "Early CNNs turn image and taxel maps into 8 × 8 feature grids; with 2-D sin-cos positions and a modality embedding they form one token sequence. For the MAE loss 95 % of tokens are dropped and a decoder reconstructs both senses; for PPO the same encoder runs unmasked and a small transformer head pools its tokens.",
      towers: [
        { mod: "cnn", title: "Early CNNs", sub: "one for image, one for touch", compact: true,
          input: { label: "Image + 2 taxel maps", caption: "64 × 64 RGB; 32 × 32 × 3 each; 4 frames" },
          rows: [
            { t: "conv", label: "Image: 3 convs 4×4 s2, 1×1", call: ["32 → 64 → 128 → 256 ch; 8 × 8 grid", "c2"] },
            { t: "conv", label: "Touch: 4×4 s2 ×2, 3×3, 1×1", call: ["32 × 32 → 8 × 8 per sensor", "c2"] },
            { t: "embed", label: "+ sin-cos pos + modality emb" } ],
          output: { label: "64 image + 64 per tactile map" } },
        { mod: "vit", title: "MAE encoder (ViT)", sub: "shared by representation and policy",
          input: { label: "Visual + tactile tokens", caption: "256-d each" },
          rows: [
            { t: "linear", label: "Random masking (MAE only)", call: ["95 % of tokens dropped", "p2", "c1"],
              zoom: { k: "rows", title: "MAE decoder (training)", rows: ["visible tokens + mask tokens", "+ sin-cos positions", "decoder: 3 layers, d 256, 4 heads", "predict pixels and taxels", "L = MSE_pixels + 10 · MSE_taxels"] } },
            { t: "block", n: "4", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["4 heads × 64, width 256", "c1", "c2"], zoom: { k: "heads", q: 4, kv: 4, hd: 64, title: "Encoder attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 512", "c1"], zoom: { k: "mlp", act: "GELU", d: "256", ff: "512", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" } ],
          output: { label: "multimodal tokens z" } },
        { mod: "pol", title: "Actor–critic head", sub: "PPO, gradients reach the encoder", compact: true,
          input: { label: "Tokens z (unmasked)", caption: "vision + touch" },
          rows: [
            { t: "attn", label: "Transformer layer", call: ["1 layer, 4 heads, MLP 512", "c2"] },
            { t: "pool", label: "Mean over tokens" },
            { t: "mlp", label: "Actor / critic MLPs", call: ["256, 256, tanh", "c1"] } ],
          output: { label: "action mean, value" } }
      ],
      links: [
        { from: "vit", to: "pol", toRow: "input", label: "tokens" },
        { from: "cnn", to: "vit", toRow: "input", label: "token grids" }
      ]
    },
    modules: [
      { id: "cnn", role: "touch-enc", roleLabel: "Tokenizers", name: "Early CNNs", sub: "image + taxel → 8 × 8 grids", col: 0, frozen: false, short: "CNNs",
        stack: { rows: [
          { t: "in", label: "RGB 64 × 64 and taxel maps 32 × 32 × 3", dims: "4 frames stacked on channels", c: "data-6" },
          { t: "conv", label: "image: Conv 4×4 s2 × 3 → 1×1", dims: "32 / 64 / 128 → 256 ch" },
          { t: "conv", label: "touch: Conv 4×4 s2 × 2, 3×3 s1 → 1×1", dims: "→ 256 ch" },
          { t: "out", label: "8 × 8 token grid per input", c: "data-6" } ],
          facts: [["Image", ["64 × 64, 4 frames", "p3", "c1"]], ["Touch", ["two 32 × 32 taxel grids, 2 shear + 1 pressure", "p3"]], ["Token width", ["256", "c1"]]] } },
      { id: "vit", role: "fusion", roleLabel: "Multimodal encoder", name: "MAE ViT encoder", sub: "4 × 256 · 4 heads", col: 1, frozen: false, main: true, short: "ViT",
        stack: { rows: [
          { t: "in", label: "visual + tactile tokens (+ positions, modality)", c: "data-6" },
          { t: "linear", label: "masking 95 % (representation loss only)" },
          { t: "block", label: "ViT block (pre-norm)", n: "4", rows: [{ t: "attn", label: "MHA, 4 heads × 64" }, { t: "ffn", label: "MLP 256 → 512 → 256, GELU" }] },
          { t: "out", label: "tokens z", dims: "to the MAE decoder and the policy", c: "data-6" } ],
          facts: [["Encoder", ["depth 4, width 256, 4 heads, MLP 512", "c1"]], ["Decoder", ["depth 3, width 256, 4 heads", "c1"]], ["Masking", ["95 %", "p2", "c1"]], ["Loss", ["MSE pixels + 10 × MSE taxels", "p1", "p2"]]] } },
      { id: "pol", role: "critic", roleLabel: "Actor–critic", name: "PPO head", sub: "1 transformer layer + MLPs", col: 2, frozen: false, short: "PPO",
        stack: { rows: [
          { t: "in", label: "unmasked tokens z", c: "data-3" },
          { t: "attn", label: "transformer layer, then mean pool", dims: "256" },
          { t: "mlp", label: "actor MLP (256, 256) · critic MLP (256, 256)" },
          { t: "out", label: "Gaussian action mean, value", c: "data-3" } ],
          facts: [["Algorithm", ["PPO; its gradients also train the encoder", "p1"]], ["Rollout", ["32,768 steps, 8 envs", "p2", "c1"]], ["Epochs / lr / batch", ["10 / 10⁻⁴ / 512", "p2", "c1"]]] } }
    ],
    inputs: [
      { to: "cnn", mod: "vision", label: "RGB 64 × 64", n: "4 frames", k: 3 },
      { to: "cnn", mod: "touch", label: "taxel maps", n: "2 × 32 × 32", k: 3 }
    ],
    outputs: [
      { from: "pol", mod: "action", label: "action mean", k: 2 },
      { from: "pol", mod: "other", label: "value", k: 1 },
      { from: "vit", mod: "vision", label: "pixel + taxel recon.", k: 2 }
    ],
    links: [
      { from: "cnn", to: "vit", kind: "prefix", label: "tokens" },
      { from: "vit", to: "pol", kind: "feeds", label: "z (no mask)" }
    ],
    mask: { name: "Full attention", ref: "p1", axes: [{ label: "image tokens", short: "img", mod: "vision" }, { label: "tactile tokens", short: "tac", mod: "touch" }], m: ["11", "11"],
      note: "Vision and touch attend to each other inside one encoder; the \"sequential\" baseline that blocks this does worse." },
    callouts: [
      "Paper vs code: the paper gives the actor and the critic <b>each</b> a transformer layer; the code has <b>one</b> shared features extractor (1 transformer layer + mean pool) feeding separate 256-256 MLPs.",
      "Because the encoder accepts variable-length input, an M3L encoder trained on vision + touch can run a <b>vision-only</b> policy at test time and still keep most of the generalization gain."
    ]
  });

  /* ------------------------------------------------------------------ ViTaL */
  RB.arch.spec({
    id: "vital", method: "vital", name: "ViTaL", year: 2025,
    figRef: "Zhao et al. Fig. 2 · §3 · App. A1", prov: "",
    lede: "A local visuotactile policy plus a VLM for reaching. A ResNet-18 on the wrist camera and an MLP on 15-d AnySkin readings feed a small GPT that predicts 10-step action chunks; a residual actor-critic trained online adds small offsets.",
    sources: {
      p1: { kind: "paper", ref: "Zhao et al. 2025, §3 and Fig. 2", url: "https://arxiv.org/abs/2506.13762" },
      p2: { kind: "paper", ref: "Zhao et al. 2025, App. A1 and Table 6", url: "https://arxiv.org/abs/2506.13762" },
      p3: { kind: "paper", ref: "Zhao et al. 2025, §4.1 (setup)", url: "https://arxiv.org/abs/2506.13762" },
      c1: { kind: "code", repo: "Exiam6/ViTaL", path: "agent/bc.py", commit: "4f349cf", url: "https://github.com/Exiam6/ViTaL/blob/4f349cf/agent/bc.py" },
      c2: { kind: "code", repo: "Exiam6/ViTaL", path: "agent/actor_critic_nets/gpt.py", commit: "4f349cf", url: "https://github.com/Exiam6/ViTaL/blob/4f349cf/agent/actor_critic_nets/gpt.py" },
      c3: { kind: "code", repo: "Exiam6/ViTaL", path: "agent/actor_critic_nets/mlp.py", commit: "4f349cf", url: "https://github.com/Exiam6/ViTaL/blob/4f349cf/agent/actor_critic_nets/mlp.py" },
      c4: { kind: "code", repo: "Exiam6/ViTaL", path: "cfgs/config.yaml", commit: "4f349cf", url: "https://github.com/Exiam6/ViTaL/blob/4f349cf/cfgs/config.yaml" },
      c5: { kind: "code", repo: "Exiam6/ViTaL", path: "cfgs/suite/xarm.yaml", commit: "4f349cf", url: "https://github.com/Exiam6/ViTaL/blob/4f349cf/cfgs/suite/xarm.yaml" },
      c6: { kind: "code", repo: "Exiam6/ViTaL", path: "agent/networks/gpt.py", commit: "4f349cf", url: "https://github.com/Exiam6/ViTaL/blob/4f349cf/agent/networks/gpt.py" }
    },
    summary: {
      pattern: ["Multimodal fusion policy (vision + touch/force)", "p1"],
      params: ["7.6M base policy; the residual RL phase adds 2.46M", "p2"],
      vision: ["Wrist fisheye RGB 128 × 128, ResNet-18 from scratch → 256", "p2", "p3", "c1"],
      backbone: ["minGPT: 8 layers, 4 heads, width 256", "c2"],
      head: ["Deterministic MLP head → 10-step chunk; residual actor and twin critics (n-step DDPG)", "p1", "p2", "c2", "c3"],
      output: ["Relative end-effector actions (7-d), chunk 10, temporal ensembling", "p2", "c5"],
      attention: ["Causal attention over [image ‖ tactile ‖ action query] tokens", "c2", "c6"],
      cond: ["AnySkin 15-d reading → MLP (256, 256) → 256-d token", "p2", "c1"],
      steps: null,
      chunk: ["10 actions, exponential ensembling (m = 0.01)", "p2"],
      rate: ["6 Hz (demos at 30 Hz, subsampled)", "p2"],
      latency: null,
      train: ["32 demos per task + 45 min online residual RL (about 16k steps)", "p2"]
    },
    blueprint: {
      headline: "ViTaL: local visuotactile GPT + residual RL",
      note: "Each observation becomes one 256-d token (image, touch); a learned action token is appended and the GPT's last output predicts a 10-step chunk. Online, the encoders and base policy are frozen and a small actor adds a bounded offset to the ensembled base action, trained with n-step DDPG. A VLM (Molmo) only picks the starting point.",
      towers: [
        { mod: "enc", title: "Encoders", sub: "trained with BC, frozen for RL", compact: true,
          input: { label: "Wrist image + AnySkin", caption: "128 × 128 fisheye; 15-d magnetometer" },
          rows: [
            { t: "conv", label: "ResNet-18 → 256", call: ["random init, semantic augmentation", "p1", "p2"] },
            { t: "mlp", label: "Tactile MLP → 256", call: ["hidden 256, 256", "p2", "c1"] } ],
          output: { label: "2 tokens × 256" } },
        { mod: "gpt", title: "minGPT base policy", sub: "behavior cloning, action chunking",
          input: { label: "[image, tactile, action] tokens", caption: "1 learned action token appended" },
          rows: [
            { t: "embed", label: "Token + position embedding", call: ["Linear 256 → 256, learned positions", "c6"] },
            { t: "block", n: "8", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Causal self-attention", call: ["4 heads × 64, width 256", "c2"], zoom: { k: "heads", q: 4, kv: 4, hd: 64, title: "GPT attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["256 → 1,024 → 256, GELU", "c6"], zoom: { k: "mlp", act: "GELU", d: "256", ff: "1,024", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "mlp", label: "Deterministic head (2 layers)", call: ["last token → 10 × 7 actions", "c2", "c5"] } ],
          output: { label: "base chunk → temporal ensemble a_b" } },
        { mod: "res", title: "Residual actor–critic", sub: "online, n-step DDPG", compact: true,
          input: { label: "z_image, z_tactile, a_b", caption: "frozen features + base action" },
          rows: [
            { t: "mlp", label: "Actor MLP → offset a_r", call: ["offset ≤ 20 % of max action (paper)", "p2"],
              zoom: { k: "rows", title: "Residual update", rows: ["a = a_b + a_r", "twin Q(z, a_b, a_r), LayerNorm", "n-step DDPG, UTD 16", "noise σ: 0.25 → 0.1 over 5,000 steps", "reward: success + L1 to goal"] } },
            { t: "mlp", label: "Critic: 2 Q-nets", call: ["2 hidden layers of 256 each", "p2", "c3"] } ],
          output: { label: "executed action a_b + a_r" } }
      ],
      links: [
        { from: "gpt", to: "res", toRow: "input", label: "a_b" },
        { from: "enc", to: "gpt", toRow: "input", label: "tokens" }
      ]
    },
    modules: [
      { id: "enc", role: "touch-enc", roleLabel: "Vision + touch encoders", name: "ResNet-18 · MLP", sub: "→ 256-d tokens", col: 0, frozen: "partial", short: "Encoders",
        note: "Trained during behavior cloning, frozen during residual RL.",
        stack: { rows: [
          { t: "in", label: "wrist RGB 128 × 128 · AnySkin 15-d", c: "data-6" },
          { t: "conv", label: "ResNet-18 (random init)", dims: "→ 256" },
          { t: "mlp", label: "MLP 15 → 256 → 256 → 256" },
          { t: "out", label: "image token, tactile token", c: "data-6" } ],
          facts: [["Image", ["128 × 128 fisheye wrist camera", "p2", "p3"]], ["Touch", ["AnySkin, 15-d, baseline-subtracted", "p2", "p3"]], ["Width", ["256", "c5"]], ["Augmentation", ["background replacement with SAM 2 + XMem masks", "p1"]]] } },
      { id: "gpt", role: "action-head", roleLabel: "Base policy", name: "minGPT policy", sub: "8 × 256 · 4 heads", col: 1, frozen: "partial", main: true, short: "GPT",
        stack: { rows: [
          { t: "in", label: "[image, tactile, action token]", c: "data-3" },
          { t: "block", label: "GPT block (pre-norm, causal)", n: "8", rows: [{ t: "attn", label: "4 heads × 64" }, { t: "ffn", label: "MLP 256 → 1024 → 256" }] },
          { t: "mlp", label: "deterministic head, 2 layers", dims: "→ 10 × 7" },
          { t: "out", label: "base action chunk", dims: "temporal ensemble, m = 0.01", c: "data-3" } ],
          facts: [["GPT", ["8 layers, 4 heads, width 256, dropout 0.1", "c2"]], ["Chunk", ["10", "p2", "c4"]], ["BC training", ["20k iterations, lr 10⁻⁴, batch 256", "p2"]]] } },
      { id: "res", role: "critic", roleLabel: "Residual RL", name: "Residual actor–critic", sub: "offset actor · 2 Q-nets", col: 2, frozen: false, short: "Residual",
        stack: { rows: [
          { t: "in", label: "z_image, z_tactile, base action a_b", c: "data-3" },
          { t: "mlp", label: "actor: MLP → bounded offset a_r" },
          { t: "mlp", label: "critic: 2 Q-networks, LayerNorm" },
          { t: "out", label: "a = a_b + a_r", c: "data-3" } ],
          facts: [["Actor", ["1-layer MLP (paper) · 3 × 256 MLP + 2-layer head (code)", "p2", "c3"]], ["Critic", ["2-layer MLP (paper); 2 Q-nets of 2 × 256 in code", "p2", "c3"]], ["Offset scale", ["20 % of max action (paper) · 0.3 (code config)", "p2", "c4"]], ["UTD", ["16", "p2"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "wrist RGB", n: "128 × 128", k: 3 },
      { to: "enc", mod: "touch", label: "AnySkin", n: "15-d", k: 2 }
    ],
    outputs: [{ from: "res", mod: "action", label: "a_b + a_r", n: "7-d, 6 Hz", k: 3 }],
    links: [
      { from: "enc", to: "gpt", kind: "prefix", label: "2 tokens" },
      { from: "gpt", to: "res", kind: "feeds", label: "base action a_b" }
    ],
    mask: { name: "Causal (minGPT)", ref: "c2", axes: [{ label: "image token", short: "img", mod: "vision" }, { label: "tactile token", short: "tac", mod: "touch" }, { label: "action token", short: "act", mod: "action" }], m: ["100", "110", "111"],
      note: "Only the last (action) token's output is read, so it sees both observations." },
    callouts: [
      "Paper vs code: the paper describes a <b>1-layer</b> residual actor and an offset limit of <b>20 %</b> of the largest action; the code's actor is a 3 × 256 MLP with a 2-layer head, and cfgs/config.yaml sets offset_action_scale = <b>0.3</b>.",
      "Paper App. A1: VITAL-BC has 7.6M parameters and residual RL adds 2.46M, but the stated total is 9.06M (7.6 + 2.46 = 10.06).",
      "Reaching is not learned here: <b>Molmo</b> points at the target in a third-person RGB-D image and the policy starts from a pose sampled near that point (10 cm above it for USB insertion)."
    ]
  });

  /* ------------------------------------------------------------------ TA-VLA */
  RB.arch.spec({
    id: "ta-vla", method: "ta-vla", name: "TA-VLA", year: 2025, parent: "pi0",
    diffRows: ["cond", "output", "attention", "latency", "train"],
    figRef: "Zhang et al. Figs. 2, 4, 5 · App. A.3–A.8", prov: "π0 + obs + obj variant",
    lede: "π0 that feels its own joint torques. Ten frames of 14 motor-current torques are flattened into one token placed before the state token in the action expert, and the expert also predicts the next 50 torques beside the 50 actions.",
    sources: {
      p1: { kind: "paper", ref: "Zhang et al. 2025, §4 (Figs. 2, 4; Tables 1, 3)", url: "https://arxiv.org/abs/2509.07962" },
      p2: { kind: "paper", ref: "Zhang et al. 2025, §5 (action–torque diffusion)", url: "https://arxiv.org/abs/2509.07962" },
      p3: { kind: "paper", ref: "Zhang et al. 2025, App. A.3–A.7", url: "https://arxiv.org/abs/2509.07962" },
      p4: { kind: "paper", ref: "Zhang et al. 2025, App. A.8, Tables 7–8", url: "https://arxiv.org/abs/2509.07962" },
      p5: { kind: "paper", ref: "Zhang et al. 2025, §6.1 (hardware)", url: "https://arxiv.org/abs/2509.07962" },
      c1: { kind: "code", repo: "ZZongzheng0918/TA-VLA", path: "src/openpi/models/pi0.py", commit: "149d4be", url: "https://github.com/ZZongzheng0918/TA-VLA/blob/149d4be/src/openpi/models/pi0.py" },
      c2: { kind: "code", repo: "ZZongzheng0918/TA-VLA", path: "src/openpi/shared/effort_type.py", commit: "149d4be", url: "https://github.com/ZZongzheng0918/TA-VLA/blob/149d4be/src/openpi/shared/effort_type.py" },
      c3: { kind: "code", repo: "ZZongzheng0918/TA-VLA", path: "src/openpi/models/gemma.py", commit: "149d4be", url: "https://github.com/ZZongzheng0918/TA-VLA/blob/149d4be/src/openpi/models/gemma.py" },
      c4: { kind: "code", repo: "ZZongzheng0918/TA-VLA", path: "src/openpi/training/config.py", commit: "149d4be", url: "https://github.com/ZZongzheng0918/TA-VLA/blob/149d4be/src/openpi/training/config.py" }
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p3"],
      params: ["π0: PaliGemma 3B + 300M action expert, plus a torque MLP", "p3"],
      vision: ["3 cameras (top, left wrist, right wrist) into PaliGemma's image encoder", "p3"],
      backbone: ["Gemma 2B: 18 layers, width 2,048 (LoRA finetuned)", "p3", "c3", "c4"],
      head: ["Action expert 18 × 1,024, MLP 4,096 (LoRA); in/out projections widened to 32 + 14", "c1", "c3"],
      output: ["Velocity on 50 actions and 50 future joint torques", "p3", "c1"],
      attention: ["Blockwise causal: [images + text] → [torque token] → [state] → [actions]", "c1"],
      cond: ["Torque history: 10 frames over 2 s × 14 joints → MLP → 1 token before the state token", "p3", "c1", "c4"],
      steps: ["10 flow integration steps", "p3"],
      chunk: ["H = 50", "p3", "c1"],
      rate: null,
      latency: ["93.96 ms on an RTX 4090 (π0: 90.70 ms)", "p4"],
      train: ["400 demos per task; LoRA, 30k steps; loss = action + 0.1 × torque", "p3", "c1"]
    },
    changes: [
      "A <b>torque token</b>: 10 frames × 14 joint torques are flattened and projected 140 → 2,048 → 1,024 (swish).",
      "The token enters the <b>action expert</b> (decoder side), before the state token and in its own attention block; the VLM never sees it.",
      "The expert also <b>predicts future torques</b>: its input and output projections widen from 32 to 32 + 14, and a torque loss is added with weight 0.1.",
      "Torque comes from motor currents (τ = kₜ·i), with no force sensor."
    ],
    blueprint: {
      headline: "TA-VLA: torque in, torque out",
      note: "The VLM half of π0 is unchanged. The torque adapter turns 2 s of joint torques into one 1,024-d token that opens the expert's suffix. The expert denoises [action ‖ future torque] vectors with one shared linear head, so predicting torque shapes the same features that produce actions.",
      towers: [
        { mod: "gemma", title: "PaliGemma (π0)", sub: "SigLIP + Gemma 2B, LoRA", compact: true,
          input: { label: "Image + text tokens", caption: "3 cameras, instruction" },
          rows: [
            { t: "embed", label: "SigLIP tokens + text embed" },
            { t: "block", n: "18", rows: [
              { id: "att", t: "attn", label: "Masked multi-query attention", call: ["Width 2,048; 8 query heads, 1 KV head", "c3"], callDy: -24 },
              { t: "ffn", label: "Feed forward (GeGLU)" } ] },
            { t: "norm", label: "Final RMSNorm" } ],
          output: { label: "prefix keys and values" } },
        { mod: "expert", title: "Action expert (π0)", sub: "width 1,024, LoRA",
          input: { label: "Torque + state + noisy [A ‖ T]", caption: "1 + 1 + 50 tokens, time τ" },
          rows: [
            { id: "tq", t: "embed", label: "Torque token (own block)" },
            { t: "linear", label: "State projection" },
            { t: "linear", label: "Action–torque in projection", call: ["(32 + 14) → 1,024", "c1"] },
            { t: "mlp", label: "Action + time MLP", call: ["[· ‖ sinusoid(τ)] → swish → 1,024", "c1"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention" },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["1,024 → 4,096 → 1,024", "c3"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Out projection, then split", call: ["1,024 → 32 + 14", "c1"],
              zoom: { k: "rows", title: "Joint action–torque loss", rows: ["vθ → [vᴬ ‖ vᵀ]", "L_action = ‖vᴬ − (ε − A)‖²", "L_torque = ‖vᵀ − (ε − T)‖²", "L = L_action + 0.1 · L_torque"] } } ],
          output: { label: "vθ for 50 actions + 50 torques" } },
        { mod: "adapter", title: "Torque adapter", sub: "DePost, 1 token", compact: true,
          input: { label: "Torque history", caption: "10 frames in 2 s × 14 joints" },
          rows: [
            { t: "linear", label: "Flatten → 140" },
            { t: "mlp", label: "MLP with swish", call: ["140 → 2,048 → 1,024", "p3", "c1"], zoom: { k: "rows", title: "Torque MLP", rows: ["history, flattened: 140", "Linear 140 → 2,048", "swish", "Linear 2,048 → 1,024"] } } ],
          output: { label: "1 torque token" } }
      ],
      links: [{ from: "adapter", to: "expert", toRow: "tq", label: "torque token" }],
      shared: [{ a: ["gemma", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "gemma", role: "vlm", name: "PaliGemma (π0)", sub: "18 × 2048 · LoRA", col: 0, frozen: "lora", short: "PaliGemma",
        stack: { rows: [
          { t: "in", label: "[3 images | instruction]", c: "data-2" },
          { t: "block", label: "Gemma block", n: "18", rows: [{ t: "attn", label: "MQA, 8 query / 1 KV head" }, { t: "ffn", label: "GeGLU 2048 → 16,384" }] },
          { t: "out", label: "prefix keys and values", c: "data-2" } ],
          facts: [["Variant", ["gemma_2b_lora", "c4"]], ["Width / depth", ["2,048 / 18", "c3"]], ["Torque input", ["none: encoder-side torque did worse (Tables 1, 3)", "p1"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert", sub: "18 × 1024 · [A ‖ T] out", col: 1, frozen: "lora", main: true, short: "Expert",
        stack: { rows: [
          { t: "in", label: "torque token · state · noisy [action ‖ torque] × 50", c: "data-3" },
          { t: "linear", label: "in projection (32 + 14) → 1024" },
          { t: "block", label: "Expert block", n: "18", rows: [{ t: "attn", label: "joint attention with the prefix" }, { t: "ffn", label: "GeGLU 1024 → 4096" }] },
          { t: "linear", label: "out projection 1024 → 32 + 14" },
          { t: "out", label: "velocity for actions and future torques", c: "data-3" } ],
          facts: [["Variant", ["gemma_300m_lora", "c4"]], ["Width / depth / MLP", ["1,024 / 18 / 4,096", "c3"]], ["Torque loss weight", ["0.1", "p3", "c1"]], ["Chunk", ["50 actions and 50 torques", "p3"]]] } },
      { id: "adapter", role: "touch-enc", roleLabel: "Torque encoder", name: "Torque adapter", sub: "140 → 2048 → 1024", col: 2, frozen: false, short: "Adapter",
        stack: { rows: [
          { t: "in", label: "joint torques, 10 frames × 14", dims: "from motor currents", c: "data-6" },
          { t: "linear", label: "flatten → 140" },
          { t: "mlp", label: "Linear 140 → 2048, swish, Linear 2048 → 1024" },
          { t: "out", label: "one token, first in the suffix", c: "data-6" } ],
          facts: [["History", ["10 frames sampled over the past 2 s", "p3", "c4"]], ["Joints", ["14 (two 7-DoF arms)", "p3"]], ["Aggregation", ["MLP beats RNN and attention (15 vs 7 vs 13 of 20)", "p3"]], ["Source", ["τ = kₜ · i from motor current", "p5"]]] } }
    ],
    inputs: [
      { to: "gemma", mod: "vision", label: "3 cameras", k: 4 },
      { to: "gemma", mod: "lang", label: "instruction", k: 2 },
      { to: "expert", mod: "state", label: "joint angles", n: "14-d", k: 1 },
      { to: "expert", mod: "action", label: "noisy [A ‖ T]", n: "50 × (32 + 14)", k: 4, noisy: true },
      { to: "adapter", mod: "touch", label: "torque history", n: "10 × 14", k: 3 }
    ],
    outputs: [{ from: "expert", mod: "action", label: "actions + torques", n: "50 each", k: 4 }],
    links: [
      { from: "gemma", to: "expert", kind: "joint-attn", label: "shared self-attn" },
      { from: "adapter", to: "expert", kind: "prefix", label: "1 torque token|before state" }
    ],
    mask: { name: "Blockwise causal (4 blocks)", ref: "c1", axes: [{ label: "images + text", short: "img+ℓ", mod: "vision" }, { label: "torque token", short: "τ", mod: "touch" }, { label: "state", short: "q", mod: "state" }, { label: "actions", short: "A", mod: "action" }], m: ["1000", "1100", "1110", "1111"],
      note: "The torque token opens its own block, so the prefix never sees it and the state and actions always do." },
    callouts: [
      "Design-space result: torque belongs in the <b>decoder</b> (action expert), as <b>one</b> history token. The winning 1-token decoder variant reaches 15/20 button pushes vs 9/20 with one token per frame (Table 3).",
      "The same recipe applied to RDT raises charger plugging from 1/20 to 15/20 (Table 6)."
    ]
  });

})();
