/* Architecture specs, topic E6 (physics priors for learned dynamics). Numbers from the papers and the official code; see sources. */
(function () {
  var RB = window.RB;

  /* ---------------- DeLaN ---------------- */
  RB.arch.spec({
    id: "delan", method: "delan", name: "DeLaN", year: 2019,
    figRef: "Lutter et al. Figs. 1–2 · §4 · §5", prov: "PyTorch example config",
    lede: "A small MLP reads only the joint positions q. Three heads give a lower-triangular factor L(q) and a potential; closed-form Euler–Lagrange algebra turns them into torques, with a mass matrix that is positive definite by construction.",
    sources: {
      p1: { kind: "paper", ref: "Lutter et al. 2019, §4 and Fig. 1", url: "https://arxiv.org/abs/1907.04490" },
      p2: { kind: "paper", ref: "Lutter et al. 2019, §4.2–4.3 and Fig. 2 (Lagrangian layer)", url: "https://arxiv.org/abs/1907.04490" },
      p3: { kind: "paper", ref: "Lutter et al. 2019, §5 experimental setup", url: "https://arxiv.org/abs/1907.04490" },
      c1: { kind: "code", repo: "milutter/deep_lagrangian_networks", path: "deep_lagrangian_networks/DeLaN_model.py", commit: "18a943d", url: "https://github.com/milutter/deep_lagrangian_networks/blob/18a943d/deep_lagrangian_networks/DeLaN_model.py" },
      c2: { kind: "code", repo: "milutter/deep_lagrangian_networks", path: "example_DeLaN.py", commit: "18a943d", url: "https://github.com/milutter/deep_lagrangian_networks/blob/18a943d/example_DeLaN.py" }
    },
    summary: {
      pattern: ["Physics-structured network", "p1"],
      params: null,
      vision: "None: joint states only",
      backbone: ["Shared MLP on q only: 2 hidden layers of 64, SoftPlus (example config)", "c1", "c2"],
      head: ["Three heads: diagonal of L (ReLU + offset), off-diagonal of L (linear), potential (linear)", "p1", "c1"],
      output: ["Torque τ = H(q)q̈ + c(q, q̇) + g(q); the forward model solves for q̈ with H⁻¹", "p1"],
      attention: "None",
      cond: ["q̇ and q̈ never enter the network, only the Euler–Lagrange algebra", "p1"],
      steps: null, chunk: null,
      rate: ["500 Hz control loop; feed-forward torque updated at 200 Hz", "p3"],
      latency: ["Each torque must be computed within 1/200 s", "p3"],
      train: ["Online from random initialization; Barrett WAM: only the lower 4 joints learned", "p3"]
    },
    blueprint: {
      headline: "DeLaN: an MLP inside Euler–Lagrange",
      note: "The MLP runs once on q and carries its own Jacobian ∂l/∂q layer by layer, so no second autodiff pass is needed. The physics block has no weights: it builds H = LLᵀ, its time and position derivatives, and the torque in closed form.",
      towers: [
        { mod: "net", title: "DeLaN MLP", sub: "shared trunk, three heads",
          input: { label: "Joint positions q", caption: "q̇ and q̈ bypass the network" },
          rows: [
            { t: "block", n: "2", label: "Lagrangian layer", rows: [
              { t: "linear", label: "Linear W h + b", call: ["Width 64 (example config)", "c2"],
                zoom: { k: "rows", title: "Lagrangian layer", rows: ["in: h, ∂h/∂q", "a = W h + b", "h′ = g(a)", "∂h′/∂q = diag(g′(a)) W ∂h/∂q"] } },
              { t: "mlp", label: "SoftPlus, and g′ for ∂/∂q", call: ["Paper: ReLU; code: SoftPlus", "p3", "c2"] } ] },
            { t: "group", label: "Three heads", rows: [
              { t: "linear", label: "Potential head: linear", call: ["Code outputs V; g(q) = ∂V/∂q", "c1"] },
              { t: "linear", label: "Off-diagonal head: linear", call: ["n(n − 1)/2 entries of L", "c1"] },
              { t: "linear", label: "Diagonal head: ReLU + b", call: ["n entries, bias initialized to 0.001", "c1", "c2"] } ] } ],
          output: { label: "l(q), ∂l/∂q, V, ∂V/∂q" } },
        { mod: "phys", title: "Euler–Lagrange block", sub: "closed form, no weights",
          input: { label: "L, ∂L/∂q, g, q̇, q̈", caption: "reshaped head outputs + states" },
          rows: [
            { t: "linear", label: "H = L Lᵀ + ε I", call: ["ε = 0.01 in the example config", "c1", "c2"],
              zoom: { k: "rows", title: "Positive-definite mass matrix", rows: ["heads → diagonal ≥ 0, off-diagonal", "fill lower-triangular L", "diag(L) > 0 via ReLU + b", "H = L Lᵀ ≻ 0, always invertible"] } },
            { t: "linear", label: "Ḣ = L L̇ᵀ + L̇ Lᵀ", call: ["L̇ from (∂l/∂q) q̇: weights are time-invariant", "p2"] },
            { t: "linear", label: "c = Ḣ q̇ − ½ ∂(q̇ᵀH q̇)/∂q", call: ["Coriolis and centrifugal forces", "p1"] },
            { t: "linear", label: "τ = H q̈ + c + g" } ],
          output: { label: "torque τ, or q̈ = H⁻¹(τ − c − g)" } }
      ],
      links: [{ from: "net", to: "phys", toRow: "input", label: "l, ∂l/∂q, V" }]
    },
    modules: [
      { id: "net", role: "world", roleLabel: "Structured dynamics net", name: "DeLaN MLP", sub: "2 × 64 · SoftPlus · 3 heads", col: 0, frozen: false, main: true, short: "MLP",
        stack: { rows: [
          { t: "in", label: "joint positions q", dims: "n joints (4 on the WAM)", c: "data-5" },
          { t: "block", label: "Lagrangian layer", n: "2", rows: [
            { t: "linear", label: "a = W h + b", dims: "→ 64" },
            { t: "mlp", label: "h = SoftPlus(a); ∂h/∂q = diag(g′(a)) W ∂h/∂q", dims: "Jacobian carried forward" } ] },
          { t: "group", label: "Three heads", rows: [
            { t: "linear", label: "diagonal of L: ReLU, bias init 0.001", dims: "→ n" },
            { t: "linear", label: "off-diagonal of L: linear", dims: "→ n(n − 1)/2" },
            { t: "linear", label: "potential V: linear", dims: "→ 1; g = ∂V/∂q" } ] },
          { t: "out", label: "l(q), ∂l/∂q, V(q), g(q)", dims: "to the Euler–Lagrange block", c: "data-5" } ],
          facts: [["Hidden layers", ["2 × 64 (example config)", "c2"]], ["Activation", ["ReLU (paper §5) · SoftPlus (example config)", "p3", "c2"]], ["Diagonal", ["ReLU + positive offset", "p1", "c1"]], ["Mass matrix", ["H = LLᵀ + εI, ε = 0.01 (example config)", "c1", "c2"]], ["Optimizer", ["Adam, lr 5 × 10⁻⁴, weight decay 10⁻⁵, batch 512", "c2"]]] } },
      { id: "phys", role: "net", roleLabel: "Physics block", name: "Euler–Lagrange block", sub: "H, Ḣ, c, τ in closed form", col: 1, frozen: true, short: "Physics",
        note: "No learned parameters: pure algebra on the network outputs." }
    ],
    inputs: [
      { to: "net", mod: "state", label: "joint positions q", n: "n joints", k: 3 },
      { to: "phys", mod: "state", label: "q̇, q̈ (desired)", n: "n each", k: 3 }
    ],
    outputs: [{ from: "phys", mod: "action", label: "feed-forward torque τ", n: "n joints", k: 3 }],
    links: [{ from: "net", to: "phys", kind: "feeds", label: "L(q), ∂L/∂q|V(q), g(q)" }],
    callouts: [
      "Paper vs code: the paper's third head outputs <b>g(q)</b> directly; the released model outputs a potential V and takes g = ∂V/∂q from the carried Jacobian.",
      "Paper §5 says both networks use <b>ReLU</b>; the released PyTorch example uses SoftPlus (2 × 64) and adds εI to H.",
      "Because the net only sees q, DeLaN extrapolates to faster trajectories than a black-box net trained on (q, q̇, q̈)."
    ]
  });

  /* ---------------- Hamiltonian Neural Networks ---------------- */
  RB.arch.spec({
    id: "hamiltonian-neural-networks", method: "hamiltonian-neural-networks", name: "Hamiltonian Neural Network", year: 2019,
    figRef: "Greydanus et al. Fig. A.1 · §2–3 · §5", prov: "pixel pendulum",
    lede: "An MLP outputs one number, an energy Hθ(q, p). Its input gradient, rotated by the symplectic matrix, is the vector field, so every rollout conserves the learned energy. For pixels, an MLP autoencoder supplies (q, p).",
    sources: {
      p1: { kind: "paper", ref: "Greydanus et al. 2019, §2 (Eqs. 2–3)", url: "https://arxiv.org/abs/1906.01563" },
      p2: { kind: "paper", ref: "Greydanus et al. 2019, §3.1 methods and App. A", url: "https://arxiv.org/abs/1906.01563" },
      p3: { kind: "paper", ref: "Greydanus et al. 2019, §5.1 pixel pendulum", url: "https://arxiv.org/abs/1906.01563" },
      p4: { kind: "paper", ref: "Greydanus et al. 2019, §4.1 two-body", url: "https://arxiv.org/abs/1906.01563" },
      c1: { kind: "code", repo: "greydanus/hamiltonian-nn", path: "nn_models.py", commit: "bcc3622", url: "https://github.com/greydanus/hamiltonian-nn/blob/bcc3622/nn_models.py" },
      c2: { kind: "code", repo: "greydanus/hamiltonian-nn", path: "hnn.py", commit: "bcc3622", url: "https://github.com/greydanus/hamiltonian-nn/blob/bcc3622/hnn.py" },
      c3: { kind: "code", repo: "greydanus/hamiltonian-nn", path: "experiment-pixels/train.py", commit: "bcc3622", url: "https://github.com/greydanus/hamiltonian-nn/blob/bcc3622/experiment-pixels/train.py" }
    },
    summary: {
      pattern: ["Physics-structured network", "p1"],
      params: null,
      vision: ["Pixel task only: MLP autoencoder on 2 stacked 28 × 28 frames → 2-d latent", "p3", "c3"],
      backbone: ["MLP: 3 layers, 200 hidden units, tanh", "p2", "c1"],
      head: ["Scalar Hθ(q, p); the code's MLP emits 2 scalars and uses the second as H", "p1", "c1", "c2"],
      output: ["Symplectic gradient (∂H/∂p, −∂H/∂q) = (q̇, ṗ)", "p1"],
      attention: "None",
      cond: ["No control input: an autonomous, energy-conserving system", "p1"],
      steps: ["Rollouts with RK4 (scipy solve_ivp), tolerance 10⁻⁹", "p2"],
      train: ["L2 on time derivatives; Adam 10⁻³; 2,000 steps (10,000 for two-body)", "p2", "p4"]
    },
    blueprint: {
      headline: "HNN: learn the energy, not the motion",
      note: "The encoder turns two frames into z = (q̃, p̃). The energy MLP maps that state to one scalar. The symplectic block has no weights: it differentiates Hθ in the graph, swaps and negates the two halves, and hands the field to an RK4 integrator.",
      towers: [
        { mod: "ae", title: "MLP encoder", sub: "pixel task only", compact: true,
          input: { label: "Two frames 28 × 28", caption: "flattened, 1,568 values" },
          rows: [
            { t: "linear", label: "Linear → 200 · ReLU", call: ["Residual MLP, width 200", "p3", "c3"] },
            { t: "block", n: "2", rows: [
              { t: "linear", label: "Linear 200 · ReLU" },
              { t: "add", span: 1 } ] },
            { t: "linear", label: "Linear → z (2-d)", call: ["Latent of 2 units", "p3", "c3"],
              zoom: { k: "rows", title: "Latent losses", rows: ["HNN loss on z (Eq. 3)", "+ pixel L2 reconstruction", "+ ‖p̃ − (q̃ₜ − q̃ₜ₊₁)‖²", "weight decay 10⁻⁵"] } } ],
          output: { label: "z = (q̃, p̃)" } },
        { mod: "hnn", title: "Energy MLP Hθ", sub: "one scalar out",
          input: { label: "State (q, p)", caption: "or latent z from the encoder" },
          rows: [
            { t: "block", n: "2", rows: [
              { t: "linear", label: "Linear → 200", call: ["200 hidden units, orthogonal init", "p2", "c1"] },
              { t: "mlp", label: "tanh" } ] },
            { t: "linear", label: "Linear → Hθ (scalar)", call: ["No output bias in the code", "c1"] } ],
          output: { label: "energy Hθ(q, p)" } },
        { mod: "sg", title: "Symplectic block", sub: "autograd, no weights", compact: true,
          input: { label: "Hθ(q, p)", caption: "same graph as the MLP" },
          rows: [
            { t: "linear", label: "∇Hθ by in-graph autograd",
              zoom: { k: "rows", title: "Why energy is conserved", rows: ["dH/dt = ∂H/∂q·q̇ + ∂H/∂p·ṗ", "= ∂H/∂q·∂H/∂p − ∂H/∂p·∂H/∂q", "= 0 along every rollout"] } },
            { t: "linear", label: "(∂H/∂p, −∂H/∂q)", call: ["Loss: L2 to observed (q̇, ṗ)", "p1"] },
            { t: "linear", label: "RK4 step t → t + Δt" } ],
          output: { label: "(q̇, ṗ); decode for pixels" } }
      ],
      links: [
        { from: "hnn", to: "sg", toRow: "input", label: "Hθ" },
        { from: "ae", to: "hnn", toRow: "input", label: "z" }
      ]
    },
    modules: [
      { id: "ae", role: "vision-enc", roleLabel: "Pixel autoencoder", name: "MLP autoencoder", sub: "4 + 4 layers · 200 · z = 2", col: 0, frozen: false, short: "Autoencoder",
        note: "Pixel pendulum only. Encoder and decoder each 4 fully connected layers with residual connections.",
        stack: { rows: [
          { t: "in", label: "two stacked frames", dims: "28 × 28 × 2 → 1,568", c: "data-1" },
          { t: "linear", label: "Linear → 200 · ReLU" },
          { t: "block", label: "residual layer", n: "2", rows: [{ t: "linear", label: "h + ReLU(Linear 200 → 200)" }, { t: "add", span: 1 }] },
          { t: "linear", label: "Linear → 2", dims: "z = (q̃, p̃)" },
          { t: "out", label: "latent state z", dims: "decoder mirrors the encoder", c: "data-1" } ],
          facts: [["Layers", ["4 encoder + 4 decoder, residual", "p3", "c1"]], ["Width", ["200", "p3", "c3"]], ["Latent", ["2", "p3", "c3"]], ["Activation", ["ReLU", "p3", "c3"]], ["Weight decay", ["10⁻⁵", "p3", "c3"]]] } },
      { id: "hnn", role: "world", roleLabel: "Energy network", name: "Hθ MLP", sub: "200 hidden · tanh", col: 1, frozen: false, main: true, short: "Hθ",
        stack: { rows: [
          { t: "in", label: "(q, p) or latent z", dims: "2 per degree of freedom", c: "data-5" },
          { t: "linear", label: "Linear → 200 · tanh" },
          { t: "linear", label: "Linear 200 → 200 · tanh" },
          { t: "linear", label: "Linear 200 → Hθ", dims: "scalar energy" },
          { t: "out", label: "Hθ(q, p)", dims: "differentiated in-graph", c: "data-5" } ],
          facts: [["Depth", ["3 layers", "p2", "c1"]], ["Width", ["200", "p2", "c1"]], ["Activation", ["tanh", "p2", "c1"]], ["Optimizer", ["Adam, lr 10⁻³, full batch (small tasks)", "p2"]], ["Weight decay", ["10⁻⁴ on the first three tasks", "p2"]]] } },
      { id: "sg", role: "net", roleLabel: "Physics block", name: "Symplectic gradient", sub: "autograd · RK4", col: 2, frozen: true, short: "Symplectic",
        note: "No learned parameters." }
    ],
    inputs: [
      { to: "ae", mod: "vision", label: "two stacked frames", n: "28 × 28 × 2", k: 4 },
      { to: "hnn", mod: "state", label: "(q, p) when observed", n: "2 per DoF", k: 2 }
    ],
    outputs: [{ from: "sg", mod: "state", label: "time derivative (q̇, ṗ)", n: "2 per DoF", k: 2 }],
    links: [
      { from: "ae", to: "hnn", kind: "latent", label: "z = (q̃, p̃)" },
      { from: "hnn", to: "sg", kind: "feeds", label: "scalar Hθ|autograd" }
    ],
    callouts: [
      "The code's MLP has <b>two</b> scalar outputs (a conservative and a solenoidal potential); the default <i>solenoidal</i> field uses only the second, which is the paper's Hθ.",
      "HNNs assume a conserved quantity, so friction on the real pendulum is not modelled (§3.2)."
    ]
  });

  /* ---------------- Lagrangian Neural Networks ---------------- */
  RB.arch.spec({
    id: "lagrangian-neural-networks", method: "lagrangian-neural-networks", name: "Lagrangian Neural Network", year: 2020, parent: "hamiltonian-neural-networks",
    diffRows: ["backbone", "head", "output", "cond", "steps", "train"],
    figRef: "Cranmer et al. §2 (Eq. 6) · §4 · App. A, C", prov: "double pendulum",
    lede: "An MLP outputs a scalar Lagrangian Lθ(q, q̇) in any coordinates. Accelerations come from the Euler–Lagrange equation: a Hessian of the network, a pseudoinverse and a mixed Jacobian, all by autodiff in JAX.",
    sources: {
      p1: { kind: "paper", ref: "Cranmer et al. 2020, §2 (Eq. 6)", url: "https://arxiv.org/abs/2003.04630" },
      p2: { kind: "paper", ref: "Cranmer et al. 2020, §4 methods", url: "https://arxiv.org/abs/2003.04630" },
      p3: { kind: "paper", ref: "Cranmer et al. 2020, App. C initialization", url: "https://arxiv.org/abs/2003.04630" },
      p4: { kind: "paper", ref: "Cranmer et al. 2020, §5 experiments", url: "https://arxiv.org/abs/2003.04630" },
      c1: { kind: "code", repo: "MilesCranmer/lagrangian_nns", path: "lnn/core.py", commit: "3b99472", url: "https://github.com/MilesCranmer/lagrangian_nns/blob/3b99472/lnn/core.py" },
      c2: { kind: "code", repo: "MilesCranmer/lagrangian_nns", path: "notebooks/DoublePendulum.ipynb", commit: "3b99472", url: "https://github.com/MilesCranmer/lagrangian_nns/blob/3b99472/notebooks/DoublePendulum.ipynb" }
    },
    summary: {
      pattern: ["Physics-structured network", "p1"],
      params: null,
      vision: "None",
      backbone: ["MLP: 4 layers, 500 hidden units, softplus (paper)", "p2", "p3"],
      head: ["Scalar Lagrangian Lθ(q, q̇)", "p1"],
      output: ["q̈ = (∇q̇∇q̇ᵀL)⁻¹[∇qL − (∇q∇q̇ᵀL) q̇]", "p1", "c1"],
      attention: "None",
      cond: ["Arbitrary coordinates (q, q̇): no canonical momenta needed", "p1"],
      steps: ["Rollouts integrate q̈; code offers an RK4 step of Δt = 0.1", "c1"],
      train: ["Double pendulum: 600,000 random initial states, instantaneous accelerations; batch 32, lr 10⁻³ decaying", "p2", "p4"]
    },
    changes: [
      "Learns a Lagrangian Lθ(q, q̇) instead of a Hamiltonian Hθ(q, p): <b>no canonical momenta</b> are needed.",
      "Dynamics need the <b>Hessian</b> ∇q̇∇q̇ᵀL, its pseudoinverse and a mixed Jacobian, not one gradient.",
      "Activation changes from tanh to <b>softplus</b>, chosen because second derivatives matter.",
      "Wider MLP: 500 hidden units instead of 200, with a custom per-layer initialization.",
      "A graph variant sums a learned Lagrangian density over neighbouring nodes (1-D wave)."
    ],
    blueprint: {
      headline: "LNN: a Lagrangian in any coordinates",
      note: "The MLP is a plain stack that outputs one number. Everything physical happens after it: JAX takes a gradient, a Hessian and a mixed Jacobian of that scalar and solves the Euler–Lagrange equation for q̈ with a pseudoinverse.",
      towers: [
        { mod: "mlp", title: "Lagrangian MLP Lθ", sub: "scalar out, softplus",
          input: { label: "State (q, q̇)", caption: "any coordinates; 4 values for the double pendulum" },
          rows: [
            { t: "block", n: "3", rows: [
              { t: "linear", label: "Dense → 500", call: ["500 units (paper); 600 (notebook)", "p2", "c2"],
                zoom: { k: "rows", title: "LNN initialization (App. C)", rows: ["σ = 2.2 / √n  (first layer)", "σ = 0.58 i / √n  (hidden layer i)", "σ = n / √n  (output layer)", "biases start at 0"] } },
              { t: "mlp", label: "Softplus", call: ["Beat ReLU², ReLU³, tanh, sigmoid", "p2"] } ] },
            { t: "linear", label: "Dense → Lθ (scalar)", call: ["4 weight matrices in all", "p3"] } ],
          output: { label: "Lagrangian Lθ(q, q̇)" } },
        { mod: "el", title: "Euler–Lagrange solve", sub: "JAX autodiff, no weights", compact: true,
          input: { label: "Lθ(q, q̇)", caption: "differentiated twice" },
          rows: [
            { t: "linear", label: "∇q L", zoom: { k: "rows", title: "Equation 6 in JAX", rows: ["Hs = jax.hessian(L, 1)", "g = jax.grad(L, 0)", "J = jacobian(jacobian(L, 1), 0)", "q̈ = pinv(Hs) @ (g − J @ q̇)"] } },
            { t: "linear", label: "∇q∇q̇ᵀ L (mixed)" },
            { t: "linear", label: "∇q̇∇q̇ᵀ L (Hessian)", call: ["O(d³) in d coordinates", "p2"] },
            { t: "linear", label: "pinv(·) → q̈", call: ["pinv: safe if singular", "p2", "c1"] } ],
          output: { label: "q̈, integrated for rollouts" } }
      ],
      links: [{ from: "mlp", to: "el", toRow: "input", label: "scalar Lθ" }]
    },
    modules: [
      { id: "mlp", role: "world", roleLabel: "Energy network", name: "Lagrangian MLP", sub: "500 hidden · softplus", col: 0, frozen: false, main: true, short: "Lθ",
        stack: { rows: [
          { t: "in", label: "(q, q̇)", dims: "4 for the double pendulum", c: "data-5" },
          { t: "block", label: "hidden layer", n: "3", rows: [{ t: "linear", label: "Dense → 500" }, { t: "mlp", label: "Softplus" }] },
          { t: "linear", label: "Dense → 1", dims: "scalar Lθ" },
          { t: "out", label: "Lθ(q, q̇)", dims: "Hessian taken downstream", c: "data-5" } ],
          facts: [["Depth", ["4 weight layers (paper)", "p2", "p3"]], ["Width", ["500 (paper) · 600 (notebook)", "p2", "c2"]], ["Activation", ["softplus", "p2", "c2"]], ["Batch", ["32 (paper) · 512 (notebook)", "p2", "c2"]], ["Init", ["σ = (1/√n)·{2.2, 0.58 i, n}", "p3"]]] } },
      { id: "el", role: "net", roleLabel: "Physics block", name: "Euler–Lagrange solve", sub: "Hessian · pinv", col: 1, frozen: true, short: "E–L solve",
        note: "No learned parameters; O(d³) in the number of coordinates." }
    ],
    inputs: [{ to: "mlp", mod: "state", label: "positions and velocities", n: "(q, q̇)", k: 4 }],
    outputs: [{ from: "el", mod: "state", label: "accelerations q̈", n: "d", k: 2 }],
    links: [{ from: "mlp", to: "el", kind: "feeds", label: "scalar Lθ|2nd-order autodiff" }],
    callouts: [
      "Paper vs notebook: §4 trains a 4-layer, <b>500</b>-unit MLP with batch 32; the double-pendulum notebook config uses hidden_dim 600, 3 layers and batch 512.",
      "Unlike DeLaN, the kinetic energy is not forced to be ½ q̇ᵀM(q)q̇, so relativistic and magnetic systems fit (§3)."
    ]
  });

  /* ---------------- Neural ODE ---------------- */
  RB.arch.spec({
    id: "neural-ode", method: "neural-ode", name: "Neural ODE", year: 2018,
    figRef: "Chen et al. Figs. 2, 6 · §2 · §3 · §5.1", prov: "latent ODE (§5)",
    lede: "A small network f defines dz/dt; a black-box ODE solver integrates it to any requested time. In the latent ODE, an RNN infers z₀ from observations, f rolls it forward, and a decoder reads out observations. Gradients use the adjoint method.",
    sources: {
      p1: { kind: "paper", ref: "Chen et al. 2018, §2 (adjoint method, Alg. 1)", url: "https://arxiv.org/abs/1806.07366" },
      p2: { kind: "paper", ref: "Chen et al. 2018, §3 and Table 1 (ODE-Net)", url: "https://arxiv.org/abs/1806.07366" },
      p3: { kind: "paper", ref: "Chen et al. 2018, §5 and §5.1 (latent ODE)", url: "https://arxiv.org/abs/1806.07366" },
      c1: { kind: "code", repo: "rtqichen/torchdiffeq", path: "examples/latent_ode.py", commit: "657943a", url: "https://github.com/rtqichen/torchdiffeq/blob/657943a/examples/latent_ode.py" },
      c2: { kind: "code", repo: "rtqichen/torchdiffeq", path: "examples/odenet_mnist.py", commit: "657943a", url: "https://github.com/rtqichen/torchdiffeq/blob/657943a/examples/odenet_mnist.py" },
      c3: { kind: "code", repo: "rtqichen/torchdiffeq", path: "torchdiffeq/_impl/misc.py", commit: "657943a", url: "https://github.com/rtqichen/torchdiffeq/blob/657943a/torchdiffeq/_impl/misc.py" }
    },
    summary: {
      pattern: ["Continuous-depth network (neural ODE)", "p1"],
      params: ["0.22M for the MNIST ODE-Net; latent ODE not stated", "p2"],
      vision: "None in the latent ODE (time-series observations)",
      backbone: ["ODE function f: MLP 4 → 20 → 20 → 4, ELU (code); paper: one hidden layer of 20", "p3", "c1"],
      head: ["Decoder MLP 4 → 20 → 2, ReLU", "p3", "c1"],
      output: ["Latent states z(t₁ … tₙ) at any requested times, decoded to x̂(t)", "p3"],
      attention: "None",
      cond: ["Recognition RNN (25 hidden) reads the observations backwards → q(z₀)", "p3", "c1"],
      steps: ["Adaptive solver: dopri5 by default; depth = number of function evaluations", "p2", "c3"],
      train: ["ELBO; gradients from one reverse-time ODE solve (adjoint), O(1) memory in depth", "p1", "p2", "p3"]
    },
    blueprint: {
      headline: "Neural ODE: a network for dz/dt",
      note: "The RNN runs once to infer z₀. The solver then calls f as many times as it needs (the NFE brace) to reach each requested time; the decoder maps every z(tᵢ) back to an observation. Training backpropagates by solving the adjoint ODE backwards.",
      towers: [
        { mod: "rnn", title: "Recognition RNN", sub: "reads x backwards in time", compact: true,
          input: { label: "Observations xᵢ, tᵢ", caption: "irregularly sampled" },
          rows: [
            { t: "linear", label: "[xᵢ ‖ h] → 25 · tanh", call: ["25 hidden units", "p3", "c1"] },
            { t: "linear", label: "Linear 25 → 2 × latent", call: ["μ, log σ² of a 4-d z₀", "p3", "c1"] } ],
          output: { label: "z₀ ~ q(z₀ | x)" } },
        { mod: "odef", title: "ODE function f", sub: "dz/dt = f(z(t), θ)",
          input: { label: "Latent z(t)", caption: "starts at the sampled z₀" },
          rows: [
            { t: "block", n: "NFE", label: "called by the solver", rows: [
              { t: "linear", label: "Linear 4 → 20", call: ["Latent 4, 20 hidden units", "p3", "c1"],
                zoom: { k: "rows", title: "ODE-Net on MNIST (§3)", rows: ["Conv 3×3 1 → 64 · GN · ReLU", "2 × Conv 4×4, stride 2", "ODEBlock: f = 2 ConcatConv 3×3", "GN · ReLU · pool · Linear → 10"] } },
              { t: "mlp", label: "ELU" },
              { t: "linear", label: "Linear 20 → 20 · ELU", call: ["Code: 2 hidden layers; paper: 1", "p3", "c1"] },
              { t: "linear", label: "Linear 20 → 4 = dz/dt" } ] },
            { t: "linear", label: "ODESolve(z₀, f, t₀ … tₙ)", call: ["dopri5 by default (torchdiffeq)", "c1", "c3"],
              zoom: { k: "rows", title: "Adjoint gradients", rows: ["a(t) = ∂L/∂z(t)", "da/dt = −aᵀ ∂f/∂z", "dL/dθ = −∫ aᵀ ∂f/∂θ dt", "one backward solve, O(1) memory"] } } ],
          output: { label: "z(t₁), …, z(tₙ), any t" } },
        { mod: "dec", title: "Decoder", sub: "per time point", compact: true,
          input: { label: "z(tᵢ)", caption: "one latent per requested time" },
          rows: [
            { t: "linear", label: "Linear 4 → 20 · ReLU", call: ["One hidden layer of 20", "p3", "c1"] },
            { t: "linear", label: "Linear 20 → x̂", call: ["2-d spirals", "p3", "c1"] } ],
          output: { label: "reconstructions and extrapolations" } }
      ],
      links: [
        { from: "odef", to: "dec", toRow: "input", label: "z(tᵢ)" },
        { from: "rnn", to: "odef", toRow: "input", label: "z₀" }
      ]
    },
    modules: [
      { id: "rnn", role: "state-enc", roleLabel: "Recognition RNN", name: "RNN encoder", sub: "25 hidden · tanh", col: 0, frozen: false, short: "RNN",
        stack: { rows: [
          { t: "in", label: "observations xₙ … x₀", dims: "processed backwards", c: "data-5" },
          { t: "linear", label: "h = tanh(W [x ‖ h])", dims: "25 hidden" },
          { t: "linear", label: "Linear → μ, log σ² of z₀", dims: "2 × 4" },
          { t: "out", label: "z₀ sample", dims: "reparameterized", c: "data-7" } ],
          facts: [["Hidden units", ["25", "p3", "c1"]], ["Latent", ["4", "p3", "c1"]]] } },
      { id: "odef", role: "world", roleLabel: "Learned vector field", name: "ODE function f", sub: "4 → 20 → 20 → 4 · ELU", col: 1, frozen: false, main: true, short: "f",
        stack: { rows: [
          { t: "in", label: "z(t)", dims: "4-d latent", c: "data-7" },
          { t: "block", label: "one function evaluation", n: "NFE", rows: [
            { t: "linear", label: "Linear 4 → 20 · ELU" }, { t: "linear", label: "Linear 20 → 20 · ELU" }, { t: "linear", label: "Linear 20 → 4" } ] },
          { t: "linear", label: "ODESolve", dims: "adaptive steps, error-controlled" },
          { t: "out", label: "z(t₁ … tₙ)", dims: "any requested times", c: "data-7" } ],
          facts: [["Hidden", ["20 (paper: 1 layer; code: 2)", "p3", "c1"]], ["Activation", ["ELU (code)", "c1"]], ["Solver", ["dopri5 default (code); implicit Adams, LSODE (paper §3)", "c3", "p2"]], ["Memory", ["O(1) in depth with the adjoint", "p2"]]] } },
      { id: "dec", role: "codec", roleLabel: "Decoder", name: "MLP decoder", sub: "4 → 20 → 2 · ReLU", col: 2, frozen: false, short: "Decoder" }
    ],
    inputs: [
      { to: "rnn", mod: "state", label: "observed series", n: "irregular times", k: 4 },
      { to: "odef", mod: "time", label: "query times t₁ … tₘ", n: "any", k: 3 }
    ],
    outputs: [{ from: "dec", mod: "future", label: "x̂(t), incl. extrapolation", n: "per query time", k: 4 }],
    links: [
      { from: "rnn", to: "odef", kind: "latent", label: "z₀ ~ q(z₀|x)" },
      { from: "odef", to: "dec", kind: "feeds", label: "z(tᵢ)" }
    ],
    callouts: [
      "Paper vs code: §5.1 gives f <b>one</b> hidden layer of 20; latent_ode.py uses two (ELU). §3 solved with implicit Adams (LSODE via scipy); torchdiffeq defaults to dopri5.",
      "The MNIST ODE-Net replaces 6 residual blocks with one ODEBlock: 0.22M parameters and 0.42 % test error versus the ResNet's 0.60M and 0.41 % (Table 1)."
    ]
  });

  /* ---------------- Variational Integrator Networks ---------------- */
  RB.arch.spec({
    id: "variational-integrator-networks", method: "variational-integrator-networks", name: "Variational Integrator Network", year: 2020,
    figRef: "Saemundsson et al. Figs. 1–2 · §3 · App. B–C", prov: "pixel VAE setting",
    lede: "A residual network whose layers are the steps of a symplectic integrator. A one-hidden-layer MLP learns the potential Uθ(q); Störmer–Verlet updates stack 10 of those steps, inside a VAE that maps pixels to the latent position.",
    sources: {
      p1: { kind: "paper", ref: "Saemundsson et al. 2020, §3 (Eqs. 4–12)", url: "https://arxiv.org/abs/1910.09349" },
      p2: { kind: "paper", ref: "Saemundsson et al. 2020, §3.2 and Fig. 2 (VIN in a VAE)", url: "https://arxiv.org/abs/1910.09349" },
      p3: { kind: "paper", ref: "Saemundsson et al. 2020, §4.2 pixel observations", url: "https://arxiv.org/abs/1910.09349" },
      p4: { kind: "paper", ref: "Saemundsson et al. 2020, App. C hyperparameters", url: "https://arxiv.org/abs/1910.09349" },
      c1: { kind: "code", repo: "steindoringi/Variational_Integrator_Networks", path: "models.py", commit: "6345aee", url: "https://github.com/steindoringi/Variational_Integrator_Networks/blob/6345aee/models.py" },
      c2: { kind: "code", repo: "steindoringi/Variational_Integrator_Networks", path: "config/base.gin", commit: "6345aee", url: "https://github.com/steindoringi/Variational_Integrator_Networks/blob/6345aee/config/base.gin" },
      c3: { kind: "code", repo: "steindoringi/Variational_Integrator_Networks", path: "config/pixels.gin", commit: "6345aee", url: "https://github.com/steindoringi/Variational_Integrator_Networks/blob/6345aee/config/pixels.gin" },
      c4: { kind: "code", repo: "steindoringi/Variational_Integrator_Networks", path: "config/pixels_SO2.gin", commit: "6345aee", url: "https://github.com/steindoringi/Variational_Integrator_Networks/blob/6345aee/config/pixels_SO2.gin" }
    },
    summary: {
      pattern: ["Physics-structured network", "p1"],
      params: null,
      vision: ["28 × 28 pixels: MLP encoder 2 × 1,000 ReLU, then a backward LSTM (50) for the initial state", "p4", "c3"],
      backbone: ["Potential Uθ(q): one hidden layer of 1,000, tanh", "p4", "c2"],
      head: ["Integrator step: Störmer–Verlet, velocity Verlet or the SO(2) Lie-group update", "p1"],
      output: ["Latent positions q₁, q₂, …, decoded to pixels by an MLP 2 × 1,000 ReLU", "p2", "p4"],
      attention: "None",
      cond: ["Mass matrix Mθ learned (Cholesky) or fixed to the identity", "p1", "c1"],
      steps: ["Depth 10: one layer per integrator step; step size 1.0 in latent space", "p3", "p4"],
      train: ["ELBO; Adam 3 × 10⁻⁴; up to 6,000 epochs; 6 s of 10 Hz frames", "p3", "p4"]
    },
    blueprint: {
      headline: "VIN: the integrator is the network",
      note: "The encoder infers the initial condition from 10 frames. Each of the 10 layers is one Störmer–Verlet step that reuses the same potential net; its skip reaches two steps back (2qₜ − qₜ₋₁). The decoder sees positions only.",
      towers: [
        { mod: "enc", title: "Encoder", sub: "initial condition", compact: true,
          input: { label: "10 frames 28 × 28", caption: "784 pixels each" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "linear", label: "Dense 1,000 · ReLU" }] },
            { t: "linear", label: "LSTM 50, reversed", call: ["50-d state over 10 frames", "p4", "c3"] },
            { t: "linear", label: "Dense → mean, variance" } ],
          output: { label: "x₁ = (q₀, q₁)" } },
        { mod: "vin", title: "VIN (Störmer–Verlet)", sub: "shared potential net per step",
          input: { label: "x₁ = (q₀, q₁)", caption: "sampled initial condition" },
          rows: [
            { t: "block", n: "10", label: "one integrator step", rows: [
              { t: "linear", label: "Uθ(qₜ): Dense 1,000 · tanh", call: ["One hidden layer, 1,000 units", "p4", "c2"],
                zoom: { k: "rows", title: "Velocity Verlet variant", rows: ["q′ = q + h q̇ − ½h² M⁻¹∇U(q)", "∇U at q and at q′", "q̇′ = q̇ − ½h M⁻¹(∇U + ∇U′)"] } },
              { t: "linear", label: "∂Uθ/∂q by autodiff",
                zoom: { k: "rows", title: "ResRNN baseline vs VIN", rows: ["ResRNN: xₜ₊₁ = xₜ + h f(xₜ)", "VIN: skip from two steps back", "symplectic: volume preserved", "latent orbit stays bounded"] } },
              { t: "linear", label: "Mθ⁻¹ ∂Uθ/∂q", call: ["Identity unless inertia is learned", "p1", "c1"] },
              { t: "linear", label: "qₜ₊₁ = 2qₜ − qₜ₋₁ − h²(·)", call: ["Step h = 1.0 in latent space", "p4", "c3"],
                zoom: { k: "rows", title: "SO(2) rotation variant", rows: ["r(ϑ): MLP, sin at last layer", "sin Δϑₜ = sin Δϑₜ₋₁ + h² r(ϑ)", "ϑₜ₊₁ = ϑₜ + Δϑₜ", "stays on the circle by design"] } } ] } ],
          output: { label: "positions q₁ … q₁₀" } },
        { mod: "dec", title: "Decoder", sub: "positions → pixels", compact: true,
          input: { label: "qₜ", caption: "position only" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "linear", label: "Dense 1,000 · ReLU" }] },
            { t: "linear", label: "Dense → 784", call: ["28 × 28 frame", "p3", "c3"] } ],
          output: { label: "predicted frames" } }
      ],
      links: [
        { from: "vin", to: "dec", toRow: "input", label: "qₜ" },
        { from: "enc", to: "vin", toRow: "input", label: "initial state" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", roleLabel: "Pixel encoder", name: "MLP + LSTM encoder", sub: "2 × 1,000 · LSTM 50", col: 0, frozen: false, short: "Encoder",
        stack: { rows: [
          { t: "in", label: "10 frames, 28 × 28", dims: "784 per frame", c: "data-1" },
          { t: "linear", label: "Dense 1,000 · ReLU (× 2)", dims: "per frame" },
          { t: "linear", label: "LSTM, reversed in time", dims: "50-d" },
          { t: "linear", label: "Dense → mean and variance", dims: "q(x₁)" },
          { t: "out", label: "initial condition x₁", dims: "sampled", c: "data-7" } ],
          facts: [["Hidden", ["2 × 1,000, ReLU", "p4", "c3"]], ["LSTM", ["50", "p4", "c3"]], ["Frames in", ["10", "p3", "c3"]]] } },
      { id: "vin", role: "world", roleLabel: "Integrator network", name: "VIN potential net", sub: "Uθ: 1,000 · tanh · 10 steps", col: 1, frozen: false, main: true, short: "VIN",
        stack: { rows: [
          { t: "in", label: "(qₜ, qₜ₋₁)", dims: "1-d q for the pendulum", c: "data-7" },
          { t: "block", label: "Störmer–Verlet step", n: "10", rows: [
            { t: "linear", label: "Uθ(qₜ) = Dense 1,000 · tanh → 1" },
            { t: "linear", label: "∂Uθ/∂q, times Mθ⁻¹" },
            { t: "linear", label: "qₜ₊₁ = 2qₜ − qₜ₋₁ − h² Mθ⁻¹ ∂Uθ/∂q" } ] },
          { t: "out", label: "q₁ … q₁₀", dims: "to the decoder", c: "data-7" } ],
          facts: [["Potential net", ["1 hidden layer, 1,000, tanh (pixels)", "p4", "c2"]], ["Noisy-state setting", ["200 hidden, tanh", "p4"]], ["Depth", ["10 steps", "p3", "c3"]], ["Step size", ["1.0 (latent)", "p4", "c3"]], ["Optimizer", ["Adam 3 × 10⁻⁴", "p4", "c3"]]] } },
      { id: "dec", role: "codec", roleLabel: "Pixel decoder", name: "MLP decoder", sub: "2 × 1,000 · ReLU", col: 2, frozen: false, short: "Decoder" }
    ],
    inputs: [{ to: "enc", mod: "vision", label: "pixel frames", n: "10 × 28 × 28", k: 5 }],
    outputs: [{ from: "dec", mod: "future", label: "forecast frames", n: "10 per window", k: 5 }],
    links: [
      { from: "enc", to: "vin", kind: "latent", label: "x₁ ~ q(x₁)" },
      { from: "vin", to: "dec", kind: "feeds", label: "positions qₜ" }
    ],
    callouts: [
      "Paper vs code: App. C trains up to <b>6,000</b> epochs with step size 1.0; pixels.gin sets 8,000 epochs and pixels_SO2.gin overrides the SO(2) step to 0.1.",
      "The code's Störmer–Verlet update adds +h²M⁻¹∂U/∂q where Eq. 6 subtracts it; the learned potential absorbs the sign."
    ]
  });

  /* ---------------- Port-Hamiltonian neural ODE on SE(3) ---------------- */
  RB.arch.spec({
    id: "port-hamiltonian-on-se", method: "port-hamiltonian-on-se", name: "Port-Hamiltonian NODE on SE(3)", year: 2024,
    figRef: "Duong et al. Fig. 2 · §V-B, V-D · App. IX-A", prov: "Crazyflie config",
    lede: "Five small MLPs learn the inverse mass blocks, potential, dissipation and input matrix of a rigid body. Port-Hamiltonian equations on SE(3) turn them into pose and twist rates that a neural ODE solver integrates; an energy-shaping controller reuses the learned terms.",
    sources: {
      p1: { kind: "paper", ref: "Duong et al. 2024, §V-B (Eq. 33) and Fig. 2", url: "https://arxiv.org/abs/2401.09520" },
      p2: { kind: "paper", ref: "Duong et al. 2024, §V-D (Eqs. 39–44)", url: "https://arxiv.org/abs/2401.09520" },
      p3: { kind: "paper", ref: "Duong et al. 2024, App. IX-A network sizes", url: "https://arxiv.org/abs/2401.09520" },
      p4: { kind: "paper", ref: "Duong et al. 2024, §VII-C Crazyflie quadrotor", url: "https://arxiv.org/abs/2401.09520" },
      p5: { kind: "paper", ref: "Duong et al. 2024, §VI IDA-PBC control", url: "https://arxiv.org/abs/2401.09520" },
      p6: { kind: "paper", ref: "Duong et al. 2024, §V-C training", url: "https://arxiv.org/abs/2401.09520" },
      c1: { kind: "code", repo: "thaipduong/LieGroupHamDL", path: "se3hamneuralode/SE3HamNODE.py", commit: "4408b85", url: "https://github.com/thaipduong/LieGroupHamDL/blob/4408b85/se3hamneuralode/SE3HamNODE.py" },
      c2: { kind: "code", repo: "thaipduong/LieGroupHamDL", path: "se3hamneuralode/nn_models.py", commit: "4408b85", url: "https://github.com/thaipduong/LieGroupHamDL/blob/4408b85/se3hamneuralode/nn_models.py" },
      c3: { kind: "code", repo: "thaipduong/LieGroupHamDL", path: "examples/quadrotor/train_quadrotor_SE3.py", commit: "4408b85", url: "https://github.com/thaipduong/LieGroupHamDL/blob/4408b85/examples/quadrotor/train_quadrotor_SE3.py" }
    },
    summary: {
      pattern: ["Physics-structured network", "p1"],
      params: null,
      vision: "None: pose and twist from state estimation or motion capture",
      backbone: ["Five tanh MLPs: Mᵥ⁻¹(p), Mω⁻¹(R), V(q), D(q, 𝔭), B(q); width 400 (Crazyflie)", "p2", "p3", "c1"],
      head: ["Port-Hamiltonian equations on SE(3) (Eq. 30) assemble ṗ, Ṙ and the momentum rate 𝔭̇", "p1", "c1"],
      output: ["Pose (p, R) and twist ζ = (v, ω) at t₁ … tₙ", "p1"],
      attention: "None",
      cond: ["Control u (thrust + 3 torques) enters as B(q)u, held constant per segment", "p1", "p4"],
      steps: ["Neural ODE solve; paper: 5th-order Runge–Kutta; training script default: rk4", "p6", "c3"],
      train: ["Crazyflie: 1,080 segments of N = 5 steps, 500 iterations, no nominal model", "p4"]
    },
    blueprint: {
      headline: "Port-Hamiltonian NODE: energy on SE(3)",
      note: "The two mass nets and the potential and input nets are queried at the current pose. The middle block builds H = ½𝔭ᵀM⁻¹𝔭 + V, differentiates it, and applies the SE(3) port-Hamiltonian equations with dissipation D and control B u (the Crazyflie model drops D); an ODE solver repeats this along each segment.",
      towers: [
        { mod: "mass", title: "Mass nets (×2)", sub: "Mᵥ⁻¹(p) and Mω⁻¹(R)", compact: true,
          input: { label: "p (3) or R (9)", caption: "position for Mᵥ, rotation for Mω" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Linear → 400 · tanh", call: ["Width 400 (Crazyflie)", "p3", "c1"] }] },
            { t: "linear", label: "Linear → 6 = L entries" },
            { t: "linear", label: "M⁻¹ = L Lᵀ + ε I", call: ["ε = 0.01", "p3", "c1"],
              zoom: { k: "rows", title: "Cholesky mass network", rows: ["net out: 3 diagonal + 3 lower", "fill lower-triangular L (3 × 3)", "M⁻¹ = (L₀ + L)(L₀ + L)ᵀ + εI", "positive definite by construction"] } } ],
          output: { label: "Mᵥ⁻¹, Mω⁻¹ (3 × 3 each)" } },
        { mod: "ph", title: "Port-Hamiltonian layer", sub: "SE(3) equations, autograd",
          input: { label: "Pose q, momentum 𝔭, u", caption: "𝔭 = M(q) ζ is an internal state" },
          rows: [
            { id: "ham", t: "linear", label: "H = ½ 𝔭ᵀM⁻¹𝔭 + V(q)" },
            { t: "linear", label: "∂H/∂q, ∂H/∂𝔭 (autograd)" },
            { t: "linear", label: "ṗ = R v, Ṙ = R ω̂", call: ["Kinematics keep q on SE(3)", "p1"] },
            { id: "force", t: "linear", label: "𝔭̇ = ad* − D ∂H/∂𝔭 + B u" },
            { t: "linear", label: "ODESolve over N = 5 steps",
              zoom: { k: "rows", title: "Loss on the Lie group", rows: ["rotation: ‖log(R̄ Rᵀ)∨‖²", "+ ‖p − p̄‖² (position)", "+ ‖ζ − ζ̄‖² (twist)", "adjoint-state backprop"] } } ],
          output: { label: "pose and twist at t₁ … tₙ" } },
        { mod: "vb", title: "Potential + input nets", sub: "V(q) and B(q)", compact: true,
          input: { label: "Pose q (12)", caption: "p and flattened R" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "linear", label: "Linear → 400 · tanh" }] },
            { t: "linear", label: "V → 1 · B → 24 (6 × 4)", call: ["B maps 4 inputs to the twist", "p3", "c1"],
              zoom: { k: "rows", title: "IDA-PBC tracking controller", rows: ["desired energy Hᵈ = H + Hᵃ", "closed loop (Jᵈ − Rᵈ) ∇Hᵈ", "u from the matching condition", "Lyapunov: Ḣᵈ ≤ 0"] } } ],
          output: { label: "V(q), B(q)" } }
      ],
      links: [
        { from: "mass", to: "ph", toRow: "ham", label: "M⁻¹(q)" },
        { from: "vb", to: "ph", toRow: "force", label: "V, B(q)" }
      ]
    },
    modules: [
      { id: "mass", role: "world", roleLabel: "Inverse mass nets", name: "Mᵥ⁻¹ and Mω⁻¹", sub: "3 × 400 · tanh · Cholesky", col: 0, frozen: false, short: "Mass",
        stack: { rows: [
          { t: "in", label: "position p (Mᵥ) or rotation R (Mω)", dims: "3 or 9", c: "data-5" },
          { t: "block", label: "hidden layer", n: "3", rows: [{ t: "linear", label: "Linear → 400 · tanh" }] },
          { t: "linear", label: "Linear → 6", dims: "lower-triangular L" },
          { t: "linear", label: "M⁻¹ = LLᵀ + εI", dims: "ε = 0.01" },
          { t: "out", label: "3 × 3 inverse mass block", dims: "positive definite", c: "data-5" } ],
          facts: [["Crazyflie", ["3 hidden × 400, tanh", "p3", "c1"]], ["Real PX4", ["3 hidden × 20, tanh", "p3"]], ["ε", ["0.01", "p3", "c1"]]] } },
      { id: "ph", role: "net", roleLabel: "Physics block", name: "Port-Hamiltonian ODE", sub: "SE(3) · autograd · solver", col: 1, frozen: true, main: true, short: "pH layer",
        note: "No weights of its own; energy is conserved except for dissipation D and the control port B u." },
      { id: "vb", role: "world", roleLabel: "Energy and input nets", name: "V(q) and B(q)", sub: "2 × 400 · tanh", col: 2, frozen: false, short: "V, B",
        stack: { rows: [
          { t: "in", label: "pose q = (p, R)", dims: "12 values", c: "data-5" },
          { t: "block", label: "hidden layer", n: "2", rows: [{ t: "linear", label: "Linear → 400 · tanh" }] },
          { t: "linear", label: "V: → 1 · B: → 24", dims: "B reshaped to 6 × 4" },
          { t: "out", label: "potential V(q), input matrix B(q)", c: "data-5" } ],
          facts: [["Crazyflie", ["2 hidden × 400, tanh", "p3", "c1"]], ["B output", ["24 = 6 × 4", "p3", "c1"]], ["Real PX4", ["2 hidden × 20; plus D nets 3 × 20", "p3"]]] } }
    ],
    inputs: [
      { to: "mass", mod: "state", label: "position p, rotation R", n: "3 + 9", k: 3 },
      { to: "ph", mod: "action", label: "control u", n: "thrust + 3 torques", k: 2 },
      { to: "vb", mod: "state", label: "pose q", n: "12", k: 3 }
    ],
    outputs: [{ from: "ph", mod: "future", label: "pose and twist trajectory", n: "t₁ … tₙ", k: 4 }],
    links: [
      { from: "mass", to: "ph", kind: "feeds", label: "Mᵥ⁻¹, Mω⁻¹" },
      { from: "vb", to: "ph", kind: "feeds", label: "V(q), B(q)" }
    ],
    callouts: [
      "Paper vs code: §V-C integrates with a <b>5th-order Runge–Kutta</b> to keep R on SO(3); the training script's default solver is rk4 (and its default step count is 5,000, where §VII-C reports 500 iterations).",
      "The learned Crazyflie terms converge to constants: Mᵥ⁻¹ ≈ 27.5 I and Bω ≈ 76 I, with V linear in height (§VII-C)."
    ]
  });

  /* ---------------- Neural SDE (Djeumou) ---------------- */
  RB.arch.spec({
    id: "neural-sde", method: "neural-sde", name: "Physics-constrained neural SDE", year: 2023,
    figRef: "Djeumou et al. Fig. 2 · §2.2–2.3 · App. A, D", prov: "hexacopter (Eq. 4)",
    lede: "A stochastic model whose drift is the known 6-DoF rigid-body equations with small learned pieces, and whose diffusion is a learned, distance-aware uncertainty: near zero around the training data, saturating far from it.",
    sources: {
      p1: { kind: "paper", ref: "Djeumou et al. 2023, §2.1 and Fig. 2", url: "https://arxiv.org/abs/2306.06335" },
      p2: { kind: "paper", ref: "Djeumou et al. 2023, §2.2 distance-aware diffusion", url: "https://arxiv.org/abs/2306.06335" },
      p3: { kind: "paper", ref: "Djeumou et al. 2023, App. A implementation details", url: "https://arxiv.org/abs/2306.06335" },
      p4: { kind: "paper", ref: "Djeumou et al. 2023, App. D hexacopter model (Eq. 4)", url: "https://arxiv.org/abs/2306.06335" },
      p5: { kind: "paper", ref: "Djeumou et al. 2023, §3.3 hexacopter", url: "https://arxiv.org/abs/2306.06335" },
      c1: { kind: "code", repo: "wuwushrek/sde4mbrl", path: "sde4mbrlExamples/rotor_uav/hexa_ahg/optimizer_sde.yaml", commit: "f4f34bf", url: "https://github.com/wuwushrek/sde4mbrl/blob/f4f34bf/sde4mbrlExamples/rotor_uav/hexa_ahg/optimizer_sde.yaml" },
      c2: { kind: "code", repo: "wuwushrek/sde4mbrl", path: "sde4mbrl/nsde.py", commit: "f4f34bf", url: "https://github.com/wuwushrek/sde4mbrl/blob/f4f34bf/sde4mbrl/nsde.py" }
    },
    summary: {
      pattern: ["Physics-structured network", "p1"],
      params: null,
      vision: "None: EKF state from IMU and motion capture",
      backbone: ["Known 6-DoF rigid-body drift with learned mass, inertia, motor map and mixer", "p4"],
      head: ["Residual force and moment MLPs: hidden 8 and 16, tanh", "p4", "c1"],
      output: ["Sampled state paths from dx = fθ dt + Σϕ ⋆ dW", "p1"],
      attention: "None",
      cond: ["Σ = σₘₐₓ ⊙ hϕ(ηψ(v, ω)); ηψ: 2 × 32 swish, sigmoid out", "p2", "p3", "c1"],
      steps: ["Training rollouts: Milstein (paper) / Euler–Maruyama (config), step 0.05 s, horizon 20", "p4", "c1"],
      rate: ["State estimates and MPC at 100 Hz", "p5"],
      latency: ["0.13 ms per prediction with 1 particle, 0.7 ms with 50 (horizon 30)", "p3"],
      train: ["203 s of manual flight in 3 trajectories; Adam, lr 0.01 → 0.001, batch 512", "p5", "p3"]
    },
    blueprint: {
      headline: "Neural SDE: physics drift, learned doubt",
      note: "The learned terms on the left slot into the known rigid-body drift in the middle. The diffusion net on the right sees only velocity and body rates and scales noise by distance from the training data; the solver samples paths for the MPC.",
      towers: [
        { mod: "unk", title: "Learned unknowns", sub: "inside the drift", compact: true,
          input: { label: "u ∈ [0, 1]⁶, (v, ω)", caption: "motor commands; v and ω" },
          rows: [
            { t: "linear", label: "Motor map T = α u + β", call: ["Degree-1 polynomial per motor", "p4", "c1"] },
            { t: "linear", label: "Mixer Aₘᵢₓ (6 × 6)", call: ["Learned, geometry-constrained", "p4"] },
            { t: "mlp", label: "fᵣₑₛ, Mᵣₑₛ: 8 → 16 · tanh", call: ["Input: v and ω only", "p4", "c1"] },
            { t: "linear", label: "mθ, Jθ = diag(Jx, Jy, Jz)" } ],
          output: { label: "thrust, moments, residuals" } },
        { mod: "drift", title: "Physics drift fθ", sub: "6-DoF rigid body (Eq. 4)",
          input: { label: "State x (13)", caption: "p, v, quaternion q, ω" },
          rows: [
            { t: "linear", label: "ṗ = v, q̇ = ½ q ⊗ ω (known)" },
            { id: "force", t: "linear", label: "v̇ = q(T + fᵣₑₛ)q̄ / m + g", call: ["g = (0, 0, −9.81)", "p4"] },
            { t: "linear", label: "ω̇ = J⁻¹(M + Mᵣₑₛ − ω×Jω)" },
            { id: "solve", t: "linear", label: "Sample paths: + Σ ⋆ dW",
              zoom: { k: "rows", title: "Training losses", rows: ["data: NLL of sampled paths", "gradient: ∇ηψ = 0 at data", "strong convexity in a ball", "Σ 1/μζ; μζ is a 2 × 8 tanh net"] } } ],
          output: { label: "state paths for the MPC" } },
        { mod: "diff", title: "Diffusion Σϕ", sub: "distance-aware", compact: true,
          input: { label: "Features (v, ω)", caption: "6 values" },
          rows: [
            { t: "mlp", label: "ηψ: 2 × 32 swish", call: ["Hidden 32, 32; sigmoid output", "p3", "c1"],
              zoom: { k: "rows", title: "Distance awareness", rows: ["near data: ηψ ≈ 0 → Σ ≈ 0", "moving away: ηψ rises", "far away: ηψ → 1, Σ → σₘₐₓ"] } },
            { t: "linear", label: "hϕ = σ(W σ⁻¹(η) + b)", call: ["Entries of W kept above 1", "p2"] },
            { t: "linear", label: "Σ = σₘₐₓ ⊙ hϕ(η)", call: ["σₘₐₓ: overestimated sensor noise", "p5"] } ],
          output: { label: "diffusion Σ(x)" } }
      ],
      links: [
        { from: "unk", to: "drift", toRow: "force", label: "T, M, fᵣₑₛ" },
        { from: "diff", to: "drift", toRow: "solve", label: "Σ" }
      ]
    },
    modules: [
      { id: "unk", role: "world", roleLabel: "Learned unknown terms", name: "Motor map + residuals", sub: "MLPs 8 → 16 · tanh", col: 0, frozen: false, short: "Unknowns",
        stack: { rows: [
          { t: "in", label: "motor commands u; v, ω", dims: "6 + 6", c: "data-3" },
          { t: "linear", label: "Tₘₒₜ(uᵢ) = α uᵢ + β, per motor", dims: "degree 1" },
          { t: "linear", label: "Aₘᵢₓ: 6 × 6 → thrust + 3 moments" },
          { t: "mlp", label: "fᵣₑₛ, Mᵣₑₛ MLPs", dims: "hidden 8, 16 · tanh" },
          { t: "linear", label: "mθ, Jθ (diagonal inertia)", dims: "non-negative" },
          { t: "out", label: "forces, moments, mass, inertia", c: "data-4" } ],
          facts: [["Residual MLPs", ["2 hidden layers: 8 and 16, tanh", "p4", "c1"]], ["Motor map", ["polynomial of degree 1", "p4", "c1"]], ["Mixer", ["6 × 6, learned", "p4"]]] } },
      { id: "drift", role: "net", roleLabel: "Physics-constrained drift", name: "Rigid-body SDE", sub: "13-d state · solver", col: 1, frozen: "partial", main: true, short: "Drift",
        note: "Known structure; only the terms from the left module are learned." },
      { id: "diff", role: "latent", roleLabel: "Distance-aware diffusion", name: "Diffusion net Σϕ", sub: "ηψ 2 × 32 · swish", col: 2, frozen: false, short: "Diffusion",
        stack: { rows: [
          { t: "in", label: "Features (v, ω)", dims: "6", c: "data-5" },
          { t: "mlp", label: "ηψ: Dense 32 · swish (× 2) → 1 · sigmoid" },
          { t: "linear", label: "hϕ(η) = sigmoid(W sigmoid⁻¹(η) + b)", dims: "W > 1 element-wise" },
          { t: "linear", label: "Σ = σₘₐₓ ⊙ hϕ", dims: "applied to v and ω rows" },
          { t: "out", label: "diffusion Σ(x)", c: "data-7" } ],
          facts: [["ηψ", ["2 × 32, swish", "p3", "c1"]], ["μζ", ["2 × 8, tanh", "p3", "c1"]], ["Ball radius r", ["0.1 (hexacopter)", "p4", "c1"]], ["Convexity-loss weight", ["1 (hexacopter)", "p4", "c1"]]] } }
    ],
    inputs: [
      { to: "unk", mod: "action", label: "motor commands u", n: "6 in [0, 1]", k: 3 },
      { to: "drift", mod: "state", label: "state x", n: "13", k: 4 },
      { to: "diff", mod: "state", label: "v, ω", n: "6", k: 2 }
    ],
    outputs: [{ from: "drift", mod: "future", label: "sampled state paths", n: "nₚ particles", k: 4 }],
    links: [
      { from: "unk", to: "drift", kind: "feeds", label: "learned terms|in the drift" },
      { from: "diff", to: "drift", kind: "feeds", label: "Σ(x) ⋆ dW" }
    ],
    callouts: [
      "Paper vs code: App. D trains the hexacopter model with the <b>Milstein</b> solver; the released config uses euler_maruyama. App. A weights the zero-gradient loss by 0.01; the hexacopter config sets pen_grad_density = 1.0.",
      "In the code the density is sigmoid(NN − 7), so near-zero weights give near-zero noise (nsde.py)."
    ]
  });

  /* ---------------- PI-TCN ---------------- */
  RB.arch.spec({
    id: "pi-tcn", method: "pi-tcn", name: "PI-TCN", year: 2022,
    figRef: "Saviolo et al. Fig. 2 · §III-B–D · §IV-C", prov: "paper only",
    lede: "A temporal conv encoder reads 200 ms of velocity, attitude, body rate and motor-speed history; an MLP decodes six accelerations. A nominal rigid-body model enters only through a training loss, and the learned model runs inside an RK4-integrated MPC.",
    sources: {
      p1: { kind: "paper", ref: "Saviolo et al. 2022, §III-B and Fig. 2", url: "https://arxiv.org/abs/2206.03305" },
      p2: { kind: "paper", ref: "Saviolo et al. 2022, §IV-C architecture and training", url: "https://arxiv.org/abs/2206.03305" },
      p3: { kind: "paper", ref: "Saviolo et al. 2022, §III-C physics-inspired loss", url: "https://arxiv.org/abs/2206.03305" },
      p4: { kind: "paper", ref: "Saviolo et al. 2022, §III-D and supp. F (MPC)", url: "https://arxiv.org/abs/2206.03305" },
      p5: { kind: "paper", ref: "Saviolo et al. 2022, Table II", url: "https://arxiv.org/abs/2206.03305" },
      p6: { kind: "paper", ref: "Saviolo et al. 2022, §IV-A–B system and data", url: "https://arxiv.org/abs/2206.03305" },
      p7: { kind: "paper", ref: "Saviolo et al. 2022, supp. Table VI (history length)", url: "https://arxiv.org/abs/2206.03305" }
    },
    summary: {
      pattern: ["Physics-regularized temporal CNN dynamics model", "p1"],
      params: null,
      vision: "None",
      backbone: ["TCN encoder: 4 hidden layers of 16, ReLU, BatchNorm, dropout 10 %", "p2"],
      head: ["MLP decoder: hidden 64, 32, 32, ReLU → 6", "p2"],
      output: ["Linear and angular accelerations (v̇, ω̇), a 6 × 1 vector", "p1"],
      attention: "None",
      cond: ["History 14 × T of v, q, ω and 4 motor speeds; T = 20 at δt = 10 ms; no position", "p1", "p2"],
      steps: ["MPC integrates the model with RK4: 1 s horizon, N = 20", "p4"],
      rate: ["MPC above 100 Hz on a laptop", "p4"],
      latency: ["1.735 ms per prediction", "p5"],
      train: ["60 of 68 real trajectories (58 min 3 s total); Adam 10⁻⁴, batch 1,024, 10,000 epochs", "p2", "p6"]
    },
    blueprint: {
      headline: "PI-TCN: history in, accelerations out",
      note: "The TCN compresses the 200 ms window into one hidden vector and the MLP maps it to accelerations. The nominal quadrotor model on the right has no weights and is used only in training: it pulls predictions on sampled inputs toward rigid-body physics.",
      towers: [
        { mod: "tcn", title: "TCN encoder", sub: "dilated causal convolutions",
          input: { label: "History 14 × 20", caption: "v, q, ω, 4 motor speeds; 200 ms" },
          rows: [
            { t: "block", n: "4", rows: [
              { t: "conv", label: "Dilated causal conv · 16", call: ["Size 16; kernel, dilation not stated", "p2"] },
              { t: "norm", label: "BatchNorm" },
              { t: "mlp", label: "ReLU · Dropout 10 %" } ] } ],
          output: { label: "hidden-state vector" } },
        { mod: "mlp", title: "MLP decoder", sub: "dense head",
          input: { label: "Hidden state", caption: "from the TCN" },
          rows: [
            { t: "linear", label: "Linear → 64 · ReLU", call: ["Hidden sizes 64, 32, 32", "p2"],
              zoom: { k: "rows", title: "History length (Table VI)", rows: ["T = 0: RMSE 3.36", "T = 1: RMSE 1.32", "T = 4: RMSE 0.82", "T = 20: RMSE 0.23, 1.73 ms"] } },
            { t: "linear", label: "Linear → 32 · ReLU" },
            { t: "linear", label: "Linear → 32 · ReLU" },
            { id: "out", t: "linear", label: "Linear → 6 (v̇, ω̇)",
              zoom: { k: "rows", title: "MPC with the learned model", rows: ["min Σ x̃ᵀQₓx̃ + ũᵀQᵤũ", "Xᵢ₊₁ = RK4(h(Xᵢ, Uᵢ))", "1 s horizon, N = 20", "RTI + HPIPM, > 100 Hz"] } } ],
          output: { label: "accelerations; RK4 in the MPC" } },
        { mod: "nom", title: "Nominal model", sub: "training loss only", compact: true,
          input: { label: "Sampled (x, u)", caption: "fixed batch of 1,024" },
          rows: [
            { t: "linear", label: "f, τ from rotor constants" },
            { t: "linear", label: "v̇ = (q ⊙ f)/m + g" },
            { t: "linear", label: "ω̇ = J⁻¹(τ − ω × Jω)",
              zoom: { k: "rows", title: "Composite loss", rows: ["L = Lₘₛₑ + λ Lₚᵢ", "first half: λ = 0", "second half: λ = 1", "Lₚᵢ: distance to hₙₒₘ"] } } ],
          output: { label: "physics target hₙₒₘ" } }
      ],
      links: [
        { from: "tcn", to: "mlp", toRow: "input", label: "hidden state" },
        { from: "nom", to: "mlp", toRow: "out", label: "λ Lₚᵢ" }
      ]
    },
    modules: [
      { id: "tcn", role: "state-enc", roleLabel: "Temporal encoder", name: "TCN encoder", sub: "4 × 16 · BN · dropout 0.1", col: 0, frozen: false, short: "TCN",
        stack: { rows: [
          { t: "in", label: "states and motor speeds, T = 20", dims: "14 × 20, δt = 10 ms", c: "data-5" },
          { t: "block", label: "TCN layer", n: "4", rows: [
            { t: "conv", label: "dilated causal conv", dims: "16 channels" },
            { t: "norm", label: "BatchNorm" },
            { t: "mlp", label: "ReLU · Dropout 0.1" } ] },
          { t: "out", label: "compact hidden state", c: "data-5" } ],
          facts: [["Layers", ["4 hidden, size 16", "p2"]], ["Regularization", ["BatchNorm, dropout 10 %", "p2"]], ["Kernel, dilation", "not stated"], ["Window", ["20 × 10 ms = 200 ms", "p2"]]] } },
      { id: "mlp", role: "world", roleLabel: "Dynamics decoder", name: "MLP decoder", sub: "64 → 32 → 32 → 6", col: 1, frozen: false, main: true, short: "MLP",
        stack: { rows: [
          { t: "in", label: "hidden state", c: "data-5" },
          { t: "linear", label: "Linear → 64 · ReLU" },
          { t: "linear", label: "Linear → 32 · ReLU" },
          { t: "linear", label: "Linear → 32 · ReLU" },
          { t: "linear", label: "Linear → 6" },
          { t: "out", label: "v̇, ω̇", dims: "integrated by RK4 in the MPC", c: "data-4" } ],
          facts: [["Hidden", ["64, 32, 32", "p2"]], ["Optimizer", ["Adam, lr 10⁻⁴, 10,000 epochs", "p2"]], ["Batch", ["1,024 for both data and physics batches", "p2"]], ["Inference", ["1.735 ms", "p5"]]] } },
      { id: "nom", role: "critic", roleLabel: "Physics prior (loss only)", name: "Nominal quadrotor model", sub: "rigid body · training only", col: 2, frozen: true, short: "Nominal",
        note: "Not part of the deployed model; it only supplies Lₚᵢ during the second half of training." }
    ],
    inputs: [{ to: "tcn", mod: "state", label: "v, q, ω, motor speeds", n: "14 × 20", k: 5 }],
    outputs: [{ from: "mlp", mod: "state", label: "accelerations v̇, ω̇", n: "6", k: 3 }],
    links: [
      { from: "tcn", to: "mlp", kind: "feeds", label: "hidden state" },
      { from: "nom", to: "mlp", kind: "feeds", label: "soft constraint|λ Lₚᵢ (training)" }
    ],
    callouts: [
      "No model code is public: the official repository (arplaboratory/PI-TCN) holds only the bag-to-dataset processing script, so every number here comes from the paper.",
      "Unlike residual models, the physics is a <b>soft</b> loss term, so a wrong nominal model degrades PI-TCN less than RES-TCN (§V-B)."
    ]
  });
})();
