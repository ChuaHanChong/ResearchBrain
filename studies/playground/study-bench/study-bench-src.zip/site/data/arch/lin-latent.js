/* Architecture specs: language-driven representations and latent-action models on the Evolution lineage map
   (Voltron, LIV, IGOR, GO-1, UniVLA (Bu et al.), H-RDT, CLAP). Numbers from the papers and official code; see sources. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ Voltron */
  RB.arch.spec({
    id: "voltron", method: "voltron", name: "Voltron", year: 2023, parent: "mvp",
    diffRows: ["vision", "backbone", "head", "attention", "cond", "train"],
    figRef: "Karamcheti et al. Fig. 2 · §3–4 · App. B", prov: "V-Gen (α = 0.5), ViT-S",
    lede: "A masked autoencoder that reads two video frames and their caption in one ViT-S encoder. A shared decoder rebuilds the masked pixels and, half the time, writes the caption back out, so features carry both spatial detail and semantics.",
    sources: {
      p1: { kind: "paper", ref: "Karamcheti et al. 2023, §3 (Eq. for L(θ), α, V-Cond / V-Dual / V-Gen)", url: "https://arxiv.org/abs/2302.12766" },
      p2: { kind: "paper", ref: "Karamcheti et al. 2023, §4 (implementation, data, architecture details, MAP)", url: "https://arxiv.org/abs/2302.12766" },
      p3: { kind: "paper", ref: "Karamcheti et al. 2023, App. B.2 (joint vision–language processing)", url: "https://arxiv.org/abs/2302.12766" },
      p4: { kind: "paper", ref: "Karamcheti et al. 2023, App. B.4 (released artifacts)", url: "https://arxiv.org/abs/2302.12766" },
      c1: { kind: "code", repo: "siddk/voltron-robotics", path: "voltron/conf/models.py", commit: "1b299bf", url: "https://github.com/siddk/voltron-robotics/blob/1b299bf/voltron/conf/models.py" },
      c2: { kind: "code", repo: "siddk/voltron-robotics", path: "voltron/models/core/vgen.py", commit: "1b299bf", url: "https://github.com/siddk/voltron-robotics/blob/1b299bf/voltron/models/core/vgen.py" },
      c3: { kind: "code", repo: "siddk/voltron-robotics", path: "voltron/models/util/transformer.py", commit: "1b299bf", url: "https://github.com/siddk/voltron-robotics/blob/1b299bf/voltron/models/util/transformer.py" },
      c4: { kind: "code", repo: "siddk/voltron-robotics", path: "voltron/conf/datasets.py", commit: "1b299bf", url: "https://github.com/siddk/voltron-robotics/blob/1b299bf/voltron/conf/datasets.py" },
      c5: { kind: "code", repo: "siddk/voltron-robotics", path: "voltron/models/util/extraction.py", commit: "1b299bf", url: "https://github.com/siddk/voltron-robotics/blob/1b299bf/voltron/models/util/extraction.py" }
    },
    summary: {
      pattern: ["Visual representation encoder", "p1"],
      params: ["ViT-S encoder 22M (ViT-B variant 86M)", "p4"],
      vision: ["ViT-S/16 at 224 × 224 → 196 patches per frame; 2 frames, 75 % masked", "p2", "c1", "c4"],
      backbone: ["Multimodal encoder: 12 blocks, width 384, 6 heads over [visible patches ‖ caption]", "p2", "c1"],
      head: ["Shared decoder: 6 blocks, width 192; pixel head + language head (vocab 30,522)", "c1", "c2"],
      output: ["Frozen patch (and caption) features, pooled by MAP for each downstream head", "p2", "c5"],
      attention: ["Encoder bidirectional; decoder prefix mask (patches full, caption causal)", "p3", "c2"],
      cond: ["Caption via frozen DistilBERT, Linear 768 → 384, padded to 20 tokens", "p3", "c1", "c2"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["Sth-Sth v2: 168K clips × 5 frames, 400 epochs, batch 1,024, TPU v3-8", "p2", "c4"]
    },
    changes: [
      "The encoder also reads the <b>caption</b>: frozen DistilBERT tokens join the visible patches in one sequence.",
      "With probability α the caption becomes &lt;NULL&gt; and the decoder must <b>generate</b> it (V-Gen uses α = 0.5).",
      "Two frames per sample (an early and a later one) share one mask and get learned frame embeddings.",
      "Blocks switch to <b>RMSNorm, SwishGLU and LayerScale</b> for training stability.",
      "Features are read out with <b>multihead attention pooling</b> instead of the CLS token."
    ],
    blueprint: {
      headline: "Voltron: reconstruct pixels, condition or write words",
      note: "Caption tokens from a frozen DistilBERT are projected to 384 and appended to the visible patches of both frames. The encoder is a pre-norm ViT-S with RMSNorm, SwishGLU and LayerScale. The decoder adds mask tokens and runs under a prefix mask: patch rows see only patches, caption rows see all patches and earlier words.",
      towers: [
        { mod: "lm", title: "DistilBERT", sub: "frozen text encoder", compact: true,
          input: { label: "Caption tokens", caption: "or <NULL> when generating" },
          rows: [
            { t: "embed", label: "DistilBERT (frozen)", call: ["Width 768, vocab 30,522", "c1"] },
            { t: "linear", label: "Linear 768 → 384", note: "Learned projection into the encoder width (§4, lang2encoder)",
              zoom: { k: "rows", title: "The α switch (§3.2)", rows: ["draw z ~ Bernoulli(α) per example", "z = 0: encoder sees the caption", "z = 1: encoder sees <NULL>", "decoder then generates the caption"] } },
            { t: "embed", label: "+ modality and 1-D sin-cos", call: ["Padded to 20 tokens", "p3", "c4"] } ],
          output: { label: "20 caption tokens" } },
        { mod: "enc", title: "ViT-S/16 encoder", sub: "multimodal, RMSNorm + SwishGLU",
          input: { label: "Visible patches + caption", caption: "25 % of 2 × 196 patches, shared mask" },
          rows: [
            { t: "embed", label: "Patch embed 16 × 16", call: ["2-D sin-cos positions + frame embedding", "p3", "c2"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["6 heads × 64 = 384, bidirectional", "c1"], zoom: { k: "heads", q: 6, kv: 6, hd: 64, title: "Attention heads (ViT-S)" } },
              { t: "linear", label: "LayerScale γ", call: ["γ initialised to 0.1", "c3"] },
              { t: "add", span: 3 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwishGLU)", call: ["Hidden 1,536 (ratio 4)", "c1", "c3"], zoom: { k: "glu", act: "SiLU", d: "384", ff: "1,536", title: "Feed forward (SwishGLU)" } },
              { t: "linear", label: "LayerScale γ" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Final RMSNorm" } ],
          output: { label: "patch + caption features (MAP downstream)" } },
        { mod: "dec", title: "Shared decoder", sub: "MAE reconstructor + language generator",
          input: { label: "Encoder tokens + mask tokens", caption: "own modality and frame embeddings" },
          rows: [
            { t: "linear", label: "Linear 384 → 192", call: ["Encoder-to-decoder projection", "c2"] },
            { t: "block", n: "6", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Prefix-masked attention", call: ["6 heads; caption rows causal", "c1", "p3"],
                zoom: { k: "rows", title: "Decoder prefix mask", rows: ["patch rows attend to all patches", "caption row t: patches + words < t", "padding removed by the length mask", "encoder has no such mask"] } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwishGLU)", call: ["Hidden 768 (ratio 4)", "c1", "c3"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "Patch head 192 → 768", call: ["16 × 16 × 3 normalised pixels, MSE", "p1", "c2"] },
            { t: "linear", label: "Language head 192 → 30,522", call: ["NLL of the caption (V-Gen only)", "p1", "c2"] } ],
          output: { label: "masked pixels and the caption" } }
      ],
      links: [
        { from: "lm", to: "enc", toRow: "input", label: "caption tokens" },
        { from: "enc", to: "dec", toRow: "input", label: "visible features" }
      ]
    },
    modules: [
      { id: "lm", role: "lang", name: "DistilBERT", sub: "768-d · 20 tokens", col: 0, frozen: true, short: "DistilBERT",
        stack: { rows: [
          { t: "in", label: "caption or <NULL>", dims: "padded to 20", c: "data-2" },
          { t: "embed", label: "DistilBERT last hidden state", dims: "20 × 768" },
          { t: "linear", label: "Linear 768 → 384 (+ <LANG> embedding)" },
          { t: "out", label: "caption tokens", dims: "join the encoder sequence", c: "data-2" } ],
          facts: [["Model", ["distilbert-base-uncased, frozen", "p3", "c1"]], ["Width", ["768", "c1"]], ["Max length", ["20 tokens", "p3", "c4"]], ["Positions", ["1-D sin-cos", "p3"]]] } },
      { id: "enc", role: "vision-enc", name: "ViT-S/16 encoder", sub: "12 × 384 · 6 heads", col: 1, frozen: false, main: true, params: "22M", short: "Encoder",
        stack: { rows: [
          { t: "in", label: "2 frames 224 × 224, 75 % masked", dims: "49 visible patches each", c: "data-1" },
          { t: "embed", label: "Patch 16 × 16 → 384 + sin-cos + frame emb." },
          { t: "block", label: "Pre-norm block", n: "12", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MHA · 6 heads · bidirectional" }, { t: "add", span: 2, note: "LayerScale γ before the residual add" },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwishGLU 384 → 1,536 → 384" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "RMSNorm" },
          { t: "out", label: "patch + caption features", c: "data-1" } ],
          facts: [["Width / depth / heads", ["384 / 12 / 6", "p2", "c1"]], ["Mask ratio", ["0.75, one mask for both frames", "p1", "c1"]], ["Norm / FFN", ["RMSNorm, SwishGLU, LayerScale 0.1", "p2", "c3"]], ["Base variant", ["768 / 12 / 12, 86M", "c1", "p4"]]] } },
      { id: "dec", role: "net", roleLabel: "MAE + LM decoder", name: "Shared decoder", sub: "6 × 192 · prefix mask", col: 2, frozen: false, short: "Decoder",
        stack: { rows: [
          { t: "in", label: "visible features + mask tokens + caption", c: "data-8" },
          { t: "linear", label: "Linear 384 → 192" },
          { t: "block", label: "Decoder block", n: "6", rows: [{ t: "attn", label: "MHA · 6 heads · prefix mask" }, { t: "ffn", label: "SwishGLU 192 → 768 → 192" }] },
          { t: "linear", label: "Patch head → 768 pixels · language head → 30,522" },
          { t: "out", label: "pixels (MSE) + caption (NLL)", c: "data-4" } ],
          facts: [["Width / depth / heads", ["192 / 6 / 6", "c1"]], ["Loss weights (code)", ["MAE 1.0, LM 0.5", "c1", "c2"]], ["Pixel target", ["normalised per patch", "p1", "c1"]]] } }
    ],
    inputs: [
      { to: "lm", mod: "lang", label: "caption", n: "≤ 20 tokens", k: 3 },
      { to: "enc", mod: "vision", label: "2 frames, 75 % masked", n: "224 × 224", k: 5 }
    ],
    outputs: [
      { from: "enc", mod: "other", label: "features → MAP", n: "frozen downstream", k: 3 },
      { from: "dec", mod: "vision", label: "masked patches", n: "MSE", k: 3 },
      { from: "dec", mod: "lang", label: "caption", n: "if generating", k: 2 }
    ],
    links: [
      { from: "lm", to: "enc", kind: "prefix", label: "Linear → 384|caption tokens" },
      { from: "enc", to: "dec", kind: "feeds", label: "Linear → 192|+ mask tokens" }
    ],
    mask: { name: "Decoder prefix mask", ref: "p3", axes: [{ label: "image patches", short: "img", mod: "vision" }, { label: "caption", short: "ℓ", mod: "lang" }], m: ["10", "11"],
      note: "Inside the caption block the mask is lower-triangular, so each word sees only earlier words." },
    callouts: [
      "Paper §3.2 writes the loss as L<sub>reconstruct</sub> + L<sub>generate</sub>; the released V-Gen code weights the language term by <code>lm_weight = 0.5</code>.",
      "Drawn is <b>V-Gen</b> (α = 0.5, two frames). V-Cond is the same network with α = 0 and one frame; V-Dual has α = 0 and two frames.",
      "Downstream, encoder and DistilBERT stay frozen; a MAP block (learned query, 12 heads for ViT-S) pools the features for each task head."
    ]
  });

  /* ------------------------------------------------------------------ LIV */
  RB.arch.spec({
    id: "liv", method: "liv", name: "LIV", year: 2023, parent: "vip",
    diffRows: ["vision", "backbone", "head", "cond", "train"],
    figRef: "Ma et al. Alg. 1 · §4.3 · App. B", prov: "CLIP RN50 weights",
    lede: "CLIP's ResNet-50 image encoder and text transformer, fine-tuned so that cosine similarity to an image or a text goal acts as a value function. The change in value between frames is a dense reward.",
    sources: {
      p1: { kind: "paper", ref: "Ma et al. 2023, §4.1–4.3 (Eq. 6, S = CS/(1 − γ), Alg. 1)", url: "https://arxiv.org/abs/2306.00958" },
      p2: { kind: "paper", ref: "Ma et al. 2023, App. B (Table 2)", url: "https://arxiv.org/abs/2306.00958" },
      p3: { kind: "paper", ref: "Ma et al. 2023, §5.3 (LCBC on frozen features)", url: "https://arxiv.org/abs/2306.00958" },
      p4: { kind: "paper", ref: "Radford et al. 2021 (CLIP), §2.4 and Table 19", url: "https://arxiv.org/abs/2103.00020" },
      c1: { kind: "code", repo: "penn-pal-lab/LIV", path: "liv/models/model_liv.py", commit: "a12991f", url: "https://github.com/penn-pal-lab/LIV/blob/a12991f/liv/models/model_liv.py" },
      c2: { kind: "code", repo: "penn-pal-lab/LIV", path: "liv/trainer.py", commit: "a12991f", url: "https://github.com/penn-pal-lab/LIV/blob/a12991f/liv/trainer.py" },
      c3: { kind: "code", repo: "penn-pal-lab/LIV", path: "liv/cfgs/training/pretrain.yaml", commit: "a12991f", url: "https://github.com/penn-pal-lab/LIV/blob/a12991f/liv/cfgs/training/pretrain.yaml" },
      c4: { kind: "code", repo: "penn-pal-lab/LIV", path: "liv/models/clip/clip/model.py", commit: "a12991f", url: "https://github.com/penn-pal-lab/LIV/blob/a12991f/liv/models/clip/clip/model.py" },
      c5: { kind: "code", repo: "penn-pal-lab/LIV", path: "liv/cfgs/config_liv.yaml", commit: "a12991f", url: "https://github.com/penn-pal-lab/LIV/blob/a12991f/liv/cfgs/config_liv.yaml" }
    },
    summary: {
      pattern: ["Visual representation encoder", "p1"],
      params: null,
      vision: ["CLIP modified ResNet-50 at 224 × 224 → attention pool → 1,024-d", "p2", "p4", "c4"],
      backbone: ["CLIP text transformer: 12 layers, width 512, 8 heads, 76-token context", "p4"],
      head: ["No head: value S = cos(φ(o), goal) / (1 − γ) for an image or text goal", "p1", "c2"],
      output: ["1,024-d image and text embeddings; reward = change in value", "p1", "p4"],
      attention: ["Text encoder causal; image side has one attention-pooling layer", "p4", "c4"],
      cond: "Goal is an image φ(g) or an instruction ψ(ℓ) in the same space",
      steps: null, chunk: null, rate: null, latency: null,
      train: ["EPIC-KITCHENS-100; 200,000 steps, batch 512, lr 1e-5, γ = 0.98, 8 V100", "p2", "c3"]
    },
    changes: [
      "Adds a <b>text encoder</b>: goals can be images or instructions in one shared 1,024-d space.",
      "Starts from <b>CLIP ResNet-50</b> weights rather than a randomly initialised torchvision ResNet-50.",
      "Similarity is <b>cosine / (1 − γ)</b> instead of negative L2 distance.",
      "Objective = VIP on images + CLIP-style InfoNCE on (last frame, caption); pretraining also adds VIP on text goals.",
      "Pretraining data move from Ego4D to text-annotated EPIC-KITCHENS-100."
    ],
    blueprint: {
      headline: "LIV: CLIP whose similarity is value",
      note: "Both CLIP towers are fine-tuned. Each sampled clip gives an initial frame, two consecutive frames and the last frame; VIP-I uses them with the last frame as goal, and InfoNCE pairs the last frame with its caption. No new layers are added.",
      towers: [
        { mod: "img", title: "CLIP ResNet-50 φ", sub: "modified ResNet (ResNet-D stem)",
          input: { label: "Image 224 × 224", caption: "frame o or goal image g" },
          rows: [
            { t: "conv", label: "Stem: 3 convs · avg-pool", call: ["3 × 3 convs: 32 → 32 → 64 channels", "c4", "p4"] },
            { t: "block", n: "16", label: "bottlenecks", rows: [{ t: "conv", label: "1×1 → 3×3 → avg-pool → 1×1" }] },
            { t: "pool", label: "Stages (3, 4, 6, 3)", call: ["Final width 2,048 at 7 × 7", "p4", "c4"] },
            { t: "attn", label: "Attention pool", call: ["32 heads; query = mean token", "c4", "p4"], zoom: { k: "heads", q: 32, kv: 32, hd: 64, title: "Attention pool (one layer)" } },
            { t: "linear", label: "Output projection", call: ["2,048 → 1,024 embedding", "p4", "c4"] } ],
          output: { label: "φ(o), 1,024-d" } },
        { mod: "txt", title: "CLIP text transformer ψ", sub: "GPT-2 style, causal",
          input: { label: "Instruction ℓ", caption: "BPE, [SOS] … [EOS]" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["Vocab 49,408, width 512", "p4"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Masked self-attention", call: ["8 heads × 64 = 512", "p4"], zoom: { k: "heads", q: 8, kv: 8, hd: 64, title: "Text attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "MLP (QuickGELU)", call: ["Hidden 2,048 (ratio 4)", "c4"], zoom: { k: "mlp", act: "QuickGELU", d: "512", ff: "2,048", title: "Text MLP" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "linear", label: "Projection at [EOS]", call: ["512 → 1,024", "p4"] } ],
          output: { label: "ψ(ℓ), 1,024-d" } },
        { mod: "value", title: "Implicit value", sub: "no weights", compact: true,
          input: { label: "φ(o) and φ(g) or ψ(ℓ)", caption: "all L2-normalised" },
          rows: [
            { t: "linear", label: "S = cos(·, ·) / (1 − γ)", call: ["γ = 0.98", "p1", "p2"] },
            { t: "linear", label: "VIP-I on (o₀, oₖ, oₖ₊₁, g)", note: "3 shuffled negatives in pretraining (pretrain.yaml, trainer.py)" },
            { t: "linear", label: "InfoNCE on (g, ℓ)", call: ["Symmetric, in-batch", "p1", "c2"],
              zoom: { k: "rows", title: "LIV objective (Eq. 6)", rows: ["VIP-I: value to the last frame g", "InfoNCE: last frame g ↔ caption ℓ", "pretraining adds VIP-L (goal = ℓ)", "weights 1 : 1 : 1 in pretraining"] } },
            { t: "linear", label: "R = S(oₜ₊₁; goal) − S(oₜ; goal)", call: ["Dense reward", "p1"] } ],
          output: { label: "value and reward" } }
      ],
      links: [
        { from: "img", to: "value", toRow: "input", label: "φ(o), φ(g)" },
        { from: "txt", to: "value", toRow: "input", label: "ψ(ℓ)" }
      ]
    },
    modules: [
      { id: "img", role: "vision-enc", name: "CLIP ResNet-50 φ", sub: "(3, 4, 6, 3) · attn pool", col: 0, frozen: false, main: true, short: "RN50",
        stack: { rows: [
          { t: "in", label: "RGB 224 × 224", dims: "CLIP normalisation", c: "data-1" },
          { t: "conv", label: "3-conv stem + avg-pool" },
          { t: "conv", label: "4 bottleneck stages (3, 4, 6, 3)", dims: "→ 7 × 7 × 2,048" },
          { t: "attn", label: "Attention pool, 32 heads" },
          { t: "linear", label: "c_proj 2,048 → 1,024" },
          { t: "out", label: "φ(o) ∈ ℝ¹⁰²⁴", c: "data-1" } ],
          facts: [["Init", ["CLIP RN50 weights", "p2", "c5"]], ["Embedding", ["1,024-d", "p4"]], ["Blocks", ["(3, 4, 6, 3)", "p4"]], ["Optimizer", ["Adam, lr 1e-5, weight decay 0.001", "p2", "c1"]]] } },
      { id: "value", role: "critic", roleLabel: "Implicit value", name: "Cosine value", sub: "S = cos / (1 − γ)", col: 1, frozen: false, short: "Value",
        note: "Not a network: value and reward are read off the two encoders." },
      { id: "txt", role: "lang", name: "CLIP text encoder ψ", sub: "12 × 512 · 8 heads", col: 2, frozen: false, short: "Text",
        stack: { rows: [
          { t: "in", label: "instruction ℓ (BPE)", c: "data-2" },
          { t: "embed", label: "Token embedding, vocab 49,408" },
          { t: "block", label: "Causal transformer block", n: "12", rows: [{ t: "attn", label: "Masked MHA · 8 heads" }, { t: "ffn", label: "MLP 512 → 2,048 → 512" }] },
          { t: "linear", label: "LayerNorm, take [EOS], project → 1,024" },
          { t: "out", label: "ψ(ℓ) ∈ ℝ¹⁰²⁴", c: "data-2" } ],
          facts: [["Width / depth / heads", ["512 / 12 / 8", "p4"]], ["Context", ["76 tokens", "p4"]], ["Trained in LIV", ["yes (grad_text = True)", "c5"]]] } }
    ],
    inputs: [
      { to: "img", mod: "vision", label: "frames + goal image", n: "224 × 224", k: 4 },
      { to: "txt", mod: "lang", label: "instruction ℓ", n: "text goal", k: 3 }
    ],
    outputs: [
      { from: "value", mod: "other", label: "reward R", n: "image or text goal", k: 2 },
      { from: "img", mod: "other", label: "features for LCBC", n: "frozen", k: 3 }
    ],
    links: [
      { from: "img", to: "value", kind: "feeds", label: "φ(o), φ(g)" },
      { from: "txt", to: "value", kind: "feeds", label: "ψ(ℓ)" }
    ],
    callouts: [
      "With S = cos / (1 − γ), the InfoNCE term's (1 − γ)·S is plain cosine similarity, so LIV's InfoNCE is exactly CLIP's loss (App. B); the code uses unscaled cosine logits.",
      "Fine-tuning drops VIP-L and the negatives (<code>langweight 0</code>, <code>num_negatives 0</code>) and uses batch 64 for 10,000 steps (Table 2)."
    ]
  });

  /* ------------------------------------------------------------------ IGOR */
  RB.arch.spec({
    id: "igor", method: "igor", name: "IGOR", year: 2024, parent: "lapa",
    diffRows: ["vision", "backbone", "head", "output", "train"],
    figRef: "Chen et al. Fig. 1 · §2 · App. B", prov: "paper only (no code released)",
    lede: "A latent action model turns the change from an image to its goal into 4 discrete tokens shared by humans and robots. A 12-layer policy predicts those tokens from text and frames, and an Open-Sora world model renders their effect.",
    sources: {
      p1: { kind: "paper", ref: "Chen et al. 2024, §2.1 (latent action model)", url: "https://arxiv.org/abs/2411.00785" },
      p2: { kind: "paper", ref: "Chen et al. 2024, §2.2 (world model, Eqs. 1–3)", url: "https://arxiv.org/abs/2411.00785" },
      p3: { kind: "paper", ref: "Chen et al. 2024, §2.3 (policy and low-level policy, Eqs. 4–5)", url: "https://arxiv.org/abs/2411.00785" },
      p4: { kind: "paper", ref: "Chen et al. 2024, §3.1–3.2 (data, codebook)", url: "https://arxiv.org/abs/2411.00785" },
      p5: { kind: "paper", ref: "Chen et al. 2024, App. B (training details)", url: "https://arxiv.org/abs/2411.00785" }
    },
    summary: {
      pattern: ["Latent-action pretraining", "p1"],
      params: "not stated",
      vision: ["Frozen DINOv2 ViT, patch 14, in both the latent model and the policy", "p5"],
      backbone: ["Foundation policy: ST-transformer, 12 layers, width 768, 12 heads", "p5"],
      head: ["Low-level policy: extra layers on the policy; one latent → τ = 3 RT-1 actions", "p3", "p5"],
      output: ["Latent action: N = 4 tokens from a 32-code book, 128-d each", "p4", "p5"],
      attention: ["Spatial + causal temporal attention in the IDM and the policy", "p1", "p3"],
      cond: ["Instruction via frozen CLIP text features, concatenated with image tokens", "p3", "p5"],
      steps: null,
      chunk: ["τ = 3 robot actions per latent action (RT-1 fine-tuning)", "p5"],
      rate: null, latency: null,
      train: ["~2.8M clips (0.8M robot + 2.0M human); latent model 140K steps, batch 512", "p4", "p5"]
    },
    changes: [
      "Latents come from <b>learnable readout tokens</b> and VQ over frozen DINOv2 features, not from a frame-feature difference.",
      "The forward model sees <b>one frame only</b>, with a different random crop, so motion must pass through the latent.",
      "Codebook: 32 codes of 128-d, still 4 tokens per transition.",
      "The policy is a 12-layer <b>ST-transformer</b> that regresses latents with L2, not a 7B language model.",
      "Adds an <b>Open-Sora world model</b> steered by the latent actions."
    ],
    blueprint: {
      headline: "IGOR: image-goal latents drive policy and world",
      note: "Stage 1 trains the latent action model and labels every clip. The foundation policy then learns to predict those latents from frames and text; a low-level head is added later on 1 % of RT-1. Separately, the Open-Sora world model cross-attends to one latent-action token per frame.",
      towers: [
        { mod: "lam", title: "Latent action model", sub: "IDM + VQ + single-frame FDM", compact: true,
          input: { label: "Frames o₁:ₜ₊₁, crop c₁", caption: "labels any video, no actions" },
          rows: [
            { t: "embed", label: "Frozen DINOv2 ViT", call: ["Patch size 14", "p5"] },
            { t: "group", label: "ST-transformer (depth not stated)", rows: [
              { t: "attn", label: "Spatial attention" },
              { t: "attn", label: "Causal temporal attn" } ] },
            { t: "linear", label: "Readout tokens → N = 4", call: ["Compress the visual change", "p1", "p4"] },
            { t: "linear", label: "Vector quantization", call: ["|C| = 32 codes, D = 128", "p4", "p5"],
              zoom: { k: "rows", title: "Latent action learning (§2.1)", rows: ["aₜ = I(c₁[o₁:ₜ₊₁])", "quantize each of 4 tokens", "ôₜ₊₁ = F(c₂[oₜ], aₜ)", "loss ‖c₂[oₜ₊₁] − ôₜ₊₁‖² + commit"] } },
            { t: "attn", label: "FDM: single-frame ViT", call: ["Sees oₜ only, crop c₂", "p1"] } ],
          output: { label: "latent action aₜ (4 × 128)" } },
        { mod: "policy", title: "Foundation policy", sub: "ST-transformer over frames + text",
          input: { label: "Frames o₁:ₜ + instruction s", caption: "frozen CLIP text features" },
          rows: [
            { t: "embed", label: "Frozen DINOv2 ViT", call: ["Patch size 14", "p5"] },
            { t: "linear", label: "Concat text + image tokens", call: ["Text from frozen CLIP", "p3", "p5"] },
            { t: "block", n: "12", rows: [
              { t: "attn", label: "Spatial attention", call: ["12 heads × 64 = 768", "p5"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "Policy attention heads" } },
              { t: "attn", label: "Temporal attention" },
              { t: "ffn", label: "Feed forward" } ] },
            { id: "pred", t: "linear", label: "Prediction layer → aₜ", call: ["L2 to the latent label", "p3"] },
            { t: "mlp", label: "Low-level policy layers", call: ["τ = 3 RT-1 actions per latent", "p5"],
              zoom: { k: "rows", title: "Two-stage policy (§2.3)", rows: ["stage 1: predict latents on 2.8M clips", "stage 2: freeze, add low-level layers", "input [s; P(s, o); o] per patch", "L2 to u¹:τ on 1 % of RT-1"] } } ],
          output: { label: "latent aₜ, then 7-D robot actions" } },
        { mod: "world", title: "Foundation world model", sub: "Open-Sora, rectified flow", compact: true,
          input: { label: "Noisy video latent", caption: "+ FDM prediction ôₜ₊₁:T added" },
          rows: [
            { t: "conv", label: "3-D VAE (Open-Sora)", call: ["8 × 8 space, 4× time", "p2"] },
            { t: "attn", label: "ST rectified-flow transformer" },
            { id: "xa", t: "attn", label: "Cross-attn to latent actions", call: ["1 token per frame", "p2"] },
            { t: "linear", label: "Velocity vθ", note: "Trained 48K steps, batch 12, lr 1e-4 (App. B.2)" } ],
          output: { label: "future frames oₜ₊₁:T" } }
      ],
      links: [
        { from: "lam", to: "policy", toRow: "pred", label: "latent labels" },
        { from: "policy", to: "world", toRow: "xa", label: "latent actions" }
      ]
    },
    modules: [
      { id: "lam", role: "latent", roleLabel: "Latent action model", name: "IDM + VQ + FDM", sub: "4 tokens · 32 codes", col: 0, frozen: false, short: "LAM",
        stack: { rows: [
          { t: "in", label: "o₁:ₜ₊₁ with random crop c₁", c: "data-1" },
          { t: "embed", label: "Frozen DINOv2 ViT, patch 14" },
          { t: "attn", label: "ST-transformer, causal in time" },
          { t: "linear", label: "4 readout tokens → VQ (32 × 128)" },
          { t: "attn", label: "FDM: single-frame ViT on c₂[oₜ] + aₜ" },
          { t: "out", label: "ôₜ₊₁ and latent aₜ", c: "data-7" } ],
          facts: [["Tokens / codes / dim", ["4 / 32 / 128", "p4", "p5"]], ["Training", ["140K steps, batch 512, lr 1.5e-4", "p5"]], ["Depth / width", "not stated"]] } },
      { id: "policy", role: "planner", roleLabel: "Foundation policy", name: "ST-transformer policy", sub: "12 × 768 · 12 heads", col: 1, frozen: false, main: true, short: "Policy",
        stack: { rows: [
          { t: "in", label: "o₁:ₜ + CLIP text features", c: "data-2" },
          { t: "block", label: "ST block", n: "12", rows: [{ t: "attn", label: "Spatial attention · 12 heads" }, { t: "attn", label: "Temporal attention" }, { t: "ffn", label: "Feed forward" }] },
          { t: "linear", label: "Prediction layer → latent aₜ (L2)" },
          { t: "mlp", label: "Low-level policy layers → u¹:³" },
          { t: "out", label: "latent, then robot actions", c: "data-3" } ],
          facts: [["Width / depth / heads", ["768 / 12 / 12", "p5"]], ["Pretraining", ["124K steps, batch 128, lr 1e-4", "p5"]], ["Low-level fine-tune", ["32K steps on 1 % of RT-1", "p4", "p5"]]] } },
      { id: "world", role: "world", name: "Open-Sora world model", sub: "3-D VAE + ST-RFT", col: 2, frozen: false, short: "World",
        stack: { rows: [
          { t: "in", label: "history frames, noisy future latent", c: "data-4" },
          { t: "conv", label: "3-D VAE encode (8 × 8, 4× time)" },
          { t: "attn", label: "ST-RFT with cross-attention to aₜ:T" },
          { t: "out", label: "velocity vθ → future frames", c: "data-4" } ],
          facts: [["Init", ["pre-trained Open-Sora", "p2"]], ["Action input", ["one token per frame via cross-attention", "p2"]], ["Training", ["48K steps, batch 12", "p5"]]] } }
    ],
    inputs: [
      { to: "lam", mod: "vision", label: "frames o₁:ₜ₊₁", n: "human + robot video", k: 4 },
      { to: "policy", mod: "vision", label: "frames o₁:ₜ", n: "DINOv2 patches", k: 4 },
      { to: "policy", mod: "lang", label: "instruction s", n: "CLIP text", k: 3 },
      { to: "world", mod: "future", label: "noisy video latent", n: "3-D VAE", k: 4, noisy: true }
    ],
    outputs: [
      { from: "lam", mod: "latent", label: "latent aₜ", n: "4 × 128", k: 4 },
      { from: "policy", mod: "action", label: "robot actions", n: "3 per latent", k: 3 },
      { from: "world", mod: "future", label: "future frames", n: "oₜ₊₁:T", k: 4 }
    ],
    links: [
      { from: "lam", to: "policy", kind: "two-stage", label: "latent labels|pseudo-actions" },
      { from: "policy", to: "world", kind: "cross-attn", label: "latent actions|1 token / frame" }
    ],
    callouts: [
      "No official code is released, so this diagram follows the paper alone; depth and width of the latent action model and the world model are not stated.",
      "IGOR's Eq. 1 puts clean data at n = 0 and noise at n = 1, the reverse of this site's convention (τ = 0 is noise).",
      "App. B.3 opens with \"The latent action model uses an ST-transformer…\" but then gives the <b>foundation policy's</b> 12 layers, 768 width and 12 heads; the site reads it as the policy."
    ]
  });

  /* ------------------------------------------------------------------ GO-1 (AgiBot World) */
  RB.arch.spec({
    id: "agibot-world-go-1", method: "agibot-world-go-1", name: "GO-1", year: 2025, parent: "lapa",
    diffRows: ["params", "vision", "backbone", "head", "output", "attention", "steps", "chunk"],
    figRef: "Bu et al. Fig. 4 · §IV · §V-A", prov: "agibot-world/GO-1 release config",
    lede: "InternVL2.5-2B reads three camera views and the instruction. A 24-layer latent planner attends to the VLM's keys and values layer by layer, and a 24-layer diffusion action expert attends to both to denoise a 30-step chunk.",
    sources: {
      p1: { kind: "paper", ref: "Bu et al. 2025 (AgiBot World), §IV-A–C and Fig. 4", url: "https://arxiv.org/abs/2503.06669" },
      p2: { kind: "paper", ref: "Bu et al. 2025, §V-A.2 (implementation details)", url: "https://arxiv.org/abs/2503.06669" },
      c1: { kind: "code", repo: "OpenDriveLab/AgiBot-World", path: "go1/internvl/model/go1/modeling_go1.py", commit: "98f136e", url: "https://github.com/OpenDriveLab/AgiBot-World/blob/98f136e/go1/internvl/model/go1/modeling_go1.py" },
      c2: { kind: "code", repo: "OpenDriveLab/AgiBot-World", path: "go1/internvl/model/go1/modeling_latent_action_expert.py", commit: "98f136e", url: "https://github.com/OpenDriveLab/AgiBot-World/blob/98f136e/go1/internvl/model/go1/modeling_latent_action_expert.py" },
      c3: { kind: "code", repo: "OpenDriveLab/AgiBot-World", path: "go1/configs/go1_base_cfg.py", commit: "98f136e", url: "https://github.com/OpenDriveLab/AgiBot-World/blob/98f136e/go1/configs/go1_base_cfg.py" },
      c4: { kind: "code", repo: "agibot-world/GO-1 (Hugging Face)", path: "config.json", commit: "0bc37be", url: "https://huggingface.co/agibot-world/GO-1/blob/0bc37be9caa20b5b3d4a569ec462409072d3e244/config.json" }
    },
    summary: {
      pattern: ["Latent-action pretraining", "p1"],
      params: ["InternVL2.5-2B backbone + latent planner + action expert", "p1"],
      vision: ["InternViT: 24 layers, width 1,024, 448 × 448, patch 14 → 256 tokens per view; head + 2 wrist views", "p1", "c1", "c4"],
      backbone: ["InternLM2 (InternVL2.5-2B): 24 layers, width 2,048, 16 heads, 8 KV heads", "p1", "c4"],
      head: ["Latent planner and action expert: 24 layers each, width 1,024, 16 heads, 8 KV heads", "p1", "c4"],
      output: ["Chunk of H = 30 actions (16-D in the released config)", "p1", "c4"],
      attention: ["Layer-wise: each expert layer attends to projected keys and values of the layer before it in the hierarchy", "p1", "c1", "c2"],
      cond: ["Denoising step and control frequency enter as two tokens; state via a 3-layer MLP", "c1", "c4"],
      steps: ["DDPM with 1,000 training steps; 5 DPM-Solver steps at inference; predicts the clean chunk", "c1", "c4"],
      chunk: ["H = 30", "p1", "c3"],
      rate: null, latency: null,
      train: ["LAM on web + human video, planner on latent labels, then joint with the expert; fine-tune 30,000 steps, batch 768, lr 2e-5", "p1", "p2"]
    },
    changes: [
      "Latent actions are <b>kept at inference</b>: a 24-layer latent planner sits between the VLM and the controller.",
      "A <b>diffusion action expert</b> outputs 30-step continuous chunks instead of a retrained token head.",
      "Backbone moves from LWM 7B to <b>InternVL2.5-2B</b> with three camera views.",
      "Experts read the VLM <b>layer by layer</b> through projected keys and values, as in π0.",
      "Pretraining adds the 1M-trajectory AgiBot World dataset to web and human video."
    ],
    blueprint: {
      headline: "GO-1: VLM, then latent plan, then actions",
      note: "Three towers run layer by layer: at each of the 24 layers the latent planner attends to that InternLM2 layer's keys and values (projected from head dim 128 to 64), and the action expert attends to the planner's cache, which already holds the VLM keys. The latent action model (Genie-style IDM/FDM, k = 4) only supplies training labels and is not in the release.",
      towers: [
        { mod: "vit", title: "InternViT", sub: "vision encoder, 3 views", compact: true,
          input: { label: "Image patches 14 × 14", caption: "448 × 448 per view" },
          rows: [
            { t: "embed", label: "Patch embedding", call: ["Width 1,024", "c4"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", note: "16 heads × 64 (release config)" },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "MLP (GELU)", call: ["Hidden 4,096", "c4"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Pixel shuffle + MLP", call: ["1,024 patches → 256 tokens → 2,048", "c1", "c4"],
              zoom: { k: "rows", title: "Pixel-shuffle projector", rows: ["32 × 32 patches of 1,024-d", "merge 2 × 2 → 16 × 16 of 4,096-d", "LayerNorm · Linear 4,096 → 2,048", "GELU · Linear 2,048 → 2,048"] } } ],
          output: { label: "256 tokens per view" } },
        { mod: "llm", title: "InternLM2", sub: "InternVL2.5-2B language model",
          input: { label: "Image tokens + instruction", caption: "3 × 256 image tokens, then ℓ" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["Vocab 92,553, width 2,048", "c4"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Causal GQA", side: "RoPE", call: ["16 heads, 8 KV heads, dim 128", "c4"], zoom: { k: "heads", q: 16, kv: 8, hd: 128, title: "Grouped-query attention (VLM)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden 8,192", "c4"], zoom: { k: "glu", act: "SiLU", d: "2,048", ff: "8,192", title: "Feed forward (VLM)" } },
              { t: "add", span: 2 } ] } ],
          output: { label: "K, V of all 24 layers" } },
        { mod: "planner", title: "Latent planner", sub: "24 × 1,024", compact: true,
          input: { label: "4 latent query tokens", caption: "constant −1 through an MLP" },
          rows: [
            { t: "mlp", label: "Input MLP 1 → 1,024", call: ["3 Linear + GELU", "c2"] },
            { t: "block", n: "24", rows: [
              { id: "kv1", t: "linear", label: "K, V proj 128 → 64", call: ["One pair per VLM layer", "c1"] },
              { t: "attn", label: "Attn over [VLM ‖ latents]", call: ["16 heads, 8 KV heads, dim 64", "c4"] },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden 2,048", "c4"] } ] },
            { t: "linear", label: "Latent head → 32 codes", call: ["k = 4 latent tokens", "p1", "c2", "c4"] } ],
          output: { label: "cache: VLM + latent K, V" } },
        { mod: "expert", title: "Action expert", sub: "diffusion, 24 × 1,024",
          input: { label: "State q + noisy chunk Aᵏ", caption: "+ denoising-step and frequency tokens" },
          rows: [
            { t: "mlp", label: "State / action MLPs → 1,024", call: ["3 Linear + GELU each, 16-D in", "c1", "c4"] },
            { t: "embed", label: "Step + freq. embeddings", call: ["Sinusoid 256 → MLP → 1,024", "c1"] },
            { t: "block", n: "24", rows: [
              { id: "kv2", t: "linear", label: "K, V proj from planner", call: ["64 → 64 per layer", "c2"] },
              { t: "attn", label: "Attn over [VLM ‖ z ‖ own]", call: ["16 heads, 8 KV heads, dim 64", "c4"], zoom: { k: "heads", q: 16, kv: 8, hd: 64, title: "Grouped-query attention (experts)" } },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden 4,096", "c4"], zoom: { k: "glu", act: "SiLU", d: "1,024", ff: "4,096", title: "Feed forward (action expert)" } } ] },
            { t: "linear", label: "Final layer: RMSNorm + MLP", call: ["1,024 → 16-D per step, 30 steps", "c2", "c4"] } ],
          output: { label: "clean-chunk estimate; 5 DPM-Solver steps" } }
      ],
      links: [
        { from: "vit", to: "llm", toRow: "input", label: "image tokens" },
        { from: "llm", to: "planner", toRow: "kv1", label: "layer-wise K, V" },
        { from: "planner", to: "expert", toRow: "kv2", label: "planner cache" }
      ]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "InternViT", sub: "24 × 1,024 · 448 px", col: 0, frozen: false, short: "InternViT",
        stack: { rows: [
          { t: "in", label: "head + left + right wrist, 448 × 448", c: "data-1" },
          { t: "embed", label: "Patch 14 × 14 → 1,024 patches" },
          { t: "block", label: "ViT block", n: "24", rows: [{ t: "attn", label: "MHA · 16 heads" }, { t: "ffn", label: "MLP 1,024 → 4,096 · GELU" }] },
          { t: "linear", label: "Pixel shuffle 0.5 → MLP → 2,048" },
          { t: "out", label: "256 tokens per view", c: "data-1" } ],
          facts: [["Width / depth / heads", ["1,024 / 24 / 16", "c4"]], ["Resolution", ["448 × 448, patch 14", "c4"]], ["Tokens per view", ["(448 / 14)² × 0.5² = 256", "c1", "c4"]]] } },
      { id: "llm", role: "vlm", name: "InternLM2 (InternVL2.5-2B)", sub: "24 × 2,048 · GQA 16/8", col: 1, frozen: false, main: true, short: "InternLM2",
        stack: { rows: [
          { t: "in", label: "[image tokens | instruction]", c: "data-2" },
          { t: "block", label: "Decoder block", n: "24", rows: [{ t: "norm", label: "RMSNorm" }, { t: "attn", label: "Causal GQA · 16 q / 8 kv · RoPE" }, { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 2,048 → 8,192" }] },
          { t: "out", label: "per-layer keys and values", c: "data-2" } ],
          facts: [["Width / depth", ["2,048 / 24", "c4"]], ["Heads", ["16 query, 8 KV, head dim 128", "c4"]], ["FFN", ["8,192", "c4"]], ["Vocab", ["92,553", "c4"]]] } },
      { id: "planner", role: "latent", roleLabel: "Latent planner", name: "Latent planner", sub: "24 × 1,024 · 32 codes", col: 2, frozen: false, short: "Planner",
        stack: { rows: [
          { t: "in", label: "4 latent query tokens", c: "data-7" },
          { t: "block", label: "Expert block", n: "24", rows: [{ t: "linear", label: "project VLM K, V 128 → 64" }, { t: "attn", label: "GQA over [VLM ‖ latent]" }, { t: "ffn", label: "SwiGLU 1,024 → 2,048" }] },
          { t: "linear", label: "score head → 32 classes" },
          { t: "out", label: "latent tokens z + cache", c: "data-7" } ],
          facts: [["Width / depth", ["1,024 / 24", "p1", "c4"]], ["Heads", ["16 query, 8 KV, dim 64", "c4"]], ["Latent tokens", ["k = 4", "p1", "c2"]], ["Codebook (release)", ["32", "c4"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert", sub: "24 × 1,024 · DDPM", col: 3, frozen: false, short: "Expert",
        stack: { rows: [
          { t: "in", label: "[step, freq, state, 30 noisy actions]", dims: "33 tokens", c: "data-3" },
          { t: "block", label: "Expert block", n: "24", rows: [{ t: "linear", label: "project planner K, V" }, { t: "attn", label: "GQA over [VLM ‖ z ‖ own]" }, { t: "ffn", label: "SwiGLU 1,024 → 4,096" }] },
          { t: "linear", label: "RMSNorm + MLP → 16-D" },
          { t: "out", label: "clean chunk estimate", dims: "30 × 16", c: "data-3" } ],
          facts: [["Width / depth", ["1,024 / 24", "p1", "c4"]], ["FFN", ["4,096", "c4"]], ["Tokens", ["3 conditioning + 30 actions", "c1", "c4"]], ["Sampler", ["DPM-Solver, 5 steps", "c1", "c4"]]] } }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "3 camera views", n: "256 tokens each", k: 5 },
      { to: "llm", mod: "lang", label: "instruction ℓ", n: "text", k: 3 },
      { to: "planner", mod: "latent", label: "4 latent queries", n: "k = 4", k: 4 },
      { to: "expert", mod: "state", label: "state q, step, freq", n: "3 tokens", k: 3 },
      { to: "expert", mod: "action", label: "noisy chunk Aᵏ", n: "H = 30", k: 5, noisy: true }
    ],
    outputs: [
      { from: "planner", mod: "latent", label: "latent plan z", n: "4 tokens", k: 4 },
      { from: "expert", mod: "action", label: "action chunk", n: "30 × 16", k: 5 }
    ],
    links: [
      { from: "vit", to: "llm", kind: "prefix", label: "pixel shuffle + MLP|256 tokens / view" },
      { from: "llm", to: "planner", kind: "joint-attn", label: "layer-wise K, V|128 → 64", note: "the planner reads each VLM layer's cache; the VLM never sees planner tokens" },
      { from: "planner", to: "expert", kind: "joint-attn", label: "layer-wise K, V|VLM + latents", note: "the expert reads the planner cache, which already contains the VLM keys" }
    ],
    mask: { name: "Hierarchical (block-causal)", ref: "p1", axes: [{ label: "images + text", short: "img+ℓ", mod: "vision" }, { label: "latent plan", short: "z", mod: "latent" }, { label: "state + actions", short: "A", mod: "action" }], m: ["100", "110", "111"],
      note: "Each expert is conditioned on the modules before it, never the reverse." },
    callouts: [
      "Paper §IV-C says the planner generates latent tokens by masked language modeling; in the released inference code it runs 4 placeholder tokens and hands its key–value cache to the expert without decoding them.",
      "The paper leaves the codebook size |C| open; the released config gives the planner a 32-way head (<code>vocab_size 32</code>).",
      "The action expert regresses the clean chunk (<code>prediction_type: sample</code>), not noise or velocity."
    ]
  });

  /* ------------------------------------------------------------------ UniVLA (Bu et al.) */
  RB.arch.spec({
    id: "univla-2", method: "univla-2", name: "UniVLA", year: 2025, parent: "igor",
    diffRows: ["params", "vision", "backbone", "head", "output", "cond", "train"],
    figRef: "Bu et al. Figs. 2–3 · §III", prov: "OpenDriveLab/UniVLA",
    lede: "A latent action model working in DINOv2 feature space learns 4 task-centric tokens per second of video. Prismatic-7B predicts them as new vocabulary tokens, and a 12.6M attention-pooling head decodes them into each robot's action chunk.",
    sources: {
      p1: { kind: "paper", ref: "Bu et al. 2025, §III-A (task-centric latent actions, Fig. 2)", url: "https://arxiv.org/abs/2505.06111" },
      p2: { kind: "paper", ref: "Bu et al. 2025, §III-B (generalist policy)", url: "https://arxiv.org/abs/2505.06111" },
      p3: { kind: "paper", ref: "Bu et al. 2025, §III-C (latent decoding, LoRA, history)", url: "https://arxiv.org/abs/2505.06111" },
      p4: { kind: "paper", ref: "Touvron et al. 2023a (LLaMA), Table 2", url: "https://arxiv.org/abs/2302.13971" },
      c1: { kind: "code", repo: "OpenDriveLab/UniVLA", path: "latent_action_model/config/lam-stage-2.yaml", commit: "0ab9e9d", url: "https://github.com/OpenDriveLab/UniVLA/blob/0ab9e9d/latent_action_model/config/lam-stage-2.yaml" },
      c2: { kind: "code", repo: "OpenDriveLab/UniVLA", path: "latent_action_model/genie/modules/lam.py", commit: "0ab9e9d", url: "https://github.com/OpenDriveLab/UniVLA/blob/0ab9e9d/latent_action_model/genie/modules/lam.py" },
      c3: { kind: "code", repo: "OpenDriveLab/UniVLA", path: "latent_action_model/genie/modules/blocks.py", commit: "0ab9e9d", url: "https://github.com/OpenDriveLab/UniVLA/blob/0ab9e9d/latent_action_model/genie/modules/blocks.py" },
      c4: { kind: "code", repo: "OpenDriveLab/UniVLA", path: "vla-scripts/finetune_libero.py", commit: "0ab9e9d", url: "https://github.com/OpenDriveLab/UniVLA/blob/0ab9e9d/vla-scripts/finetune_libero.py" },
      c5: { kind: "code", repo: "OpenDriveLab/UniVLA", path: "vla-scripts/train.py", commit: "0ab9e9d", url: "https://github.com/OpenDriveLab/UniVLA/blob/0ab9e9d/vla-scripts/train.py" },
      c6: { kind: "code", repo: "OpenDriveLab/UniVLA", path: "prismatic/models/backbones/vision/dinosiglip_vit.py", commit: "0ab9e9d", url: "https://github.com/OpenDriveLab/UniVLA/blob/0ab9e9d/prismatic/models/backbones/vision/dinosiglip_vit.py" }
    },
    summary: {
      pattern: ["Latent-action pretraining", "p1"],
      params: ["7B (Prismatic-7B); ~123M trainable in post-training incl. a 12.6M action head", "p2", "p3"],
      vision: ["Prismatic DINOv2 ‖ SigLIP fused patches of one third-person image", "p2", "c6"],
      backbone: ["Llama 2 7B: 32 layers, width 4,096, 32 heads", "p2", "p4"],
      head: ["Action decoder: 2 attention-pooling blocks (width 512, 8 heads) + Linear", "p3", "c4"],
      output: ["N = 4 latent tokens from |C| = 16; LIBERO head outputs 12 × 7 actions", "p2", "c4"],
      attention: ["LLM causal; latent model spatial + causal temporal", "p1", "c3"],
      cond: ["Instruction plus the previous step's 4 latent tokens as history", "p3"],
      steps: null,
      chunk: ["One latent spans ~1 s; LIBERO decoder window 12", "p1", "c4"],
      rate: null, latency: null,
      train: ["960 A100-hours pretraining (OXE, GNM, Ego4D); LoRA rank 32 post-training", "p2", "c4"]
    },
    changes: [
      "The latent model predicts <b>DINOv2 features</b>, not pixels, so texture and lighting drop out of the target.",
      "Latent learning has <b>two stages</b>: language-conditioned stage 1 absorbs task-irrelevant motion, stage 2 learns a new task-centric codebook.",
      "The policy is <b>Prismatic-7B</b> with 16 added &lt;ACT&gt; tokens, trained by next-token prediction.",
      "A small <b>attention-pooling decoder</b> maps latents to each robot's chunk; past latents return as history.",
      "No world model: the decoder of the latent model is used only for training."
    ],
    blueprint: {
      headline: "UniVLA: plan in DINO-space latent tokens",
      note: "The latent action model labels every clip with 4 task-centric tokens. Prismatic-7B learns to emit them after the image and instruction. For each robot, the decoder pools the last-layer visual states into one query, uses it to pool the 4 latent-token states, and projects to an action chunk.",
      towers: [
        { mod: "lam", title: "Latent action model", sub: "stage 2: task-centric", compact: true,
          input: { label: "DINOv2 of oₜ and oₜ₊ₖ", caption: "224 × 224, ~1 s apart" },
          rows: [
            { t: "embed", label: "Frozen DINOv2 ViT-B/14", call: ["256 × 768 patches", "c1", "c2"] },
            { t: "linear", label: "+ 4 action tokens (TI + TC)", note: "Stage 1 also appends T5-base instruction tokens (§III-A)" },
            { t: "block", n: "12", label: "encoder", rows: [
              { t: "attn", label: "Spatial attention", call: ["12 heads × 64 = 768", "c1"] },
              { t: "attn", label: "Causal temporal attn" },
              { t: "ffn", label: "MLP 768 → 3,072", call: ["GELU, pre-LayerNorm", "c3"] } ] },
            { t: "linear", label: "VQ: task-centric codebook", call: ["|C| = 16, 128-d, N = 4", "p2", "c1", "c2"],
              zoom: { k: "rows", title: "Two-stage decoupling (§III-A)", rows: ["stage 1: [Oₜ; Oₜ₊ₖ; a_TI; ℓ] → VQ", "decoder sees ℓ → a_TI = nuisance", "stage 2: freeze TI codes, drop ℓ", "new a_TC codebook = task-centric"] } },
            { t: "block", n: "12", label: "decoder", rows: [{ t: "attn", label: "Spatial attn over [z ‖ Oₜ]" }] },
            { t: "linear", label: "Linear → 768 DINO", call: ["Loss ‖Ôₜ₊ₖ − Oₜ₊ₖ‖²", "p1", "c2"] } ],
          output: { label: "4 latent tokens per ~1 s" } },
        { mod: "vlm", title: "Prismatic-7B", sub: "Llama 2 7B + DINOv2 ‖ SigLIP",
          input: { label: "Image tokens + instruction", caption: "+ last step's 4 latent tokens" },
          rows: [
            { t: "embed", label: "Tokens + 16 <ACT> tokens", call: ["Codebook index → <ACT_i>", "p2", "c5"] },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["32 heads, head dim 128", "p4"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Attention (Llama 2 7B)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["LoRA rank 32 in post-training", "c4"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { id: "lmhead", t: "linear", label: "LM head → 4 latent tokens", call: ["Cross-entropy on N = 4", "p2"] } ],
          output: { label: "last-layer states: image + latent" } },
        { mod: "dec", title: "Action decoder", sub: "attention pooling, 12.6M", compact: true,
          input: { label: "Last-layer hidden states", caption: "visual Eᵥ and latent Eₐ" },
          rows: [
            { t: "attn", label: "Pool visual → 1 token", call: ["MAP: width 512, 8 heads, from 4,096", "c4"] },
            { t: "attn", label: "Pool latents, query + visual", call: ["q = qₐ + E′ᵥ", "p3", "c4"],
              zoom: { k: "rows", title: "Latent decoding (§III-C)", rows: ["E′ᵥ = A(qᵥ, Eᵥ, Eᵥ)", "E′ₐ = A(qₐ + E′ᵥ, Eₐ, Eₐ)", "Linear E′ₐ → action chunk", "L1 loss + latent-token loss"] } },
            { t: "linear", label: "Linear 512 → 12 × 7 · tanh", call: ["LIBERO window 12", "c4"] } ],
          output: { label: "action chunk" } }
      ],
      links: [
        { from: "lam", to: "vlm", toRow: "lmhead", label: "latent labels" },
        { from: "vlm", to: "dec", toRow: "input", label: "hidden states" }
      ]
    },
    modules: [
      { id: "lam", role: "latent", roleLabel: "Latent action model", name: "DINO-space LAM", sub: "12 + 12 × 768 · 16 codes", col: 0, frozen: false, short: "LAM",
        stack: { rows: [
          { t: "in", label: "DINOv2 features of oₜ, oₜ₊ₖ", dims: "16 × 16 × 768", c: "data-1" },
          { t: "block", label: "ST-transformer encoder", n: "12", rows: [{ t: "attn", label: "Spatial MHA · 12 heads" }, { t: "attn", label: "Causal temporal MHA" }, { t: "ffn", label: "MLP 768 → 3,072" }] },
          { t: "linear", label: "action tokens → 128-d → VQ (16 codes)" },
          { t: "block", label: "Spatial decoder", n: "12", rows: [{ t: "attn", label: "Spatial MHA over [z ‖ Oₜ]" }] },
          { t: "out", label: "Ôₜ₊ₖ (DINO features)", c: "data-4" } ],
          facts: [["Width / heads", ["768 / 12", "c1"]], ["Depth", ["12 encoder + 12 decoder", "c1"]], ["Codebook", ["16 codes × 128-d, 4 tokens", "p2", "c1", "c2"]], ["Language", ["T5-base, stage 1 only", "p1", "c2"]], ["Frame gap", ["~1 s per dataset", "p1"]]] } },
      { id: "vlm", role: "vlm", name: "Prismatic-7B", sub: "32 × 4,096 · +16 tokens", col: 1, frozen: "lora", main: true, params: "7B", short: "Prismatic",
        stack: { rows: [
          { t: "in", label: "[image | instruction | history latents]", c: "data-2" },
          { t: "block", label: "Llama 2 block", n: "32", rows: [{ t: "attn", label: "Causal MHA · 32 heads · RoPE" }, { t: "ffn", label: "SwiGLU feed forward" }] },
          { t: "linear", label: "LM head over vocab + <ACT_1…16>" },
          { t: "out", label: "4 latent tokens", c: "data-7" } ],
          facts: [["Width / depth / heads", ["4,096 / 32 / 32", "p4"]], ["Latent vocab", ["16 added tokens", "p2", "c5"]], ["Post-training", ["LoRA rank 32, lr 3.5e-4 (LIBERO)", "c4"]], ["Pretraining", ["960 A100-hours", "p2"]]] } },
      { id: "dec", role: "action-head", name: "Attention-pool decoder", sub: "2 × MAP · 512 · 8 heads", col: 2, frozen: false, params: "12.6M", short: "Decoder",
        stack: { rows: [
          { t: "in", label: "Eᵥ (visual) and Eₐ (4 latent states)", dims: "4,096-d", c: "data-7" },
          { t: "attn", label: "MAP visual → 1 token (512)" },
          { t: "attn", label: "MAP latents with visual-initialised query" },
          { t: "linear", label: "Linear → window × 7" },
          { t: "out", label: "action chunk", c: "data-3" } ],
          facts: [["Size", ["12.6M (§III-C)", "p3"]], ["Width / heads", ["512 / 8", "c4"]], ["LIBERO window", ["12 actions", "c4"]], ["Loss", ["L1 on actions", "p3", "c4"]]] } }
    ],
    inputs: [
      { to: "lam", mod: "vision", label: "oₜ and oₜ₊ₖ", n: "~1 s apart", k: 4 },
      { to: "vlm", mod: "vision", label: "image", n: "3rd person", k: 4 },
      { to: "vlm", mod: "lang", label: "text + history", n: "4 latents", k: 3 }
    ],
    outputs: [
      { from: "lam", mod: "latent", label: "latent labels", n: "4 of 16 codes", k: 4 },
      { from: "dec", mod: "action", label: "action chunk", n: "12 × 7 (LIBERO)", k: 5 }
    ],
    links: [
      { from: "lam", to: "vlm", kind: "two-stage", label: "latent labels|4 tokens" },
      { from: "vlm", to: "dec", kind: "feeds", label: "last-layer states|visual + latent" }
    ],
    callouts: [
      "The paper gives two sizes for the decoder: §I says 10.8M parameters, §III-C says the action head has 12.6M.",
      "The released real-robot head also embeds proprioception (7 → 512) before the final Linear, and uses a 5-step window.",
      "In stage 2 the stage-1 codebook is frozen and language is dropped, so the new task-centric codes must carry what language used to explain."
    ]
  });

  /* ------------------------------------------------------------------ H-RDT */
  RB.arch.spec({
    id: "h-rdt", method: "h-rdt", name: "H-RDT", year: 2025, parent: "egomimic",
    diffRows: ["params", "vision", "backbone", "head", "output", "attention", "cond", "steps", "train"],
    figRef: "Bi et al. Fig. 2 · Method · App. B", prov: "HongzheBi/H_RDT",
    lede: "A 2B flow-matching diffusion transformer pretrained on EgoDex hand motion with a 48-D action vector. State and noisy actions form the sequence; image and language tokens enter by separate cross-attentions, and per-robot adapters are re-initialised for fine-tuning.",
    sources: {
      p1: { kind: "paper", ref: "Bi et al. 2025, Method (human action representation, two-stage training)", url: "https://arxiv.org/abs/2507.23523" },
      p2: { kind: "paper", ref: "Bi et al. 2025, H-RDT Architecture (Eqs. 1–5)", url: "https://arxiv.org/abs/2507.23523" },
      p3: { kind: "paper", ref: "Bi et al. 2025, App. B (Table 7, B.2, B.3)", url: "https://arxiv.org/abs/2507.23523" },
      c1: { kind: "code", repo: "HongzheBi/H_RDT", path: "configs/hrdt_finetune.yaml", commit: "8be02cb", url: "https://github.com/HongzheBi/H_RDT/blob/8be02cb/configs/hrdt_finetune.yaml" },
      c2: { kind: "code", repo: "HongzheBi/H_RDT", path: "models/hrdt/blocks.py", commit: "8be02cb", url: "https://github.com/HongzheBi/H_RDT/blob/8be02cb/models/hrdt/blocks.py" },
      c3: { kind: "code", repo: "HongzheBi/H_RDT", path: "models/hrdt/model.py", commit: "8be02cb", url: "https://github.com/HongzheBi/H_RDT/blob/8be02cb/models/hrdt/model.py" },
      c4: { kind: "code", repo: "HongzheBi/H_RDT", path: "models/hrdt_runner.py", commit: "8be02cb", url: "https://github.com/HongzheBi/H_RDT/blob/8be02cb/models/hrdt_runner.py" },
      c5: { kind: "code", repo: "HongzheBi/H_RDT", path: "models/encoder/dinosiglip_vit.py", commit: "8be02cb", url: "https://github.com/HongzheBi/H_RDT/blob/8be02cb/models/encoder/dinosiglip_vit.py" },
      c6: { kind: "code", repo: "HongzheBi/H_RDT", path: "train/train.py", commit: "8be02cb", url: "https://github.com/HongzheBi/H_RDT/blob/8be02cb/train/train.py" },
      c7: { kind: "code", repo: "HongzheBi/H_RDT", path: "models/hrdt/attention.py", commit: "8be02cb", url: "https://github.com/HongzheBi/H_RDT/blob/8be02cb/models/hrdt/attention.py" }
    },
    summary: {
      pattern: ["Diffusion transformer policy", "p2"],
      params: ["2B", "p1", "p3"],
      vision: ["DINOv2 ViT-L/14 ‖ SigLIP So400m/14 at 384 px; 1 camera (human) or up to 3 (robot)", "p2", "p3", "c5", "c6"],
      backbone: ["DiT: 16 blocks, width 2,176, 16 heads, 8 KV heads (GQA)", "p3", "c1"],
      head: ["Modular MLP action decoder with AdaLN; re-initialised per robot", "p1", "c2"],
      output: ["Velocity on a chunk of 16 actions (48-D human, 14-D bimanual robot)", "p1", "c1"],
      attention: ["Self-attention over [state ‖ actions]; separate cross-attention to image and to language", "p2", "c2"],
      cond: ["τ via AdaLN (shift, scale, gate) in every block", "p2", "c2"],
      steps: ["5 Euler steps, Δτ = 0.2, τ from 0 to 1", "p3", "c4"],
      chunk: ["16 actions", "c1"],
      rate: ["30 Hz control", "p3"],
      latency: null,
      train: ["EgoDex 338K+ trajectories (829 h), then robot fine-tuning; AdamW lr 1e-4", "p1", "p3"]
    },
    changes: [
      "Human data are <b>pretrained on alone</b> (EgoDex, 338K trajectories), then fine-tuned, instead of co-trained with paired robot data.",
      "Human actions are a <b>48-D hand vector</b> (wrist poses + fingertips), not poses shared with one robot.",
      "The policy is a <b>2B diffusion transformer</b> trained by flow matching, not an ACT CVAE.",
      "State and action adapters and the decoder are <b>re-initialised per robot</b>; the backbone transfers.",
      "Images go through DINOv2 + SigLIP and language through T5-XXL."
    ],
    blueprint: {
      headline: "H-RDT: human hands pretrain a robot DiT",
      note: "The state token and 16 noisy action tokens are the only self-attention sequence. Every block modulates three sub-layers from τ (AdaLN, 9 vectors), cross-attends to all image tokens and then to T5 tokens, and ends in SwiGLU. Only the adapters and the decoder change between the human and robot stages.",
      towers: [
        { mod: "enc", title: "Encoders + adapters", sub: "DINOv2 ‖ SigLIP · T5-XXL", compact: true,
          input: { label: "Images + instruction", caption: "384 px letterbox; ≤ 1,024 tokens" },
          rows: [
            { t: "attn", label: "DINOv2 ViT-L ‖ SigLIP So400m", call: ["2nd-to-last layer; 1,024 + 1,152", "c5", "c1"] },
            { t: "attn", label: "T5-XXL encoder", call: ["4,096-d tokens", "c1"] },
            { t: "mlp", label: "Image adapter (2-layer MLP)", call: ["2,176 → 2,176, SiLU", "p3", "c1"] },
            { t: "mlp", label: "Text adapter (2-layer MLP)", call: ["4,096 → 2,176", "p3", "c1"] } ],
          output: { label: "image tokens, language tokens" } },
        { mod: "dit", title: "H-RDT backbone", sub: "flow-matching DiT, 2B",
          input: { label: "State sₜ + noisy chunk Aτ", caption: "1 + 16 tokens at flow time τ" },
          rows: [
            { t: "mlp", label: "State + action adapters", call: ["3-layer MLP · SiLU, per robot", "p3", "c1"] },
            { t: "embed", label: "Time embedder", call: ["Sinusoid 256 → MLP → 2,176", "c2"] },
            { t: "block", n: "16", rows: [
              { t: "adaln", label: "AdaLN from τ (9 vectors)", side: "AdaLN", call: ["shift, scale, gate × 3", "c2"], zoom: { k: "rows", title: "AdaLN in an H-RDT block", rows: ["t_emb = MLP(sinusoid(τ)), 2,176-d", "SiLU → Linear → 9 × 2,176", "(shift, scale, gate) for self-attn", "same for image cross-attn and FFN"] } },
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "GQA self-attention", call: ["16 heads, 8 KV, dim 136; QK-RMSNorm", "c1", "c7"], zoom: { k: "heads", q: 16, kv: 8, hd: 136, title: "Grouped-query attention" } },
              { t: "add", span: 3 },
              { t: "attn", label: "Image cross-attention", call: ["Keys: all image tokens", "p2", "c2"] },
              { t: "add", span: 1 },
              { id: "xl", t: "attn", label: "Language cross-attention", call: ["Keys: T5 tokens, padding masked", "p2", "c2"] },
              { t: "add", span: 1 },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden 5,888", "c2", "c1"], zoom: { k: "glu", act: "SiLU", d: "2,176", ff: "5,888", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 1 } ] },
            { t: "mlp", label: "Action decoder: AdaLN + MLP", call: ["→ 14-D robot or 48-D human", "c1", "p3"],
              zoom: { k: "rows", title: "48-D human action (§Method)", rows: ["wrist position 3 × 2 hands", "wrist 6-D rotation × 2 hands", "5 fingertips × 3 × 2 hands", "18 + 30 = 48"] } } ],
          output: { label: "velocity vθ; 5 Euler steps" } }
      ],
      links: [{ from: "enc", to: "dit", toRow: "xl", label: "image + text tokens" }]
    },
    modules: [
      { id: "enc", role: "vision-enc", roleLabel: "Encoders", name: "DINOv2 ‖ SigLIP + T5-XXL", sub: "→ 2,176 via MLP adapters", col: 0, frozen: false, short: "Encoders",
        stack: { rows: [
          { t: "in", label: "1–3 camera images, 384 px", c: "data-1" },
          { t: "attn", label: "DINOv2 ViT-L/14 (reg4) ‖ SigLIP So400m/14" },
          { t: "mlp", label: "Image adapter: 2-layer MLP · SiLU" },
          { t: "attn", label: "T5-XXL instruction encoder (4,096-d)" },
          { t: "mlp", label: "Language adapter: 2-layer MLP · SiLU" },
          { t: "out", label: "image and language tokens", c: "data-2" } ],
          facts: [["Vision width", ["1,024 + 1,152 = 2,176", "c1", "c5"]], ["Text width", ["4,096 (T5-XXL)", "p2", "c1"]], ["Max text tokens", ["1,024", "p3", "c1"]], ["Adapters", ["shared between stages", "p1", "c1"]]] } },
      { id: "dit", role: "action-head", roleLabel: "Diffusion transformer", name: "H-RDT backbone", sub: "16 × 2,176 · GQA 16/8", col: 1, frozen: false, main: true, params: "2B", short: "DiT",
        stack: { rows: [
          { t: "in", label: "[state ‖ 16 noisy actions] + τ", c: "data-3" },
          { t: "mlp", label: "State / action adapters (3-layer MLP)" },
          { t: "block", label: "H-RDT block", n: "16", rows: [{ t: "adaln", label: "AdaLN from τ" }, { t: "attn", label: "GQA self-attn · QK-RMSNorm" }, { t: "attn", label: "cross-attn: image" }, { t: "attn", label: "cross-attn: language" }, { t: "ffn", label: "SwiGLU 2,176 → 5,888" }] },
          { t: "mlp", label: "Action decoder (AdaLN + MLP)" },
          { t: "out", label: "velocity vθ", dims: "16 × action dim", c: "data-3" } ],
          facts: [["Width / depth", ["2,176 / 16", "p3", "c1"]], ["Heads", ["16 query, 8 KV, head dim 136", "p3", "c1"]], ["FFN", ["SwiGLU, 5,888", "c2"]], ["Positions", ["fixed sin-cos per modality, no RoPE", "c3"]], ["τ sampling", ["uniform on [0, 0.999]", "p3", "c1"]]] } },
      { id: "dec", role: "action-head", roleLabel: "Per-robot decoder", name: "Modular action decoder", sub: "re-initialised per robot", col: 2, frozen: false, short: "Decoder",
        note: "Drawn inside the DiT tower in the Blueprint; separate here to show what is swapped per embodiment." }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "cameras", n: "1–3", k: 4 },
      { to: "enc", mod: "lang", label: "text ℓ", n: "T5", k: 3 },
      { to: "dit", mod: "state", label: "state sₜ", n: "1 token", k: 1 },
      { to: "dit", mod: "action", label: "noisy chunk Aτ, τ", n: "16 tokens", k: 5, noisy: true }
    ],
    outputs: [{ from: "dec", mod: "action", label: "velocity vθ", n: "16 × 14 (robot)", k: 5 }],
    links: [
      { from: "enc", to: "dit", kind: "cross-attn", label: "image + text|2 cross-attns / block" },
      { from: "dit", to: "dec", kind: "feeds", label: "action tokens|+ τ AdaLN" }
    ],
    callouts: [
      "The paper says the backbone uses RMSNorm; the released blocks use <b>LayerNorm</b> before each sub-layer and RMSNorm only on queries and keys.",
      "Eq. 2 regresses vθ onto z − a*, but with aτ = τa* + (1 − τ)z the path velocity is a* − z. The code trains on <code>action − noise</code> and integrates τ from 0 to 1, which matches this site's convention.",
      "App. B.2 says images use 196 patches, and the config keeps <code>num_patches: 196</code>; the training script builds the DINOv2/SigLIP pair at 384 px and sizes the image positions from it (27 × 27 = 729 patches per camera)."
    ]
  });

  /* ------------------------------------------------------------------ CLAP */
  RB.arch.spec({
    id: "clap", method: "clap", name: "CLAP", year: 2026, parent: "univla-2",
    diffRows: ["params", "vision", "backbone", "head", "output", "cond", "chunk", "train"],
    figRef: "Zhang et al. Figs. 3–4 · §III · Table IX", prov: "LinShan-Bin/OpenCLAP",
    lede: "Act-VAE turns robot action chunks into 8 tokens per arm; VD-VAE maps video transitions onto that codebook contrastively, so human clips get robot-grounded pseudo-tokens. Qwen3-VL-4B predicts subtask and tokens, and a rectified-flow DiT turns its hidden states into continuous chunks.",
    sources: {
      p1: { kind: "paper", ref: "Zhang et al. 2026, §III-C (Act-VAE, VD-VAE, Eqs. 2–4)", url: "https://arxiv.org/abs/2601.04061" },
      p2: { kind: "paper", ref: "Zhang et al. 2026, §III-D–E (CLAP-NTP, CLAP-RF, Knowledge Matching)", url: "https://arxiv.org/abs/2601.04061" },
      p3: { kind: "paper", ref: "Zhang et al. 2026, §IV and Table IX (training details)", url: "https://arxiv.org/abs/2601.04061" },
      p4: { kind: "paper", ref: "Zhang et al. 2026, §V-A and Table VIII (setup, latency)", url: "https://arxiv.org/abs/2601.04061" },
      c1: { kind: "code", repo: "LinShan-Bin/OpenCLAP", path: "clap/configs/clap-s2-l32.yaml", commit: "4883013", url: "https://github.com/LinShan-Bin/OpenCLAP/blob/4883013/clap/configs/clap-s2-l32.yaml" },
      c2: { kind: "code", repo: "LinShan-Bin/OpenCLAP", path: "clap/modules/clap.py", commit: "4883013", url: "https://github.com/LinShan-Bin/OpenCLAP/blob/4883013/clap/modules/clap.py" },
      c3: { kind: "code", repo: "LinShan-Bin/OpenCLAP", path: "clap/configs/clap-s1-l32.yaml", commit: "4883013", url: "https://github.com/LinShan-Bin/OpenCLAP/blob/4883013/clap/configs/clap-s1-l32.yaml" },
      c4: { kind: "code", repo: "LinShan-Bin/OpenCLAP", path: "examples/LIBERO/train_files/starvla_libero_clap_km_l16.yaml", commit: "4883013", url: "https://github.com/LinShan-Bin/OpenCLAP/blob/4883013/examples/LIBERO/train_files/starvla_libero_clap_km_l16.yaml" },
      c5: { kind: "code", repo: "LinShan-Bin/OpenCLAP", path: "starVLA/model/framework/VLM4A/QwenPI.py", commit: "4883013", url: "https://github.com/LinShan-Bin/OpenCLAP/blob/4883013/starVLA/model/framework/VLM4A/QwenPI.py" },
      c6: { kind: "code", repo: "LinShan-Bin/OpenCLAP", path: "starVLA/model/modules/action_model/LayerwiseFM_ActionHeader.py", commit: "4883013", url: "https://github.com/LinShan-Bin/OpenCLAP/blob/4883013/starVLA/model/modules/action_model/LayerwiseFM_ActionHeader.py" },
      c7: { kind: "code", repo: "Qwen/Qwen3-VL-4B-Instruct (Hugging Face)", path: "config.json", commit: "ebb281e", url: "https://huggingface.co/Qwen/Qwen3-VL-4B-Instruct/blob/ebb281ec70b05090aa6165b016eac8ec08e71b17/config.json" },
      c8: { kind: "code", repo: "LinShan-Bin/OpenCLAP", path: "examples/Astribot/train_files/starvla_astribot_qwenpikm.yaml", commit: "4883013", url: "https://github.com/LinShan-Bin/OpenCLAP/blob/4883013/examples/Astribot/train_files/starvla_astribot_qwenpikm.yaml" }
    },
    summary: {
      pattern: ["Latent-action pretraining", "p1"],
      params: ["4.5B (CLAP-NTP), 6.0B (CLAP-RF)", "p4"],
      vision: ["Qwen3-VL ViT: 24 layers, width 1,024, patch 16; head + 2 wrist cameras", "c7", "p4"],
      backbone: ["Qwen3-VL-4B: 36 layers, width 2,560, 32 heads, 8 KV heads", "p3", "c7"],
      head: ["CLAP-RF: DiT at width 2,560, one layer per selected VLM layer (16 on LIBERO)", "p2", "c4", "c5"],
      output: ["NTP: subtask text + 16 action tokens (8 per arm); RF: 32 × 14 chunk", "p3", "c8"],
      attention: ["Each DiT layer cross-attends to one VLM layer's hidden states", "p2", "c6"],
      cond: ["RF time from Beta(1.5, 1) as in π0; KM reverse-KL to frozen NTP, weight 0.005", "p3", "c6", "c8"],
      steps: ["4 Euler steps (released default)", "c5"],
      chunk: ["32 actions", "p3", "c8"],
      rate: null,
      latency: ["70.1 ms (RF) vs 382.0 ms (NTP) on one H100, one 224 × 224 image", "p4"],
      train: ["NTP 150,000 steps, batch 512 (~3,800 A100-h) on AgiBot, Astribot, DROID + Ego4D pseudo-labels", "p3"]
    },
    changes: [
      "The codebook comes from <b>robot actions</b> (Act-VAE), not from visual reconstruction alone.",
      "Video transitions are <b>aligned contrastively</b> (SigLIP loss) to Act-VAE codes; an EMA teacher gives targets for human clips.",
      "A separate <b>environment codebook</b> with an L1 penalty soaks up nuisance motion.",
      "Backbone switches to <b>Qwen3-VL-4B</b>, which also writes a subtask string.",
      "Deployment adds a <b>rectified-flow DiT</b> over VLM hidden states, kept near the NTP policy by Knowledge Matching."
    ],
    blueprint: {
      headline: "CLAP: robot-grounded tokens for human video",
      note: "Act-VAE is trained first and frozen. VD-VAE's inverse-dynamics encoder then quantizes video transitions with that frozen action codebook plus a small environment codebook, and a spatial decoder rebuilds DINOv3 features. Qwen3-VL-4B learns the tokens; the RF DiT reads 16 of its layers on LIBERO.",
      towers: [
        { mod: "tok", title: "Act-VAE + VD-VAE", sub: "action codebook, video aligner", compact: true,
          input: { label: "Actions; DINOv3 of oₜ, oₜ₊H", caption: "32 steps; frames 240 × 320" },
          rows: [
            { t: "attn", label: "Act-VAE encoder", call: ["15 layers, width 512, 4 heads", "p3", "c2"] },
            { t: "linear", label: "Action codebook C_act", call: ["8 codes per arm, 128-d", "p3", "c2"] },
            { t: "embed", label: "Frozen DINOv3 ViT-B/16", note: "768-d patch features (config clap-s2-l32, clap.py)" },
            { t: "block", n: "12", label: "IDM", rows: [{ t: "attn", label: "Spatial + causal temporal", call: ["Width 768, 12 heads", "c1"] }] },
            { t: "linear", label: "Quantize: C_act + C_env", call: ["2 environment codes, L1 penalty", "p3", "c2"],
              zoom: { k: "rows", title: "Contrastive alignment (Alg. 2)", rows: ["robot: z⁺ = sg(E_act(a))", "human: z⁺ from EMA teacher", "SigLIP loss on (z_v,a, z⁺)", "λ_con 0.1 · λ_reg 0.5"] } },
            { t: "block", n: "12", label: "FDM", rows: [{ t: "attn", label: "Spatial attention" }] },
            { t: "linear", label: "Predict f̂ₜ₊H (DINOv3)", call: ["MSE in feature space", "p1"] } ],
          output: { label: "action tokens ẑₐ for human video" } },
        { mod: "vlm", title: "Qwen3-VL-4B", sub: "CLAP-NTP policy",
          input: { label: "3 camera images + instruction", caption: "head camera and two wrists" },
          rows: [
            { t: "embed", label: "ViT + merger → tokens", call: ["24 layers, width 1,024, patch 16", "c7"] },
            { t: "embed", label: "Tokens + <ACT_*> tokens", call: ["Vocab 151,936 + codebook entries", "c7", "p3"] },
            { t: "block", n: "36", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Causal GQA", side: "RoPE", call: ["32 heads, 8 KV heads, dim 128", "c7"], zoom: { k: "heads", q: 32, kv: 8, hd: 128, title: "Grouped-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden 9,728", "c7"], zoom: { k: "glu", act: "SiLU", d: "2,560", ff: "9,728", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { id: "lm", t: "linear", label: "LM head: subtask + tokens", call: ["16 action tokens for two arms", "c8"] } ],
          output: { label: "hidden states of the chosen layers" } },
        { mod: "rf", title: "CLAP-RF expert", sub: "rectified-flow DiT", compact: true,
          input: { label: "Noisy chunk Aτ + state", caption: "32 × 14 at time τ" },
          rows: [
            { t: "mlp", label: "Action encoder (+ sinusoid τ)", call: ["3 Linear, width 2,560", "c6", "c5"] },
            { t: "block", n: "16", label: "LIBERO", rows: [
              { t: "adaln", label: "AdaNorm from τ", side: "AdaLN" },
              { id: "xa", t: "attn", label: "Cross-attn to VLM layer i", call: ["40 heads × 64 = 2,560", "c5", "c6"] },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "Decoder → velocity", call: ["4 Euler steps", "c5"] } ],
          output: { label: "velocity vθ, 32 × 14" } }
      ],
      links: [
        { from: "tok", to: "vlm", toRow: "lm", label: "token labels" },
        { from: "vlm", to: "rf", toRow: "xa", label: "layer-wise states" }
      ]
    },
    modules: [
      { id: "tok", role: "codec", roleLabel: "Action tokenizers", name: "Act-VAE + VD-VAE", sub: "150M + 200M · 8 codes / arm", col: 0, frozen: true, short: "Tokenizers",
        stack: { rows: [
          { t: "in", label: "robot chunk a (32 × 7 per arm); oₜ, oₜ₊H", c: "data-3" },
          { t: "attn", label: "Act-VAE: 15-layer transformer VQ-VAE" },
          { t: "linear", label: "C_act: 8 codes per arm, 128-d" },
          { t: "attn", label: "VD-VAE IDM: 12 ST blocks on DINOv3 features" },
          { t: "linear", label: "quantize with frozen C_act + C_env (2 codes)" },
          { t: "attn", label: "VD-VAE FDM: 12 spatial blocks → f̂ₜ₊H" },
          { t: "out", label: "tokens zₐ (robot) or ẑₐ (human)", c: "data-7" } ],
          facts: [["Act-VAE", ["15 / 15 layers, 150M", "p3"]], ["VD-VAE", ["12 / 12 layers, 200M, width 768", "p3", "c1"]], ["Contrastive loss", ["SigLIP (sigmoid), weight 0.1", "p1", "p3", "c1"]], ["Features", ["DINOv3 ViT-B/16", "p3", "c1"]]] } },
      { id: "vlm", role: "vlm", name: "Qwen3-VL-4B", sub: "36 × 2,560 · GQA 32/8", col: 1, frozen: false, main: true, params: "4.5B", short: "Qwen3-VL",
        stack: { rows: [
          { t: "in", label: "[3 images | instruction]", c: "data-2" },
          { t: "block", label: "Decoder block", n: "36", rows: [{ t: "attn", label: "Causal GQA · 32 q / 8 kv · RoPE" }, { t: "ffn", label: "SwiGLU 2,560 → 9,728" }] },
          { t: "linear", label: "LM head over vocab + action tokens" },
          { t: "out", label: "subtask + 16 action tokens", c: "data-7" } ],
          facts: [["Width / depth", ["2,560 / 36", "c7"]], ["Heads", ["32 query, 8 KV, dim 128", "c7"]], ["NTP training", ["150,000 steps, lr 5e-5 → 5e-6", "p3"]], ["Latency", ["382.0 ms (H100)", "p4"]]] } },
      { id: "rf", role: "action-expert", name: "CLAP-RF DiT", sub: "width 2,560 · 16 layers", col: 2, frozen: false, short: "RF head",
        stack: { rows: [
          { t: "in", label: "state + noisy chunk Aτ + τ", c: "data-3" },
          { t: "block", label: "DiT block", n: "16", rows: [{ t: "adaln", label: "AdaNorm from τ" }, { t: "attn", label: "cross-attn to VLM layer i" }, { t: "ffn", label: "feed forward" }] },
          { t: "linear", label: "decoder → 14-D velocity" },
          { t: "out", label: "vθ, 32 × 14", c: "data-3" } ],
          facts: [["Width / heads", ["2,560 / 40 (head dim 64)", "c5", "c6"]], ["Depth (LIBERO)", ["16, from VLM layers 0–6 and 8–24 even", "c4"]], ["Time sampling", ["Beta(1.5, 1), s = 0.999", "p3", "c6"]], ["Latency", ["70.1 ms (H100)", "p4"]]] } }
    ],
    inputs: [
      { to: "tok", mod: "action", label: "robot action chunk", n: "32 steps", k: 4 },
      { to: "tok", mod: "vision", label: "oₜ, oₜ₊H", n: "robot + human", k: 4 },
      { to: "vlm", mod: "vision", label: "3 camera views", n: "head + wrists", k: 5 },
      { to: "vlm", mod: "lang", label: "instruction ℓ", n: "text", k: 3 },
      { to: "rf", mod: "action", label: "noisy chunk Aτ, τ", n: "32 × 14", k: 5, noisy: true }
    ],
    outputs: [
      { from: "tok", mod: "latent", label: "pseudo-tokens ẑₐ", n: "for human clips", k: 4 },
      { from: "vlm", mod: "latent", label: "subtask + tokens", n: "16 tokens", k: 4 },
      { from: "rf", mod: "action", label: "velocity vθ", n: "32 × 14", k: 5 }
    ],
    links: [
      { from: "tok", to: "vlm", kind: "two-stage", label: "action tokens|8 per arm" },
      { from: "vlm", to: "rf", kind: "cross-attn", label: "layer-wise states|16 VLM layers" }
    ],
    callouts: [
      "Paper Table IX lists the Act-VAE codebook as [256, 128] and 100,000 training steps; the released configs and checkpoints use <b>512 codes</b> of 128-d and set 50,000 steps.",
      "§IV-C says the RF expert is shallower than the VLM and reads early and middle layers. The LIBERO config does this (16 DiT layers from VLM layers 0–6 and even layers 8–24); the Astribot config leaves the depth unset, which defaults to one DiT layer per VLM layer (36).",
      "In the released layer-wise path every DiT block cross-attends to its VLM layer; the code notes that the interleaved self-attention is skipped."
    ]
  });
})();
