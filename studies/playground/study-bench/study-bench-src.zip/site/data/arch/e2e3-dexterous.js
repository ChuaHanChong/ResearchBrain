/* Architecture specs, topics E2 (dexterous hands) and E3 (deformables and mobile / whole-body manipulation).
   Numbers from the papers and the official code; see sources. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ E2 · DAPG ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "dapg", method: "dapg", name: "DAPG", year: 2017,
    figRef: "Rajeswaran et al. §III–IV", prov: "released relocate-v0 config",
    lede: "A small Gaussian MLP policy for the simulated ADROIT hand. It is first behaviour-cloned from 25 VR demonstrations, then fine-tuned with natural policy gradient plus a decaying demonstration term.",
    sources: {
      p1: { kind: "paper", ref: "Rajeswaran et al. 2018, §III (tasks, ADROIT, demos)", url: "https://arxiv.org/abs/1709.10087" },
      p2: { kind: "paper", ref: "Rajeswaran et al. 2018, §IV (NPG, DAPG, λ₀ and λ₁)", url: "https://arxiv.org/abs/1709.10087" },
      c1: { kind: "code", repo: "aravindr93/hand_dapg", path: "dapg/examples/dapg.txt", commit: "9a1de23", url: "https://github.com/aravindr93/hand_dapg/blob/9a1de23/dapg/examples/dapg.txt" },
      c2: { kind: "code", repo: "aravindr93/mjrl", path: "mjrl/policies/gaussian_mlp.py", commit: "3871d93", url: "https://github.com/aravindr93/mjrl/blob/3871d93/mjrl/policies/gaussian_mlp.py" },
      c3: { kind: "code", repo: "aravindr93/mjrl", path: "mjrl/utils/fc_network.py", commit: "3871d93", url: "https://github.com/aravindr93/mjrl/blob/3871d93/mjrl/utils/fc_network.py" },
      c4: { kind: "code", repo: "aravindr93/mjrl", path: "mjrl/baselines/mlp_baseline.py", commit: "3871d93", url: "https://github.com/aravindr93/mjrl/blob/3871d93/mjrl/baselines/mlp_baseline.py" }
    },
    summary: {
      pattern: ["Actor–critic", "p2"],
      params: null,
      vision: ["None: low-dimensional state (hand joint angles, object and target poses)", "p1"],
      backbone: ["Policy MLP, hidden sizes (32, 32), tanh (released config)", "c1", "c3"],
      head: ["Gaussian: linear mean per actuator + learned state-independent log σ", "c2"],
      output: ["Desired joint positions of the 24-DoF ADROIT hand (position control)", "p1"],
      attention: "None (MLP)",
      cond: "None",
      chunk: "One action per step (no chunking)",
      train: ["25 VR demos per task → behaviour cloning → NPG with an augmented demo gradient", "p1", "p2"]
    },
    blueprint: {
      headline: "DAPG: tiny MLP, big gradient trick",
      note: "The network is deliberately small: a two-layer tanh MLP maps the state to the means of a Gaussian over joint targets. What makes DAPG work is the training signal: behaviour cloning initialises it, and every NPG step adds a demonstration log-likelihood term whose weight decays by λ₁ each iteration. The value baseline is a separate MLP used only to compute advantages.",
      towers: [
        { mod: "policy", title: "Gaussian MLP policy", sub: "πθ(a | s), trained by BC then NPG",
          input: { label: "State sₜ", caption: "hand joints, object and target poses" },
          rows: [
            { t: "norm", label: "Input shift and scale", call: ["Shift and scale set from demo statistics", "c1", "c3"] },
            { t: "block", n: "2", rows: [
              { t: "linear", label: "Fully connected layer", call: ["Hidden sizes (32, 32)", "c1"] },
              { t: "mlp", label: "tanh activation" } ] },
            { t: "linear", label: "Linear → action means μ", call: ["One mean per actuator; last layer scaled ×0.01", "c2"] },
            { t: "mlp", label: "Sample a = μ + σ ⊙ ε", side: "log σ", call: ["Learned log σ, clamped at −3", "c2"], zoom: { k: "rows", title: "DAPG update", rows: ["BC init: max Σ log π(a|s) on demos", "Roll out, estimate Â with baseline", "g = Σ∇log π·Â + Σ_demo ∇log π·w", "w = λ₀ λ₁ᵏ · max Â (decays)", "NPG: θ += √(δ / gᵀF⁻¹g) · F⁻¹g"] } } ],
          output: { label: "desired joint positions" } },
        { mod: "critic", title: "Value baseline", sub: "MLP, train-time only", compact: true,
          input: { label: "State + time features", caption: "used to compute advantages Â" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "linear", label: "Linear · ReLU", call: ["Hidden (128, 128); input = obs + 4 features", "c4"] }] },
            { t: "linear", label: "Linear → V(s)" } ],
          output: { label: "baseline V(s)" } }
      ],
      links: [{ from: "critic", to: "policy", toRow: "input", label: "advantages Â" }]
    },
    modules: [
      { id: "critic", role: "critic", roleLabel: "Value baseline", name: "MLP baseline", sub: "2 × 128 · ReLU", col: 0, frozen: false, short: "Baseline",
        stack: { rows: [
          { t: "in", label: "state + time features", dims: "obs dim + 4", c: "data-4" },
          { t: "linear", label: "Linear → 128 · ReLU" }, { t: "linear", label: "Linear → 128 · ReLU" },
          { t: "linear", label: "Linear → 1" },
          { t: "out", label: "V(s) for GAE", dims: "train-time only", c: "data-4" } ],
          facts: [["Hidden", ["(128, 128), ReLU", "c4"]], ["Fit", ["Adam, 2 epochs per iteration, batch 64", "c1"]], ["GAE", ["γ = 0.995, λ = 0.97", "c1"]]] } },
      { id: "policy", role: "action-head", roleLabel: "Gaussian policy", name: "Gaussian MLP policy", sub: "2 × 32 · tanh", col: 1, frozen: false, main: true, short: "Policy",
        stack: { rows: [
          { t: "in", label: "state sₜ", dims: "joint angles, object and target poses", c: "data-4" },
          { t: "norm", label: "Input shift / scale (from BC data)" },
          { t: "block", label: "Hidden layer", n: "2", rows: [{ t: "linear", label: "Linear → 32" }, { t: "mlp", label: "tanh" }] },
          { t: "linear", label: "Linear → action means", dims: "output shift / scale from demos" },
          { t: "mlp", label: "+ exp(log σ) ⊙ ε", note: "log σ is a free parameter per action dimension" },
          { t: "out", label: "desired joint positions", dims: "ADROIT position actuators", c: "data-3" } ],
          facts: [["Hidden sizes", ["(32, 32), tanh", "c1", "c3"]], ["log σ", ["learned, clamped at −3", "c2"]], ["BC", ["5 epochs, batch 32, lr 1e-3", "c1"]], ["NPG", ["step δ = 0.05, 200 trajectories / iteration", "c1"]], ["Demo weight", ["λ₀ = 0.1, λ₁ = 0.95 (paper)", "p2"]]] } }
    ],
    inputs: [
      { to: "policy", mod: "state", label: "hand, object, target state", n: "1 vector", k: 2 },
      { to: "critic", mod: "state", label: "same state + time", n: "1 vector", k: 2 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint position targets", n: "1 step", k: 2 }],
    links: [{ from: "critic", to: "policy", kind: "feeds", label: "advantages Â|train-time only", note: "the baseline only shapes the policy gradient" }],
    callouts: [
      "Paper §IV-C uses <b>λ₀ = 0.1, λ₁ = 0.95</b> for all experiments; the released relocate config (dapg.txt) sets lam_0 = 1e-2.",
      "The paper does not state the network size; the (32, 32) tanh MLP comes from the released configs."
    ]
  });

  /* ------------------------------------------------------------------ E2 · PDDM ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "pddm", method: "pddm", name: "PDDM", year: 2019,
    figRef: "Nagabandi et al. §3 · App. B, Tables 1–2", prov: "Baoding balls",
    lede: "Model-based RL for a 24-DoF hand: an ensemble of small MLPs predicts state deltas, and a filtered MPPI planner scores hundreds of 7-step action sequences through it every control step.",
    sources: {
      p1: { kind: "paper", ref: "Nagabandi et al. 2019, §3 (model, planner)", url: "https://arxiv.org/abs/1909.11652" },
      p2: { kind: "paper", ref: "Nagabandi et al. 2019, App. B, Tables 1–2", url: "https://arxiv.org/abs/1909.11652" },
      p3: { kind: "paper", ref: "Nagabandi et al. 2019, §4.4 and App. C (real hand, tracker)", url: "https://arxiv.org/abs/1909.11652" },
      p4: { kind: "paper", ref: "Nagabandi et al. 2019, §4.3 (Baoding result)", url: "https://arxiv.org/abs/1909.11652" },
      c1: { kind: "code", repo: "google-research/pddm", path: "pddm/config/baoding.txt", commit: "06b88cd", url: "https://github.com/google-research/pddm/blob/06b88cd/pddm/config/baoding.txt" },
      c2: { kind: "code", repo: "google-research/pddm", path: "pddm/regressors/feedforward_network.py", commit: "06b88cd", url: "https://github.com/google-research/pddm/blob/06b88cd/pddm/regressors/feedforward_network.py" },
      c3: { kind: "code", repo: "google-research/pddm", path: "pddm/regressors/dynamics_model.py", commit: "06b88cd", url: "https://github.com/google-research/pddm/blob/06b88cd/pddm/regressors/dynamics_model.py" }
    },
    summary: {
      pattern: ["Dynamics-model ensemble + MPC planner", "p1"],
      params: null,
      vision: ["None in sim; real Baoding uses a stereo dilated-CNN ball tracker (280 × 180 pairs)", "p3"],
      backbone: ["Ensemble of E = 3 MLPs, 2 hidden layers × 500, ReLU (paper)", "p2"],
      head: ["Linear output Δs; ŝₜ₊₁ = ŝₜ + f(ŝₜ, aₜ), MSE loss", "p1", "p2"],
      output: ["First action of an H = 7 plan: 24-D hand joint targets in [−1, 1]", "p2"],
      attention: "None (MLP)",
      cond: "Planner: MPPI with filtered noise (β) and reward weighting (γ)",
      steps: ["N = 700 sampled sequences × H = 7 steps per control step (Baoding)", "p2"],
      rate: ["10 Hz planner, 1 kHz low-level position control (real hand)", "p3"],
      latency: ["Tracker ≈20 ms (capture + inference)", "p3"],
      train: ["Baoding sim: 100,000 transitions (≈2.7 h); real hand: <4 h of real data", "p4", "p3"]
    },
    blueprint: {
      headline: "PDDM: plan through a learned ensemble",
      note: "No policy network: the planner proposes N smooth action sequences, the three dynamics MLPs roll each one forward H steps, and the reward-weighted mean becomes the new plan. Only the first action is executed; the loop repeats at 10 Hz on the real hand, where a stereo CNN supplies ball positions.",
      towers: [
        { mod: "tracker", title: "Ball tracker", sub: "real hand only", compact: true,
          input: { label: "Stereo RGB pair", caption: "280 × 180, 12 cm baseline" },
          rows: [
            { t: "conv", label: "Dilated CNN (KeypointNet)", call: ["Sim-trained, fine-tuned on ≈10,000 images", "p3"] },
            { t: "pool", label: "Spatial softmax: 2-D + depth" },
            { t: "linear", label: "Pinhole → 3-D ball centres", call: ["≈5 mm error, ≈20 ms latency", "p3"] } ],
          output: { label: "ball positions in state s" } },
        { mod: "planner", title: "Filtered MPPI", sub: "no learned weights", compact: true,
          input: { label: "Current plan μ₀…μ₆", caption: "shifted from the last step" },
          rows: [
            { t: "mlp", label: "Sample filtered noise", call: ["N = 700, β = 0.7 (Baoding)", "p2"], zoom: { k: "rows", title: "Filtered MPPI", rows: ["uₜ ~ N(0, Σ)", "nₜ = β·uₜ + (1 − β)·nₜ₋₁", "aₜ = μₜ + nₜ for N sequences", "Rₖ = ensemble-mean reward", "μₜ = Σ e^{γRₖ} aₖ / Σ e^{γRₖ}"] } },
            { id: "roll", t: "linear", label: "Roll out through ensemble" },
            { t: "mlp", label: "Reward-weighted mean", call: ["γ = 20 for Baoding", "p2"] } ],
          output: { label: "execute a₀, replan" } },
        { mod: "dyn", title: "Dynamics MLP (×3)", sub: "f(s, a) → Δs, bootstrap ensemble",
          input: { label: "[ŝₜ ‖ aₜ]", caption: "normalised state and action" },
          rows: [
            { t: "norm", label: "Normalise (dataset stats)" },
            { t: "block", n: "2", rows: [
              { t: "linear", label: "Fully connected layer", call: ["500 units (paper)", "p2"] },
              { t: "mlp", label: "ReLU" } ] },
            { t: "linear", label: "Linear → Δs", call: ["Adam lr 1e-3, MSE, batch 500", "p2"], zoom: { k: "rows", title: "One ensemble member", rows: ["[s ‖ a], normalised", "Linear → 500 · ReLU", "Linear → 500 · ReLU", "Linear → Δs, un-normalise"] } },
            { t: "add", span: 3 } ],
          output: { label: "ŝₜ₊₁; repeat H = 7 times" } }
      ],
      links: [
        { from: "tracker", to: "planner", toRow: "input", label: "ball positions" },
        { from: "planner", to: "dyn", toRow: "input", label: "N × H action samples" }
      ]
    },
    modules: [
      { id: "tracker", role: "vision-enc", name: "Stereo ball tracker", sub: "dilated CNN · real only", col: 0, frozen: true, short: "Tracker",
        stack: { rows: [
          { t: "in", label: "RGB stereo pair", dims: "280 × 180, 12 cm baseline", c: "data-1" },
          { t: "conv", label: "Dilated CNN (KeypointNet-style)" },
          { t: "pool", label: "Spatial softmax → 2-D location + depth per ball" },
          { t: "linear", label: "Pinhole + calibration → hand frame" },
          { t: "out", label: "3-D ball centres", dims: "joins the planner's state", c: "data-1" } ],
          facts: [["Input", ["280 × 180 RGB stereo pair", "p3"]], ["Training", ["sim, then fine-tuned; ≈100 hand-labelled images, >10,000 total", "p3"]], ["Error / latency", ["≈5 mm, ≈20 ms", "p3"]]] } },
      { id: "planner", role: "planner", roleLabel: "MPC planner", name: "Filtered MPPI", sub: "N = 700 · H = 7", col: 1, frozen: false, short: "MPPI",
        stack: { rows: [
          { t: "in", label: "mean plan μ", dims: "H × action dim", c: "data-3" },
          { t: "mlp", label: "Filtered Gaussian noise (β)" },
          { t: "linear", label: "Predict rewards with each model, average" },
          { t: "mlp", label: "Softmax(γ · R) weighted mean" },
          { t: "out", label: "execute first action", dims: "MPC, replan every step", c: "data-3" } ],
          facts: [["Horizon H", ["7", "p2"]], ["Samples N", ["700 (Baoding)", "p2"]], ["γ / β", ["20 / 0.7 (Baoding, paper)", "p2"]], ["Control dt", ["0.1 s", "p2"]]] } },
      { id: "dyn", role: "world", roleLabel: "Dynamics model", name: "MLP ensemble", sub: "E = 3 · 2 × 500 ReLU", col: 2, frozen: false, main: true, short: "Dynamics",
        stack: { rows: [
          { t: "in", label: "[ŝₜ ‖ aₜ]", dims: "Baoding: 40-D state, 24-D action", c: "data-4" },
          { t: "norm", label: "Normalise inputs" },
          { t: "block", label: "Hidden layer", n: "2", rows: [{ t: "linear", label: "Linear → 500" }, { t: "mlp", label: "ReLU" }] },
          { t: "linear", label: "Linear → Δs" },
          { t: "add", label: "ŝₜ₊₁ = ŝₜ + Δs", span: 3 },
          { t: "out", label: "next-state prediction", dims: "rolled out H steps", c: "data-4" } ],
          facts: [["Members", ["E = 3, random init, different batches", "p1", "p2"]], ["Width", ["2 × 500 (paper); 2 × 250 (released config)", "p2", "c1"]], ["Loss", ["MSE, Adam 1e-3", "p2"]], ["State / action", ["40-D / 24-D (Baoding)", "p2"]]] } }
    ],
    inputs: [
      { to: "tracker", mod: "vision", label: "stereo RGB", n: "280 × 180", k: 2 },
      { to: "planner", mod: "state", label: "state sₜ", n: "40-D", k: 2 },
      { to: "dyn", mod: "action", label: "candidate actions", n: "700 × 7", k: 5 }
    ],
    outputs: [{ from: "planner", mod: "action", label: "first action a₀", n: "24-D", k: 2 }],
    links: [
      { from: "tracker", to: "planner", kind: "feeds", label: "ball positions|(real hand)" },
      { from: "planner", to: "dyn", kind: "feeds", label: "N sequences|H steps", note: "each sequence is rolled through every ensemble member" }
    ],
    callouts: [
      "Paper App. B: 2 hidden layers of <b>500</b>, batch 500; the released baoding.txt uses depth_fc_layers = <b>250</b> and batchsize 512.",
      "Paper Table 1 lists <b>β = 0.7</b> for Baoding; the released config sets mppi_beta = 0.6."
    ]
  });

  /* ------------------------------------------------------------------ E2 · Dactyl ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "learning-dexterous-in-hand-manipulation", method: "learning-dexterous-in-hand-manipulation", name: "Dactyl (OpenAI)", year: 2018,
    figRef: "OpenAI Fig. 6, 12 · Tables 2, 10, 12", prov: "block reorientation",
    lede: "An LSTM policy trained with large-scale PPO in randomised simulation, plus a three-camera CNN that estimates the block pose from rendered images. The critic has the same shape but sees privileged state.",
    sources: {
      p1: { kind: "paper", ref: "OpenAI 2018, §4.1–4.2, Table 2", url: "https://arxiv.org/abs/1808.00177" },
      p2: { kind: "paper", ref: "OpenAI 2018, App. D.1, Fig. 12, Table 10", url: "https://arxiv.org/abs/1808.00177" },
      p3: { kind: "paper", ref: "OpenAI 2018, §5.1, Fig. 6, Tables 11–12", url: "https://arxiv.org/abs/1808.00177" },
      p4: { kind: "paper", ref: "OpenAI 2018, App. B.3–B.4, C.1", url: "https://arxiv.org/abs/1808.00177" },
      p5: { kind: "paper", ref: "OpenAI 2018, §6.3–6.4", url: "https://arxiv.org/abs/1808.00177" }
    },
    summary: {
      pattern: ["Actor–critic", "p1"],
      params: null,
      vision: ["3 RGB cameras, 200 × 200 crops, shared-weight CNN → position + quaternion", "p3"],
      backbone: ["Policy: input normalisation → dense 1,024 ReLU → LSTM 512", "p2"],
      head: ["Categorical, 11 bins for each of 20 action coordinates", "p1", "p4"],
      output: ["Relative joint targets for 20 actuators, EMA-smoothed (0.3 per 80 ms)", "p4"],
      attention: "None (LSTM memory)",
      cond: "Goal enters as the noisy relative target orientation (quaternion)",
      rate: ["One action per 80 ms (12.5 Hz); PD loop every 5 ms", "p4"],
      latency: ["≈25 ms policy inference on a GPU", "p4"],
      train: ["PPO on Rapid: 8 V100s + 6,144 CPU cores; ≈100 years of experience with all randomisations", "p2", "p5"]
    },
    blueprint: {
      headline: "Dactyl: memory beats randomisation",
      note: "Three identical CNN stacks turn camera images into one pose estimate, which replaces the motion-capture object pose at deployment. The policy is a single dense layer feeding an LSTM, so it can infer the randomised physics of the current episode from its own history. The value network repeats the same shape with separate weights and a privileged input.",
      towers: [
        { mod: "vision", title: "Pose CNN", sub: "×3 cameras, shared weights", compact: true,
          input: { label: "RGB 200 × 200", caption: "one of 3 Basler cameras" },
          rows: [
            { t: "conv", label: "Conv 5×5 → Conv 3×3", call: ["32 filters each, stride 1", "p3"] },
            { t: "pool", label: "Max pool 3×3, stride 3" },
            { t: "conv", label: "ResNet stages (7 blocks)", call: ["16 → 32 → 64 → 64 filters", "p3"], zoom: { k: "rows", title: "Pose CNN stack", rows: ["Conv 5×5 · 32, Conv 3×3 · 32", "Max pool 3×3, stride 3", "ResNet 1 × 16, then 2 × 32", "ResNet 2 × 64, then 2 × 64", "Spatial softmax per camera"] } },
            { t: "pool", label: "Spatial softmax" },
            { t: "linear", label: "Concat 3 views → FC", call: ["FC 128 → 7 (3 pos + 4 quat)", "p3"] } ],
          output: { label: "object pose estimate" } },
        { mod: "policy", title: "LSTM policy", sub: "PPO actor",
          input: { label: "Observation oₜ", caption: "fingertips 15-D, object pos, rel. goal" },
          rows: [
            { t: "norm", label: "Running mean / std, clip", call: ["Clipped to ±5 standard deviations", "p2"] },
            { t: "linear", label: "Dense layer · ReLU", call: ["1,024 units", "p2"] },
            { t: "ffn", label: "LSTM (state hₜ)", call: ["LSTM size 512", "p2"], zoom: { k: "rows", title: "LSTM cell", rows: ["[xₜ ‖ hₜ₋₁]", "Gates i, f, o (σ) and g (tanh)", "cₜ = f ⊙ cₜ₋₁ + i ⊙ g", "hₜ = o ⊙ tanh(cₜ)"] } },
            { t: "linear", label: "Linear → per-joint logits", call: ["20 coordinates × 11 bins", "p1", "p4"] } ],
          output: { label: "relative joint targets → EMA" } },
        { mod: "critic", title: "LSTM value net", sub: "privileged input", compact: true,
          input: { label: "Privileged state", caption: "noiseless, adds velocities" },
          rows: [
            { t: "norm", label: "Running mean / std" },
            { t: "linear", label: "Dense layer · ReLU", call: ["Same shape as the policy", "p2"] },
            { t: "ffn", label: "LSTM" },
            { t: "linear", label: "Linear → V(s)" } ],
          output: { label: "value for PPO" } }
      ],
      links: [{ from: "vision", to: "policy", toRow: "input", label: "object pose" }]
    },
    modules: [
      { id: "vision", role: "vision-enc", name: "Pose CNN", sub: "3 views · ResNet · SSM", col: 0, frozen: true, short: "Pose CNN",
        stack: { rows: [
          { t: "in", label: "RGB image per camera", dims: "200 × 200 × 3", c: "data-1" },
          { t: "conv", label: "Conv2D 32 · 5×5, Conv2D 32 · 3×3", dims: "stride 1, no padding" },
          { t: "pool", label: "Max pool 3×3, stride 3" },
          { t: "group", label: "ResNet stages, stride 3", rows: [
            { t: "conv", label: "1 block · 16 filters" }, { t: "conv", label: "2 blocks · 32 filters" },
            { t: "conv", label: "2 blocks · 64 filters" }, { t: "conv", label: "2 blocks · 64 filters" } ] },
          { t: "pool", label: "Spatial softmax, flatten" },
          { t: "linear", label: "Concat 3 towers → FC 128 → 7" },
          { t: "out", label: "position (3) + quaternion (4)", dims: "fed to the policy", c: "data-1" } ],
          facts: [["Cameras", ["3 Basler, 640 × 480, ≈50 cm away", "p4"]], ["Input", ["200 × 200 RGB", "p3"]], ["Training", ["synthetic renders only, 400,000 batches of 192 images", "p3"]], ["Head", ["FC 128 → 3 position + 4 rotation", "p3"]]] } },
      { id: "policy", role: "action-head", roleLabel: "LSTM policy", name: "Policy network", sub: "dense 1024 → LSTM 512", col: 1, frozen: false, main: true, short: "Policy",
        stack: { rows: [
          { t: "in", label: "fingertips, object position, relative goal", dims: "15 + 3 + 4 D", c: "data-4" },
          { t: "norm", label: "Normalise (running stats), clip ±5σ" },
          { t: "linear", label: "Dense 1,024 · ReLU" },
          { t: "ffn", label: "LSTM 512", note: "memory lets the policy identify the randomised dynamics" },
          { t: "linear", label: "Linear → 20 × 11 logits" },
          { t: "out", label: "relative joint targets", dims: "EMA-smoothed, PD every 5 ms", c: "data-3" } ],
          facts: [["Dense", ["1,024, ReLU", "p2"]], ["LSTM", ["512", "p2"]], ["Actions", ["20 coordinates × 11 bins, relative targets", "p1", "p4"]], ["PPO", ["γ = 0.998, λ = 0.95, clip 0.2, lr 3e-4", "p2"]]] } },
      { id: "critic", role: "critic", roleLabel: "Value network", name: "Value network", sub: "same shape · privileged", col: 2, frozen: false, short: "Critic",
        stack: { rows: [
          { t: "in", label: "privileged state", dims: "adds joint angles / velocities, object velocities", c: "data-4" },
          { t: "norm", label: "Normalise (running stats)" },
          { t: "linear", label: "Dense 1,024 · ReLU" },
          { t: "ffn", label: "LSTM 512" },
          { t: "linear", label: "Linear → V(s)" },
          { t: "out", label: "value estimate", dims: "train-time only", c: "data-4" } ],
          facts: [["Weights", ["not shared with the policy", "p2"]], ["Extra inputs", ["hand joints and velocities (24-D each), object velocities", "p1"]], ["Noise", ["observation noise only on policy inputs", "p4"]]] } }
    ],
    inputs: [
      { to: "vision", mod: "vision", label: "3 RGB cameras", n: "200 × 200 each", k: 3 },
      { to: "policy", mod: "state", label: "fingertips + rel. goal", n: "15 + 4 D", k: 2 },
      { to: "critic", mod: "state", label: "privileged state", n: "incl. velocities", k: 3 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint-target deltas", n: "20 × 11 bins", k: 3 }],
    links: [
      { from: "vision", to: "policy", kind: "feeds", label: "object position|+ orientation" },
      { from: "policy", to: "critic", kind: "feeds", label: "asymmetric|actor–critic", note: "the critic only exists for PPO training" }
    ],
    callouts: [
      "No official code for the policy or pose network has been released, so every number here comes from the paper.",
      "Table 2 footnote: the current object orientation was accidentally left out of the policy input; it is implied by the relative target orientation."
    ]
  });

  /* ------------------------------------------------------------------ E2 · DeXtreme ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "dextreme", method: "dextreme", name: "DeXtreme", year: 2022, parent: "learning-dexterous-in-hand-manipulation",
    figRef: "Handa et al. §2.3, §2.7 · Tables 1, 12", prov: "ADR config",
    lede: "Dactyl's recipe moved to an Allegro Hand and GPU simulation: an LSTM-then-MLP actor on 50-D noisy observations, a bigger asymmetric critic on 265-D privileged state, and a keypoint-based pose estimator on three RGB cameras.",
    sources: {
      p1: { kind: "paper", ref: "Handa et al. 2023, §2.3, Table 1", url: "https://arxiv.org/abs/2210.13702" },
      p2: { kind: "paper", ref: "Handa et al. 2023, §2.7 (pose estimation)", url: "https://arxiv.org/abs/2210.13702" },
      p3: { kind: "paper", ref: "Handa et al. 2023, App. A.3, Table 12", url: "https://arxiv.org/abs/2210.13702" },
      p4: { kind: "paper", ref: "Handa et al. 2023, §3.1 (training setup)", url: "https://arxiv.org/abs/2210.13702" },
      p5: { kind: "paper", ref: "Handa et al. 2023, App. A.1, Table 10", url: "https://arxiv.org/abs/2210.13702" },
      c1: { kind: "code", repo: "isaac-sim/IsaacGymEnvs", path: "isaacgymenvs/cfg/train/AllegroHandDextremeADRPPO.yaml", commit: "aeed298", url: "https://github.com/isaac-sim/IsaacGymEnvs/blob/aeed298/isaacgymenvs/cfg/train/AllegroHandDextremeADRPPO.yaml" },
      c2: { kind: "code", repo: "isaac-sim/IsaacGymEnvs", path: "isaacgymenvs/cfg/task/AllegroHandDextremeADR.yaml", commit: "aeed298", url: "https://github.com/isaac-sim/IsaacGymEnvs/blob/aeed298/isaacgymenvs/cfg/task/AllegroHandDextremeADR.yaml" }
    },
    summary: {
      pattern: ["Actor–critic", "p1"],
      params: null,
      vision: ["3 RGB D415 cameras → Mask R-CNN-style box, mask and 8 cube-corner keypoints → PnP, triangulation", "p2"],
      backbone: ["Actor: LSTM 1,024 with layer norm → MLP 512, 512 (ELU)", "p1", "c1"],
      head: ["Gaussian with fixed σ over 16 continuous PD targets", "p3", "c1"],
      output: ["16 Allegro joint PD targets; EMA 0.2 → 0.15 in training, 0.1 on hardware", "p1"],
      attention: "None (LSTM memory)",
      cond: ["Asymmetric critic: 265-D privileged input incl. 78-D randomisation parameters", "p1"],
      rate: ["Control 30 Hz (sim dt 1/60 s); pose estimator locked to 15 Hz", "p4", "p2", "c2"],
      train: ["PPO, 16,384 agents per GPU on 8 A40s; ADR run ≈2.5 days", "p4", "p5", "c2"]
    },
    changes: [
      "Allegro Hand (16 DoF) and plain RGB cameras replace the Shadow Hand and motion capture.",
      "Continuous Gaussian actions (absolute PD targets) replace 11-bin categorical relative targets.",
      "LSTM comes first (1,024 units, layer norm), followed by a 512 × 2 ELU MLP.",
      "Critic grows to LSTM 2,048 + MLP 1,024, 512 and sees DR parameters.",
      "Pose from keypoints + PnP + triangulation instead of end-to-end pose regression.",
      "Isaac Gym on 8 GPUs instead of a CPU cluster."
    ],
    diffRows: ["vision", "backbone", "head", "output", "cond", "train"],
    blueprint: {
      headline: "DeXtreme: LSTM first, then MLP",
      note: "The actor reads a 50-D noisy observation, passes it through one layer-normed LSTM and a two-layer ELU MLP, and emits 16 PD targets that are low-pass filtered. The critic has the same layout at twice the width and a 265-D privileged input. At deployment the pose estimator replaces the simulator's object pose.",
      towers: [
        { mod: "pose", title: "Keypoint pose net", sub: "per camera, then geometry", compact: true,
          input: { label: "RGB frame", caption: "3 Intel D415, RGB only" },
          rows: [
            { t: "conv", label: "Mask R-CNN-style backbone" },
            { t: "linear", label: "Box, mask, keypoint heads", call: ["8 cube-corner keypoints in the box", "p2"] },
            { t: "mlp", label: "PnP per camera, filter", zoom: { k: "rows", title: "Pose from keypoints", rows: ["Detect box + mask per view", "Corner keypoints inside the box", "PnP pose per camera", "Drop views that disagree", "Triangulate, register to the cube"] } },
            { t: "mlp", label: "Triangulate + register", call: ["20 Hz on an RTX 3090, used at 15 Hz", "p2"] } ],
          output: { label: "cube pose (palm frame)" } },
        { mod: "actor", title: "LSTM actor", sub: "rl-games a2c_continuous",
          input: { label: "Observation (50-D)", caption: "noisy pose, goal, joints, last action" },
          rows: [
            { t: "norm", label: "Running mean / std input" },
            { t: "ffn", label: "LSTM + LayerNorm (hₜ)", call: ["1,024 units; BPTT length 16", "p1", "c1"], zoom: { k: "rows", title: "Actor recurrence", rows: ["oₜ normalised", "LSTM(oₜ, hₜ₋₁) → hₜ", "LayerNorm(hₜ)", "MLP 512 → 512, ELU", "μ(16), fixed σ"] } },
            { t: "block", n: "2", rows: [{ t: "linear", label: "Dense · ELU", call: ["MLP units [512, 512]", "p1", "c1"] }] },
            { t: "linear", label: "μ → 16 PD targets", call: ["Fixed σ; bounds loss 0.005", "p3", "c1"] } ],
          output: { label: "EMA-filtered joint targets" } },
        { mod: "critic", title: "LSTM critic", sub: "privileged, train-time only", compact: true,
          input: { label: "Privileged state", caption: "265-D incl. DR parameters" },
          rows: [
            { t: "ffn", label: "LSTM + LayerNorm", call: ["2,048 units", "p1", "c1"] },
            { t: "linear", label: "Dense · ELU", call: ["1,024 then 512 units", "p1", "c1"] },
            { t: "linear", label: "Dense · ELU" },
            { t: "linear", label: "Linear → V" } ],
          output: { label: "value for PPO" } }
      ],
      links: [{ from: "pose", to: "actor", toRow: "input", label: "object pose" }]
    },
    modules: [
      { id: "pose", role: "vision-enc", name: "Keypoint pose net", sub: "bbox + 8 keypoints · PnP", col: 0, frozen: true, short: "Pose net",
        stack: { rows: [
          { t: "in", label: "RGB frame per camera", dims: "3 cameras, no depth", c: "data-1" },
          { t: "conv", label: "torchvision Mask R-CNN-inspired network" },
          { t: "linear", label: "Heads: box (smooth L1), mask and keypoints (cross-entropy)" },
          { t: "mlp", label: "PnP per camera, reprojection check" },
          { t: "mlp", label: "Triangulation + model registration (roma)" },
          { t: "out", label: "cube pose", dims: "palm frame", c: "data-1" } ],
          facts: [["Keypoints", ["8 cube corners", "p2"]], ["Training data", ["5M synthetic Omniverse images", "p2"]], ["Sim test error", ["5.3° rotation", "p2"]], ["Rate", ["20 Hz inference, locked to 15 Hz", "p2"]]] } },
      { id: "actor", role: "action-head", roleLabel: "LSTM actor", name: "Actor", sub: "LSTM 1024 · MLP 512×2", col: 1, frozen: false, main: true, short: "Actor",
        stack: { rows: [
          { t: "in", label: "noisy object pose, goal, joints, last action", dims: "50-D", c: "data-4" },
          { t: "norm", label: "Input normalisation (running stats)" },
          { t: "ffn", label: "LSTM 1,024 + LayerNorm", dims: "before the MLP" },
          { t: "linear", label: "Dense 512 · ELU" }, { t: "linear", label: "Dense 512 · ELU" },
          { t: "linear", label: "μ → 16, fixed σ" },
          { t: "out", label: "PD targets", dims: "EMA-filtered", c: "data-3" } ],
          facts: [["LSTM", ["1,024, layer norm, 1 layer", "p1", "c1"]], ["MLP", ["[512, 512], ELU", "p1", "c1"]], ["Discount", ["0.998", "p1", "c1"]], ["Horizon / minibatch", ["16 / 16,384", "p3", "c1"]], ["Actor lr", ["1e-4, linear schedule", "p1", "c1"]]] } },
      { id: "critic", role: "critic", roleLabel: "Asymmetric critic", name: "Critic", sub: "LSTM 2048 · MLP 1024, 512", col: 2, frozen: false, short: "Critic",
        stack: { rows: [
          { t: "in", label: "privileged state", dims: "265-D", c: "data-4" },
          { t: "ffn", label: "LSTM 2,048 + LayerNorm" },
          { t: "linear", label: "Dense 1,024 · ELU" }, { t: "linear", label: "Dense 512 · ELU" },
          { t: "linear", label: "Linear → value" },
          { t: "out", label: "V(s, o)", dims: "train-time only", c: "data-4" } ],
          facts: [["Input", ["265-D incl. forces, velocities, 78-D DR params", "p1"]], ["LSTM", ["2,048", "p1", "c1"]], ["MLP", ["[1,024, 512], ELU", "p1", "c1"]], ["Critic lr", ["5e-5 (text and config)", "p1", "c1"]]] } }
    ],
    inputs: [
      { to: "pose", mod: "vision", label: "3 RGB cameras", n: "keypoints per view", k: 3 },
      { to: "actor", mod: "state", label: "noisy obs", n: "50-D", k: 3 },
      { to: "critic", mod: "state", label: "privileged state", n: "265-D", k: 4 }
    ],
    outputs: [{ from: "actor", mod: "action", label: "PD targets", n: "16", k: 3 }],
    links: [
      { from: "pose", to: "actor", kind: "feeds", label: "object pose|15 Hz" },
      { from: "actor", to: "critic", kind: "feeds", label: "asymmetric|actor–critic", note: "the critic only exists for PPO training" }
    ],
    callouts: [
      "Table 12 lists critic learning rate <b>5e-4</b> and KL threshold <b>0.16</b>; §2.3 and the released config use 5e-5 and 0.016.",
      "What changed vs Dactyl: continuous actions, LSTM before MLP, keypoint-based pose, and a single 8-GPU machine."
    ]
  });

  /* ------------------------------------------------------------------ E2 · Visual Dexterity ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "visual-dexterity", method: "visual-dexterity", name: "Visual Dexterity", year: 2022,
    figRef: "Chen et al. Fig. 6–7 · Supplementary", prov: "3-finger D'Claw",
    lede: "A privileged-state MLP teacher is distilled into a point-cloud student: a sparse 3-D CNN reads one voxelised cloud (scene + hand + goal object), a GRU adds memory, and the policy outputs joint deltas at 12 Hz.",
    sources: {
      p1: { kind: "paper", ref: "Chen et al. 2023, Methods (teacher, student, action space)", url: "https://arxiv.org/abs/2211.11744" },
      p2: { kind: "paper", ref: "Chen et al. 2023, Fig. 7 (student architecture)", url: "https://arxiv.org/abs/2211.11744" },
      p3: { kind: "paper", ref: "Chen et al. 2023, Supplementary: training setup", url: "https://arxiv.org/abs/2211.11744" },
      p4: { kind: "paper", ref: "Chen et al. 2023, Table S1", url: "https://arxiv.org/abs/2211.11744" },
      c1: { kind: "code", repo: "Improbable-AI/dexenv", path: "dexenv/models/voxel_impala.py", commit: "ad9634e", url: "https://github.com/Improbable-AI/dexenv/blob/ad9634e/dexenv/models/voxel_impala.py" },
      c2: { kind: "code", repo: "Improbable-AI/dexenv", path: "dexenv/models/sparse_cnn_rnn_models.py", commit: "ad9634e", url: "https://github.com/Improbable-AI/dexenv/blob/ad9634e/dexenv/models/sparse_cnn_rnn_models.py" },
      c3: { kind: "code", repo: "Improbable-AI/dexenv", path: "dexenv/conf/dclaw_fptd.yaml", commit: "ad9634e", url: "https://github.com/Improbable-AI/dexenv/blob/ad9634e/dexenv/conf/dclaw_fptd.yaml" },
      c4: { kind: "code", repo: "Improbable-AI/dexenv", path: "dexenv/models/state_model.py", commit: "ad9634e", url: "https://github.com/Improbable-AI/dexenv/blob/ad9634e/dexenv/models/state_model.py" }
    },
    summary: {
      pattern: ["Teacher–student policy", "p1"],
      params: null,
      vision: ["One depth camera; exteroceptive + proprioceptive + goal point clouds merged, voxelised at 5 mm", "p1", "p3", "c3"],
      backbone: ["Sparse 3-D CNN (Minkowski): 4 groups, 32 → 64 → 128 → 256 channels, 2 residual blocks each", "p2", "c1", "c3"],
      head: ["GRU 256 → Gaussian joint deltas; auxiliary head predicts rotation distance", "p2", "c2", "c3"],
      output: ["Relative joint deltas in ℝ³ᴳ (9-D for 3 fingers), EMA α = 0.8", "p1", "c2"],
      attention: "None (sparse convolutions + GRU)",
      cond: "Goal given as the object's point cloud in the target orientation, merged into the input",
      rate: ["12 Hz", "p1"],
      train: ["Teacher PPO with 32,000 envs; student DAgger in 2 stages; <400 GPU-hours in total", "p3", "p4"]
    },
    blueprint: {
      headline: "Visual Dexterity: sparse voxels to finger deltas",
      note: "The teacher sees exact object and finger state and is trained with PPO. The student sees only one merged point cloud per step: camera points, points sampled on the hand links from joint encoders, and the goal-pose object. Stage 1 trains it on cheap synthetic complete clouds; stage 2 fine-tunes on rendered, occluded clouds.",
      towers: [
        { mod: "enc", title: "Sparse 3-D CNN", sub: "Minkowski Engine, IMPALA-style",
          input: { label: "Voxelised point cloud", caption: "scene ∪ hand ∪ goal, 5 mm voxels" },
          rows: [
            { t: "block", n: "4", label: "channel group", rows: [
              { t: "conv", label: "Sparse conv k3 s2 · BN", call: ["Channels 32 → 64 → 128 → 256", "p2", "c3"] },
              { t: "conv", label: "Pre-act residual block" },
              { t: "add", span: 1 },
              { t: "conv", label: "Pre-act residual block", zoom: { k: "rows", title: "Residual block", rows: ["x", "BN → ReLU → sparse conv 3³", "BN → ReLU → sparse conv 3³", "x + F(x)"] } },
              { t: "add", span: 1 } ] },
            { t: "pool", label: "Global max ‖ avg pool" },
            { t: "linear", label: "Linear → 256 · GELU", call: ["embed_dim 256", "c3"] } ],
          output: { label: "scene embedding" } },
        { mod: "student", title: "Student head", sub: "GRU policy", compact: true,
          input: { label: "Embedding + prev. action", caption: "action MLP 9 → 32 → 32" },
          rows: [
            { t: "linear", label: "Merge → 256", call: ["[256 ‖ 32] → 256", "c2", "c3"] },
            { t: "ffn", label: "GRU (state hₜ)", call: ["256 features, 1 layer", "c3"] },
            { t: "linear", label: "Gaussian → joint deltas" },
            { t: "mlp", label: "Aux head on embedding", call: ["MLP 256 → 128 → 1, stops when small", "p3", "c2"] } ],
          output: { label: "Δq for 3G joints" } },
        { mod: "teacher", title: "Teacher MLP", sub: "privileged, PPO", compact: true,
          input: { label: "Privileged state", caption: "19G + 21 dims, G fingers" },
          rows: [
            { t: "linear", label: "Dense · ELU", call: ["Hidden 512, 256, 256", "p3", "c4"] },
            { t: "linear", label: "Dense · ELU" },
            { t: "linear", label: "Dense · ELU" },
            { t: "linear", label: "Gaussian → 3G deltas", zoom: { k: "rows", title: "Teacher → student", rows: ["Teacher: PPO on privileged state", "Stage 1: synthetic full clouds", "Stage 2: rendered, occluded clouds", "Deploy: one depth camera, 12 Hz"] } } ],
          output: { label: "actions to imitate" } }
      ],
      links: [{ from: "enc", to: "student", toRow: "input", label: "256-D embedding" }]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "Sparse 3-D CNN", sub: "32→64→128→256 ch", col: 0, frozen: false, main: true, short: "Sparse CNN",
        stack: { rows: [
          { t: "in", label: "merged point cloud", dims: "voxel size 0.005 m, no colour", c: "data-1" },
          { t: "block", label: "Channel group", n: "4", rows: [
            { t: "conv", label: "MinkowskiConv k3 s2 + BN", dims: "max pool k2 s2 in group 1" },
            { t: "conv", label: "Pre-activation residual block × 2" } ] },
          { t: "pool", label: "Global max pool ‖ global avg pool" },
          { t: "linear", label: "Linear → 256, then Linear + GELU" },
          { t: "out", label: "256-D embedding", dims: "per time step", c: "data-1" } ],
          facts: [["Channels", ["[32, 64, 128, 256]", "p2", "c3"]], ["Voxel", ["0.005 m", "p3", "c3"]], ["Pooling", ["global max ‖ global average", "c1"]], ["Augmentation", ["jitter and drop-out, p = 0.4 each", "p3", "c3"]]] } },
      { id: "student", role: "action-head", roleLabel: "Student policy", name: "GRU student", sub: "GRU 256 · aux rot-dist", col: 1, frozen: false, short: "Student",
        stack: { rows: [
          { t: "in", label: "embedding + previous action", dims: "256 + 9", c: "data-3" },
          { t: "mlp", label: "Action embed 9 → 32 → 32" },
          { t: "linear", label: "Merge [256 ‖ 32] → 256" },
          { t: "ffn", label: "GRU 256", note: "memory stands in for object velocity" },
          { t: "linear", label: "Gaussian head → Δq" },
          { t: "out", label: "joint deltas", dims: "q_tgt = q + EMA(a)", c: "data-3" } ],
          facts: [["GRU", ["256 features, 1 layer", "c3"]], ["Aux head", ["MLP 256 → 128 → 1 (rotation distance)", "c2"]], ["DAgger", ["400 / 260 envs, batch 40 / 20 (stage 1 / 2)", "p4"]], ["Loss", ["MLE on teacher actions", "c3"]]] } },
      { id: "teacher", role: "action-head", roleLabel: "Teacher policy", name: "Teacher MLP", sub: "512-256-256 · ELU", col: 2, frozen: true, short: "Teacher",
        stack: { rows: [
          { t: "in", label: "joints, fingertips, object pose/velocity, goal", dims: "19G + 21 D", c: "data-4" },
          { t: "linear", label: "Dense 512 · ELU" }, { t: "linear", label: "Dense 256 · ELU" }, { t: "linear", label: "Dense 256 · ELU" },
          { t: "linear", label: "Gaussian → 3G" },
          { t: "out", label: "expert actions", dims: "labels for the student", c: "data-3" } ],
          facts: [["Hidden", ["512, 256, 256, ELU", "p3", "c4"]], ["PPO", ["32,000 envs, 8 steps / update, 12 epochs", "p4"]], ["Discount", ["0.99", "p4"]], ["Objects", ["150 training objects (7,500 = 150 × 50 evals)", "p2"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "depth + hand + goal clouds", n: "one merged cloud", k: 5 },
      { to: "student", mod: "action", label: "previous action", n: "9-D", k: 1 },
      { to: "teacher", mod: "state", label: "privileged state", n: "19G + 21", k: 3 }
    ],
    outputs: [{ from: "student", mod: "action", label: "joint deltas", n: "3G", k: 2 }],
    links: [
      { from: "enc", to: "student", kind: "feeds", label: "embedding|256-D" },
      { from: "student", to: "teacher", kind: "two-stage", label: "DAgger|imitates teacher", note: "teacher trained first with PPO, then frozen" }
    ],
    callouts: [
      "Merging the goal cloud into the scene cloud and using <b>one</b> encoder learned faster than separate encoders (Fig. S7).",
      "Stage 1 skips rendering and samples points from meshes; that cut student training from 20+ days to under 3 (§Methods)."
    ]
  });

  /* ------------------------------------------------------------------ E2 · HORA ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "in-hand-object-rotation", method: "in-hand-object-rotation", name: "HORA (in-hand rotation)", year: 2022,
    figRef: "Qi et al. Fig. 2 · §3 · App. C", prov: "",
    lede: "Rapid Motor Adaptation for fingertip rotation. A small MLP policy reads 3 steps of joints and actions plus an 8-D extrinsics vector; in training μ encodes it from object physics, at deployment a temporal-conv module φ infers it from 30 steps of proprioception.",
    sources: {
      p1: { kind: "paper", ref: "Qi et al. 2022, §3 (base policy, adaptation module)", url: "https://arxiv.org/abs/2210.04887" },
      p2: { kind: "paper", ref: "Qi et al. 2022, §4 (hardware, simulation)", url: "https://arxiv.org/abs/2210.04887" },
      p3: { kind: "paper", ref: "Qi et al. 2022, App. C (architecture, optimisation)", url: "https://arxiv.org/abs/2210.04887" },
      c1: { kind: "code", repo: "HaozhiQi/hora", path: "hora/algo/models/models.py", commit: "410d958", url: "https://github.com/HaozhiQi/hora/blob/410d958/hora/algo/models/models.py" },
      c2: { kind: "code", repo: "HaozhiQi/hora", path: "configs/train/AllegroHandHora.yaml", commit: "410d958", url: "https://github.com/HaozhiQi/hora/blob/410d958/configs/train/AllegroHandHora.yaml" },
      c3: { kind: "code", repo: "HaozhiQi/hora", path: "configs/task/AllegroHandHora.yaml", commit: "410d958", url: "https://github.com/HaozhiQi/hora/blob/410d958/configs/task/AllegroHandHora.yaml" }
    },
    summary: {
      pattern: ["Teacher–student policy", "p1"],
      params: null,
      vision: "None: proprioception only (no vision, no touch)",
      backbone: ["Base policy MLP 512 → 256 → 128, ELU", "p3", "c1", "c2"],
      head: ["Linear → 16 PD targets; value head on the same trunk", "p3", "c1"],
      output: ["16 Allegro joint targets at 20 Hz; PD (Kp 3.0, Kd 0.1) at 300 Hz", "p2"],
      attention: "None (MLP + temporal convolutions)",
      cond: ["Extrinsics z ∈ ℝ⁸: μ(e) with e ∈ ℝ⁹ in training, φ(30-step history) at deployment", "p1", "p3", "c3"],
      rate: ["20 Hz", "p2"],
      train: ["PPO with 16,384 envs, ≈500M agent steps; then φ by supervised regression", "p2", "p3"]
    },
    blueprint: {
      headline: "HORA: infer the object from the fingers",
      note: "Stage 1 trains π and the privileged encoder μ together with PPO. Stage 2 freezes both and trains φ to regress μ's extrinsics from 30 steps of joint positions and commanded actions. At deployment φ runs online and its ẑ replaces z, so the same π adapts to mass, size and friction it cannot see.",
      towers: [
        { mod: "adapt", title: "Adaptation module φ", sub: "stage 2, supervised", compact: true,
          input: { label: "History (30 steps)", caption: "[qₜ ‖ aₜ₋₁] per step, 32-D" },
          rows: [
            { t: "mlp", label: "Per-step MLP · ReLU", call: ["32 → 32 → 32", "p3", "c1"] },
            { t: "conv", label: "Conv1d k9 s2" },
            { t: "conv", label: "Conv1d k5 s1" },
            { t: "conv", label: "Conv1d k5 s1", call: ["32 channels; kernels 9, 5, 5", "p3", "c1"], zoom: { k: "rows", title: "Temporal convs", rows: ["30 steps × 32 channels", "Conv k9 s2 → 11 steps", "Conv k5 → 7 steps", "Conv k5 → 3 steps", "Flatten 96 → Linear 8, tanh"] } },
            { t: "linear", label: "Flatten → 8, tanh", call: ["32 × 3 = 96 → 8", "p3", "c1"] } ],
          output: { label: "estimated ẑₜ" } },
        { mod: "policy", title: "Base policy π", sub: "PPO, shared actor–critic trunk",
          input: { label: "oₜ ‖ zₜ", caption: "q and a over 3 steps (96-D) + 8-D" },
          rows: [
            { t: "norm", label: "Running mean / std" },
            { t: "linear", label: "Dense · ELU", call: ["Units [512, 256, 128]", "p3", "c2"] },
            { t: "linear", label: "Dense · ELU" },
            { t: "linear", label: "Dense · ELU" },
            { t: "linear", label: "μ → 16 targets (+ value)", call: ["σ: one learned parameter per joint", "c1"], zoom: { k: "rows", title: "Two training stages", rows: ["Stage 1: PPO trains π and μ", "Stage 2: freeze π; fit φ to z (MSE)", "Deploy: φ online at 20 Hz"] } } ],
          output: { label: "16 PD targets" } },
        { mod: "mu", title: "Extrinsics encoder μ", sub: "privileged, stage 1", compact: true,
          input: { label: "Privileged eₜ (9-D)", caption: "position, scale, mass, friction, CoM" },
          rows: [
            { t: "linear", label: "Dense 256" },
            { t: "linear", label: "Dense 128" },
            { t: "linear", label: "Dense 8, tanh", call: ["Units [256, 128, 8]", "p3", "c2"] } ],
          output: { label: "extrinsics zₜ ∈ ℝ⁸" } }
      ],
      links: [
        { from: "adapt", to: "policy", toRow: "input", label: "ẑₜ (deploy)" },
        { from: "mu", to: "policy", toRow: "input", label: "zₜ (train)" }
      ]
    },
    modules: [
      { id: "adapt", role: "state-enc", roleLabel: "Adaptation module", name: "φ: temporal conv", sub: "30 steps → 8-D", col: 0, frozen: false, short: "φ",
        stack: { rows: [
          { t: "in", label: "joint positions + commanded actions", dims: "30 steps × 32", c: "data-4" },
          { t: "mlp", label: "Per-step Linear 32 → 32 · ReLU × 2" },
          { t: "conv", label: "Conv1d 32 → 32, k9 s2 · ReLU" },
          { t: "conv", label: "Conv1d 32 → 32, k5 s1 · ReLU" },
          { t: "conv", label: "Conv1d 32 → 32, k5 s1 · ReLU" },
          { t: "linear", label: "Flatten 96 → 8, tanh" },
          { t: "out", label: "ẑₜ", dims: "replaces z at deployment", c: "data-4" } ],
          facts: [["History", ["30 steps = 1.5 s", "p3", "c3"]], ["Convs", ["[32, 32, 9, 2], [32, 32, 5, 1], [32, 32, 5, 1]", "p3", "c1"]], ["Loss", ["MSE to z, Adam 3e-4", "p3"]]] } },
      { id: "policy", role: "action-head", roleLabel: "Base policy", name: "Base policy π", sub: "512-256-128 · ELU", col: 1, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "qₜ₋₂:ₜ, aₜ₋₃:ₜ₋₁ ‖ zₜ", dims: "96 + 8", c: "data-4" },
          { t: "norm", label: "Input normalisation (running stats)" },
          { t: "linear", label: "Dense 512 · ELU" }, { t: "linear", label: "Dense 256 · ELU" }, { t: "linear", label: "Dense 128 · ELU" },
          { t: "linear", label: "Heads: μ (16) and value (1)" },
          { t: "out", label: "PD targets", dims: "20 Hz", c: "data-3" } ],
          facts: [["Hidden", ["[512, 256, 128], ELU", "p3", "c2"]], ["Output", ["16 joint targets", "p1"]], ["PPO", ["horizon 8, batch 32,768, 5 epochs, lr 5e-3", "p3", "c2"]], ["Envs", ["16,384", "p2", "c3"]]] } },
      { id: "mu", role: "state-enc", roleLabel: "Privileged encoder", name: "μ: extrinsics MLP", sub: "9 → 256 → 128 → 8", col: 2, frozen: false, short: "μ",
        stack: { rows: [
          { t: "in", label: "object position, scale, mass, friction, CoM", dims: "9-D", c: "data-4" },
          { t: "linear", label: "Dense 256" }, { t: "linear", label: "Dense 128" }, { t: "linear", label: "Dense 8" },
          { t: "mlp", label: "tanh" },
          { t: "out", label: "zₜ", dims: "train-time only", c: "data-4" } ],
          facts: [["Input", ["9-D privileged vector", "p1"]], ["Units", ["[256, 128, 8]", "p3", "c2"]], ["Output", ["8-D extrinsics, tanh-squashed", "p1", "c1"]]] } }
    ],
    inputs: [
      { to: "adapt", mod: "state", label: "proprio + action history", n: "30 steps", k: 5 },
      { to: "policy", mod: "state", label: "3-step joints + actions", n: "96-D", k: 3 },
      { to: "mu", mod: "other", label: "object physics", n: "9-D", k: 2 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint targets", n: "16", k: 3 }],
    links: [
      { from: "adapt", to: "policy", kind: "latent", label: "ẑₜ (8-D)|deployment" },
      { from: "mu", to: "policy", kind: "latent", label: "zₜ (8-D)|training", note: "φ is trained to regress this vector" }
    ],
    callouts: [
      "Paper App. C says μ uses <b>ReLU</b>; the released MLP class uses <b>ELU</b> and squashes z with tanh.",
      "Trained only on cylinders, yet the same π rotates 30+ real objects because φ re-estimates z online (Fig. 5)."
    ]
  });

  /* ------------------------------------------------------------------ E2 · HATO ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "hato", method: "hato", name: "HATO", year: 2024, parent: "diffusion-policy",
    figRef: "Lin et al. §III-C, §IV", prov: "",
    lede: "A Diffusion Policy for two UR5e arms with prosthetic hands. Per-camera ResNet-18s, a touch MLP and an end-effector MLP produce one condition vector that FiLM-modulates a 1-D U-Net denoising 16 × 24-D joint actions.",
    sources: {
      p1: { kind: "paper", ref: "Lin et al. 2024, §III-C (data)", url: "https://arxiv.org/abs/2404.16823" },
      p2: { kind: "paper", ref: "Lin et al. 2024, §IV-A (learning)", url: "https://arxiv.org/abs/2404.16823" },
      p3: { kind: "paper", ref: "Lin et al. 2024, §IV-B (deployment)", url: "https://arxiv.org/abs/2404.16823" },
      p4: { kind: "paper", ref: "Lin et al. 2024, §V (tasks, demos)", url: "https://arxiv.org/abs/2404.16823" },
      c1: { kind: "code", repo: "toruowo/hato", path: "learning/dp/models.py", commit: "3b6f449", url: "https://github.com/toruowo/hato/blob/3b6f449/learning/dp/models.py" },
      c2: { kind: "code", repo: "toruowo/hato", path: "learning/dp/pipeline.py", commit: "3b6f449", url: "https://github.com/toruowo/hato/blob/3b6f449/learning/dp/pipeline.py" },
      c3: { kind: "code", repo: "toruowo/hato", path: "learning/dp/learner.py", commit: "3b6f449", url: "https://github.com/toruowo/hato/blob/3b6f449/learning/dp/learner.py" }
    },
    summary: {
      pattern: ["Multimodal fusion policy (vision + touch/force)", "p2"],
      params: null,
      vision: ["3 cameras (2 wrist, 1 head) at 240 × 320; one ResNet-18 (GroupNorm) per camera → 32-D", "p1", "p2", "c2"],
      backbone: ["Conditional 1-D U-Net, down dims 256 / 512 / 1,024, kernel 5", "c1"],
      head: ["ε-prediction DDPM with a squared-cosine schedule", "p2", "c3"],
      output: ["16 × 24-D absolute joint targets (6 per arm + 6 per hand)", "p2"],
      attention: "None (convolutions only)",
      cond: ["FiLM on [image ‖ touch ‖ EEF features ‖ step embedding 256]", "c1", "c2"],
      steps: ["100 train / 15 inference DDPM steps", "p2", "p3"],
      chunk: ["Tₒ = 1 → 16 predicted; asynchronous server averages overlapping predictions", "p2", "p3"],
      rate: ["Data recorded at 10 Hz", "p1"],
      train: ["100–300 teleop demos per task; AdamW 1e-4, batch 128, EMA weights", "p4", "p2"]
    },
    changes: [
      "Bimanual 24-D joint-position actions for two UR5e arms and two Ability hands.",
      "Adds two MLP encoders to the condition: 60 touch readings and both end-effector poses.",
      "Observation horizon 1 instead of 2; 15 DDPM steps at inference.",
      "Smaller U-Net: down dims 256 / 512 / 1,024.",
      "Asynchronous inference with temporal averaging of overlapping chunks."
    ],
    diffRows: ["vision", "backbone", "output", "cond", "steps", "chunk"],
    blueprint: {
      headline: "HATO: Diffusion Policy that can feel",
      note: "Each camera has its own ResNet-18; touch and end-effector poses go through small MLPs. All features are concatenated once per chunk with the step embedding and set FiLM scale and bias in every conditional residual block of the U-Net, which repeats for each denoising step.",
      towers: [
        { mod: "resnet", title: "ResNet-18 × 3", sub: "one per camera, GroupNorm", compact: true,
          input: { label: "RGB 240 × 320", caption: "2 wrist + 1 head camera" },
          rows: [
            { t: "conv", label: "Conv 7×7 · GN · ReLU" },
            { t: "block", n: "4", rows: [{ t: "conv", label: "Residual stage (2 blocks)" }] },
            { t: "pool", label: "Global average pool" },
            { t: "linear", label: "FC 512 → 32", call: ["image_output_size 32, not shared", "p2", "c2"] } ],
          output: { label: "3 × 32-D" } },
        { mod: "unet", title: "Conditional 1-D U-Net", sub: "noise-prediction network εθ",
          input: { label: "Noisy chunk Aᵏ", caption: "16 steps × 24-D, step k" },
          rows: [
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k5 · GN · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k5 · GN · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 256 → 512 → 1,024", "c1"] } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block" }] },
            { t: "group", label: "Up path, mirror", rows: [
              { t: "conv", label: "Concat skip + cond. blocks" },
              { t: "conv", label: "Upsample (transposed)" } ] },
            { t: "conv", label: "Final Conv1d → 24", call: ["Step embedding 256; 8 GN groups", "c1"], zoom: { k: "rows", title: "Asynchronous deployment", rows: ["Server: denoise on latest obs", "Send 16-step chunk + timestamp", "Client: average overlapping chunks", "Execute next action, send obs"] } } ],
          output: { label: "noise εθ; 15 steps at inference" } },
        { mod: "touch", title: "Touch + EEF MLPs", sub: "2-layer, ELU in code", compact: true,
          input: { label: "Touch 60 + EEF 12", caption: "6 sensors × 5 fingers × 2 hands" },
          rows: [
            { t: "linear", label: "Touch: Linear → 256", call: ["Hidden 256, out 64", "p2", "c1"] },
            { t: "linear", label: "Touch: Linear → 64" },
            { t: "linear", label: "EEF: Linear → 128 → 64", call: ["EEF hidden 128 in code", "c2"] } ],
          output: { label: "64 + 64 features" } }
      ],
      links: [
        { from: "resnet", to: "unet", toRow: "film", label: "image features" },
        { from: "touch", to: "unet", toRow: "film", label: "touch + EEF" }
      ]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet-18 per camera", sub: "GroupNorm · 32-D each", col: 0, frozen: false, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "RGB (optionally depth) frame", dims: "240 × 320, per camera", c: "data-1" },
          { t: "conv", label: "Conv 7×7 /2 → GN → ReLU → MaxPool" },
          { t: "group", label: "4 residual stages", rows: [{ t: "conv", label: "64 → 128 → 256 → 512 ch" }] },
          { t: "pool", label: "Global average pool" },
          { t: "linear", label: "FC 512 → 32" },
          { t: "out", label: "32-D per camera", dims: "concatenated", c: "data-1" } ],
          facts: [["Cameras", ["3 RealSense: 2 wrist, 1 head view", "p1"]], ["Norm", ["GroupNorm instead of BatchNorm", "p2", "c1"]], ["Output", ["32-D, weights not shared", "p2", "c2"]], ["Depth", ["optional; did not help (Fig. 8)", "p4"]]] } },
      { id: "unet", role: "action-head", roleLabel: "Noise-prediction net", name: "Conditional 1-D U-Net", sub: "256 → 512 → 1024 ch", col: 1, frozen: false, main: true, short: "1-D U-Net",
        stack: { rows: [
          { t: "in", label: "noisy action chunk Aᵏ", dims: "16 × 24", c: "data-3" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k5 → GN(8) → Mish" },
              { t: "film", label: "FiLM scale + bias from condition", side: "cond" },
              { t: "conv", label: "Conv1d k5 → GN(8) → Mish" },
              { t: "add", label: "residual", span: 3 } ] },
            { t: "conv", label: "Downsample1d (stride 2)" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block at 1,024 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · residual blocks · Upsample1d" }] },
          { t: "conv", label: "Final Conv1d → 24" },
          { t: "out", label: "predicted noise εθ", dims: "same shape as Aᵏ", c: "data-3" } ],
          facts: [["Down dims", ["256 / 512 / 1,024", "c1"]], ["Kernel / groups", ["5 / 8", "c1"]], ["Step embedding", ["256", "c1"]], ["Schedule", ["squared cosine, 100 train steps", "p2", "c3"]], ["Inference", ["15 DDPM steps", "p3"]]] } },
      { id: "touch", role: "touch-enc", name: "Touch + EEF encoders", sub: "MLP 60 → 256 → 64", col: 2, frozen: false, short: "Touch MLP",
        stack: { rows: [
          { t: "in", label: "touch readings + EEF poses", dims: "60 + 12", c: "data-6" },
          { t: "linear", label: "Touch: Linear → 256 → 64" },
          { t: "linear", label: "EEF: Linear → 128 → 64" },
          { t: "out", label: "64 + 64 features", dims: "join the FiLM condition", c: "data-6" } ],
          facts: [["Touch", ["60 readings: 6 per fingertip × 5 × 2 hands", "p1"]], ["Touch MLP", ["hidden 256, output 64", "p2", "c2"]], ["EEF", ["position + axis-angle for both arms", "p1"]], ["Activation", ["ReLU (paper) · ELU (code)", "p2", "c1"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "3 RGB views", n: "240 × 320", k: 3 },
      { to: "unet", mod: "action", label: "noisy chunk Aᵏ", n: "16 × 24", k: 5, noisy: true },
      { to: "touch", mod: "touch", label: "fingertip touch + EEF", n: "60 + 12", k: 3 }
    ],
    outputs: [{ from: "unet", mod: "action", label: "noise εθ", n: "16 × 24", k: 5 }],
    links: [
      { from: "resnet", to: "unet", kind: "film", label: "image features|3 × 32" },
      { from: "touch", to: "unet", kind: "film", label: "touch + EEF|64 + 64" }
    ],
    callouts: [
      "Paper §IV-A says the proprioception and touch MLPs use <b>ReLU</b> with hidden size 256; the released code uses <b>ELU</b> and hidden size <b>128</b> for the EEF encoder.",
      "Touch barely changes action MSE on Steak Serving (0.07 vs 0.08) but moves success from 0/10 to 5/10 (Table III)."
    ]
  });

  /* ------------------------------------------------------------------ E3 · DeformerNet ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "deformernet", method: "deformernet", name: "DeformerNet", year: 2021,
    figRef: "Thach et al. Fig. 3 · §IV-B", prov: "",
    lede: "A Siamese point-cloud network for 3-D shape servoing. One PointConv encoder embeds the current and goal clouds; an MLP maps the feature difference to a 3-D end-effector displacement, applied in closed loop.",
    sources: {
      p1: { kind: "paper", ref: "Thach et al. 2022, §IV-A, IV-B, Fig. 3", url: "https://arxiv.org/abs/2110.04685" },
      p2: { kind: "paper", ref: "Thach et al. 2022, §V-A (data, evaluation)", url: "https://arxiv.org/abs/2110.04685" },
      c1: { kind: "code", repo: "Utah-ARMLab/deformernet", path: "dvrk_gazebo_control/src/rlgpu/rl-pytorch/rl_pytorch/ppo/deformernet.py", commit: "3374946", url: "https://github.com/Utah-ARMLab/deformernet/blob/3374946/dvrk_gazebo_control/src/rlgpu/rl-pytorch/rl_pytorch/ppo/deformernet.py" }
    },
    summary: {
      pattern: ["Point-cloud visual servo (Siamese encoder + MLP)", "p1"],
      params: null,
      vision: ["Partial-view point clouds of the current and goal shape, FPS to 1,024 points", "p1"],
      backbone: ["Shared PointConv encoder: (64 ch, 512 pts) → (128 ch, 256 pts) → 256-D vector", "p1"],
      head: ["FC 128 → 64 → 32 → 3 with ReLU + GroupNorm", "p1", "c1"],
      output: ["End-effector displacement Δx ∈ ℝ³, executed by resolved-rate control", "p1"],
      attention: "None",
      cond: "Goal enters as a feature difference Δψ = ψc − ψg",
      train: ["10,000 supervised pairs per object type from 3,000 sim trajectories; MSE, Adam 1e-3", "p1", "p2"]
    },
    blueprint: {
      headline: "DeformerNet: servo on a feature difference",
      note: "The same encoder runs twice, once on the current cloud and once on the goal cloud. Their 256-D difference is the whole state the controller sees, so the network learns which end-effector motion shrinks the gap. The robot moves, re-observes and repeats until the Chamfer distance is small. The grasp point is chosen beforehand by a keypoint heuristic.",
      towers: [
        { mod: "enc", title: "PointConv encoder g", sub: "shared for Pc and Pg",
          input: { label: "Point cloud, 1,024 pts", caption: "FPS-downsampled partial view" },
          rows: [
            { t: "conv", label: "PointConv SA 1", call: ["512 points × 64 channels", "p1", "c1"], zoom: { k: "rows", title: "One PointConv layer", rows: ["FPS centroids + neighbour groups", "Local coordinates + density", "MLP weights w(Δp) per neighbour", "Σ w · f over the neighbourhood", "Out: centroids × channels"] } },
            { t: "conv", label: "PointConv SA 2", call: ["256 points × 128 channels (paper)", "p1"] },
            { t: "conv", label: "PointConv SA 3, group all", call: ["→ 256-D shape feature ψ", "p1", "c1"] } ],
          output: { label: "ψc and ψg" } },
        { mod: "ctrl", title: "Deformation controller F", sub: "MLP on Δψ", compact: true,
          input: { label: "Δψ = ψc − ψg", caption: "256-D" },
          rows: [
            { t: "linear", label: "FC · GroupNorm · ReLU", call: ["128, 64, 32 units", "p1", "c1"] },
            { t: "linear", label: "FC · GroupNorm · ReLU" },
            { t: "linear", label: "FC · GroupNorm · ReLU" },
            { t: "linear", label: "Linear → Δx (3)", zoom: { k: "rows", title: "Closed-loop shape servo", rows: ["Pick grasp point (keypoints)", "Observe Pc with a depth camera", "Δx = F(g(Pc) − g(Pg))", "Resolved-rate step; repeat"] } } ],
          output: { label: "EE displacement" } }
      ],
      links: [{ from: "enc", to: "ctrl", toRow: "input", label: "ψc − ψg" }]
    },
    modules: [
      { id: "enc", role: "vision-enc", roleLabel: "Point-cloud encoder", name: "PointConv encoder g", sub: "3 SA layers → 256-D", col: 0, frozen: false, main: true, short: "PointConv",
        stack: { rows: [
          { t: "in", label: "partial-view point cloud", dims: "1,024 points (FPS)", c: "data-1" },
          { t: "conv", label: "PointConv set abstraction", dims: "→ 512 points × 64" },
          { t: "conv", label: "PointConv set abstraction", dims: "→ 256 points × 128" },
          { t: "conv", label: "PointConv, group all", dims: "→ 256-D" },
          { t: "out", label: "shape feature ψ", dims: "same weights for current and goal", c: "data-1" } ],
          facts: [["Input", ["1,024 points, furthest-point sampled", "p1"]], ["Layers", ["(64, 512), (128, 256), 256-D", "p1"]], ["Norm", ["GroupNorm + ReLU", "p1", "c1"]]] } },
      { id: "ctrl", role: "action-head", roleLabel: "Servo controller", name: "Controller F", sub: "FC 128-64-32 → 3", col: 1, frozen: false, short: "F",
        stack: { rows: [
          { t: "in", label: "Δψ", dims: "256-D", c: "data-4" },
          { t: "linear", label: "FC 128 · GN · ReLU" }, { t: "linear", label: "FC 64 · GN · ReLU" }, { t: "linear", label: "FC 32 · GN · ReLU" },
          { t: "linear", label: "Linear → 3" },
          { t: "out", label: "Δx end-effector", dims: "resolved-rate control", c: "data-3" } ],
          facts: [["Units", ["128, 64, 32", "p1", "c1"]], ["Loss", ["MSE, Adam 1e-3, ÷10 every 50 epochs", "p1"]], ["Data", ["10,000 pairs per object type", "p2"]], ["Grasp point", ["keypoint heuristic, K = 200", "p2"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "current cloud Pc", n: "1,024 pts", k: 4 },
      { to: "enc", mod: "future", label: "goal cloud Pg", n: "1,024 pts", k: 4 }
    ],
    outputs: [{ from: "ctrl", mod: "action", label: "EE displacement", n: "3-D", k: 1 }],
    links: [{ from: "enc", to: "ctrl", kind: "feeds", label: "ψc − ψg|256-D" }],
    callouts: [
      "Paper: second PointConv layer keeps <b>256</b> points and the input is <b>ψc − ψg</b>. The only public definition (a commented-out class in the Utah-ARMLab repo) samples <b>128</b> points and computes ψg − ψc; the paper's training repo is not public.",
      "Model-free RL (PPO + HER) with this same architecture as actor and critic did much worse despite 10× the data (Fig. 6)."
    ]
  });

  /* ------------------------------------------------------------------ E3 · DexDeform ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "dexdeform", method: "dexdeform", name: "DexDeform", year: 2023,
    figRef: "Li et al. Fig. 2, 6 · App. C", prov: "Folding config",
    lede: "A latent skill model for dexterous dough manipulation. ConvONet + a conv VAE compress the scene cloud to a 128-D latent; an LSTM skill encoder, a skill-dynamics MLP and an action decoder let a gradient planner search over skills, then differentiable physics refines the result.",
    sources: {
      p1: { kind: "paper", ref: "Li et al. 2023, §2.2–2.3", url: "https://arxiv.org/abs/2304.03223" },
      p2: { kind: "paper", ref: "Li et al. 2023, App. A (tasks, action spaces)", url: "https://arxiv.org/abs/2304.03223" },
      p3: { kind: "paper", ref: "Li et al. 2023, App. C (architecture, training, planning)", url: "https://arxiv.org/abs/2304.03223" },
      c1: { kind: "code", repo: "sizhe-li/DexDeform", path: "policy/skill/models/act_embd.py", commit: "72f5087", url: "https://github.com/sizhe-li/DexDeform/blob/72f5087/policy/skill/models/act_embd.py" },
      c2: { kind: "code", repo: "sizhe-li/DexDeform", path: "policy/skill/models/dyn_pred.py", commit: "72f5087", url: "https://github.com/sizhe-li/DexDeform/blob/72f5087/policy/skill/models/dyn_pred.py" },
      c3: { kind: "code", repo: "sizhe-li/DexDeform", path: "assets/policy/perception/folding/vae_stage2.yaml", commit: "72f5087", url: "https://github.com/sizhe-li/DexDeform/blob/72f5087/assets/policy/perception/folding/vae_stage2.yaml" },
      c4: { kind: "code", repo: "sizhe-li/DexDeform", path: "assets/policy/skill/folding/skillnet.yaml", commit: "72f5087", url: "https://github.com/sizhe-li/DexDeform/blob/72f5087/assets/policy/skill/folding/skillnet.yaml" },
      c5: { kind: "code", repo: "sizhe-li/DexDeform", path: "policy/perception/scene_vae/vae_btlneck.py", commit: "72f5087", url: "https://github.com/sizhe-li/DexDeform/blob/72f5087/policy/perception/scene_vae/vae_btlneck.py" }
    },
    summary: {
      pattern: ["Latent skill model + gradient planner", "p1"],
      params: null,
      vision: ["Full scene point cloud → ConvONet tri-plane features, resolution 128, 64 channels", "p3", "c3"],
      backbone: ["Conv VAE: 6 stride-2 convs (64 → 512 ch) → scene latent sₜ ∈ ℝ¹²⁸", "p3", "c5", "c3"],
      head: ["Action decoder MLP 512 → 256 → action dim; skill dynamics MLP 512 → 256 → 128", "p3", "c1", "c2"],
      output: ["K = 10 relative joint-angle actions per skill: 26-D one hand + base, 20-D in-hand, 52-D two hands", "p2", "p3"],
      attention: "None",
      cond: ["Skill z ∈ ℝ¹²⁸ from a 5-layer LSTM (128) over K steps of (s, a)", "p3", "c1"],
      steps: "Gradient descent on a batch of skill sequences; best one decoded, then refined with differentiable MPM",
      train: ["10 teleop demos per task variant, grown with refined trajectories on augmented goals", "p1"]
    },
    blueprint: {
      headline: "DexDeform: plan in skill space, refine in physics",
      note: "The scene codec is trained first and frozen. The skill model then learns, VAE-style, to compress K = 10 steps into z, to decode z back into actions, and to predict the scene latent K steps later. Planning chains the dynamics MLP, decodes the final latent into occupancy and descends the occupancy loss against the goal cloud.",
      towers: [
        { mod: "codec", title: "Scene codec", sub: "ConvONet encoder + conv VAE",
          input: { label: "Scene point cloud", caption: "hands + dough, 3,000 points" },
          rows: [
            { t: "mlp", label: "PointNet, local pooling", call: ["hidden 64", "c3"] },
            { t: "pool", label: "Project to 3 planes", call: ["Tri-plane resolution 128, 64 channels", "p3", "c3"] },
            { t: "conv", label: "2-D U-Net per plane", call: ["depth 5", "p3", "c3"], zoom: { k: "rows", title: "Occupancy decoder (training)", rows: ["Query point p ∈ ℝ³", "Bilinear sample 3 planes, sum", "5 ResNet-FC blocks, width 32", "→ free / hand / object"] } },
            { t: "block", n: "6", rows: [{ t: "conv", label: "Conv 3×3 s2 · BN", call: ["64, 64, 128, 256, 512, 512 ch", "p3", "c5"] }] },
            { t: "linear", label: "FC → μ, log σ", call: ["scene latent 128-D", "p3", "c3"] } ],
          output: { label: "scene latent sₜ" } },
        { mod: "skill", title: "Skill model", sub: "SkiMo-style VAE + dynamics",
          input: { label: "(s, a) for K steps", caption: "K = 10, from demos" },
          rows: [
            { t: "ffn", label: "LSTM encoder f", call: ["5 layers × 128", "p3", "c1"] },
            { t: "linear", label: "FC 256 · BN · ReLU → 256" },
            { t: "linear", label: "→ μ, log σ of z", call: ["z ∈ ℝ¹²⁸", "p3", "c4"] },
            { t: "group", label: "Decoders on [sₜ ‖ z]", rows: [
              { t: "mlp", label: "Action decoder π", call: ["512 → 256 → action dim", "p3", "c1"] },
              { t: "mlp", label: "Skill dynamics ŝₜ₊K", call: ["512 → 256 → 128", "p3", "c2"], zoom: { k: "rows", title: "Planning with skills", rows: ["Sample z-sequences ~ N(0, I)", "ŝ ← T(z, ŝ) for each skill", "Occupancy loss vs goal cloud", "Gradient step on z; keep best", "Decode with π; refine by MPM"] } } ] } ],
          output: { label: "K actions and ŝₜ₊K" } }
      ],
      links: [{ from: "codec", to: "skill", toRow: "input", label: "scene latent sₜ" }]
    },
    modules: [
      { id: "codec", role: "codec", name: "ConvONet + VAE", sub: "tri-plane 128² → 128-D", col: 0, frozen: true, short: "Scene VAE",
        stack: { rows: [
          { t: "in", label: "full scene point cloud", dims: "position + colour label", c: "data-1" },
          { t: "mlp", label: "PointNet (local pool), hidden 64" },
          { t: "pool", label: "Scatter to xy, xz, yz planes", dims: "128 × 128 × 64 each" },
          { t: "conv", label: "2-D U-Net, depth 5" },
          { t: "block", label: "VAE encoder", n: "6", rows: [{ t: "conv", label: "Conv 3×3 s2 · BN · activation" }] },
          { t: "linear", label: "FC → μ, log σ (128)" },
          { t: "out", label: "scene latent sₜ", dims: "decodable to occupancy", c: "data-5" } ],
          facts: [["Planes", ["3, resolution 128, 64 channels", "p3", "c3"]], ["U-Net depth", ["5", "p3", "c3"]], ["VAE channels", ["64, 64, 128, 256, 512, 512", "p3", "c5"]], ["Latent", ["128", "p3", "c3"]], ["Training", ["ConvONet 10,000 iters; VAE 50,000 iters", "p3"]]] } },
      { id: "skill", role: "latent", roleLabel: "Skill model", name: "Skill VAE + dynamics", sub: "LSTM 5×128 · z ∈ ℝ¹²⁸", col: 1, frozen: false, main: true, short: "Skills",
        stack: { rows: [
          { t: "in", label: "K-step (s, a) sequence", dims: "K = 10", c: "data-3" },
          { t: "ffn", label: "LSTM, 5 layers × 128" },
          { t: "linear", label: "FC 256 → 256 → μ, log σ" },
          { t: "group", label: "Heads on [sₜ ‖ z]", rows: [
            { t: "mlp", label: "Action decoder: 512 → 256 → a" },
            { t: "mlp", label: "Skill dynamics: 512 → 256 → 128" } ] },
          { t: "out", label: "actions + ŝₜ₊K", dims: "used by the planner", c: "data-3" } ],
          facts: [["K", ["10", "p3"]], ["Encoder", ["LSTM 5 × 128", "p3", "c1"]], ["z", ["128-D", "p3", "c4"]], ["Loss", ["action MSE + β·KL + latent dynamics MSE", "p3"]], ["Action dim", ["26 (Folding, one hand + base)", "p2", "c4"]]] } }
    ],
    inputs: [
      { to: "codec", mod: "vision", label: "scene point cloud", n: "hands + dough", k: 4 },
      { to: "skill", mod: "action", label: "K-step actions", n: "K = 10", k: 3 }
    ],
    outputs: [{ from: "skill", mod: "action", label: "decoded actions", n: "K per skill", k: 3 }],
    links: [{ from: "codec", to: "skill", kind: "latent", label: "scene latent|128-D" }],
    callouts: [
      "App. C.2 trains on 50-step samples (5 skills); the released Folding skillnet.yaml uses 3 clips × 10 steps.",
      "Paper: point features are position + RGB (6-D); the released Folding perception config sets the encoder input dim to 4."
    ]
  });

  /* ------------------------------------------------------------------ E3 · Deep Whole-Body Control ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "deep-whole-body-control", method: "deep-whole-body-control", name: "Deep Whole-Body Control", year: 2022,
    figRef: "Fu et al. Fig. 2 · §2 · App. B–D", prov: "",
    lede: "One MLP drives a Go1 quadruped and a 6-DoF WidowX arm. A shared layer splits into a leg head and an arm head; a 20-D extrinsics vector comes from a privileged encoder in training and from a 10-step history convnet on the robot.",
    sources: {
      p1: { kind: "paper", ref: "Fu et al. 2022, §2 (policy, Advantage Mixing, ROA)", url: "https://arxiv.org/abs/2210.10044" },
      p2: { kind: "paper", ref: "Fu et al. 2022, App. C (simulation, control)", url: "https://arxiv.org/abs/2210.10044" },
      p3: { kind: "paper", ref: "Fu et al. 2022, App. D, Table 8", url: "https://arxiv.org/abs/2210.10044" },
      p4: { kind: "paper", ref: "Fu et al. 2022, App. F (real-world setup)", url: "https://arxiv.org/abs/2210.10044" },
      c1: { kind: "code", repo: "MarkFzp/Deep-Whole-Body-Control", path: "rsl_rl/rsl_rl/modules/actor_critic.py", commit: "8159e4e", url: "https://github.com/MarkFzp/Deep-Whole-Body-Control/blob/8159e4e/rsl_rl/rsl_rl/modules/actor_critic.py" },
      c2: { kind: "code", repo: "MarkFzp/Deep-Whole-Body-Control", path: "legged_gym/legged_gym/envs/widowGo1/widowGo1_config.py", commit: "8159e4e", url: "https://github.com/MarkFzp/Deep-Whole-Body-Control/blob/8159e4e/legged_gym/legged_gym/envs/widowGo1/widowGo1_config.py" }
    },
    summary: {
      pattern: ["Actor–critic", "p1"],
      params: null,
      vision: "None: proprioception + commands (vision only sets EE targets at deployment)",
      backbone: ["Shared Dense 128, then a leg head and an arm head of 2 × 128 each (ELU)", "p3", "c1", "c2"],
      head: ["Leg head → 12 targets, arm head → 6 targets, tanh-bounded", "p1", "c1"],
      output: ["18 joint position targets; PD with Kp 50 (legs) and 5 (arm)", "p1", "p2"],
      attention: "None (MLP)",
      cond: ["Extrinsics zₜ ∈ ℝ²⁰: μ(e) in training, φ(10-step history) online, regularised together (ROA)", "p1", "p3", "c1"],
      rate: ["Policy and φ at 50 Hz on a Raspberry Pi 4; sim at 200 Hz", "p2", "p4"],
      train: ["PPO with 5,000 envs, 2 billion samples, Advantage Mixing curriculum", "p3", "p1"]
    },
    blueprint: {
      headline: "Deep WBC: one body, two heads",
      note: "The state (75-D) and the extrinsics (20-D) pass through one shared layer, then split: the leg head produces 12 targets, the arm head 6. Advantage Mixing first credits arm actions with the manipulation advantage and leg actions with the locomotion advantage, then blends both. μ and φ are trained at the same time and pulled together by a regulariser.",
      towers: [
        { mod: "adapt", title: "Adaptation module φ", sub: "onboard, 50 Hz", compact: true,
          input: { label: "History (10 steps)", caption: "arm, leg, base states + actions" },
          rows: [
            { t: "linear", label: "Per-step Linear · ELU", call: ["→ 30 channels", "c1"] },
            { t: "conv", label: "Conv1d k4 s2 · ELU" },
            { t: "conv", label: "Conv1d k2 s1 · ELU", call: ["20 → 10 channels", "c1"], zoom: { k: "rows", title: "History encoder", rows: ["10 steps × 30 channels", "Conv k4 s2 → 4 steps × 20", "Conv k2 s1 → 3 steps × 10", "Flatten 30 → Linear 20"] } },
            { t: "linear", label: "Flatten → 20", call: ["ẑ ∈ ℝ²⁰", "p1", "c1"] } ],
          output: { label: "estimated zφ" } },
        { mod: "policy", title: "Unified policy π", sub: "legs + arm, one network",
          input: { label: "sₜ ‖ zₜ", caption: "state 75-D + extrinsics 20-D" },
          rows: [
            { t: "linear", label: "Shared Dense · ELU", call: ["128 units", "p3", "c2"] },
            { t: "group", label: "Two parallel heads", rows: [
              { t: "linear", label: "Leg head: 2 × 128 · ELU", call: ["→ 12 leg targets, tanh", "p3", "c1"] },
              { t: "linear", label: "Arm head: 2 × 128 · ELU", call: ["→ 6 arm targets, tanh", "p3", "c1"], zoom: { k: "rows", title: "Advantage Mixing", rows: ["Arm: A_manip + β·A_loco", "Leg: β·A_manip + A_loco", "β rises 0 → 1 over T_mix"] } } ] },
            { t: "mlp", label: "Concat → PD targets", call: ["Kp 50 / 5, Kd 1 / 0.5 (legs / arm)", "p2"] } ],
          output: { label: "18 joint targets" } },
        { mod: "priv", title: "Privileged encoder μ", sub: "simulation only", compact: true,
          input: { label: "Privileged eₜ", caption: "payloads, CoM, friction, strength" },
          rows: [
            { t: "linear", label: "Dense · ELU", call: ["64 then 20 units", "c1", "c2"] },
            { t: "linear", label: "Dense · ELU", zoom: { k: "rows", title: "Regularized Online Adaptation", rows: ["π uses zμ = μ(e) during RL", "φ regresses zφ to sg(zμ)", "+ λ‖zμ − sg(zφ)‖ pulls zμ to zφ", "Deploy: zφ only"] } } ],
          output: { label: "zμ ∈ ℝ²⁰" } }
      ],
      links: [
        { from: "adapt", to: "policy", toRow: "input", label: "zφ (deploy)" },
        { from: "priv", to: "policy", toRow: "input", label: "zμ (train)" }
      ]
    },
    modules: [
      { id: "adapt", role: "state-enc", roleLabel: "Adaptation module", name: "φ: history convnet", sub: "10 steps → 20-D", col: 0, frozen: false, short: "φ",
        stack: { rows: [
          { t: "in", label: "states and actions, last 10 steps", dims: "10 × proprio", c: "data-4" },
          { t: "linear", label: "Per-step Linear → 30 · ELU" },
          { t: "conv", label: "Conv1d 30 → 20, k4 s2 · ELU" },
          { t: "conv", label: "Conv1d 20 → 10, k2 s1 · ELU" },
          { t: "linear", label: "Flatten 30 → 20 · ELU" },
          { t: "out", label: "zφ", dims: "used on the robot", c: "data-4" } ],
          facts: [["History", ["10 steps", "p1", "c2"]], ["Convs", ["k4 s2 then k2 s1", "c1"]], ["Update", ["every H = 20 iterations, imitate sg(zμ)", "p1", "p3"]]] } },
      { id: "policy", role: "action-head", roleLabel: "Unified policy", name: "Unified policy π", sub: "128 → 2 heads × 2 × 128", col: 1, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "base, arm, leg state, last action, commands ‖ z", dims: "75 + 20", c: "data-4" },
          { t: "linear", label: "Shared Dense 128 · ELU" },
          { t: "group", label: "Leg head", rows: [{ t: "linear", label: "128 · ELU → 128 · ELU → 12, tanh" }] },
          { t: "group", label: "Arm head", rows: [{ t: "linear", label: "128 · ELU → 128 · ELU → 6, tanh" }] },
          { t: "out", label: "18 joint targets", dims: "PD-tracked, 50 Hz", c: "data-3" } ],
          facts: [["Shared", ["128", "p3", "c2"]], ["Heads", ["2 × 128 each", "p3", "c2"]], ["Actions", ["12 leg + 6 arm", "p1"]], ["PPO", ["lr 2e-4, γ 0.99, λ 0.95, 40 steps / batch", "p3"]], ["Envs", ["5,000", "p3", "c2"]]] } },
      { id: "priv", role: "state-enc", roleLabel: "Privileged encoder", name: "μ: privileged MLP", sub: "→ 64 → 20", col: 2, frozen: false, short: "μ",
        stack: { rows: [
          { t: "in", label: "masses, CoM, friction, motor strengths", dims: "privileged", c: "data-4" },
          { t: "linear", label: "Dense 64 · ELU" }, { t: "linear", label: "Dense 20 · ELU" },
          { t: "out", label: "zμ", dims: "simulation only", c: "data-4" } ],
          facts: [["Dims", ["[64, 20]", "c1", "c2"]], ["Inputs", ["body + EE payload, CoM, friction, arm and leg strength", "p1"]], ["Regulariser λ", ["0 → 1 linear curriculum", "p1", "p3"]]] } }
    ],
    inputs: [
      { to: "adapt", mod: "state", label: "state/action history", n: "10 steps", k: 4 },
      { to: "policy", mod: "state", label: "state + commands", n: "75-D", k: 3 },
      { to: "priv", mod: "other", label: "env parameters", n: "privileged", k: 2 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint targets", n: "12 + 6", k: 3 }],
    links: [
      { from: "adapt", to: "policy", kind: "latent", label: "zφ (20-D)|deployment" },
      { from: "priv", to: "policy", kind: "latent", label: "zμ (20-D)|training" }
    ],
    callouts: [
      "Paper App. D gives the state as sₜ ∈ ℝ<b>⁷⁵</b>; the released config sums num_proprio to <b>76</b>.",
      "RMA is the special case λ = 0 with φ trained after π converges; ROA trains both at once and closes the realizability gap (Table 6)."
    ]
  });

  /* ------------------------------------------------------------------ E3 · HoMeR ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "homer", method: "homer", name: "HoMeR", year: 2025,
    figRef: "Sundaresan et al. Fig. 2 · §3 · App. A–B", prov: "",
    lede: "A hybrid imitation policy on a whole-body IK controller. A point-cloud transformer predicts absolute end-effector keyposes for reaching; a Diffusion Policy predicts delta chunks for fine work; each also predicts the next mode.",
    sources: {
      p1: { kind: "paper", ref: "Sundaresan et al. 2025, §3.1–3.3", url: "https://arxiv.org/abs/2506.01185" },
      p2: { kind: "paper", ref: "Sundaresan et al. 2025, App. A (WBC)", url: "https://arxiv.org/abs/2506.01185" },
      p3: { kind: "paper", ref: "Sundaresan et al. 2025, App. B (keypose and dense policies)", url: "https://arxiv.org/abs/2506.01185" },
      p4: { kind: "paper", ref: "Sundaresan et al. 2025, §4", url: "https://arxiv.org/abs/2506.01185" },
      c1: { kind: "code", repo: "priyasundaresan/homer", path: "models/waypoint_transformer.py", commit: "672aed1", url: "https://github.com/priyasundaresan/homer/blob/672aed1/models/waypoint_transformer.py" },
      c2: { kind: "code", repo: "priyasundaresan/homer", path: "cfgs/waypoint/cabinet_wbc.yaml", commit: "672aed1", url: "https://github.com/priyasundaresan/homer/blob/672aed1/cfgs/waypoint/cabinet_wbc.yaml" },
      c3: { kind: "code", repo: "priyasundaresan/homer", path: "models/diffusion_policy.py", commit: "672aed1", url: "https://github.com/priyasundaresan/homer/blob/672aed1/models/diffusion_policy.py" },
      c4: { kind: "code", repo: "priyasundaresan/homer", path: "cfgs/dense/remote_wbc_allcams.yaml", commit: "672aed1", url: "https://github.com/priyasundaresan/homer/blob/672aed1/cfgs/dense/remote_wbc_allcams.yaml" },
      c5: { kind: "code", repo: "priyasundaresan/homer", path: "models/cond_unet1d.py", commit: "672aed1", url: "https://github.com/priyasundaresan/homer/blob/672aed1/models/cond_unet1d.py" }
    },
    summary: {
      pattern: ["Hybrid keypose + dense imitation policy on a whole-body controller", "p1"],
      params: null,
      vision: ["Keypose: third-person point cloud, FPS to 1,024 points (xyz + rgb); dense: third-person + wrist RGB through ResNet-18", "p1", "p3", "c1"],
      backbone: ["Point transformer: 6 layers, width 512, 8 heads, no positional encoding", "p3", "c1", "c2"],
      head: ["Per-point saliency + 3-D offset; learned tokens for rotation, gripper and mode", "p1", "p3", "c1"],
      output: ["6-DoF EE keypose, or 16 EE deltas (8 executed), + gripper; WBC maps to base (x, y, θ) + 7-DoF arm", "p1", "p3"],
      attention: "Full self-attention over point and query tokens",
      cond: ["Optional VLM keypoint (MolMo 7B-D) as an extra saliency channel (HoMeR-Cond)", "p1", "p3"],
      steps: ["Dense: DDPM in the paper; released dense configs use DDIM with 10 inference steps", "p3", "c3", "c4"],
      rate: ["Teleop data and actions at 10 Hz", "p1"],
      train: ["20 demos per task", "p4"]
    },
    blueprint: {
      headline: "HoMeR: reach by keypose, finish densely",
      note: "The keypose transformer treats 1,024 points and four extra tokens as one sequence. The point with the highest saliency, plus its predicted offset, gives the target position; the extra tokens give rotation, gripper and next mode. When the mode says dense, the Diffusion Policy takes over with EE deltas. Every target goes through the same IK whole-body controller.",
      towers: [
        { mod: "kp", title: "Keypose transformer", sub: "SPHINX-style, point cloud",
          input: { label: "Point cloud, 1,024 pts", caption: "xyz + rgb, + proprio token" },
          rows: [
            { t: "embed", label: "Linear 6 → 512 per point", call: ["+ 3 learned tokens + 11-D proprio token", "c1"] },
            { t: "block", n: "6", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head self-attention", call: ["8 heads, width 512, no positions", "p3", "c1"], zoom: { k: "heads", q: 8, kv: 8, hd: 64, title: "Self-attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["512 → 2,048 → 512, GELU", "c1"], zoom: { k: "mlp", act: "GELU", d: "512", ff: "2,048", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "linear", label: "Point + token heads", call: ["Per point: 1 logit + 3 offset", "p3", "c1"], zoom: { k: "rows", title: "Decoding a keypose", rows: ["Softmax saliency over points", "p* = most salient point", "position = p* + offset(p*)", "+ quaternion, gripper tokens", "Interpolate there via the WBC"] } } ],
          output: { label: "keypose + next mode" } },
        { mod: "dp", title: "Dense Diffusion Policy", sub: "EE delta chunks", compact: true,
          input: { label: "Wrist + base RGB", caption: "+ current EE pose" },
          rows: [
            { t: "conv", label: "ResNet-18 per view" },
            { t: "linear", label: "Compress + proprio" },
            { t: "conv", label: "Cond. 1-D U-Net (FiLM)", call: ["Down dims 256/512/1,024, kernel 5", "c4", "c5"] } ],
          output: { label: "16 deltas, run 8" } },
        { mod: "wbc", title: "Whole-body IK", sub: "MuJoCo + mink QP", compact: true,
          input: { label: "Target EE pose", caption: "from either sub-policy" },
          rows: [
            { t: "mlp", label: "QP IK, ≤ 20 iterations", call: ["W_ee 1.0, posture 2e-3, base 1.5", "p2"] },
            { t: "mlp", label: "Velocity + joint limits" } ],
          output: { label: "base (x, y, θ) + 7 arm" } }
      ],
      links: [
        { from: "kp", to: "wbc", toRow: "input", label: "keypose" },
        { from: "dp", to: "wbc", toRow: "input", label: "EE delta" }
      ]
    },
    modules: [
      { id: "kp", role: "action-head", roleLabel: "Keypose policy", name: "Point transformer", sub: "6 × 512 · 8 heads", col: 0, frozen: false, main: true, short: "Keypose",
        stack: { rows: [
          { t: "in", label: "point cloud + proprio", dims: "1,024 points × 6, 11-D proprio", c: "data-1" },
          { t: "embed", label: "Linear 6 → 512 per point; + tokens" },
          { t: "block", label: "Pre-norm transformer layer", n: "6", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 8 heads · no positional encoding" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 512 → 2,048 → 512 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final LayerNorm" },
          { t: "linear", label: "Heads: saliency + offset, pos, rot, gripper, mode" },
          { t: "out", label: "EE keypose + mode", dims: "absolute target", c: "data-3" } ],
          facts: [["Layers / width / heads", ["6 / 512 / 8", "p3", "c1"]], ["Points", ["1,024 after FPS", "c1"]], ["Training", ["Adam 1e-4, cosine, batch 64, dropout 0.1, EMA", "p3", "c2"]], ["Augmentation", ["5 cm translation, 20 % interpolated prefixes", "p3", "c2"]]] } },
      { id: "dp", role: "action-head", roleLabel: "Dense policy", name: "Diffusion Policy", sub: "ResNet-18 · 1-D U-Net", col: 1, frozen: false, short: "Dense",
        stack: { rows: [
          { t: "in", label: "RGB views + EE pose", dims: "third-person + wrist", c: "data-1" },
          { t: "conv", label: "ResNet-18 per camera" },
          { t: "linear", label: "Linear compress + proprio" },
          { t: "conv", label: "Conditional 1-D U-Net (FiLM)" },
          { t: "out", label: "EE delta chunk + mode", dims: "16 predicted, 8 executed", c: "data-3" } ],
          facts: [["Horizon", ["16 predicted, 8 executed", "p3", "c3"]], ["U-Net", ["down dims 256/512/1,024, kernel 5", "c4", "c5"]], ["Sampler", ["DDPM (paper) · DDIM 10 steps (config)", "p3", "c4"]]] } },
      { id: "wbc", role: "net", roleLabel: "Whole-body controller", name: "IK controller", sub: "mink QP · no learning", col: 2, frozen: true, short: "WBC",
        stack: { rows: [
          { t: "in", label: "target EE pose", dims: "SE(3)", c: "data-3" },
          { t: "mlp", label: "min ‖J q̇ − e‖² + posture + base damping" },
          { t: "mlp", label: "Velocity, position and optional collision limits" },
          { t: "out", label: "joint command", dims: "3 base + 7 arm", c: "data-3" } ],
          facts: [["Weights", ["EE 1.0, posture 2e-3, base damping 1.5", "p2"]], ["Solver", ["≤ 20 iterations, tolerance 1e-4", "p2"]], ["Base limit", ["0.5 m/s, π/2 rad/s", "p2"]]] } }
    ],
    inputs: [
      { to: "kp", mod: "vision", label: "third-person point cloud", n: "1,024 pts", k: 5 },
      { to: "dp", mod: "vision", label: "wrist + base RGB", n: "2–3 views", k: 3 },
      { to: "wbc", mod: "state", label: "joint state", n: "3 + 7", k: 2 }
    ],
    outputs: [{ from: "wbc", mod: "action", label: "base + arm joints", n: "10", k: 3 }],
    links: [
      { from: "kp", to: "dp", kind: "feeds", label: "mode switch|keypose ↔ dense" },
      { from: "dp", to: "wbc", kind: "feeds", label: "EE target|→ joint command" }
    ],
    callouts: [
      "The paper describes three modes (keypose, dense, terminate); the released transformer's mode head has <b>4</b> classes, adding a base-waypoint mode for the base+arm baseline.",
      "Paper App. B says the dense policy is trained with DDPM; the released dense configs set use_ddpm: 0 (DDIM, 10 inference steps)."
    ]
  });

  /* ------------------------------------------------------------------ E3 · MoManipVLA ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "momanipvla", method: "momanipvla", name: "MoManipVLA", year: 2025, parent: "openvla",
    figRef: "Wu et al. Fig. 2 · §3 · §4.1", prov: "",
    lede: "A fixed-base VLA reused for mobile manipulation. LoRA-tuned OpenVLA-7B predicts end-effector waypoints; a bi-level optimiser then searches base poses and arm poses that reach them with low reachability, smoothness and collision cost.",
    sources: {
      p1: { kind: "paper", ref: "Wu et al. 2025, §3.2–3.4, Alg. 1", url: "https://arxiv.org/abs/2503.13446" },
      p2: { kind: "paper", ref: "Wu et al. 2025, §4.1 (implementation)", url: "https://arxiv.org/abs/2503.13446" },
      p3: { kind: "paper", ref: "Wu et al. 2025, §4.4, Table 4 (real world)", url: "https://arxiv.org/abs/2503.13446" }
    },
    summary: {
      pattern: ["Autoregressive token VLA + trajectory optimiser", "p1"],
      params: ["7B (OpenVLA backbone)", "p2"],
      vision: "OpenVLA's vision encoders on RGB (not re-described in the paper)",
      backbone: ["OpenVLA-7B, LoRA fine-tuned (10K epochs on 4 RTX 3090s)", "p2"],
      head: "OpenVLA action tokens read as an EE waypoint [Δx, Δθ, ΔG]",
      output: ["Base pose + 7-DoF arm trajectory between waypoints (10-DoF search)", "p1"],
      attention: "As OpenVLA (causal decoder)",
      cond: ["Cost O = 10·F_reach + 1·F_smooth + 0.6·F_collision, ESDF margin 0.1", "p2"],
      steps: "Dual Annealing search, SLSQP refinement; upper level base, lower level arm",
      latency: ["≈580–592 ms per step on the real robot", "p3"],
      train: ["200 OVMM sim episodes; 50 real demos", "p2", "p3"]
    },
    changes: [
      "OpenVLA is LoRA-tuned on mobile-manipulation episodes, not used zero-shot.",
      "Its outputs are treated as end-effector waypoints instead of executed directly.",
      "A bi-level optimiser plans base (3-DoF) and arm (7-DoF) motion between waypoints.",
      "Feasibility costs: IK reachability, smoothness and ESDF collision (nvblox)."
    ],
    diffRows: ["head", "output", "cond", "train", "latency"],
    blueprint: {
      headline: "MoManipVLA: VLA waypoints, optimised body",
      note: "The VLA is drawn only at the level the paper describes: images and the instruction go in, one end-effector waypoint comes out. Between consecutive waypoints the optimiser first moves the base so the waypoint becomes reachable, then picks arm poses, scoring every candidate with the three costs and solving joints with Pinocchio IK.",
      towers: [
        { mod: "vla", title: "OpenVLA-7B", sub: "LoRA fine-tuned, waypoint generator",
          input: { label: "RGB frame + instruction", caption: "\"open the drawer\"" },
          rows: [
            { t: "embed", label: "Vision encoders (OpenVLA)" },
            { t: "attn", label: "LLM decoder (OpenVLA)", call: ["7B, LoRA on 200 episodes", "p2"] },
            { t: "linear", label: "Action tokens → waypoint", call: ["[Δx, Δθ, ΔG] in the base frame", "p1"] } ],
          output: { label: "EE waypoint Qᵢ" } },
        { mod: "opt", title: "Bi-level optimiser", sub: "no learned weights", compact: true,
          input: { label: "Qᵢ → Qᵢ₊₁", caption: "world frame via Γ" },
          rows: [
            { t: "mlp", label: "Init: linear interpolation", call: ["Step size 0.05 sets intermediate poses", "p2"] },
            { t: "mlp", label: "Upper: base poses (iterate)", call: ["Dual Annealing + SLSQP", "p1"], zoom: { k: "rows", title: "Feasibility costs", rows: ["Reach: N_IK / N_max, else C₀", "Smooth: Σ‖Δθ‖² + ‖Δx_base‖²", "Collision: Σ max(0, ε₀ − ESDF)", "O = λ₁F_r + λ₂F_s + λ₃F_c"] } },
            { t: "mlp", label: "Lower: search arm poses" },
            { t: "mlp", label: "Pinocchio IK per pose", zoom: { k: "rows", title: "One bi-level step", rows: ["Sample arm poses per base pose", "Score base by mean + top-k cost", "Fix base; pick best arm pose", "Repeat until the waypoint is hit"] } } ],
          output: { label: "base + arm trajectory" } }
      ],
      links: [{ from: "vla", to: "opt", toRow: "input", label: "waypoints" }]
    },
    modules: [
      { id: "vla", role: "vlm", roleLabel: "VLA", name: "OpenVLA-7B", sub: "LoRA · waypoint tokens", col: 0, frozen: "lora", params: "7B", main: true, short: "OpenVLA",
        stack: { rows: [
          { t: "in", label: "RGB image + instruction + EE state", dims: "fixed-base VLA inputs", c: "data-1" },
          { t: "embed", label: "Vision encoders → visual tokens" },
          { t: "attn", label: "LLM decoder, LoRA adapters" },
          { t: "linear", label: "Action tokens → [Δx, Δθ, ΔG]" },
          { t: "out", label: "EE waypoint", dims: "base frame", c: "data-3" } ],
          facts: [["Backbone", ["OpenVLA-7B", "p2"]], ["Fine-tuning", ["LoRA, 200 episodes, 10K epochs, 4 RTX 3090", "p2"]], ["Real robot", ["50 demos", "p3"]]] } },
      { id: "opt", role: "planner", roleLabel: "Trajectory optimiser", name: "Bi-level optimiser", sub: "base (3) + arm (7)", col: 1, frozen: true, short: "Optimiser",
        stack: { rows: [
          { t: "in", label: "consecutive waypoints Q̂ᵢ, Q̂ᵢ₊₁", dims: "world frame", c: "data-3" },
          { t: "mlp", label: "Upper level: base poses (Dual Annealing)" },
          { t: "mlp", label: "Lower level: arm / EE poses" },
          { t: "mlp", label: "Refine with SLSQP; IK with Pinocchio" },
          { t: "out", label: "whole-body trajectory", dims: "10-DoF", c: "data-3" } ],
          facts: [["λ₁, λ₂, λ₃", ["10.0, 1.0, 0.6", "p2"]], ["Safety margin ε₀", ["0.1", "p2"]], ["Search space", ["7 arm + 3 base", "p1"]], ["Collision map", ["nvblox ESDF", "p1"]]] } }
    ],
    inputs: [
      { to: "vla", mod: "vision", label: "RGB frame", n: "1 view", k: 3 },
      { to: "vla", mod: "lang", label: "instruction", n: "text", k: 2 },
      { to: "opt", mod: "vision", label: "RGB-D → ESDF", n: "scene map", k: 2 }
    ],
    outputs: [{ from: "opt", mod: "action", label: "base + arm trajectory", n: "10-DoF", k: 4 }],
    links: [{ from: "vla", to: "opt", kind: "two-stage", label: "EE waypoints|[Δx, Δθ, ΔG]" }],
    callouts: [
      "No official code release was found; every number here is from the paper.",
      "The paper does not re-describe OpenVLA's layers; see the OpenVLA spec (parent) for those."
    ]
  });

  /* ------------------------------------------------------------------ E3 · χ0 ------------------------------------------------------------------ */
  RB.arch.spec({
    id: "chi0", method: "chi0", name: "χ0", year: 2026, parent: "pi0-5",
    figRef: "χ0 Fig. 2 · App. C–D, Table I", prov: "garment tasks",
    lede: "A post-training recipe around an unchanged π0.5. Checkpoints trained on data subsets are merged in weight space, a π0.5-shaped estimator with a value head labels stage-aware advantages, and a smoothing buffer blends overlapping action chunks.",
    sources: {
      p1: { kind: "paper", ref: "χ0 2026, §III and Fig. 2", url: "https://arxiv.org/abs/2602.09021" },
      p2: { kind: "paper", ref: "χ0 2026, App. C (MA, SA, TDA details)", url: "https://arxiv.org/abs/2602.09021" },
      p3: { kind: "paper", ref: "χ0 2026, App. D, Table I (hyperparameters, hardware)", url: "https://arxiv.org/abs/2602.09021" },
      p4: { kind: "paper", ref: "χ0 2026, §IV-E (Model Arithmetic results)", url: "https://arxiv.org/abs/2602.09021" },
      c1: { kind: "code", repo: "OpenDriveLab/kai0", path: "src/openpi/models_pytorch/pi0_pytorch.py", commit: "9d93078", url: "https://github.com/OpenDriveLab/kai0/blob/9d93078/src/openpi/models_pytorch/pi0_pytorch.py" },
      c2: { kind: "code", repo: "OpenDriveLab/kai0", path: "src/openpi/models/gemma.py", commit: "9d93078", url: "https://github.com/OpenDriveLab/kai0/blob/9d93078/src/openpi/models/gemma.py" },
      c3: { kind: "code", repo: "OpenDriveLab/kai0", path: "src/openpi/models/pi0_config.py", commit: "9d93078", url: "https://github.com/OpenDriveLab/kai0/blob/9d93078/src/openpi/models/pi0_config.py" },
      c4: { kind: "code", repo: "OpenDriveLab/kai0", path: "src/openpi/training/config.py", commit: "9d93078", url: "https://github.com/OpenDriveLab/kai0/blob/9d93078/src/openpi/training/config.py" },
      c5: { kind: "code", repo: "OpenDriveLab/kai0", path: "train_deploy_alignment/inference/agilex/inference/agilex_inference_openpi_temporal_smoothing.py", commit: "9d93078", url: "https://github.com/OpenDriveLab/kai0/blob/9d93078/train_deploy_alignment/inference/agilex/inference/agilex_inference_openpi_temporal_smoothing.py" }
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p1"],
      params: null,
      vision: ["3 RealSense D435i views (1 head, 2 wrist), 640 × 480 at 30 Hz", "p3"],
      backbone: ["π0.5 VLM: Gemma 2B, 18 × 2,048, 8 query / 1 KV heads", "c2", "c3"],
      head: ["Action expert Gemma 300M, 18 × 1,024, time via adaRMSNorm", "c1", "c2", "c3"],
      output: ["K = 50 joint actions for 2 × (6 arm + 1 gripper) = 14-D, padded to 32", "p3", "c3", "c5"],
      attention: ["Blockwise causal, as in π0.5", "c1"],
      cond: ["Stage Advantage: binary optimality label for AWBC (top ε = 0.3)", "p2", "p3"],
      steps: ["10 Euler flow steps (openpi default)", "c1"],
      chunk: ["K = 50; overlapping chunks blended by temporal chunk-wise smoothing", "p3", "c5"],
      rate: ["Execution 100 Hz; low-level joint control 100–200 Hz", "p3"],
      train: ["≈20 h demos per task; full fine-tune 80,000 steps, batch 128, 8 A100s", "p3"]
    },
    changes: [
      "Full-parameter fine-tune on ≈20 h of garment demos per task.",
      "Model Arithmetic: 4 checkpoints trained on data subsets merged in weight space.",
      "Stage Advantage: a π0.5-shaped estimator with a value head labels data for advantage-weighted BC.",
      "Heuristic DAgger and spatio-temporal augmentation expand the training set.",
      "Temporal chunk-wise smoothing blends overlapping chunks at deployment."
    ],
    diffRows: ["cond", "chunk", "rate", "train"],
    blueprint: {
      headline: "χ0: π0.5, post-trained three ways",
      note: "The deployed policy is π0.5 unchanged: Gemma 2B and a 300M action expert share attention at every layer, and the expert gets the flow time through adaRMSNorm. χ0 adds no layers to it. The advantage estimator reuses the same two-expert network with a small value MLP on the state token; its labels decide which demos count as positive.",
      towers: [
        { mod: "vlm", title: "Gemma 2B (π0.5 VLM)", sub: "SigLIP images + prompt",
          input: { label: "3 images + prompt", caption: "head + 2 wrist views, task text" },
          rows: [
            { t: "embed", label: "SigLIP + token embedding", call: ["Prompt up to 200 tokens (π0.5)", "c3"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Multi-query attention", side: "RoPE", call: ["8 query heads, 1 KV head, dim 256", "c2"], callDy: -26, zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["2,048 → 16,384 → 2,048", "c2"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" } ],
          output: { label: "prefix keys / values" } },
        { mod: "expert", title: "Action expert (300M)", sub: "flow matching, adaRMS time",
          input: { label: "Noisy chunk Aτ", caption: "50 × 32, time τ" },
          rows: [
            { t: "linear", label: "Action in-projection", call: ["32 → 1,024", "c1", "c2"] },
            { t: "mlp", label: "Time MLP → adaRMS cond", side: "AdaLN" },
            { t: "block", n: "18", rows: [
              { t: "adaln", label: "adaRMSNorm 1" },
              { id: "att", t: "attn", label: "Masked MQA (shared)" },
              { t: "add", span: 2 },
              { t: "adaln", label: "adaRMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["1,024 → 4,096 → 1,024", "c2"], zoom: { k: "glu", act: "GELU", d: "1,024", ff: "4,096", title: "Expert GeGLU" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Out-projection → vθ", call: ["1,024 → 32", "c1", "c2"], zoom: { k: "rows", title: "Temporal chunk-wise smoothing", rows: ["New chunk arrives mid-execution", "Drop first k steps (latency)", "Blend overlap with current chunk", "Append the new tail, publish"] } } ],
          output: { label: "velocity for 50 actions" } },
        { mod: "adv", title: "Stage Advantage", sub: "π0.5 + value head", compact: true,
          input: { label: "Frame pair + stage", caption: "same episode, any two times" },
          rows: [
            { t: "mlp", label: "π0.5 network, value only", call: ["Action-loss weight 0", "c4"] },
            { t: "linear", label: "Value MLP on state token", call: ["1,024 → 1,024 → 1, tanh", "c1"] },
            { t: "mlp", label: "Top ε → positive label", call: ["ε = 0.3", "p2", "p3"], zoom: { k: "rows", title: "Model Arithmetic", rows: ["Train on each data subset", "θ = Σ αᵢ θᵢ over checkpoints", "αᵢ from DAgger validation loss", "Inverse-loss or greedy weights"] } } ],
          output: { label: "advantage labels" } }
      ],
      links: [],
      shared: [{ a: ["vlm", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "vlm", role: "vlm", name: "Gemma 2B (π0.5)", sub: "18 × 2048 · MQA", col: 0, frozen: false, short: "Gemma 2B",
        stack: { rows: [
          { t: "in", label: "[3 images | prompt]", dims: "prefix", c: "data-1" },
          { t: "embed", label: "SigLIP image tokens + text embedding" },
          { t: "block", label: "Gemma decoder block", n: "18", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MQA · 8 Q heads, 1 KV head, dim 256 · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 2,048 → 16,384" }, { t: "add", span: 2 } ] },
          { t: "out", label: "prefix K, V", dims: "shared with the expert", c: "data-2" } ],
          facts: [["Width / depth", ["2,048 / 18", "c2"]], ["MLP", ["16,384", "c2"]], ["Heads", ["8 query, 1 KV, dim 256", "c2"]], ["Fine-tune", ["full parameters", "p3"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert (300M)", sub: "18 × 1024 · adaRMS", col: 1, frozen: false, main: true, short: "Expert",
        stack: { rows: [
          { t: "in", label: "noisy chunk Aτ + time τ", dims: "50 × 32", c: "data-3" },
          { t: "linear", label: "Action in-projection → 1,024" },
          { t: "mlp", label: "Time MLP → adaRMS condition" },
          { t: "block", label: "Expert block", n: "18", rows: [
            { t: "adaln", label: "adaRMSNorm" }, { t: "attn", label: "Joint attention with the VLM prefix" }, { t: "add", span: 2 },
            { t: "adaln", label: "adaRMSNorm" }, { t: "ffn", label: "GeGLU 1,024 → 4,096" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "Out-projection → 32" },
          { t: "out", label: "velocity vθ", dims: "K = 50", c: "data-3" } ],
          facts: [["Width / depth", ["1,024 / 18", "c2"]], ["MLP", ["4,096", "c2"]], ["Chunk", ["K = 50, action dim 32 (padded)", "p3", "c3"]], ["Training", ["80,000 steps, batch 128, lr 2.5e-5", "p3"]]] } },
      { id: "adv", role: "critic", roleLabel: "Advantage estimator", name: "Stage Advantage", sub: "π0.5 + value MLP", col: 2, frozen: false, short: "Advantage",
        stack: { rows: [
          { t: "in", label: "two frames + stage prompt", dims: "same episode", c: "data-1" },
          { t: "mlp", label: "π0.5 two-expert network" },
          { t: "linear", label: "Value MLP 1,024 → 1,024 → 1, tanh" },
          { t: "out", label: "relative progress", dims: "thresholded to a binary label", c: "data-4" } ],
          facts: [["Head", ["3-layer MLP, SiLU, tanh output", "c1"]], ["Threshold", ["top ε = 0.3 positive", "p2"]], ["Stages", ["2 / 4 / 3 for tasks A / B / C", "p2"]]] } }
    ],
    inputs: [
      { to: "vlm", mod: "vision", label: "3 camera views", n: "640 × 480", k: 3 },
      { to: "vlm", mod: "lang", label: "task prompt", n: "text", k: 2 },
      { to: "expert", mod: "action", label: "noisy chunk Aτ", n: "50 × 32", k: 5, noisy: true },
      { to: "adv", mod: "vision", label: "frame pair", n: "2 frames", k: 2 }
    ],
    outputs: [{ from: "expert", mod: "action", label: "velocity vθ", n: "50 × 32", k: 5 }],
    links: [
      { from: "vlm", to: "expert", kind: "joint-attn", label: "shared self-attn" },
      { from: "expert", to: "adv", kind: "two-stage", label: "advantage labels|→ AWBC data" }
    ],
    mask: { name: "Blockwise causal (π0.5)", ref: "c1", axes: [{ label: "images + prompt", short: "img+ℓ", mod: "vision" }, { label: "actions", short: "A", mod: "action" }], m: ["10", "11"],
      note: "χ0 keeps π0.5's attention pattern unchanged; the prefix never attends to action tokens." },
    callouts: [
      "§IV-E reports <b>greedy search</b> as the best merging strategy, while App. C.2 says the 4 checkpoints are merged with <b>inverse-loss</b> weights.",
      "Table I: 80,000 steps and batch 128; the released pi05_*_normal configs use <b>100,000</b> steps and batch <b>256</b>."
    ]
  });
})();
