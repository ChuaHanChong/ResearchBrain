/* Architecture specs, topic B4 (vision-language-action models), part B: π0.5, Knowledge Insulation, GR00T N1, SmolVLA, π0.7, CogACT, RT-H, Hi Robot.
   Numbers from the papers and the official code; see sources. */
(function () {
  var RB = window.RB;
  var OPENPI = "https://github.com/Physical-Intelligence/openpi/blob/215abfb/";
  var GR00T = "https://github.com/NVIDIA/Isaac-GR00T/blob/755876a/";
  var LEROBOT = "https://github.com/huggingface/lerobot/blob/e0d5021/";
  var COGACT = "https://github.com/microsoft/CogACT/blob/b174a1b/";
  function opi(path) { return { kind: "code", repo: "Physical-Intelligence/openpi", path: path, commit: "215abfb", url: OPENPI + path }; }

  /* ================= π0.5 ================= */
  RB.arch.spec({
    id: "pi0-5", method: "pi0-5", name: "π0.5", year: 2025, parent: "pi0",
    diffRows: ["backbone", "head", "output", "attention", "cond", "train"],
    figRef: "Black et al. Fig. 3 · §IV · App. E", prov: "",
    lede: "π0's two-expert transformer, taught in two stages: first the VLM learns robot actions as discrete FAST tokens, then a fresh 300M flow expert is added. At run time the same model writes a subtask in text, then denoises actions for it.",
    sources: {
      p1: { kind: "paper", ref: "Black et al. 2025 (π0.5), §IV-A, IV-B", url: "https://arxiv.org/abs/2504.16054" },
      p2: { kind: "paper", ref: "Black et al. 2025 (π0.5), §IV-D, IV-E (post-training, robot system)", url: "https://arxiv.org/abs/2504.16054" },
      p3: { kind: "paper", ref: "Black et al. 2025 (π0.5), App. E and Fig. 18 (model details, mask)", url: "https://arxiv.org/abs/2504.16054" },
      p4: { kind: "paper", ref: "Black et al. 2025 (π0.5), Fig. 3 (model overview)", url: "https://arxiv.org/abs/2504.16054" },
      c1: opi("src/openpi/models/gemma.py"),
      c2: opi("src/openpi/models/pi0.py"),
      c3: opi("src/openpi/models/pi0_config.py"),
      c4: opi("src/openpi/models/tokenizer.py"),
      c5: opi("src/openpi/models/siglip.py"),
      c6: opi("src/openpi/models/model.py"),
      c7: opi("README.md")
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p1"],
      params: ["SigLIP 400M + Gemma 2B VLM, plus a 300M action expert", "p3", "p4"],
      vision: ["SigLIP So400m/14 at 224 × 224; 4 cameras for the subtask, wrist + front cameras for actions", "p2", "c6"],
      backbone: ["Gemma 2B: 18 layers, width 2,048, MQA; also emits text and FAST action tokens", "p1", "p3", "c1"],
      head: ["Action expert: 18 layers, width 1,024, MLP 4,096; randomly initialised at post-training", "p2", "p3", "c1"],
      output: ["Subtask text ℓ̂, then velocity vθ on H = 50 actions (padded to 32 dims)", "p1", "p3", "c3"],
      attention: ["Prefix bidirectional; FAST tokens causal; flow tokens see prefix and each other, never FAST", "p3"],
      cond: ["τ → sinusoid → 2-layer swish MLP → adaptive RMSNorm in every expert layer", "p3", "c1", "c2"],
      steps: ["10 flow steps, after the subtask text is decoded", "p1"],
      chunk: ["H = 50", "p3", "c3"],
      rate: ["Target poses and base velocities at 50 Hz", "p2"],
      latency: null,
      train: ["280k steps FAST-only pre-training (α = 0), then 80k steps with α = 10; 97.6 % of phase-1 examples are not household mobile data", "p1", "p2"]
    },
    changes: [
      "Robot state enters as <b>discretized text tokens</b> in the VLM prompt, not as a continuous token for the expert.",
      "The VLM also predicts <b>FAST action tokens</b> and text (subtasks, answers, boxes); pre-training uses only these discrete targets.",
      "The action expert arrives only in <b>post-training</b>, from random init, trained jointly with next-token loss (α = 10).",
      "Flow time τ enters every expert layer through <b>adaptive RMSNorm</b> (scale, shift, gate), not by mixing into action tokens.",
      "<b>Hierarchical inference</b> in one model: decode a subtask ℓ̂ first, then denoise actions conditioned on it."
    ],
    blueprint: {
      headline: "π0.5: one model, text then actions",
      note: "Same lockstep layout as π0: at each of 18 layers Gemma's tokens and the expert's tokens share one masked self-attention. New: Gemma's prefix now includes discretized state and ends in a text head (subtasks, FAST tokens), while τ modulates every expert norm.",
      towers: [
        { mod: "siglip", title: "SigLIP So400m/14", sub: "vision encoder", compact: true,
          input: { label: "Image patches 14 × 14", caption: "224 × 224, up to 4 cameras" },
          rows: [
            { t: "embed", label: "Patch embedding layer", call: ["Embedding dimension of 1,152", "c5"] },
            { t: "block", n: "27", rows: [
              { t: "attn", label: "Multi-head attention", call: ["16 heads, bidirectional", "c5"] },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 4,304", "c5"] } ] },
            { t: "linear", label: "Linear projection", call: ["1,152 → 2,048", "c2"] } ],
          output: { label: "256 image tokens per camera" } },
        { mod: "gemma", title: "Gemma 2B", sub: "VLM backbone (PaliGemma init)",
          input: { label: "Images + prompt + state", caption: "state as 256-bin text tokens" },
          rows: [
            { t: "embed", label: "Token embedding layer", call: ["Vocabulary of 257,152 · 2,048-d; prompt ≤ 200 tokens", "c1", "c3"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention", side: "RoPE", call: ["8 query heads share 1 KV head (dim 256)", "c1"], callDy: -26, zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Hidden layer dimension of 16,384", "c1"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head: text + FAST logits", call: ["Cross-entropy on subtasks, answers, FAST tokens", "p1"] } ],
          output: { label: "subtask ℓ̂ (text); prefix K, V for the expert" } },
        { mod: "expert", title: "Action expert", sub: "Gemma-style, 300M, added at post-training",
          input: { label: "Noisy actions Aτ", caption: "H = 50 action tokens, time τ" },
          rows: [
            { t: "linear", label: "Action input projection", call: ["32 → 1,024, one linear layer", "p3", "c2"] },
            { id: "tmlp", t: "mlp", label: "Time MLP on sinusoid(τ)", call: ["swish(W₂ · swish(W₁ · φ(τ)))", "p3", "c2"], zoom: { k: "rows", title: "Adaptive RMSNorm", rows: ["τ → sinusoid φ(τ) → time MLP", "Dense → scale, shift, gate", "x̂ · (1 + scale) + shift", "sub-layer (attention or FFN)", "residual: x + gate · y"] } },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "Adaptive RMSNorm 1", side: "AdaLN" },
              { id: "att", t: "attn", label: "Masked multi-query attention", call: ["Sees prefix and all actions, not FAST tokens", "p3"] },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "Adaptive RMSNorm 2", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Width 1,024 · hidden layer dimension of 4,096", "p3", "c1"], zoom: { k: "glu", act: "GELU", d: "1,024", ff: "4,096", title: "Feed forward (GeGLU), expert" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Final adaptive RMSNorm" },
            { t: "linear", label: "Action output projection", call: ["1,024 → 32 (padded action dim)", "c2", "c3"] } ],
          output: { label: "velocity vθ for 50 actions; 10 steps" } }
      ],
      links: [{ from: "siglip", to: "gemma", toRow: "input", label: "image tokens" }],
      shared: [{ a: ["gemma", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "27 × 1152 · 16 heads", col: 0, frozen: false, short: "SigLIP" },
      { id: "gemma", role: "vlm", name: "Gemma 2B (PaliGemma)", sub: "18 × 2048 · MQA · text out", col: 1, frozen: false, short: "Gemma 2B", main: true,
        stack: { rows: [
          { t: "in", label: "[images | prompt | discretized state]", dims: "prefix, bidirectional", c: "data-2" },
          { t: "embed", label: "Token embedding", dims: "vocab 257,152 → 2048" },
          { t: "block", label: "Gemma decoder block (pre-norm)", n: "18", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MQA · 8 query heads, 1 KV head · RoPE", note: "shared with the action expert's tokens in the same layer" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 2048 → 16,384 → 2048" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "LM head", dims: "subtask text, answers, FAST tokens" },
          { t: "out", label: "text ℓ̂ · prefix keys and values", dims: "K, V cached for the flow steps", c: "data-2" } ],
          facts: [["Width / depth", ["2048 / 18", "p3", "c1"]], ["Heads", ["8 query, 1 KV, head dim 256 (code)", "c1"]], ["State input", ["256 bins per dimension, written as text", "c4"]], ["Prompt length", ["200 tokens (π0: 48)", "c3"]], ["Outputs", ["text and FAST tokens; flow actions via the expert", "p1"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert", sub: "18 × 1024 · adaRMSNorm", col: 2, frozen: false, params: "300M", short: "Action expert",
        stack: { rows: [
          { t: "in", label: "noisy actions Aτ, time τ", dims: "50 tokens", c: "data-3" },
          { t: "linear", label: "Action projection", dims: "32 → 1024" },
          { t: "mlp", label: "Time MLP: swish(W₂ swish(W₁ φ(τ)))", dims: "conditions every norm" },
          { t: "block", label: "Expert block, same layer index as Gemma", n: "18", rows: [
            { t: "norm", label: "Adaptive RMSNorm (scale, shift)", side: "cond" }, { t: "attn", label: "Joint attention over [prefix ‖ actions]" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "Adaptive RMSNorm (scale, shift)", side: "cond" }, { t: "ffn", label: "GeGLU 1024 → 4096 → 1024" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "norm", label: "Final adaptive RMSNorm" },
          { t: "linear", label: "Output projection", dims: "1024 → 32" },
          { t: "out", label: "velocity vθ", dims: "50 × 32", c: "data-3" } ],
          facts: [["Width / depth", ["1024 / 18", "p3", "c1"]], ["MLP", ["4096", "p3", "c1"]], ["Time input", ["adaptive RMSNorm, zero-initialised modulation", "p3", "c1"]], ["Init", ["random, at the start of post-training", "p2"]]] } }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "cameras", n: "256 tokens each", k: 5 },
      { to: "gemma", mod: "lang", label: "task ℓ + state text", n: "≤ 200 tokens", k: 3 },
      { to: "expert", mod: "action", label: "noisy chunk Aτ, time τ", n: "H = 50", k: 5, noisy: true }
    ],
    outputs: [
      { from: "gemma", mod: "lang", label: "subtask ℓ̂ / FAST", n: "text tokens", k: 3 },
      { from: "expert", mod: "action", label: "velocity vθ", n: "50 × 32", k: 5 }
    ],
    links: [
      { from: "siglip", to: "gemma", kind: "prefix", label: "linear → 2048|256 tokens / image" },
      { from: "gemma", to: "expert", kind: "joint-attn", label: "shared self-attn", note: "the expert reads the prefix inside attention; no VLM token attends to the expert" }
    ],
    mask: { name: "Prefix · FAST · flow", ref: "p3", axes: [{ label: "prefix", short: "pre", mod: "vision" }, { label: "FAST tokens", short: "FAST", mod: "lang" }, { label: "flow actions", short: "A", mod: "action" }], m: ["100", "110", "101"],
      note: "FAST tokens are causal among themselves and exist only as training targets; flow tokens never see them, so the two action codes cannot leak into each other." },
    callouts: [
      "Paper App. E lists num_heads = 18 for Gemma 2B; the released openpi config uses 8 query heads and 1 KV head.",
      "openpi's README says the released π0.5 code supports <b>only the flow-matching head</b>; the FAST/text path of the paper is not in the public code.",
      "Time convention: the paper integrates τ from 0 (noise) to 1; openpi runs t from 1 (noise) to 0. This site uses the paper's."
    ]
  });

  /* ================= Knowledge Insulation ================= */
  RB.arch.spec({
    id: "knowledge-insulation", method: "knowledge-insulation", name: "Knowledge Insulation (π0 + KI)", year: 2025, parent: "pi0",
    diffRows: ["backbone", "attention", "train"],
    figRef: "Driess et al. Fig. 1 · §5 · App. B", prov: "",
    lede: "π0's architecture with a new training recipe: the VLM learns actions as FAST tokens with a next-token loss, while the flow expert learns continuous actions through a stop-gradient on the VLM's keys and values.",
    sources: {
      p1: { kind: "paper", ref: "Driess et al. 2025, Fig. 1 and §3 (architecture)", url: "https://arxiv.org/abs/2505.23705" },
      p2: { kind: "paper", ref: "Driess et al. 2025, §5.1 (joint training, Eq. 4)", url: "https://arxiv.org/abs/2505.23705" },
      p3: { kind: "paper", ref: "Driess et al. 2025, §5.2 (stop-gradient, Eqs. 5–6)", url: "https://arxiv.org/abs/2505.23705" },
      p4: { kind: "paper", ref: "Driess et al. 2025, App. B (dimensions, mask) and App. C (state)", url: "https://arxiv.org/abs/2505.23705" },
      p5: { kind: "paper", ref: "Driess et al. 2025, §4 (inference speeds)", url: "https://arxiv.org/abs/2505.23705" },
      c1: opi("src/openpi/models/gemma.py"),
      c2: opi("README.md"),
      c3: opi("src/openpi/models/siglip.py")
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p1"],
      params: ["3B VLM backbone + 300M action expert", "p1", "p4"],
      vision: ["As π0 (PaliGemma's SigLIP); multi-view images", "p1"],
      backbone: ["Gemma 2B: 18 layers, width 2,048; trained with next-token loss on text + FAST tokens", "p2", "p4"],
      head: ["Action expert: 18 layers, width 1,024, MLP 4,096", "p4"],
      output: ["Continuous action chunk from the expert; FAST tokens are a training target only", "p2"],
      attention: ["Prefix bidirectional; FAST causal; flow tokens see prefix and each other; FAST ↔ flow blocked", "p4"],
      cond: null,
      steps: null, chunk: null, rate: null,
      latency: ["Motivation: π0-FAST needs ≈750 ms per 1-second chunk on an RTX 4090", "p5"],
      train: ["One stage: L = CE(text + FAST) + α · flow loss with α = 1; co-trained with VLM data", "p2", "p3"]
    },
    changes: [
      "The backbone is also trained to predict <b>FAST action tokens</b> and VLM data with next-token loss, in the same run.",
      "<b>Stop-gradient</b> on the backbone's keys and values wherever action-expert queries attend to them (Eqs. 5–6).",
      "FAST tokens and flow tokens are masked from each other.",
      "Loss weight α = 1: the flow loss now touches only the expert's weights.",
      "State can be text, special tokens or a continuous projection (App. C)."
    ],
    blueprint: {
      headline: "KI: a one-way valve in attention",
      note: "Weights and layout are π0's: SigLIP tokens join Gemma's prefix, and Gemma and the expert share one attention per layer. The difference is where gradients may flow: the expert reads sg(K), sg(V) of the backbone, so only the cross-entropy loss trains the VLM.",
      towers: [
        { mod: "siglip", title: "SigLIP", sub: "vision encoder (PaliGemma)", compact: true,
          input: { label: "Image patches", caption: "multi-view camera images" },
          rows: [
            { t: "block", n: "27", rows: [{ t: "attn", label: "ViT block (attn + MLP)", call: ["Width 1,152, 16 heads", "c3"] }] },
            { t: "linear", label: "Linear projection → 2,048" } ],
          output: { label: "image tokens" } },
        { mod: "gemma", title: "Gemma 2B", sub: "VLM backbone, trained by cross-entropy",
          input: { label: "Images + text + state", caption: "then FAST action tokens (training)" },
          rows: [
            { t: "embed", label: "Token embedding layer" },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention", side: "RoPE", call: ["18 heads in the paper; 8 query / 1 KV in openpi", "p4", "c1"], callDy: -26, zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention (openpi)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Width 2,048 · hidden layer dimension of 16,384", "p4"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head: text + FAST logits", call: ["Next-token loss, the only gradient into the VLM", "p2", "p3"], zoom: { k: "rows", title: "Loss (Eq. 4)", rows: ["CE on text + FAST tokens", "+ α ‖ω − a − fᵃ(aτ,ω)‖², α = 1", "flow term off if no actions", "VLM gets only the CE gradient"] } } ],
          output: { label: "text / FAST tokens; keys and values" } },
        { mod: "expert", title: "Action expert", sub: "300M, trained by flow matching",
          input: { label: "Noisy actions aτ,ω", caption: "flow time τ, noise ω" },
          rows: [
            { t: "linear", label: "Action input projection" },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Attention with sg(K_b), sg(V_b)", call: ["Gradient stops at backbone keys and values", "p3"], zoom: { k: "rows", title: "Stop-gradient attention", rows: ["queries Qₐ(Xₐ) from action tokens", "keys [sg(K_b) ‖ Kₐ] + mask A", "softmax → P_ab, P_aa", "Eₐ = P_ab · sg(V_b) + P_aa · Vₐ"] } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward", call: ["Width 1,024 · hidden layer dimension of 4,096", "p4"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Action output projection" } ],
          output: { label: "flow vector field → continuous actions" } }
      ],
      links: [{ from: "siglip", to: "gemma", toRow: "input", label: "image tokens" }],
      shared: [{ a: ["gemma", "att"], b: ["expert", "att"], label: "one attention, one-way gradient" }]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP", sub: "PaliGemma vision tower", col: 0, frozen: false, short: "SigLIP" },
      { id: "gemma", role: "vlm", name: "Gemma 2B (PaliGemma)", sub: "18 × 2048 · CE loss only", col: 1, frozen: false, short: "VLM 3B", main: true,
        stack: { rows: [
          { t: "in", label: "[images | text | state] then FAST tokens", dims: "prefix bidirectional, FAST causal", c: "data-2" },
          { t: "block", label: "Gemma decoder block", n: "18", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "Masked MQA · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 2048 → 16,384 → 2048" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "LM head", dims: "text + FAST logits" },
          { t: "out", label: "tokens · keys and values", dims: "K, V read by the expert under sg", c: "data-2" } ],
          facts: [["Width / depth", ["2048 / 18", "p4"]], ["MLP", ["16,384", "p4"]], ["Heads", ["18 (paper) · 8 query, 1 KV (openpi)", "p4", "c1"]], ["Loss", ["next-token cross-entropy only", "p2", "p3"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert", sub: "18 × 1024 · MLP 4096", col: 2, frozen: false, params: "300M", short: "Action expert",
        stack: { rows: [
          { t: "in", label: "noisy actions aτ,ω", dims: "chunk of H actions", c: "data-3" },
          { t: "block", label: "Expert block", n: "18", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "Attention over [sg(K_b, V_b) ‖ Kₐ, Vₐ]" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "MLP 1024 → 4096 → 1024" }, { t: "add", span: 2 } ] },
          { t: "out", label: "flow ω − a", dims: "integrated to actions", c: "data-3" } ],
          facts: [["Width / depth", ["1024 / 18", "p4"]], ["MLP", ["4096", "p4"]], ["Loss weight", ["α = 1", "p3"]], ["Gradient", ["stops at backbone K, V", "p3"]]] } }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "multi-view images", n: "per camera", k: 4 },
      { to: "gemma", mod: "lang", label: "instruction ℓ + state", n: "text / special / continuous", k: 3 },
      { to: "expert", mod: "action", label: "noisy chunk aτ,ω", n: "H actions", k: 5, noisy: true }
    ],
    outputs: [
      { from: "gemma", mod: "lang", label: "text + FAST (train)", n: "cross-entropy", k: 3 },
      { from: "expert", mod: "action", label: "continuous actions", n: "flow", k: 5 }
    ],
    links: [
      { from: "siglip", to: "gemma", kind: "prefix", label: "image tokens" },
      { from: "gemma", to: "expert", kind: "joint-attn", label: "shared attn|stop-grad on K, V", note: "forward pass as π0; backward pass cannot reach the VLM from the expert" }
    ],
    mask: { name: "Prefix · FAST · flow", ref: "p4", axes: [{ label: "prefix", short: "pre", mod: "vision" }, { label: "FAST tokens", short: "FAST", mod: "lang" }, { label: "flow actions", short: "A", mod: "action" }], m: ["100", "110", "101"],
      note: "Same mask as π0.5. Information flows one way, from VLM to expert; the stop-gradient makes the gradient flow one way too." },
    callouts: [
      "Paper App. B lists num_heads = 18 for the 2B backbone; openpi's Gemma 2B config uses 8 query heads and 1 KV head.",
      "No official KI training code: openpi's README says π0.5 checkpoints were trained with knowledge insulation, but the repo supports only the flow-matching head.",
      "Without the FAST loss the stop-gradient would starve the backbone; freezing it instead gives 0 % on some tasks (§4, Fig. 8)."
    ]
  });

  /* ================= GR00T N1 ================= */
  RB.arch.spec({
    id: "gr00t-n1", method: "gr00t-n1", name: "GR00T N1", year: 2025, parent: "pi0",
    diffRows: ["vision", "backbone", "head", "attention", "cond", "steps", "chunk", "rate"],
    figRef: "NVIDIA Fig. 3 · §2.1 · Table 6", prov: "GR00T-N1-2B release config",
    lede: "Dual system: a frozen Eagle-2 VLM, cut to its first 12 layers, reads images and text at 10 Hz; a 16-layer flow-matching DiT cross-attends to those features and emits 16-step action chunks through per-embodiment MLP decoders.",
    sources: {
      p1: { kind: "paper", ref: "NVIDIA (Bjorck et al.) 2025, §2.1 and Fig. 3", url: "https://arxiv.org/abs/2503.14734" },
      p2: { kind: "paper", ref: "NVIDIA 2025, §1–2 (system rates, parameters, latency)", url: "https://arxiv.org/abs/2503.14734" },
      p3: { kind: "paper", ref: "NVIDIA 2025, §2.1 flow matching (Eq. 1, K steps)", url: "https://arxiv.org/abs/2503.14734" },
      p4: { kind: "paper", ref: "NVIDIA 2025, §2.2–2.3 and Table 6 (data, training)", url: "https://arxiv.org/abs/2503.14734" },
      c1: { kind: "code", repo: "NVIDIA/Isaac-GR00T", path: "gr00t/model/action_head/flow_matching_action_head.py", commit: "755876a", url: GR00T + "gr00t/model/action_head/flow_matching_action_head.py" },
      c2: { kind: "code", repo: "NVIDIA/Isaac-GR00T", path: "gr00t/model/action_head/cross_attention_dit.py", commit: "755876a", url: GR00T + "gr00t/model/action_head/cross_attention_dit.py" },
      c3: { kind: "code", repo: "NVIDIA/Isaac-GR00T", path: "gr00t/model/backbone/eagle_backbone.py", commit: "755876a", url: GR00T + "gr00t/model/backbone/eagle_backbone.py" },
      c4: { kind: "code", repo: "NVIDIA/Isaac-GR00T", path: "gr00t/model/backbone/eagle2_hg_model/config.json", commit: "755876a", url: GR00T + "gr00t/model/backbone/eagle2_hg_model/config.json" },
      c5: { kind: "code", repo: "NVIDIA/Isaac-GR00T", path: "gr00t/model/backbone/eagle2_hg_model/modeling_eagle_chat.py", commit: "755876a", url: GR00T + "gr00t/model/backbone/eagle2_hg_model/modeling_eagle_chat.py" },
      c6: { kind: "code", repo: "nvidia/GR00T-N1-2B (Hugging Face)", path: "config.json", commit: "fc87958", url: "https://huggingface.co/nvidia/GR00T-N1-2B/blob/fc879581ca32f4f6d6e02cf0cc80452f6b0c3873/config.json" }
    },
    summary: {
      pattern: ["Dual-system VLA (slow VLM + fast policy)", "p2"],
      params: ["2.2B total, 1.34B in the VLM", "p2"],
      vision: ["SigLIP-2 at 224 × 224; pixel shuffle → 64 tokens per frame", "p1", "c4", "c6"],
      backbone: ["Eagle-2 LLM (SmolLM2) cut to 12 of 24 layers, width 2,048; frozen", "p1", "c3", "c4", "c6"],
      head: ["DiT: 16 layers, width 1,536 (32 heads × 48); cross- and self-attention alternate", "c2", "c6"],
      output: ["Velocity on H = 16 actions (padded to 32 dims) via an embodiment-specific MLP", "p1", "c1", "c6"],
      attention: ["Even DiT layers cross-attend to VL tokens; odd layers self-attend over [state ‖ actions]", "p1", "c2", "c6"],
      cond: ["AdaLN (scale, shift) from the timestep embedding in every block", "p1", "c2"],
      steps: ["K = 4 Euler steps (paper); the release config sets 16", "p3", "c6"],
      chunk: ["H = 16", "p1", "c6"],
      rate: ["VLM 10 Hz on an L40; actions at 120 Hz", "p2"],
      latency: ["63.9 ms per 16-action chunk on an L40 (bf16)", "p2"],
      train: ["Data pyramid: human video (latent actions), sim + neural trajectories, real robot; batch 16,384, 200k steps", "p4"]
    },
    changes: [
      "The VLM and action module meet by <b>cross-attention</b>, not shared self-attention; features come from LLM layer 12 of 24.",
      "The action module is a <b>DiT</b> with AdaLN timestep conditioning, alternating cross- and self-attention layers.",
      "State and actions pass through <b>embodiment-specific MLPs</b> (up to 32 embodiments) in and out of the DiT.",
      "The LLM is frozen; images are cut to 64 tokens per frame by pixel shuffle.",
      "Shorter chunks and fewer steps: H = 16, K = 4 (paper)."
    ],
    blueprint: {
      headline: "GR00T N1: frozen VLM, cross-attending DiT",
      note: "SigLIP-2 tokens and text run through the first 12 layers of the frozen LLM once per observation. The DiT reads those features in its 8 cross-attention layers; its 8 self-attention layers mix the state token with the 16 noisy action tokens. It repeats K times.",
      towers: [
        { mod: "siglip", title: "SigLIP-2", sub: "vision encoder (trained)", compact: true,
          input: { label: "Image patches 14 × 14", caption: "224 × 224 per frame" },
          rows: [
            { t: "embed", label: "Patch embedding layer", call: ["Embedding dimension of 1,152", "c4"] },
            { t: "block", n: "27", rows: [
              { t: "attn", label: "Multi-head attention", call: ["16 heads", "c4"] },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 4,304", "c4"] } ] },
            { t: "pool", label: "Pixel shuffle (2 × 2 → 1)", call: ["256 → 64 tokens, 4,608-d", "c4", "c6"] },
            { t: "mlp", label: "MLP projector", call: ["4,608 → 2,048 → 2,048 (GELU)", "c5"] } ],
          output: { label: "64 image tokens per frame" } },
        { mod: "llm", title: "Eagle-2 LLM (SmolLM2)", sub: "frozen, top 12 layers removed",
          input: { label: "Image tokens + text", caption: "chat template, task instruction" },
          rows: [
            { t: "embed", label: "Token embedding layer", call: ["Width 2,048", "c4"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["32 heads, 32 KV heads", "c4"], zoom: { k: "heads", q: 32, kv: 32, hd: 64, title: "Eagle-2 LLM attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden layer dimension of 8,192", "c4"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Linear 2,048 → 1,536", call: ["Layer-12 features; 24 layers in the full LLM", "p1", "c3", "c4"] } ],
          output: { label: "vision-language tokens φₜ" } },
        { mod: "dit", title: "Action DiT", sub: "flow matching, 16 layers",
          input: { label: "State qₜ + noisy Aτ", caption: "1 state token + 16 action tokens" },
          rows: [
            { t: "mlp", label: "Embodiment MLPs: state, action", call: ["State 64 → 1,024 → 1,536; action 32 → 1,536", "c1", "c6"], zoom: { k: "rows", title: "Embodiment-specific encoders", rows: ["pick weights W[embodiment id]", "state: Linear → ReLU → Linear", "action: W₁a ‖ sinusoid(τ) → W₂", "swish → W₃, + positions"] } },
            { t: "block", n: "8", label: "cross + self pair", rows: [
              { id: "ca", t: "norm", label: "LayerNorm · scale, shift", side: "AdaLN", zoom: { k: "rows", title: "AdaLN in the DiT", rows: ["timestep → sinusoid → MLP", "SiLU → Linear → scale, shift", "LN(x) · (1 + scale) + shift", "no gate; second norm is plain LN"] } },
              { t: "attn", label: "Cross-attention to φₜ", call: ["32 heads × 48 = width 1,536", "c2", "c6"], zoom: { k: "heads", q: 32, kv: 32, hd: 48, title: "DiT attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward (GELU)" },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · scale, shift", side: "AdaLN" },
              { t: "attn", label: "Self-attention: state + actions" },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward (GELU)" },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "AdaLN final layer", call: ["1,536 → 1,024", "c2", "c6"] },
            { t: "mlp", label: "Embodiment action decoder", call: ["1,024 → 1,024 → 32, last 16 tokens", "c1", "c6"] } ],
          output: { label: "velocity for 16 actions; K Euler steps" } }
      ],
      links: [
        { from: "llm", to: "dit", toRow: "ca", label: "VL tokens (layer 12)" },
        { from: "siglip", to: "llm", toRow: "input", label: "64 tokens / frame" }
      ]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP-2", sub: "27 × 1152 · 64 tok/frame", col: 0, frozen: false, short: "SigLIP-2" },
      { id: "llm", role: "vlm", name: "Eagle-2 LLM (SmolLM2)", sub: "12 of 24 layers · 2048", col: 1, frozen: true, short: "Eagle-2",
        stack: { rows: [
          { t: "in", label: "[64 image tokens per frame | text]", dims: "chat format", c: "data-2" },
          { t: "block", label: "Llama-style decoder block", n: "12", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MHA · 32 heads · RoPE · causal" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 2048 → 8192 → 2048" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "Linear 2048 → 1536", dims: "trainable projector" },
          { t: "out", label: "VL tokens φₜ", dims: "keys and values for the DiT", c: "data-2" } ],
          facts: [["Layers used", ["12 of 24 (select_layer = 12)", "p1", "c3", "c6"]], ["Width", ["2048", "c4"]], ["Heads", ["32 query, 32 KV", "c4"]], ["MLP", ["8192 (SiLU)", "c4"]], ["Trainable", ["no (tune_llm = false)", "p4", "c6"]]] } },
      { id: "dit", role: "action-head", roleLabel: "Action DiT (System 1)", name: "Flow-matching DiT", sub: "16 × 1536 · 32 heads", col: 2, frozen: false, main: true, short: "DiT",
        stack: { rows: [
          { t: "in", label: "[state token | 16 noisy action tokens]", dims: "embodiment MLPs → 1536", c: "data-3" },
          { t: "block", label: "Cross + self pair", n: "8", rows: [
            { t: "adaln", label: "AdaLN(τ) → cross-attention to φₜ", side: "cond" }, { t: "add", span: 1 }, { t: "ffn", label: "LN → GELU MLP" }, { t: "add", span: 1 },
            { t: "adaln", label: "AdaLN(τ) → self-attention", side: "cond" }, { t: "add", span: 1 }, { t: "ffn", label: "LN → GELU MLP" }, { t: "add", span: 1 } ] },
          { t: "norm", label: "AdaLN final layer · Linear 1536 → 1024" },
          { t: "mlp", label: "Embodiment action decoder", dims: "1024 → 1024 → 32" },
          { t: "out", label: "velocity on 16 actions", dims: "A ← A + V / K", c: "data-3" } ],
          facts: [["Layers / width / heads", ["16 / 1536 / 32 × 48", "c6"]], ["Interleave", ["odd layers self-attention only", "c2", "c6"]], ["Dropout", ["0.2", "c6"]], ["Time sampling", ["Beta((s − τ)/s; 1.5, 1), s = 0.999", "p3", "c6"]], ["Embodiments", ["up to 32 MLP heads", "c1"]]] } }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "camera frames", n: "64 tokens each", k: 4 },
      { to: "llm", mod: "lang", label: "instruction", n: "text tokens", k: 3 },
      { to: "dit", mod: "state", label: "state qₜ", n: "1 token", k: 1 },
      { to: "dit", mod: "action", label: "noisy Aτ, τ", n: "H = 16", k: 5, noisy: true }
    ],
    outputs: [{ from: "dit", mod: "action", label: "velocity → motor actions", n: "16 × 32", k: 5 }],
    links: [
      { from: "siglip", to: "llm", kind: "prefix", label: "pixel shuffle|64 tokens / frame" },
      { from: "llm", to: "dit", kind: "cross-attn", label: "layer-12 features", note: "the DiT's even layers use φₜ as keys and values" }
    ],
    mask: { name: "Cross-attention + full self-attention", ref: "p1", axes: [{ label: "VL tokens", short: "φ", mod: "vision" }, { label: "state", short: "q", mod: "state" }, { label: "actions", short: "A", mod: "action" }], m: ["100", "111", "111"],
      note: "VL tokens are computed once, causally, and never see the robot tokens; state and actions attend to each other freely in the self-attention layers." },
    callouts: [
      "Paper §2.1 uses K = 4 inference steps; the released GR00T-N1-2B config sets num_inference_timesteps = 16 (overridable at load time).",
      "Paper Eq. 1 regresses ε − Aₜ, but the code regresses Aₜ − ε, which is the direction its Euler update A + V/K needs.",
      "OpenWAM-style label: a <b>dual-system</b> design coupled by cross-attention (π0 couples its two experts by shared self-attention)."
    ]
  });

  /* ================= SmolVLA ================= */
  RB.arch.spec({
    id: "smolvla", method: "smolvla", name: "SmolVLA", year: 2025, parent: "pi0",
    diffRows: ["params", "vision", "backbone", "head", "attention", "train"],
    figRef: "Shukor et al. Fig. 1 · §3.1 · §4", prov: "lerobot default config",
    lede: "A 0.45B π0-style VLA: the first 16 layers of a frozen SmolVLM2-500M read 64 tokens per image, and a 0.75-width flow expert alternates cross-attention to the VLM's keys and values with joint self-attention.",
    sources: {
      p1: { kind: "paper", ref: "Shukor et al. 2025, §3.1 (architecture) and Fig. 1", url: "https://arxiv.org/abs/2506.01844" },
      p2: { kind: "paper", ref: "Shukor et al. 2025, §4.3 (implementation)", url: "https://arxiv.org/abs/2506.01844" },
      p3: { kind: "paper", ref: "Shukor et al. 2025, §4.7, Tables 6–13 (ablations)", url: "https://arxiv.org/abs/2506.01844" },
      p4: { kind: "paper", ref: "Shukor et al. 2025, §4.6 (asynchronous inference)", url: "https://arxiv.org/abs/2506.01844" },
      p5: { kind: "paper", ref: "Shukor et al. 2025, §1 (contributions)", url: "https://arxiv.org/abs/2506.01844" },
      c1: { kind: "code", repo: "huggingface/lerobot", path: "src/lerobot/policies/smolvla/configuration_smolvla.py", commit: "e0d5021", url: LEROBOT + "src/lerobot/policies/smolvla/configuration_smolvla.py" },
      c2: { kind: "code", repo: "huggingface/lerobot", path: "src/lerobot/policies/smolvla/smolvlm_with_expert.py", commit: "e0d5021", url: LEROBOT + "src/lerobot/policies/smolvla/smolvlm_with_expert.py" },
      c3: { kind: "code", repo: "huggingface/lerobot", path: "src/lerobot/policies/smolvla/modeling_smolvla.py", commit: "e0d5021", url: LEROBOT + "src/lerobot/policies/smolvla/modeling_smolvla.py" },
      c4: { kind: "code", repo: "HuggingFaceTB/SmolVLM2-500M-Video-Instruct (Hugging Face)", path: "config.json", commit: "7b375e1", url: "https://huggingface.co/HuggingFaceTB/SmolVLM2-500M-Video-Instruct/blob/7b375e1b73b11138ff12fe22c8f2822d8fe03467/config.json" }
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (interleaved cross- and self-attention)", "p1"],
      params: ["0.45B, of which ≈100M action expert", "p2"],
      vision: ["SigLIP (width 768, patch 16) at 512 × 512, global image only; pixel shuffle → 64 tokens per frame", "p1", "p2", "c4"],
      backbone: ["SmolVLM2-500M text model, first 16 of 32 layers; width 960; frozen", "p2", "c1", "c4"],
      head: ["Expert: 16 layers, width 720 (0.75 × 960), MLP 2,048", "p1", "c1", "c2"],
      output: ["Velocity on n = 50 actions (padded to 32 dims)", "p2", "c1"],
      attention: ["Even expert layers: joint self-attention (causal over actions); odd layers: cross-attention to VLM K, V", "p1", "c2", "c3"],
      cond: ["[action ‖ sinusoid(τ)] → Linear → swish → Linear, as in π0", "c3"],
      steps: ["10 Euler steps", "p2", "c1"],
      chunk: ["n = 50; asynchronous inference overlaps execution and prediction", "p2", "p4"],
      rate: null, latency: null,
      train: ["< 30k community episodes (SO100); 200k steps, batch 256, only the expert trained", "p2", "p5"]
    },
    changes: [
      "Backbone: <b>SmolVLM2-500M</b>, and only its first 16 of 32 layers; kept frozen.",
      "<b>64 visual tokens</b> per frame (pixel shuffle, no tiling) instead of 256.",
      "Expert layers <b>alternate cross-attention</b> to the VLM's K, V with self-attention; π0 used shared self-attention in every layer.",
      "<b>Causal</b> attention among action tokens (π0: bidirectional).",
      "State enters the VLM prefix as one projected token; expert width is 0.75 × the VLM's.",
      "0.45B parameters in total; an asynchronous inference stack."
    ],
    blueprint: {
      headline: "SmolVLA: half a small VLM, interleaved expert",
      note: "The VLM runs once per observation and caches its keys and values at all 16 layers. The expert has 16 layers too: in even ones its tokens join the VLM's self-attention (causal among actions); in odd ones they cross-attend to that layer's cached K, V.",
      towers: [
        { mod: "siglip", title: "SigLIP (SmolVLM2)", sub: "vision encoder, frozen", compact: true,
          input: { label: "Image 512 × 512", caption: "global image, no tiling" },
          rows: [
            { t: "embed", label: "Patch embedding 16 × 16", call: ["Width 768 · 1,024 patches", "c4"] },
            { t: "attn", label: "ViT encoder", call: ["12 heads", "c4"] },
            { t: "pool", label: "Pixel shuffle", call: ["Scale 4: 1,024 → 64 tokens", "p1", "c4"] },
            { t: "linear", label: "Connector → 960" } ],
          output: { label: "64 image tokens per frame" } },
        { mod: "vlm", title: "SmolLM2 (first 16 layers)", sub: "VLM text model, frozen",
          input: { label: "Image + text + state", caption: "state: one projected token" },
          rows: [
            { t: "linear", label: "State projection", call: ["32 → 960, one token", "p1", "c3"] },
            { t: "embed", label: "Token embedding layer", call: ["Vocabulary of 49,280 · width 960", "c4"] },
            { t: "block", n: "16", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Grouped-query attention", side: "RoPE", call: ["15 query heads, 5 KV heads (dim 64)", "c4"], callDy: -26, zoom: { k: "heads", q: 15, kv: 5, hd: 64, title: "Grouped-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden layer dimension of 2,560", "c4"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "keys and values of all 16 layers, cached" } },
        { mod: "expert", title: "Action expert", sub: "≈100M, width 0.75 × VLM",
          input: { label: "Noisy actions Aτ", caption: "n = 50 tokens, time τ" },
          rows: [
            { t: "mlp", label: "Action + time MLP", call: ["[W aτ ‖ sinusoid(τ)] → swish MLP → 720", "c3"] },
            { t: "block", n: "8", label: "self + cross pair", rows: [
              { t: "norm", label: "RMSNorm" },
              { id: "att", t: "attn", label: "Joint self-attention", call: ["Actions causal among themselves", "p1", "p3", "c3"] },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Width 720 · hidden layer dimension of 2,048", "c2"], zoom: { k: "glu", act: "SiLU", d: "720", ff: "2,048", title: "Feed forward (SwiGLU), expert" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm" },
              { id: "ca", t: "attn", label: "Cross-attn to VLM K, V", side: "VLM K, V", call: ["K, V re-projected 320 → 320", "c2"], zoom: { k: "rows", title: "Cross-attention layer", rows: ["VLM layer ℓ keys, values (5 × 64)", "expert k_proj, v_proj on them", "queries from 50 action tokens", "attend under the prefix pad mask"] } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm" },
              { t: "ffn", label: "Feed forward (SwiGLU)" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Action output projection", call: ["720 → 32", "c3"] } ],
          output: { label: "velocity vθ for 50 actions; 10 steps" } }
      ],
      links: [
        { from: "vlm", to: "expert", toRow: "ca", label: "cached K, V (odd layers)" },
        { from: "siglip", to: "vlm", toRow: "input", label: "64 tokens / frame" }
      ],
      shared: [{ a: ["vlm", "att"], b: ["expert", "att"], label: "shared self-attn (even layers)" }]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP (SmolVLM2)", sub: "512² → 64 tokens", col: 0, frozen: true, short: "SigLIP" },
      { id: "vlm", role: "vlm", name: "SmolLM2, 16 layers", sub: "16 × 960 · GQA 15/5", col: 1, frozen: true, short: "SmolVLM2",
        stack: { rows: [
          { t: "in", label: "[64 image tokens/frame | text | state token]", dims: "state is its own block", c: "data-2" },
          { t: "block", label: "Llama-style decoder block", n: "16", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "GQA · 15 query, 5 KV heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 960 → 2560 → 960" }, { t: "add", span: 2 } ] },
          { t: "out", label: "per-layer keys and values", dims: "top 16 layers discarded", c: "data-2" } ],
          facts: [["Layers used", ["16 of 32", "p2", "c1", "c4"]], ["Width", ["960", "c4"]], ["Heads", ["15 query, 5 KV, head dim 64", "c4"]], ["MLP", ["2560", "c4"]], ["Trainable", ["no (train_expert_only)", "p2", "c1"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert", sub: "16 × 720 · MLP 2048", col: 2, frozen: false, params: "≈100M", short: "Action expert", main: true,
        stack: { rows: [
          { t: "in", label: "noisy actions Aτ, time τ", dims: "50 tokens", c: "data-3" },
          { t: "mlp", label: "Action + time MLP", dims: "[aτ ‖ φ(τ)] → 720" },
          { t: "block", label: "Self + cross pair", n: "8", rows: [
            { t: "attn", label: "Joint self-attention over [prefix ‖ actions], causal actions" }, { t: "add", span: 1 }, { t: "ffn", label: "SwiGLU 720 → 2048 → 720" }, { t: "add", span: 1 },
            { t: "attn", label: "Cross-attention to VLM layer K, V" }, { t: "add", span: 1 }, { t: "ffn", label: "SwiGLU 720 → 2048 → 720" }, { t: "add", span: 1 } ] },
          { t: "linear", label: "Output projection", dims: "720 → 32" },
          { t: "out", label: "velocity vθ", dims: "Euler from τ = 0 to 1", c: "data-3" } ],
          facts: [["Width", ["720 = 0.75 × 960", "p1", "c1"]], ["Layers", ["16, one per VLM layer", "c1", "c2"]], ["Interleave", ["self-attention every 2nd layer", "c1"]], ["Heads", ["15 query, 5 KV, dim 64", "c2", "c4"]], ["Params", ["≈100M", "p2"]]] } }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "RGB cameras", n: "64 tokens each", k: 4 },
      { to: "vlm", mod: "lang", label: "instruction + state", n: "≤ 48 text tokens + 1", k: 3 },
      { to: "expert", mod: "action", label: "noisy chunk Aτ", n: "n = 50", k: 5, noisy: true }
    ],
    outputs: [{ from: "expert", mod: "action", label: "velocity vθ", n: "50 × 32", k: 5 }],
    links: [
      { from: "siglip", to: "vlm", kind: "prefix", label: "pixel shuffle|64 tokens / frame" },
      { from: "vlm", to: "expert", kind: "cross-attn", label: "CA odd · SA even", note: "even expert layers share self-attention with the VLM layer; odd ones cross-attend to its keys and values" }
    ],
    mask: { name: "Prefix · state · causal actions", ref: "p1", axes: [{ label: "images + text", short: "img+ℓ", mod: "vision" }, { label: "state", short: "q", mod: "state" }, { label: "actions", short: "A", mod: "action" }], m: ["100", "110", "111"],
      note: "Within the action block each token sees only earlier actions (causal); a bidirectional expert scored lower in Table 7." },
    callouts: [
      "Paper §3.1 describes the self-attention layers as action tokens attending to each other; in lerobot's code those layers run one joint attention over [prefix ‖ actions], so actions also see the VLM there.",
      "Table 9 finds a 1.0 × wide expert best (82.3 %) and 0.75 × lower (77.5 %) than 0.5 ×; the released default is 0.75 ×.",
      "Table 8: keeping the first 16 of 32 layers of the 500M VLM beats a smaller 256M VLM."
    ]
  });

  /* ================= π0.7 ================= */
  RB.arch.spec({
    id: "pi0-7", method: "pi0-7", name: "π0.7", year: 2026, parent: "pi0-5",
    diffRows: ["params", "vision", "backbone", "head", "cond", "steps", "chunk", "train"],
    figRef: "Ai et al. Fig. 2 · §VI-B · App. B–D", prov: "no public code",
    lede: "A 5B VLA on π0.6-MEM: Gemma3 4B with a video-history encoder and an 860M flow expert. Its prompt can carry subtask text, subgoal images from a BAGEL world model, and episode metadata such as quality and speed.",
    sources: {
      p1: { kind: "paper", ref: "Ai et al. 2026 (π0.7), §IV and Fig. 2 (overview)", url: "https://arxiv.org/abs/2604.15483" },
      p2: { kind: "paper", ref: "Ai et al. 2026, §VI-B (model architecture)", url: "https://arxiv.org/abs/2604.15483" },
      p3: { kind: "paper", ref: "Ai et al. 2026, §VII and Alg. 1 (prompting at runtime)", url: "https://arxiv.org/abs/2604.15483" },
      p4: { kind: "paper", ref: "Ai et al. 2026, App. B, Fig. 19 (attention patterns)", url: "https://arxiv.org/abs/2604.15483" },
      p5: { kind: "paper", ref: "Ai et al. 2026, App. C (world model)", url: "https://arxiv.org/abs/2604.15483" },
      p6: { kind: "paper", ref: "Ai et al. 2026, App. D (inference speed)", url: "https://arxiv.org/abs/2604.15483" },
      p7: { kind: "paper", ref: "Ai et al. 2026, §III and §V (KI recipe, prompt parts)", url: "https://arxiv.org/abs/2604.15483" }
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p1"],
      params: ["≈5B: Gemma3 4B VLM (incl. 400M vision encoder) + 860M action expert", "p1"],
      vision: ["MEM history encoder: up to 4 cameras × 6 frames at 448 × 448, compressed to one frame's tokens; up to 3 subgoal images", "p2"],
      backbone: ["Gemma3 4B; layer sizes not given in the paper", "p1"],
      head: ["Action expert, 860M; layer sizes not given", "p1"],
      output: ["Velocity on 50 actions, joint or end-effector per control mode", "p2", "p3"],
      attention: ["Block-causal: observations, then subgoal images, then causal text; FAST and flow tokens never see each other", "p2", "p4"],
      cond: ["τ via adaptive RMSNorm; prompt = task, subtask, subgoal images, metadata, control mode", "p2", "p7"],
      steps: ["5 denoising steps; optional CFG on metadata, β ∈ {1.3, 1.7, 2.2}", "p3"],
      chunk: ["50 predicted, 15 or 25 executed; training-time RTC with 0–12 step delays", "p2", "p3"],
      rate: ["50 Hz robots (12 steps = 240 ms delay)", "p2"],
      latency: ["38 ms for the minimal variant (3 cameras, 5 steps) on one H100", "p6"],
      train: ["KI recipe (FAST on the backbone, stop-gradient); demos, autonomous and failed rollouts, human video, web data", "p7"]
    },
    changes: [
      "Backbone grows to <b>Gemma3 4B</b> (≈5B total) and the expert to 860M.",
      "A <b>MEM video-history</b> encoder: up to 6 frames per camera, compressed to one frame's tokens.",
      "The prompt adds <b>subgoal images</b> (from a BAGEL world model), episode metadata and control mode, each with dropout.",
      "State is embedded by a linear projection, one token per history step (π0.5: discretized text).",
      "5 denoising steps, training-time RTC, and CFG on metadata.",
      "Trained with the KI recipe, including suboptimal and autonomous data labelled by metadata."
    ],
    blueprint: {
      headline: "π0.7: a VLA steered by its prompt",
      note: "Disclosed at block level only. A BAGEL world model draws subgoal images every 4 s or on a new subtask; they pass through the same history encoder as the cameras. Gemma3 and the 860M expert share attention as in π0.5, with τ entering by adaptive RMSNorm.",
      towers: [
        { mod: "wm", title: "World model (BAGEL)", sub: "subgoal images, 14B MoT", compact: true,
          input: { label: "Obs + subtask ℓ̂", caption: "3 cameras, metadata" },
          rows: [
            { t: "attn", label: "ViT → 7B understanding", call: ["ViT input 448 × 336, patch 14", "p5"] },
            { t: "attn", label: "VAE → 7B generation", call: ["VAE input 512 × 384, patch 16", "p5"] } ],
          output: { label: "subgoal images g⋆ (every 4 s)" } },
        { mod: "mem", title: "MEM vision encoder", sub: "Gemma3 init, 400M", compact: true,
          input: { label: "Cameras × history", caption: "448 × 448, 1 s stride" },
          rows: [
            { t: "attn", label: "Vision transformer", call: ["Up to 4 cameras × 6 frames", "p2"] },
            { t: "pool", label: "Temporal + spatial compression", call: ["History → one frame's token count", "p1", "p2"], zoom: { k: "rows", title: "MEM history encoding", rows: ["4 cameras × up to 6 frames, 448²", "history dropped with p = 0.3", "shared vision encoder", "temporal + spatial compression", "tokens of one frame per camera"] } } ],
          output: { label: "observation + subgoal tokens" } },
        { mod: "gemma", title: "Gemma3 4B", sub: "VLM backbone (KI: FAST loss)",
          input: { label: "Obs + goals + prompt", caption: "state: linear, one token per step" },
          rows: [
            { t: "embed", label: "Prompt embedding", call: ["Task, subtask, metadata, control mode", "p3", "p7"], zoom: { k: "rows", title: "Prompt context Cₜ", rows: ["task ℓ + control mode", "subtask ℓ̂ₜ (policy or human coach)", "metadata: speed, quality, mistake", "subgoal images g⋆", "each part dropped out in training"] } },
            { t: "group", label: "Decoder layers (count not stated)", rows: [
              { id: "att", t: "attn", label: "Block-causal self-attention" },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "LM head: text + FAST logits", call: ["FAST tokens only at training time", "p4", "p7"] } ],
          output: { label: "prefix keys and values" } },
        { mod: "expert", title: "Action expert", sub: "860M, flow matching",
          input: { label: "Noisy actions Aτ", caption: "50 tokens, time τ, RTC prefix" },
          rows: [
            { t: "group", label: "Expert layers (sizes not stated)", rows: [
              { t: "norm", label: "Adaptive RMSNorm", side: "AdaLN", call: ["Injects flow time τ", "p2"] },
              { id: "att", t: "attn", label: "Attention: backbone + actions", call: ["50 tokens, bidirectional", "p2"] },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "Action output projection", call: ["5 steps; CFG on metadata", "p3"], zoom: { k: "rows", title: "Metadata CFG", rows: ["(+), (−) branches in one sequence", "(−) drops the metadata", "v = v₋ + (1 + β)(v₊ − v₋)", "β ∈ {1.3, 1.7, 2.2}"] } } ],
          output: { label: "velocity for 50 actions; run 15 or 25" } }
      ],
      links: [
        { from: "mem", to: "gemma", toRow: "input", label: "image tokens" },
        { from: "wm", to: "mem", toRow: "input", label: "subgoal images" }
      ],
      shared: [{ a: ["gemma", "att"], b: ["expert", "att"], label: "shared attention (stop-grad)" }]
    },
    modules: [
      { id: "wm", role: "world", name: "BAGEL world model", sub: "7B + 7B MoT · subgoals", col: 0, frozen: false, short: "World model" },
      { id: "mem", role: "vision-enc", name: "MEM vision encoder", sub: "400M · 6-frame history", col: 1, frozen: false, short: "MEM" },
      { id: "gemma", role: "vlm", name: "Gemma3 4B", sub: "backbone · KI (FAST loss)", col: 2, frozen: false, short: "Gemma3 4B", main: true,
        stack: { rows: [
          { t: "in", label: "[obs history | subgoal images | text prompt | states]", dims: "block-causal", c: "data-2" },
          { t: "group", label: "Gemma3 decoder layers", rows: [{ t: "attn", label: "Self-attention (block-causal mask)" }, { t: "ffn", label: "Feed forward" }] },
          { t: "linear", label: "LM head", dims: "text, subtasks, FAST tokens" },
          { t: "out", label: "keys and values", dims: "read by the expert", c: "data-2" } ],
          facts: [["Init", ["Gemma3 4B, incl. 400M vision encoder", "p1"]], ["Image size", ["448 × 448", "p2"]], ["State", ["linear projection, one token per history step", "p2"]], ["Layer sizes", "not stated"]] } },
      { id: "expert", role: "action-expert", name: "Action expert", sub: "adaptive RMSNorm · 50 tok", col: 3, frozen: false, params: "860M", short: "Action expert" }
    ],
    inputs: [
      { to: "wm", mod: "lang", label: "subtask ℓ̂", n: "text", k: 2 },
      { to: "mem", mod: "vision", label: "cameras × history", n: "≤ 4 × 6 frames", k: 5 },
      { to: "gemma", mod: "lang", label: "prompt + metadata", n: "text", k: 3 },
      { to: "expert", mod: "action", label: "noisy chunk Aτ", n: "50", k: 5, noisy: true }
    ],
    outputs: [
      { from: "wm", mod: "future", label: "subgoal images g⋆", n: "≤ 3 views", k: 3 },
      { from: "expert", mod: "action", label: "velocity vθ", n: "50 actions", k: 5 }
    ],
    links: [
      { from: "wm", to: "mem", kind: "two-stage", label: "subgoal images|async, every 4 s" },
      { from: "mem", to: "gemma", kind: "prefix", label: "compressed|history tokens" },
      { from: "gemma", to: "expert", kind: "joint-attn", label: "shared attn", note: "KI: stop-gradient from the expert into the backbone" }
    ],
    mask: { name: "Block-causal prompt", ref: "p4", axes: [{ label: "obs history", short: "obs", mod: "vision" }, { label: "subgoals", short: "g⋆", mod: "future" }, { label: "text prompt", short: "ℓ", mod: "lang" }, { label: "flow actions", short: "A", mod: "action" }], m: ["1000", "1100", "1110", "1111"],
      note: "Text tokens are causal among themselves; FAST tokens (training only) and flow actions do not attend to each other." },
    callouts: [
      "No official code or weights; layer counts and widths of the backbone and expert are <b>not disclosed</b>.",
      "The high-level language policy uses the same architecture, fine-tuned on verbal coaching data (§V-A).",
      "The world model is a separate 14B BAGEL MoT (7B understanding + 7B generation backbones), not part of the 5B VLA."
    ]
  });

  /* ================= CogACT ================= */
  RB.arch.spec({
    id: "cogact", method: "cogact", name: "CogACT", year: 2024, parent: "openvla",
    diffRows: ["params", "head", "output", "attention", "cond", "steps", "chunk"],
    figRef: "Li et al. Fig. 2 · §3 · Table III", prov: "DiT-Base (default)",
    lede: "OpenVLA's 7B VLM, but its output is one cognition feature, not action tokens. A separate diffusion transformer (DiT-Base, 89M) turns that feature into 16 future end-effector actions, fused over time by an adaptive ensemble.",
    sources: {
      p1: { kind: "paper", ref: "Li et al. 2024, §3.1 (vision and language modules)", url: "https://arxiv.org/abs/2411.19650" },
      p2: { kind: "paper", ref: "Li et al. 2024, §3.2 (diffusion action module)", url: "https://arxiv.org/abs/2411.19650" },
      p3: { kind: "paper", ref: "Li et al. 2024, §3.4 (adaptive action ensemble)", url: "https://arxiv.org/abs/2411.19650" },
      p4: { kind: "paper", ref: "Li et al. 2024, §4 (training data, implementation)", url: "https://arxiv.org/abs/2411.19650" },
      p5: { kind: "paper", ref: "Li et al. 2024, App. Table III (action-module sizes)", url: "https://arxiv.org/abs/2411.19650" },
      p6: { kind: "paper", ref: "Li et al. 2024, §4.1 and Table 7 (parameters)", url: "https://arxiv.org/abs/2411.19650" },
      p7: { kind: "paper", ref: "Touvron et al. 2023 (LLaMA), Table 2 and §2.2; LLaMA-2 keeps this architecture", url: "https://arxiv.org/abs/2302.13971" },
      c1: { kind: "code", repo: "microsoft/CogACT", path: "action_model/models.py", commit: "b174a1b", url: COGACT + "action_model/models.py" },
      c2: { kind: "code", repo: "microsoft/CogACT", path: "action_model/action_model.py", commit: "b174a1b", url: COGACT + "action_model/action_model.py" },
      c3: { kind: "code", repo: "microsoft/CogACT", path: "vla/cogactvla.py", commit: "b174a1b", url: COGACT + "vla/cogactvla.py" },
      c4: { kind: "code", repo: "microsoft/CogACT", path: "scripts/deploy.py", commit: "b174a1b", url: COGACT + "scripts/deploy.py" },
      c5: { kind: "code", repo: "microsoft/CogACT", path: "scripts/train.py", commit: "b174a1b", url: COGACT + "scripts/train.py" },
      c6: { kind: "code", repo: "microsoft/CogACT", path: "conf/vla.py", commit: "b174a1b", url: COGACT + "conf/vla.py" }
    },
    summary: {
      pattern: ["VLM + diffusion/flow action head", "p2"],
      params: ["7.6B total; DiT-Base action module 89M", "p6"],
      vision: ["DINOv2 + SigLIP, channel-concatenated → 256 visual tokens at 224 px", "p1", "c6"],
      backbone: ["LLaMA-2 7B (Prismatic VLM, OpenVLA weights); causal; cognition token last", "p1", "p4"],
      head: ["DiT-Base: 12 layers, width 768, 12 heads, MLP ratio 4", "p5", "c1", "c2"],
      output: ["Noise ε on 16 actions (current + 15 future), 7-DoF Δ end effector + gripper", "p2", "c5"],
      attention: ["VLM causal; DiT full self-attention over 17 tokens [cognition + step ‖ 16 actions]", "p2", "c1"],
      cond: ["Cognition feature (4,096 → 768) plus timestep embedding form one prefix token; no AdaLN", "p2", "c1", "c3"],
      steps: ["100 DDPM steps (squared cosine) in training; DDIM 10 at inference, CFG 1.5", "c2", "c4"],
      chunk: ["16 predicted; adaptive action ensemble over K = 2 (Google robot) or 7 (WidowX) past chunks", "p2", "p4"],
      rate: null, latency: null,
      train: ["OXE subset, 25 datasets, 22.5M frames; 135K iters, batch 256, 8 diffusion samples per example", "p4"]
    },
    changes: [
      "Actions no longer come out as LLM tokens: the LLM's last hidden state at one <b>cognition token</b> is the only output used.",
      "A separate <b>DiT action module</b> (89M default) denoises a chunk of 16 continuous 7-DoF actions.",
      "Loss is diffusion noise MSE on continuous actions, not cross-entropy on 256 bins.",
      "An <b>adaptive action ensemble</b> blends overlapping chunks weighted by cosine similarity.",
      "Initialised from OpenVLA weights and trained end to end."
    ],
    blueprint: {
      headline: "CogACT: 7B cognition, 89M action DiT",
      note: "The VLM runs once per step and hands a single 4,096-d cognition feature to the DiT. That feature, plus the diffusion-step embedding, becomes the first of 17 tokens; the DiT denoises the other 16 (the action chunk) with plain self-attention.",
      towers: [
        { mod: "vis", title: "DINOv2 + SigLIP", sub: "Prismatic vision module", compact: true,
          input: { label: "RGB image 224 px", caption: "one third-person camera" },
          rows: [
            { t: "attn", label: "DINOv2 ViT ‖ SigLIP ViT", call: ["Run in parallel on the same image", "p1"] },
            { t: "linear", label: "Channel concat · projection", call: ["256 visual tokens", "p1"] } ],
          output: { label: "256 visual tokens" } },
        { mod: "llm", title: "LLaMA-2 7B", sub: "language module",
          input: { label: "Visual + text + cognition", caption: "cognition token appended last" },
          rows: [
            { t: "embed", label: "Token embedding layer", call: ["Width 4,096", "p7", "c3"] },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["32 heads", "p7"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "LLaMA-2 7B attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)" },
              { t: "add", span: 2 } ] },
            { id: "cog", t: "linear", label: "Cognition feature fᶜₜ", call: ["Last hidden state at the cognition token", "p1", "c3"] } ],
          output: { label: "fᶜₜ, 4,096-d" } },
        { mod: "dit", title: "DiT-Base action module", sub: "diffusion transformer, 89M",
          input: { label: "Noisy actions aⁱ", caption: "16 tokens × 7-DoF, step i" },
          rows: [
            { id: "cond", t: "linear", label: "Cond token: Linear(fᶜₜ) + emb(i)", side: "cond", call: ["4,096 → 768; dropped 10 % for CFG", "c1", "c2"], zoom: { k: "rows", title: "Condition token", rows: ["fᶜₜ (4,096) → Linear → 768", "or learned 'uncond' (p = 0.1)", "step i → sinusoid 256 → MLP → 768", "sum → token 0 of 17"] } },
            { t: "linear", label: "Action embedding 7 → 768", call: ["+ learned positions for 17 tokens", "c1", "p2"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head self-attention", call: ["12 heads, width 768, qkv bias", "p5", "c1"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "DiT-Base attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 3,072", "c1", "p5"], zoom: { k: "mlp", act: "GELU (tanh)", d: "768", ff: "3,072", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm · Linear", call: ["768 → 7; token 0 dropped", "c1"] } ],
          output: { label: "noise ε for 16 actions; DDIM 10" } }
      ],
      links: [
        { from: "llm", to: "dit", toRow: "cond", label: "cognition feature" },
        { from: "vis", to: "llm", toRow: "input", label: "256 visual tokens" }
      ]
    },
    modules: [
      { id: "vis", role: "vision-enc", name: "DINOv2 + SigLIP", sub: "→ 256 tokens", col: 0, frozen: false, short: "DINO+SigLIP" },
      { id: "llm", role: "vlm", name: "LLaMA-2 7B", sub: "32 × 4096 · causal", col: 1, frozen: false, short: "LLaMA-2 7B" },
      { id: "dit", role: "action-head", roleLabel: "Diffusion action module", name: "DiT-Base", sub: "12 × 768 · 12 heads", col: 2, frozen: false, params: "89M", short: "DiT-B", main: true,
        stack: { rows: [
          { t: "in", label: "[cond token | 16 noisy actions]", dims: "17 tokens", c: "data-3" },
          { t: "linear", label: "Cond token: Linear(fᶜₜ) + emb(i)", dims: "4096 → 768" },
          { t: "linear", label: "Action embedding", dims: "7 → 768, + learned positions" },
          { t: "block", label: "DiT block (plain pre-norm, no AdaLN)", n: "12", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 12 heads · bidirectional" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 768 → 3072 → 768 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final LayerNorm → Linear 768 → 7" },
          { t: "out", label: "predicted noise ε", dims: "16 × 7, cond token dropped", c: "data-3" } ],
          facts: [["Depth / width / heads", ["12 / 768 / 12", "p5", "c2"]], ["Other sizes", ["S: 6 / 384 / 4 (13M) · L: 24 / 1024 / 16 (308M)", "p5", "c2"]], ["Context", ["N + 2 = 17 tokens", "p2"]], ["Schedule", ["squared cosine, 100 steps", "c2"]], ["CFG", ["condition dropout 0.1, scale 1.5", "c2", "c4"]]] } }
    ],
    inputs: [
      { to: "vis", mod: "vision", label: "image oₜ", n: "224 px", k: 4 },
      { to: "llm", mod: "lang", label: "instruction ℓ", n: "+ cognition token", k: 3 },
      { to: "dit", mod: "action", label: "noisy actions aⁱ", n: "16 × 7", k: 5, noisy: true },
      { to: "dit", mod: "time", label: "step i", n: "sinusoid", k: 1 }
    ],
    outputs: [{ from: "dit", mod: "action", label: "noise ε → 16 actions", n: "16 × 7", k: 5 }],
    links: [
      { from: "vis", to: "llm", kind: "prefix", label: "256 visual tokens" },
      { from: "llm", to: "dit", kind: "prefix", label: "one cognition token", note: "the cognition feature becomes the DiT's first token" }
    ],
    mask: { name: "DiT: full self-attention", ref: "p2", axes: [{ label: "condition", short: "c", mod: "lang" }, { label: "actions", short: "a", mod: "action" }], m: ["11", "11"],
      note: "The DiT sees one condition token and 16 action tokens with no mask; the VLM before it is ordinary causal LLaMA-2." },
    callouts: [
      "Paper §3.1 calls the cognition token an additional learnable token; the code appends LLaMA's EOS token (id 2) and reads its last hidden state.",
      "Paper §4 trains with 8 diffusion samples per example; <code>train.py</code> sets repeated_diffusion_steps = 8, while the strategy class defaults to 4.",
      "Table 7: DiT-Large (308M) scores 64.8 % average vs 62.5 % for DiT-Base; the release default is DiT-Base."
    ]
  });

  /* ================= RT-H ================= */
  RB.arch.spec({
    id: "rt-h", method: "rt-h", name: "RT-H", year: 2024, parent: "rt-2",
    diffRows: ["output", "train"],
    figRef: "Belkhale et al. Fig. 2 · §III · App. A", prov: "no public code",
    lede: "RT-2's PaLI-X 55B asked two questions per step: first which language motion to do (“move arm forward”), then which action, with that motion in the prompt. Humans can correct the motion in words.",
    sources: {
      p1: { kind: "paper", ref: "Belkhale et al. 2024, §III-B and Fig. 2", url: "https://arxiv.org/abs/2403.01823" },
      p2: { kind: "paper", ref: "Belkhale et al. 2024, §III-C (language motion labels)", url: "https://arxiv.org/abs/2403.01823" },
      p3: { kind: "paper", ref: "Belkhale et al. 2024, §IV (inference, corrections)", url: "https://arxiv.org/abs/2403.01823" },
      p4: { kind: "paper", ref: "Belkhale et al. 2024, App. A–B (queries, training)", url: "https://arxiv.org/abs/2403.01823" },
      p5: { kind: "paper", ref: "Belkhale et al. 2024, §V (datasets)", url: "https://arxiv.org/abs/2403.01823" },
      p6: { kind: "paper", ref: "Chen et al. 2023 (PaLI-X), §3.1 and §3.3", url: "https://arxiv.org/abs/2305.18565" }
    },
    summary: {
      pattern: ["Autoregressive token VLA", "p1"],
      params: ["55B (PaLI-X)", "p1"],
      vision: ["ViT-22B, frozen during robot co-training; 224 × 224 base resolution", "p4", "p6"],
      backbone: ["PaLI-X encoder–decoder (UL2 32B variant: 50 encoder + 50 decoder layers)", "p1", "p6"],
      head: ["None: the decoder writes text and action tokens", "p1"],
      output: ["Query 1: language motion z (text). Query 2: action tokens, 256 bins per dimension", "p1", "p4"],
      attention: ["Encoder bidirectional over image + prompt; decoder causal with cross-attention", "p1", "p6"],
      cond: ["Language motion z goes into the encoder prompt of the action query", "p1"],
      steps: ["2 queries per step; asynchronous: motion predicted one step ahead", "p3"],
      chunk: ["1 action per query (no chunking)", "p1"],
      rate: null, latency: null,
      train: ["Diverse + Kitchen (30K + 70K demos); 50 % PaLI-X web mixture, 25 % each query; batch 1,024", "p4", "p5"]
    },
    changes: [
      "One extra query per step: predict a <b>language motion</b> z (“move arm forward”) before the action.",
      "The action query puts z in the <b>encoder</b> prompt: “What action … with current skill: [z]?”.",
      "Motions are auto-labelled from proprioception; more than 2,500 distinct phrases.",
      "Humans can <b>override z</b> in words; training on those corrections updates only the motion query.",
      "Architecture and action tokenization are unchanged from RT-2."
    ],
    blueprint: {
      headline: "RT-H: ask for a motion, then an action",
      note: "One PaLI-X model, queried twice. The ViT-22B tokens and the prompt enter the encoder; the decoder writes the answer. Query 1 answers with a language motion; query 2, with that motion added to the prompt, answers with action tokens.",
      towers: [
        { mod: "vit", title: "ViT-22B", sub: "vision encoder, frozen", compact: true,
          input: { label: "Camera image", caption: "224 × 224 base resolution" },
          rows: [
            { t: "attn", label: "ViT-22B", call: ["22B parameters, frozen", "p4", "p6"] },
            { t: "linear", label: "Projection to encoder width" } ],
          output: { label: "patch embeddings, no pooling" } },
        { mod: "enc", title: "PaLI-X encoder", sub: "UL2 32B variant, bidirectional",
          input: { label: "Image tokens + prompt", caption: "task g (+ motion z in query 2)" },
          rows: [
            { t: "embed", label: "Text embedding + image tokens", call: ["Prompt templates of Appendix A", "p4"], zoom: { k: "rows", title: "Two queries, one model", rows: ["Q1: What skill … to [task]?", "→ decoder: motion z", "Q2: What action … skill: [z]?", "→ decoder: action tokens"] } },
            { t: "block", n: "50", rows: [
              { t: "attn", label: "Self-attention (bidirectional)" },
              { t: "add", span: 1 },
              { t: "ffn", label: "Feed forward" },
              { t: "add", span: 1 } ] } ],
          output: { label: "encoder states" } },
        { mod: "dec", title: "PaLI-X decoder", sub: "autoregressive",
          input: { label: "Previous output tokens", caption: "starts after “A:”" },
          rows: [
            { t: "block", n: "50", rows: [
              { t: "attn", label: "Causal self-attention" },
              { t: "add", span: 1 },
              { id: "xa", t: "attn", label: "Cross-attn to encoder", side: "Encoder", call: ["50 decoder layers", "p6"] },
              { t: "add", span: 1 },
              { t: "ffn", label: "Feed forward" },
              { t: "add", span: 1 } ] },
            { t: "linear", label: "Token head", call: ["Motion text or 256-bin action tokens", "p1"], zoom: { k: "rows", title: "Action tokens (as RT-2)", rows: ["Δ position (3), Δ axis-angle (3)", "gripper open / close", "termination flag", "each dimension → one of 256 bins"] } } ],
          output: { label: "language motion z, or action a" } }
      ],
      links: [
        { from: "enc", to: "dec", toRow: "xa", label: "encoder states" },
        { from: "vit", to: "enc", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "ViT-22B", sub: "224² base resolution", col: 0, frozen: true, params: "22B", short: "ViT-22B" },
      { id: "enc", role: "vlm", roleLabel: "Encoder", name: "PaLI-X encoder", sub: "50 layers · UL2 32B", col: 1, frozen: false, short: "Encoder", main: true },
      { id: "dec", role: "vlm", roleLabel: "Decoder", name: "PaLI-X decoder", sub: "50 layers · causal", col: 2, frozen: false, short: "Decoder" }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "RGB image", n: "224 × 224", k: 4 },
      { to: "enc", mod: "lang", label: "task g (+ motion z)", n: "prompt text", k: 3 }
    ],
    outputs: [
      { from: "dec", mod: "lang", label: "motion z", n: "query 1", k: 3 },
      { from: "dec", mod: "action", label: "actions", n: "query 2", k: 4 }
    ],
    links: [
      { from: "vit", to: "enc", kind: "prefix", label: "projected|image tokens" },
      { from: "enc", to: "dec", kind: "cross-attn", label: "encoder states" }
    ],
    callouts: [
      "No public code or weights; the architecture is RT-2's PaLI-X 55B and only the queries and data change.",
      "RT-H-Joint (one query writing motion then action) performs about as well; the two-query form lets z enter the encoder and makes corrections easy (App. A).",
      "Motions come from 9 action dimensions (position, rotation, base, gripper), dropping small ones and ordering by magnitude (§III-C)."
    ]
  });

  /* ================= Hi Robot ================= */
  RB.arch.spec({
    id: "hi-robot", method: "hi-robot", name: "Hi Robot", year: 2025, parent: "pi0",
    diffRows: ["pattern", "params", "rate", "train"],
    figRef: "Shi et al. Fig. 2 · §4 · App. B–C", prov: "no public code; low level is π0",
    lede: "Two PaliGemma-3B models in a hierarchy. A high-level VLM reads the images and the user's open-ended prompt and writes a short command (plus an optional spoken reply); π0 turns that command into action chunks.",
    sources: {
      p1: { kind: "paper", ref: "Shi et al. 2025, §4.1–4.2 (hierarchical inference, interjections)", url: "https://arxiv.org/abs/2502.19417" },
      p2: { kind: "paper", ref: "Shi et al. 2025, §4.3–4.4 (data, model)", url: "https://arxiv.org/abs/2502.19417" },
      p3: { kind: "paper", ref: "Shi et al. 2025, App. B (speech, latency, robots)", url: "https://arxiv.org/abs/2502.19417" },
      p4: { kind: "paper", ref: "Shi et al. 2025, App. C (initialisation, optimiser)", url: "https://arxiv.org/abs/2502.19417" },
      c1: opi("src/openpi/models/gemma.py"),
      c2: opi("src/openpi/models/pi0.py"),
      c3: opi("src/openpi/models/pi0_config.py")
    },
    summary: {
      pattern: ["Dual-system VLA (slow VLM + fast policy)", "p1"],
      params: ["≈3B per policy (PaliGemma-3B based); π0 adds a 300M expert", "p2", "p4"],
      vision: ["Base + wrist cameras for both levels", "p1", "p3"],
      backbone: ["High level: PaliGemma 3B fine-tuned for next-token prediction of commands and replies", "p2"],
      head: ["Low level: π0 (Gemma 2B + flow-matching action expert)", "p2"],
      output: ["High: command ℓ̂ₜ (+ utterance uₜ). Low: action chunk Aₜ (7, 14 or 16 dims)", "p1", "p3"],
      attention: ["Two separate models; low level uses π0's block-causal mask", "p2"],
      cond: ["The low level sees ℓ̂ₜ in place of the user's prompt ℓₜ", "p1"],
      steps: ["Low level as π0: 10 flow steps", "p3", "c2"],
      chunk: null,
      rate: ["High level every 1 s or on interjection; low level ≈10 Hz inference, 50 Hz control", "p1", "p3"],
      latency: ["Low level 73 ms on an RTX 4090; high level 47 ms prefill + 13.2 ms per decode step", "p3"],
      train: ["High level: skill-segmented demos + VLM-generated synthetic prompts; batch 512, 1e-5, ≈2 h on 8 × H100", "p2", "p4"]
    },
    changes: [
      "A second <b>PaliGemma-3B</b> policy is added on top of π0 as a high-level planner.",
      "The planner maps images + open-ended prompts or interjections to a <b>short command</b> ℓ̂ₜ.",
      "It may also write a <b>verbal reply</b> uₜ, spoken by text-to-speech and stripped before π0 sees ℓ̂ₜ.",
      "Its training data are skill-segmented demos plus <b>synthetic user prompts</b> generated by a large VLM.",
      "π0 itself is unchanged; it simply follows ℓ̂ₜ."
    ],
    blueprint: {
      headline: "Hi Robot: a talking planner over π0",
      note: "The high-level VLM runs about once a second, or at once when the user speaks. Its text command becomes π0's instruction. π0's Gemma and action expert then share attention layer by layer as usual, producing action chunks at ≈10 Hz.",
      towers: [
        { mod: "hi", title: "High-level VLM", sub: "PaliGemma 3B, fine-tuned", compact: true,
          input: { label: "Images + user prompt", caption: "text or Whisper-transcribed speech" },
          rows: [
            { t: "attn", label: "SigLIP image tokens" },
            { t: "block", n: "18", rows: [{ t: "attn", label: "Gemma 2B decoder layer", call: ["Width 2,048 (PaliGemma)", "c1"] }] },
            { t: "linear", label: "LM head → command text", call: ["47 ms prefill + 13.2 ms / token (4090)", "p3"], zoom: { k: "rows", title: "High-level output", rows: ["user: “… something sweet?”", "→ reply uₜ: “sure, … a KitKat!”", "→ command ℓ̂ₜ: “pick up KitKat”", "uₜ → speech; ℓ̂ₜ → π0"] } } ],
          output: { label: "command ℓ̂ₜ (+ reply uₜ)" } },
        { mod: "lo", title: "π0 VLM (Gemma 2B)", sub: "low-level policy prefix",
          input: { label: "Images + command ℓ̂ₜ", caption: "base and wrist cameras" },
          rows: [
            { t: "embed", label: "SigLIP tokens + text embed" },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention", side: "RoPE", call: ["8 query heads share 1 KV head", "c1"], callDy: -26, zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention (π0)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Hidden layer dimension of 16,384", "c1"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "prefix keys and values" } },
        { mod: "expert", title: "π0 action expert", sub: "300M, flow matching",
          input: { label: "State qₜ + noisy Aτ", caption: "7, 14 or 16 action dims" },
          rows: [
            { t: "mlp", label: "State + action/time MLP", call: ["Actions padded to 32 dims", "c3"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention" },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Width 1,024 · hidden layer dimension of 4,096", "c1"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Action output projection", call: ["10 steps: 73 ms on an RTX 4090", "p3"] } ],
          output: { label: "action chunk Aₜ at 50 Hz" } }
      ],
      links: [{ from: "hi", to: "lo", toRow: "input", label: "command ℓ̂ₜ" }],
      shared: [{ a: ["lo", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "hi", role: "planner", name: "High-level VLM", sub: "PaliGemma 3B · 1 Hz", col: 0, frozen: false, short: "High level", main: true },
      { id: "lo", role: "vlm", name: "π0 VLM (Gemma 2B)", sub: "18 × 2048 · MQA", col: 1, frozen: false, short: "π0 VLM" },
      { id: "expert", role: "action-expert", name: "π0 action expert", sub: "18 × 1024 · flow", col: 2, frozen: false, params: "≈300M", short: "Expert" }
    ],
    inputs: [
      { to: "hi", mod: "vision", label: "base + wrist images", n: "each step", k: 4 },
      { to: "hi", mod: "lang", label: "prompt / interjection", n: "text or speech", k: 3 },
      { to: "lo", mod: "vision", label: "same images", n: "per inference", k: 4 },
      { to: "expert", mod: "action", label: "noisy Aτ + state", n: "chunk", k: 4, noisy: true }
    ],
    outputs: [
      { from: "hi", mod: "lang", label: "reply uₜ (spoken)", n: "optional", k: 2 },
      { from: "expert", mod: "action", label: "action chunk Aₜ", n: "50 Hz", k: 5 }
    ],
    links: [
      { from: "hi", to: "lo", kind: "feeds", label: "command ℓ̂ₜ|every 1 s", note: "the command replaces the user's prompt as π0's instruction" },
      { from: "lo", to: "expert", kind: "joint-attn", label: "shared self-attn" }
    ],
    mask: { name: "π0 blockwise causal (low level)", ref: "p2", axes: [{ label: "images + ℓ̂ₜ", short: "img+ℓ̂", mod: "vision" }, { label: "state", short: "q", mod: "state" }, { label: "actions", short: "A", mod: "action" }], m: ["100", "110", "111"],
      note: "The high-level VLM is a separate network with its own ordinary prefix-LM attention." },
    callouts: [
      "No public Hi Robot code; the low-level sizes shown are π0's from openpi, which the paper says it uses unchanged.",
      "The paper trains a separate synthetic dataset and high-level policy for each task domain (App. A.2).",
      "Instruction accuracy is over 40 % higher on average than a GPT-4o high level driving the same π0 (§5)."
    ]
  });
})();
