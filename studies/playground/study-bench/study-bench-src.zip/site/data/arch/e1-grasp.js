/* Architecture specs, topic E1 (grasp synthesis). Numbers from the papers and the official code; see sources. */
(function () {
  var RB = window.RB;

  /* ---------------- GG-CNN ---------------- */
  RB.arch.spec({
    id: "gg-cnn", method: "gg-cnn", name: "GG-CNN", year: 2018,
    figRef: "Morrison et al. Fig. 4a · §IV-C · §V-C", prov: "",
    lede: "A 62k-parameter fully convolutional net turns one depth image into four same-size maps: grasp quality, cos 2Φ, sin 2Φ and gripper width. The best grasp is the arg-max pixel, fast enough for closed-loop servoing.",
    sources: {
      p1: { kind: "paper", ref: "Morrison et al. 2018, §IV-C (network) and Fig. 4", url: "https://arxiv.org/abs/1804.05172" },
      p2: { kind: "paper", ref: "Morrison et al. 2018, §IV-B (grasp maps and training data)", url: "https://arxiv.org/abs/1804.05172" },
      p3: { kind: "paper", ref: "Morrison et al. 2018, §V-A, §V-C, §V-D (pipeline, timing, control)", url: "https://arxiv.org/abs/1804.05172" },
      c1: { kind: "code", repo: "dougsm/ggcnn", path: "models/ggcnn.py", commit: "0c50aa7", url: "https://github.com/dougsm/ggcnn/blob/0c50aa7/models/ggcnn.py" }
    },
    summary: {
      pattern: ["Grasp CNN (per-pixel)", "p1"],
      params: ["62,420", "p1"],
      vision: ["One inpainted, mean-subtracted depth image, 300 × 300", "p2", "p3"],
      backbone: ["3 strided convs down, 3 transposed convs up (32 → 16 → 8 → 8 → 16 → 32 filters)", "c1"],
      head: ["Four 2 × 2 conv heads: Q, cos 2Φ, sin 2Φ, W", "c1"],
      output: ["Grasp map G = (Q, Φ, W) at every pixel; width ≤ 150 px", "p1", "p2"],
      attention: "None (convolutions only)",
      cond: null,
      steps: ["One forward pass: 6 ms net, 19 ms full pipeline (GTX 1070)", "p3"],
      chunk: null,
      rate: ["Depth at 30 Hz; closed loop up to 50 Hz", "p3"],
      latency: ["19 ms to a grasp pose", "p3"],
      train: ["Cornell, augmented to 8,840 depth images (51,100 grasps)", "p2"]
    },
    blueprint: {
      headline: "GG-CNN: a grasp map from one depth image",
      note: "Three strided convolutions shrink the 300 × 300 depth image to 25 × 25; three transposed convolutions grow it back. Four tiny heads read the same 32-channel map, so every pixel gets its own grasp in one pass.",
      towers: [
        { mod: "ggcnn", title: "GG-CNN", sub: "fully convolutional, no pooling, no FC",
          input: { label: "Depth image 300 × 300", caption: "inpainted, mean subtracted" },
          rows: [
            { t: "group", label: "Encoder, 3 strided convs", rows: [
              { t: "conv", label: "Conv 9 × 9 /3 · ReLU", call: ["32 filters → 100 × 100", "c1"] },
              { t: "conv", label: "Conv 5 × 5 /2 · ReLU", call: ["16 filters → 50 × 50", "c1"] },
              { id: "bott", t: "conv", label: "Conv 3 × 3 /2 · ReLU", call: ["8 filters → 25 × 25", "c1"], zoom: { k: "rows", title: "Feature-map sizes", rows: ["300 × 300 × 1 depth", "100 × 100 × 32", "50 × 50 × 16", "25 × 25 × 8 bottleneck", "back up: 50, 100, 300"] } } ] },
            { t: "group", label: "Decoder, 3 transposed convs", rows: [
              { t: "conv", label: "ConvT 3 × 3 ×2 · ReLU", call: ["8 filters → 50 × 50", "c1"] },
              { t: "conv", label: "ConvT 5 × 5 ×2 · ReLU", call: ["16 filters → 100 × 100", "c1"] },
              { t: "conv", label: "ConvT 9 × 9 ×3 · ReLU", call: ["32 filters → 300 × 300", "c1"] } ] },
            { t: "conv", label: "4 heads: Conv 2 × 2 each", call: ["Q, cos 2Φ, sin 2Φ, W; W scaled by 1/150", "c1", "p2"],
              zoom: { k: "rows", title: "Four output maps", rows: ["shared 32-channel map", "Q: grasp quality", "cos 2Φ and sin 2Φ", "W: gripper width", "Φ = ½ atan2(sin 2Φ, cos 2Φ)"] } } ],
          output: { label: "grasp map; best grasp = arg-max of Q" } }
      ]
    },
    modules: [
      { id: "ggcnn", role: "net", roleLabel: "Grasp CNN", name: "GG-CNN", sub: "6 conv layers · 62k params", col: 0, frozen: false, main: true, short: "GG-CNN", params: "62,420",
        stack: { rows: [
          { t: "in", label: "depth image I", dims: "300 × 300 × 1", c: "data-1" },
          { t: "conv", label: "Conv 9×9 /3 · Conv 5×5 /2 · Conv 3×3 /2", dims: "32 → 16 → 8 filters, down to 25 × 25" },
          { t: "conv", label: "ConvT 3×3 ×2 · ConvT 5×5 ×2 · ConvT 9×9 ×3", dims: "8 → 16 → 32 filters, back to 300 × 300" },
          { t: "conv", label: "Four Conv 2×2 heads", dims: "Q, cos 2Φ, sin 2Φ, W" },
          { t: "out", label: "grasp map G = (Q, Φ, W)", dims: "one grasp per pixel", c: "data-3" } ],
          facts: [["Parameters", ["62,420", "p1"]], ["Input", ["300 × 300 depth, inpainted, mean subtracted", "p2", "p3"]], ["Filters", ["32, 16, 8, 8, 16, 32", "c1"]], ["Kernels", ["9, 5, 3, 3, 5, 9", "c1"]], ["Strides", ["3, 2, 2, 2, 2, 3", "c1"]], ["Angle encoding", ["cos 2Φ and sin 2Φ, Φ ∈ [−π/2, π/2]", "p2"]], ["Loss (code)", ["MSE on each of the four maps", "c1"]], ["Selection", ["95 variants trained; best kept", "p1"]]] } }
    ],
    inputs: [{ to: "ggcnn", mod: "vision", label: "wrist depth image", n: "300 × 300", k: 4 }],
    outputs: [{ from: "ggcnn", mod: "action", label: "Q, Φ, W maps → best grasp", n: "per pixel", k: 4 }],
    links: [],
    callouts: [
      "The grasp is <b>generated</b>, not sampled and ranked: one pass scores every pixel, which is what makes closed-loop servoing possible (§I).",
      "The best of three local maxima closest to the previous target is tracked, so the controller does not jump between similar grasps (§V-D)."
    ]
  });

  /* ---------------- GR-ConvNet ---------------- */
  RB.arch.spec({
    id: "gr-convnet", method: "gr-convnet", name: "GR-ConvNet", year: 2020, parent: "gg-cnn",
    diffRows: ["params", "vision", "backbone", "head", "train"],
    figRef: "Kumra et al. Fig. 2 · §IV-C, §IV-E", prov: "grconvnet3, RGB-D",
    lede: "GG-CNN's per-pixel grasp map on a deeper net: three convolutions, five residual blocks at 56 × 56 and three transposed convolutions turn an n-channel image (RGB, depth or RGB-D) into quality, angle and width maps.",
    sources: {
      p1: { kind: "paper", ref: "Kumra et al. 2020, §IV-C (architecture) and Fig. 2", url: "https://arxiv.org/abs/1909.04810" },
      p2: { kind: "paper", ref: "Kumra et al. 2020, §IV-A, §IV-D, §IV-E (input, training, loss)", url: "https://arxiv.org/abs/1909.04810" },
      p3: { kind: "paper", ref: "Kumra et al. 2020, §V-A, Table III (datasets, speed)", url: "https://arxiv.org/abs/1909.04810" },
      c1: { kind: "code", repo: "skumra/robotic-grasping", path: "inference/models/grconvnet3.py", commit: "183c6f6", url: "https://github.com/skumra/robotic-grasping/blob/183c6f6/inference/models/grconvnet3.py" },
      c2: { kind: "code", repo: "skumra/robotic-grasping", path: "inference/models/grasp_model.py", commit: "183c6f6", url: "https://github.com/skumra/robotic-grasping/blob/183c6f6/inference/models/grasp_model.py" },
      c3: { kind: "code", repo: "skumra/robotic-grasping", path: "train_network.py", commit: "183c6f6", url: "https://github.com/skumra/robotic-grasping/blob/183c6f6/train_network.py" }
    },
    summary: {
      pattern: ["Grasp CNN (per-pixel)", "p1"],
      params: ["1,900,900", "p1"],
      vision: ["n-channel image 224 × 224: RGB, depth or RGB-D (depth inpainted)", "p2", "c3"],
      backbone: ["3 convs → 5 residual blocks (128 ch at 56 × 56) → 3 transposed convs", "p1", "c1"],
      head: ["Four 2 × 2 conv heads: Q, cos 2Θ, sin 2Θ, W", "c1"],
      output: ["Grasp map (Θ, W, Q) at every pixel", "p1"],
      attention: "None (convolutions only)",
      cond: null,
      steps: ["One forward pass, 20 ms for RGB-D (GTX 1080 Ti)", "p3"],
      chunk: null,
      rate: ["Suitable for closed loop up to 50 Hz", "p1"],
      latency: ["19–20 ms per image", "p3"],
      train: ["Cornell (augmented, ~51k grasps) or Jacquard (54k images, 1.1M grasps)", "p3"]
    },
    changes: [
      "Input becomes an <b>n-channel</b> image (RGB, depth or RGB-D) at 224 × 224 instead of depth only at 300 × 300.",
      "The 3-layer encoder gains BatchNorm and <b>5 residual blocks</b> at 56 × 56 with 128 channels.",
      "Parameters grow from 62,420 to 1,900,900.",
      "Loss switches to smooth L1 (Huber) on the four maps.",
      "The output format stays the same: Q, cos 2Θ, sin 2Θ and W per pixel."
    ],
    blueprint: {
      headline: "GR-ConvNet: GG-CNN plus residual blocks",
      note: "The encoder halves the image twice to 56 × 56. Five residual blocks work at that size with 128 channels; three transposed convolutions return to 224 × 224, where four 2 × 2 heads read the same 32-channel map.",
      towers: [
        { mod: "grconv", title: "GR-ConvNet", sub: "generative residual CNN (grconvnet3)",
          input: { label: "Image 224 × 224 × n", caption: "RGB, depth or RGB-D; n = 4 for RGB-D" },
          rows: [
            { t: "conv", label: "Conv 9 × 9 · BN · ReLU", call: ["32 channels at 224 × 224", "c1"] },
            { t: "conv", label: "Conv 4 × 4 /2 · BN · ReLU", call: ["64 channels at 112 × 112", "c1"] },
            { t: "conv", label: "Conv 4 × 4 /2 · BN · ReLU", call: ["128 channels at 56 × 56", "c1", "p1"] },
            { t: "block", n: "5", rows: [
              { t: "conv", label: "Conv 3 × 3 · BN · ReLU" },
              { id: "res", t: "conv", label: "Conv 3 × 3 · BN", call: ["128 channels, same size", "c1", "c2"], zoom: { k: "rows", title: "Residual block", rows: ["x (128 ch, 56 × 56)", "Conv 3×3 → BN → ReLU", "Conv 3×3 → BN", "x + F(x)"] } },
              { t: "add", span: 2 } ] },
            { t: "conv", label: "ConvT 4 × 4 ×2 · BN · ReLU", call: ["64 channels", "c1"] },
            { t: "conv", label: "ConvT 4 × 4 ×2 · BN · ReLU", call: ["32 channels, back to 224", "c1", "p1"] },
            { t: "conv", label: "ConvT 9 × 9", call: ["32 channels", "c1"] },
            { t: "conv", label: "4 heads: Conv 2 × 2 each", call: ["Q, cos 2Θ, sin 2Θ, W; dropout 0.1", "c1", "c3"],
              zoom: { k: "rows", title: "Four output maps", rows: ["shared 32-channel map", "Q: grasp quality", "cos 2Θ and sin 2Θ", "W: gripper width", "smooth L1 on each map"] } } ],
          output: { label: "Q, Θ, W maps; best pixel → grasp" } }
      ]
    },
    modules: [
      { id: "grconv", role: "net", roleLabel: "Grasp CNN", name: "GR-ConvNet", sub: "5 res blocks · 1.9M params", col: 0, frozen: false, main: true, short: "GR-ConvNet", params: "1,900,900",
        stack: { rows: [
          { t: "in", label: "n-channel image", dims: "224 × 224 × n", c: "data-1" },
          { t: "conv", label: "Conv 9×9 · Conv 4×4 /2 · Conv 4×4 /2 (BN, ReLU)", dims: "32 → 64 → 128 ch, 224 → 56" },
          { t: "block", label: "Residual block", n: "5", rows: [
            { t: "conv", label: "Conv 3×3 → BN → ReLU → Conv 3×3 → BN" }, { t: "add", span: 1 } ] },
          { t: "conv", label: "ConvT 4×4 ×2 · ConvT 4×4 ×2 · ConvT 9×9", dims: "128 → 64 → 32 → 32 ch, 56 → 224" },
          { t: "conv", label: "Four Conv 2×2 heads", dims: "Q, cos 2Θ, sin 2Θ, W" },
          { t: "out", label: "grasp map", dims: "224 × 224 × 4", c: "data-3" } ],
          facts: [["Parameters", ["1,900,900", "p1"]], ["Input", ["224 × 224, n channels", "p2", "c3"]], ["Base channels", ["32 (code default)", "c3"]], ["Residual blocks", ["5 at 56 × 56", "p1", "c1"]], ["Loss", ["smooth L1 (Huber)", "p2", "c2"]], ["Optimizer", ["Adam, lr 10⁻³, batch 8", "p2", "c3"]], ["Cornell accuracy", ["97.7 % IW, 96.6 % OW (RGB-D)", "p3"]]] } }
    ],
    inputs: [{ to: "grconv", mod: "vision", label: "RGB-D image", n: "224 × 224 × 4", k: 4 }],
    outputs: [{ from: "grconv", mod: "action", label: "Q, Θ, W maps → best grasp", n: "per pixel", k: 4 }],
    links: [],
    callouts: [
      "The paper states 1,900,900 parameters; the released <code>grconvnet3</code> with its default 32 base channels is the model drawn here.",
      "Same grasp-map output as GG-CNN; the gain comes from depth (5 residual blocks) and from using colour as well as depth."
    ]
  });

  /* ---------------- Dex-Net 4.0 (GQ-CNN) ---------------- */
  RB.arch.spec({
    id: "dex-net", method: "dex-net", name: "Dex-Net 4.0 GQ-CNN", year: 2019,
    figRef: "Mahler 2017 Fig. 4 · gqcnn 4.0 configs", prov: "GQCNN-4.0-PJ and GQCNN-4.0-SUCTION",
    lede: "Grasp-quality CNNs rank sampled candidates. A 96 × 96 depth crop, centred and rotated onto one candidate, plus the gripper depth goes in; the probability that the grasp is robust comes out. Dex-Net 4.0 trains one such net per gripper.",
    sources: {
      p1: { kind: "paper", ref: "Mahler et al. 2017 (Dex-Net 2.0), §IV-B and Fig. 4 (GQ-CNN inputs and output)", url: "https://arxiv.org/abs/1703.09312" },
      p2: { kind: "paper", ref: "Mahler et al. 2017 (Dex-Net 2.0), §V and App. B (sampling, CEM policy)", url: "https://arxiv.org/abs/1703.09312" },
      c1: { kind: "code", repo: "BerkeleyAutomation/gqcnn", path: "cfg/train_dex-net_4.0_pj.yaml", commit: "499a609", url: "https://github.com/BerkeleyAutomation/gqcnn/blob/499a609/cfg/train_dex-net_4.0_pj.yaml" },
      c2: { kind: "code", repo: "BerkeleyAutomation/gqcnn", path: "cfg/train_dex-net_4.0_suction.yaml", commit: "499a609", url: "https://github.com/BerkeleyAutomation/gqcnn/blob/499a609/cfg/train_dex-net_4.0_suction.yaml" },
      c3: { kind: "code", repo: "BerkeleyAutomation/gqcnn", path: "cfg/examples/replication/dex-net_4.0_pj.yaml", commit: "499a609", url: "https://github.com/BerkeleyAutomation/gqcnn/blob/499a609/cfg/examples/replication/dex-net_4.0_pj.yaml" },
      c4: { kind: "code", repo: "BerkeleyAutomation/gqcnn", path: "gqcnn/utils/utils.py", commit: "499a609", url: "https://github.com/BerkeleyAutomation/gqcnn/blob/499a609/gqcnn/utils/utils.py" }
    },
    summary: {
      pattern: ["Grasp-quality CNN (sample and rank)", "p1"],
      params: null,
      vision: ["Depth crop 96 × 96 × 1, centred on the grasp pixel and aligned with its axis", "c1", "p1"],
      backbone: ["Image stream: 4 convs (9, 5, 5, 5; 16 filters) + FC 128; pose stream FC 16", "c1"],
      head: ["Merge FC 128 → 2-way softmax", "c1"],
      output: ["Robustness Q ∈ [0, 1] for one candidate grasp", "p1"],
      attention: "None (convolutions only)",
      cond: ["Gripper depth z (plus one more pose value for suction) enters a separate pose stream", "p1", "c4"],
      steps: ["CEM: 128 seed candidates, 64 GMM samples, 3 iterations", "c3"],
      chunk: null, rate: null, latency: null, train: null
    },
    blueprint: {
      headline: "Dex-Net 4.0: score one grasp, twice",
      note: "Each candidate grasp gets its own crop, so the network never learns rotation: the crop is turned so the jaw axis is horizontal. The image stream and a small pose stream meet in one fully connected layer. The suction net has the same shape with fewer filters.",
      towers: [
        { mod: "gqpj", title: "GQ-CNN, parallel jaw", sub: "GQCNN-4.0-PJ",
          input: { label: "Depth crop 96 × 96", caption: "centred and rotated onto one candidate" },
          rows: [
            { id: "c11", t: "conv", label: "Conv 9 × 9 · ReLU", call: ["16 filters", "c1"],
              zoom: { k: "rows", title: "Grasp-aligned crop", rows: ["depth image of the heap", "sample antipodal candidates", "crop around the grasp pixel", "rotate to the jaw axis", "score each crop with GQ-CNN"] } },
            { t: "conv", label: "Conv 5 × 5 · max-pool /2", call: ["16 filters", "c1"] },
            { t: "conv", label: "Conv 5 × 5 · ReLU", call: ["16 filters", "c1"] },
            { t: "conv", label: "Conv 5 × 5 · max-pool /2", call: ["16 filters", "c1"] },
            { t: "linear", label: "FC3 (image stream)", call: ["128 units", "c1"] },
            { id: "merge", t: "mlp", label: "FC4 merge [image ‖ pose]", side: "depth z", call: ["pose stream FC 16 → merge 128", "c1"] },
            { t: "linear", label: "FC5 · softmax", call: ["2 classes: robust or not", "c1"],
              zoom: { k: "rows", title: "CEM grasp policy", rows: ["seed candidates", "score all with GQ-CNN", "fit GMM to the top quarter", "resample from the GMM", "repeat, return the best"] } } ],
          output: { label: "Q = P(robust | crop, z)" } },
        { mod: "gqsuc", title: "GQ-CNN, suction", sub: "GQCNN-4.0-SUCTION", compact: true,
          input: { label: "Depth crop 96 × 96", caption: "centred on the suction point" },
          rows: [
            { t: "conv", label: "Conv 9 × 9, then 3 × 3 ×3", call: ["8 filters each", "c2"] },
            { t: "linear", label: "FC3 (image stream)", call: ["64 units", "c2"] },
            { t: "mlp", label: "FC4 merge [image ‖ pose]", side: "pose", call: ["pose vector of 2", "c2", "c4"] },
            { t: "linear", label: "FC5 · softmax", call: ["2 classes", "c2"] } ],
          output: { label: "Q for a suction candidate" } }
      ]
    },
    modules: [
      { id: "gqpj", role: "critic", roleLabel: "Grasp-quality CNN", name: "GQ-CNN (jaw)", sub: "4 conv · FC 128 · 96² crop", col: 0, frozen: false, main: true, short: "GQ-CNN PJ",
        stack: { rows: [
          { t: "in", label: "depth crop aligned to the grasp", dims: "96 × 96 × 1", c: "data-1" },
          { t: "conv", label: "4 convs (9, 5, 5, 5), 2 pools", dims: "16 filters each" },
          { t: "linear", label: "FC3", dims: "128" },
          { t: "mlp", label: "pose stream: gripper depth z → FC", dims: "16" },
          { t: "mlp", label: "FC4 merge", dims: "128" },
          { t: "linear", label: "FC5 → softmax", dims: "2" },
          { t: "out", label: "robustness Q", dims: "one value per candidate", c: "data-8" } ],
          facts: [["Input size", ["96 × 96 × 1", "c1"]], ["Conv kernels", ["9, 5, 5, 5", "c1"]], ["Filters", ["16 per conv", "c1"]], ["Pooling", ["2 × 2 after the 2nd and 4th conv", "c1"]], ["Pose input", ["1 value (depth z)", "c4"]], ["Training", ["batch 64, 50 epochs (config)", "c1"]]] } },
      { id: "gqsuc", role: "critic", roleLabel: "Grasp-quality CNN", name: "GQ-CNN (suction)", sub: "4 conv · FC 64 · 96² crop", col: 1, frozen: false, short: "GQ-CNN suction" }
    ],
    inputs: [
      { to: "gqpj", mod: "vision", label: "aligned depth crop", n: "96 × 96", k: 3 },
      { to: "gqpj", mod: "state", label: "gripper depth z", n: "1 value", k: 1 },
      { to: "gqsuc", mod: "vision", label: "depth crop", n: "96 × 96", k: 3 }
    ],
    outputs: [{ from: "gqpj", mod: "other", label: "robustness Q", n: "per candidate", k: 1 }, { from: "gqsuc", mod: "other", label: "robustness Q", n: "per candidate", k: 1 }],
    links: [],
    callouts: [
      "The Dex-Net 4.0 paper (Science Robotics, 2019) could not be read here. Layer sizes come from the released <b>GQCNN-4.0</b> training configs; the input and output definition comes from Dex-Net 2.0.",
      "Dex-Net 2.0's GQ-CNN had about 18 million parameters and 32 × 32 crops; the released 4.0 nets are much narrower (16 or 8 filters)."
    ]
  });

  /* ---------------- 6-DOF GraspNet ---------------- */
  RB.arch.spec({
    id: "6-dof-graspnet", method: "6-dof-graspnet", name: "6-DOF GraspNet", year: 2019,
    figRef: "Mousavian et al. Figs. 3–4 · §3 · §4", prov: "",
    lede: "A PointNet++ VAE samples diverse 6-DoF grasps for one object point cloud, one per latent z. A second PointNet++ scores each grasp by looking at object and gripper points together, and its gradient nudges bad grasps into good ones.",
    sources: {
      p1: { kind: "paper", ref: "Mousavian et al. 2019, §3.1–3.3 (sampler, evaluator, refinement)", url: "https://arxiv.org/abs/1905.10520" },
      p2: { kind: "paper", ref: "Mousavian et al. 2019, §4 (network details, training)", url: "https://arxiv.org/abs/1905.10520" },
      p3: { kind: "paper", ref: "Mousavian et al. 2019, §4.1–4.2 (ablations, robot timing)", url: "https://arxiv.org/abs/1905.10520" },
      c1: { kind: "code", repo: "NVlabs/6dof-graspnet", path: "cfgs/config_Bottle_Bowl_Box_Cylinder_Mug_0.12.yml", commit: "cd08b6c", url: "https://github.com/NVlabs/6dof-graspnet/blob/cd08b6c/cfgs/config_Bottle_Bowl_Box_Cylinder_Mug_0.12.yml" },
      c2: { kind: "code", repo: "NVlabs/6dof-graspnet", path: "models/model.py", commit: "cd08b6c", url: "https://github.com/NVlabs/6dof-graspnet/blob/cd08b6c/models/model.py" },
      c3: { kind: "code", repo: "NVlabs/6dof-graspnet", path: "demo/main.py", commit: "cd08b6c", url: "https://github.com/NVlabs/6dof-graspnet/blob/cd08b6c/demo/main.py" }
    },
    summary: {
      pattern: ["Point-cloud grasp network", "p1"],
      params: null,
      vision: ["Segmented partial object point cloud, 1,024 points, in a frame at its centroid", "p1", "c1"],
      backbone: ["PointNet++: 3 set-abstraction layers + 2 FC of 1,024 (sampler and evaluator alike)", "p2", "c2"],
      head: ["Sampler: unit quaternion + translation. Evaluator: 2-way softmax", "p2"],
      output: ["Set of 6-DoF parallel-jaw grasps (R, T) with success probabilities", "p1"],
      attention: "None (PointNet++ grouping and max-pooling)",
      cond: ["Latent z (2-D) concatenated to every point feature in the decoder", "p1", "p3"],
      steps: ["Sample 200 latents, then iterative refinement (10 steps in ablations)", "p3"],
      chunk: null, rate: null,
      latency: ["VAE + evaluator 0.04 s; 0.3 s per refinement step for 200 grasps (Titan XP)", "p3"],
      train: ["FleX simulation: 206 objects, 7,074,038 grasps simulated, 2,104,894 successful", "p3"]
    },
    blueprint: {
      headline: "6-DOF GraspNet: sample with a VAE, then refine",
      note: "Two PointNet++ networks of the same shape. The sampler's decoder turns (points, z) into a grasp; the encoder is used only in training. The evaluator scores the object cloud merged with a gripper cloud rendered at that grasp, and its gradient moves the grasp.",
      towers: [
        { mod: "vae", title: "Grasp sampler (VAE decoder)", sub: "PointNet++, z ~ N(0, I)",
          input: { label: "Object points ‖ z", caption: "z is appended to every point" },
          rows: [
            { t: "embed", label: "Per-point [xyz ‖ z]", call: ["1,024 points; z has 2 dims", "c1", "p3"] },
            { id: "sa1", t: "conv", label: "SA1: 128 centres, r 2 cm", call: ["MLP 64, 64, 128", "p2", "c2"],
              zoom: { k: "rows", title: "Set-abstraction level", rows: ["pick centres (farthest point)", "group neighbours in radius r", "shared MLP on each point", "max-pool per group"] } },
            { t: "conv", label: "SA2: 32 centres, r 4 cm", call: ["MLP 128, 128, 256", "p2", "c2"] },
            { t: "pool", label: "SA3: all points (global)", call: ["MLP 256, 256, 512", "p2", "c2"] },
            { t: "mlp", label: "FC 1,024 · FC 1,024", call: ["2 fully connected layers", "p2"] },
            { t: "linear", label: "Heads: quaternion q, t", call: ["q L2-normalised; t unnormalised", "p2"] } ],
          output: { label: "grasp g = (R, T) per z" } },
        { mod: "eval", title: "Grasp evaluator", sub: "PointNet++ on object ∪ gripper",
          input: { label: "Object ∪ gripper points", caption: "gripper cloud rendered at g" },
          rows: [
            { t: "embed", label: "Per-point [xyz ‖ flag]", call: ["binary flag: object or gripper", "p1"] },
            { t: "conv", label: "PointNet++, 3 SA levels", call: ["same design as the sampler", "p2"] },
            { t: "mlp", label: "FC 1,024 · FC 1,024", call: ["2 fully connected layers", "p2"] },
            { id: "sm", t: "linear", label: "Softmax: success s", call: ["batches: 30 % pos, 30 % neg, 40 % hard neg", "p2"],
              zoom: { k: "rows", title: "Gradient refinement", rows: ["grasp g from the sampler", "s = P(success | g, X)", "Δg = η · ∂s/∂g (Euler, t)", "step ≤ 1 cm, repeat", "drop grasps below threshold"] } } ],
          output: { label: "s per grasp; ∂s/∂g refines g" } }
      ],
      links: [{ from: "vae", to: "eval", toRow: "input", label: "sampled grasps g" }]
    },
    modules: [
      { id: "vae", role: "net", roleLabel: "Grasp sampler (VAE)", name: "VAE sampler", sub: "PointNet++ · latent 2", col: 0, frozen: false, main: true, short: "VAE",
        stack: { rows: [
          { t: "in", label: "object points ‖ latent z", dims: "1,024 × (3 + 2)", c: "data-1" },
          { t: "conv", label: "SA1 128 centres, 2 cm · SA2 32, 4 cm · SA3 global", dims: "→ 128 → 256 → 512 ch" },
          { t: "mlp", label: "FC 1,024 → FC 1,024" },
          { t: "linear", label: "quaternion (L2-norm) and translation" },
          { t: "out", label: "grasp g = (R, T)", dims: "one per z", c: "data-3" } ],
          facts: [["Latent size", ["2", "p3", "c1"]], ["KL weight α", ["0.01", "p2", "c1"]], ["SA centres", ["128, 32, all", "p2", "c2"]], ["SA radii", ["2 cm, 4 cm, ∞", "p2"]], ["Grasps per batch", ["64 per rendered view", "p2", "c1"]], ["Loss", ["L1 on transformed gripper points + KL", "p1"]]] } },
      { id: "eval", role: "critic", roleLabel: "Grasp evaluator", name: "Evaluator", sub: "PointNet++ · obj ∪ gripper", col: 1, frozen: false, short: "Evaluator",
        stack: { rows: [
          { t: "in", label: "object ∪ gripper points + binary flag", c: "data-1" },
          { t: "conv", label: "PointNet++, 3 SA levels" },
          { t: "mlp", label: "FC 1,024 → FC 1,024" },
          { t: "linear", label: "softmax" },
          { t: "out", label: "success probability s", c: "data-8" } ],
          facts: [["Loss", ["cross-entropy", "p1"]], ["Hard negatives", ["positives perturbed by ±0.6 rad and ±3 cm", "p2"]], ["Refinement step", ["translation update ≤ 1 cm", "p1"]]] } }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "object point cloud", n: "1,024 pts", k: 4 },
      { to: "vae", mod: "latent", label: "latent z", n: "2-D", k: 1 },
      { to: "eval", mod: "vision", label: "object points", n: "+ gripper points", k: 3 }
    ],
    outputs: [{ from: "eval", mod: "action", label: "scored 6-DoF grasps", n: "200 per batch", k: 4 }],
    links: [{ from: "vae", to: "eval", kind: "feeds", label: "grasps g|as gripper points" }],
    callouts: [
      "Paper vs code: the paper refines with the evaluator's <b>gradient</b> (10 steps in the ablations); the released demo defaults to <b>sampling-based</b> refinement with 20 steps, and uses 10 steps only in gradient mode.",
      "The encoder Q(z | X, g) exists only at training time; at test time z is drawn from N(0, I)."
    ]
  });

  /* ---------------- Contact-GraspNet ---------------- */
  RB.arch.spec({
    id: "contact-graspnet", method: "contact-graspnet", name: "Contact-GraspNet", year: 2021, parent: "6-dof-graspnet",
    diffRows: ["vision", "backbone", "head", "output", "steps", "latency", "train"],
    figRef: "Sundermeyer et al. Figs. 3–4 · §III-A, §III-C–E", prov: "",
    lede: "A U-shaped PointNet++ reads the whole scene and treats every observed point as a possible grasp contact. Per point it predicts a contact score, two direction vectors and a width bin, which fix a full 6-DoF grasp.",
    sources: {
      p1: { kind: "paper", ref: "Sundermeyer et al. 2021, §III-A (contact grasp representation)", url: "https://arxiv.org/abs/2103.14127" },
      p2: { kind: "paper", ref: "Sundermeyer et al. 2021, §III-B–E (data, network, losses, training)", url: "https://arxiv.org/abs/2103.14127" },
      p3: { kind: "paper", ref: "Sundermeyer et al. 2021, §IV-A (inference, run time)", url: "https://arxiv.org/abs/2103.14127" },
      c1: { kind: "code", repo: "NVlabs/contact_graspnet", path: "contact_graspnet/config.yaml", commit: "7217060", url: "https://github.com/NVlabs/contact_graspnet/blob/7217060/contact_graspnet/config.yaml" }
    },
    summary: {
      pattern: ["Point-cloud grasp network", "p2"],
      params: null,
      vision: ["Scene point cloud from one depth image, 20,000 points (optionally a local region)", "p2", "c1"],
      backbone: ["Asymmetric U-shaped PointNet++: 3 MSG set-abstraction levels, global SA, 3 feature-propagation levels", "p2", "c1"],
      head: ["4 heads of two 1-D convs: contact score s, z₁, z₂, 10 width bins", "p2"],
      output: ["6-DoF grasp + width for each of 2,048 farthest-point-sampled points", "p2"],
      attention: "None (PointNet++ grouping and max-pooling)",
      cond: null,
      steps: ["One forward pass, then threshold 0.23 (0.19 fallback) and FPS on contacts", "p3", "c1"],
      chunk: null, rate: null,
      latency: ["0.28 s full scene, ~0.19 s local region", "p3"],
      train: ["ACRONYM (8,872 meshes, 17.7M grasps) in 10,000 rendered table scenes", "p2"]
    },
    changes: [
      "Input moves from a segmented <b>object</b> cloud to the whole <b>scene</b> cloud, so collisions with neighbours are learned.",
      "No VAE and no latent: every observed point is a candidate <b>contact</b>, which fixes the translation and leaves 4 DoF to predict.",
      "No evaluator network and no refinement loop: one forward pass gives grasps and confidences.",
      "Rotation comes from two predicted vectors joined by in-network Gram–Schmidt; width is a 10-bin classification.",
      "Trained on ACRONYM (8,872 objects) instead of 206 objects from 5 categories."
    ],
    blueprint: {
      headline: "Contact-GraspNet: every point a grasp contact",
      note: "Three multi-scale set-abstraction levels shrink 20,000 points to 128 centres, a global layer adds scene context, and feature propagation carries it back to 2,048 points. Four small heads then turn each point's feature into a grasp anchored at that point.",
      towers: [
        { mod: "cgn", title: "Contact-GraspNet", sub: "asymmetric U-shaped PointNet++",
          input: { label: "Scene points 20,000 × 3", caption: "from depth; centred at the mean" },
          rows: [
            { t: "group", label: "Set abstraction, 3 MSG levels", rows: [
              { id: "sa1", t: "conv", label: "SA1: 2,048 centres", call: ["radii 2, 4, 8 cm in parallel", "c1", "p2"],
                zoom: { k: "rows", title: "Multi-scale grouping (MSG)", rows: ["pick centres (farthest point)", "3 ball radii in parallel", "shared MLP per branch", "max-pool, concatenate"] } },
              { t: "conv", label: "SA2: 512 centres", call: ["radii 4, 8, 16 cm", "c1", "p2"] },
              { t: "conv", label: "SA3: 128 centres", call: ["radii 8, 16, 32 cm", "c1", "p2"] } ] },
            { t: "pool", label: "Global SA (all points)", call: ["MLP 256, 512, 1,024", "c1"] },
            { t: "conv", label: "Feature propagation ×3", call: ["back up to 2,048 points", "c1", "p2"] },
            { id: "heads", t: "conv", label: "4 heads, 1-D conv ×2 each", call: ["s, z₁, z₂, 10 width bins", "p2"],
              zoom: { k: "rows", title: "Four per-point heads", rows: ["per-point feature", "s: contact confidence", "b = z₁ / ‖z₁‖ (baseline)", "a = z₂ minus its b part (approach)", "width = best bin centre"] } },
            { t: "linear", label: "Grasp from contact c", call: ["t = c + (w/2)·b + d·a", "p1"],
              zoom: { k: "rows", title: "Contact grasp representation", rows: ["contact point c", "R = [b, a × b, a]", "t = c + (w/2)·b + d·a", "6-DoF pose + width w"] } } ],
          output: { label: "grasps at 2,048 points + scores" } }
      ]
    },
    modules: [
      { id: "cgn", role: "net", roleLabel: "Contact grasp net", name: "Contact-GraspNet", sub: "PointNet++ U-net · 4 heads", col: 0, frozen: false, main: true, short: "Contact-GraspNet",
        stack: { rows: [
          { t: "in", label: "scene point cloud", dims: "20,000 × 3", c: "data-1" },
          { t: "conv", label: "MSG SA levels at 2,048 / 512 / 128 centres", dims: "3 radii each" },
          { t: "pool", label: "global SA", dims: "MLP 256, 512, 1,024" },
          { t: "conv", label: "3 feature-propagation levels", dims: "to 2,048 points" },
          { t: "conv", label: "4 heads × two 1-D convs", dims: "s · z₁ · z₂ · width bins" },
          { t: "out", label: "per-point grasp (R, t, w) + confidence", c: "data-3" } ],
          facts: [["Input points", ["20,000", "p2", "c1"]], ["Output points", ["2,048 (FPS)", "p2", "c1"]], ["Width bins", ["10, max width 0.08 m", "p2", "c1"]], ["Positive contact radius", ["5 mm", "p2"]], ["Losses", ["top-k BCE (k = 512) + 10 × ADD-S + width BCE", "p2", "c1"]], ["Training", ["Adam lr 10⁻³, batch 3, ~40 h on one V100", "p2"]]] } }
    ],
    inputs: [{ to: "cgn", mod: "vision", label: "scene point cloud", n: "20,000 pts", k: 5 }],
    outputs: [{ from: "cgn", mod: "action", label: "6-DoF grasps + widths", n: "2,048", k: 5 }],
    links: [],
    callouts: [
      "Rooting each grasp at an observed contact reduces the learned output to <b>4 DoF</b> (rotation + width); the network is never asked to regress a free 3-D position.",
      "Instance masks are optional and only used afterwards, to assign grasps to objects by their contact points (Fig. 4)."
    ]
  });

  /* ---------------- GraspNet-1Billion baseline ---------------- */
  RB.arch.spec({
    id: "graspnet-1billion", method: "graspnet-1billion", name: "GraspNet-1Billion baseline", year: 2020,
    figRef: "Fang et al. CVPR 2020 Fig. 5 · §4 · §5.2", prov: "end-to-end baseline network",
    lede: "The benchmark's own network splits a grasp into parts. PointNet++ picks 1,024 seed points; ApproachNet scores 300 approach views per seed; a cylinder of points along the best view feeds OperationNet (rotation, width, score) and ToleranceNet.",
    sources: {
      p1: { kind: "paper", ref: "Fang et al. 2020, §4.1–4.5 and Fig. 5 (CVPR version)", url: "https://arxiv.org/abs/1912.13470" },
      p2: { kind: "paper", ref: "Fang et al. 2020, §5.2 (implementation details, CVPR version)", url: "https://arxiv.org/abs/1912.13470" },
      c1: { kind: "code", repo: "graspnet/graspnet-baseline", path: "models/backbone.py", commit: "280c215", url: "https://github.com/graspnet/graspnet-baseline/blob/280c215/models/backbone.py" },
      c2: { kind: "code", repo: "graspnet/graspnet-baseline", path: "models/graspnet.py", commit: "280c215", url: "https://github.com/graspnet/graspnet-baseline/blob/280c215/models/graspnet.py" },
      c3: { kind: "code", repo: "graspnet/graspnet-baseline", path: "models/modules.py", commit: "280c215", url: "https://github.com/graspnet/graspnet-baseline/blob/280c215/models/modules.py" }
    },
    summary: {
      pattern: ["Point-cloud grasp network", "p1"],
      params: null,
      vision: ["Single-view scene point cloud (RealSense or Kinect); 20k points sampled in training", "p1", "p2"],
      backbone: ["PointNet++: 4 SA layers + 2 FP layers → 1,024 seeds × 256", "p2", "c1"],
      head: ["ApproachNet → cylinder grouping → OperationNet + ToleranceNet", "p1"],
      output: ["Dense 6-DoF grasps G = [R t w] with scores and tolerance", "p1"],
      attention: "None (PointNet++ grouping and max-pooling)",
      cond: null,
      steps: ["One forward pass; grasps re-sorted by predicted tolerance within 10 score bins", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["GraspNet-1Billion: 97,280 real RGB-D images, over one billion analytic grasp labels", "p1"]
    },
    blueprint: {
      headline: "GraspNet baseline: view, then operation",
      note: "The backbone gives every seed point a 256-d feature. ApproachNet picks a view; points inside a cylinder along that view are re-expressed in its frame and pooled, once per approach depth. OperationNet and ToleranceNet read that pooled feature.",
      towers: [
        { mod: "pn", title: "PointNet++ backbone", sub: "4 SA + 2 FP", compact: true,
          input: { label: "Scene points N × 3", caption: "one RGB-D view" },
          rows: [
            { t: "conv", label: "SA1: 2,048 pts, r 4 cm", call: ["64 neighbours; MLP 64, 64, 128", "p2", "c1"] },
            { t: "conv", label: "SA2: 1,024 pts, r 10 cm", call: ["32 neighbours; MLP 128, 128, 256", "p2", "c1"] },
            { t: "conv", label: "SA3: 512 pts, r 20 cm", call: ["16 neighbours", "p2", "c1"] },
            { t: "conv", label: "SA4: 256 pts, r 30 cm", call: ["16 neighbours", "p2", "c1"] },
            { t: "conv", label: "FP ×2 up to 1,024 seeds", call: ["256-d feature per seed", "p2", "c1"] } ],
          output: { label: "M = 1,024 seeds × 256" } },
        { mod: "heads", title: "Grasp heads", sub: "Approach · Operation · Tolerance",
          input: { label: "Seed features", caption: "M × 256 with xyz" },
          rows: [
            { t: "mlp", label: "ApproachNet (shared MLP)", call: ["256, 302, 302: graspable (2) + 300 views", "p2", "c3"],
              zoom: { k: "rows", title: "Decoupled grasp pose", rows: ["grasp point = seed", "approach vector: 1 of 300 views", "in-plane rotation: 12 bins", "depth: 4 bins; width w", "G = [R t w]"] } },
            { id: "cyl", t: "conv", label: "Cylinder crop along view", call: ["radius 5 cm, 64 points, 4 depths", "c2", "c3"],
              zoom: { k: "rows", title: "Cylinder region", rows: ["seed + chosen view v", "one cylinder per depth (1–4 cm)", "sample 64 points, rotate to v", "MLP 64, 128, 256 → max-pool"] } },
            { t: "mlp", label: "OperationNet", call: ["128, 128, 36: 12 angles × 3 outputs", "p2", "c3"] },
            { t: "mlp", label: "ToleranceNet (GAF)", call: ["128, 64, 12: perturbation tolerance", "p2", "p1"] } ],
          output: { label: "grasps [R t w] + score + tolerance" } }
      ],
      links: [{ from: "pn", to: "heads", toRow: "input", label: "seed features" }]
    },
    modules: [
      { id: "pn", role: "vision-enc", roleLabel: "Point encoder", name: "PointNet++", sub: "4 SA · 2 FP → 1,024 × 256", col: 0, frozen: false, short: "PointNet++",
        stack: { rows: [
          { t: "in", label: "scene points", dims: "N × 3", c: "data-1" },
          { t: "conv", label: "SA 2,048 / 1,024 / 512 / 256 points", dims: "radii 0.04, 0.1, 0.2, 0.3 m" },
          { t: "conv", label: "2 feature-propagation layers", dims: "→ 1,024 × 256" },
          { t: "out", label: "seed features", c: "data-1" } ],
          facts: [["SA radii", ["0.04, 0.1, 0.2, 0.3 m", "p2", "c1"]], ["Group sizes", ["64, 32, 16, 16", "p2", "c1"]], ["Seeds", ["M = 1,024 at 256-d", "p2"]]] } },
      { id: "heads", role: "net", roleLabel: "Grasp heads", name: "Grasp heads", sub: "300 views · 12 angles", col: 1, frozen: false, main: true, short: "Heads",
        stack: { rows: [
          { t: "in", label: "seed features", dims: "1,024 × 256", c: "data-1" },
          { t: "mlp", label: "ApproachNet", dims: "2 + 300 per seed" },
          { t: "conv", label: "cylinder grouping per depth", dims: "64 points → MLP 64, 128, 256" },
          { t: "mlp", label: "OperationNet", dims: "12 × (class, score, width) per depth" },
          { t: "mlp", label: "ToleranceNet", dims: "12 tolerances per depth" },
          { t: "out", label: "grasps G = [R t w]", c: "data-3" } ],
          facts: [["Views V", ["300", "p2", "c2"]], ["Rotation bins", ["12 over 0–180°", "p1", "p2"]], ["Depth bins", ["0.01, 0.02, 0.03, 0.04 m", "p2", "c2"]], ["Cylinder", ["radius 0.05 m, 64 points", "c2", "c3"]], ["Loss weights λ₁, λ₂, λ₃, α, β", ["0.5, 1.0, 0.2, 0.5, 0.1", "p2"]], ["Training", ["Adam lr 10⁻³, batch 4, RTX 2080", "p2"]]] } }
    ],
    inputs: [{ to: "pn", mod: "vision", label: "scene point cloud", n: "~20k pts", k: 5 }],
    outputs: [{ from: "heads", mod: "action", label: "dense 6-DoF grasps", n: "per seed", k: 5 }],
    links: [{ from: "pn", to: "heads", kind: "feeds", label: "1,024 seeds|× 256-d" }],
    callouts: [
      "Classifying rotation into bins beat regressing it: AP 29.88 vs 23.74 on the Kinect seen split (Table 4).",
      "The arXiv v2 of this paper is an earlier dataset-only draft; the network appears in the CVPR 2020 version, which is the one cited here."
    ]
  });

  /* ---------------- AnyGrasp ---------------- */
  RB.arch.spec({
    id: "anygrasp", method: "anygrasp", name: "AnyGrasp", year: 2023, parent: "graspnet-1billion",
    diffRows: ["backbone", "head", "output", "latency", "train"],
    figRef: "Fang et al. Figs. 2–3 · §IV-B, §IV-C", prov: "",
    lede: "GSNet predicts dense 7-DoF grasps from one point cloud with a sparse 3-D conv backbone, graspness-guided seed and view selection and a centre-of-gravity stable score. A temporal module embeds each grasp so it can be matched in the next frame.",
    sources: {
      p1: { kind: "paper", ref: "Fang et al. 2023, §IV-B (geometry and temporal modules) and Figs. 2–3", url: "https://arxiv.org/abs/2212.08333" },
      p2: { kind: "paper", ref: "Fang et al. 2023, §IV-A, §IV-C, §IV-D (data, training, post-processing)", url: "https://arxiv.org/abs/2212.08333" },
      p3: { kind: "paper", ref: "Fang et al. 2023, §I and §V-A (speed, hardware)", url: "https://arxiv.org/abs/2212.08333" },
      c1: { kind: "code", repo: "graspnet/anygrasp_sdk", path: "README.md", commit: "b8eaafc", url: "https://github.com/graspnet/anygrasp_sdk/blob/b8eaafc/README.md" }
    },
    summary: {
      pattern: ["Point-cloud grasp network", "p1"],
      params: "not disclosed",
      vision: ["Single-view point cloud (colour used for tracking) from D415, D435 or L515", "p3"],
      backbone: ["GSNet: 3-D sparse-conv backbone, graspable FPS of 1,024 seeds, 300 candidate views", "p1"],
      head: ["MLP per seed: 12 rotations × 5 depths (score, width) + 12 stable scores", "p1"],
      output: ["Dense 7-DoF grasps G = [R t w]; top 100 kept after collision check", "p1", "p2"],
      attention: "None (sparse convolutions, MLPs)",
      cond: null,
      steps: ["One pass per frame; temporal embeddings matched by cosine similarity", "p1"],
      chunk: null, rate: null,
      latency: ["Grasps in 100 ms; post-processing 80 ms for 100 grasps", "p3", "p2"],
      train: ["GraspNet-1Billion train set + 168 new scenes: 268 real scenes, 144 objects", "p2"]
    },
    changes: [
      "The PointNet++ backbone becomes a <b>3-D sparse-conv</b> network on 5 mm voxels (GSNet).",
      "Seeds and views are chosen by predicted <b>graspness</b> (graspable FPS and probabilistic view selection).",
      "A fifth approach depth (0.5 cm) and a centre-of-gravity <b>stable score</b> are added to the head.",
      "A new <b>temporal association</b> module gives every grasp a 256-d embedding for tracking across frames.",
      "Trained on 268 real scenes (GraspNet-1Billion plus 168 new ones) instead of 100."
    ],
    blueprint: {
      headline: "AnyGrasp: dense grasps that can be tracked",
      note: "The geometry module runs on every frame. Its seed and grasp features, together with a colour feature pooled from 16 points in each grasp's cylinder, go through an MLP to a 256-d embedding; embeddings from two frames give an M × M correspondence matrix.",
      towers: [
        { mod: "gsnet", title: "Geometry module (GSNet)", sub: "sparse 3-D conv + graspness",
          input: { label: "Point cloud (xyz)", caption: "voxelised at 5 mm" },
          rows: [
            { t: "conv", label: "Sparse 3-D conv backbone", call: ["5 mm voxels; layers not disclosed", "p2", "c1"] },
            { t: "mlp", label: "Objectness + graspness MLP", call: ["per-point heat map", "p1"] },
            { t: "pool", label: "Graspable FPS", call: ["M = 1,024 seeds", "p1"] },
            { t: "mlp", label: "View MLP · graspable PVS", call: ["300 view scores per seed", "p1"] },
            { t: "conv", label: "Cylinder grouping on view" },
            { id: "gh", t: "mlp", label: "Grasp MLP", call: ["12 × 5 × 2 + 12 values per seed", "p1"],
              zoom: { k: "rows", title: "Grasp head outputs", rows: ["12 rotations × 5 depths", "score and width for each", "+ 12 stable (COG) scores", "score × (1 − stable score)", "top 100 → collision check"] } } ],
          output: { label: "M grasps [R t w] + features" } },
        { mod: "temporal", title: "Temporal association", sub: "grasp embedding for tracking", compact: true,
          input: { label: "Seed + grasp features", caption: "plus RGB and pose" },
          rows: [
            { t: "conv", label: "Colour cylinder grouping", call: ["K = 16 RGB points per grasp", "p1"] },
            { t: "mlp", label: "MLP + pooling (colour)" },
            { id: "emb", t: "mlp", label: "Concat → MLP embedding", call: ["C = 256 per grasp", "p1"],
              zoom: { k: "rows", title: "Grasp tracking", rows: ["seed ‖ grasp ‖ colour ‖ pose", "MLP → 256-d embedding", "cosine similarity, M × M", "keep the top matches", "supervised contrastive loss"] } } ],
          output: { label: "correspondence to the last frame" } }
      ],
      links: [{ from: "gsnet", to: "temporal", toRow: "input", label: "seed + grasp features" }]
    },
    modules: [
      { id: "gsnet", role: "net", roleLabel: "Grasp detector", name: "GSNet geometry", sub: "sparse conv · 1,024 seeds", col: 0, frozen: false, main: true, short: "GSNet",
        stack: { rows: [
          { t: "in", label: "point cloud", dims: "5 mm voxels", c: "data-1" },
          { t: "conv", label: "3-D sparse-conv backbone" },
          { t: "mlp", label: "objectness + graspness", dims: "per point" },
          { t: "pool", label: "graspable FPS", dims: "1,024 seeds" },
          { t: "mlp", label: "view scores → graspable PVS", dims: "300 views" },
          { t: "mlp", label: "cylinder grouping → grasp MLP", dims: "12 × 5 × 2 + 12" },
          { t: "out", label: "7-DoF grasps", c: "data-3" } ],
          facts: [["Seeds", ["1,024", "p1", "p2"]], ["Views", ["300", "p1"]], ["Depths", ["5 (0.5, 1, 2, 3, 4 cm)", "p2"]], ["Voxel", ["0.005 m", "p2"]], ["Optimizer", ["Adam lr 10⁻³, poly decay 0.9, batch 4", "p2"]]] } },
      { id: "temporal", role: "net", roleLabel: "Tracker", name: "Temporal module", sub: "256-d grasp embedding", col: 1, frozen: false, short: "Temporal",
        stack: { rows: [
          { t: "in", label: "seed, grasp, colour features + pose", c: "data-1" },
          { t: "mlp", label: "MLP", dims: "→ C = 256" },
          { t: "out", label: "embedding per grasp", dims: "cosine similarity across frames", c: "data-7" } ],
          facts: [["Embedding", ["C = 256", "p1", "p2"]], ["Colour points", ["K = 16", "p1", "p2"]], ["Contrastive σ, τ", ["0.1, 0.1", "p1"]]] } }
    ],
    inputs: [{ to: "gsnet", mod: "vision", label: "point cloud (+ RGB)", n: "single view", k: 5 }],
    outputs: [{ from: "gsnet", mod: "action", label: "7-DoF grasps", n: "M = 1,024", k: 5 }, { from: "temporal", mod: "latent", label: "grasp embeddings", n: "256-d", k: 2 }],
    links: [{ from: "gsnet", to: "temporal", kind: "feeds", label: "seed + grasp|features" }],
    callouts: [
      "AnyGrasp ships as a licensed SDK of compiled <code>gsnet</code> libraries; the sparse-conv backbone's layers are specified neither there nor in this paper (they come from GSNet, ICCV 2021).",
      "The temporal module is trained on adjacent camera views of static scenes, which mimic small object motions (§IV-A)."
    ]
  });

  /* ---------------- LGD (Grasp-Anything++) ---------------- */
  RB.arch.spec({
    id: "grasp-anything-lgd", method: "grasp-anything-lgd", name: "LGD", year: 2024,
    figRef: "Vuong et al. Fig. 4 · §4 · App. D, Tables 7–8", prov: "LGD + CLIP text encoder",
    lede: "Language-driven grasp detection as diffusion over one 5-number grasp rectangle. ALBEF fuses image and instruction; its attention map is the rough estimate x̃₀, and small MLPs combine it with the step and the noisy grasp to predict the clean grasp.",
    sources: {
      p1: { kind: "paper", ref: "Vuong et al. 2024, §4.1–4.2 and Fig. 4", url: "https://arxiv.org/abs/2406.09489" },
      p2: { kind: "paper", ref: "Vuong et al. 2024, App. D.2, Tables 7–8 (architecture, hyperparameters)", url: "https://arxiv.org/abs/2406.09489" },
      p3: { kind: "paper", ref: "Vuong et al. 2024, App. F, Table 9 (parameters) and §5.1", url: "https://arxiv.org/abs/2406.09489" },
      c1: { kind: "code", repo: "Fsoft-AIC/LGD", path: "inference/models/lgdm/network.py", commit: "501904d", url: "https://github.com/Fsoft-AIC/LGD/blob/501904d/inference/models/lgdm/network.py" },
      c2: { kind: "code", repo: "Fsoft-AIC/LGD", path: "inference/models/lgdm/albef/models/model_retrieval.py", commit: "501904d", url: "https://github.com/Fsoft-AIC/LGD/blob/501904d/inference/models/lgdm/albef/models/model_retrieval.py" }
    },
    summary: {
      pattern: ["Language-conditioned grasp model", "p1"],
      params: ["5.18M (trainable, as reported)", "p3"],
      vision: ["ResNet-50 on a 224 × 224 RGB image, 196 patches", "p2"],
      backbone: ["ALBEF fusion, 6 attention layers; output attention map x̃₀ and a 1,024-d joint feature", "p2"],
      head: ["MLPs: step → 32, fused feature → 256, noisy grasp → 256; concat → MLP → 5", "p2"],
      output: ["Grasp rectangle x₀ = (x, y, w, h, θ)", "p2"],
      attention: ["Cross-attention from image patches to text tokens inside ALBEF", "p2"],
      cond: ["Text: CLIP (512-d) or BERT (768-d) → MLP → 128-d tokens", "p2"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["Grasp-Anything++: 1M images, 10M+ instructions; L = contrastive + diffusion", "p1"]
    },
    blueprint: {
      headline: "LGD: denoise a grasp toward the attention map",
      note: "Image and text are encoded once. ALBEF's cross-attention yields a map x̃₀ (where the instruction points) and a joint feature. At every step the denoiser MLPs see the step, the joint feature and the current noisy rectangle; the contrastive loss ties x̃₀ to the noisy grasp.",
      towers: [
        { mod: "res", title: "ResNet-50", sub: "vision encoder", compact: true,
          input: { label: "RGB 224 × 224", caption: "one image" },
          rows: [{ t: "conv", label: "ResNet-50 feature map", call: ["196 patches (N)", "p2"] }],
          output: { label: "image patches v" } },
        { mod: "albef", title: "Text encoder + ALBEF", sub: "CLIP text, then fusion",
          input: { label: "Instruction text", caption: "e.g. 'grasp the knife handle'" },
          rows: [
            { t: "embed", label: "CLIP text embedding", call: ["512-d (BERT: 768-d)", "p2"] },
            { t: "mlp", label: "MLP → text tokens u", call: ["N + 1 tokens × 128", "p2"] },
            { t: "block", n: "6", rows: [
              { id: "xa", t: "attn", label: "Cross-attention v ↔ u", call: ["6 attention layers", "p2"] },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "Attention map x̃₀", call: ["224 × 224 (W × H)", "p2"],
              zoom: { k: "rows", title: "Contrastive term", rows: ["x̃₀: where the text points", "x(T): fully noised grasp", "‖(√ᾱ(T) x̃₀ − x(T))/√(1 − ᾱ(T))‖² − M", "hinge at 0; M = 5", "pushes x̃₀ toward x₀"] } },
            { t: "linear", label: "Joint feature z*", call: ["ℓ = 1,024", "p2"] } ],
          output: { label: "x̃₀ and z*" } },
        { mod: "den", title: "Denoiser", sub: "MLPs, signal prediction", compact: true,
          input: { label: "Noisy grasp xₜ₊₁", caption: "5 numbers, step t + 1" },
          rows: [
            { t: "mlp", label: "MLP(t + 1)", call: ["→ 32", "p2"] },
            { t: "mlp", label: "MLP(z*)", call: ["→ 256", "p2"] },
            { t: "mlp", label: "MLP(xₜ₊₁)", call: ["→ 256", "p2"] },
            { id: "cat", t: "linear", label: "Concat → MLP → xₜ", call: ["544 → 5 (32 + 256 + 256)", "p2"],
              zoom: { k: "rows", title: "Grasp rectangle", rows: ["centre (x, y)", "width w, height h", "angle θ to the image axis", "M = 5 numbers"] } } ],
          output: { label: "cleaner grasp xₜ" } }
      ],
      links: [
        { from: "albef", to: "den", toRow: "cat", label: "x̃₀, z*" },
        { from: "res", to: "albef", toRow: "xa", label: "image patches v" }
      ]
    },
    modules: [
      { id: "res", role: "vision-enc", name: "ResNet-50", sub: "224² → 196 patches", col: 0, frozen: false, short: "ResNet-50" },
      { id: "albef", role: "fusion", name: "Text + ALBEF", sub: "CLIP text · 6 attn layers", col: 1, frozen: false, short: "ALBEF",
        stack: { rows: [
          { t: "in", label: "image patches + text tokens", c: "data-2" },
          { t: "block", label: "multimodal layer", n: "6", rows: [{ t: "attn", label: "cross-attention image ↔ text" }, { t: "ffn", label: "feed forward" }] },
          { t: "out", label: "attention map x̃₀ · joint feature z*", dims: "224 × 224 · 1,024", c: "data-2" } ],
          facts: [["Attention layers", ["6", "p2"]], ["Text token width", ["128", "p2"]], ["Joint feature ℓ", ["1,024", "p2"]]] } },
      { id: "den", role: "action-head", roleLabel: "Grasp denoiser", name: "Denoiser MLPs", sub: "32 + 256 + 256 → 5", col: 2, frozen: false, main: true, short: "Denoiser",
        stack: { rows: [
          { t: "in", label: "t + 1 · z* · xₜ₊₁", c: "data-3" },
          { t: "mlp", label: "three MLPs", dims: "32 · 256 · 256" },
          { t: "mlp", label: "concat → MLP", dims: "→ 5" },
          { t: "out", label: "xₜ (signal prediction)", c: "data-3" } ],
          facts: [["d(ts), d(vl), d(df)", ["32, 256, 256", "p2"]], ["Grasp size M", ["5", "p2"]], ["Loss", ["contrastive + ‖x₀ − f(xₜ₊₁, t + 1, x̃₀)‖²", "p1"]]] } }
    ],
    inputs: [
      { to: "res", mod: "vision", label: "RGB image", n: "224 × 224", k: 4 },
      { to: "albef", mod: "lang", label: "grasp instruction", n: "object or part", k: 3 },
      { to: "den", mod: "action", label: "noisy rectangle", n: "5 numbers", k: 2, noisy: true },
      { to: "den", mod: "time", label: "step t + 1", n: "→ 32", k: 1 }
    ],
    outputs: [{ from: "den", mod: "action", label: "grasp rectangle", n: "(x, y, w, h, θ)", k: 2 }],
    links: [
      { from: "res", to: "albef", kind: "feeds", label: "image patches" },
      { from: "albef", to: "den", kind: "feeds", label: "x̃₀ and z*" }
    ],
    callouts: [
      "Paper vs code: the paper describes a ResNet-50 encoder and an MLP denoiser over 5 numbers. The released <code>lgdm</code> uses ALBEF's ViT-B/16 (12 layers, fusion from layer 6), masks the RGB image with the ALBEF attention, and predicts GG-CNN-style per-pixel maps; the step t is not used in its forward pass.",
      "Without x̃₀ the success rate collapses from 0.48 to 0.15 on seen objects (Table 3)."
    ]
  });

  /* ---------------- LGrasp6D (Grasp-Anything-6D) ---------------- */
  RB.arch.spec({
    id: "grasp-anything-6d", method: "grasp-anything-6d", name: "LGrasp6D", year: 2024,
    figRef: "Nguyen et al. Fig. 3 · §4.2–4.3 · App. D.1", prov: "",
    lede: "A diffusion model over one 6-DoF grasp (se(3) + width) in a cluttered point cloud. One query built from grasp, text and step cross-attends to 128 PointNet++ scene tokens; a learned negative prompt steers sampling away from other objects.",
    sources: {
      p1: { kind: "paper", ref: "Nguyen et al. 2024, §4.2 and Fig. 3 (denoiser, negative prompt)", url: "https://arxiv.org/abs/2407.13842" },
      p2: { kind: "paper", ref: "Nguyen et al. 2024, §4.3 and Table 2 (training, sampling, DDIM)", url: "https://arxiv.org/abs/2407.13842" },
      p3: { kind: "paper", ref: "Nguyen et al. 2024, App. D.1 and Table 8 (dimensions, encoders)", url: "https://arxiv.org/abs/2407.13842" },
      c1: { kind: "code", repo: "Fsoft-AIC/Language-Driven-6-DoF-Grasp-Detection-Using-Negative-Prompt-Guidance", path: "models/noise_predictor.py", commit: "ed31348", url: "https://github.com/Fsoft-AIC/Language-Driven-6-DoF-Grasp-Detection-Using-Negative-Prompt-Guidance/blob/ed31348/models/noise_predictor.py" },
      c2: { kind: "code", repo: "Fsoft-AIC/Language-Driven-6-DoF-Grasp-Detection-Using-Negative-Prompt-Guidance", path: "models/utils.py", commit: "ed31348", url: "https://github.com/Fsoft-AIC/Language-Driven-6-DoF-Grasp-Detection-Using-Negative-Prompt-Guidance/blob/ed31348/models/utils.py" },
      c3: { kind: "code", repo: "Fsoft-AIC/Language-Driven-6-DoF-Grasp-Detection-Using-Negative-Prompt-Guidance", path: "config/Denoiser.py", commit: "ed31348", url: "https://github.com/Fsoft-AIC/Language-Driven-6-DoF-Grasp-Detection-Using-Negative-Prompt-Guidance/blob/ed31348/config/Denoiser.py" }
    },
    summary: {
      pattern: ["Language-conditioned grasp model", "p1"],
      params: null,
      vision: ["Single-view scene point cloud, 8,192 points → PointNet++ (about 2M params) → 128 tokens", "p3"],
      backbone: ["One multi-head cross-attention (4 heads, 512-d) from a unified query to the scene tokens", "p3", "c1"],
      head: ["MLP 512 → 128 → 7: noise on se(3) (6) + width (1)", "c1"],
      output: ["6-DoF grasp: se(3) vector + gripper width", "p1"],
      attention: ["1 query token cross-attends to 128 scene tokens", "p3", "c1"],
      cond: ["Frozen CLIP ViT-B/32 text (512-d) summed with the grasp embedding; sinusoidal step (64-d) concatenated", "p1", "p3"],
      steps: ["T = 200 DDPM steps (β 10⁻⁴ → 0.02); DDIM 10–100 also tested", "p2", "c3"],
      chunk: null, rate: null,
      latency: ["1.48 s per 1,000 grasps at 200 steps; 0.07 s at 10 DDIM steps", "p2"],
      train: ["Grasp-Anything-6D: 1M scenes, ~200M grasps; 200 epochs on 8 A100s", "p2", "p3"]
    },
    blueprint: {
      headline: "LGrasp6D: diffusion with a negative prompt",
      note: "Scene tokens, text embedding and the negative embedding t̃ are computed once. Each step builds one query from grasp, text and step, cross-attends to the scene and predicts the noise. Sampling mixes three passes: no text, the prompt, and t̃.",
      towers: [
        { mod: "pn", title: "Scene encoder", sub: "PointNet++", compact: true,
          input: { label: "Scene points 8,192", caption: "xyz + colour" },
          rows: [
            { t: "conv", label: "PointNet++ (MSG) levels", call: ["first level: 2,048 centres", "c2"] },
            { t: "linear", label: "Scene tokens", call: ["nₛ = 128 tokens", "p3", "c1"] },
            { t: "mlp", label: "Negative-prompt MLP", call: ["mean(scene − text) → t̃ (512-d)", "p1", "c1"],
              zoom: { k: "rows", title: "Negative prompt guidance", rows: ["ε(g, S, ∅): text dropped", "ε(g, S, t): the prompt", "ε(g, S, t̃): learned negative", "ε̃ = ε∅ + w·(εₜ − ε(t̃))", "w = 0.2 at sampling"] } } ],
          output: { label: "128 scene tokens · t̃" } },
        { mod: "den", title: "Denoiser", sub: "grasp + text + step query",
          input: { label: "Noisy grasp gₜ", caption: "se(3) + width = 7 numbers" },
          rows: [
            { t: "mlp", label: "Grasp MLP", call: ["7 → 64 → 256 → 512", "c2"] },
            { t: "linear", label: "+ text embedding (sum)", side: "CLIP", call: ["frozen CLIP ViT-B/32, 512-d", "p3"] },
            { t: "mlp", label: "[· ‖ sinusoid(t)] → MLP", call: ["64-d step embedding → 512", "p3", "c1"] },
            { id: "xa", t: "attn", label: "Cross-attn to scene", call: ["4 heads, width 512", "p3", "c1"], zoom: { k: "heads", q: 4, kv: 4, hd: 128, title: "Cross-attention heads" } },
            { t: "add", span: 1 },
            { t: "mlp", label: "MLP 512 → 128 → 7", call: ["predicted noise εθ", "c1"] } ],
          output: { label: "εθ; 200 reverse steps" } }
      ],
      links: [{ from: "pn", to: "den", toRow: "xa", label: "scene tokens (K, V)" }]
    },
    modules: [
      { id: "pn", role: "vision-enc", roleLabel: "Point encoder", name: "PointNet++", sub: "8,192 pts → 128 tokens", col: 0, frozen: "partial", short: "PointNet++", note: "Frozen after the first 100 epochs." },
      { id: "den", role: "action-head", roleLabel: "Grasp denoiser", name: "LGrasp6D denoiser", sub: "1 query · 4-head x-attn", col: 1, frozen: false, main: true, short: "Denoiser",
        stack: { rows: [
          { t: "in", label: "noisy grasp gₜ · text t · step t", c: "data-3" },
          { t: "mlp", label: "grasp MLP 7 → 512, + text", dims: "512" },
          { t: "mlp", label: "[· ‖ sinusoid 64] → MLP", dims: "512" },
          { t: "attn", label: "cross-attention to 128 scene tokens", dims: "4 heads" },
          { t: "mlp", label: "MLP 512 → 128 → 7" },
          { t: "out", label: "noise εθ", dims: "7", c: "data-3" } ],
          facts: [["Steps T", ["200, linear β 10⁻⁴ → 0.02", "p2", "c3"]], ["Text drop p(mask)", ["0.1", "p2", "c3"]], ["Guidance w", ["0.2", "p2"]], ["Loss", ["0.9 L(noise) + 0.1 L(negative)", "p2"]], ["Optimizer", ["Adam lr 10⁻³, wd 10⁻⁴, batch 128", "p2", "c3"]]] } }
    ],
    inputs: [
      { to: "pn", mod: "vision", label: "scene point cloud", n: "8,192 pts", k: 5 },
      { to: "den", mod: "lang", label: "prompt (CLIP)", n: "512-d", k: 2 },
      { to: "den", mod: "action", label: "noisy grasp", n: "7 numbers", k: 2, noisy: true },
      { to: "den", mod: "time", label: "step t", n: "64-d", k: 1 }
    ],
    outputs: [{ from: "den", mod: "action", label: "6-DoF grasp", n: "se(3) + width", k: 2 }],
    links: [{ from: "pn", to: "den", kind: "cross-attn", label: "128 scene|tokens" }],
    callouts: [
      "Paper vs code: App. D.1 says the scene tokens are <b>256-d</b>; the released noise predictor uses <b>512-d</b> tokens (B × 128 × 512).",
      "Sampling needs three denoiser passes per step (∅, prompt, negative), yet scene tokens and embeddings are cached, so only the small query path reruns."
    ]
  });

  /* ---------------- GraspGPT ---------------- */
  RB.arch.spec({
    id: "graspgpt", method: "graspgpt", name: "GraspGPT", year: 2023,
    figRef: "Tang et al. Fig. 2 · §IV-C–D · App. Table IX", prov: "",
    lede: "A task-oriented grasp evaluator. An LLM writes descriptions of the object class and task; a two-layer cross-attention decoder injects them into the instruction, and a PointNet++ reads the object with the candidate gripper to score each grasp.",
    sources: {
      p1: { kind: "paper", ref: "Tang et al. 2023, §IV-C–D and Fig. 2", url: "https://arxiv.org/abs/2307.13204" },
      p2: { kind: "paper", ref: "Tang et al. 2023, §V-B–C (robot setup, implementation)", url: "https://arxiv.org/abs/2307.13204" },
      p3: { kind: "paper", ref: "Tang et al. 2023, App. B, Table IX (hyperparameters)", url: "https://arxiv.org/abs/2307.13204" },
      p4: { kind: "paper", ref: "Tang et al. 2023, Table V (language encoder ablation)", url: "https://arxiv.org/abs/2307.13204" },
      c1: { kind: "code", repo: "mkt1412/GraspGPT_public", path: "gcngrasp/models/graspgpt_plain.py", commit: "0ec44a1", url: "https://github.com/mkt1412/GraspGPT_public/blob/0ec44a1/gcngrasp/models/graspgpt_plain.py" }
    },
    summary: {
      pattern: ["Language-conditioned grasp model", "p1"],
      params: null,
      vision: ["Partial object point cloud, 4,096 points, plus 6 gripper control points", "p1", "p3"],
      backbone: ["PointNet++ (3 SA layers: 512, 128, 1 centres) → 1,024-d → 300-d shape", "p1", "p3"],
      head: ["Task-oriented grasp evaluator: 2 cross-attention decoder layers, mean pool, 3-layer MLP → sigmoid", "p1"],
      output: ["Task-compatibility score S for each candidate grasp", "p1"],
      attention: ["Instruction tokens cross-attend to description tokens, 8 heads at width 128", "p1"],
      cond: ["Frozen BERT-Base encodes instruction and LLM descriptions (768-d tokens)", "p1"],
      steps: ["Contact-GraspNet proposes 50 candidates; each is scored once", "p2"],
      chunk: null, rate: null, latency: null,
      train: ["LA-TaskGrasp: TaskGrasp (250K grasps, 56 tasks, 75 classes) + GPT-3 descriptions", "p2"]
    },
    blueprint: {
      headline: "GraspGPT: LLM descriptions steer a grasp scorer",
      note: "Sample-then-evaluate. The grasp enters only through the gripper points added to the object cloud. Text never touches the points until the end: instruction, task and object descriptions meet in the decoder, and the pooled sentence joins the shape embedding in the final MLP.",
      towers: [
        { mod: "pn", title: "Object + grasp encoder", sub: "PointNet++", compact: true,
          input: { label: "Object ∪ gripper points", caption: "4,096 + 6 points, binary flag" },
          rows: [
            { t: "conv", label: "SA1: 512 centres (MSG)", call: ["→ 320-d", "p3", "c1"] },
            { t: "conv", label: "SA2: 128 centres (MSG)", call: ["→ 640-d", "p3", "c1"] },
            { t: "pool", label: "SA3: global", call: ["→ 1,024-d", "p1", "p3"] },
            { t: "linear", label: "FC → shape embedding", call: ["F̃ₓ ∈ R³⁰⁰", "p1", "c1"] } ],
          output: { label: "300-d shape + grasp" } },
        { mod: "bert", title: "BERT-Base", sub: "frozen", compact: true,
          input: { label: "Instruction + descriptions", caption: "LLM-written paragraphs" },
          rows: [{ t: "embed", label: "BERT word embeddings", call: ["12 layers, 768-d tokens", "p4", "p1"] }],
          output: { label: "F(I), F(od), F(td)" } },
        { mod: "tge", title: "Grasp evaluator (TGE)", sub: "customised transformer decoder",
          input: { label: "Instruction tokens", caption: "plus description tokens" },
          rows: [
            { t: "linear", label: "Project 768 → 128", call: ["instruction, task, object text", "p1", "c1"] },
            { t: "block", n: "2", label: "object, then task", rows: [
              { id: "ca", t: "attn", label: "Cross-attn: instr → desc", call: ["8 heads, width 128", "p1"], zoom: { k: "heads", q: 8, kv: 8, hd: 16, title: "Cross-attention heads" } },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward" },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "pool", label: "Mean pool → sentence", call: ["128-d", "p1"] },
            { id: "m", t: "mlp", label: "[shape ‖ sentence] MLP", call: ["3 FC + BN, ReLU, dropout → sigmoid", "p1"],
              zoom: { k: "rows", title: "Sample then evaluate", rows: ["segment object (SAM)", "Contact-GraspNet: candidates", "LLM describes class and task", "score every candidate", "execute the best"] } } ],
          output: { label: "score S per grasp" } }
      ],
      links: [
        { from: "pn", to: "tge", toRow: "m", label: "300-d shape" },
        { from: "bert", to: "tge", toRow: "input", label: "text tokens" }
      ]
    },
    modules: [
      { id: "pn", role: "vision-enc", roleLabel: "Point encoder", name: "PointNet++", sub: "object ∪ gripper → 300", col: 2, frozen: false, short: "PointNet++" },
      { id: "bert", role: "lang", name: "BERT-Base", sub: "frozen · 768-d", col: 0, frozen: true, short: "BERT" },
      { id: "tge", role: "critic", roleLabel: "Grasp evaluator", name: "TGE decoder", sub: "2 layers · 8 heads · 128", col: 1, frozen: false, main: true, short: "TGE",
        stack: { rows: [
          { t: "in", label: "instruction, object and task description tokens", dims: "768 → 128", c: "data-2" },
          { t: "block", label: "decoder layer (object, then task)", n: "2", rows: [
            { t: "attn", label: "cross-attention instruction → description" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" },
            { t: "ffn", label: "FFN" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" } ] },
          { t: "pool", label: "mean pool", dims: "128" },
          { t: "mlp", label: "[300 shape ‖ 128 sentence] → 3 FC → sigmoid" },
          { t: "out", label: "task-compatibility score S", c: "data-8" } ],
          facts: [["Width", ["128", "p1"]], ["Heads", ["8", "p1"]], ["Decoder layers", ["2", "p1"]], ["Loss", ["binary cross-entropy", "p1"]], ["Training", ["Adam lr 10⁻⁴, batch 32, 50 epochs", "p2", "p3"]], ["LLM", ["GPT-3 text-davinci-003", "p2", "p3"]]] } }
    ],
    inputs: [
      { to: "pn", mod: "vision", label: "object points + gripper", n: "4,096 + 6", k: 4 },
      { to: "bert", mod: "lang", label: "instruction + LLM descriptions", n: "paragraphs", k: 3 }
    ],
    outputs: [{ from: "tge", mod: "other", label: "score S", n: "per candidate", k: 1 }],
    links: [
      { from: "bert", to: "tge", kind: "cross-attn", label: "description|tokens" },
      { from: "pn", to: "tge", kind: "feeds", label: "300-d shape|into final MLP" }
    ],
    callouts: [
      "Paper vs code: the released <code>graspgpt_plain.py</code> has no cross-attention decoder. It mean-pools the instruction, task and object embeddings and concatenates them with the 300-d shape embedding (300 + 3 × 128) before the MLP.",
      "Grasp candidates come from an off-the-shelf <b>Contact-GraspNet</b>; GraspGPT only re-ranks them for the task."
    ]
  });

  /* ---------------- ThinkGrasp ---------------- */
  RB.arch.spec({
    id: "thinkgrasp", method: "thinkgrasp", name: "ThinkGrasp", year: 2024,
    figRef: "Qian et al. Fig. 1 · §3.2–3.6 · App. A.6", prov: "",
    lede: "A training-free loop. GPT-4o picks the goal object, or an occluder to clear first, plus one cell of a 3 × 3 grid; LangSAM or VLPart segments it; an off-the-shelf 6-DoF grasp net proposes grasps, ranked by closeness to that cell.",
    sources: {
      p1: { kind: "paper", ref: "Qian et al. 2024, §3.2 (pipeline) and Fig. 1", url: "https://arxiv.org/abs/2407.11298" },
      p2: { kind: "paper", ref: "Qian et al. 2024, §3.3–3.7 (selection, grid, segmentation, grasp ranking)", url: "https://arxiv.org/abs/2407.11298" },
      p3: { kind: "paper", ref: "Qian et al. 2024, App. A.4, A.6–A.7 (grid ablation, compute, latency)", url: "https://arxiv.org/abs/2407.11298" },
      c1: { kind: "code", repo: "H-Freax/ThinkGrasp", path: "simulation_main.py", commit: "d724fbc", url: "https://github.com/H-Freax/ThinkGrasp/blob/d724fbc/simulation_main.py" },
      c2: { kind: "code", repo: "H-Freax/ThinkGrasp", path: "realarm.py", commit: "d724fbc", url: "https://github.com/H-Freax/ThinkGrasp/blob/d724fbc/realarm.py" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p1"],
      params: "not disclosed",
      vision: ["RGB-D, 224 × 224 in simulation, 640 × 480 on the robot", "p1"],
      backbone: ["GPT-4o (closed) for target and region selection", "p1", "c1"],
      head: ["Grasp generator: GraspNet-1Billion (simulation) or FGC-GraspNet (real)", "p1"],
      output: ["One 6-DoF parallel-jaw grasp per step; re-observe and repeat", "p1"],
      attention: "not disclosed",
      cond: ["Instruction + image; GPT-4o returns an object or part name and a grid index 1–9", "p1"],
      steps: ["Closed loop until success or the step limit (15 or 50 attempts)", "p2"],
      chunk: null, rate: null,
      latency: ["Grasp pose within 10 s via the GPT-4o API", "p3"],
      train: ["None: pretrained components only", "p1"]
    },
    blueprint: {
      headline: "ThinkGrasp: reason, segment, grasp, repeat",
      note: "Three off-the-shelf models in a loop. GPT-4o never outputs coordinates: it names what to pick next and which of nine cells to aim at. The segmenter turns the name into a point-cloud crop; the grasp net turns the crop into candidates.",
      towers: [
        { mod: "gpt", title: "GPT-4o", sub: "closed VLM, prompted", compact: true,
          input: { label: "Image + instruction", caption: "'give me a fruit'" },
          rows: [
            { t: "attn", label: "GPT-4o (weights closed)", call: ["gpt-4o-2024-05-13 in code", "c1", "c2"] },
            { t: "mlp", label: "Target: goal or occluder", call: ["object or part name", "p1"] },
            { id: "grid", t: "linear", label: "Preferred cell of 3 × 3", call: ["index 1–9, k = 3", "p1", "p3"],
              zoom: { k: "rows", title: "Grid strategy", rows: ["box around the target", "split into k × k cells", "GPT-4o picks one cell", "its centre = target point"] } } ],
          output: { label: "name + grid cell" } },
        { mod: "seg", title: "Segmenter", sub: "LangSAM or VLPart", compact: true,
          input: { label: "Object or part name", caption: "from GPT-4o" },
          rows: [
            { t: "conv", label: "LangSAM (DINO + SAM)", call: ["whole objects, low-res images", "p2"] },
            { t: "conv", label: "VLPart for object parts", call: ["higher-res; LangSAM fallback", "p2"] },
            { t: "pool", label: "Crop the point cloud" } ],
          output: { label: "cropped point cloud" } },
        { mod: "grasp", title: "Grasp generator", sub: "off-the-shelf 6-DoF net",
          input: { label: "Cropped point cloud", caption: "all matching segments" },
          rows: [
            { t: "conv", label: "GraspNet / FGC-GraspNet", call: ["GraspNet-1B in sim, FGC real", "p1"] },
            { id: "rank", t: "mlp", label: "Rank near the target cell", call: ["10 closest poses, best score", "p2"],
              zoom: { k: "rows", title: "Closed loop", rows: ["observe the scene", "GPT-4o: what to pick next", "segment and crop", "grasp, then re-observe", "stop when the goal is grasped"] } } ],
          output: { label: "grasp; re-observe and repeat" } }
      ],
      links: [
        { from: "seg", to: "grasp", toRow: "input", label: "crop" },
        { from: "gpt", to: "seg", toRow: "input", label: "name" }
      ]
    },
    modules: [
      { id: "gpt", role: "planner", name: "GPT-4o", sub: "closed · prompted", col: 0, frozen: true, short: "GPT-4o" },
      { id: "seg", role: "vision-enc", roleLabel: "Segmenter", name: "LangSAM / VLPart", sub: "open-vocabulary masks", col: 1, frozen: true, short: "LangSAM" },
      { id: "grasp", role: "net", roleLabel: "Grasp generator", name: "GraspNet-1B / FGC", sub: "6-DoF parallel-jaw grasps", col: 2, frozen: true, main: true, short: "Grasp net",
        stack: { rows: [
          { t: "in", label: "cropped point cloud", c: "data-1" },
          { t: "conv", label: "grasp generator (GraspNet-1B or FGC-GraspNet)" },
          { t: "mlp", label: "rank by distance to the preferred cell, then score" },
          { t: "out", label: "one 6-DoF grasp", c: "data-3" } ],
          facts: [["Grid", ["3 × 3 (k = 3)", "p1", "p3"]], ["Candidates re-ranked", ["10 closest to the target point", "p2"]], ["Real-robot views (code)", ["300", "c2"]], ["Cost", ["about $0.01 per step", "p3"]]] } }
    ],
    inputs: [
      { to: "gpt", mod: "vision", label: "RGB image", n: "224² or 640 × 480", k: 3 },
      { to: "gpt", mod: "lang", label: "instruction", n: "free text", k: 2 },
      { to: "seg", mod: "vision", label: "RGB-D", n: "same frame", k: 2 }
    ],
    outputs: [{ from: "grasp", mod: "action", label: "6-DoF grasp", n: "1 per step", k: 1 }],
    links: [
      { from: "gpt", to: "seg", kind: "two-stage", label: "object or|part name" },
      { from: "seg", to: "grasp", kind: "two-stage", label: "point-cloud|crop" }
    ],
    callouts: [
      "Nothing is trained: all three models are used as released. Removing the 3 × 3 grid lowers success from 0.980 to 0.973 and adds steps (Table 1).",
      "In simulation the grasp generator is GraspNet-1Billion's baseline; on the real robot it is FGC-GraspNet, kept fixed across baselines for a fair comparison (§3.2)."
    ]
  });

  /* ---------------- RT-Grasp ---------------- */
  RB.arch.spec({
    id: "rt-grasp", method: "rt-grasp", name: "RT-Grasp", year: 2024,
    figRef: "Xu et al. Figs. 2, 5 · §III–V-A", prov: "LoRA fine-tuning variant",
    lede: "LLaVA-7B is tuned to answer 'predict the grasp' with a short category-based reasoning sentence followed by the grasp as plain text: point [x, y] and angle θ. Only the projection and LoRA adapters train.",
    sources: {
      p1: { kind: "paper", ref: "Xu et al. 2024, §IV and Figs. 2, 5 (reasoning tuning, training strategies)", url: "https://arxiv.org/abs/2411.05212" },
      p2: { kind: "paper", ref: "Xu et al. 2024, §V-A (setup: LLaVA-7B-v0, CLIP ViT-L/14, LoRA)", url: "https://arxiv.org/abs/2411.05212" },
      p3: { kind: "paper", ref: "Xu et al. 2024, §III (grasp format)", url: "https://arxiv.org/abs/2411.05212" },
      p4: { kind: "paper", ref: "Touvron et al. 2023 (LLaMA), Table 2 (7B: width 4,096, 32 heads, 32 layers)", url: "https://arxiv.org/abs/2302.13971" },
      c1: { kind: "code", repo: "openai/clip-vit-large-patch14 (Hugging Face)", path: "config.json", commit: "32bd642", url: "https://huggingface.co/openai/clip-vit-large-patch14/blob/32bd642/config.json" }
    },
    summary: {
      pattern: ["Language-conditioned grasp model", "p1"],
      params: ["7B (LLaVA-7B-v0 on LLaMA-7B)", "p2"],
      vision: ["CLIP ViT-L/14 at 224 × 224 (frozen) → 256 patch features", "p2", "c1"],
      backbone: ["LLaMA-7B: 32 layers, width 4,096, 32 heads (frozen, LoRA on all linear layers)", "p2", "p4"],
      head: ["LM head: grasp written as text tokens", "p1"],
      output: ["Text: reasoning, then [x, y] (normalised) and θ in radians; width fixed to the gripper maximum", "p3"],
      attention: ["Causal self-attention over image and text tokens", "p1"],
      cond: null,
      steps: ["Autoregressive decoding; refinable in later dialogue turns", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["76k image–text samples from Cornell (885 images, 74 categories); LoRA r 64, α 32, lr 5 × 10⁻⁴", "p2"]
    },
    blueprint: {
      headline: "RT-Grasp: reason in words, then write the grasp",
      note: "A standard LLaVA: CLIP patch features pass through a trainable projection into LLaMA's word space. The answer is supervised as text in two parts, a reasoning sentence and then the numbers, so the numbers are conditioned on the reasoning.",
      towers: [
        { mod: "clip", title: "CLIP ViT-L/14", sub: "vision encoder, frozen", compact: true,
          input: { label: "RGB image 224 × 224", caption: "workspace crop" },
          rows: [
            { t: "embed", label: "Patch embed 14 × 14", call: ["256 patches, width 1,024", "c1"] },
            { t: "block", n: "24", rows: [
              { t: "attn", label: "Multi-head attention", call: ["16 heads", "c1"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "CLIP attention heads" } },
              { t: "ffn", label: "Feed forward (MLP)", call: ["hidden 4,096", "c1"] } ] } ],
          output: { label: "patch features" } },
        { mod: "llm", title: "LLaMA-7B + LoRA", sub: "language model, frozen base",
          input: { label: "Image tokens + prompt", caption: "'predict the grasp pose'" },
          rows: [
            { t: "linear", label: "Projection W (trainable)", call: ["CLIP features → word space", "p1"] },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm" },
              { id: "att", t: "attn", label: "Self-attention + LoRA", side: "RoPE", call: ["32 heads, width 4,096", "p4"],
                zoom: { k: "rows", title: "LoRA adapter", rows: ["x", "W₀x: frozen weight", "+ B·A·x, rank r = 64", "scale α / r, α = 32"] } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm" },
              { t: "ffn", label: "Feed forward + LoRA", call: ["LoRA on every linear layer", "p1"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "LM head → text", call: ["reasoning, then [x, y] and θ", "p1", "p3"],
              zoom: { k: "rows", title: "Answer format", rows: ["'The object is a cup…'", "reasoning Aʳ (shape, strategy)", "'Grasp point: [x, y]'", "'Rotation angle: θ'", "width = gripper maximum"] } } ],
          output: { label: "text answer with the grasp" } }
      ],
      links: [{ from: "clip", to: "llm", toRow: "input", label: "patch features" }]
    },
    modules: [
      { id: "clip", role: "vision-enc", name: "CLIP ViT-L/14", sub: "24 × 1024 · 16 heads", col: 0, frozen: true, short: "CLIP" },
      { id: "llm", role: "vlm", name: "LLaMA-7B (LLaVA)", sub: "32 × 4096 · LoRA r 64", col: 1, frozen: "lora", main: true, short: "LLaMA-7B", params: "7B",
        stack: { rows: [
          { t: "in", label: "[image tokens | instruction]", c: "data-2" },
          { t: "linear", label: "projection W (trainable)" },
          { t: "block", label: "LLaMA decoder block + LoRA", n: "32", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "causal self-attention, 32 heads" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU FFN" }, { t: "add", span: 2 } ] },
          { t: "out", label: "text: reasoning + grasp", dims: "[x, y], θ", c: "data-3" } ],
          facts: [["Base", ["LLaVA-7B-v0 (LLaMA-7B)", "p2"]], ["Width / layers / heads", ["4,096 / 32 / 32", "p4"]], ["LoRA", ["r = 64, α = 32, all linear layers", "p1", "p2"]], ["Batch", ["32", "p2"]], ["Pre-training lr", ["2 × 10⁻³ (projection only)", "p2"]]] } }
    ],
    inputs: [
      { to: "clip", mod: "vision", label: "RGB image", n: "224 × 224", k: 4 },
      { to: "llm", mod: "lang", label: "instruction", n: "text", k: 2 }
    ],
    outputs: [{ from: "llm", mod: "action", label: "grasp as text", n: "x, y, θ", k: 2 }],
    links: [{ from: "clip", to: "llm", kind: "prefix", label: "projection W|image tokens" }],
    callouts: [
      "No official code was found; LLaMA and CLIP dimensions come from their own papers and configs, not from an RT-Grasp release.",
      "Reasoning tuning adds 8.7–26.7 points over plain numeric answers (No Reasoning-A), yet real-robot success (83.7 %) stays just below GR-ConvNet (85.2 %)."
    ]
  });

  /* ---------------- VCoT-Grasp ---------------- */
  RB.arch.spec({
    id: "vcot-grasp", method: "vcot-grasp", name: "VCoT-Grasp", year: 2025, parent: "rt-grasp",
    diffRows: ["params", "vision", "backbone", "head", "output", "steps", "train"],
    figRef: "Zhang et al. Fig. 2 · §III-B, §III-D · §IV-A", prov: "LM-head variant (pretrained <loc> tokens)",
    lede: "PaliGemma2-3B grasps in two turns. First it writes the target's bounding box; that region is cropped, resized and fed back with the full image, and the second turn writes the grasp rectangle as location tokens.",
    sources: {
      p1: { kind: "paper", ref: "Zhang et al. 2025, §III-B and Fig. 2 (architecture, action heads)", url: "https://arxiv.org/abs/2510.05827" },
      p2: { kind: "paper", ref: "Zhang et al. 2025, §III-A, §III-D (grasp format, two turns, losses)", url: "https://arxiv.org/abs/2510.05827" },
      p3: { kind: "paper", ref: "Zhang et al. 2025, §IV-A (implementation) and Table IV", url: "https://arxiv.org/abs/2510.05827" },
      c1: { kind: "code", repo: "zhanghr2001/VCoT-Grasp", path: "model/config.json", commit: "8fea4b3", url: "https://github.com/zhanghr2001/VCoT-Grasp/blob/8fea4b3/model/config.json" },
      c2: { kind: "code", repo: "zhanghr2001/VCoT-Grasp", path: "model/action_head.py", commit: "8fea4b3", url: "https://github.com/zhanghr2001/VCoT-Grasp/blob/8fea4b3/model/action_head.py" }
    },
    summary: {
      pattern: ["Language-conditioned grasp model", "p1"],
      params: ["3B (PaliGemma2-3B)", "p3"],
      vision: ["SigLIP So400m/14, frozen, 224 × 224 → 256 tokens; full image + zoomed crop in turn 2", "p1", "p3", "c1"],
      backbone: ["Gemma2 2B: 26 layers, width 2,304, 8 query / 4 KV heads, MLP 9,216", "c1"],
      head: ["LM head over 1,024 location tokens per value (best); MLP and DiT heads compared", "p1", "p3"],
      output: ["Bounding box, then rectangle [x, y, w, h, θ]", "p2"],
      attention: ["Causal over [image(s) ‖ text ‖ generated tokens]", "p1"],
      cond: null,
      steps: ["Two decoding turns (box, then grasp)", "p2"],
      chunk: null, rate: null, latency: null,
      train: ["VCoT-GraspSet: 186K training samples, 3 epochs, AdamW 2 × 10⁻⁵, batch 32 on 4 A100s", "p3"]
    },
    changes: [
      "Backbone shrinks from LLaVA-7B (CLIP + LLaMA) to <b>PaliGemma2-3B</b> (SigLIP + Gemma2).",
      "Reasoning becomes <b>visual</b>: predict a box, crop and zoom, then look again, instead of writing a sentence.",
      "Grasp values are 1 of 1,024 <b>location tokens</b> each, not decimal text.",
      "Output adds width and height: [x, y, w, h, θ] instead of [x, y, θ] with fixed width.",
      "Everything except the vision encoder is fine-tuned, instead of projection + LoRA only."
    ],
    blueprint: {
      headline: "VCoT-Grasp: box first, then zoom and grasp",
      note: "The same PaliGemma2 runs both turns. Turn 1 sees the image and 'detect X' and writes box tokens. The box region is cropped to a square, resized and encoded by the same SigLIP; turn 2 sees both images and 'grasp X' and writes five grasp tokens.",
      towers: [
        { mod: "siglip", title: "SigLIP So400m/14", sub: "frozen", compact: true,
          input: { label: "Image 224 × 224", caption: "full view; crop in turn 2" },
          rows: [
            { t: "embed", label: "Patch embed 14 × 14", call: ["256 tokens, width 1,152", "c1"] },
            { t: "block", n: "27", rows: [
              { t: "attn", label: "Multi-head attention", call: ["16 heads", "c1"] },
              { t: "ffn", label: "Feed forward (MLP)", call: ["hidden 4,304", "c1"] } ] },
            { t: "linear", label: "Linear projector", call: ["1,152 → 2,304", "c1"] } ],
          output: { label: "256 tokens per image" } },
        { mod: "gemma", title: "Gemma2 2B", sub: "language model (PaliGemma2)",
          input: { label: "Image tokens + prompt", caption: "'detect X', then 'grasp X'" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["vocab 257,216 · width 2,304", "c1"] },
            { t: "block", n: "26", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Grouped-query attention", side: "RoPE", call: ["8 query heads, 4 KV heads, dim 256", "c1"], zoom: { k: "heads", q: 8, kv: 4, hd: 256, title: "Grouped-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["hidden 9,216", "c1"], zoom: { k: "glu", act: "GELU", d: "2,304", ff: "9,216", title: "Feed forward (GeGLU)" } },
              { t: "add", span: 2 } ] },
            { id: "lm", t: "linear", label: "LM head: <loc> tokens", call: ["each value → 1 of 1,024 tokens", "p1"],
              zoom: { k: "rows", title: "Visual chain of thought", rows: ["turn 1: image + 'detect X'", "→ box tokens", "crop and resize the box", "turn 2: image + crop + 'grasp X'", "→ [x, y, w, h, θ]"] } } ],
          output: { label: "box, then grasp tokens" } },
        { mod: "head", title: "MLP head (variant)", sub: "on dummy tokens", compact: true,
          input: { label: "Dummy-token states", caption: "one per grasp value" },
          rows: [{ t: "mlp", label: "MLP-ResNet per value", call: ["2,304 → 512 → 1, L1 loss", "c2", "p2"] }],
          output: { label: "continuous grasp" } }
      ],
      links: [
        { from: "gemma", to: "head", toRow: "input", label: "hidden states" },
        { from: "siglip", to: "gemma", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "27 × 1152 · frozen", col: 0, frozen: true, short: "SigLIP" },
      { id: "gemma", role: "vlm", name: "Gemma2 2B", sub: "26 × 2304 · GQA 8/4", col: 1, frozen: false, main: true, short: "Gemma2",
        stack: { rows: [
          { t: "in", label: "[full image | crop | instruction]", dims: "256 tokens per image", c: "data-2" },
          { t: "embed", label: "token embedding", dims: "257,216 → 2,304" },
          { t: "block", label: "Gemma2 decoder block", n: "26", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "GQA · 8 query, 4 KV heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 2304 → 9216 → 2304" }, { t: "add", span: 2 } ] },
          { t: "out", label: "box tokens, then grasp tokens", dims: "<loc0000>–<loc1023>", c: "data-3" } ],
          facts: [["Width / depth", ["2,304 / 26", "c1"]], ["Heads", ["8 query, 4 KV, dim 256", "c1"]], ["MLP", ["9,216", "c1"]], ["Vocab", ["257,216", "c1"]], ["Location bins", ["1,024 per value", "p1"]], ["Loss", ["CE on grasp + 1.0 × CE on box", "p2"]]] } },
      { id: "head", role: "action-head", roleLabel: "Alt. action head", name: "MLP / DiT head", sub: "variants in Table IV", col: 2, frozen: false, short: "Head" }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "image, then crop", n: "224 × 224", k: 4 },
      { to: "gemma", mod: "lang", label: "'detect X' / 'grasp X'", n: "2 turns", k: 2 }
    ],
    outputs: [{ from: "gemma", mod: "action", label: "box, then grasp", n: "[x, y, w, h, θ]", k: 2 }],
    links: [
      { from: "siglip", to: "gemma", kind: "prefix", label: "linear → 2,304|256 tokens / image" },
      { from: "gemma", to: "head", kind: "feeds", label: "dummy-token|states" }
    ],
    callouts: [
      "Head ablation (Table IV): LM head with pretrained location tokens 83.60 / 58.98 (seen / unseen), MLP 73.37 / 52.25, DiT diffusion 57.50 / 41.29.",
      "Dropping the visual chain of thought costs about 6 points on seen objects with the MLP head (73.37 → 67.60)."
    ]
  });

  /* ---------------- GraspVLA ---------------- */
  RB.arch.spec({
    id: "graspvla", method: "graspvla", name: "GraspVLA", year: 2025,
    figRef: "Deng et al. Fig. 3 · §4 · App. E, K", prov: "",
    lede: "A VLM (InternLM2 1.8B fed by frozen DINOv2 + SigLIP) first writes the target's 2-D boxes, then the grasp pose; a flow-matching action expert reads the VLM's key–value cache and outputs a chunk of end-effector moves.",
    sources: {
      p1: { kind: "paper", ref: "Deng et al. 2025, §4 and Fig. 3 (architecture, PAG, losses)", url: "https://arxiv.org/abs/2505.03233" },
      p2: { kind: "paper", ref: "Deng et al. 2025, App. K, Table 15 (inference time)", url: "https://arxiv.org/abs/2505.03233" },
      p3: { kind: "paper", ref: "Deng et al. 2025, App. E, Table 9 (training, chunk size)", url: "https://arxiv.org/abs/2505.03233" },
      p4: { kind: "paper", ref: "Deng et al. 2025, §3 (SynGrasp-1B)", url: "https://arxiv.org/abs/2505.03233" },
      c1: { kind: "code", repo: "PKU-EPIC/GraspVLA", path: "vla_network/config/__init__.py", commit: "6acd035", url: "https://github.com/PKU-EPIC/GraspVLA/blob/6acd035/vla_network/config/__init__.py" },
      c2: { kind: "code", repo: "PKU-EPIC/GraspVLA", path: "vla_network/model/vla/assembled_vla.py", commit: "6acd035", url: "https://github.com/PKU-EPIC/GraspVLA/blob/6acd035/vla_network/model/vla/assembled_vla.py" },
      c3: { kind: "code", repo: "PKU-EPIC/GraspVLA", path: "vla_network/model/common/projector.py", commit: "6acd035", url: "https://github.com/PKU-EPIC/GraspVLA/blob/6acd035/vla_network/model/common/projector.py" },
      c4: { kind: "code", repo: "PKU-EPIC/GraspVLA", path: "vla_network/model/backbone_2d/dinosiglip_vit.py", commit: "6acd035", url: "https://github.com/PKU-EPIC/GraspVLA/blob/6acd035/vla_network/model/backbone_2d/dinosiglip_vit.py" },
      c5: { kind: "code", repo: "internlm/internlm2-1_8b (Hugging Face)", path: "config.json", commit: "d753f1d", url: "https://huggingface.co/internlm/internlm2-1_8b/blob/d753f1d/config.json" },
      c6: { kind: "code", repo: "timm (Hugging Face): DINOv2-L/14 reg4 and SigLIP So400m/14", path: "config.json", commit: "f3c408e", url: "https://huggingface.co/timm/vit_large_patch14_reg4_dinov2.lvd142m/blob/f3c408e/config.json" }
    },
    summary: {
      pattern: ["Grasp VLA", "p1"],
      params: null,
      vision: ["Frozen DINOv2 ViT-L/14 (1,024-d) + SigLIP So400m/14 (1,152-d), fused per patch; 2 views at 224 × 224", "p1", "c1", "c4", "c6"],
      backbone: ["InternLM2 1.8B: 24 layers, width 2,048, 16 query / 8 KV heads, MLP 8,192 (trained)", "p1", "c5"],
      head: ["Action expert: same depth, width 1,024, MLP 2,048; flow matching on the VLM KV cache", "p1", "c2", "c5"],
      output: ["Boxes (8 tokens) → grasp pose (6 tokens) → chunk of end-effector delta actions", "p1", "p2"],
      attention: ["Expert tokens attend to the cached prefix: images, text, boxes, proprio, grasp", "p1"],
      cond: ["Proprioception from the last 2 steps is tokenised before the grasp pose", "p1", "c1"],
      steps: ["10 Euler steps (code default)", "c2"],
      chunk: ["4 actions per chunk", "p3", "c1"],
      rate: null,
      latency: ["~200 ms on an L40s: vision 9, boxes 72, grasp 50, flow 64 ms", "p2"],
      train: ["SynGrasp-1B (billion frames, 240 categories, 10,680 objects) + GRIT grounding", "p4", "p1"]
    },
    blueprint: {
      headline: "GraspVLA: box, grasp, then act",
      note: "Progressive Action Generation. The VLM decodes box tokens and, for synthetic data, grasp-pose tokens; web data trains only the boxes. The action expert, a narrower copy of the LLM, then denoises the action chunk while attending to all of those cached keys and values.",
      towers: [
        { mod: "vis", title: "DINOv2 + SigLIP", sub: "frozen, fused per patch", compact: true,
          input: { label: "Front + side views", caption: "224 × 224 each" },
          rows: [
            { t: "conv", label: "DINOv2 ViT-L/14", call: ["1,024-d patch features", "c4", "c6"] },
            { t: "conv", label: "SigLIP So400m/14", call: ["1,152-d patch features", "c4"] },
            { t: "linear", label: "Concat → MLP projector", call: ["3 Linear + GELU → 2,048", "c3", "c5"] } ],
          output: { label: "image tokens" } },
        { mod: "llm", title: "InternLM2 1.8B", sub: "VLM backbone, trained",
          input: { label: "Image + instruction", caption: "'pick up the charger'" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["vocab 92,544 · width 2,048", "c5"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Grouped-query attention", side: "RoPE", call: ["16 query heads, 8 KV heads", "c5"], callDy: -26, zoom: { k: "heads", q: 16, kv: 8, hd: 128, title: "Grouped-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["hidden 8,192", "c5"], zoom: { k: "glu", act: "SiLU", d: "2,048", ff: "8,192", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Next token: box, grasp", call: ["8 box + 6 grasp tokens", "p2"],
              zoom: { k: "rows", title: "Progressive Action Generation", rows: ["images + instruction", "→ 2-D boxes (both views)", "+ proprio (last 2 steps)", "→ grasp pose (robot base)", "→ expert: action chunk"] } } ],
          output: { label: "KV cache of the whole prefix" } },
        { mod: "expert", title: "Action expert", sub: "InternLM2 layers, narrower",
          input: { label: "Noisy chunk Aτ + time τ", caption: "4 actions, flow matching" },
          rows: [
            { t: "linear", label: "Action + time embedding", call: ["sinusoid(τ); τ ~ Beta(1.5, 1)", "c1"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Attention to VLM cache", call: ["prefix + box + grasp tokens", "p1"] },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["width 1,024, hidden 2,048", "c2", "c5"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Velocity vθ", call: ["10 Euler steps (code default)", "c2"] } ],
          output: { label: "4 end-effector delta actions" } }
      ],
      links: [{ from: "vis", to: "llm", toRow: "input", label: "image tokens" }],
      shared: [{ a: ["llm", "att"], b: ["expert", "att"], label: "reads the VLM KV cache" }]
    },
    modules: [
      { id: "vis", role: "vision-enc", name: "DINOv2 + SigLIP", sub: "frozen · 1,024 + 1,152", col: 0, frozen: true, short: "DINO+SigLIP" },
      { id: "llm", role: "vlm", name: "InternLM2 1.8B", sub: "24 × 2048 · GQA 16/8", col: 1, frozen: false, main: true, short: "InternLM2",
        stack: { rows: [
          { t: "in", label: "[images | instruction | boxes | proprio | grasp]", c: "data-2" },
          { t: "embed", label: "token embedding", dims: "92,544 → 2,048" },
          { t: "block", label: "InternLM2 block", n: "24", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "GQA · 16 query, 8 KV heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 2048 → 8192 → 2048" }, { t: "add", span: 2 } ] },
          { t: "out", label: "box and grasp tokens; KV cache", c: "data-2" } ],
          facts: [["Width / depth", ["2,048 / 24", "c5"]], ["Heads", ["16 query, 8 KV", "c5"]], ["MLP", ["8,192", "c5"]], ["Vocab", ["92,544", "c5"]], ["Box / grasp tokens", ["8 / 6", "p2"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert", sub: "24 × 1024 · MLP 2048", col: 2, frozen: false, short: "Expert",
        stack: { rows: [
          { t: "in", label: "noisy chunk Aτ + time τ", dims: "4 actions", c: "data-3" },
          { t: "block", label: "expert block (InternLM2 layout)", n: "24", rows: [
            { t: "attn", label: "attention over [VLM cache ‖ actions]" }, { t: "ffn", label: "SwiGLU 1024 → 2048 → 1024" } ] },
          { t: "out", label: "velocity vθ", dims: "10 Euler steps", c: "data-3" } ],
          facts: [["Width", ["2,048 / 2 = 1,024", "c1", "c2", "c5"]], ["MLP", ["8,192 / 4 = 2,048", "c1", "c2", "c5"]], ["Depth", ["24 (copied from the LLM config)", "c2", "c5"]], ["Flow steps", ["10", "c2"]], ["Loss", ["VLM token loss + flow-matching loss, simple sum", "p1"]]] } }
    ],
    inputs: [
      { to: "vis", mod: "vision", label: "front + side cameras", n: "2 views", k: 4 },
      { to: "llm", mod: "lang", label: "instruction", n: "text", k: 2 },
      { to: "llm", mod: "state", label: "proprio, last 2 steps", n: "tokenised", k: 2 },
      { to: "expert", mod: "action", label: "noisy chunk Aτ", n: "4 actions", k: 4, noisy: true }
    ],
    outputs: [{ from: "llm", mod: "other", label: "boxes + grasp pose", n: "8 + 6 tokens", k: 3 }, { from: "expert", mod: "action", label: "end-effector deltas", n: "4 × 7", k: 4 }],
    links: [
      { from: "vis", to: "llm", kind: "prefix", label: "MLP → 2,048|image tokens" },
      { from: "llm", to: "expert", kind: "joint-attn", label: "KV cache", note: "the expert attends to the VLM's cached keys and values" }
    ],
    callouts: [
      "Paper vs code: Table 9 lists batch size <b>384</b> for GraspVLA; the released training default is a global batch of <b>512</b> (both at lr 1.6 × 10⁻⁴).",
      "The two extra reasoning stages cost about 63 % of inference time (14 extra tokens), yet removing them lowers grasp success (App. K)."
    ]
  });

  /* ---------------- Dex1B (DexSimple) ---------------- */
  RB.arch.spec({
    id: "dex1b", method: "dex1b", name: "DexSimple (Dex1B)", year: 2025,
    figRef: "Ye et al. Figs. 2–3 · §III–IV · App. Table VI", prov: "generator behind the Dex1B dataset",
    lede: "The generator behind Dex1B is a plain CVAE: a PointNet encodes the object, MLPs encode and decode the hand pose, and an SDF loss on hand spheres keeps samples out of the object. A local point feature can steer where the hand goes.",
    sources: {
      p1: { kind: "paper", ref: "Ye et al. 2025, §IV (DexSimple model, objectives, conditions)", url: "https://arxiv.org/abs/2506.17198" },
      p2: { kind: "paper", ref: "Ye et al. 2025, App. IV, Table VI (architecture and hyperparameters)", url: "https://arxiv.org/abs/2506.17198" },
      p3: { kind: "paper", ref: "Ye et al. 2025, §III and §V-B (data engine, curation, implementation)", url: "https://arxiv.org/abs/2506.17198" },
      p4: { kind: "paper", ref: "Ye et al. 2025, §V-A, Tables II and IV (grasp synthesis, ablation)", url: "https://arxiv.org/abs/2506.17198" }
    },
    summary: {
      pattern: ["Conditional VAE grasp generator (dexterous hand)", "p1"],
      params: null,
      vision: ["Object point cloud, 1,024 points (full mesh samples for data, one depth view for deployment)", "p1", "p2"],
      backbone: ["PointNet (3 → 64 → 128 → 1,024 → 256) for f(obj) and per-point features fₚ", "p1", "p2"],
      head: ["CVAE with MLP encoder and decoder (256, 512, 256), latent 256", "p2", "p3"],
      output: ["Hand pose trajectory: N(frames) × N(DoF) (root pose + joints)", "p2"],
      attention: "None (PointNet and MLPs)",
      cond: ["f(obj), optional root rotation, translation, joints, and a local point feature fₚ for debiasing", "p1"],
      steps: ["One decoder pass per sample, then 100 post-optimisation steps and a simulator filter", "p3"],
      chunk: null, rate: null, latency: null,
      train: ["Iterative: 5M optimised seeds → 50M → 500M → ~950M successful demos", "p3"]
    },
    blueprint: {
      headline: "DexSimple: a CVAE with a geometry loss",
      note: "The object feature is concatenated to both the encoder input and the decoder input, as in any CVAE. The novelty is in the losses (SDF and contact distance) and in the extra condition fₚ, which the data engine uses to ask for grasps near rarely used object points.",
      towers: [
        { mod: "pointnet", title: "PointNet", sub: "object encoder", compact: true,
          input: { label: "Object points 1,024 × 3", caption: "mesh samples or one depth view" },
          rows: [
            { t: "conv", label: "Shared MLP per point", call: ["3 → 64 → 128 → 1,024", "p2"] },
            { t: "pool", label: "Max-pool (global)", call: ["plus per-point features fₚ", "p1"] },
            { t: "linear", label: "FC → f(obj)", call: ["256-d", "p2", "p3"] } ],
          output: { label: "f(obj) and fₚ" } },
        { mod: "cvae", title: "CVAE", sub: "MLP encoder and decoder",
          input: { label: "Hand pose g (train only)", caption: "root pose + joint angles" },
          rows: [
            { t: "mlp", label: "Encoder [g ‖ f(obj) ‖ c]", call: ["MLP 256, 512, 256", "p2"] },
            { id: "z", t: "linear", label: "μ, σ → z", call: ["latent 256", "p3"],
              zoom: { k: "rows", title: "Training losses", rows: ["reconstruction ‖g − ĝ‖²", "KL to N(0, I)", "SDF: hand spheres vs points", "contact distance, smoothness"] } },
            { id: "dec", t: "mlp", label: "Decoder [z ‖ f(obj) ‖ c]", call: ["MLP 256, 512, 256", "p2"] },
            { t: "linear", label: "Hand pose ĝ", call: ["N(frames) × N(DoF)", "p2"],
              zoom: { k: "rows", title: "Dex1B data engine", rows: ["optimise a seed set", "train DexSimple on it", "sample, post-optimise, simulate", "debias toward rare points", "retrain on the bigger set"] } } ],
          output: { label: "hand pose ĝ → forward kinematics" } }
      ],
      links: [{ from: "pointnet", to: "cvae", toRow: "dec", label: "f(obj) (and fₚ)" }]
    },
    modules: [
      { id: "pointnet", role: "vision-enc", roleLabel: "Point encoder", name: "PointNet", sub: "1,024 pts → 256-d", col: 0, frozen: false, short: "PointNet" },
      { id: "cvae", role: "net", roleLabel: "Grasp generator", name: "DexSimple CVAE", sub: "MLP 256-512-256 · z 256", col: 1, frozen: false, main: true, short: "CVAE",
        stack: { rows: [
          { t: "in", label: "hand pose g ‖ f(obj) ‖ conditions", c: "data-3" },
          { t: "mlp", label: "encoder MLP", dims: "256, 512, 256" },
          { t: "linear", label: "μ, σ → z", dims: "256" },
          { t: "mlp", label: "decoder MLP on [z ‖ f(obj) ‖ c]", dims: "256, 512, 256" },
          { t: "out", label: "hand pose ĝ", dims: "N(frames) × N(DoF)", c: "data-3" } ],
          facts: [["Latent", ["256", "p3"]], ["Loss weights", ["MSE 1.0, KL 10⁻⁴, SDF 10⁻⁴, distance 10⁻⁴, smooth 10⁻⁵", "p2"]], ["Optimizer", ["Adam, lr 10⁻⁵", "p2"]], ["Without SDF loss", ["success 63.7 → 0.7 %", "p4"]], ["DexGraspNet benchmark", ["86.0 % success with post-optimisation", "p4"]]] } }
    ],
    inputs: [
      { to: "pointnet", mod: "vision", label: "object point cloud", n: "1,024 pts", k: 4 },
      { to: "cvae", mod: "latent", label: "z ~ N(0, I)", n: "256-d", k: 2 }
    ],
    outputs: [{ from: "cvae", mod: "action", label: "hand pose trajectory", n: "N(frames) × N(DoF)", k: 4 }],
    links: [{ from: "pointnet", to: "cvae", kind: "feeds", label: "f(obj) ‖ fₚ|concatenated" }],
    callouts: [
      "No official code release was found; everything here is from the paper's text and Table VI.",
      "DexGraspNet, in contrast, has no generator network: its grasps come from gradient-based energy optimisation and simulator filtering."
    ]
  });
})();
