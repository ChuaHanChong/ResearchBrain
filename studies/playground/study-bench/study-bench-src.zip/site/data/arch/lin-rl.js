/* Architecture specs for the RL and sim-to-real lineage nodes (topics A3, A4): PPO, RLPD, SERL, DPPO, ConRFT, SimpleVLA-RL and Tobin et al.'s domain-randomization detector.
   Numbers from the papers and, where released, the official code at the commits recorded in each source. */
(function () {
  var RB = window.RB;
  function gh(repo, commit, path) { return { kind: "code", repo: repo, path: path, commit: commit, url: "https://github.com/" + repo + "/blob/" + commit + "/" + path }; }
  function ax(ref, id) { return { kind: "paper", ref: ref, url: "https://arxiv.org/abs/" + id }; }

  /* ───────────────────────── A3 · PPO ───────────────────────── */
  RB.arch.spec({
    id: "ppo", method: "ppo", name: "PPO", year: 2017,
    figRef: "Schulman et al. §3, §5 · §6.1 · App. A", prov: "MuJoCo 1M-step benchmark networks",
    lede: "PPO is an objective, not a network: two separate 2 × 64 tanh MLPs, a Gaussian policy with a learned state-independent σ and a value function, trained for several epochs per batch on a clipped probability-ratio surrogate.",
    sources: {
      p1: ax("Schulman et al. 2017, §3 and §5 (clipped surrogate, Algorithm 1)", "1707.06347"),
      p2: ax("Schulman et al. 2017, §6.1 (MuJoCo policy network)", "1707.06347"),
      p3: ax("Schulman et al. 2017, §6.4 (Atari: network of Mnih et al. 2016)", "1707.06347"),
      p4: ax("Schulman et al. 2017, App. A, Tables 3–5 (hyperparameters)", "1707.06347"),
      c1: gh("openai/baselines", "ea25b9e", "baselines/ppo1/mlp_policy.py"),
      c2: gh("openai/baselines", "ea25b9e", "baselines/ppo1/run_mujoco.py"),
      c3: gh("openai/baselines", "ea25b9e", "baselines/ppo2/defaults.py"),
      c4: gh("openai/baselines", "ea25b9e", "baselines/common/models.py")
    },
    summary: {
      pattern: ["Actor–critic (on-policy policy gradient)", "p1"],
      params: null,
      vision: ["None on MuJoCo; Atari reuses an A3C-style CNN", "p2", "p3"],
      backbone: ["Policy and value are separate MLPs: 2 hidden layers × 64 units, tanh", "p2", "c1", "c2"],
      head: ["Linear → Gaussian mean; log σ is a learned vector, not a function of s", "p2", "c1"],
      output: ["a ~ 𝒩(μθ(s), σ²) (continuous); categorical logits on Atari", "p2", "p3"],
      attention: "None (MLPs)",
      cond: ["Observation normalized by a running mean and std, clipped to [−5, 5] (code)", "c1"],
      steps: "One forward pass per action (no iterative sampling)",
      chunk: null, rate: null, latency: null,
      train: ["Adam 3 × 10⁻⁴, 10 epochs × minibatch 64 per 2,048 steps, γ 0.99, GAE λ 0.95, clip ε 0.2; 1M steps per task", "p1", "p2", "p4"]
    },
    blueprint: {
      headline: "PPO: two small MLPs, one clipped objective",
      note: "Policy and value never share weights on MuJoCo, so the value loss coefficient is irrelevant. Both read the same normalized state. The value network only enters training, through the GAE advantage that weights the clipped ratio term.",
      towers: [
        { mod: "policy", title: "Gaussian policy πθ", sub: "mean MLP + free log σ",
          input: { label: "State sₜ", caption: "MuJoCo observation" },
          rows: [
            { t: "norm", label: "Running-stat normalize · clip", call: ["clipped to [−5, 5]", "c1"] },
            { t: "block", n: "2", rows: [{ t: "linear", label: "Linear · tanh", call: ["64 units", "p2", "c2"] }] },
            { id: "mu", t: "linear", label: "Linear → mean μθ(s)", call: ["final init scale 0.01", "c1"] },
            { t: "mlp", label: "a ~ 𝒩(μ, diag σ²)", side: "log σ", note: "log σ is a trainable vector initialized to 0 (code).", zoom: { k: "rows", title: "Clipped surrogate (Eq. 7)", rows: ["rₜ = πθ(aₜ|sₜ) / πθold(aₜ|sₜ)", "clip rₜ to [1 − ε, 1 + ε], ε = 0.2", "L = E[min(rₜÂₜ, clip(rₜ)Âₜ)]", "K epochs of minibatch Adam on it"] } } ],
          output: { label: "action aₜ, log πθ(aₜ | sₜ)" } },
        { mod: "value", title: "Value function Vφ", sub: "separate weights", compact: true,
          input: { label: "State sₜ", caption: "same normalized input" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "linear", label: "Linear · tanh", call: ["64 units", "c1", "c2"] }] },
            { t: "linear", label: "Linear → V(s)", zoom: { k: "rows", title: "Truncated GAE (Eq. 11–12)", rows: ["δₜ = rₜ + γV(sₜ₊₁) − V(sₜ)", "Âₜ = δₜ + (γλ)δₜ₊₁ + …", "γ = 0.99, λ = 0.95", "V trained on squared error"] } } ],
          output: { label: "V(s) → advantage Âₜ" } }
      ],
      links: []
    },
    modules: [
      { id: "policy", role: "action-head", roleLabel: "Stochastic actor", name: "Gaussian policy", sub: "2 × 64 tanh · free log σ", col: 0, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "state s", dims: "normalized, clipped ±5", c: "data-5" },
          { t: "linear", label: "Linear 64 · tanh" }, { t: "linear", label: "Linear 64 · tanh" },
          { t: "linear", label: "Linear → mean μ", dims: "action dim" },
          { t: "mlp", label: "a = μ + σ ⊙ ε, σ = exp(log σ)", side: "log σ" },
          { t: "out", label: "action a and log π(a|s)", dims: "ratio rₜ uses log π", c: "data-3" } ],
          facts: [["Hidden", ["2 × 64, tanh", "p2", "c2"]], ["σ", ["state-independent, learned", "p2", "c1"]], ["Sharing", ["none with the value net (MuJoCo)", "p2"]], ["Entropy bonus", ["not used on MuJoCo", "p2"]], ["Clip ε", ["0.2", "p2"]]] } },
      { id: "value", role: "critic", roleLabel: "State value", name: "Value MLP", sub: "2 × 64 tanh → V(s)", col: 1, frozen: false, short: "V",
        stack: { rows: [
          { t: "in", label: "state s", dims: "same input as π", c: "data-5" },
          { t: "linear", label: "Linear 64 · tanh" }, { t: "linear", label: "Linear 64 · tanh" },
          { t: "linear", label: "Linear → scalar V(s)" },
          { t: "out", label: "V(s) → GAE advantage", dims: "", c: "data-8" } ],
          facts: [["Horizon T", ["2,048 steps per batch", "p4"]], ["GAE λ", ["0.95", "p4"]], ["Epochs × minibatch", ["10 × 64", "p4"]], ["Atari c₁, c₂", ["1 and 0.01 (shared trunk there)", "p4"]]] } }
    ],
    inputs: [
      { to: "policy", mod: "state", label: "state s", n: "MuJoCo", k: 3 },
      { to: "value", mod: "state", label: "state s", n: "MuJoCo", k: 3 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "Gaussian action", n: "1 per step", k: 2 }, { from: "value", mod: "other", label: "V(s)", n: "scalar", k: 1 }],
    links: [{ from: "policy", to: "value", kind: "feeds", label: "rollouts|→ GAE targets" }],
    callouts: [
      "<b>Atari network, paper vs code:</b> §6.4 says PPO used the policy network of Mnih et al. 2016 (A3C; ppo1 keeps it as its small CNN: conv 16 and 32 filters, FC 256). The released ppo2 defaults use the Nature-DQN CNN (conv 32 / 64 / 64, FC 512) with a shared policy–value trunk, and 4 epochs where Table 5 lists 3.",
      "Robotics RL papers mostly borrow PPO's objective and wrap it around their own network: DPPO applies it to every denoising step of a diffusion policy."
    ]
  });

  /* ───────────────────────── A3 · RLPD ───────────────────────── */
  RB.arch.spec({
    id: "rlpd", method: "rlpd", name: "RLPD", year: 2023, parent: "sac",
    diffRows: ["backbone", "head", "cond", "steps", "train"],
    figRef: "Ball et al. §4.1–4.5 · Alg. 1 · App. B.2", prov: "State-based config (rlpd_config.py)",
    lede: "SAC with three changes for learning online with prior data: every batch is half offline data, the critics carry LayerNorm, and a 10-member critic ensemble with a random-subset minimum allows 20 gradient steps per environment step.",
    sources: {
      p1: ax("Ball et al. 2023, §4.1–4.3 (symmetric sampling, LayerNorm, ensembles)", "2302.02948"),
      p2: ax("Ball et al. 2023, §4.4–4.5 and Algorithm 1", "2302.02948"),
      p3: ax("Ball et al. 2023, App. B.2, Tables 1–2 (hyperparameters)", "2302.02948"),
      c1: gh("ikostrikov/rlpd", "c90fd4b", "rlpd/agents/sac/sac_learner.py"),
      c2: gh("ikostrikov/rlpd", "c90fd4b", "configs/rlpd_config.py"),
      c3: gh("ikostrikov/rlpd", "c90fd4b", "rlpd/networks/mlp.py"),
      c4: gh("ikostrikov/rlpd", "c90fd4b", "configs/td_config.py"),
      c5: gh("ikostrikov/rlpd", "c90fd4b", "README.md"),
      c6: gh("ikostrikov/rlpd", "c90fd4b", "configs/pixel_config.py"),
      c7: gh("ikostrikov/rlpd", "c90fd4b", "rlpd/distributions/tanh_normal.py")
    },
    summary: {
      pattern: ["Actor–critic (SAC with offline data)", "p2"],
      params: null,
      vision: ["State tasks: none. V-D4RL pixels: 4 convs (32 → 256 ch, stride 2) → 50-d latent, 64 × 64 frames", "p3", "c6"],
      backbone: ["MLPs of width 256; 2 or 3 hidden layers chosen per environment", "p2", "p3", "c4", "c5"],
      head: ["Actor: tanh-Gaussian, log σ ∈ [−20, 2]; critic: ensemble of E = 10 Q-networks", "p3", "c2", "c7"],
      output: ["a = tanh(u), u ~ 𝒩(μ, σ²)", "c1", "c7"],
      attention: "None (MLPs)",
      cond: ["Q reads [s ‖ a]; each critic layer is Dense → LayerNorm → ReLU (actor has no LayerNorm)", "p1", "c1", "c3"],
      steps: ["G = 20 critic updates per environment step (state-based)", "p3", "c5"],
      chunk: null, rate: null, latency: null,
      train: ["Batch 128 online + 128 offline, Adam 3 × 10⁻⁴, γ 0.99, EMA ρ 0.005, α₀ = 1, target entropy −|A|/2", "p1", "p3", "c1"]
    },
    changes: [
      "<b>Symmetric sampling</b>: each batch is 50 % online replay and 50 % offline data; there is no pre-training phase.",
      "<b>LayerNorm in every critic layer</b> bounds Q by the last weight norm, so out-of-distribution actions cannot inflate values.",
      "An <b>ensemble of 10 critics</b>; the target takes the minimum over a random subset of Z = 1 or 2 (REDQ-style).",
      "<b>20 gradient steps per environment step</b> instead of 1.",
      "No separate V network; the temperature α is learned and the entropy backup is an environment-specific switch."
    ],
    blueprint: {
      headline: "RLPD: SAC plus LayerNorm critic ensemble",
      note: "The actor is a plain SAC tanh-Gaussian MLP. Ten independent critics share one architecture: [s ‖ a] through Dense → LayerNorm → ReLU layers to a scalar. Targets use the minimum over a random subset of target critics; the actor maximizes their mean.",
      towers: [
        { mod: "actor", title: "Actor πϕ(a | s)", sub: "tanh-Gaussian, no LayerNorm", compact: true,
          input: { label: "State s", caption: "or 50-d pixel latent" },
          rows: [
            { t: "block", n: "2–3", rows: [{ t: "linear", label: "Dense · ReLU", call: ["256 units", "p3", "c4"] }] },
            { t: "linear", label: "Heads: mean μ, log σ", call: ["log σ clipped to [−20, 2]", "c7"] },
            { t: "mlp", label: "ã = tanh(μ + σ ⊙ ε)" } ],
          output: { label: "ã, log π(ã | s)" } },
        { mod: "critic", title: "Critic ensemble Qθ₁ … Qθ₁₀", sub: "E independent LayerNorm MLPs",
          input: { label: "[s ‖ a]", caption: "state and action concatenated" },
          rows: [
            { id: "qin", t: "linear", label: "Concat state and action", side: "cond" },
            { t: "group", label: "One ensemble member (× 10)", rows: [
              { t: "block", n: "2–3", rows: [
                { t: "linear", label: "Dense", call: ["256 units", "p3", "c4"] },
                { t: "norm", label: "LayerNorm", zoom: { k: "rows", title: "Why LayerNorm bounds Q (§4.2)", rows: ["ψ(s, a) = LayerNorm(hidden)", "‖relu(ψ)‖ ≤ ‖ψ‖ ≤ 1 (no bias)", "|Q(s, a)| ≤ ‖w‖ for any a", "no runaway values off the data"] } },
                { t: "linear", label: "ReLU" } ] },
              { t: "linear", label: "Dense → scalar Q", call: ["E = 10 critics", "p3", "c2"] } ] },
            { t: "mlp", label: "min over random subset Z", call: ["Z = 2 (code default); 1 on AntMaze, pixels", "p2", "c2", "c5"], zoom: { k: "rows", title: "RLPD update (Alg. 1)", rows: ["batch: 128 from R, 128 from D", "y = r + γ min over Z of Q̄ᵢ(s′, ã′)", "G = 20 critic steps per env step", "actor: max mean Q − α log π"] } } ],
          output: { label: "Q-values; min for targets" } }
      ],
      links: [{ from: "actor", to: "critic", toRow: "qin", label: "ã ~ πϕ" }]
    },
    modules: [
      { id: "actor", role: "action-head", roleLabel: "Actor", name: "tanh-Gaussian MLP", sub: "256 × 2–3 · ReLU", col: 0, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "state s (or pixel latent)", dims: "", c: "data-5" },
          { t: "linear", label: "Dense 256 · ReLU" }, { t: "linear", label: "Dense 256 · ReLU", dims: "3rd layer on AntMaze, Adroit" },
          { t: "linear", label: "mean and log σ heads", dims: "log σ ∈ [−20, 2]" },
          { t: "out", label: "tanh-Gaussian action", dims: "", c: "data-3" } ],
          facts: [["Width", ["256", "p3", "c4"]], ["Depth", ["2 or 3 layers per environment", "p3"]], ["Temperature", ["learned, α₀ = 1, target −|A|/2", "p3", "c1"]], ["Learning rate", ["3 × 10⁻⁴", "p3", "c4"]]] } },
      { id: "critic", role: "critic", name: "LayerNorm critic ensemble", sub: "10 × MLP 256 · LN on [s‖a]", col: 1, frozen: false, short: "Q × 10",
        stack: { rows: [
          { t: "in", label: "[s ‖ a]", dims: "", c: "data-3" },
          { t: "block", label: "Hidden layer", n: "2–3", rows: [{ t: "linear", label: "Dense 256" }, { t: "norm", label: "LayerNorm" }, { t: "linear", label: "ReLU" }] },
          { t: "linear", label: "Dense → scalar Q" },
          { t: "out", label: "Q₁ … Q₁₀; target = min over subset Z", dims: "", c: "data-8" } ],
          facts: [["Ensemble", ["E = 10", "p3", "c2"]], ["Subset", ["Z = 2 default, 1 per environment", "p2", "c2", "c5"]], ["UTD", ["20 (state)", "p3", "c5"]], ["Target EMA", ["0.005", "p3", "c4"]], ["Batch", ["128 online + 128 offline", "p3"]]] } }
    ],
    inputs: [
      { to: "actor", mod: "state", label: "state s", n: "or 50-d pixel code", k: 3 },
      { to: "critic", mod: "action", label: "action a", n: "from R or D", k: 2 }
    ],
    outputs: [{ from: "actor", mod: "action", label: "tanh-Gaussian action", n: "1 per step", k: 2 }],
    links: [{ from: "actor", to: "critic", kind: "feeds", label: "ã ~ πϕ|scored by 10 Qs" }],
    callouts: [
      "The paper's recommended workflow is to ablate, in order: critic subset Z (2 → 1), entropy backups (off) and a deeper 3-layer MLP (Table 2 lists the resulting per-domain choices).",
      "SERL and HIL-SERL put this agent behind a frozen ResNet-10 image encoder."
    ]
  });

  /* ───────────────────────── A3 · SERL ───────────────────────── */
  RB.arch.spec({
    id: "serl", method: "serl", name: "SERL", year: 2024, parent: "rlpd",
    diffRows: ["vision", "backbone", "head", "cond", "rate", "train"],
    figRef: "Luo et al. §4.1–4.6 · §5 · Fig. 2, 4", prov: "Franka peg / PCB insertion, pixel agent",
    lede: "RLPD on a real Franka: a frozen ImageNet ResNet-10 turns each 128 × 128 wrist image into a 256-d vector, a 64-d proprio embedding joins it, and tanh + LayerNorm MLPs form the actor and a 10-critic ensemble running at 10 Hz.",
    sources: {
      p1: ax("Luo et al. 2024, §4.1 (RLPD core)", "2401.16013"),
      p2: ax("Luo et al. 2024, §4.2–4.4 (rewards, resets, actor/learner)", "2401.16013"),
      p3: ax("Luo et al. 2024, §4.5–4.6 (impedance control, relative frames)", "2401.16013"),
      p4: ax("Luo et al. 2024, §5 (encoder, observations, action)", "2401.16013"),
      p5: ax("Luo et al. 2024, §1 and Table 1 (training time, success)", "2401.16013"),
      c1: gh("rail-berkeley/serl", "1fa2af7", "serl_launcher/serl_launcher/utils/launcher.py"),
      c2: gh("rail-berkeley/serl", "1fa2af7", "serl_launcher/serl_launcher/agents/continuous/drq.py"),
      c3: gh("rail-berkeley/serl", "1fa2af7", "serl_launcher/serl_launcher/common/encoding.py"),
      c4: gh("rail-berkeley/serl", "1fa2af7", "serl_launcher/serl_launcher/vision/resnet_v1.py"),
      c5: gh("rail-berkeley/serl", "1fa2af7", "examples/async_peg_insert_drq/run_learner.sh"),
      c6: gh("rail-berkeley/serl", "1fa2af7", "serl_robot_infra/franka_env/envs/franka_env.py")
    },
    summary: {
      pattern: ["Actor–critic (RLPD on pixels)", "p1"],
      params: null,
      vision: ["ImageNet ResNet-10 per camera, frozen trunk, 128 × 128 images", "p4", "c2", "c6"],
      backbone: ["Per camera: 8 spatial learned embeddings → Dense 256 · LN · tanh; proprio → Dense 64 · LN · tanh", "c2", "c3"],
      head: ["Actor and 10-critic ensemble: MLP 256 × 256, tanh + LayerNorm", "p4", "c1"],
      output: ["6-D end-effector twist relative to the current EE frame (tanh-Gaussian)", "p3", "p4"],
      attention: "None (conv + MLPs)",
      cond: ["Image vectors ‖ proprio embedding (EE pose, twist, force, torque)", "p4", "c3"],
      steps: ["Critic updated 4 × per actor update (peg example)", "c5"],
      chunk: null,
      rate: ["10 Hz policy over a 1 kHz impedance controller with clipped reference", "p3", "c6"],
      latency: null,
      train: ["RLPD, 50/50 demo and online batches of 256, 20 demos; 15–60 min per policy", "p1", "p5", "c5"]
    },
    changes: [
      "Adds <b>pixels</b>: a frozen, ImageNet-pretrained ResNet-10 per wrist camera with learned spatial embeddings.",
      "Hidden layers become <b>tanh + LayerNorm</b> in the actor too, not only in the critic.",
      "The temperature starts at 10⁻², entropy backups are off, and γ defaults to 0.96.",
      "Separate <b>actor and learner processes</b> keep a fixed 10 Hz control rate while the learner trains.",
      "Rewards come from a <b>binary image classifier</b> (or VICE) and resets from a learned backward policy."
    ],
    blueprint: {
      headline: "SERL: frozen ResNet-10 feeding RLPD",
      note: "Each wrist image passes through the same frozen ResNet-10 trunk; learned spatial embeddings and a 256-d bottleneck give one vector per camera. Those vectors plus a 64-d proprio embedding feed an actor MLP and ten critic MLPs, each with its own encoder copy.",
      towers: [
        { mod: "enc", title: "Image encoder", sub: "one per camera, frozen trunk", compact: true,
          input: { label: "RGB 128 × 128", caption: "two wrist cameras" },
          rows: [
            { t: "conv", label: "ResNet-10 trunk (frozen)", call: ["ImageNet init; 1 block per stage", "p4", "c4"], zoom: { k: "rows", title: "ResNet-10 (pre-pooling)", rows: ["Conv 7×7 /2 · GroupNorm · ReLU", "max-pool 3×3 /2", "4 stages × 1 residual block", "stop-gradient on the trunk"] } },
            { t: "pool", label: "Spatial learned embeddings", call: ["8 spatial blocks", "c2"] },
            { t: "linear", label: "Dense · LayerNorm · tanh", call: ["bottleneck 256", "c2"] } ],
          output: { label: "256-d per camera" } },
        { mod: "actor", title: "Actor π(a | s)", sub: "tanh-Gaussian twist policy",
          input: { label: "[image vectors ‖ proprio]", caption: "EE pose, twist, force, torque" },
          rows: [
            { t: "linear", label: "Proprio Dense · LN · tanh", call: ["64-d embedding", "c3"] },
            { t: "block", n: "2", rows: [{ t: "linear", label: "Dense · LayerNorm · tanh", call: ["256 units", "c1"] }] },
            { t: "linear", label: "Mean and σ heads · tanh", call: ["σ = exp(·) in [10⁻⁵, 5]", "c1"] } ],
          output: { label: "6-D twist, 10 Hz" } },
        { mod: "critic", title: "Critic ensemble", sub: "RLPD, own encoder copy",
          input: { label: "[features ‖ a]", caption: "twist action appended" },
          rows: [
            { t: "group", label: "Ensemble of 10 critics", rows: [
              { id: "q", t: "linear", label: "2 × Dense 256 · LN · tanh", call: ["10 members, min over 2", "c1"], zoom: { k: "rows", title: "Control stack (§4.5)", rows: ["policy: 10 Hz twist target", "impedance controller at 1 kHz", "reference error clipped to |e| ≤ Δ", "free-space motion stays fast"] } },
              { t: "linear", label: "Dense → Q" } ] } ],
          output: { label: "Q(s, a)" } }
      ],
      links: [
        { from: "actor", to: "critic", toRow: "q", label: "a ~ π" },
        { from: "enc", to: "actor", toRow: "input", label: "camera vectors" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "ResNet-10 per camera", sub: "frozen · 8 spatial emb → 256", col: 0, frozen: "partial", short: "ResNet-10",
        note: "The trunk is frozen; spatial embeddings and the bottleneck are trained.",
        stack: { rows: [
          { t: "in", label: "RGB image per camera", dims: "128 × 128", c: "data-1" },
          { t: "conv", label: "Conv 7×7 /2 · GroupNorm · ReLU · max-pool" },
          { t: "block", label: "Residual stage", n: "4", rows: [{ t: "conv", label: "basic block · GroupNorm", dims: "64 → 512 ch" }] },
          { t: "pool", label: "SpatialLearnedEmbeddings", dims: "8 blocks" },
          { t: "linear", label: "Dense 256 · LayerNorm · tanh" },
          { t: "out", label: "camera vector", dims: "256", c: "data-1" } ],
          facts: [["Trunk", ["ResNet-10, stages (1, 1, 1, 1), ImageNet", "p4", "c4"]], ["Frozen", ["yes (resnetv1-10-frozen)", "c2", "c4"]], ["Bottleneck", ["256", "c2"]], ["Image size", ["128 × 128", "c6"]]] } },
      { id: "actor", role: "action-head", roleLabel: "Actor", name: "Twist policy π", sub: "MLP 256 × 256 · tanh · LN", col: 1, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "camera vectors ‖ proprio embedding", dims: "256 per camera + 64", c: "data-5" },
          { t: "linear", label: "Dense 256 · LayerNorm · tanh" }, { t: "linear", label: "Dense 256 · LayerNorm · tanh" },
          { t: "linear", label: "mean, std heads (exp, [10⁻⁵, 5])" },
          { t: "out", label: "tanh-Gaussian 6-D twist", dims: "relative EE frame", c: "data-3" } ],
          facts: [["MLP", ["256 × 256", "c1"]], ["Temperature init", ["10⁻²", "c1"]], ["Discount", ["0.96 (default)", "c1"]], ["Control", ["10 Hz", "p3", "c6"]]] } },
      { id: "critic", role: "critic", name: "Critic ensemble", sub: "10 × MLP 256² · tanh · LN", col: 2, frozen: false, short: "Q × 10",
        stack: { rows: [
          { t: "in", label: "features ‖ action", dims: "", c: "data-3" },
          { t: "block", label: "Ensemble member", n: "10", rows: [{ t: "linear", label: "Dense 256 × 2 · LN · tanh → Q" }] },
          { t: "out", label: "Q(s, a); target = min over 2 sampled", dims: "", c: "data-8" } ],
          facts: [["Ensemble", ["10 critics, subsample 2", "c1"]], ["Critic:actor updates", ["4 : 1", "c5"]], ["Batch", ["256, half demos", "c5"]], ["Demos", ["20", "c5"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "wrist cameras", n: "128 × 128 each", k: 4 },
      { to: "actor", mod: "state", label: "EE pose, twist, F/T", n: "→ 64-d", k: 2 }
    ],
    outputs: [{ from: "actor", mod: "action", label: "EE twist", n: "6-D", k: 3 }],
    links: [
      { from: "enc", to: "actor", kind: "feeds", label: "256-d per camera" },
      { from: "actor", to: "critic", kind: "feeds", label: "a ~ π" }
    ],
    callouts: [
      "The reward classifier and the forward/backward reset policies are extra networks built from the same encoder recipe (§4.2–4.3).",
      "HIL-SERL keeps this stack but shrinks the ensemble to 2 critics and adds a DQN grasp critic and human corrections."
    ]
  });

  /* ───────────────────────── A3 · DPPO ───────────────────────── */
  RB.arch.spec({
    id: "dppo", method: "dppo", name: "DPPO", year: 2024, parent: "diffusion-policy",
    diffRows: ["vision", "backbone", "head", "steps", "chunk", "train"],
    figRef: "Ren et al. Fig. 3 · §4 · App. E.1, Tables A7–A10", prov: "Robomimic Square, pixel config (ViT + MLP)",
    lede: "A small diffusion policy fine-tuned with PPO: every denoising step is a Gaussian action in an inner MDP. Pixels go through a one-layer ViT and a spatial embedding; a residual MLP predicts noise for a 4-step chunk; a separate critic estimates V(s).",
    sources: {
      p1: ax("Ren et al. 2024, §4.1–4.2 (Diffusion Policy MDP, advantage)", "2409.00588"),
      p2: ax("Ren et al. 2024, §4.3 (best practices: K′, DDIM, σ clipping, networks)", "2409.00588"),
      p3: ax("Ren et al. 2024, App. E.1 (policy architectures)", "2409.00588"),
      p4: ax("Ren et al. 2024, App. E.10, Tables A7 and A10 (hyperparameters, model size)", "2409.00588"),
      c1: gh("irom-lab/dppo", "cc7234a", "cfg/robomimic/finetune/square/ft_ppo_diffusion_mlp_img.yaml"),
      c2: gh("irom-lab/dppo", "cc7234a", "model/diffusion/mlp_diffusion.py"),
      c3: gh("irom-lab/dppo", "cc7234a", "model/common/vit.py"),
      c4: gh("irom-lab/dppo", "cc7234a", "model/common/modules.py"),
      c5: gh("irom-lab/dppo", "cc7234a", "model/common/mlp.py"),
      c6: gh("irom-lab/dppo", "cc7234a", "cfg/robomimic/finetune/square/ft_ppo_diffusion_mlp.yaml")
    },
    summary: {
      pattern: ["Diffusion policy fine-tuned by policy gradient (actor–critic)", "p1"],
      params: ["1.06M (DPPO-ViT-MLP, Square)", "p4"],
      vision: ["One agent-view image 96 × 96 → conv patch stem → 121 tokens of width 128 → 1 transformer layer", "p3", "c1", "c3"],
      backbone: ["Residual MLP, width 768: Linear in, 1 two-layer pre-activation block, Linear out; Mish", "c1", "c5"],
      head: ["εθ(aᵏ, k, s): noise for the whole flattened chunk (4 × 7)", "p1", "c2"],
      output: ["Chunk of Tₐ = 4 actions × 7 dims, executed open loop", "p4", "c1"],
      attention: ["ViT only: 4 heads × 32 dims over 121 patch tokens", "c1", "c3"],
      cond: ["Concat [aᵏ ‖ time embedding (32) ‖ image feature (128) ‖ state (9)] at the MLP input", "p3", "c1", "c2"],
      steps: ["Pre-train K = 100 (DDPM); fine-tune K′ = 5 DDIM steps with η = 1", "p2", "p4"],
      chunk: ["Tₚ = Tₐ = 4 on Square", "p4", "c1"],
      rate: null, latency: null,
      train: ["PPO over the denoising chain: γ env 0.999, GAE λ 0.95, clip 0.01, σₘᵢₙ 0.1 for sampling and likelihood", "p2", "p4"]
    },
    changes: [
      "Training changes from behaviour cloning to <b>PPO</b>: each denoising step is an action with a Gaussian likelihood in a two-layer MDP.",
      "Only the <b>last K′ steps</b> (or K′ = 5 DDIM steps) are fine-tuned; a frozen copy runs the earlier steps.",
      "A <b>critic V(s)</b> is added, reading only the environment state, not the partially denoised action.",
      "The denoiser is a <b>residual MLP</b> on the flattened chunk (a U-Net is optional); pixels use a small ViT, not a ResNet.",
      "The noise std is <b>clipped from below</b> (0.1) so the chain keeps exploring and log-likelihoods stay bounded."
    ],
    blueprint: {
      headline: "DPPO: PPO through every denoising step",
      note: "The ViT runs once per decision; its spatial embedding, concatenated with the robot state, conditions every denoising call of the residual MLP. The critic has its own ViT and only sees the observation. PPO treats each of the K′ denoising steps as a Gaussian action and discounts noisier steps by γ denoise.",
      towers: [
        { mod: "vit", title: "ViT encoder", sub: "1 layer, 121 patch tokens", compact: true,
          input: { label: "RGB 96 × 96", caption: "agent-view camera" },
          rows: [
            { t: "conv", label: "Conv 8×8/4 · ReLU · Conv 3×3/2", call: ["128 ch → 11 × 11 = 121 tokens", "c1", "c3"] },
            { t: "embed", label: "+ learned position embedding" },
            { t: "block", n: "1", rows: [
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "Multi-head self-attention", call: ["4 heads × 32 dims", "c1", "c3"], zoom: { k: "heads", q: 4, kv: 4, hd: 32, title: "ViT attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "MLP · GELU", call: ["128 → 512 → 128", "c3"], zoom: { k: "mlp", act: "GELU", d: "128", ff: "512" } },
              { t: "add", span: 2 } ] },
            { t: "pool", label: "Spatial embedding (+ state)", call: ["→ 128-d feature", "p3", "c1", "c4"] } ],
          output: { label: "128-d image feature" } },
        { mod: "den", title: "Denoiser εθ", sub: "residual MLP, width 768",
          input: { label: "Noisy chunk aᵏ (4 × 7)", caption: "denoising step k" },
          rows: [
            { t: "embed", label: "Step embedding of k", side: "k", call: ["sinusoid → MLP → 32-d", "c1", "c2"] },
            { id: "cat", t: "linear", label: "Concat [aᵏ ‖ t ‖ feat ‖ s]", call: ["28 + 32 + 128 + 9 = 197 in", "c1", "c2"] },
            { t: "linear", label: "Linear → 768", call: ["MLP dims 768 × 3", "c1"] },
            { t: "block", n: "1", rows: [
              { t: "linear", label: "Mish · Linear 768" },
              { t: "linear", label: "Mish · Linear 768" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Linear → 28 = 4 × 7", zoom: { k: "rows", title: "Diffusion Policy MDP (§4.1)", rows: ["state s̄ = (sₜ, aᵏ), action a̅ = aᵏ⁻¹", "each step Gaussian, σₖ ≥ 0.1", "reward only when k = 0", "Â = γ denoiseᵏ (r̄ − V(sₜ))"] } } ],
          output: { label: "noise εθ → next aᵏ⁻¹" } },
        { mod: "critic", title: "Critic V(s)", sub: "own ViT, state only", compact: true,
          input: { label: "Image + state", caption: "no action input" },
          rows: [
            { t: "conv", label: "ViT + spatial embedding", call: ["same ViT config, 128-d", "c1"] },
            { t: "linear", label: "Residual MLP · Mish", call: ["dims 256 × 3", "c1"] },
            { t: "linear", label: "Linear → V(s)" } ],
          output: { label: "V(s) for GAE" } }
      ],
      links: [{ from: "vit", to: "den", toRow: "cat", label: "128-d feature" }]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "Mini ViT", sub: "1 × 128 · 4 heads · 121 tok", col: 0, frozen: false, short: "ViT",
        stack: { rows: [
          { t: "in", label: "RGB 96 × 96", dims: "1 camera, 1 frame", c: "data-1" },
          { t: "conv", label: "Conv 8×8 stride 4 · ReLU", dims: "128 ch" },
          { t: "conv", label: "Conv 3×3 stride 2", dims: "11 × 11 → 121 tokens" },
          { t: "embed", label: "+ learned position embedding" },
          { t: "block", label: "Pre-LN transformer layer", n: "1", rows: [{ t: "attn", label: "MHSA, 4 heads" }, { t: "ffn", label: "MLP 512 · GELU" }] },
          { t: "pool", label: "SpatialEmb: per-channel learned weights over [patch ‖ state]", dims: "→ 128" },
          { t: "out", label: "image feature", dims: "128", c: "data-1" } ],
          facts: [["Patch stem", ["Conv 8/4 then 3/2 (embed2)", "c1", "c3"]], ["Width, heads", ["128, 4", "c1"]], ["Depth", ["1", "c1"]], ["Spatial embedding", ["128", "c1", "c4"]]] } },
      { id: "den", role: "action-head", roleLabel: "Noise-prediction net", name: "Residual MLP εθ", sub: "768 wide · Mish", col: 1, frozen: "partial", main: true, short: "εθ",
        note: "A frozen copy of the pre-trained weights runs the early denoising steps; the copy θ FT used for the last K′ steps is fine-tuned.",
        stack: { rows: [
          { t: "in", label: "noisy chunk aᵏ", dims: "4 × 7 = 28", c: "data-3" },
          { t: "embed", label: "time embedding: sinusoid → Linear 64 → Mish → Linear 32", side: "k" },
          { t: "linear", label: "concat [aᵏ, t-emb, feature, state] → Linear 768", dims: "197 → 768" },
          { t: "block", label: "Pre-activation residual block", n: "1", rows: [{ t: "linear", label: "Mish → Linear 768" }, { t: "linear", label: "Mish → Linear 768" }, { t: "add", label: "residual", span: 2 }] },
          { t: "linear", label: "Linear → 28" },
          { t: "out", label: "predicted noise εθ", dims: "reshaped 4 × 7", c: "data-3" } ],
          facts: [["MLP dims", ["768 × 3, residual style", "c1", "c5"]], ["Time embedding", ["32", "c1", "c2"]], ["Denoising steps", ["K = 100, K′ = 5 DDIM", "p4", "c1"]], ["Model size", ["1.06M", "p4"]], ["Actor lr", ["1 × 10⁻⁵", "p4", "c1"]]] } },
      { id: "critic", role: "critic", roleLabel: "State value", name: "ViT critic", sub: "own ViT · MLP 256 × 3", col: 2, frozen: false, short: "V",
        stack: { rows: [
          { t: "in", label: "image + state", dims: "96 × 96, 9-d", c: "data-1" },
          { t: "conv", label: "ViT encoder (same config)" },
          { t: "pool", label: "SpatialEmb → 128 ‖ state" },
          { t: "linear", label: "Residual MLP 256 · Mish" },
          { t: "linear", label: "Linear → V(s)" },
          { t: "out", label: "V(s)", dims: "for GAE", c: "data-8" } ],
          facts: [["MLP", ["256 × 3, residual, Mish", "c1"]], ["Critic lr", ["1 × 10⁻³", "p4", "c1"]], ["Input", ["state only, not aᵏ", "p1"]]] } }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "agent-view image", n: "96 × 96", k: 3 },
      { to: "den", mod: "action", label: "noisy chunk aᵏ", n: "4 × 7", k: 4, noisy: true },
      { to: "den", mod: "time", label: "step k", n: "→ 32-d", k: 1 }
    ],
    outputs: [{ from: "den", mod: "action", label: "action chunk", n: "4 × 7", k: 4 }],
    links: [
      { from: "vit", to: "den", kind: "feeds", label: "128-d feature|+ 9-d state" },
      { from: "critic", to: "den", kind: "feeds", label: "V(s) → GAE Â|weights PPO loss" }
    ],
    callouts: [
      "<b>Paper vs code:</b> Table A10 lists γ denoise = 0.9 for DPPO-ViT-MLP on Robomimic pixels; the released Square pixel config sets it to 0.99.",
      "The state-based Square config uses a wider residual MLP (1,024 × 3, matching Table A7) with an observation MLP 512 → 64, K = 20 and K′ = 10."
    ]
  });

  /* ───────────────────────── A3 · ConRFT ───────────────────────── */
  RB.arch.spec({
    id: "conrft", method: "conrft", name: "ConRFT", year: 2025, parent: "hil-serl",
    diffRows: ["vision", "backbone", "head", "output", "steps", "train"],
    figRef: "Chen et al. Fig. 1 · §IV-A–B · Alg. 1 · App. B", prov: "Octo-small actor, single-arm Franka",
    lede: "A frozen Octo-small transformer turns two camera views and the instruction into one mean-pooled readout vector; a one-step consistency-policy MLP maps noise to a 6–7-D action. A separate ResNet-10 critic ensemble trains it with Cal-QL, then HIL RL.",
    sources: {
      p1: ax("Chen et al. 2025, §IV-A (Cal-ConRFT, Eq. 1–3)", "2502.05450"),
      p2: ax("Chen et al. 2025, §IV-B (HIL-ConRFT, Eq. 4–5)", "2502.05450"),
      p3: ax("Chen et al. 2025, §V-A (setup: Octo-small, cameras, action space)", "2502.05450"),
      p4: ax("Chen et al. 2025, App. B (consistency head, task tables)", "2502.05450"),
      p5: ax("Chen et al. 2025, Tables I–II (results)", "2502.05450"),
      c1: gh("cccedric/conrft", "a779fde", "serl_launcher/serl_launcher/utils/launcher.py"),
      c2: gh("cccedric/conrft", "a779fde", "serl_launcher/serl_launcher/networks/actor_critic_nets.py"),
      c3: gh("cccedric/conrft", "a779fde", "serl_launcher/serl_launcher/common/encoding.py"),
      c4: gh("cccedric/conrft", "a779fde", "serl_launcher/serl_launcher/agents/continuous/conrft_single_octo_cp.py"),
      c5: gh("octo-models/octo", "241fb35", "octo/model/components/transformer.py")
    },
    summary: {
      pattern: ["VLA + consistency-policy head, actor–critic fine-tuning", "p1"],
      params: null,
      vision: ["Octo tokenizers on a side view 256 × 256 and a wrist view 128 × 128 (actor); frozen ResNet-10 per view (critic)", "p3", "c3", "c4"],
      backbone: ["Octo-small, frozen: 12 layers, width 384, 6 heads, MLP 1,536", "p3", "c5", "c2"],
      head: ["Consistency policy: MLP 256 × 2 on [cᵢₙ·xₖ ‖ t-emb ‖ readout ‖ proprio]", "p4", "c1", "c2"],
      output: ["6-D EE delta pose, or 7-D with a binary gripper, clipped to [−1, 1]", "p3", "c2"],
      attention: "Octo's block-causal transformer (frozen); the head is an MLP",
      cond: ["Mean of Octo readout tokens ‖ 64-d proprio embedding (Dense · LN · tanh)", "c3"],
      steps: ["One network call per action from x = σₘₐₓ·z; training uses M = 40 Karras levels", "p4", "c2"],
      chunk: null,
      rate: ["10 Hz commands to an impedance controller", "p3"],
      latency: null,
      train: ["Offline Cal-QL + consistency BC on 20–30 demos, then online RL with interventions; lr 3 × 10⁻⁴, batch 256", "p1", "p2", "p4"]
    },
    changes: [
      "The actor starts from a <b>pre-trained VLA</b> (Octo-small, frozen) instead of a ResNet-10 trained from scratch.",
      "The Gaussian twist head becomes a <b>consistency-policy head</b> that maps noise to an action in one call.",
      "The actor loss is <b>β·BC + η·Q</b> in both stages, so demonstrations keep anchoring the policy online.",
      "An <b>offline Cal-QL stage</b> initializes the critic and policy before any robot interaction.",
      "The gripper is part of the continuous action (no separate DQN grasp critic)."
    ],
    blueprint: {
      headline: "ConRFT: frozen Octo, one-step consistency head",
      note: "Octo runs once per step and stays frozen; its readout tokens are averaged into one vector and joined by a proprio embedding. The consistency head scales noisy actions by cᵢₙ, adds a sinusoidal noise-level embedding and outputs a denoised action through the skip/out parametrization. The critics use their own frozen ResNet-10 encoders.",
      towers: [
        { mod: "octo", title: "Octo-small", sub: "frozen, readout tokens", compact: true,
          input: { label: "Side + wrist images", caption: "+ instruction tokens" },
          rows: [
            { t: "embed", label: "Image and text tokenizers", call: ["side 256 × 256, wrist 128 × 128", "p3", "c3"] },
            { t: "block", n: "12", rows: [{ t: "attn", label: "Transformer layer", call: ["width 384, 6 heads", "c5"], zoom: { k: "heads", q: 6, kv: 6, hd: 64, title: "Octo-small attention" } }] },
            { t: "pool", label: "Mean over readout tokens", call: ["384-d, stop-gradient", "c3", "c5"] } ],
          output: { label: "readout vector" } },
        { mod: "head", title: "Consistency head fψ", sub: "one call: noise → action",
          input: { label: "x = σ·z", caption: "noise level σ ∈ [0.002, 80]" },
          rows: [
            { id: "enc", t: "linear", label: "Readout ‖ proprio embedding", side: "cond", call: ["proprio → 64-d", "c3"] },
            { t: "embed", label: "σ → sinusoid → MLP", side: "σ", call: ["time dim 16", "c1"] },
            { t: "linear", label: "Concat [cᵢₙ·x ‖ t ‖ obs]" },
            { t: "block", n: "2", rows: [{ t: "linear", label: "Dense · LayerNorm · tanh", call: ["256 units (paper: Mish)", "p4", "c1"] }] },
            { t: "linear", label: "Dense → action dim", zoom: { k: "rows", title: "Consistency parametrization", rows: ["σ from Karras schedule, M = 40, ρ = 7", "F = MLP(cᵢₙ·x, emb(σ), obs)", "a = cₛₖᵢₚ(σ)·x + cₒᵤₜ(σ)·F", "clip a to [−1, 1]"] } } ],
          output: { label: "6/7-D action, 10 Hz" } },
        { mod: "critic", title: "Critic ensemble", sub: "own ResNet-10 encoders", compact: true,
          input: { label: "[image vectors ‖ a]", caption: "frozen ResNet-10 per view" },
          rows: [
            { id: "q", t: "linear", label: "2 × Dense 256 · LN · tanh", call: ["ensemble of 2", "c1"] },
            { t: "linear", label: "Dense → Q", zoom: { k: "rows", title: "Two-stage objective", rows: ["offline: Cal-QL critic (Eq. 1)", "actor: β·BC loss + η·Q loss (Eq. 3)", "online: TD critic, 50/50 D and R", "(β, η): (1, 0.1) → (0.5, 1)"] } } ],
          output: { label: "Q(s, a)" } }
      ],
      links: [
        { from: "head", to: "critic", toRow: "q", label: "a ~ πψ" },
        { from: "octo", to: "head", toRow: "enc", label: "readout (frozen)" }
      ]
    },
    modules: [
      { id: "octo", role: "vlm", roleLabel: "VLA backbone", name: "Octo-small", sub: "12 × 384 · 6 heads", col: 0, frozen: true, short: "Octo",
        stack: { rows: [
          { t: "in", label: "side 256², wrist 128², instruction", dims: "", c: "data-1" },
          { t: "embed", label: "Octo tokenizers (images, language)" },
          { t: "block", label: "Transformer layer", n: "12", rows: [{ t: "attn", label: "self-attention, 6 heads" }, { t: "ffn", label: "MLP 1,536" }] },
          { t: "pool", label: "mean over readout tokens" },
          { t: "out", label: "readout vector", dims: "384, stop-gradient", c: "data-2" } ],
          facts: [["Model", ["Octo-small", "p3"]], ["Size", ["ViT-S size: 12 layers, 384, 6 heads, MLP 1,536", "c5"]], ["Frozen", ["encoders and transformer", "p3", "c4"]]] } },
      { id: "head", role: "action-head", roleLabel: "Consistency head", name: "Consistency MLP", sub: "256 × 2 · one-step", col: 1, frozen: false, main: true, short: "fψ",
        stack: { rows: [
          { t: "in", label: "noisy action x = σₘₐₓ·z", dims: "6 or 7", c: "data-3" },
          { t: "embed", label: "noise level σ → sinusoid → MLP", dims: "16", side: "σ" },
          { t: "linear", label: "concat [cᵢₙ·x, emb(σ), readout, proprio]" },
          { t: "linear", label: "Dense 256 · LayerNorm · tanh" }, { t: "linear", label: "Dense 256 · LayerNorm · tanh" },
          { t: "linear", label: "Dense → action dim" },
          { t: "mlp", label: "a = cₛₖᵢₚ·x + cₒᵤₜ·F, clip ±1" },
          { t: "out", label: "EE delta pose (+ gripper)", dims: "6 or 7", c: "data-3" } ],
          facts: [["Hidden", ["2 × 256", "p4", "c1"]], ["Activation", ["Mish (paper) · tanh + LayerNorm (code)", "p4", "c1"]], ["Noise range", ["σ ∈ [0.002, 80], ρ = 7", "p4", "c1"]], ["Levels", ["M = 40", "p4", "c1"]], ["σ data", ["0.5", "c1"]]] } },
      { id: "critic", role: "critic", name: "Critic ensemble", sub: "ResNet-10 · 2 × MLP 256²", col: 2, frozen: "partial", short: "Q × 2",
        stack: { rows: [
          { t: "in", label: "camera vectors ‖ proprio ‖ action", dims: "", c: "data-3" },
          { t: "conv", label: "frozen ResNet-10 + spatial embeddings → 256 per view" },
          { t: "block", label: "Ensemble member", n: "2", rows: [{ t: "linear", label: "Dense 256 × 2 · LN · tanh → Q" }] },
          { t: "out", label: "Q(s, a)", dims: "", c: "data-8" } ],
          facts: [["Ensemble", ["2", "c1"]], ["Offline loss", ["Cal-QL, α = 0.01 per task table", "p1", "p4"]], ["Discount", ["0.97 (code default)", "c1"]]] } }
    ],
    inputs: [
      { to: "octo", mod: "vision", label: "side + wrist images", n: "256² and 128²", k: 4 },
      { to: "octo", mod: "lang", label: "instruction", n: "e.g. \"Open the drawer.\"", k: 2 },
      { to: "head", mod: "action", label: "noise x", n: "σₘₐₓ = 80", k: 2, noisy: true }
    ],
    outputs: [{ from: "head", mod: "action", label: "EE delta (+ gripper)", n: "6 or 7", k: 3 }],
    links: [
      { from: "octo", to: "head", kind: "feeds", label: "readout mean|(frozen)" },
      { from: "head", to: "critic", kind: "feeds", label: "a ~ πψ|Q loss" }
    ],
    callouts: [
      "<b>Paper vs code:</b> App. B describes the consistency head as a 2-layer MLP with Mish activations; the released launcher builds it with tanh and LayerNorm.",
      "Results: 96.3 % average success on eight real tasks after 45–90 min of online fine-tuning, versus 31.9 % for HIL-SERL from scratch in the same time (Tables I–II)."
    ]
  });

  /* ───────────────────────── A3 · SimpleVLA-RL ───────────────────────── */
  RB.arch.spec({
    id: "simplevla-rl", method: "simplevla-rl", name: "SimpleVLA-RL", year: 2025, parent: "openvla-oft",
    diffRows: ["vision", "head", "output", "cond", "train"],
    figRef: "Li et al. Fig. 2 · §2.3, §3 · §4.1", prov: "LIBERO recipe (run_openvla_oft_rl_libero.sh)",
    lede: "OpenVLA-OFT turned back into a token policy for RL: one image and the instruction fill 56 empty action slots in one pass, the Llama head samples each from 256 bin tokens at temperature 1.6, and GRPO with a 0/1 outcome reward updates all 7B weights.",
    sources: {
      p1: ax("Li et al. 2025, §2.2–2.3 (VLA RL formulation, GRPO)", "2509.09674"),
      p2: ax("Li et al. 2025, §3.1–3.4 (rollout, outcome reward, exploration, objective)", "2509.09674"),
      p3: ax("Li et al. 2025, §4.1 (backbone changes, implementation details)", "2509.09674"),
      p4: ax("Li et al. 2025, §4.2, Tables 2–4 (results)", "2509.09674"),
      p5: ax("Touvron et al. 2023a (LLaMA), §2.2 and Table 2 (RMSNorm, SwiGLU; 7B: 32 layers, width 4,096)", "2302.13971"),
      c1: gh("PRIME-RL/SimpleVLA-RL", "7c51662", "verl/utils/vla_utils/openvla_oft/modeling_prismatic.py"),
      c2: gh("PRIME-RL/SimpleVLA-RL", "7c51662", "verl/utils/vla_utils/openvla_oft/constants.py"),
      c3: gh("PRIME-RL/SimpleVLA-RL", "7c51662", "examples/run_openvla_oft_rl_libero.sh")
    },
    summary: {
      pattern: ["Autoregressive token VLA (parallel-decoded) + outcome-reward RL", "p2"],
      params: ["7B (OpenVLA-OFT base), full-parameter RL", "p3"],
      vision: ["One third-person view only (no wrist camera); 256 patch tokens per image", "p3", "c1", "c3"],
      backbone: ["Llama 2 7B (32 layers, width 4,096), bidirectional over the action slots", "p3", "p5", "c1"],
      head: ["Llama 2 LM head restricted to the 256 action-bin tokens; cross-entropy in SFT", "p3", "c1"],
      output: ["Chunk of 8 × 7 tokens (LIBERO) or 25 × 14 (RoboTwin) → bin centres in [−1, 1]", "p3", "c1", "c2"],
      attention: ["Non-causal over [image | prompt | empty action slots] (OFT parallel decoding)", "p3", "c1"],
      cond: ["Instruction tokens; proprio omitted on LIBERO", "p3", "c3"],
      steps: ["One forward pass per chunk; up to 512 environment steps per LIBERO episode", "p3"],
      chunk: ["8 actions (LIBERO), 25 (RoboTwin)", "p3", "c2"],
      rate: null, latency: null,
      train: ["GRPO: 8 rollouts per task, clip [0.8, 1.28], T = 1.6, no KL, lr 5 × 10⁻⁶, batch 64; 8 × A800", "p2", "p3", "c3"]
    },
    changes: [
      "The <b>L1 MLP action head is removed</b>: the Llama LM head outputs a distribution over 256 bin tokens for every slot, so actions can be sampled and log-probabilities computed.",
      "Inputs shrink to <b>one camera view</b> and the instruction (no wrist view; no proprio on LIBERO).",
      "Training adds <b>online RL</b>: GRPO with a binary task-success reward and group-normalized advantages, no critic.",
      "<b>Exploration tweaks</b>: dynamic sampling of mixed-outcome groups, upper clip 1.28, rollout temperature 1.6.",
      "All 7B parameters are updated (full-parameter training), not LoRA."
    ],
    blueprint: {
      headline: "SimpleVLA-RL: sample action tokens, reward success",
      note: "The vision encoder turns one image into 256 patch tokens placed before the prompt; 56 empty action slots follow. Llama 2 reads everything in one non-causal pass, the LM head's last 256 action-token logits are divided by T and sampled per slot, and the decoded chunk is executed. GRPO compares 8 rollouts of the same task.",
      towers: [
        { mod: "vis", title: "Vision encoder", sub: "OpenVLA-OFT, one view", compact: true,
          input: { label: "RGB, center-cropped", caption: "third-person camera" },
          rows: [
            { t: "conv", label: "DINOv2 ‖ SigLIP patches", call: ["256 patch tokens per image", "c1"] },
            { t: "mlp", label: "Projector → Llama width" } ],
          output: { label: "256 visual tokens" } },
        { mod: "llama", title: "Llama 2 7B", sub: "parallel decoding, full fine-tune",
          input: { label: "[img | prompt | slots]", caption: "slot embeddings zeroed" },
          rows: [
            { id: "seq", t: "embed", label: "Sequence assembly", call: ["7 dims × 8 steps = 56 slots", "p3", "c2", "c3"], zoom: { k: "rows", title: "Parallel decoding input", rows: ["<BOS> + 256 visual tokens", "instruction prompt tokens", "56 action slots, embeddings zeroed", "one pass fills every slot"] } },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm" },
              { t: "attn", label: "Non-causal attention", call: ["width 4,096, 32 heads", "p5"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Llama 2 7B attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm" },
              { t: "ffn", label: "SwiGLU feed-forward" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "LM head → last 256 tokens", call: ["action bins; logits / T, T = 1.6", "p2", "c1"], zoom: { k: "rows", title: "GRPO step (Eq. 11–12)", rows: ["8 rollouts, reward R ∈ {0, 1}", "keep groups with mixed outcomes", "Âᵢ = (Rᵢ − mean R) / std R", "clip ratio to [0.8, 1.28], no KL term"] } } ],
          output: { label: "56 sampled tokens → actions" } }
      ],
      links: [{ from: "vis", to: "llama", toRow: "seq", label: "visual prefix" }]
    },
    modules: [
      { id: "vis", role: "vision-enc", name: "DINOv2 + SigLIP", sub: "1 view · 256 tokens", col: 0, frozen: false, short: "Vision",
        stack: { rows: [
          { t: "in", label: "one third-person image", dims: "center crop", c: "data-1" },
          { t: "conv", label: "fused DINOv2 ‖ SigLIP patch features", dims: "256 tokens" },
          { t: "mlp", label: "MLP projector → Llama embedding" },
          { t: "out", label: "visual tokens", dims: "256", c: "data-1" } ],
          facts: [["Views", ["1 (wrist dropped)", "p3", "c3"]], ["Tokens", ["256 per image", "c1"]]] } },
      { id: "llama", role: "vlm", roleLabel: "Token policy", name: "Llama 2 7B", sub: "32 × 4096 · 256 action bins", col: 1, frozen: false, main: true, params: "7B", short: "Llama 2",
        stack: { rows: [
          { t: "in", label: "[visual | prompt | empty action slots]", dims: "56 slots on LIBERO", c: "data-2" },
          { t: "block", label: "Decoder layer (non-causal here)", n: "32", rows: [{ t: "attn", label: "self-attention" }, { t: "ffn", label: "SwiGLU MLP" }] },
          { t: "linear", label: "LM head, last 256 vocabulary entries" },
          { t: "mlp", label: "softmax(logits / T) → sample per slot" },
          { t: "out", label: "bin index → bin centre", dims: "8 × 7 actions", c: "data-3" } ],
          facts: [["Action tokens", ["256 bins", "p3", "c1"]], ["Temperature", ["1.6 rollout, greedy eval", "p2", "p3", "c3"]], ["Group size", ["8", "p3", "c3"]], ["Clip", ["ε low 0.2, ε high 0.28", "p2", "p3"]], ["Learning rate", ["5 × 10⁻⁶", "p3", "c3"]]] } }
    ],
    inputs: [
      { to: "vis", mod: "vision", label: "third-person image", n: "1 view", k: 4 },
      { to: "llama", mod: "lang", label: "instruction", n: "prompt tokens", k: 3 },
      { to: "llama", mod: "action", label: "empty action slots", n: "56 (8 × 7)", k: 4 }
    ],
    outputs: [{ from: "llama", mod: "action", label: "sampled action chunk", n: "8 × 7", k: 5 }],
    links: [{ from: "vis", to: "llama", kind: "prefix", label: "256 patch tokens|prefix" }],
    mask: { name: "Non-causal (parallel decoding)", ref: "p3", axes: [{ label: "image", short: "img", mod: "vision" }, { label: "prompt", short: "ℓ", mod: "lang" }, { label: "action slots", short: "A", mod: "action" }], m: ["111", "111", "111"],
      note: "All 56 slots are filled in one pass, as in OpenVLA-OFT; the code notes the stop token is needed for non-causal attention." },
    callouts: [
      "The paper's own OpenVLA-OFT differs from the official one: tokens and cross-entropy instead of the L1 MLP head, so official checkpoints cannot be reused and SFT is redone (§4.1).",
      "LIBERO average rises from 91.0 % (SFT) to 99.1 %; with one demo per task, LIBERO-Long goes from 17.3 % to 91.7 % (Tables 2, Fig. 1)."
    ]
  });

  /* ───────────────────────── A4 · Domain randomization (Tobin) ───────────────────────── */
  RB.arch.spec({
    id: "domain-randomization", method: "domain-randomization", name: "Domain randomization (Tobin)", year: 2017,
    figRef: "Tobin et al. Fig. 2 · §III-A–B · §IV", prov: "Paper only; no official code",
    lede: "The network is an ordinary VGG-16 with small fully connected layers of 256 and 64 that regresses an object's (x, y, z) from one webcam image. What makes it transfer is the data: only MuJoCo renders with random non-realistic textures, lights, cameras and distractors.",
    sources: {
      p1: ax("Tobin et al. 2017, §III-A (what is randomized)", "1703.06907"),
      p2: ax("Tobin et al. 2017, §III-B and Fig. 2 (model and training)", "1703.06907"),
      p3: ax("Tobin et al. 2017, §IV (setup, ablations, grasping)", "1703.06907"),
      p4: ax("Simonyan & Zisserman 2014, Table 1 config D (VGG-16 conv layers)", "1409.1556")
    },
    summary: {
      pattern: ["Visual regression network (sim-only training)", "p2"],
      params: null,
      vision: ["One RGB webcam image resized to 224 × 224; uncalibrated camera", "p2"],
      backbone: ["Standard VGG-16 conv layers (13 × 3×3 conv, 5 max-pools), ImageNet or random init", "p2", "p4"],
      head: ["FC 256 → FC 64 → (x, y, z); no dropout, ReLU throughout", "p2"],
      output: ["Cartesian position of the target object (table height fixed), fed to a motion planner", "p2", "p3"],
      attention: "None (convolutions)",
      cond: null, steps: null, chunk: null, rate: null, latency: null,
      train: ["Adam, lr ≈ 10⁻⁴ (2 × 10⁻⁴ searched), L2 loss, batch 25–100; about 5,000–50,000 rendered images", "p2", "p3"]
    },
    blueprint: {
      headline: "Tobin DR: plain VGG-16, randomized pixels",
      note: "Every rendered sample re-draws textures, lights, camera pose and distractors; the network itself is unchanged VGG-16 conv layers with max pooling between groups, then two small fully connected layers and a 3-unit regression output.",
      towers: [
        { mod: "vgg", title: "Modified VGG-16", sub: "object-position regressor",
          input: { label: "RGB 224 × 224", caption: "rendered (train) or webcam (test)" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "conv", label: "Conv 3×3 · ReLU", call: ["64 ch at 224 × 224", "p2", "p4"] }] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Conv 3×3 · ReLU", call: ["max-pool, then 128 ch at 112 × 112", "p2", "p4"] }] },
            { t: "block", n: "3", rows: [{ t: "conv", label: "Conv 3×3 · ReLU", call: ["max-pool, then 256 ch at 56 × 56", "p2", "p4"] }] },
            { t: "block", n: "3", rows: [{ t: "conv", label: "Conv 3×3 · ReLU", call: ["max-pool, then 512 ch at 28 × 28", "p2", "p4"] }] },
            { t: "block", n: "3", rows: [{ t: "conv", label: "Conv 3×3 · ReLU", call: ["max-pool, then 512 ch at 14 × 14", "p2", "p4"], zoom: { k: "rows", title: "Randomized per sample (§III-A)", rows: ["0–10 distractors; object poses", "textures: RGB, gradient, checker", "camera box 10 × 5 × 10 cm, ±0.1 rad", "lights, specular, image noise"] } }] },
            { t: "pool", label: "Max-pool · flatten" },
            { t: "linear", label: "FC · ReLU", call: ["256 units, no dropout", "p2"] },
            { t: "linear", label: "FC · ReLU", call: ["64 units", "p2"] },
            { t: "linear", label: "Linear → (x, y, z)", call: ["L2 loss, Adam lr ≈ 10⁻⁴", "p2"], zoom: { k: "rows", title: "What the ablations found (§IV-C)", rows: ["< 1,000 textures: worse transfer", "no distractors: 1.8 → 7.2 cm error", "random ≈ ImageNet init at 50k", "added noise: negligible effect"] } } ],
          output: { label: "object position, ≈ 1.5 cm error" } }
      ],
      links: []
    },
    modules: [
      { id: "vgg", role: "vision-enc", roleLabel: "Object detector", name: "Modified VGG-16", sub: "13 conv · FC 256 · FC 64", col: 0, frozen: false, main: true, short: "VGG-16",
        stack: { rows: [
          { t: "in", label: "RGB image", dims: "224 × 224", c: "data-1" },
          { t: "group", label: "VGG-16 convolutional layers (max-pool between groups)", rows: [
            { t: "conv", label: "2 × Conv 3×3", dims: "224² × 64" }, { t: "conv", label: "2 × Conv 3×3", dims: "112² × 128" },
            { t: "conv", label: "3 × Conv 3×3", dims: "56² × 256" }, { t: "conv", label: "3 × Conv 3×3", dims: "28² × 512" }, { t: "conv", label: "3 × Conv 3×3", dims: "14² × 512" } ] },
          { t: "linear", label: "FC 256 · ReLU" }, { t: "linear", label: "FC 64 · ReLU" },
          { t: "linear", label: "Linear → 3" },
          { t: "out", label: "(x, y, z) of the object", dims: "to a motion planner", c: "data-5" } ],
          facts: [["FC sizes", ["256 and 64, no dropout", "p2"]], ["Init", ["ImageNet or random (both work with enough data)", "p2", "p3"]], ["Optimizer", ["Adam, lr 1 × 10⁻⁴ or 2 × 10⁻⁴", "p2", "p3"]], ["Batch sizes searched", ["25, 50, 100", "p3"]], ["Real-world error", ["≈ 1.5 cm average", "p3"]], ["Grasping", ["38 of 40 trials in clutter", "p3"]]] } }
    ],
    inputs: [{ to: "vgg", mod: "vision", label: "one RGB frame", n: "224 × 224", k: 4 }],
    outputs: [{ from: "vgg", mod: "state", label: "object (x, y, z)", n: "3", k: 1 }],
    links: [],
    callouts: [
      "Only simulated images are used for training; no real image is seen before deployment on the Fetch robot.",
      "The network is deliberately standard: the paper's claim is about the training distribution, and it lists better architectures as future work."
    ]
  });
})();
