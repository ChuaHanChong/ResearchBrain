/* Architecture specs, topic 06 (generative policy heads). Numbers from the paper and the official code; see sources. */
(function () {
  var RB = window.RB;
  RB.arch.spec({
    id: "diffusion-policy", method: "diffusion-policy", name: "Diffusion Policy (CNN)", year: 2023,
    figRef: "Chi et al. Fig. 2b · §3.1–3.3 · Tab. 7", prov: "Push-T image config",
    lede: "A per-camera ResNet-18 turns the last two frames into one feature vector. A 1-D temporal U-Net denoises a 16-step action chunk, and that vector plus the step embedding modulate every conv block through FiLM.",
    sources: {
      p1: { kind: "paper", ref: "Chi et al. 2023, §3.1 and Fig. 2b", url: "https://arxiv.org/abs/2303.04137" },
      p2: { kind: "paper", ref: "Chi et al. 2023, §3.2 visual encoder", url: "https://arxiv.org/abs/2303.04137" },
      p3: { kind: "paper", ref: "Chi et al. 2023, §3.4 and App. A.4", url: "https://arxiv.org/abs/2303.04137" },
      c1: { kind: "code", repo: "real-stanford/diffusion_policy", path: "diffusion_policy/config/train_diffusion_unet_image_workspace.yaml", commit: "5ba07ac", url: "https://github.com/real-stanford/diffusion_policy/blob/5ba07ac/diffusion_policy/config/train_diffusion_unet_image_workspace.yaml" },
      c2: { kind: "code", repo: "real-stanford/diffusion_policy", path: "diffusion_policy/model/diffusion/conditional_unet1d.py", commit: "5ba07ac", url: "https://github.com/real-stanford/diffusion_policy/blob/5ba07ac/diffusion_policy/model/diffusion/conditional_unet1d.py" },
      c3: { kind: "code", repo: "real-stanford/diffusion_policy", path: "diffusion_policy/model/vision/model_getter.py", commit: "5ba07ac", url: "https://github.com/real-stanford/diffusion_policy/blob/5ba07ac/diffusion_policy/model/vision/model_getter.py" }
    },
    summary: {
      pattern: ["Observation encoder + 1-D temporal U-Net (FiLM)", "p1"],
      params: null,
      vision: ["Per-camera ResNet-18, trained from scratch, GroupNorm", "p2", "c1"],
      backbone: ["None: a conv U-Net, no transformer", "p1"],
      head: ["ε-prediction U-Net, down dims 512 / 1024 / 2048, kernel 5", "c1"],
      output: ["Noise ε on a chunk of Tₚ = 16 actions; Tₐ = 8 executed", "c1"],
      attention: "None (convolutions only)",
      cond: ["FiLM on every residual conv block: [obs features ‖ step embedding]", "p1", "c2"],
      steps: ["100 train / 100 inference (DDPM, sim); 16 DDIM steps on real robots", "p3"],
      chunk: ["Tₒ = 2 observations → Tₚ = 16 predicted → Tₐ = 8 executed", "c1"],
      rate: ["10 Hz commands, interpolated to 125 Hz (real Push-T)", "p3"],
      latency: ["0.1 s with DDIM 10 steps on an RTX 3080", "p3"]
    },
    blueprint: {
      headline: "Diffusion Policy: a 1-D U-Net steered by FiLM",
      note: "The ResNet runs once per chunk. Its features, concatenated with the diffusion-step embedding, set the scale γ and bias β of every conditional residual block; only the U-Net repeats for each of the K denoising steps.",
      towers: [
        { mod: "resnet", title: "ResNet-18", sub: "one per camera, trained from scratch", compact: true,
          input: { label: "Image crop 76 × 76", caption: "last Tₒ = 2 frames" },
          rows: [
            { t: "conv", label: "Conv 7×7 · GN · ReLU", call: ["BatchNorm replaced by GroupNorm", "p2", "c1"] },
            { t: "block", n: "4", rows: [{ t: "conv", label: "Residual stage (2 blocks)" }] },
            { t: "pool", label: "Pooling", call: ["Spatial softmax in the paper; average pool in the image config", "p2", "c3"] } ],
          output: { label: "512-d per frame" } },
        { mod: "unet", title: "Conditional 1-D U-Net", sub: "noise-prediction network εθ",
          input: { label: "Noisy action chunk Aᵏ", caption: "16 steps × action dim, step k" },
          rows: [
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 512 → 1,024 → 2,048", "c1"] } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block, 2,048 ch" }] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "conv", label: "Upsample (transposed conv)" } ] },
            { t: "conv", label: "Final Conv1d → action dim", call: ["Kernel 5, 8 GroupNorm groups", "c1"] } ],
          output: { label: "noise εθ; repeat for K steps" } }
      ],
      links: [{ from: "resnet", to: "unet", toRow: "film", label: "obs features ‖ step embedding (128)" }]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet-18 per camera", sub: "GroupNorm · 512-d / frame", col: 0, frozen: false, short: "ResNet-18",
        note: "Paper: no pretraining, spatial-softmax pooling. The image config keeps torchvision's global average pool.",
        stack: { rows: [
          { t: "in", label: "RGB frame, random crop 76 × 76", dims: "Tₒ = 2 frames, each encoded alone", c: "data-1" },
          { t: "conv", label: "Conv 7×7 /2 → GroupNorm → ReLU → MaxPool", dims: "64 ch" },
          { t: "group", label: "4 residual stages (2 BasicBlocks each)", rows: [
            { t: "conv", label: "Stage 1 · 3×3 convs", dims: "64 ch" }, { t: "conv", label: "Stage 2 · /2", dims: "128 ch" },
            { t: "conv", label: "Stage 3 · /2", dims: "256 ch" }, { t: "conv", label: "Stage 4 · /2", dims: "512 ch" } ] },
          { t: "norm", label: "BatchNorm swapped for GroupNorm", dims: "stable with EMA (§3.2)" },
          { t: "pool", label: "Global average pool (code) · spatial softmax (paper)", dims: "→ 512" },
          { t: "out", label: "feature per frame", dims: "concat over frames and cameras", c: "data-1" } ],
          facts: [["Pretraining", ["none (trained end to end)", "p2", "c1"]], ["Normalization", ["GroupNorm instead of BatchNorm", "p2", "c1"]], ["Pooling", ["spatial softmax (paper) · average pool (image config)", "p2", "c3"]], ["Crop", ["76 × 76 random crop (Push-T image)", "c1"]], ["Cameras", ["separate encoder per view", "p2"]]] } },
      { id: "unet", role: "action-head", roleLabel: "Noise-prediction net", name: "Conditional 1-D U-Net", sub: "512 → 1024 → 2048 ch", col: 1, frozen: false, main: true, short: "1-D U-Net",
        stack: { rows: [
          { t: "in", label: "noisy action chunk Aᵏ", dims: "16 steps × action dim", c: "data-3" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "film", label: "FiLM: x · scale + bias", side: "cond", note: "scale and bias come from a Mish + Linear on [obs ‖ step]" },
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "add", label: "residual (1×1 conv if widths differ)", span: 3 } ] },
            { t: "conv", label: "Downsample1d (stride 2)", dims: "512 → 1024 → 2048 ch" } ], note: "skip features saved" },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block at 2048 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [
            { t: "conv", label: "concat skip · 2 conditional residual blocks" }, { t: "conv", label: "Upsample1d (transposed conv)" } ] },
          { t: "conv", label: "Conv1dBlock → Conv1d 1×1", dims: "→ action dim" },
          { t: "out", label: "predicted noise εθ", dims: "same shape as Aᵏ", c: "data-3" } ],
          facts: [["Down dims", ["512 / 1024 / 2048", "c1"]], ["Kernel", ["5, GroupNorm with 8 groups, Mish", "c1", "c2"]], ["Step embedding", ["sinusoid 128 → MLP 512 → 128", "c1", "c2"]], ["Conditioning", ["FiLM scale and bias on every block", "p1", "c2"]], ["Noise schedule", ["squared-cosine (iDDPM)", "p3", "c1"]], ["Prediction", ["ε (noise)", "c1"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "last 2 frames per camera", n: "Tₒ = 2", k: 4 },
      { to: "unet", mod: "action", label: "noisy chunk Aᵏ", n: "16 × action dim", k: 5, noisy: true },
      { to: "unet", mod: "time", label: "step k", n: "→ 128-d", k: 2 }
    ],
    outputs: [{ from: "unet", mod: "action", label: "noise εθ", n: "16 × action dim", k: 5 }],
    links: [{ from: "resnet", to: "unet", kind: "film", label: "obs features|(+ state)" }],
    callouts: [
      "The observation is encoded <b>once</b> per chunk; only the U-Net runs K times (§2.3).",
      "The paper's transformer variant replaces the U-Net with a causal decoder that cross-attends to observation tokens (Fig. 2c)."
    ]
  });
})();
