/* Architecture specs, topic B5 (LLM/VLM planners and language-conditioned affordance models).
   Numbers from the papers and the official code; see sources. Closed models are drawn at the level the papers disclose. */
(function () {
  var RB = window.RB;
  var GR = "https://github.com/google-research/google-research/blob/d36068b/";
  var VP = "https://github.com/huangwl18/VoxPoser/blob/e3a4c9e/";
  var RK = "https://github.com/huangwl18/ReKep/blob/63c43fd/";
  var MK = "https://github.com/moka-manipulation/moka/blob/f6b6425/";
  var RP = "https://github.com/wentaoyuan/RoboPoint/blob/206cb1e/";
  var CP = "https://github.com/cliport/cliport/blob/2be5c47/";

  /* ---------------- SayCan ---------------- */
  RB.arch.spec({
    id: "saycan", method: "saycan", name: "SayCan", year: 2022,
    figRef: "Ahn et al. Figs. 3, 9, 10 · §3–4 · App. C–D", prov: "PaLM-SayCan, mobile manipulator in the kitchen",
    lede: "PaLM 540B scores how useful each skill's text is as the next step; a language-conditioned value function scores whether that skill can succeed from the current image. The robot runs the skill with the highest product, appends it to the prompt, and repeats until 'done'.",
    sources: {
      p1: { kind: "paper", ref: "Ahn et al. 2022, §3 and Algorithm 1 (scoring)", url: "https://arxiv.org/abs/2204.01691" },
      p2: { kind: "paper", ref: "Ahn et al. 2022, §4 and App. C.1–C.2 (skills, Figs. 9–10, training)", url: "https://arxiv.org/abs/2204.01691" },
      p3: { kind: "paper", ref: "Ahn et al. 2022, §5, Tables 2–3 (results, LLM ablation)", url: "https://arxiv.org/abs/2204.01691" },
      p4: { kind: "paper", ref: "Ahn et al. 2022, App. D.2–D.3 (affordance calibration, prompt)", url: "https://arxiv.org/abs/2204.01691" },
      c1: { kind: "code", repo: "google-research/google-research", path: "saycan/SayCan-Robot-Pick-Place.ipynb", commit: "d36068b", url: GR + "saycan/SayCan-Robot-Pick-Place.ipynb" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p1"],
      params: ["LLM: PaLM 540B (8B, 62B and FLAN 137B ablated); policy sizes not stated", "p3"],
      vision: ["Value functions see the full 640 × 512 image; the BC policy a half-size 256 × 320 image", "p2"],
      backbone: ["PaLM 540B, frozen and prompted; used only to score fixed skill texts", "p1", "p3"],
      head: ["BC-Z-style ResNet-18 policy (FiLM on the skill embedding) and MT-Opt-style Q-network", "p2"],
      output: ["One skill per step = argmax p_LLM × p_affordance; the policy outputs arm pose, gripper, base x-y-yaw and terminate", "p1", "p2"],
      attention: null,
      cond: ["Skill text → frozen Universal Sentence Encoder embedding into policy and Q-network", "p2"],
      steps: ["One LLM + value-function query per skill, looped until the LLM picks 'done'", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["BC: 68,000 teleoperated demos + 12,000 autonomous successes; RL: MT-Opt in simulation with RetinaGAN", "p2"]
    },
    blueprint: {
      headline: "SayCan: what is useful × what can succeed",
      note: "No network is trained end to end. PaLM ranks all skill texts given the instruction and the steps so far; the Q-network of each skill turns the current image into a success probability. The product picks the skill; its BC policy runs; the chosen text is appended and the loop repeats.",
      towers: [
        { mod: "llm", title: "PaLM 540B", sub: "frozen LLM, scoring mode", compact: true,
          input: { label: "Prompt + instruction i", caption: "dialog prompt, 17 examples" },
          rows: [
            { t: "attn", label: "PaLM decoder (frozen)", call: ["540B parameters; not fine-tuned", "p3"] },
            { id: "score", t: "linear", label: "Score every skill text", call: ["p(ℓπ | i, history), every skill", "p1"],
              zoom: { k: "rows", title: "The SayCan loop", rows: ["for every skill π in the library", "p_LLM = p(ℓπ | i, history)", "p_aff = p(cπ | s, ℓπ)", "run argmax of p_LLM × p_aff", "append ℓπ; stop at 'done'"] } } ],
          output: { label: "p_LLM for each skill" } },
        { mod: "vf", title: "Q-network", sub: "MT-Opt-style, trained with RL",
          input: { label: "Image + skill + action", caption: "640 × 512 RGB, full size" },
          rows: [
            { t: "block", n: "7", rows: [{ t: "conv", label: "Conv layer on the image", call: ["7 conv layers", "p2"] }] },
            { t: "mlp", label: "FC on [USE(ℓ) ‖ action ‖ state]", side: "cond", call: ["state: gripper height, action left to run", "p2"] },
            { t: "conv", label: "Tile, add to conv volume" },
            { t: "block", n: "11", rows: [{ t: "conv", label: "Conv layer", call: ["11 more conv layers", "p2"] }] },
            { t: "linear", label: "Sigmoid → Q ∈ [0, 1]", call: ["sparse 0/1 reward, log loss", "p2"] },
            { id: "aff", t: "norm", label: "v = maxₐ Q (CEM), calibrate", call: ["pick: clamp((v − 0.2) / (0.5 − 0.2))", "p4"],
              zoom: { k: "rows", title: "Affordance per skill family", rows: ["pick: clamped Q value (0.2–0.5)", "go to: distance, 0–100 m", "place: always 1.0", "terminate: fixed 0.1"] } } ],
          output: { label: "p_affordance for each skill" } },
        { mod: "bc", title: "BC skill policy", sub: "BC-Z-style, 68k teleop demos", compact: true,
          input: { label: "Image 256 × 320", caption: "chosen skill ℓπ" },
          rows: [
            { t: "embed", label: "USE sentence embedding", call: ["frozen encoder", "p2"] },
            { id: "film", t: "film", label: "ResNet-18 with FiLM", side: "FiLM", call: ["FiLM on the skill embedding", "p2"] },
            { t: "mlp", label: "FC heads per action part", call: ["arm, gripper, terminate heads", "p2"] } ],
          output: { label: "arm, base and gripper commands" } }
      ],
      links: [
        { from: "vf", to: "bc", toRow: "input", label: "argmax skill" },
        { from: "llm", to: "vf", toRow: "aff", label: "× p_LLM" }
      ]
    },
    modules: [
      { id: "llm", role: "planner", roleLabel: "LLM planner (scoring)", name: "PaLM 540B", sub: "frozen · scores skill text", col: 0, frozen: true, params: "540B", short: "PaLM", main: true },
      { id: "vf", role: "critic", roleLabel: "Affordance value fn", name: "MT-Opt-style Q-net", sub: "7 + 11 conv · sigmoid", col: 1, frozen: false, short: "Q-network",
        stack: { rows: [
          { t: "in", label: "RGB 640 × 512 + skill embedding + action", dims: "full-size image", c: "data-1" },
          { t: "conv", label: "7 conv layers on the image" },
          { t: "mlp", label: "FC on [USE(ℓ) ‖ action ‖ state]", dims: "tiled, added to conv volume" },
          { t: "conv", label: "11 conv layers" },
          { t: "linear", label: "sigmoid → Q(s, a, ℓ) ∈ [0, 1]" },
          { t: "pool", label: "v(s) = maxₐ Q via cross-entropy method" },
          { t: "out", label: "calibrated p_affordance", dims: "clamp((v − 0.2) / 0.3, 0, 1) for pick", c: "data-8" } ],
          facts: [["Conv layers", ["7 before and 11 after the conditioning", "p2"]], ["Output", ["sigmoid, so Q ∈ [0, 1]", "p2"]], ["Reward", ["1 on success (2 of 3 raters), else 0", "p2"]], ["Training", ["16 TPUv3, about 100 h; 3,000 + 3,000 CPU workers", "p2"]], ["Pick calibration", ["v_min 0.2, v_max 0.5", "p4"]]] } },
      { id: "bc", role: "action-head", roleLabel: "Skill policy (BC)", name: "BC-Z-style policy", sub: "ResNet-18 · FiLM (USE)", col: 2, frozen: false, short: "BC policy",
        stack: { rows: [
          { t: "in", label: "RGB, downsampled to 256 × 320", dims: "no previous action or gripper height", c: "data-1" },
          { t: "embed", label: "Universal Sentence Encoder on the skill text", dims: "frozen" },
          { t: "conv", label: "ResNet-18 trunk, FiLM-conditioned on the embedding" },
          { t: "mlp", label: "separate FC heads", dims: "arm position · orientation · gripper · terminate" },
          { t: "out", label: "one action per control step", c: "data-3" } ],
          facts: [["Demos", ["68,000 teleop + 12,000 success-filtered autonomous", "p2"]], ["Fleet", ["10 robots over 11 months", "p2"]], ["Loss", ["MSE (continuous) + cross-entropy (discrete), equal weights", "p2"]], ["Training", ["16 TPUv3, about 27 h", "p2"]]] } }
    ],
    inputs: [
      { to: "llm", mod: "lang", label: "instruction + steps so far", n: "text", k: 3 },
      { to: "vf", mod: "vision", label: "camera image", n: "640 × 512", k: 3 },
      { to: "vf", mod: "lang", label: "every skill text", n: "551 skills", k: 3 },
      { to: "bc", mod: "vision", label: "camera image", n: "256 × 320", k: 3 }
    ],
    outputs: [
      { from: "llm", mod: "other", label: "p_LLM per skill", n: "scores", k: 3 },
      { from: "bc", mod: "action", label: "arm, base, gripper", n: "+ terminate", k: 3 }
    ],
    links: [
      { from: "llm", to: "vf", kind: "feeds", label: "p_LLM × p_aff|→ argmax skill", note: "the two probabilities are multiplied per skill" },
      { from: "vf", to: "bc", kind: "two-stage", label: "chosen skill ℓπ", note: "the chosen skill's policy runs until it terminates" }
    ],
    callouts: [
      "The released Colab is a <b>different, tabletop SayCan</b>: GPT-3 (<code>text-davinci-002</code>) scores the options, ViLD detections supply the affordances and a CLIP-conditioned Transporter executes pick-and-place. PaLM and the kitchen policies are not released.",
      "PaLM-SayCan plans 84 % and executes 74 % of 101 instructions in the mock kitchen; without the value function (No VF) planning drops to 67 % (Table 2).",
      "Navigation and place are not learned: go-to uses a classical planner with a distance-based affordance, and place is a scripted motion (App. D.2)."
    ]
  });

  /* ---------------- Inner Monologue ---------------- */
  RB.arch.spec({
    id: "inner-monologue", method: "inner-monologue", name: "Inner Monologue", year: 2022, parent: "saycan",
    diffRows: ["backbone", "cond", "output", "vision", "train"],
    figRef: "Huang et al. Figs. 2–3, 7 · App. A", prov: "Kitchen instantiation for the success detector",
    lede: "SayCan's loop with the lights on. After every skill, textual feedback (success, visible objects, task progress, a human's answer) is appended to the LLM prompt, so the planner can retry, replan or ask. No model is trained except a CLIP-based success detector.",
    sources: {
      p1: { kind: "paper", ref: "Huang et al. 2022, §3 and Fig. 2 (feedback types)", url: "https://arxiv.org/abs/2207.05608" },
      p2: { kind: "paper", ref: "Huang et al. 2022, App. A.1–A.2 and Table 4 (tabletop systems)", url: "https://arxiv.org/abs/2207.05608" },
      p3: { kind: "paper", ref: "Huang et al. 2022, App. A.3 and Fig. 7 (kitchen, success detector)", url: "https://arxiv.org/abs/2207.05608" },
      p4: { kind: "paper", ref: "Huang et al. 2022, §4.1–4.2, Tables 1–2 (results)", url: "https://arxiv.org/abs/2207.05608" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p1"],
      params: ["LLM: 1.3B (InstructGPT) or 540B (PaLM)", "p2", "p3"],
      vision: ["Only through feedback models: MDETR boxes (real tabletop), fine-tuned CLIP success detector (kitchen)", "p2", "p3"],
      backbone: ["InstructGPT 1.3B via API (tabletop) or PaLM 540B (kitchen); few-shot prompted, not fine-tuned", "p1", "p2", "p3"],
      head: ["Pretrained skills: CLIP-based Transporter (sim), MDETR + scripted suction (real), SayCan policies (kitchen)", "p2", "p3"],
      output: ["Next skill as text, a question to the human, or 'done'", "p1", "p3"],
      attention: null,
      cond: ["Prompt = instruction + running log of Success, Object, Scene and Human feedback", "p1"],
      steps: ["At most k = 15 steps per episode in simulation", "p4"],
      chunk: null, rate: null, latency: null,
      train: ["None for the planner; success detector: CLIP fine-tuned with BCE (foresight) and contrastive loss (hindsight)", "p3"]
    },
    changes: [
      "Closes the loop: <b>success, object and scene feedback</b> is appended to the prompt as text after every skill.",
      "The LLM can <b>ask the human</b> a question (active scene description) instead of issuing a skill.",
      "Adds a learned <b>success detector</b>: fine-tuned CLIP foresight model plus a contrastive hindsight model (kitchen).",
      "Planner varies by domain: InstructGPT 1.3B on the tabletops, PaLM 540B in the kitchen; still no training.",
      "In the kitchen SayCan's affordance grounding stays, but affordances never talk back to the LLM."
    ],
    blueprint: {
      headline: "Inner Monologue: feedback as text in the prompt",
      note: "Three models talk only in language. The success detector (and object detectors or a human) write short lines into the prompt; the LLM reads the whole log and writes the next skill; the skill policy executes it. Nothing repeats inside a network: the loop is the prompt growing by one step at a time.",
      towers: [
        { mod: "succ", title: "Success detector", sub: "kitchen: fine-tuned CLIP", compact: true,
          input: { label: "o₀, o_f, skill ℓ", caption: "first and last frame of the skill" },
          rows: [
            { t: "conv", label: "CLIP image encoder (o₀, o_f)" },
            { t: "mlp", label: "Fusion MLP on [o₀ ‖ o_f]", call: ["CLIP encoders fine-tuned too", "p3"] },
            { t: "embed", label: "‖ CLIP text embedding of ℓ" },
            { id: "sd", t: "mlp", label: "MLP → p(success)", call: ["binary cross-entropy; threshold τ", "p3"],
              zoom: { k: "rows", title: "Foresight + hindsight", rows: ["foresight: p(success | o₀, o_f, ℓ)", "if p > τ, run hindsight model", "hindsight: softmax over all skills", "success only if argmax = ℓ"] } } ],
          output: { label: "'Success: True / False'" } },
        { mod: "llm", title: "LLM planner", sub: "InstructGPT 1.3B or PaLM 540B",
          input: { label: "Instruction + feedback log", caption: "few-shot prompt per domain" },
          rows: [
            { id: "log", t: "embed", label: "Prompt grows each step", call: ["Success, Object, Scene, Human lines", "p1"],
              zoom: { k: "rows", title: "A kitchen prompt", rows: ["Human: bring me a drink", "Robot: go to the table", "Scene: coke, lime soda", "Robot: which kind would you like?", "Success: False → retry"] } },
            { t: "attn", label: "LLM decoder (frozen)", call: ["1.3B (tabletop) · 540B (kitchen)", "p2", "p3"] },
            { t: "linear", label: "Next skill · question · done" } ],
          output: { label: "next skill in language" } },
        { mod: "skill", title: "Skill policies", sub: "pretrained, one per domain", compact: true,
          input: { label: "Skill text", caption: "e.g. 'pick up coke'" },
          rows: [
            { t: "conv", label: "Sim: CLIP Transporter", call: ["20,000 demos; 3-D pick + place", "p2"] },
            { t: "conv", label: "Real: MDETR + suction", call: ["scripted, no fine-tuning", "p2"] },
            { t: "mlp", label: "Kitchen: SayCan skills", call: ["68,000 teleop + 12,000 autonomous", "p3"] } ],
          output: { label: "robot executes; frames go to feedback" } }
      ],
      links: [
        { from: "llm", to: "skill", toRow: "input", label: "next skill" },
        { from: "succ", to: "llm", toRow: "log", label: "success text" }
      ]
    },
    modules: [
      { id: "succ", role: "critic", roleLabel: "Success detector", name: "CLIP success det.", sub: "foresight + hindsight", col: 0, frozen: false, short: "Success det.",
        stack: { rows: [
          { t: "in", label: "o₀ (first frame), o_f (last frame), skill ℓ", c: "data-1" },
          { t: "conv", label: "CLIP image encoder on o₀ and o_f", dims: "fine-tuned" },
          { t: "mlp", label: "fusion MLP on [o₀ ‖ o_f]" },
          { t: "embed", label: "concat with CLIP text embedding of ℓ" },
          { t: "mlp", label: "MLP → scalar p(success)" },
          { t: "out", label: "'[success: no]' below threshold τ", c: "data-8" } ],
          facts: [["Foresight loss", ["binary cross-entropy", "p3"]], ["Hindsight loss", ["CLIP symmetric contrastive over skills", "p3"]], ["Used in", ["kitchen only; tabletops use ground truth or MDETR heuristics", "p2"]]] } },
      { id: "llm", role: "planner", roleLabel: "LLM planner", name: "InstructGPT / PaLM", sub: "1.3B tabletop · 540B kitchen", col: 1, frozen: true, short: "LLM", main: true },
      { id: "skill", role: "action-head", roleLabel: "Skill policies", name: "Pretrained skills", sub: "Transporter · MDETR · BC", col: 2, frozen: true, short: "Skills" }
    ],
    inputs: [
      { to: "succ", mod: "vision", label: "first + last frame", n: "o₀, o_f", k: 2 },
      { to: "llm", mod: "lang", label: "instruction + log", n: "text", k: 4 },
      { to: "skill", mod: "vision", label: "RGB-D view", n: "per domain", k: 3 }
    ],
    outputs: [{ from: "skill", mod: "action", label: "pick-and-place, nav", n: "per skill", k: 3 }],
    links: [
      { from: "succ", to: "llm", kind: "feeds", label: "'Success: False'|as text", note: "feedback enters the prompt as language" },
      { from: "llm", to: "skill", kind: "two-stage", label: "next skill", note: "the skill runs to completion before the next query" }
    ],
    callouts: [
      "No official code release; everything here is from the paper.",
      "Real tabletop: Object + Success feedback finishes 90 % of tasks against 20 % for an open-loop LLM with a one-off object list (Table 2, 10 runs each).",
      "In simulation the object list, success and task-progress feedback come from ground-truth state, not from a learned model (App. A.1)."
    ]
  });

  /* ---------------- Code as Policies ---------------- */
  RB.arch.spec({
    id: "code-as-policies", method: "code-as-policies", name: "Code as Policies", year: 2022,
    figRef: "Liang et al. Fig. 1 · §III · §IV-A, App. G–H", prov: "Tabletop pick-and-place instantiation",
    lede: "A code-writing LLM turns a comment-style instruction into Python that calls perception and control APIs. When the code uses a function that does not exist yet, another prompt writes it, recursively. The policy is the program; nothing is trained.",
    sources: {
      p1: { kind: "paper", ref: "Liang et al. 2022, §III and §III-A (LMPs, prompting, hierarchical code-gen)", url: "https://arxiv.org/abs/2209.07753" },
      p2: { kind: "paper", ref: "Liang et al. 2022, §IV-A, Tables I–II (RoboCodeGen, HumanEval)", url: "https://arxiv.org/abs/2209.07753" },
      p3: { kind: "paper", ref: "Liang et al. 2022, App. G–H (VLMs, drawing APIs)", url: "https://arxiv.org/abs/2209.07753" },
      c1: { kind: "code", repo: "google-research/google-research", path: "code_as_policies/Interactive_Demo.ipynb", commit: "d36068b", url: GR + "code_as_policies/Interactive_Demo.ipynb" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p1"],
      params: ["Codex size not public", "p2"],
      vision: ["Open-vocabulary detectors: ViLD (mobile robot), MDETR (tabletop, whiteboard); pixels deprojected with depth", "p3"],
      backbone: ["OpenAI Codex code-davinci-002, greedy decoding (temperature 0)", "p1", "c1"],
      head: ["Scripted control primitives (pick_place, set_velocity, draw, say)", "p1", "p3"],
      output: ["Executable Python that loops over perception results and calls control APIs", "p1"],
      attention: null,
      cond: ["Prompt = Hints (imports, API names) + Examples (comment → code pairs)", "p1"],
      steps: ["One program per instruction; undefined functions generated recursively", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["None: few-shot prompting only", "p1"]
    },
    blueprint: {
      headline: "Code as Policies: the policy is a program",
      note: "The LLM never sees pixels. Perception APIs turn the scene into names and coordinates; the top-level LMP writes code over them and calls control APIs. Functions it invents are written by a function-generating LMP, which can call itself until everything is defined; then Python exec runs the result.",
      towers: [
        { mod: "perc", title: "Perception APIs", sub: "open-vocabulary detectors", compact: true,
          input: { label: "RGB-D image + object query", caption: "e.g. detect_objects('bowls')" },
          rows: [
            { t: "conv", label: "ViLD (mobile robot)", call: ["boxes + masks from a caption", "p3"] },
            { t: "conv", label: "MDETR (tabletop, board)", call: ["'square' beats 'block' as query", "p3"] },
            { t: "pool", label: "Deproject pixels with depth" } ],
          output: { label: "object names, positions, boxes" } },
        { mod: "lmp", title: "Language model programs", sub: "Codex code-davinci-002, prompted",
          input: { label: "# instruction as a comment", caption: "'stack the blocks on the empty bowl'" },
          rows: [
            { t: "embed", label: "Prompt: Hints + Examples", call: ["imports and APIs, then comment → code pairs", "p1"] },
            { id: "llm", t: "attn", label: "Codex code-davinci-002", call: ["temperature 0; 512-token cap", "p1", "c1"], callDy: -8 },
            { t: "group", label: "LMP hierarchy (tabletop)", rows: [
              { t: "mlp", label: "tabletop_ui (top level)" },
              { t: "mlp", label: "parse_obj_name · parse_position" },
              { id: "fgen", t: "mlp", label: "fgen: define missing functions (recursive)",
                zoom: { k: "rows", title: "Hierarchical code-gen", rows: ["code calls stack_objs_in_order()", "not defined → ask fgen LMP", "fgen writes the def (may recurse)", "all functions now exist", "exec() with API globals"] } } ] },
            { t: "linear", label: "Safety check, then exec()", call: ["no import, no __ names, no exec / eval", "p1"],
              zoom: { k: "rows", title: "A generated policy", rows: ["blocks = get_obj_names(…)", "bowl = parse_obj_name(…)", "for each block b:", "  put_first_on_second(b, bowl)", "say('done')"] } } ],
          output: { label: "policy code, executed live" } },
        { mod: "ctrl", title: "Control APIs", sub: "scripted primitives", compact: true,
          input: { label: "API calls from the code", caption: "positions, velocities, text" },
          rows: [
            { t: "linear", label: "put_first_on_second, goto" },
            { t: "linear", label: "set_velocity · draw · say" } ],
          output: { label: "robot motion" } }
      ],
      links: [
        { from: "lmp", to: "ctrl", toRow: "input", label: "API calls" },
        { from: "perc", to: "lmp", toRow: "llm", label: "names + coordinates" }
      ]
    },
    modules: [
      { id: "perc", role: "vision-enc", roleLabel: "Perception APIs", name: "ViLD / MDETR", sub: "open-vocab detection", col: 0, frozen: true, short: "Detectors" },
      { id: "lmp", role: "planner", roleLabel: "Code-writing LLM", name: "Codex LMPs", sub: "code-davinci-002 · temp 0", col: 1, frozen: true, short: "Codex", main: true },
      { id: "ctrl", role: "net", roleLabel: "Control APIs (no weights)", name: "Scripted primitives", sub: "pick-place · velocity · say", col: 2, frozen: true, short: "Control" }
    ],
    inputs: [
      { to: "perc", mod: "vision", label: "RGB-D image", n: "per call", k: 3 },
      { to: "lmp", mod: "lang", label: "instruction (comment)", n: "text", k: 3 }
    ],
    outputs: [
      { from: "lmp", mod: "other", label: "Python policy code", n: "exec()", k: 4 },
      { from: "ctrl", mod: "action", label: "waypoints, velocities", n: "per API call", k: 3 }
    ],
    links: [
      { from: "perc", to: "lmp", kind: "feeds", label: "object names|and positions" },
      { from: "lmp", to: "ctrl", kind: "feeds", label: "API calls" }
    ],
    callouts: [
      "Hierarchical code-gen raises RoboCodeGen pass rate from 81 % to 95 % with code-davinci-002 and sets 39.8 % P@1 on HumanEval (Tables I–II).",
      "The released Colab demo runs a PyBullet tabletop that reads object positions from the <b>simulator's ground truth</b>; the ViLD and MDETR perception of the real-robot demos is not part of it."
    ]
  });

  /* ---------------- PaLM-E ---------------- */
  RB.arch.spec({
    id: "palm-e", method: "palm-e", name: "PaLM-E", year: 2023,
    figRef: "Driess et al. Fig. 1 · §3–5 · Table 1", prov: "PaLM-E-562B = PaLM 540B + ViT-22B",
    lede: "A decoder-only PaLM that reads 'multimodal sentences': image, state or object-slot embeddings are projected into the word-embedding space and dropped between text tokens. It writes plans as text, one step at a time, for low-level language-conditioned policies.",
    sources: {
      p1: { kind: "paper", ref: "Driess et al. 2023, §3 (multimodal sentences, control loop)", url: "https://arxiv.org/abs/2303.03378" },
      p2: { kind: "paper", ref: "Driess et al. 2023, §4–5 (encoders, sizes, freezing)", url: "https://arxiv.org/abs/2303.03378" },
      p3: { kind: "paper", ref: "Driess et al. 2023, §6.3–6.4, Table 1 (TAMP, Language-Table, mobile manipulation)", url: "https://arxiv.org/abs/2303.03378" },
      p4: { kind: "paper", ref: "Chowdhery et al. 2022 (PaLM), §2 and Table 1", url: "https://arxiv.org/abs/2204.02311" },
      p5: { kind: "paper", ref: "Dehghani et al. 2023 (ViT-22B), §2 and Table 1", url: "https://arxiv.org/abs/2302.05442" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p1"],
      params: ["12B (8B + ViT-4B), 84B (62B + ViT-22B), 562B (540B + ViT-22B)", "p2"],
      vision: ["ViT-22B or ViT-4B tokens → learned affine ψ; alternatives: state MLP, object-masked ViT, OSRT slots", "p2"],
      backbone: ["PaLM 540B: 118 layers, width 18,432, 48 query heads with multi-query attention", "p4"],
      head: ["None: PaLM's own vocabulary head writes the plan", "p1"],
      output: ["Text: answers, or the next plan step for a low-level policy", "p1"],
      attention: ["Causal decoder over interleaved [text | image | text …] tokens", "p1", "p4"],
      cond: ["Observations enter as tokens in place of <img>, <obj j> or state placeholders", "p1", "p2"],
      steps: ["Language-Table: subgoals at 1 Hz to a 5 Hz policy; kitchen: one step per query until 'terminate'", "p3"],
      chunk: null, rate: ["Planner 1 Hz, low-level policy 5 Hz (Language-Table)", "p3"], latency: null,
      train: ["Encoders + projector trained end to end; LLM frozen or fine-tuned (both studied); web VQA mixed with robot data", "p2", "p3"]
    },
    blueprint: {
      headline: "PaLM-E: images as words for a 540B LLM",
      note: "The ViT encodes each image into tokens; an affine projection maps them to PaLM's 18,432-d word space; they replace an <img> placeholder anywhere in the prompt. PaLM's 118 parallel blocks then read everything causally and write the next plan step, which an RT-1 or Language-Table policy executes.",
      towers: [
        { mod: "vit", title: "ViT-22B", sub: "image encoder, JFT-pretrained", compact: true,
          input: { label: "Image patches 14 × 14", caption: "one or more images per prompt" },
          rows: [
            { t: "embed", label: "Patch embedding", call: ["width 6,144", "p5"] },
            { t: "block", n: "48", rows: [
              { t: "norm", label: "LayerNorm (shared)" },
              { t: "attn", label: "MHA with QK-norm", call: ["48 heads", "p5"], zoom: { k: "heads", q: 48, kv: 48, hd: 128, title: "ViT-22B attention" } },
              { t: "ffn", label: "MLP, in parallel", call: ["hidden dimension 24,576", "p5"], zoom: { k: "mlp", act: "GELU", d: "6,144", ff: "24,576", title: "ViT-22B feed forward" } },
              { t: "add", span: 3 } ] },
            { t: "linear", label: "Affine projection ψ", call: ["ViT width → LLM word space", "p2"] } ],
          output: { label: "m image tokens" } },
        { mod: "palm", title: "PaLM 540B", sub: "decoder-only LLM",
          input: { label: "Multimodal sentence", caption: "'Given <img>. Q: how to …'" },
          rows: [
            { id: "emb", t: "embed", label: "Word embedding γ", call: ["vocabulary 256,000", "p2", "p4"] },
            { t: "block", n: "118", rows: [
              { t: "norm", label: "LayerNorm (shared)" },
              { t: "attn", label: "Multi-query attention", side: "RoPE", call: ["48 query heads, 1 KV head, head 256", "p4"], zoom: { k: "heads", q: 48, kv: 1, hd: 256, title: "PaLM multi-query attention" } },
              { t: "ffn", label: "SwiGLU MLP, in parallel", call: ["d_ff = 4 × 18,432 = 73,728", "p4"], zoom: { k: "glu", act: "Swish", d: "18.4k", ff: "73.7k", title: "PaLM SwiGLU (d 18,432 → 73,728)" } },
              { t: "add", span: 3 } ] },
            { t: "linear", label: "Tied output embedding", call: ["input and output embeddings shared", "p4"] } ],
          output: { label: "next plan step as text" } },
        { mod: "pol", title: "Low-level policy", sub: "RT-1 or Language-Table", compact: true,
          input: { label: "Plan step as text", caption: "'pick the green rice chip bag'" },
          rows: [
            { t: "attn", label: "RT-1 (mobile manip.)", call: ["image + instruction → end-effector", "p3"] },
            { t: "conv", label: "Lynch et al. (table)", call: ["runs 4 s per instruction at 10 Hz", "p3"] } ],
          output: { label: "robot actions; new image → PaLM-E" } }
      ],
      links: [
        { from: "palm", to: "pol", toRow: "input", label: "plan step" },
        { from: "vit", to: "palm", toRow: "emb", label: "replace <img>" }
      ]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "ViT-22B + ψ", sub: "48 × 6144 · 48 heads", col: 0, frozen: "partial", params: "22B", short: "ViT-22B",
        note: "The ViT is pretrained; the affine projector ψ is always trained. Whether the ViT itself is updated in PaLM-E-562B is not stated here.",
        stack: { rows: [
          { t: "in", label: "image, 14 × 14 patches", c: "data-1" },
          { t: "embed", label: "patch embedding + learned 1-D position", dims: "→ 6,144" },
          { t: "block", label: "parallel ViT block", n: "48", rows: [
            { t: "norm", label: "LayerNorm (no bias)" }, { t: "attn", label: "MHA · 48 heads · QK LayerNorm" }, { t: "ffn", label: "MLP 6,144 → 24,576 → 6,144 (parallel)" }, { t: "add", span: 3 } ] },
          { t: "linear", label: "affine ψ: ViT width → PaLM word space" },
          { t: "out", label: "m tokens per image", dims: "placed where <img> appears", c: "data-1" } ],
          facts: [["Width / depth / heads", ["6,144 / 48 / 48", "p5"]], ["MLP", ["24,576", "p5"]], ["Patch", ["14 × 14", "p5"]], ["Pretraining", ["JFT, about 4B images, at 224 × 224", "p5"]], ["Smaller option", ["ViT-4B in PaLM-E-12B", "p2"]]] } },
      { id: "palm", role: "lang", roleLabel: "Embodied LLM", name: "PaLM 540B", sub: "118 × 18432 · MQA", col: 1, frozen: false, params: "540B", short: "PaLM", main: true,
        stack: { rows: [
          { t: "in", label: "multimodal sentence", dims: "text tokens interleaved with observation tokens", c: "data-2" },
          { t: "embed", label: "word embedding γ (text only)", dims: "vocab 256,000 → 18,432" },
          { t: "block", label: "parallel decoder block", n: "118", rows: [
            { t: "norm", label: "LayerNorm (no bias)" },
            { t: "attn", label: "causal MQA · 48 query heads · 1 KV head · head 256 · RoPE" },
            { t: "ffn", label: "SwiGLU 18,432 → 73,728 → 18,432 (parallel)" },
            { t: "add", label: "y = x + Attn(LN x) + MLP(LN x)", span: 3 } ] },
          { t: "linear", label: "tied output embedding" },
          { t: "out", label: "text: answer or next plan step", c: "data-2" } ],
          facts: [["Layers / width / heads", ["118 / 18,432 / 48", "p4"]], ["Head size", ["256; one shared K/V head", "p4"]], ["FFN", ["SwiGLU, 4 × d_model", "p4"]], ["Vocab", ["256,000 SentencePiece", "p2", "p4"]], ["Smaller LLMs", ["PaLM 8B (32 × 4,096) and 62B (64 × 8,192)", "p4"]]] } },
      { id: "pol", role: "action-head", roleLabel: "Low-level policy", name: "RT-1 / Lang-Table", sub: "language-conditioned", col: 2, frozen: true, short: "Policy" }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "camera image", n: "any position in text", k: 4 },
      { to: "palm", mod: "lang", label: "task + step history", n: "text tokens", k: 3 },
      { to: "palm", mod: "state", label: "state or object slots", n: "via MLP ψ", k: 2 }
    ],
    outputs: [{ from: "pol", mod: "action", label: "end-effector actions", n: "5 Hz (table)", k: 3 }],
    links: [
      { from: "vit", to: "palm", kind: "prefix", label: "affine ψ|tokens join text" },
      { from: "palm", to: "pol", kind: "two-stage", label: "plan step|as text" }
    ],
    mask: { name: "Causal (decoder-only)", ref: "p1", axes: [{ label: "prefix text", short: "txt", mod: "lang" }, { label: "image tokens", short: "img", mod: "vision" }, { label: "generated plan", short: "plan", mod: "lang" }], m: ["100", "110", "111"],
      note: "Observation tokens sit wherever <img> appears and reuse PaLM's positional encoding; the loss covers only the generated text." },
    callouts: [
      "No code or weights are released. Layer numbers come from the PaLM and ViT-22B papers; tokens per image and the exact image resolution in PaLM-E are not stated.",
      "With the LLM frozen, co-training on the full mixture lifts TAMP planning with ViT-4B from 30.6 / 32.9 % (single robot) to 74.1 / 74.6 % (Table 1)."
    ]
  });

  /* ---------------- VoxPoser ---------------- */
  RB.arch.spec({
    id: "voxposer", method: "voxposer", name: "VoxPoser", year: 2023, parent: "code-as-policies",
    diffRows: ["vision", "head", "output", "steps", "rate"],
    figRef: "Huang et al. Fig. 2 · §3–4 · App. A.3, A.6", prov: "Real-world system; released code runs in RLBench",
    lede: "GPT-4 writes code that calls a detector and NumPy to paint 100 × 100 × 100 voxel maps: where to go (affordance), what to avoid, how to rotate, how fast, when to grip. A greedy planner walks the combined cost map and replans at 5 Hz.",
    sources: {
      p1: { kind: "paper", ref: "Huang et al. 2023, §3.1–3.3 and Fig. 2", url: "https://arxiv.org/abs/2307.05973" },
      p2: { kind: "paper", ref: "Huang et al. 2023, §4 implementation details (LLM, perception, value maps, planner)", url: "https://arxiv.org/abs/2307.05973" },
      p3: { kind: "paper", ref: "Huang et al. 2023, §4.1–4.3, Tables 1–3", url: "https://arxiv.org/abs/2307.05973" },
      p4: { kind: "paper", ref: "Huang et al. 2023, App. A.3 and A.6 (APIs, prompts)", url: "https://arxiv.org/abs/2307.05973" },
      c1: { kind: "code", repo: "huangwl18/VoxPoser", path: "src/configs/rlbench_config.yaml", commit: "e3a4c9e", url: VP + "src/configs/rlbench_config.yaml" },
      c2: { kind: "code", repo: "huangwl18/VoxPoser", path: "src/planners.py", commit: "e3a4c9e", url: VP + "src/planners.py" },
      c3: { kind: "code", repo: "huangwl18/VoxPoser", path: "README.md", commit: "e3a4c9e", url: VP + "README.md" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p1"],
      params: "not disclosed",
      vision: ["OWL-ViT box → SAM mask → XMem tracking → point cloud from RGB-D", "p2"],
      backbone: ["GPT-4 via API, temperature 0; 5–20 examples per LMP", "p2", "c1"],
      head: ["Greedy search over a voxel cost map + MPC; no learned head", "p2", "c2"],
      output: ["Dense 6-DoF end-effector waypoints with velocity and gripper action", "p1"],
      attention: null,
      cond: ["Value maps V: affordance, avoidance, rotation, velocity, gripper, each (100, 100, 100, k)", "p2", "c1"],
      steps: ["Plan, execute the first waypoint, replan", "p2"],
      chunk: null,
      rate: ["Replans at 5 Hz", "p2"], latency: null,
      train: ["None (zero-shot); optional MLP dynamics model learned online for contact-rich tasks", "p1", "p3"]
    },
    changes: [
      "The LLM no longer calls pre-built motion primitives: its code <b>writes 3-D voxel value maps</b> instead.",
      "A <b>motion planner</b> turns the maps into dense 6-DoF trajectories, replanning at 5 Hz.",
      "LMPs are specialised by map type: planner, composer, and one LMP per value map.",
      "Perception is an OWL-ViT → SAM → XMem chain on RGB-D, re-queried every step.",
      "LLM: GPT-4 instead of Codex; the recursive-LMP prompting style is kept."
    ],
    blueprint: {
      headline: "VoxPoser: an LLM paints cost into voxels",
      note: "The planner LMP splits the task; the composer calls one LMP per value map, whose code queries the perception stack and writes NumPy arrays. Affordance and avoidance maps become one cost; the other maps are read off at each waypoint. The code is cached per sub-task, so only perception and planning rerun at 5 Hz.",
      towers: [
        { mod: "perc", title: "Perception", sub: "detect(name) API", compact: true,
          input: { label: "Object or part name", caption: "multi-view RGB-D" },
          rows: [
            { t: "conv", label: "OWL-ViT: box", call: ["open-vocabulary detector", "p2"] },
            { t: "conv", label: "SAM: mask" },
            { t: "conv", label: "XMem: track the mask" },
            { t: "pool", label: "Point cloud from depth", call: ["centre, occupancy grid, normal", "p4"] } ],
          output: { label: "object dict per instance" } },
        { mod: "lmp", title: "GPT-4 LMPs", sub: "code-writing, prompted",
          input: { label: "Instruction L", caption: "'open the top drawer, mind the vase'" },
          rows: [
            { t: "attn", label: "Planner LMP → sub-tasks", call: ["GPT-4, temperature 0, 512 tokens", "p2", "c1"] },
            { t: "mlp", label: "composer LMP" },
            { t: "group", label: "value-map LMPs (NumPy code)", rows: [
              { id: "maps", t: "linear", label: "affordance · avoidance", call: ["(100, 100, 100, 1) each", "p2", "c1"] },
              { t: "linear", label: "rotation · velocity · gripper", call: ["rotation k = 4 (quaternion)", "p2"],
                zoom: { k: "rows", title: "One value-map LMP", rows: ["map = zeros(100, 100, 100)", "handles = detect('handle')", "top = highest handle", "map[top.xyz] = 1", "return smooth(map)"] } } ] } ],
          output: { label: "voxel value maps" } },
        { mod: "plan", title: "Motion planner", sub: "no learned weights", compact: true,
          input: { label: "Value maps", caption: "re-evaluated every step" },
          rows: [
            { t: "norm", label: "EDT / Gaussian smoothing", call: ["avoidance σ = 10 voxels (code)", "c1", "c2"] },
            { id: "cost", t: "mlp", label: "Cost = −(2·aff + 1·avoid)", call: ["weights 2 and 1", "p2", "c1"],
              zoom: { k: "rows", title: "Closed loop at 5 Hz", rows: ["observe RGB-D, re-run detect()", "rebuild maps with cached code", "greedy path through cost map", "read rotation / speed / grip", "execute first waypoint"] } },
            { t: "pool", label: "Greedy search → waypoints", call: ["≤ 300 steps; Savitzky–Golay smoothing", "c1", "c2"] } ],
          output: { label: "6-DoF waypoints → OSC" } }
      ],
      links: [
        { from: "lmp", to: "plan", toRow: "input", label: "value maps" },
        { from: "perc", to: "lmp", toRow: "maps", label: "object dicts" }
      ]
    },
    modules: [
      { id: "perc", role: "vision-enc", roleLabel: "Perception stack", name: "OWL-ViT · SAM · XMem", sub: "RGB-D → point clouds", col: 0, frozen: true, short: "Perception" },
      { id: "lmp", role: "planner", roleLabel: "Code-writing LLM", name: "GPT-4 LMPs", sub: "planner · composer · maps", col: 1, frozen: true, short: "GPT-4", main: true },
      { id: "plan", role: "planner", roleLabel: "Motion planner (no weights)", name: "Greedy voxel planner", sub: "100³ map · replans at 5 Hz", col: 2, frozen: true, short: "Planner",
        stack: { rows: [
          { t: "in", label: "affordance, avoidance, rotation, velocity, gripper maps", dims: "100 × 100 × 100 × k", c: "data-7" },
          { t: "norm", label: "Euclidean distance transform (affordance), Gaussian filter (avoidance)" },
          { t: "mlp", label: "cost = −(2 · affordance + 1 · avoidance), normalised" },
          { t: "pool", label: "greedy search for collision-free positions p₁…p_N" },
          { t: "linear", label: "attach rotation, velocity, gripper from their maps at each p" },
          { t: "out", label: "execute first waypoint, replan", dims: "operational-space controller", c: "data-3" } ],
          facts: [["Map size", ["100 × 100 × 100", "p2", "c1"]], ["Map weights", ["affordance 2, avoidance 1", "p2", "c1"]], ["Avoidance blur", ["Gaussian σ = 10 voxels", "c1"]], ["Replanning", ["5 Hz", "p2"]], ["Pushing MPC samples", ["10,000 (code)", "c1"]]] } }
    ],
    inputs: [
      { to: "perc", mod: "vision", label: "multi-view RGB-D", n: "every step", k: 4 },
      { to: "lmp", mod: "lang", label: "instruction L", n: "free text", k: 3 }
    ],
    outputs: [{ from: "plan", mod: "action", label: "6-DoF waypoints", n: "+ velocity, gripper", k: 4 }],
    links: [
      { from: "perc", to: "lmp", kind: "feeds", label: "detect() results" },
      { from: "lmp", to: "plan", kind: "latent", label: "voxel value maps|(100³ × k)" }
    ],
    callouts: [
      "The released code runs in RLBench and <b>uses RLBench's object masks</b> instead of the OWL-ViT → SAM → XMem pipeline of the real-robot system (README).",
      "Real world: 88 % success on static scenes and 70 % under disturbances, against 24 % and 0 % for an LLM calling primitives (Table 1).",
      "Code-only values (not given in the paper): avoidance Gaussian σ = 10 voxels, a 300-step planner cap and Savitzky–Golay path smoothing."
    ]
  });

  /* ---------------- ReKep ---------------- */
  RB.arch.spec({
    id: "rekep", method: "rekep", name: "ReKep", year: 2024, parent: "voxposer",
    diffRows: ["vision", "backbone", "head", "output", "cond", "rate"],
    figRef: "Huang et al. Fig. 2 · §3 · App. A.5–A.9", prov: "",
    lede: "DINOv2 features and SAM masks propose a few numbered keypoints on the image. GPT-4o reads the marked image and writes each task stage as Python cost functions of those keypoints. A SciPy solver finds end-effector poses that drive every cost below zero, at about 10 Hz.",
    sources: {
      p1: { kind: "paper", ref: "Huang et al. 2024, §3.1–3.2 (constraints, Eq. 1)", url: "https://arxiv.org/abs/2409.01652" },
      p2: { kind: "paper", ref: "Huang et al. 2024, §3.3–3.4 (solver, keypoint proposal, generation)", url: "https://arxiv.org/abs/2409.01652" },
      p3: { kind: "paper", ref: "Huang et al. 2024, App. A.5–A.8 (keypoints, VLM, tracker, sub-goal solver)", url: "https://arxiv.org/abs/2409.01652" },
      p4: { kind: "paper", ref: "Huang et al. 2024, §4.1, Tables 1–2", url: "https://arxiv.org/abs/2409.01652" },
      c1: { kind: "code", repo: "huangwl18/ReKep", path: "configs/config.yaml", commit: "63c43fd", url: RK + "configs/config.yaml" },
      c2: { kind: "code", repo: "huangwl18/ReKep", path: "keypoint_proposal.py", commit: "63c43fd", url: RK + "keypoint_proposal.py" },
      c3: { kind: "code", repo: "huangwl18/ReKep", path: "subgoal_solver.py", commit: "63c43fd", url: RK + "subgoal_solver.py" },
      c4: { kind: "code", repo: "facebookresearch/dinov2", path: "dinov2/models/vision_transformer.py", commit: "7764ea0", url: "https://github.com/facebookresearch/dinov2/blob/7764ea0/dinov2/models/vision_transformer.py" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p2"],
      params: "not disclosed",
      vision: ["DINOv2 ViT-S/14 patch features + SAM masks → k-means keypoints, lifted with calibrated RGB-D", "p2", "p3", "c2"],
      backbone: ["GPT-4o (closed), visual prompting with numbered keypoints", "p2", "c1"],
      head: ["SciPy: Dual Annealing + SLSQP for the sub-goal, SLSQP for the path", "p2", "c3"],
      output: ["SE(3) end-effector poses (one per arm) for the next sub-goal and the path to it", "p1", "p3"],
      attention: null,
      cond: ["Per stage: sub-goal constraints and path constraints f(k) ≤ 0 on keypoint positions", "p1"],
      steps: ["First solve ≈ 1 s (global + local), then local re-solves at ≈ 10 Hz", "p2"],
      chunk: null,
      rate: ["Keypoint tracking and ESDF at 20 Hz; solver ≈ 10 Hz", "p2", "p3"], latency: null,
      train: ["None: pretrained DINOv2, SAM, GPT-4o, AnyGrasp", "p2"]
    },
    changes: [
      "Task knowledge is written as <b>Python constraint functions on 3-D keypoints</b> instead of voxel value maps.",
      "A <b>VLM</b> (GPT-4o) reads a keypoint-marked image, where VoxPoser's LLM only saw detector output.",
      "Keypoints come from DINOv2 + SAM clustering, not from a named-object detector.",
      "The planner is a <b>constrained optimiser</b> over SE(3) poses (Dual Annealing + SLSQP), with stages and backtracking.",
      "Handles multi-stage and bimanual tasks: one pose per arm, 12 decision variables."
    ],
    blueprint: {
      headline: "ReKep: keypoints in, cost functions out",
      note: "One image goes through DINOv2 and SAM once to propose keypoints; GPT-4o writes the constraint code once per task. After that only the tracker and the solver loop: keypoints are re-tracked at 20 Hz and the solver re-optimises the next sub-goal and path at about 10 Hz, backtracking if a path constraint breaks.",
      towers: [
        { mod: "kp", title: "Keypoint proposer", sub: "DINOv2 ViT-S/14 + SAM", compact: true,
          input: { label: "RGB image", caption: "one camera with the whole scene" },
          rows: [
            { t: "embed", label: "Patch embedding 14 × 14", call: ["width 384", "c4"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["6 heads", "c4"], zoom: { k: "heads", q: 6, kv: 6, hd: 64, title: "DINOv2 ViT-S/14 attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "MLP", call: ["ratio 4 → 1,536", "c4"] },
              { t: "add", span: 2 } ] },
            { id: "km", t: "pool", label: "k-means in each SAM mask", call: ["k = 5 per mask, PCA to 3-D first", "p3", "c1", "c2"],
              zoom: { k: "rows", title: "Keypoint proposal", rows: ["upsample patch features to pixels", "SAM: all masks in the scene", "PCA → 3 dims inside each mask", "k-means, k = 5 → centroids", "lift to 3-D; merge close points"] } } ],
          output: { label: "numbered keypoints on image" } },
        { mod: "vlm", title: "GPT-4o", sub: "writes ReKep functions",
          input: { label: "Marked image + instruction", caption: "'pour tea into the cup'" },
          rows: [
            { t: "attn", label: "GPT-4o (closed)", call: ["temperature 0, ≤ 2,048 tokens (code)", "c1"] },
            { t: "linear", label: "Number of stages N" },
            { id: "rk", t: "mlp", label: "Sub-goal + path constraints", call: ["f(k) ≤ 0 means satisfied", "p1"],
              zoom: { k: "rows", title: "A ReKep function", rows: ["def subgoal_stage2(k):", "  spout, cup = k[2], k[3]", "  target = cup + [0, 0, 0.1]", "  return norm(spout − target)"] } } ],
          output: { label: "Python cost functions per stage" } },
        { mod: "solver", title: "Constrained solver", sub: "SciPy, no learned weights", compact: true,
          input: { label: "Tracked 3-D keypoints", caption: "DINOv2 tracker, 20 Hz" },
          rows: [
            { t: "mlp", label: "Sub-goal: Dual Annealing", call: ["+ SLSQP; ≈ 1 s first solve", "p2", "c3"] },
            { id: "path", t: "mlp", label: "Path: SLSQP re-solve", call: ["≈ 10 Hz, warm-started", "p2"],
              zoom: { k: "rows", title: "Control loop", rows: ["track keypoints (20 Hz)", "solve next sub-goal pose", "solve path to it", "path constraint broken? backtrack", "reached? next stage"] } },
            { t: "norm", label: "Collision (ESDF), reachability", call: ["nvblox ESDF at 20 Hz", "p3"] } ],
          output: { label: "SE(3) poses → robot" } }
      ],
      links: [
        { from: "vlm", to: "solver", toRow: "path", label: "constraint code" },
        { from: "kp", to: "vlm", toRow: "input", label: "marked image" }
      ]
    },
    modules: [
      { id: "kp", role: "vision-enc", roleLabel: "Keypoint proposer", name: "DINOv2 + SAM", sub: "ViT-S/14 · k-means k=5", col: 0, frozen: true, short: "DINOv2",
        stack: { rows: [
          { t: "in", label: "RGB image from the VLM camera", c: "data-1" },
          { t: "embed", label: "DINOv2 ViT-S/14 patch features", dims: "12 layers × 384, 6 heads" },
          { t: "linear", label: "bilinear upsample to image size" },
          { t: "conv", label: "SAM: masks of all objects", dims: "masks over half the image skipped (code)" },
          { t: "pool", label: "per mask: PCA → 3, k-means k = 5" },
          { t: "out", label: "candidate keypoints in 3-D", dims: "close candidates merged by Mean Shift", c: "data-1" } ],
          facts: [["Backbone", ["DINOv2 ViT-S/14: 384 wide, 12 deep, 6 heads", "p3", "c4"]], ["Clusters per mask", ["5", "p3", "c1"]], ["Merge distance", ["8 cm (paper) · 6 cm (code)", "p3", "c1"]], ["Tracker", ["DINOv2 features, top 100 matches, 20 Hz", "p3"]]] } },
      { id: "vlm", role: "planner", roleLabel: "VLM planner", name: "GPT-4o", sub: "writes constraint code", col: 1, frozen: true, short: "GPT-4o", main: true },
      { id: "solver", role: "planner", roleLabel: "Optimiser (no weights)", name: "SciPy solver", sub: "Dual Annealing + SLSQP", col: 2, frozen: true, short: "Solver" }
    ],
    inputs: [
      { to: "kp", mod: "vision", label: "RGB-D view", n: "first frame", k: 3 },
      { to: "vlm", mod: "lang", label: "instruction", n: "free text", k: 2 },
      { to: "solver", mod: "vision", label: "tracked keypoints", n: "20 Hz", k: 3 }
    ],
    outputs: [{ from: "solver", mod: "action", label: "SE(3) end-effector poses", n: "1 or 2 arms", k: 3 }],
    links: [
      { from: "kp", to: "vlm", kind: "feeds", label: "numbered|keypoint marks" },
      { from: "vlm", to: "solver", kind: "two-stage", label: "ReKep functions|per stage" }
    ],
    callouts: [
      "Paper vs code: the paper uses DINOv2 <b>with registers</b> (ViT-S/14) and merges keypoints within 8 cm; the released code loads <code>dinov2_vits14</code> without registers and merges within 6 cm.",
      "The paper states decision variables are normalised to [0, 1] in §3.3 but [−1, 1] in App. A.8; the code uses [−1, 1].",
      "The released code runs in OmniGibson with a Fetch robot and <code>chatgpt-4o-latest</code>; AnyGrasp and nvblox belong to the real-robot system. Real-robot success: 68.6 % with annotated and 44.3 % with automatic ReKep, against 10.0 % for VoxPoser (Table 1)."
    ]
  });

  /* ---------------- MOKA ---------------- */
  RB.arch.spec({
    id: "moka", method: "moka", name: "MOKA", year: 2024,
    figRef: "Liu et al. Fig. 2 · §IV · App. A–B", prov: "",
    lede: "GPT-4V splits the task into sub-tasks, then, per sub-task, picks from numbered marks drawn on the image: a grasp point, a function point, a target point and two grid tiles for pre- and post-contact waypoints. Depth lifts the picks to 3-D; a scripted grasp-and-move executes them.",
    sources: {
      p1: { kind: "paper", ref: "Liu et al. 2024, §IV-A–IV-B (affordance representation, hierarchical prompting)", url: "https://arxiv.org/abs/2403.03174" },
      p2: { kind: "paper", ref: "Liu et al. 2024, §IV-C–IV-E (mark-based visual prompting, motion, bootstrapping)", url: "https://arxiv.org/abs/2403.03174" },
      p3: { kind: "paper", ref: "Liu et al. 2024, App. A–B (setup, proposals, execution)", url: "https://arxiv.org/abs/2403.03174" },
      c1: { kind: "code", repo: "moka-manipulation/moka", path: "config/moka.yaml", commit: "f6b6425", url: MK + "config/moka.yaml" },
      c2: { kind: "code", repo: "moka-manipulation/moka", path: "moka/gpt_utils.py", commit: "f6b6425", url: MK + "moka/gpt_utils.py" },
      c3: { kind: "code", repo: "moka-manipulation/moka", path: "moka/vision/segmentation.py", commit: "f6b6425", url: MK + "moka/vision/segmentation.py" },
      c4: { kind: "code", repo: "moka-manipulation/moka", path: "moka/vision/keypoint.py", commit: "f6b6425", url: MK + "moka/vision/keypoint.py" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p1"],
      params: "not disclosed",
      vision: ["GroundedSAM (GroundingDINO + SAM) masks; keypoint candidates by farthest-point sampling on each contour + centre", "p2", "p3"],
      backbone: ["GPT-4V (paper); the code defaults to gpt-4o", "p1", "c2"],
      head: ["Analytic antipodal grasp sampler + scripted waypoint motion", "p3"],
      output: ["Per sub-task: grasp, function and target keypoints, pre-/post-contact tiles, heights, tool orientation", "p1", "p2"],
      attention: null,
      cond: ["Mark-based visual prompt: P1…Pn on the grasped object, Q1…Qm on the target, 5 × 5 chess-style grid", "p2", "c1"],
      steps: ["Two VLM queries per task level: one high-level, one low-level per sub-task", "p1"],
      chunk: null,
      rate: ["Robot at 5 Hz; each stage ends after 100 steps", "p3"], latency: null,
      train: ["None zero-shot; optional in-context examples or distillation into Octo from collected successes", "p2", "p3"]
    },
    blueprint: {
      headline: "MOKA: manipulation as multiple-choice VQA",
      note: "The VLM never outputs raw coordinates. GroundedSAM segments the objects named by the high-level plan; candidate points and a 5 × 5 grid are drawn on the image; GPT-4V answers by picking labels. Depth and an analytic grasp sampler turn the labels into a grasp and a three-waypoint contact motion.",
      towers: [
        { mod: "marks", title: "Mark proposer", sub: "GroundedSAM + grid",
          input: { label: "Object names from the plan", caption: "e.g. 'trash, broom'" },
          rows: [
            { t: "conv", label: "GroundingDINO: boxes", call: ["box / text thresholds 0.3 / 0.22 (code)", "c3"] },
            { t: "conv", label: "SAM: masks", call: ["ViT-H checkpoint (code)", "c3"] },
            { id: "fps", t: "pool", label: "FPS on contour + centre", call: ["6 candidates per object (code)", "c1", "c4"] },
            { t: "linear", label: "Overlay 5 × 5 tile grid", call: ["columns a–e, rows 1–5", "p3", "c1"],
              zoom: { k: "rows", title: "Marks on the image", rows: ["P1…Pn on the grasped object", "Q1…Qm on the unattached object", "5 × 5 grid, chess notation", "VLM answers with labels only"] } } ],
          output: { label: "annotated image" } },
        { mod: "vlm", title: "GPT-4V", sub: "two prompt levels", compact: true,
          input: { label: "Instruction + top-down image", caption: "'wipe the trash off the table'" },
          rows: [
            { t: "attn", label: "High level: sub-tasks", call: ["objects + motion direction", "p1"] },
            { id: "low", t: "attn", label: "Low level: pick marks", call: ["3 keypoints + 2 tiles", "p1", "p2"],
              zoom: { k: "rows", title: "Low-level answer", rows: ["grasp_keypoint: P5", "function_keypoint: P3", "target_keypoint: Q1", "pre_contact_tile: c4", "post_contact_tile: e4"] } } ],
          output: { label: "selected marks + heights" } },
        { mod: "exec", title: "Motion execution", sub: "analytic, no learned weights", compact: true,
          input: { label: "2-D picks + heights", caption: "depth from the top-down camera" },
          rows: [
            { t: "pool", label: "Antipodal grasp sampler", call: ["30 proposals, nearest to x_grasp", "p3"] },
            { id: "mv", t: "linear", label: "Pre-contact → target → post", call: ["waypoints sampled inside the tiles", "p3"],
              zoom: { k: "rows", title: "One sub-task", rows: ["grasp nearest proposal to x_grasp", "move x_function to pre-contact", "move to x_target (contact)", "move to post-contact", "return to neutral, observe"] } } ],
          output: { label: "7-D actions at 5 Hz" } }
      ],
      links: [
        { from: "vlm", to: "exec", toRow: "input", label: "chosen marks" },
        { from: "marks", to: "vlm", toRow: "low", label: "marked image" }
      ]
    },
    modules: [
      { id: "marks", role: "vision-enc", roleLabel: "Mark proposer", name: "GroundedSAM + grid", sub: "keypoints · 5 × 5 tiles", col: 0, frozen: true, short: "GroundedSAM" },
      { id: "vlm", role: "planner", roleLabel: "VLM planner", name: "GPT-4V", sub: "hierarchical prompting", col: 1, frozen: true, short: "GPT-4V", main: true },
      { id: "exec", role: "net", roleLabel: "Motion (no weights)", name: "Grasp + waypoints", sub: "antipodal sampler · 3 pts", col: 2, frozen: true, short: "Execution" }
    ],
    inputs: [
      { to: "marks", mod: "vision", label: "top-down RGB-D", n: "ZED 2 camera", k: 3 },
      { to: "vlm", mod: "lang", label: "instruction", n: "free text", k: 2 }
    ],
    outputs: [{ from: "exec", mod: "action", label: "EE twist + gripper", n: "7-D, 5 Hz", k: 3 }],
    links: [
      { from: "marks", to: "vlm", kind: "feeds", label: "marked image|(visual prompt)" },
      { from: "vlm", to: "exec", kind: "two-stage", label: "keypoints|+ tiles" }
    ],
    callouts: [
      "Paper vs code: the paper queries <b>GPT-4V</b> and samples <b>30</b> antipodal grasps; the released code defaults to <code>gpt-4o</code> and samples <b>50</b>.",
      "Successful MOKA rollouts double as demonstrations: they are used as in-context examples or distilled into an Octo policy with a behaviour-cloning loss (§IV-E)."
    ]
  });

  /* ---------------- RoboPoint ---------------- */
  RB.arch.spec({
    id: "robopoint", method: "robopoint", name: "RoboPoint", year: 2024,
    figRef: "Yuan et al. Fig. 2 · §3–4 · App. A", prov: "robopoint-v1-vicuna-v1.5-13b (full fine-tune)",
    lede: "A LLaVA-1.5 model, instruction-tuned to point. A frozen CLIP ViT-L/14 encodes the image, a 2-layer MLP projects it into Vicuna-13B, and the answer is plain text: a list of normalised (x, y) points that satisfy a spatial instruction. Depth turns the points into 3-D targets.",
    sources: {
      p1: { kind: "paper", ref: "Yuan et al. 2024, §3 (formulation, instruction tuning)", url: "https://arxiv.org/abs/2406.10721" },
      p2: { kind: "paper", ref: "Yuan et al. 2024, §4 and Table 1 (data mix)", url: "https://arxiv.org/abs/2406.10721" },
      p3: { kind: "paper", ref: "Yuan et al. 2024, §5, Tables 2–4, Fig. 5 (results)", url: "https://arxiv.org/abs/2406.10721" },
      p4: { kind: "paper", ref: "Yuan et al. 2024, App. A (training setup)", url: "https://arxiv.org/abs/2406.10721" },
      c1: { kind: "code", repo: "wentao-yuan/robopoint-v1-vicuna-v1.5-13b (Hugging Face)", path: "config.json", commit: "508ed28", url: "https://huggingface.co/wentao-yuan/robopoint-v1-vicuna-v1.5-13b/blob/508ed28687caeeb923e1d7d5905e37dccc16c991/config.json" },
      c2: { kind: "code", repo: "wentaoyuan/RoboPoint", path: "scripts/finetune_vicuna.sh", commit: "206cb1e", url: RP + "scripts/finetune_vicuna.sh" },
      c3: { kind: "code", repo: "openai/clip-vit-large-patch14-336 (Hugging Face)", path: "config.json", commit: "ce19dc9", url: "https://huggingface.co/openai/clip-vit-large-patch14-336/blob/ce19dc912ca5cd21c8a653c79e251e808ccabcd1/config.json" }
    },
    summary: {
      pattern: ["LLM/VLM planner", "p1"],
      params: ["13B (Vicuna-v1.5-13B base)", "p1"],
      vision: ["CLIP ViT-L/14 at 336 × 336 → 24 × 24 = 576 patch tokens from the penultimate layer; frozen", "p4", "c1", "c3"],
      backbone: ["Vicuna-v1.5-13B: 40 layers, width 5,120, 40 heads, SwiGLU 13,824", "p1", "c1"],
      head: ["LM head over the 32,000-token vocabulary: points are written as text", "c1"],
      output: ["List of (x, y) points normalised to [0, 1]", "p1", "p2"],
      attention: ["Causal over [image tokens | instruction | answer]", "c1"],
      cond: ["Image tokens through a 2-layer GELU MLP projector (1,024 → 5,120)", "p1", "c1"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["1 epoch on 347K object-ref + 320K free-space + 665K VQA + 100K LVIS; 40 h on 16 A100s", "p2", "p4"]
    },
    blueprint: {
      headline: "RoboPoint: a VLM that answers with points",
      note: "Standard LLaVA-1.5 wiring. 576 CLIP patch tokens pass through the MLP projector and sit in front of the instruction; Vicuna's 40 causal blocks write the answer. The projector and Vicuna are updated; CLIP stays frozen. Synthetic free-space data is what teaches it to point at empty space.",
      towers: [
        { mod: "clip", title: "CLIP ViT-L/14-336", sub: "vision encoder, frozen", compact: true,
          input: { label: "Image 336 × 336", caption: "padded to square" },
          rows: [
            { t: "embed", label: "Patch embedding 14 × 14", call: ["24 × 24 = 576 patches, width 1,024", "c1", "c3"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["16 heads", "c3"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "MLP (QuickGELU)", call: ["hidden dimension 4,096", "c3"], zoom: { k: "mlp", act: "QuickGELU", d: "1,024", ff: "4,096", title: "CLIP ViT-L feed forward" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Take penultimate layer", call: ["mm_vision_select_layer = −2", "c1"] } ],
          output: { label: "576 patch features" } },
        { mod: "llm", title: "Vicuna-v1.5-13B", sub: "language model, fine-tuned",
          input: { label: "Image tokens + instruction", caption: "'find free space left of the bowl'" },
          rows: [
            { id: "proj", t: "mlp", label: "Projector: 2-layer MLP", call: ["1,024 → 5,120, GELU (mlp2x_gelu)", "p1", "c1"] },
            { t: "embed", label: "Token embedding", call: ["vocabulary 32,000 · width 5,120", "c1"] },
            { t: "block", n: "40", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["40 heads, head dim 128", "c1"], zoom: { k: "heads", q: 40, kv: 40, hd: 128, title: "Vicuna-13B attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["hidden dimension 13,824", "c1"], zoom: { k: "glu", act: "SiLU", d: "5,120", ff: "13,824", title: "Vicuna feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head → point text", call: ["'[(0.56, 0.69), (0.53, 0.76)]'", "p2"],
              zoom: { k: "rows", title: "From text to robot target", rows: ["parse list of (x, y) in [0, 1]", "scale to pixels", "look up depth → 3-D point", "add offset → end-effector pose", "motion planner executes"] } } ],
          output: { label: "points as text" } }
      ],
      links: [{ from: "clip", to: "llm", toRow: "proj", label: "576 patch features" }]
    },
    modules: [
      { id: "clip", role: "vision-enc", name: "CLIP ViT-L/14-336", sub: "24 × 1024 · 16 heads", col: 0, frozen: true, short: "CLIP ViT-L" },
      { id: "llm", role: "vlm", name: "Vicuna-v1.5-13B", sub: "40 × 5120 · 40 heads", col: 1, frozen: false, params: "13B", short: "Vicuna-13B", main: true,
        stack: { rows: [
          { t: "in", label: "[576 image tokens | instruction tokens]", c: "data-2" },
          { t: "mlp", label: "projector: 1,024 → 5,120 → 5,120 · GELU", dims: "image tokens only" },
          { t: "embed", label: "token embedding (text only)", dims: "vocab 32,000 → 5,120" },
          { t: "block", label: "Llama decoder block (pre-norm)", n: "40", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "causal MHA · 40 heads · head 128 · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 5,120 → 13,824 → 5,120" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "LM head → 32,000 logits" },
          { t: "out", label: "answer text: list of (x, y)", c: "data-2" } ],
          facts: [["Layers / width / heads", ["40 / 5,120 / 40", "c1"]], ["FFN", ["13,824, SiLU gate", "c1"]], ["Context", ["2,048 tokens in training", "c1", "c2"]], ["Projector", ["mlp2x_gelu, from 1,024-d CLIP features", "c1"]], ["Trainable", ["projector + LLM; CLIP and tokenizer frozen", "p1"]], ["Learning rate", ["4e-5 (paper) · 2e-5 script default", "p4", "c2"]]] } }
    ],
    inputs: [
      { to: "clip", mod: "vision", label: "RGB image", n: "336 × 336", k: 4 },
      { to: "llm", mod: "lang", label: "spatial instruction", n: "text", k: 3 }
    ],
    outputs: [{ from: "llm", mod: "other", label: "(x, y) points as text", n: "normalised [0, 1]", k: 4 }],
    links: [{ from: "clip", to: "llm", kind: "prefix", label: "2-layer MLP|576 tokens" }],
    mask: { name: "Causal (LLaVA)", ref: "c1", axes: [{ label: "image tokens", short: "img", mod: "vision" }, { label: "instruction", short: "ℓ", mod: "lang" }, { label: "answer points", short: "pts", mod: "other" }], m: ["100", "110", "111"],
      note: "One causal sequence; the loss is on the answer tokens only." },
    callouts: [
      "Paper vs code: App. A reports learning rate 4e-5 on 16 A100s × 16 per GPU; <code>finetune_vicuna.sh</code> defaults to 2e-5 on 8 GPUs × 16.",
      "RoboPoint 46.8 % vs GPT-4o 29.1 % on Where2Place and 49.8 % vs 15.3 % on RoboRefIt (share of points inside the target mask, Table 2)."
    ]
  });

  /* ---------------- CLIPort ---------------- */
  RB.arch.spec({
    id: "cliport", method: "cliport", name: "CLIPort", year: 2021,
    figRef: "Shridhar et al. Figs. 2, 7 · §3 · App. C", prov: "Released two-stream agent (lateral)",
    lede: "Transporter with a CLIP 'what' stream. A frozen CLIP ResNet-50 plus a decoder conditioned on the CLIP sentence embedding gives semantics; a Transporter ResNet on RGB-D gives spatial precision; lateral 1 × 1 convs fuse them into dense pick and place affordance maps.",
    sources: {
      p1: { kind: "paper", ref: "Shridhar et al. 2021, §3.1 (Transporter formulation, two-stream architecture)", url: "https://arxiv.org/abs/2109.12098" },
      p2: { kind: "paper", ref: "Shridhar et al. 2021, §3.2 (training)", url: "https://arxiv.org/abs/2109.12098" },
      p3: { kind: "paper", ref: "Shridhar et al. 2021, App. C and Fig. 7 (layer diagram)", url: "https://arxiv.org/abs/2109.12098" },
      p4: { kind: "paper", ref: "Shridhar et al. 2021, §4 and App. D (setup, real robot)", url: "https://arxiv.org/abs/2109.12098" },
      c1: { kind: "code", repo: "cliport/cliport", path: "cliport/agents/transporter.py", commit: "2be5c47", url: CP + "cliport/agents/transporter.py" },
      c2: { kind: "code", repo: "cliport/cliport", path: "cliport/models/clip_lingunet_lat.py", commit: "2be5c47", url: CP + "cliport/models/clip_lingunet_lat.py" },
      c3: { kind: "code", repo: "cliport/cliport", path: "cliport/cfg/train.yaml", commit: "2be5c47", url: CP + "cliport/cfg/train.yaml" },
      c4: { kind: "code", repo: "cliport/cliport", path: "cliport/models/core/transport.py", commit: "2be5c47", url: CP + "cliport/models/core/transport.py" },
      c5: { kind: "code", repo: "cliport/cliport", path: "cliport/models/resnet_lat.py", commit: "2be5c47", url: CP + "cliport/models/resnet_lat.py" }
    },
    summary: {
      pattern: ["Two-stream language-conditioned FCN (Transporter)", "p1"],
      params: null,
      vision: ["Top-down RGB-D heightmap (320 × 160 × 6 in code); CLIP ResNet-50 sees RGB only", "p1", "c1"],
      backbone: ["Frozen CLIP ResNet-50 → 7 × 7 × 2,048 + decoder; tabula-rasa Transporter ResNet on RGB-D", "p1", "c2"],
      head: ["3 two-stream FCNs: f_pick (1 channel), Φ_query and Φ_key (3 channels), cross-correlated", "p1", "c4"],
      output: ["T_pick and T_place in SE(2): pixel + one of 36 yaw bins", "p1", "c3"],
      attention: "None (convolutions only)",
      cond: ["CLIP sentence embedding (1,024) → FC → tiled → Hadamard product at 3 decoder layers", "p1", "c2"],
      steps: ["One forward pass per pick-and-place step", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["Cross-entropy on one-hot pick/place pixels; 200K iterations single-task, 600K multi-task, batch 1", "p2", "c3"]
    },
    blueprint: {
      headline: "CLIPort: CLIP says what, Transporter says where",
      note: "Every one of the three FCNs (pick, place query, place key) is this two-stream net. The language goal multiplies into the first three decoder levels of the semantic stream; every spatial-stream decoder level is concatenated in through a 1 × 1 conv. Pick fuses the two outputs by addition, place by a 1 × 1 conv, then cross-correlates query and key.",
      towers: [
        { mod: "lang", title: "CLIP text encoder", sub: "frozen transformer", compact: true,
          input: { label: "Instruction lₜ", caption: "'pack the scissors in the box'" },
          rows: [
            { t: "attn", label: "CLIP sentence encoder", call: ["1,024-d goal gₜ", "p1"] },
            { t: "linear", label: "FC per level", call: ["1,024 → 1,024 / 512 / 256", "c2"] },
            { t: "pool", label: "Tile to feature map size" } ],
          output: { label: "tiled goal g⁽ˡ⁾" } },
        { mod: "sem", title: "Semantic stream", sub: "CLIP ResNet-50 + LingUNet decoder",
          input: { label: "RGB heightmap", caption: "depth cannot enter CLIP" },
          rows: [
            { t: "conv", label: "CLIP ResNet-50 (frozen)", call: ["→ 7 × 7 × 2,048, penultimate layer", "p1", "p3"] },
            { t: "conv", label: "3 × 3 conv → 1,024", call: ["2,048 → 1,024 channels", "c2"] },
            { t: "block", n: "3", label: "language-fused levels", rows: [
              { id: "fuse", t: "film", label: "⊙ tiled goal (Hadamard)", side: "text",
                zoom: { k: "rows", title: "Language fusion at one level", rows: ["decoder features v⁽ˡ⁾", "g → FC → tile to h × w", "v⁽ˡ⁾ ⊙ g⁽ˡ⁾ (Hadamard)", "up 2× + CLIP skip", "concat spatial d⁽ˡ⁾ → 1 × 1 conv"] } },
              { t: "conv", label: "Up block + CLIP skip", call: ["1,024 → 512 → 256 → 128", "c2"] },
              { id: "lat1", t: "conv", label: "Lateral 1 × 1 conv fusion" } ] },
            { t: "block", n: "3", rows: [
              { t: "conv", label: "Conv + identity, 2× up", call: ["64 → 32 → 16 channels", "c2"] },
              { t: "conv", label: "Lateral 1 × 1 conv fusion" } ] },
            { id: "out", t: "conv", label: "1 × 1 conv → d channels", call: ["d = 1 pick, 3 place", "p1", "c4"],
              zoom: { k: "rows", title: "From features to actions", rows: ["pick: add streams → softmax", "place: crop 64 × 64 at T_pick", "rotate crop 36 times → Φ_query", "Φ_query ∗ Φ_key → Q_place", "argmax → pixel + yaw"] } } ],
          output: { label: "dense affordance features" } },
        { mod: "spat", title: "Spatial stream", sub: "Transporter ResNet, from scratch", compact: true,
          input: { label: "RGB-D heightmap", caption: "depth repeated to 3 channels" },
          rows: [
            { t: "conv", label: "3 × 3 conv, 64" },
            { t: "block", n: "5", rows: [{ t: "conv", label: "Conv + identity block", call: ["64 → 1,024 ch; 4 of 5 stride 2", "p3", "c5"] }] },
            { id: "sd", t: "block", n: "6", rows: [{ t: "conv", label: "Conv + identity (+ 2× up)", call: ["512 → 16 → d; each output lateral", "c2", "c5"] }] } ],
          output: { label: "spatial features d⁽ˡ⁾" } }
      ],
      links: [
        { from: "lang", to: "sem", toRow: "fuse", label: "g⁽ˡ⁾" },
        { from: "spat", to: "sem", toRow: "lat1", label: "lateral d⁽ˡ⁾" }
      ]
    },
    modules: [
      { id: "lang", role: "lang", name: "CLIP text encoder", sub: "sentence → 1,024-d", col: 0, frozen: true, short: "CLIP text" },
      { id: "sem", role: "vision-enc", roleLabel: "Semantic stream (what)", name: "CLIP RN50 + LingUNet", sub: "frozen enc · trained dec", col: 1, frozen: "partial", short: "Semantic", main: true,
        stack: { rows: [
          { t: "in", label: "RGB heightmap", dims: "320 × 160 (code)", c: "data-1" },
          { t: "conv", label: "CLIP ResNet-50 up to the penultimate layer (frozen)", dims: "→ 7 × 7 × 2,048" },
          { t: "conv", label: "3 × 3 conv → 1,024 · ReLU" },
          { t: "block", label: "language-fused decoder level", n: "3", rows: [
            { t: "film", label: "x ⊙ tile(FC(g))", side: "text" },
            { t: "conv", label: "Up: 2× bilinear + CLIP skip + convs", dims: "1,024 → 512 → 256 → 128" },
            { t: "conv", label: "lateral: concat spatial, 1 × 1 conv" } ] },
          { t: "block", label: "plain decoder level", n: "3", rows: [
            { t: "conv", label: "ConvBlock + IdentityBlock + 2× up", dims: "64 → 32 → 16" },
            { t: "conv", label: "lateral: concat spatial, 1 × 1 conv" } ] },
          { t: "conv", label: "1 × 1 conv → d, resize to input", dims: "d = 1 (pick) or 3 (place)" },
          { t: "out", label: "semantic dense features", dims: "fused with the spatial output", c: "data-1" } ],
          facts: [["CLIP encoder", ["ResNet-50, frozen, RGB only", "p1", "c2"]], ["Goal embedding", ["1,024-d sentence feature", "p1", "c2"]], ["Language fusion", ["Hadamard product ('mult') at 3 levels", "p1", "c3"]], ["Stream fusion", ["add (pick) · 1 × 1 conv (place)", "p1", "c3"]], ["Normalization", ["no BatchNorm (batch size 1)", "p3", "c3"]]] } },
      { id: "spat", role: "net", roleLabel: "Spatial stream (where)", name: "Transporter ResNet", sub: "RGB-D · hourglass FCN", col: 2, frozen: false, short: "Spatial",
        stack: { rows: [
          { t: "in", label: "RGB-D heightmap, depth repeated ×3", dims: "6 channels", c: "data-1" },
          { t: "conv", label: "3 × 3 conv, 64" },
          { t: "block", label: "encoder", n: "5", rows: [{ t: "conv", label: "ConvBlock + IdentityBlock", dims: "64 → 128 → 256 → 512 → 1,024" }] },
          { t: "block", label: "decoder", n: "6", rows: [{ t: "conv", label: "ConvBlock + IdentityBlock (+ 2× up on 5 of 6)", dims: "512 → 256 → 128 → 64 → 32 → d; each output sent laterally" }] },
          { t: "out", label: "spatial dense features", c: "data-1" } ],
          facts: [["Init", ["tabula rasa (trained from scratch)", "p1"]], ["Crop for Φ_query", ["64 × 64", "p1", "c1"]], ["Rotations", ["k = 36", "p1", "c3"]], ["Pixel size", ["3.125 mm (code)", "c1"]]] } }
    ],
    inputs: [
      { to: "lang", mod: "lang", label: "instruction lₜ", n: "1 sentence", k: 2 },
      { to: "sem", mod: "vision", label: "RGB heightmap", n: "top-down", k: 4 },
      { to: "spat", mod: "vision", label: "RGB-D heightmap", n: "6 channels", k: 4 }
    ],
    outputs: [{ from: "sem", mod: "action", label: "Q_pick, Q_place maps", n: "pixel × 36 yaws", k: 4 }],
    links: [
      { from: "lang", to: "sem", kind: "feeds", label: "⊙ tiled goal|3 levels" },
      { from: "spat", to: "sem", kind: "feeds", label: "lateral 1 × 1|conv fusion", note: "spatial features flow into the semantic decoder" }
    ],
    callouts: [
      "Paper vs code: Fig. 7 labels the input 6 × 320 × 320; the released agent uses a 320 × 160 × 6 heightmap (<code>in_shape</code>).",
      "The same two-stream network is instantiated three times: f_pick, Φ_query and Φ_key. Place = cross-correlation of the query crop's features with the key features over 36 rotations.",
      "Inner Monologue's simulated pick-and-place skill is a CLIPort-inspired, CLIP-based Transporter trained on 20,000 demos."
    ]
  });
})();
