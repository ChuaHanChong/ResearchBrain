/* Architecture specs, topic b6 (in-context learning policies). Numbers from the paper and the official code; see sources. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ VINN */
  RB.arch.spec({
    id: "vinn", method: "vinn", topic: "b6", name: "VINN", year: 2021,
    figRef: "Pari et al. Fig. 2 · §III · §IV-C, G", prov: "",
    lede: "No policy network at all. A ResNet-50, fine-tuned with BYOL on the demonstration frames, embeds each image; the action is a softmin-weighted average of the actions of the k nearest demonstration frames.",
    sources: {
      p1: { kind: "paper", ref: "Pari et al. 2021, §III (approach) and Fig. 2", url: "https://arxiv.org/abs/2112.01511" },
      p2: { kind: "paper", ref: "Pari et al. 2021, §IV-C (training details)", url: "https://arxiv.org/abs/2112.01511" },
      p3: { kind: "paper", ref: "Pari et al. 2021, §IV-G, H and Fig. 6 (choice of k)", url: "https://arxiv.org/abs/2112.01511" },
      p4: { kind: "paper", ref: "He et al. 2016, Table 1 (ResNet-50)", url: "https://arxiv.org/abs/1512.03385" },
      c1: { kind: "code", repo: "jyopari/VINN", path: "representation_models/BYOL.py", commit: "23a756e", url: "https://github.com/jyopari/VINN/blob/23a756e/representation_models/BYOL.py" },
      c2: { kind: "code", repo: "jyopari/VINN", path: "stretch_code/remote_node/nearest.py", commit: "23a756e", url: "https://github.com/jyopari/VINN/blob/23a756e/stretch_code/remote_node/nearest.py" },
      c3: { kind: "code", repo: "jyopari/VINN", path: "README.md", commit: "23a756e", url: "https://github.com/jyopari/VINN/blob/23a756e/README.md" }
    },
    summary: {
      pattern: ["Visual representation encoder + k-NN action retrieval", "p1"],
      params: null,
      vision: ["ResNet-50 (ImageNet init), BYOL fine-tuned on demo frames; 224 × 224 → 2,048-d", "p2", "c1", "c2"],
      backbone: ["No policy network: locally weighted regression over demo embeddings", "p1"],
      head: ["Softmin-weighted average of the k nearest demo frames' actions", "p1", "c2"],
      output: ["Translation action; the door task adds a gripper state", "p1"],
      attention: null, cond: null,
      steps: ["One encoder pass and one nearest-neighbour search per control step", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["BYOL on the demo frames only (no action labels), 100 epochs, Adam 3e-4", "p2", "c1"]
    },
    blueprint: {
      headline: "VINN: embed, then copy your neighbours",
      note: "The only trained network is the encoder. Every demonstration frame is embedded once and stored with its action. At test time the query frame is embedded, compared with all stored embeddings, and the actions of the closest k are averaged with softmin weights.",
      towers: [
        { mod: "resnet", title: "ResNet-50", sub: "BYOL fine-tuned, fc removed",
          input: { label: "Camera frame 224 × 224", caption: "query frame, or each demo frame once" },
          rows: [
            { t: "conv", label: "Stem conv 7 × 7, stride 2", call: ["64 channels, then 3 × 3 max pool", "p4"] },
            { t: "block", n: "16", label: "Bottleneck", rows: [
              { t: "conv", label: "Conv 1 × 1 (reduce)" },
              { t: "conv", label: "Conv 3 × 3" },
              { t: "conv", label: "Conv 1 × 1 (expand)", call: ["3 + 4 + 6 + 3 blocks; 256 → 2,048 channels", "p4"],
                zoom: { k: "rows", title: "Four stages (ResNet-50)", rows: ["stage 1: 3 blocks, 256 ch", "stage 2: 4 blocks, 512 ch", "stage 3: 6 blocks, 1,024 ch", "stage 4: 3 blocks, 2,048 ch"] } },
              { t: "add", span: 3 } ] },
            { t: "pool", label: "Global average pool", call: ["2,048-d embedding e; final fc removed", "p2", "c2"],
              zoom: { k: "rows", title: "BYOL fine-tuning (no actions)", rows: ["two augmented views", "online: enc → proj → pred", "target: EMA copy", "loss: match the target"] } } ],
          output: { label: "embedding e" } },
        { mod: "knn", title: "k-NN regression", sub: "non-parametric, no weights", compact: true,
          input: { label: "e + stored demo pairs", caption: "(e⁽ⁱ⁾, a⁽ⁱ⁾) for every demo frame" },
          rows: [
            { t: "linear", label: "L2 distance to all demos", call: ["O(n) linear scan", "p3"] },
            { t: "pool", label: "Keep k nearest", call: ["k ≈ 10 (code: 5)", "p3", "c2"] },
            { t: "norm", label: "SoftMin weights", call: ["∝ exp(−distance)", "p1", "c2"] },
            { t: "linear", label: "Weighted sum of actions" } ],
          output: { label: "action â" } }
      ],
      links: [{ from: "resnet", to: "knn", toRow: "input", label: "query embedding" }]
    },
    modules: [
      { id: "resnet", role: "vision-enc", roleLabel: "BYOL encoder", name: "ResNet-50", sub: "BYOL · 2,048-d", col: 0, frozen: false, main: true, short: "ResNet-50",
        stack: { rows: [
          { t: "in", label: "frame 224 × 224 × 3", dims: "random crop, jitter, grayscale, blur in training", c: "data-1" },
          { t: "conv", label: "Stem 7 × 7, 64 ch, stride 2 · max pool" },
          { t: "block", label: "Bottleneck stages", n: "16", rows: [{ t: "conv", label: "1 × 1 → 3 × 3 → 1 × 1" }, { t: "add", span: 1 }] },
          { t: "pool", label: "Global average pool", dims: "→ 2,048" },
          { t: "out", label: "embedding e", dims: "fc = Identity", c: "data-1" } ],
          facts: [["Init", ["ImageNet, then BYOL on the task's own frames", "p2"]], ["Stages", ["3, 4, 6, 3 bottleneck blocks", "p4"]], ["Embedding", ["2,048-d (avgpool output)", "c1", "c2"]], ["BYOL epochs", ["100", "p2"]], ["Optimiser", ["Adam, lr 3e-4", "c1"]]] } },
      { id: "knn", role: "net", roleLabel: "k-NN regression", name: "Nearest neighbours", sub: "softmin-weighted average", col: 1, frozen: true, short: "k-NN",
        note: "No weights: the demonstration set itself is the policy.",
        stack: { rows: [
          { t: "in", label: "query e + demo set", dims: "(e⁽ⁱ⁾, a⁽ⁱ⁾)", c: "data-3" },
          { t: "linear", label: "‖e − e⁽ⁱ⁾‖₂ for every stored frame" },
          { t: "pool", label: "sort, keep the k closest" },
          { t: "norm", label: "softmax(−distance)" },
          { t: "out", label: "â = Σ wᵢ a⁽ⁱ⁾", c: "data-3" } ],
          facts: [["k", ["≈ 10 on validation MSE; no gain beyond 20", "p3"]], ["k in robot code", ["5", "c2"]], ["Weights", ["softmin of L2 distance", "p1", "c2"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "camera frame", n: "224 × 224", k: 3 },
      { to: "knn", mod: "action", label: "demo embeddings + actions", n: "every demo frame", k: 5 }
    ],
    outputs: [{ from: "knn", mod: "action", label: "action â", n: "translation (+ grip)", k: 2 }],
    links: [{ from: "resnet", to: "knn", kind: "feeds", label: "2,048-d query|L2 distance" }],
    callouts: [
      "Paper §IV-G finds <b>k ≈ 10</b> best on validation; the released Stretch robot script (nearest.py) sets <b>k = 5</b>.",
      "Door opening: actions come from structure-from-motion on the GoPro video of a reacher-grabber; a separate gripper classifier labels four gripper states."
    ]
  });

  /* ------------------------------------------------------------------ MOSAIC */
  RB.arch.spec({
    id: "mosaic", method: "mosaic", topic: "b6", name: "MOSAIC", year: 2021,
    figRef: "Mandi et al. Fig. 2 · §IV · App. D, Table III", prov: "",
    lede: "One-shot imitation: a ResNet-18 trunk encodes a demonstration video and the robot's own frames; stacked non-local attention lets each observation frame attend to the demo; a logistic-mixture head predicts the action. A temporal contrastive loss shapes the features.",
    sources: {
      p1: { kind: "paper", ref: "Mandi et al. 2022, §IV-A (architecture) and Fig. 2", url: "https://arxiv.org/abs/2110.13423" },
      p2: { kind: "paper", ref: "Mandi et al. 2022, §IV-B, C (contrastive and imitation losses)", url: "https://arxiv.org/abs/2110.13423" },
      p3: { kind: "paper", ref: "Mandi et al. 2022, App. D, Table III (hyperparameters)", url: "https://arxiv.org/abs/2110.13423" },
      p4: { kind: "paper", ref: "Mandi et al. 2022, §V (setup, ResNet-18 blocks)", url: "https://arxiv.org/abs/2110.13423" },
      c1: { kind: "code", repo: "rll-research/mosaic", path: "mosaic/models/mt_rep.py", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/mosaic/models/mt_rep.py" },
      c2: { kind: "code", repo: "rll-research/mosaic", path: "experiments/config.yaml", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/experiments/config.yaml" },
      c3: { kind: "code", repo: "rll-research/mosaic", path: "mosaic/models/rep_modules.py", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/mosaic/models/rep_modules.py" },
      c4: { kind: "code", repo: "rll-research/mosaic", path: "mosaic/models/basic_embedding.py", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/mosaic/models/basic_embedding.py" },
      c5: { kind: "code", repo: "rll-research/mosaic", path: "README.md", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/README.md" }
    },
    summary: {
      pattern: ["Demo-conditioned attention policy (one-shot imitation)", "p1"],
      params: null,
      vision: ["ResNet-18 up to stage 3, from scratch: 100 × 180 frame → 256 × 7 × 12", "p3", "p4", "c2", "c4"],
      backbone: ["Non-local attention: 2 layers (3 multi-task), 4 heads, 1 × 1 × 1 conv Q, K, V", "p1", "p3", "c2"],
      head: ["Linear embed → action MLP → discretized logistic mixture", "p1", "c1"],
      output: ["One 8-d action per observation frame", "p1", "c2"],
      attention: ["Each observation frame attends to all 4 demo frames and to itself", "p1", "c1"],
      cond: ["A video demo of the same task variation, shot with a different arm (Sawyer)", "p1"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["BC + inverse dynamics + temporal contrastive, weights 1; Adam 5e-4, batch 30", "p2", "p3", "c2"]
    },
    blueprint: {
      headline: "MOSAIC: attend to the demo, then act",
      note: "Demo frames and observation frames share one conv trunk. Inside each attention layer, every observation frame queries the demo's keys and values together with its own. The attended observation features are flattened, embedded to 40 dimensions and decoded to an action, with the demo's mean embedding appended.",
      towers: [
        { mod: "trunk", title: "ResNet-18 trunk", sub: "stages 1–3, from scratch", compact: true,
          input: { label: "Frame 100 × 180", caption: "4 demo + 7 obs frames (1 at test)" },
          rows: [
            { t: "conv", label: "Stem conv 7 × 7 + max pool" },
            { t: "block", n: "6", label: "Basic block", rows: [
              { t: "conv", label: "Conv 3 × 3" },
              { t: "conv", label: "Conv 3 × 3", call: ["2 blocks per stage: 64, 128, 256 ch", "p4", "c4"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "256 × 7 × 12 per frame" } },
        { mod: "attn", title: "Demo–obs attention", sub: "non-local blocks on 3-D feature maps",
          input: { label: "Feature maps, all frames", caption: "[demo T = 4 | obs T] × 7 × 12" },
          rows: [
            { t: "embed", label: "+ sinusoidal position enc.", call: ["over time and space, 256 channels", "p1", "c1"] },
            { t: "block", n: "2", rows: [
              { t: "attn", label: "Demo self-attention", call: ["causal in time; output unused in code", "c1"] },
              { id: "oatt", t: "attn", label: "Obs attends [demo ‖ self]", call: ["4 heads, width 128, temperature 16", "p3", "c2"], zoom: { k: "heads", q: 4, kv: 4, hd: 32, title: "Attention heads (obs)" } },
              { t: "linear", label: "1×1×1 conv out, ReLU" },
              { t: "add", span: 2 },
              { t: "norm", label: "BatchNorm3d (shared)" } ] } ],
          output: { label: "attended obs + demo features" } },
        { mod: "head", title: "Embed + action head", sub: "shared by BC and inverse model", compact: true,
          input: { label: "Flattened features", caption: "256 · 7 · 12 per frame" },
          rows: [
            { id: "emb", t: "mlp", label: "Linear embed + L2 norm", call: ["21,504 → 256 → 40", "c1", "c2"],
              zoom: { k: "rows", title: "Temporal contrastive (training)", rows: ["augmented view → online", "EMA target: a nearby frame", "projector f, predictor g", "InfoNCE with bilinear W"] } },
            { t: "pool", label: "Mean over demo frames", call: ["demo embedding, 40-d", "c1", "c2"] },
            { t: "mlp", label: "Action MLP", call: ["40 → 128 → 64, ReLU", "c2"],
              zoom: { k: "rows", title: "Inverse model (training)", rows: ["[eₜ ‖ eₜ₊₁] → MLP → 64", "‖ demo mean, L2 norm", "same logistic head", "predicts aₜ from two frames"] } },
            { t: "linear", label: "‖ demo mean, L2 norm" },
            { t: "linear", label: "Logistic mixture head", call: ["μ, s, π for each of 8 action dims", "c1", "c2"] } ],
          output: { label: "aₜ ∼ discretized logistic mixture" } }
      ],
      links: [
        { from: "attn", to: "head", toRow: "input", label: "attended features" },
        { from: "trunk", to: "attn", toRow: "input", label: "feature maps" }
      ]
    },
    modules: [
      { id: "trunk", role: "vision-enc", name: "ResNet-18 (stage 1–3)", sub: "256 × 7 × 12", col: 0, frozen: false, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "frame 100 × 180 × 3", dims: "demo and obs frames alike", c: "data-1" },
          { t: "conv", label: "Stem 7 × 7 + max pool" },
          { t: "block", label: "Basic residual block", n: "6", rows: [{ t: "conv", label: "3 × 3 → 3 × 3" }, { t: "add", span: 1 }] },
          { t: "out", label: "256-channel map, 7 × 12", dims: "layer4, pool and fc dropped", c: "data-1" } ],
          facts: [["Blocks kept", ["first three residual stages", "p4", "c4"]], ["Channels", ["256", "c1"]], ["Init", ["from scratch (pretrained: False)", "c2"]], ["Input", ["100 × 180 × 3", "p3", "c2"]]] } },
      { id: "attn", role: "net", roleLabel: "Demo–obs attention", name: "Non-local attention", sub: "2 × · 4 heads · ff 128", col: 1, frozen: false, main: true, short: "Attention",
        stack: { rows: [
          { t: "in", label: "[demo | obs] features + sinusoid PE", dims: "B × 256 × T × 7 × 12", c: "data-1" },
          { t: "block", label: "Attention layer", n: "2", rows: [
            { t: "attn", label: "Demo: causal self-attention over T·H·W", note: "In the released code its output is computed but not passed on." },
            { t: "attn", label: "Obs: queries own H·W, keys demo T·H·W ‖ own" },
            { t: "linear", label: "1×1×1 conv 128 → 256, ReLU, dropout" },
            { t: "add", span: 2 },
            { t: "norm", label: "BatchNorm3d over all frames" } ] },
          { t: "out", label: "attended features", dims: "same shape", c: "data-1" } ],
          facts: [["Layers", ["2 single-task, 3 multi-task", "p3"]], ["Heads", ["4", "c2"]], ["Q, K, V width", ["128 (1 × 1 × 1 conv)", "c2"]], ["Temperature", ["16 = √256", "p3", "c1"]], ["Dropout", ["0.2", "c2"]]] } },
      { id: "head", role: "action-head", name: "Embed + logistic head", sub: "21,504 → 40 → 8-d mix", col: 2, frozen: false, short: "Head",
        stack: { rows: [
          { t: "in", label: "attended frame features", dims: "256 · 7 · 12 = 21,504", c: "data-3" },
          { t: "mlp", label: "Linear 256, ReLU, Linear 40 · L2 norm" },
          { t: "mlp", label: "Action MLP 40 → 128 → 64" },
          { t: "linear", label: "‖ mean demo embedding · L2 norm" },
          { t: "linear", label: "μ, log s, logits per mixture" },
          { t: "out", label: "discretized logistic mixture", dims: "8-d action", c: "data-3" } ],
          facts: [["Embedding", ["40-d", "c2"]], ["Mixtures", ["4 in config.yaml; 2 in the README command", "c2", "c5"]], ["Action dim", ["8", "c2"]], ["Losses", ["BC NLL + inverse NLL + contrastive", "p2", "c2"]]] } }
    ],
    inputs: [
      { to: "trunk", mod: "vision", label: "demo video (Sawyer)", n: "4 frames", k: 4 },
      { to: "trunk", mod: "vision", label: "robot frames (Panda)", n: "1 at test", k: 2 }
    ],
    outputs: [{ from: "head", mod: "action", label: "action aₜ", n: "8-d", k: 3 }],
    links: [
      { from: "trunk", to: "attn", kind: "feeds", label: "256 × 7 × 12|per frame" },
      { from: "attn", to: "head", kind: "feeds", label: "flatten|21,504-d" }
    ],
    mask: { name: "Demo → observation", ref: "p1", axes: [{ label: "demo frames", short: "d", mod: "vision" }, { label: "observation frame", short: "o", mod: "action" }], m: ["10", "11"],
      note: "The demo never sees the robot's frames. Each observation frame sees the whole demo and only itself, not other observation frames." },
    callouts: [
      "Paper §IV-A: observation frames attend to the <b>attended</b> demo x_d^attn. In mt_rep.py the demo branch's attention output is never used: demo keys and values come from its un-attended input at every layer.",
      "Paper Table III: contrastive latent 512, action head 256 → 256. The released config and README use a 40-d embedding, action MLP 128 → 64 and a 128-d contrastive projector."
    ]
  });

  /* ------------------------------------------------------------------ ICRT */
  RB.arch.spec({
    id: "icrt", method: "icrt", topic: "b6", name: "ICRT", year: 2024,
    figRef: "Fu et al. Fig. 3 · §IV · App. D–F", prov: "",
    lede: "A small Llama-style causal transformer reads whole teleoperated trajectories as its prompt: one state token and one action token per step. After the prompt it continues the live trajectory, predicting the next 16 actions at every state token.",
    sources: {
      p1: { kind: "paper", ref: "Fu et al. 2024, §IV-B (model) and Fig. 3", url: "https://arxiv.org/abs/2408.15980" },
      p2: { kind: "paper", ref: "Fu et al. 2024, §IV-A (data formulation)", url: "https://arxiv.org/abs/2408.15980" },
      p3: { kind: "paper", ref: "Fu et al. 2024, App. D, Tables IX–X", url: "https://arxiv.org/abs/2408.15980" },
      p4: { kind: "paper", ref: "Fu et al. 2024, App. E–F, Table XI", url: "https://arxiv.org/abs/2408.15980" },
      p5: { kind: "paper", ref: "Dosovitskiy et al. 2021, Table 1 (ViT-Base)", url: "https://arxiv.org/abs/2010.11929" },
      c1: { kind: "code", repo: "Max-Fu/icrt", path: "icrt/models/policy/icrt.py", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/icrt/models/policy/icrt.py" },
      c2: { kind: "code", repo: "Max-Fu/icrt", path: "icrt/models/backbones/encoders.py", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/icrt/models/backbones/encoders.py" },
      c3: { kind: "code", repo: "Max-Fu/icrt", path: "config/model_config/custom_transformer.json", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/config/model_config/custom_transformer.json" },
      c4: { kind: "code", repo: "Max-Fu/icrt", path: "icrt/models/policy/llama.py", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/icrt/models/policy/llama.py" },
      c5: { kind: "code", repo: "Max-Fu/icrt", path: "icrt/util/args.py", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/icrt/util/args.py" },
      c6: { kind: "code", repo: "Max-Fu/icrt", path: "TRAIN.md", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/TRAIN.md" }
    },
    summary: {
      pattern: ["In-context causal transformer (prompt = demo trajectories)", "p1"],
      params: null,
      vision: ["Frozen ViT-Base/16 (CrossMAE on ImageNet + OXE); 197 tokens per camera, 2 cameras", "p1", "c2", "c5"],
      backbone: ["Llama2-style causal transformer from scratch: 12 layers, width 768, 12 heads", "p1", "c3"],
      head: ["2-layer MLP at each state token: 768 → 128 → 16 × 10", "p1", "c1"],
      output: ["Next h = 16 delta end-effector actions, 10-d (xyz, 6-D rotation, gripper)", "p1", "p4"],
      attention: ["Causal over interleaved [s, a] tokens: prompt trajectories first, live one last", "p1", "c1"],
      cond: ["Task given only by the prompt: at least one full demo trajectory, no language", "p2"],
      steps: null,
      chunk: ["16 predicted; 10 executed with temporal ensembling", "p4"],
      rate: ["39.6 Hz inference with KV cache (Llama2-7B variant: 10.7 Hz)", "p4"],
      latency: null,
      train: ["Pretrain on 10k DROID trajectories, fine-tune on ICRT-MT; L1 loss only after the prompt", "p2", "p1", "p3"]
    },
    blueprint: {
      headline: "ICRT: demonstrations are the prompt",
      note: "Per step, attention pooling squeezes each camera's frozen ViT tokens plus the proprio embedding into half a state token; an MLP embeds the action. States and actions interleave into one causal sequence of up to 512 steps: a few prompt trajectories of the same task, then the live one.",
      towers: [
        { mod: "vit", title: "ViT-Base/16", sub: "CrossMAE weights, frozen", compact: true,
          input: { label: "Image patches 16 × 16", caption: "2 cameras, 224 × 224" },
          rows: [
            { t: "embed", label: "Patch embedding + CLS", call: ["196 patches + CLS, width 768", "p5", "c2"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["12 heads, bidirectional", "p5"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden dimension of 3,072", "p5"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "197 tokens per camera" } },
        { mod: "tok", title: "Token projectors", sub: "one state + one action token per step", compact: true,
          input: { label: "Visual tokens + proprio", caption: "per camera, per timestep" },
          rows: [
            { t: "mlp", label: "Proprio MLP", call: ["10-d state → 768", "p4", "c1"] },
            { t: "norm", label: "LayerNorm (visual tokens)" },
            { t: "attn", label: "Attention pooling", call: ["8 heads, 1 query per camera", "c1", "c5"],
              zoom: { k: "rows", title: "Attention pooling (per camera)", rows: ["[197 visual ‖ proprio] → K, V", "learned latent query → Q", "attend, project → 384", "+ MLP (ratio 4), residual"] } },
            { t: "linear", label: "Concat 2 cameras", call: ["2 × 384 = 768 (fₛ)", "c1"] },
            { t: "mlp", label: "Action MLP", call: ["10-d → 768 (fₐ)", "c1"] } ],
          output: { label: "fₛ and fₐ per step" } },
        { mod: "llama", title: "Causal transformer", sub: "Llama2-Base, random init",
          input: { label: "[fₛ₁, fₐ₁, …, fₛₜ]", caption: "prompt trajectories, then the live one" },
          rows: [
            { t: "block", n: "12", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["12 heads × 64; KV cache at test", "c3", "c4"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden dimension of 2,048", "c3", "c4"], zoom: { k: "glu", act: "SiLU", d: "768", ff: "2,048", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "mlp", label: "Action decoder MLP", call: ["768 → 128 → 16 × 10, at state tokens", "c1"] } ],
          output: { label: "next 16 actions; L1 loss after the prompt" } }
      ],
      links: [
        { from: "tok", to: "llama", toRow: "input", label: "state, action tokens" },
        { from: "vit", to: "tok", toRow: "input", label: "visual tokens" }
      ]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "ViT-Base/16", sub: "12 × 768 · CrossMAE", col: 0, frozen: true, short: "ViT-B",
        stack: { rows: [
          { t: "in", label: "image 224 × 224 × 3", dims: "2 cameras per step", c: "data-1" },
          { t: "embed", label: "Patch embed 16 × 16 + CLS", dims: "→ 197 × 768" },
          { t: "block", label: "ViT block", n: "12", rows: [{ t: "attn", label: "MHA · 12 heads" }, { t: "ffn", label: "MLP 768 → 3,072 → 768" }] },
          { t: "out", label: "all 197 tokens (no pooling)", dims: "global_pool = ''", c: "data-1" } ],
          facts: [["Pre-training", ["CrossMAE on ImageNet + Open X-Embodiment", "p1"]], ["Width / depth / heads", ["768 / 12 / 12", "p5"]], ["Training", ["frozen", "p1", "c5"]]] } },
      { id: "tok", role: "state-enc", roleLabel: "Token projectors", name: "Attention pooling", sub: "2 × 384 → 768", col: 1, frozen: false, short: "Pooling",
        stack: { rows: [
          { t: "in", label: "197 visual tokens × 2 cameras + proprio", c: "data-5" },
          { t: "mlp", label: "Proprio MLP 10 → 768" },
          { t: "attn", label: "Latent-query attention pool, one per camera", dims: "8 heads" },
          { t: "mlp", label: "MLP (ratio 4) + residual" },
          { t: "linear", label: "concat cameras → 768" },
          { t: "mlp", label: "Action MLP 10 → 768" },
          { t: "out", label: "state token fₛ, action token fₐ", c: "data-5" } ],
          facts: [["Pooling heads", ["8", "c5"]], ["MLP ratio", ["4", "c5"]], ["Per-camera adapter", ["yes, 768 / 2 = 384 each", "c1", "c5"]], ["Proprio / action", ["10-d each", "p4", "c1"]]] } },
      { id: "llama", role: "net", roleLabel: "Causal policy transformer", name: "Llama2-Base", sub: "12 × 768 · 12 heads", col: 2, frozen: false, main: true, short: "Llama2-Base",
        stack: { rows: [
          { t: "in", label: "fₛ₁ fₐ₁ … fₛₜ", dims: "≤ 512 steps = 1,024 tokens", c: "data-3" },
          { t: "block", label: "Llama block (pre-norm)", n: "12", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "causal MHA · 12 heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 768 → 2,048 → 768" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "mlp", label: "MLP 768 → 128 → 160 at state positions" },
          { t: "out", label: "16 future actions", dims: "temporal ensembling", c: "data-3" } ],
          facts: [["Width / depth / heads", ["768 / 12 / 12", "p1", "c3"]], ["FFN", ["SwiGLU, 2,048 (2/3 · 4d, multiple of 256)", "c3", "c4"]], ["Sequence", ["512 steps", "p3"]], ["Loss", ["L1 on actions after the prompt", "p1"]], ["Variant", ["Llama2-7B with LoRA rank 32", "p1"]]] } }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "2 camera images / step", n: "197 tokens each", k: 4 },
      { to: "tok", mod: "state", label: "proprio sₜ", n: "10-d", k: 1 },
      { to: "tok", mod: "action", label: "past actions", n: "10-d each", k: 2 },
      { to: "llama", mod: "other", label: "prompt: demo trajectories", n: "same task", k: 5 }
    ],
    outputs: [{ from: "llama", mod: "action", label: "next actions", n: "16 × 10", k: 5 }],
    links: [
      { from: "vit", to: "tok", kind: "feeds", label: "197 tokens|per camera" },
      { from: "tok", to: "llama", kind: "prefix", label: "1 state + 1 action|token per step" }
    ],
    mask: { name: "Causal over trajectories", ref: "p1", axes: [{ label: "prompt trajectories", short: "P", mod: "other" }, { label: "live states", short: "s", mod: "state" }, { label: "live actions", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "Plain causal attention over the whole interleaved sequence; the prompt comes first, so every live step can read all of it." },
    callouts: [
      "Paper Table IX lists weight decay <b>0.05</b> for DROID pre-training; args.py defaults to <b>0.01</b> and the pre-training command in TRAIN.md does not override it.",
      "The Llama2-7B variant keeps the same tokenizers and trains with LoRA (rank 32): slightly better on poking, but 10.7 Hz instead of 39.6 Hz."
    ]
  });

  /* ------------------------------------------------------------------ Instant Policy */
  RB.arch.spec({
    id: "instant-policy", method: "instant-policy", topic: "b6", name: "Instant Policy", year: 2024,
    figRef: "Vosylius & Johns Figs. 2–3 · §3 · App. A, C, E", prov: "",
    lede: "Demonstrations, the current observation and noisy future actions become one heterogeneous graph of point-cloud and gripper nodes. Three small graph transformers pass information demo → current → actions; the predicted node flows are turned into SE(3) actions by DDIM steps and SVD.",
    sources: {
      p1: { kind: "paper", ref: "Vosylius & Johns 2025, §3.2 (graph representation) and Fig. 2", url: "https://arxiv.org/abs/2411.12633" },
      p2: { kind: "paper", ref: "Vosylius & Johns 2025, §3.3 (graph diffusion, Eqs. 2–5)", url: "https://arxiv.org/abs/2411.12633" },
      p3: { kind: "paper", ref: "Vosylius & Johns 2025, App. A (geometry encoder)", url: "https://arxiv.org/abs/2411.12633" },
      p4: { kind: "paper", ref: "Vosylius & Johns 2025, App. C (network architecture)", url: "https://arxiv.org/abs/2411.12633" },
      p5: { kind: "paper", ref: "Vosylius & Johns 2025, App. E (implementation details)", url: "https://arxiv.org/abs/2411.12633" },
      p6: { kind: "paper", ref: "Vosylius & Johns 2025, §4.1–4.2, Table 2, Fig. 6", url: "https://arxiv.org/abs/2411.12633" },
      c1: { kind: "code", repo: "vv19/instant_policy", path: "deploy.py", commit: "7228173", url: "https://github.com/vv19/instant_policy/blob/7228173/deploy.py" },
      c2: { kind: "code", repo: "vv19/instant_policy", path: "utils.py", commit: "7228173", url: "https://github.com/vv19/instant_policy/blob/7228173/utils.py" },
      c3: { kind: "code", repo: "vv19/instant_policy", path: "deploy_sim.py", commit: "7228173", url: "https://github.com/vv19/instant_policy/blob/7228173/deploy_sim.py" }
    },
    summary: {
      pattern: ["Graph diffusion policy (heterogeneous graph transformer)", "p2"],
      params: ["69M, 117M and 178M variants in the scaling study", "p6"],
      vision: ["Segmented point clouds, 2,048 points in the gripper frame → 16 nodes (frozen SA encoder, 512-d)", "p3", "p5", "c2"],
      backbone: ["Three graph transformers σ → φ → ψ, 2 layers each, width 1,024, 16 heads × 64", "p4"],
      head: ["2-layer GELU MLP on each action gripper node → 7-d", "p2", "p4"],
      output: ["Per-node flow (translation part + rotation part) and gripper; SVD → SE(3)", "p2"],
      attention: ["Graph attention along typed edges only (Eq. 3); cost linear in N and L", "p2"],
      cond: ["Context: N demos × L waypoints as local graphs, linked to the current gripper nodes", "p1"],
      steps: ["DDIM; 4 denoising steps in the released deployment scripts", "p6", "c1"],
      chunk: ["T = 8 future actions", "p6", "c3"],
      rate: null, latency: null,
      train: ["2.5M steps on procedurally generated ShapeNet pseudo-demos; AdamW 1e-5", "p5", "p6"]
    },
    blueprint: {
      headline: "Instant Policy: denoise a graph of actions",
      note: "Scene nodes come from a frozen point-cloud encoder; six gripper nodes mark the end-effector. σ updates each local graph, φ moves demo information into the current gripper nodes, ψ moves it to the gripper nodes of the imagined future poses. An MLP reads their flow, and SVD turns it into poses.",
      towers: [
        { mod: "geo", title: "Geometry encoder φₑ", sub: "occupancy-pretrained, frozen", compact: true,
          input: { label: "Segmented point cloud", caption: "2,048 points, gripper frame" },
          rows: [
            { t: "pool", label: "Furthest point sampling", call: ["M = 16 centroids", "p5"] },
            { t: "block", n: "2", label: "Set Abstraction", rows: [
              { t: "conv", label: "SA layer (PointNet++)", call: ["offsets as sin/cos(2ᵈπ Δp), d = 0 … 9", "p3"] } ] },
            { t: "linear", label: "Local geometry features", call: ["512-d per centroid", "p3"],
              zoom: { k: "rows", title: "Occupancy pre-training", rows: ["points near one centroid", "2 SA layers → 512-d code", "decoder: 8-layer res. MLP", "query → on surface? (dropped)"] } } ],
          output: { label: "16 scene nodes {Fᵢ, pᵢ}" } },
        { mod: "gnn", title: "Graph diffusion network", sub: "heterogeneous graph transformers",
          input: { label: "Graph Gᵏ", caption: "demos · current · noisy future actions" },
          rows: [
            { t: "embed", label: "Scene + gripper nodes", call: ["16 scene + 6 gripper nodes", "p1", "p5"] },
            { t: "linear", label: "Edge encoding", call: ["sin/cos of Δp", "p1"],
              zoom: { k: "rows", title: "Graph attention (Eq. 3)", rows: ["kᵢⱼ = W₄Fⱼ + W₅eᵢⱼ", "attᵢⱼ = softmax(W₃Fᵢ · kᵢⱼ / √d)", "vᵢⱼ = W₂Fⱼ + W₅eᵢⱼ", "Fᵢ′ = W₁Fᵢ + Σⱼ attᵢⱼ vᵢⱼ", "own W per node / edge type"] } },
            { t: "block", n: "2", label: "σ: local graphs", rows: [
              { t: "attn", label: "Graph attention", call: ["width 1,024, 16 heads × 64", "p4"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Graph-attention heads" } },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "block", n: "2", label: "φ: demos to current", rows: [
              { t: "attn", label: "Graph attention, context", call: ["demo gripper nodes → current ones", "p1", "p4"] },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "block", n: "2", label: "ψ: current to actions", rows: [
              { t: "attn", label: "Graph attention, actions", call: ["current gripper → future gripper nodes", "p1", "p4"] },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "mlp", label: "2-layer MLP (GELU)", call: ["ε ∈ ℝ⁷ per action gripper node", "p2", "p4"] } ],
          output: { label: "per-node flow for T future poses" } },
        { mod: "svd", title: "Pose solver", sub: "no weights", compact: true,
          input: { label: "Node flows", caption: "∇p̂ = ∇p̂ₜ + ∇p̂ᵣ, gripper" },
          rows: [
            { t: "linear", label: "p̂⁰ = pᵏ + Δpₜ + Δpᵣ" },
            { t: "linear", label: "DDIM step (Eq. 4)" },
            { t: "linear", label: "SVD fit Tₖ₋₁,ₖ (Eq. 5)" },
            { t: "linear", label: "Apply to aᵏ, repeat K ×", call: ["K = 4 in the scripts", "c1", "c3"] } ],
          output: { label: "T = 8 actions: SE(3) + gripper" } }
      ],
      links: [
        { from: "gnn", to: "svd", toRow: "input", label: "per-node ε" },
        { from: "geo", to: "gnn", toRow: "input", label: "scene nodes" }
      ]
    },
    modules: [
      { id: "geo", role: "vision-enc", roleLabel: "Point-cloud encoder", name: "Geometry encoder", sub: "2 SA layers · 512-d", col: 0, frozen: true, short: "SA encoder",
        stack: { rows: [
          { t: "in", label: "segmented point cloud", dims: "2,048 points, end-effector frame", c: "data-1" },
          { t: "pool", label: "furthest point sampling → M centroids" },
          { t: "conv", label: "2 × Set Abstraction, NeRF-style offsets" },
          { t: "out", label: "scene nodes {Fᵢ, pᵢ}", dims: "M = 16, 512-d", c: "data-1" } ],
          facts: [["Pre-training", ["occupancy network on ShapeNet; decoder dropped", "p3"]], ["Nodes", ["M = 16", "p5"]], ["Feature size", ["512", "p3"]], ["Points", ["2,048 after 1 cm voxel downsampling", "p5", "c2"]]] } },
      { id: "gnn", role: "net", roleLabel: "Graph diffusion network", name: "σ → φ → ψ", sub: "3 × 2 layers · width 1,024", col: 1, frozen: false, main: true, short: "Graph transformer",
        stack: { rows: [
          { t: "in", label: "graph: demos, current, noisy actions", dims: "local graphs of 16 + 6 nodes", c: "data-3" },
          { t: "block", label: "σ on every local graph", n: "2", rows: [{ t: "attn", label: "graph attention · LayerNorm · residual" }] },
          { t: "block", label: "φ: context graph", n: "2", rows: [{ t: "attn", label: "demo gripper → current gripper nodes" }] },
          { t: "block", label: "ψ: action graph", n: "2", rows: [{ t: "attn", label: "current → future gripper nodes" }] },
          { t: "mlp", label: "2-layer MLP, GELU" },
          { t: "out", label: "ε per action gripper node", dims: "7-d", c: "data-3" } ],
          facts: [["Layers", ["2 per network, 3 networks", "p4"]], ["Width / heads", ["1,024 / 16 × 64", "p4"]], ["Edge features", ["sin/cos of relative positions", "p1"]], ["Context", ["N = 2 demos, L = 10 waypoints", "p6"]], ["Parameters", ["69M, 117M, 178M variants", "p6"]]] } },
      { id: "svd", role: "codec", roleLabel: "Pose solver (no weights)", name: "DDIM + SVD", sub: "node flows → SE(3)", col: 2, frozen: true, short: "SVD",
        note: "Not a network: it turns predicted node displacements into rigid transforms and rebuilds the graph for the next step." }
    ],
    inputs: [
      { to: "geo", mod: "vision", label: "segmented point cloud", n: "2,048 points", k: 4 },
      { to: "gnn", mod: "other", label: "N × L demos", n: "2 × 10", k: 5 },
      { to: "gnn", mod: "state", label: "gripper", n: "6 nodes", k: 2 },
      { to: "gnn", mod: "action", label: "noisy actions", n: "T = 8", k: 4, noisy: true }
    ],
    outputs: [{ from: "svd", mod: "action", label: "end-effector actions", n: "8 × (SE(3), grip)", k: 4 }],
    links: [
      { from: "geo", to: "gnn", kind: "feeds", label: "16 nodes / graph|512-d features" },
      { from: "gnn", to: "svd", kind: "feeds", label: "per-node flow|K denoising steps" }
    ],
    callouts: [
      "The official repository ships the model only as a compiled module (instant_policy.so); layer sizes here come from App. C, and runtime settings (4 steps, 2 demos, 10 waypoints) from deploy.py.",
      "No attention between arbitrary token pairs: information moves only along typed graph edges, so memory grows linearly with the number and length of demonstrations."
    ]
  });

  /* ------------------------------------------------------------------ RICL */
  RB.arch.spec({
    id: "ricl", method: "ricl", topic: "b6", name: "RICL-π0-FAST", year: 2025, parent: "fast",
    diffRows: ["vision", "attention", "cond", "head", "output", "chunk", "latency", "train"],
    figRef: "Sridhar et al. Fig. 2 · §4 · App. C", prov: "ricl_openpi pi0_fast_ricl",
    lede: "π0-FAST-DROID, re-trained to read its own context. DINOv2 retrieves the four nearest demo states; their images, state and action chunk precede the query in one sequence, and the output tokens are blended with the nearest neighbour's.",
    sources: {
      p1: { kind: "paper", ref: "Sridhar et al. 2025, §4, Eq. 1 and Fig. 2", url: "https://arxiv.org/abs/2508.02062" },
      p2: { kind: "paper", ref: "Sridhar et al. 2025, App. C (setup and hyperparameters)", url: "https://arxiv.org/abs/2508.02062" },
      p3: { kind: "paper", ref: "Sridhar et al. 2025, §5 (priming data)", url: "https://arxiv.org/abs/2508.02062" },
      p4: { kind: "paper", ref: "Sridhar et al. 2025, App. C (runtime discussion)", url: "https://arxiv.org/abs/2508.02062" },
      c1: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/models/pi0_fast_ricl.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/models/pi0_fast_ricl.py" },
      c2: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/training/config.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/training/config.py" },
      c3: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/policies/policy.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/policies/policy.py" },
      c4: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/policies/utils.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/policies/utils.py" },
      c5: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/models/gemma_fast.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/models/gemma_fast.py" },
      c6: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/models/siglip.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/models/siglip.py" }
    },
    summary: {
      pattern: ["Autoregressive token VLA + retrieval-augmented context", "p1"],
      params: ["π0-FAST-DROID weights (PaliGemma 3B); SigLIP frozen, Gemma fully fine-tuned", "p1", "p2"],
      vision: ["SigLIP So400m/14, frozen: 3 images per block (top, side, wrist) at 224 × 224 → 256 tokens each", "p1", "p2", "c1"],
      backbone: ["Gemma 2B: 18 layers, width 2,048, 8 query / 1 KV heads", "c5"],
      head: ["LM head, then a weight-free interpolation with the nearest neighbour's tokens", "p1", "c1"],
      output: ["FAST tokens → chunk of 15 × 8 (7 joint velocities + gripper)", "p2", "c2"],
      attention: ["Prefix-LM inside each block; blocks causal left to right, nearest first, query last", "c1"],
      cond: ["4 retrieved [images, prompt, state, action chunk] groups before the query", "p2", "c2"],
      steps: ["Autoregressive FAST tokens, greedy, KV-cached context", "c1"],
      chunk: ["15 actions at 15 Hz; execute 3 (8 once a grip is predicted)", "p2"],
      rate: ["15 Hz control", "p2"],
      latency: ["≈ 1.33× π0-FAST's rollout time; retrieval under 1 ms (FAISS)", "p4"],
      train: ["400 priming demos (20 tasks × 20), 3 epochs, batch 16, peak LR 2.5e-5", "p2", "p3"]
    },
    changes: [
      "A <b>retrieval step</b> runs first: DINOv2 embeds the top camera image and FAISS finds the 4 nearest demo states.",
      "The context grows to <b>5 blocks</b>: 4 retrieved [images, prompt, state, action chunk] groups, then the query.",
      "New <b>action interpolation</b> layer: e^(−λd)·one-hot(a′) + (1 − e^(−λd))·softmax(logits), per output token.",
      "<b>SigLIP is frozen</b>; Gemma is fully fine-tuned, with loss only on the query's tokens.",
      "A new task needs no gradient step: swap in 10–20 demos as the retrieval buffer."
    ],
    blueprint: {
      headline: "RICL: retrieve, read, then blend",
      note: "Five observation blocks share one Gemma sequence: four retrieved neighbours (with their action chunks) and the query. Gemma decodes FAST tokens for the query; each token distribution is mixed with the nearest neighbour's token, weighted by how close the query image is to it in DINOv2 space.",
      towers: [
        { mod: "siglip", title: "SigLIP So400m/14", sub: "frozen during RICL", compact: true,
          input: { label: "3 images per block", caption: "top, side, wrist · 224 × 224" },
          rows: [
            { t: "embed", label: "Patch embedding layer", call: ["256 patches per image, width 1,152", "c1", "c6"] },
            { t: "block", n: "27", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention" },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Linear projection", call: ["1,152 → 2,048, no pooling", "c1"] } ],
          output: { label: "768 image tokens per block" } },
        { mod: "gemma", title: "Gemma 2B", sub: "π0-FAST-DROID LM, fully fine-tuned",
          input: { label: "[ret 1] … [ret 4] [query]", caption: "nearest neighbour first, query last" },
          rows: [
            { t: "embed", label: "Token embedding layer", call: ["Vocabulary of 257,152 · width 2,048", "c5"],
              zoom: { k: "rows", title: "Context layout", rows: ["ret 1: images · prompt · state · a′", "ret 2–4: same, farther away", "query: images · prompt · state", "“Action:” FAST tokens (loss here)"] } },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Block-causal MQA", side: "RoPE", call: ["8 query heads share 1 KV head (dim 256)", "c5"], zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Hidden dimension of 16,384", "c5"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head → softmax", call: ["distribution over 257,152 tokens", "c5"] },
            { t: "group", label: "Action interpolation (no weights)", rows: [
              { id: "mix", t: "linear", label: "Mix with one-hot(a′)", call: ["weight e^(−λd), λ = 10", "p1", "p2"], callDy: -24,
                zoom: { k: "rows", title: "Interpolation (Eq. 1)", rows: ["w = e^(−λd)", "p = w · one-hot(a′) + (1 − w) · σ(z)", "d → 0: copy the neighbour", "d large: trust the VLA"] } },
              { t: "linear", label: "Greedy token → append" } ] },
            { t: "embed", label: "FAST decode", call: ["→ 15 × 8 chunk; execute 3", "p2", "c2"] } ],
          output: { label: "action chunk" } },
        { mod: "dino", title: "DINOv2 ViT-B/14", sub: "retrieval only, frozen", compact: true,
          input: { label: "Top camera image", caption: "query and every demo frame" },
          rows: [
            { t: "attn", label: "ViT-B/14 encoder", call: ["256 patch tokens × 768", "c4"] },
            { t: "pool", label: "Mean of 8 × 8 patch groups", call: ["64 × 768 = 49,152-d key", "c4"] },
            { t: "linear", label: "FAISS L2 k-NN", call: ["top 4 of the task demos", "p2", "c3"] } ],
          output: { label: "4 neighbours + distance d" } }
      ],
      links: [
        { from: "siglip", to: "gemma", toRow: "input", label: "image tokens" },
        { from: "dino", to: "gemma", toRow: "mix", label: "distance d" }
      ]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "27 × 1152 · 16 heads", col: 0, frozen: true, short: "SigLIP",
        stack: { rows: [
          { t: "in", label: "3 images × 5 blocks", dims: "224 × 224, resized with padding", c: "data-1" },
          { t: "embed", label: "Patch embed 14 × 14", dims: "→ 256 × 1152" },
          { t: "block", label: "ViT block", n: "27", rows: [{ t: "attn", label: "MHA" }, { t: "ffn", label: "MLP" }] },
          { t: "linear", label: "Linear head (pool = none)", dims: "1152 → 2048" },
          { t: "out", label: "256 tokens per image", c: "data-1" } ],
          facts: [["Training", ["frozen (freeze filter on .*img.*)", "p1", "c1"]], ["Images per block", ["3: top, side, wrist", "p1"]], ["Resolution", ["224 × 224", "p2"]]] } },
      { id: "gemma", role: "vlm", name: "Gemma 2B (π0-FAST-DROID)", sub: "18 × 2048 · MQA", col: 1, frozen: false, main: true, short: "Gemma 2B",
        stack: { rows: [
          { t: "in", label: "[ret₁ | ret₂ | ret₃ | ret₄ | query]", dims: "each: images, prompt, state (+ a′ for ret)", c: "data-2" },
          { t: "embed", label: "Token embedding", dims: "vocab 257,152 → 2048" },
          { t: "block", label: "Gemma decoder block", n: "18", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MQA · 8 query, 1 KV · RoPE · block-causal" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 2048 → 16,384 → 2048" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "LM head → softmax", dims: "cross-entropy on the query's postfix only" },
          { t: "linear", label: "p = w · one-hot(a′) + (1 − w) · p", dims: "w = e^(−λd), per output token" },
          { t: "embed", label: "FAST decode", dims: "→ continuous chunk" },
          { t: "out", label: "action chunk 15 × 8", c: "data-3" } ],
          facts: [["Width / depth", ["2,048 / 18", "c5"]], ["Heads", ["8 query, 1 KV, head dim 256", "c5"]], ["Text tokens per block", ["≤ 250", "c2"]], ["Retrieved blocks", ["4", "p2", "c2"]], ["Fine-tuning", ["full LLM, LR 2.5e-5 cosine, 300 warm-up steps", "p2", "c2"]]] } },
      { id: "dino", role: "vision-enc", roleLabel: "Retrieval encoder", name: "DINOv2 ViT-B/14", sub: "49,152-d key · FAISS", col: 2, frozen: true, short: "DINOv2",
        note: "Used only to pick neighbours and to compute the distance d; its features never enter Gemma." }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "3 images × 5 blocks", n: "256 tokens each", k: 5 },
      { to: "gemma", mod: "lang", label: "prompt, state", n: "as text", k: 3 },
      { to: "gemma", mod: "action", label: "neighbour a′", n: "FAST", k: 4 },
      { to: "dino", mod: "vision", label: "query top image", n: "1 key", k: 1 }
    ],
    outputs: [{ from: "gemma", mod: "action", label: "action chunk", n: "15 × 8", k: 5 }],
    links: [
      { from: "siglip", to: "gemma", kind: "prefix", label: "linear → 2048|256 tokens / image" },
      { from: "dino", to: "gemma", kind: "feeds", label: "4 neighbours|and distance d" }
    ],
    mask: { name: "Block-causal context", ref: "c1", axes: [{ label: "retrieved blocks", short: "ret", mod: "other" }, { label: "query prefix", short: "q", mod: "vision" }, { label: "query actions", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "Code: each block is prefix-LM inside, OR-ed with a global lower-triangular mask, so every block reads all earlier ones; the query's action tokens are causal." },
    callouts: [
      "Paper Eq. 1 uses d, the raw ℓ2 distance between DINO embeddings. policy.py first <b>clips d to a stored maximum and divides by it</b>, so λ = 10 acts on a distance in [0, 1].",
      "The paper names only “DINO-v2”; the code uses ViT-B/14 and keeps 64 patch-group means (49,152-d) rather than the CLS token as the retrieval key."
    ]
  });
})();
