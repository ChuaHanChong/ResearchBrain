/* Architecture specs for grasp-lineage nodes (topic E1): Redmon & Angelova, Grasp-Anything's trained baseline, DexDiffuser.
   Numbers from the papers and the official code; see sources. DexGraspNet has no network (optimisation + simulation filter). */
(function () {
  var RB = window.RB;

  /* ---------------- Real-time grasp detection (Redmon & Angelova 2015) ---------------- */
  RB.arch.spec({
    id: "real-time-grasp-detection", method: "real-time-grasp-detection", name: "Redmon & Angelova grasp CNN", year: 2015,
    figRef: "Redmon & Angelova Fig. 3 · §IV · §V-C–E", prov: "direct-regression model; MultiGrasp and classification heads noted",
    lede: "An ImageNet-pretrained AlexNet-style CNN looks at the whole RGB-D image once and regresses one oriented grasp rectangle. MultiGrasp swaps the 6-number head for a 7 × 7 grid that predicts a grasp and a confidence per cell.",
    sources: {
      p1: { kind: "paper", ref: "Redmon & Angelova 2015, §IV-A–D (architecture, heads) and Fig. 3", url: "https://arxiv.org/abs/1412.3128" },
      p2: { kind: "paper", ref: "Redmon & Angelova 2015, §V-B–E (classes, pretraining, training, preprocessing)", url: "https://arxiv.org/abs/1412.3128" },
      p3: { kind: "paper", ref: "Redmon & Angelova 2015, §VI, Tables I–II (accuracy, timing)", url: "https://arxiv.org/abs/1412.3128" }
    },
    summary: {
      pattern: ["Grasp CNN (global regression)", "p1"],
      params: null,
      vision: ["RGB-D 224 × 224 × 3: depth replaces the blue channel", "p1", "p2"],
      backbone: ["AlexNet-derived: 5 convs (64, 128, 128, 128, 256 filters) + 3 FC", "p1"],
      head: ["FC 512 → FC 512 → 6 outputs (x, y, sin 2θ, cos 2θ, h, w)", "p1"],
      output: ["One grasp rectangle g = {x, y, θ, h, w}; MultiGrasp: 7 × 7 × 7 grid", "p1"],
      attention: "None (convolutions only)",
      cond: null,
      steps: "One forward pass over the full image",
      chunk: null,
      rate: ["13 frames per second (reported per batch)", "p3"],
      latency: ["76 ms per batch of 128 images on a Tesla K20", "p3"],
      train: ["Cornell: 885 images, 3,000 augmented crops each; 25 epochs, lr 0.0005", "p2"]
    },
    blueprint: {
      headline: "Redmon & Angelova: grasp detection as regression",
      note: "Five convolutions shrink the image from 224 to 7 pixels a side; three fully connected layers read the whole 7 × 7 × 256 map, so every output sees global context. The three variants share the trunk and differ only in the last layer.",
      towers: [
        { mod: "cnn", title: "Conv trunk", sub: "AlexNet-derived, ImageNet-pretrained",
          input: { label: "RGB-D image 224 × 224", caption: "depth in the blue channel" },
          rows: [
            { id: "c1", t: "conv", label: "Conv 5 × 5 /2 · max-pool /2", call: ["64 ch → 56 × 56", "p1"],
              zoom: { k: "rows", title: "RGB-D into three channels", rows: ["R and G from camera", "depth scaled 0–255", "depth into blue", "no depth → 0", "− 144; 320 → 224"] } },
            { t: "conv", label: "Conv 3 × 3 /2 · max-pool /2", call: ["128 ch → 14 × 14", "p1"] },
            { t: "conv", label: "Conv 3 × 3", call: ["128 ch, 14 × 14", "p1"] },
            { t: "conv", label: "Conv 3 × 3", call: ["128 ch, 14 × 14", "p1"] },
            { t: "conv", label: "Conv 3 × 3 · max-pool /2", call: ["256 ch → 7 × 7", "p1"] } ],
          output: { label: "7 × 7 × 256 map" } },
        { mod: "head", title: "Regression head", sub: "fully connected", compact: true,
          input: { label: "flattened map", caption: "whole image at once" },
          rows: [
            { t: "mlp", label: "FC · dropout", call: ["512 units", "p1"] },
            { t: "mlp", label: "FC · dropout", call: ["512; dropout 0.5", "p1", "p2"] },
            { id: "head", t: "linear", label: "Output layer", call: ["6: x, y, sin 2θ, cos 2θ, h, w", "p1"],
              zoom: { k: "rows", title: "Three heads, one trunk", rows: ["regression: 6", "+ 16 classes: 22", "MultiGrasp: 7 × 7 × 7", "cell ch. 1: heatmap", "ch. 2–7: cell grasp"] } } ],
          output: { label: "grasp g = {x, y, θ, h, w}" } }
      ],
      links: [{ from: "cnn", to: "head", toRow: "input", label: "7 × 7 × 256" }]
    },
    modules: [
      { id: "cnn", role: "vision-enc", roleLabel: "Conv trunk", name: "AlexNet-style trunk", sub: "5 conv · 224² → 7²", col: 0, frozen: false, short: "Conv trunk",
        note: "Pretrained on ImageNet, then fine-tuned on grasps.",
        stack: { rows: [
          { t: "in", label: "RGB-D image, depth in blue", dims: "224 × 224 × 3", c: "data-1" },
          { t: "conv", label: "Conv 5×5 /2 + pool · Conv 3×3 /2 + pool", dims: "64 → 128 filters, 224 → 14" },
          { t: "conv", label: "Conv 3×3 · Conv 3×3 · Conv 3×3 + pool", dims: "128 → 128 → 256 filters, 14 → 7" },
          { t: "out", label: "feature map", dims: "7 × 7 × 256", c: "data-1" } ],
          facts: [["Input", ["224 × 224 × 3, depth in the blue channel", "p1", "p2"]], ["Conv filters", ["64, 128, 128, 128, 256", "p1"]], ["Strides", ["2 on conv 1–2; max-pools after conv 1, 2, 5", "p1"]], ["Pretraining", ["ImageNet classification", "p2"]], ["Preprocessing", ["depth 0–255, mean 144 subtracted", "p2"]]] } },
      { id: "head", role: "action-head", roleLabel: "Grasp regression head", name: "FC head", sub: "512 · 512 · 6 outputs", col: 1, frozen: false, main: true, short: "FC head",
        stack: { rows: [
          { t: "in", label: "flattened feature map", dims: "7 × 7 × 256", c: "data-1" },
          { t: "mlp", label: "FC 512 → FC 512 (dropout 0.5)" },
          { t: "linear", label: "output layer", dims: "6 (regression) · 343 (MultiGrasp)" },
          { t: "out", label: "grasp rectangle", dims: "{x, y, θ, h, w}", c: "data-3" } ],
          facts: [["FC layers", ["512, 512, then the output layer", "p1"]], ["Angle encoding", ["sin 2θ and cos 2θ (two-fold symmetry)", "p1"]], ["Loss", ["squared error to one random ground-truth grasp", "p1"]], ["Classification", ["16 extra class outputs", "p1", "p2"]], ["Training", ["25 epochs, lr 0.0005, weight decay 0.001", "p2"]], ["Cornell accuracy", ["84.4 % IW (regression); 88.0 % IW, 87.1 % OW (MultiGrasp)", "p3"]]] } }
    ],
    inputs: [{ to: "cnn", mod: "vision", label: "RGB-D image", n: "224 × 224 × 3", k: 4 }],
    outputs: [{ from: "head", mod: "action", label: "grasp rectangle", n: "6 numbers", k: 2 }],
    links: [{ from: "cnn", to: "head", kind: "feeds", label: "7 × 7 × 256|flattened" }],
    callouts: [
      "No official code was released (the model ran in a customised <b>cuda-convnet2</b>); layer sizes come from Fig. 3 of the paper, which lists no parameter count.",
      "Direct regression learns the <b>average</b> of an object's valid grasps and fails on round objects; MultiGrasp's per-cell predictions avoid this (§VI).",
      "Dropping depth into the blue channel keeps the ImageNet weights usable for all three input channels (§V-C)."
    ]
  });

  /* ---------------- Grasp-Anything: its data engine and the GR-ConvNet it trains ---------------- */
  RB.arch.spec({
    id: "grasp-anything", method: "grasp-anything", name: "Grasp-Anything (GR-ConvNet baseline)", year: 2023, parent: "gr-convnet",
    diffRows: ["vision", "train", "params"],
    figRef: "Vuong et al. Fig. 2 · §III · §IV-A–B", prov: "grconvnet3, RGB only (--use-depth 0)",
    lede: "A dataset paper. Frozen foundation models write, render, segment and label 1M synthetic scenes; the model it trains is an unchanged GR-ConvNet fed RGB only, which then transfers to a real KUKA arm.",
    sources: {
      p1: { kind: "paper", ref: "Vuong et al. 2023, §III-A–B (scene generation, grasp annotation) and Fig. 2", url: "https://arxiv.org/abs/2309.09818" },
      p2: { kind: "paper", ref: "Vuong et al. 2023, §IV-A, Tables II–III (training setup, zero-shot and cross-dataset results)", url: "https://arxiv.org/abs/2309.09818" },
      p3: { kind: "paper", ref: "Vuong et al. 2023, §IV-B, Table V and Fig. 7 (robot evaluation)", url: "https://arxiv.org/abs/2309.09818" },
      p4: { kind: "paper", ref: "Kumra et al. 2020, §IV-C (GR-ConvNet parameter count)", url: "https://arxiv.org/abs/1909.04810" },
      c1: { kind: "code", repo: "andvg3/Grasp-Anything", path: "train_network.py", commit: "d7755f4", url: "https://github.com/andvg3/Grasp-Anything/blob/d7755f4/train_network.py" },
      c2: { kind: "code", repo: "andvg3/Grasp-Anything", path: "utils/data/grasp_anything_data.py", commit: "d7755f4", url: "https://github.com/andvg3/Grasp-Anything/blob/d7755f4/utils/data/grasp_anything_data.py" },
      c3: { kind: "code", repo: "andvg3/Grasp-Anything", path: "inference/models/grconvnet3.py", commit: "d7755f4", url: "https://github.com/andvg3/Grasp-Anything/blob/d7755f4/inference/models/grconvnet3.py" },
      c4: { kind: "code", repo: "andvg3/Grasp-Anything", path: "README.md", commit: "d7755f4", url: "https://github.com/andvg3/Grasp-Anything/blob/d7755f4/README.md" }
    },
    summary: {
      pattern: ["Grasp CNN (per-pixel)", "p2"],
      params: ["1,900,900 in the RGB-D GR-ConvNet paper; not restated here", "p4"],
      vision: ["RGB only: 416 × 416 synthetic images resized to 224 × 224", "c2", "c4", "c1"],
      backbone: ["GR-ConvNet (grconvnet3) unchanged: 3 convs → 5 residual blocks → 3 transposed convs", "c3"],
      head: ["Four 2 × 2 conv heads: Q, cos 2Θ, sin 2Θ, W", "c3"],
      output: ["Grasp map per pixel → rectangle; success = IoU > 0.25 and angle < 30°", "p2"],
      attention: "None (convolutions only)",
      cond: null,
      steps: "One forward pass",
      chunk: null, rate: null, latency: null,
      train: ["1M Grasp-Anything images, positive grasps only; batch 8, 50 epochs × 1,000 batches", "p1", "c1", "c2"]
    },
    changes: [
      "The network is <b>unchanged</b>: the same grconvnet3 code, copied from Kumra et al.",
      "Input drops depth: training uses <b>RGB only</b>, because Stable Diffusion images have no depth.",
      "Training data becomes 1M synthetic scenes labelled by frozen foundation models instead of Cornell or Jacquard.",
      "Evaluation adds base-to-new (70 % / 30 % LVIS labels) and cross-dataset splits.",
      "On the robot, depth from a RealSense turns the 2-D grasp into a 6-DoF pose."
    ],
    blueprint: {
      headline: "Grasp-Anything: foundation models label, GR-ConvNet learns",
      note: "The left tower is a pipeline of frozen models that runs once, offline, to build the dataset. Its output trains the right tower from scratch. Only GR-ConvNet is trained; none of the foundation models run at test time.",
      towers: [
        { mod: "engine", title: "Data engine (frozen)", sub: "runs offline, once", compact: true,
          input: { label: "ChatGPT scene text", caption: "prompt buffer, self-reinforcing loop" },
          rows: [
            { t: "embed", label: "Stable Diffusion 2.1", call: ["1 image per scene", "p1"] },
            { t: "conv", label: "OFA grounding + SAM masks", call: ["mask per object", "p1"] },
            { t: "conv", label: "RAGT-3/3 grasp proposals", call: ["3/3 variant, pretrained", "p1"] },
            { id: "filt", t: "norm", label: "Torque-ratio filter", call: ["keep T̃ > 0", "p1"],
              zoom: { k: "rows", title: "Grasp quality on the mask", rows: ["convex hull of the mask", "grasp line hits 2 contacts", "angles α₁, α₂ at contacts", "R: centre to centroid", "T̃ = (cos α₁ + cos α₂) / R"] } } ],
          output: { label: "1M images, ~600M grasps" } },
        { mod: "grconv", title: "GR-ConvNet (trained)", sub: "grconvnet3, 3 input channels",
          input: { label: "RGB 224 × 224 × 3", caption: "416 × 416 image, resized; no depth" },
          rows: [
            { t: "conv", label: "Conv 9 × 9 · BN · ReLU", call: ["32 channels (base size)", "c3", "c1"] },
            { t: "conv", label: "2 × Conv 4 × 4 /2 · BN", call: ["64 → 128 channels, 224 → 56", "c3"] },
            { t: "block", n: "5", rows: [
              { t: "conv", label: "Conv 3 × 3 · BN · ReLU" },
              { t: "conv", label: "Conv 3 × 3 · BN", call: ["128 channels at 56 × 56", "c3"] },
              { t: "add", span: 2 } ] },
            { t: "conv", label: "ConvT ×2 · ConvT 9 × 9", call: ["back to 224 × 224, 32 channels", "c3"] },
            { id: "heads", t: "conv", label: "4 heads: Conv 2 × 2 each", call: ["Q, cos 2Θ, sin 2Θ, W; dropout 0.1", "c3", "c1"],
              zoom: { k: "rows", title: "From map to robot grasp", rows: ["best pixel of Q", "Θ, W at that pixel", "rectangle in the image", "RealSense depth at the centre", "6-DoF pose → trajectory planner"] } } ],
          output: { label: "Q, Θ, W maps → grasp rectangle" } }
      ],
      links: [{ from: "engine", to: "grconv", toRow: "input", label: "1M labelled images" }]
    },
    modules: [
      { id: "engine", role: "net", roleLabel: "Data engine (frozen)", name: "Foundation-model data engine", sub: "ChatGPT · SD 2.1 · SAM", col: 0, frozen: true, short: "Data engine",
        note: "Runs once to build the dataset; not part of the deployed model.",
        stack: { rows: [
          { t: "in", label: "ChatGPT scene descriptions", dims: "1M sentences + object lists", c: "data-2" },
          { t: "embed", label: "Stable Diffusion 2.1 → image" },
          { t: "conv", label: "OFA grounding + Segment Anything → masks" },
          { t: "conv", label: "RAGT-3/3 → candidate rectangles" },
          { t: "norm", label: "torque-ratio T̃ on the mask's convex hull" },
          { t: "out", label: "labelled images", dims: "positive and negative grasps", c: "data-1" } ],
          facts: [["Samples", ["1M images", "p1"]], ["Prompt buffer", ["first 50 manual; 10–15 sampled per query", "p1"]], ["Text-to-image", ["Stable Diffusion 2.1", "p1"]], ["Masks", ["OFA + Segment Anything", "p1"]], ["Grasp proposer", ["pretrained RAGT-3/3", "p1"]], ["Positive grasp", ["T̃ > 0", "p1"]]] } },
      { id: "grconv", role: "net", roleLabel: "Grasp CNN", name: "GR-ConvNet", sub: "RGB · 5 res blocks", col: 1, frozen: false, main: true, short: "GR-ConvNet",
        stack: { rows: [
          { t: "in", label: "RGB image", dims: "224 × 224 × 3", c: "data-1" },
          { t: "conv", label: "Conv 9×9 · Conv 4×4 /2 · Conv 4×4 /2 (BN, ReLU)", dims: "32 → 64 → 128 ch, 224 → 56" },
          { t: "block", label: "Residual block", n: "5", rows: [
            { t: "conv", label: "Conv 3×3 → BN → ReLU → Conv 3×3 → BN" }, { t: "add", span: 1 } ] },
          { t: "conv", label: "ConvT 4×4 ×2 · ConvT 4×4 ×2 · ConvT 9×9", dims: "128 → 64 → 32 → 32 ch, 56 → 224" },
          { t: "conv", label: "Four Conv 2×2 heads", dims: "Q, cos 2Θ, sin 2Θ, W" },
          { t: "out", label: "grasp map", dims: "224 × 224 × 4", c: "data-3" } ],
          facts: [["Network file", ["identical to Kumra et al.'s grconvnet3", "c3"]], ["Input", ["RGB, --use-depth 0", "c4"]], ["Input size", ["224 (from 416 × 416 images)", "c1", "c2"]], ["Training", ["Adam, batch 8, 50 epochs × 1,000 batches", "c1"]], ["Zero-shot H", ["0.67 on Grasp-Anything base-to-new", "p2"]], ["Real robot", ["93.3 % single object, 91.6 % clutter", "p3"]]] } }
    ],
    inputs: [
      { to: "engine", mod: "lang", label: "scene descriptions", n: "1M", k: 3 },
      { to: "grconv", mod: "vision", label: "RGB image", n: "224 × 224 × 3", k: 4 }
    ],
    outputs: [{ from: "grconv", mod: "action", label: "Q, Θ, W maps → grasp", n: "per pixel", k: 4 }],
    links: [{ from: "engine", to: "grconv", kind: "two-stage", label: "1M labelled images|trains from scratch" }],
    callouts: [
      "Grasp-Anything proposes <b>no new network</b>. It also trains GG-CNN and Det-Seg-Refine; GR-ConvNet is the default and the one run on the robot (§IV-B).",
      "The released training command sets <b>--use-depth 0</b>: the synthetic images have no depth channel, so the 4-channel RGB-D GR-ConvNet becomes a 3-channel RGB one."
    ]
  });

  /* ---------------- DexDiffuser ---------------- */
  RB.arch.spec({
    id: "dexdiffuser", method: "dexdiffuser", name: "DexDiffuser", year: 2024,
    figRef: "Weng et al. Fig. 2 · §IV · §IV-E", prov: "DexSampler-BPS + DexEvaluator (Allegro)",
    lede: "A partial point cloud becomes a fixed 4,096-number BPS code. DexSampler, a small cross-attention denoiser, turns noise into a 25-number Allegro grasp; DexEvaluator, a residual MLP, scores each grasp and steers refinement.",
    sources: {
      p1: { kind: "paper", ref: "Weng et al. 2024, §III–IV-C (grasp representation, BPS, DexSampler, DexEvaluator) and Fig. 2", url: "https://arxiv.org/abs/2402.02989" },
      p2: { kind: "paper", ref: "Weng et al. 2024, §IV-D (EGD and ESR refinement)", url: "https://arxiv.org/abs/2402.02989" },
      p3: { kind: "paper", ref: "Weng et al. 2024, §IV-E and §V (implementation, dataset)", url: "https://arxiv.org/abs/2402.02989" },
      p4: { kind: "paper", ref: "Weng et al. 2024, §VI, Tables I, II and IV (results, timing)", url: "https://arxiv.org/abs/2402.02989" },
      c1: { kind: "code", repo: "YuLiHN/DexDiffuser", path: "configs/model/unet_grasp_bps.yaml", commit: "d436e77", url: "https://github.com/YuLiHN/DexDiffuser/blob/d436e77/configs/model/unet_grasp_bps.yaml" },
      c2: { kind: "code", repo: "YuLiHN/DexDiffuser", path: "models/model/unet.py", commit: "d436e77", url: "https://github.com/YuLiHN/DexDiffuser/blob/d436e77/models/model/unet.py" },
      c3: { kind: "code", repo: "YuLiHN/DexDiffuser", path: "models/model/utils.py", commit: "d436e77", url: "https://github.com/YuLiHN/DexDiffuser/blob/d436e77/models/model/utils.py" },
      c4: { kind: "code", repo: "YuLiHN/DexDiffuser", path: "models/model/evaluator.py", commit: "d436e77", url: "https://github.com/YuLiHN/DexDiffuser/blob/d436e77/models/model/evaluator.py" },
      c5: { kind: "code", repo: "YuLiHN/DexDiffuser", path: "configs/task/evaluator_dexgn_slurm.yaml", commit: "d436e77", url: "https://github.com/YuLiHN/DexDiffuser/blob/d436e77/configs/task/evaluator_dexgn_slurm.yaml" },
      c6: { kind: "code", repo: "YuLiHN/DexDiffuser", path: "configs/diffuser/ddpm.yaml", commit: "d436e77", url: "https://github.com/YuLiHN/DexDiffuser/blob/d436e77/configs/diffuser/ddpm.yaml" },
      c7: { kind: "code", repo: "YuLiHN/DexDiffuser", path: "models/dm/ddpm.py", commit: "d436e77", url: "https://github.com/YuLiHN/DexDiffuser/blob/d436e77/models/dm/ddpm.py" },
      c8: { kind: "code", repo: "YuLiHN/DexDiffuser", path: "configs/task/grasp_gen_ur_dexgn_slurm.yaml", commit: "d436e77", url: "https://github.com/YuLiHN/DexDiffuser/blob/d436e77/configs/task/grasp_gen_ur_dexgn_slurm.yaml" }
    },
    summary: {
      pattern: ["Diffusion grasp sampler + learned evaluator", "p1"],
      params: null,
      vision: ["Segmented partial point cloud → BPS distances to 4,096 fixed basis points", "p1", "p3"],
      backbone: ["DexSampler: 4 × [time-conditioned ResBlock + cross-attention transformer], width 512", "c1", "c2"],
      head: ["Conv1d 512 → 25: predicted noise ε̂ₜ", "c2"],
      output: ["Allegro grasp g = [p (3), r (6-D rotation), q (16 joints)] = 25 numbers, plus success score", "p1", "c1"],
      attention: ["8 heads × 64; grasp token queries 8 BPS tokens of 512", "c1", "c2"],
      cond: ["Object: cross-attention to BPS tokens. Step t: sinusoid 512 → MLP 1,024 added in each ResBlock", "c2", "c3"],
      steps: ["DDPM, 100 steps, linear β 10⁻⁴ → 10⁻²", "p3", "c6"],
      chunk: null, rate: null,
      latency: ["1,692 ms (DexS-BPS) to 3,036 ms (EGD + ESR-2) per real trial of 200 ranked grasps", "p4"],
      train: ["1.7M Allegro grasps (≈ 40.5 % successful) on 5,378 objects, from DexGraspNet + Isaac Gym", "p3"]
    },
    blueprint: {
      headline: "DexDiffuser: denoise a grasp, then score it",
      note: "The BPS code is computed once per point cloud and cut into 8 tokens. DexSampler repeats its 4 blocks for each of the 100 denoising steps; the single grasp token cross-attends to the object tokens. DexEvaluator scores finished grasps, and its gradient (EGD) or accept-reject moves (ESR) refine them.",
      towers: [
        { mod: "bps", title: "BPS encoding", sub: "fixed, no learned weights", compact: true,
          input: { label: "Partial point cloud O", caption: "segmented, one camera view" },
          rows: [
            { t: "embed", label: "Distance to basis points", call: ["one random set of 4,096 points", "p3"] },
            { id: "tok", t: "linear", label: "Reshape to tokens", call: ["8 tokens × 512", "c2", "c1"] } ],
          output: { label: "fₒ: object code" } },
        { mod: "sampler", title: "DexSampler", sub: "noise predictor εθ(gₜ, t, fₒ)",
          input: { label: "Noisy grasp gₜ", caption: "one token, 25 numbers" },
          rows: [
            { t: "linear", label: "Conv1d 1 × 1 in", call: ["25 → 512", "c1", "c2"] },
            { t: "block", n: "4", rows: [
              { t: "norm", label: "GroupNorm · SiLU · Conv1d" },
              { id: "temb", t: "linear", label: "+ step embedding", side: "t", call: ["sinusoid 512 → MLP 1,024 → 512", "c1", "c2", "c3"] },
              { t: "norm", label: "GroupNorm · SiLU · Conv1d" },
              { t: "add", span: 3 },
              { t: "attn", label: "Self-attention", call: ["8 heads × 64; one grasp token", "c1", "c3"] },
              { id: "xattn", t: "attn", label: "Cross-attention to fₒ", call: ["K, V from 8 BPS tokens", "c2", "c3"],
                zoom: { k: "heads", title: "Cross-attention heads", q: 8, kv: 8, hd: 64 } },
              { id: "ff", t: "ffn", label: "GEGLU feed-forward", call: ["512 → 1,024 → 512", "c1", "c3"],
                zoom: { k: "glu", title: "Feed-forward (GEGLU)", act: "GELU", d: "512", ff: "1,024" } },
              { t: "add", span: 3 } ] },
            { id: "out", t: "linear", label: "GroupNorm · SiLU · Conv1d", call: ["512 → 25", "c2"],
              zoom: { k: "rows", title: "Evaluator-guided diffusion", rows: ["gₜ from step t", "mean μθ(gₜ, t, fₒ)", "+ λ · log(T − t + 1) · ∇ log D", "sample gₜ₋₁", "repeat to g₀"] } } ],
          output: { label: "ε̂ₜ; 100 steps → grasp g₀" } },
        { mod: "eval", title: "DexEvaluator", sub: "residual MLP, P(S = 1 | g, fₒ)", compact: true,
          input: { label: "[fₒ ‖ φ(p) ‖ φ(r) ‖ q]", caption: "4,096 + 63 + 54 + 16" },
          rows: [
            { t: "embed", label: "Frequency encoding", call: ["F = 10, 4, 0 for p, r, q", "p4", "c5"] },
            { t: "block", n: "3", rows: [
              { t: "mlp", label: "FC · BN · LeakyReLU" },
              { t: "mlp", label: "FC · BN", call: ["512 units; input re-joined", "c4"] },
              { t: "add", span: 2 } ] },
            { id: "sig", t: "linear", label: "FC → sigmoid", call: ["1 output; dropout 0.2", "c4"],
              zoom: { k: "rows", title: "ESR-2 refinement", rows: ["sample Δg for p and r", "α = D(g + Δg) / D(g)", "accept if α ≥ u ~ U[0, 1]", "then refine joints q", "rank by D, execute the best"] } } ],
          output: { label: "success probability" } }
      ],
      links: [
        { from: "bps", to: "sampler", toRow: "xattn", label: "8 × 512 tokens" },
        { from: "sampler", to: "eval", toRow: "input", label: "denoised grasps g₀" }
      ]
    },
    modules: [
      { id: "bps", role: "vision-enc", roleLabel: "Object encoding (fixed)", name: "BPS encoding", sub: "4,096 basis distances", col: 0, frozen: true, short: "BPS",
        note: "Not learned: distances from a fixed random basis to the nearest cloud point.",
        stack: { rows: [
          { t: "in", label: "segmented partial point cloud O", dims: "N × 3", c: "data-1" },
          { t: "embed", label: "nearest-point distance per basis point", dims: "4,096" },
          { t: "linear", label: "reshape", dims: "8 tokens × 512" },
          { t: "out", label: "object code fₒ", c: "data-1" } ],
          facts: [["Basis points", ["4,096, one random set for all objects", "p3"]], ["Tokens", ["8 × 512 (context dim 512)", "c1", "c2"]], ["Alternative", ["PointNet++ encoder (DexS-PN2), weaker on partial clouds", "p4"]]] } },
      { id: "sampler", role: "action-head", roleLabel: "Diffusion grasp sampler", name: "DexSampler", sub: "4 blocks · 512 · 8 heads", col: 1, frozen: false, main: true, short: "DexSampler",
        stack: { rows: [
          { t: "in", label: "noisy grasp gₜ", dims: "1 token × 25", c: "data-3" },
          { t: "linear", label: "Conv1d 1×1 in", dims: "25 → 512" },
          { t: "block", label: "ResBlock + transformer", n: "4", rows: [
            { t: "conv", label: "ResBlock: GN · SiLU · Conv1d (+ step emb) · GN · SiLU · Conv1d" },
            { t: "attn", label: "self-attention · cross-attention to fₒ · GEGLU FFN", dims: "8 heads × 64" } ] },
          { t: "linear", label: "GroupNorm · SiLU · Conv1d", dims: "512 → 25" },
          { t: "out", label: "predicted noise ε̂ₜ", dims: "25", c: "data-3" } ],
          facts: [["Width", ["512", "c1"]], ["Blocks", ["4", "c1"]], ["Heads", ["8 × 64", "c1"]], ["FFN", ["GEGLU, multiplier 2", "c1", "c3"]], ["Step embedding", ["512 → 1,024", "c1", "c2"]], ["Schedule", ["linear β 10⁻⁴ → 10⁻², 100 steps", "p3", "c6"]], ["Loss", ["‖ε̂ₜ − εₜ‖², successful grasps only", "p1", "p3"]], ["Training", ["batch 16,384, 200 epochs, lr 10⁻⁴", "p3", "c8"]]] } },
      { id: "eval", role: "critic", roleLabel: "Grasp evaluator", name: "DexEvaluator", sub: "3 res blocks · 512", col: 2, frozen: false, short: "DexEvaluator",
        stack: { rows: [
          { t: "in", label: "fₒ ‖ φ(p) ‖ φ(r) ‖ q", dims: "4,096 + 133 = 4,229", c: "data-8" },
          { t: "block", label: "Residual FC block", n: "3", rows: [
            { t: "mlp", label: "FC → BN → LeakyReLU → FC → BN, + skip", dims: "512" } ] },
          { t: "linear", label: "FC → sigmoid", dims: "1" },
          { t: "out", label: "success probability", c: "data-8" } ],
          facts: [["Frequencies", ["10 for p, 4 for r, none for q", "p4", "c5"]], ["Encoded size", ["63 + 54 + 16 = 133", "c3", "c4", "c5"]], ["Width", ["512", "c4"]], ["Loss", ["binary cross-entropy", "p1", "c4"]], ["Accuracy", ["80.91 % total (Table I)", "p4"]]] } }
    ],
    inputs: [
      { to: "bps", mod: "vision", label: "partial point cloud", n: "1 view", k: 4 },
      { to: "sampler", mod: "action", label: "noisy grasp gₜ", n: "25", k: 3, noisy: true },
      { to: "sampler", mod: "time", label: "step t", n: "of 100", k: 1 }
    ],
    outputs: [{ from: "eval", mod: "action", label: "ranked Allegro grasps", n: "25 numbers each", k: 3 }],
    links: [
      { from: "bps", to: "sampler", kind: "cross-attn", label: "8 BPS tokens|as keys, values" },
      { from: "sampler", to: "eval", kind: "feeds", label: "grasps g₀|scored, refined" }
    ],
    callouts: [
      "Paper vs code: §IV-E trains DexEvaluator with batch <b>25,600</b> for <b>20</b> epochs; the released config uses batch <b>32,768</b> for <b>100</b> epochs.",
      "Paper vs code: Eq. 8 adds λ times the evaluator gradient to the mean; the released sampler multiplies the guidance term by the model variance before adding it.",
      "The grasp is <b>one token</b>, so the self-attention in each block sees only itself; the object reaches the grasp through cross-attention. Fig. 2 shows t entering beside gₜ; in the code it is added inside each ResBlock."
    ]
  });
})();
