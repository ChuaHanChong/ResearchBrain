/* Methods that reuse another model's network unchanged (alias → that diagram), and methods with no network of their own (reason shown instead of a diagram). */
(function () {
  var A = window.RB.arch;
  A.alias("open-x-embodiment-rt-x", "rt-1", "RT-X adds data, not architecture: RT-1-X is the RT-1 network trained on Open X-Embodiment, and RT-2-X is RT-2 (PaLI-X). Shown: RT-1.");
  A.alias("umi", "diffusion-policy", "UMI is a data-collection interface; its policy is a standard Diffusion Policy. Shown: Diffusion Policy.");
  A.alias("phantom", "diffusion-policy", "Phantom edits human videos into robot data and trains a standard Diffusion Policy on it. Shown: Diffusion Policy.");
  A.alias("serl", "hil-serl", "SERL runs the same RLPD agent and ResNet-10 encoder later used by HIL-SERL. Shown: HIL-SERL.");
  A.alias("rlpd", "hil-serl", "RLPD is an algorithm recipe on SAC (symmetric sampling, LayerNorm critics, ensembles); its network is drawn inside HIL-SERL.");
  [["dagger", "A data-aggregation algorithm around any supervised learner; it has no network of its own."],
   ["real-time-chunking", "An inference-time guidance and threading scheme around any diffusion or flow policy; no network of its own."],
   ["grasp-anything", "A dataset paper: it evaluates GR-ConvNet, GG-CNN and Det-Seg-Refine but trains no model of its own. See Grasp-Anything++ / LGD for its model."],
   ["dexgraspnet", "Its grasps come from gradient-based energy optimisation filtered in simulation, not from a network."],
   ["pinn", "A generic tanh MLP; the method is the PDE-residual loss, not the network."],
   ["sindy", "Sparse regression over a function library; no neural network."],
   ["ppo", "An optimisation algorithm (the clipped surrogate objective); the policy network is a generic MLP or CNN."],
   ["domain-randomization", "A training technique: randomize the simulator so the real world looks like one more variation."],
   ["dynamics-randomization", "A training technique: randomize physics parameters during simulation training."],
   ["gat", "An algorithm that grounds simulator actions in real transitions; no distinctive network."],
   ["roboarena", "An evaluation platform (crowd-sourced pairwise ranking), not a model."],
   ["autoeval", "An autonomous evaluation cell built from off-the-shelf classifiers and a reset policy."],
   ["robopair", "An LLM jailbreak attack; the attacker and judge are off-the-shelf LLMs."],
   ["badrobot", "A voice and text jailbreak benchmark with no model of its own."],
   ["poex", "An attack on planning LLMs with no robot-policy model to draw."],
   ["libero-plus", "A perturbation benchmark over LIBERO, not a policy."]
  ].forEach(function (x) { A.none(x[0], x[1]); });
})();
