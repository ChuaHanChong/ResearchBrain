/* Architecture specs, topic 08 (vision-language-action models). Numbers from the paper and the official code; see sources. */
(function () {
  var RB = window.RB;
  RB.arch.spec({
    id: "pi0", method: "pi0", name: "π0", year: 2024,
    figRef: "Black et al. Fig. 3 · §IV · App. B, D", prov: "",
    lede: "One transformer with two sets of weights. PaliGemma (SigLIP + Gemma 2B) reads images and text; a 300M action expert reads the state and the noisy action chunk. They meet only inside self-attention, under a three-block causal mask.",
    sources: {
      p1: { kind: "paper", ref: "Black et al. 2024, §IV", url: "https://arxiv.org/abs/2410.24164" },
      p2: { kind: "paper", ref: "Black et al. 2024, App. B (architecture, mask, τ sampling)", url: "https://arxiv.org/abs/2410.24164" },
      p3: { kind: "paper", ref: "Black et al. 2024, App. D, Table I (inference)", url: "https://arxiv.org/abs/2410.24164" },
      c1: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/gemma.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/gemma.py" },
      c2: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/pi0.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/pi0.py" },
      c3: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/siglip.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/siglip.py" },
      c4: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/pi0_config.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/pi0_config.py" }
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p1"],
      params: ["3.3B = PaliGemma 3B + action expert ~300M", "p1"],
      vision: ["SigLIP So400m/14 at 224 × 224 → 256 tokens per image; 2–3 images", "p1", "c2", "c3"],
      backbone: ["Gemma 2B: 18 layers, width 2048, MQA", "p2", "c1"],
      head: ["Action expert: 18 layers, width 1024, MLP 4096, same heads as Gemma", "p2", "c1"],
      output: ["Velocity vθ on H = 50 actions (action dim padded to 32)", "p1", "c4"],
      attention: ["Blockwise causal: [images + text] → [state] → [actions]", "p2", "c2"],
      cond: ["τ enters through an MLP on [action ‖ sinusoid(τ)]", "p2", "c2"],
      steps: ["10 Euler steps (δ = 0.1); prefix KV cached", "p1", "c2"],
      chunk: ["H = 50; 16 or 25 actions run open loop before the next call", "p3"],
      rate: ["20 Hz (UR5e, Franka) or 50 Hz robots", "p3"],
      latency: ["73 ms on an RTX 4090 with 3 cameras (14 + 32 + 27 ms)", "p3"],
      train: ["≈10,000 h own data + OXE Magic Soup (9.1 % open data)", "p1"]
    },
    blueprint: {
      headline: "π0: two experts, one attention",
      note: "SigLIP's output tokens join the instruction tokens as Gemma's prefix. Gemma and the action expert run layer by layer in lockstep: at every one of the 18 layers their tokens share one self-attention under the block-causal mask, but each expert keeps its own weights.",
      towers: [
        { mod: "siglip", title: "SigLIP So400m/14", sub: "vision encoder", compact: true,
          input: { label: "Image patches 14 × 14", caption: "camera image 224 × 224" },
          rows: [
            { t: "embed", label: "Patch embedding layer", call: ["Embedding dimension of 1,152", "c3"] },
            { t: "block", n: "27", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["16 heads, bidirectional", "c3"], zoom: { k: "heads", q: 16, kv: 16, hd: 72, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 4,304", "c3"], zoom: { k: "mlp", act: "GELU", d: "1,152", ff: "4,304", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "linear", label: "Linear projection", call: ["1,152 → 2,048, no pooling", "c2"] } ],
          output: { label: "256 image tokens per camera" } },
        { mod: "gemma", title: "Gemma 2B", sub: "VLM backbone (PaliGemma)",
          input: { label: "Image tokens + text tokens", caption: "prefix: [images | instruction ℓ]" },
          rows: [
            { t: "embed", label: "Token embedding layer", call: ["Vocabulary of 257,152 · embedding dimension of 2,048", "c1"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention", side: "RoPE", call: ["8 query heads share 1 KV head (dim 256)", "c1"], callDy: -26, zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Hidden layer dimension of 16,384", "c1"], zoom: { k: "glu", act: "GELU", d: "2,048", ff: "16,384", title: "Feed forward (GeGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" } ],
          output: { label: "prefix keys and values, cached for all 10 flow steps" } },
        { mod: "expert", title: "Action expert", sub: "Gemma-style, ≈300M, from scratch",
          input: { label: "State q + noisy actions Aτ", caption: "1 state token + H = 50 action tokens, time τ" },
          rows: [
            { t: "linear", label: "State projection", call: ["q → 1,024", "c2"] },
            { t: "mlp", label: "Action + time MLP", call: ["[W₁aτ ‖ sinusoid(τ)] → swish MLP → 1,024", "p2", "c2"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention", call: ["Attends to prefix, state and all actions (RoPE)", "p2", "c1"] },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Width 1,024 · hidden layer dimension of 4,096", "p2", "c1"], zoom: { k: "glu", act: "GELU", d: "1,024", ff: "4,096", title: "Feed forward (GeGLU), expert" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "Action output projection", call: ["1,024 → 32 (padded action dim)", "c2", "c4"] } ],
          output: { label: "velocity vθ for 50 actions; 10 Euler steps" } }
      ],
      links: [{ from: "siglip", to: "gemma", toRow: "input", label: "image tokens" }],
      shared: [{ a: ["gemma", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "27 × 1152 · 16 heads", col: 0, frozen: false, short: "SigLIP",
        stack: { rows: [
          { t: "in", label: "image 224 × 224 × 3", dims: "one pass per camera", c: "data-1" },
          { t: "embed", label: "Patch embed 14 × 14 + learned position", dims: "→ 256 × 1152" },
          { t: "block", label: "ViT block (pre-norm)", n: "27", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 16 heads · bidirectional" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 1152 → 4304 → 1152 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "LayerNorm" },
          { t: "linear", label: "Linear head (pool = none)", dims: "1152 → 2048, one token per patch" },
          { t: "out", label: "256 image tokens", dims: "join the VLM prefix", c: "data-1" } ],
          facts: [["Variant", ["So400m/14", "c2"]], ["Width / depth", ["1152 / 27", "c3"]], ["MLP", ["4304", "c3"]], ["Heads", ["16", "c3"]], ["Resolution", ["224 × 224", "c2"]], ["Pooling", ["none: all 256 patch tokens kept", "c2"]]] } },
      { id: "gemma", role: "vlm", name: "Gemma 2B (PaliGemma)", sub: "18 × 2048 · MQA", col: 1, frozen: false, short: "Gemma 2B", main: true,
        stack: { rows: [
          { t: "in", label: "[image tokens | text tokens]", dims: "prefix block 1", c: "data-2" },
          { t: "embed", label: "Token embedding (text only)", dims: "vocab 257,152 → 2048" },
          { t: "block", label: "Gemma decoder block (pre-norm)", n: "18", rows: [
            { t: "norm", label: "RMSNorm" },
            { t: "attn", label: "MQA · 8 query heads, 1 KV head, head 256 · RoPE", note: "keys and values are shared with the action expert's tokens in the same layer" },
            { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 2048 → 16,384 → 2048" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "out", label: "prefix keys and values", dims: "cached across the 10 flow steps", c: "data-2" } ],
          facts: [["Width / depth", ["2048 / 18", "p2", "c1"]], ["MLP", ["16,384, GeGLU (gelu gate)", "c1"]], ["Heads", ["8 query, 1 KV (multi-query), head dim 256", "c1"]], ["Positions", ["RoPE", "c1"]], ["Norm", ["RMSNorm before attention and before FFN", "c1"]], ["Vocab", ["257,152", "c1"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert (Gemma 300M)", sub: "18 × 1024 · MLP 4096", col: 2, frozen: false, params: "≈300M", short: "Action expert",
        stack: { rows: [
          { t: "in", label: "state q + noisy actions Aτ + time τ", dims: "1 + 50 tokens", c: "data-3" },
          { t: "linear", label: "State projection: q → 1024", dims: "own block, cacheable" },
          { t: "mlp", label: "W₃ · swish(W₂ · [W₁ aτ ‖ φ(τ)])", dims: "action ‖ sinusoid(τ) → 1024" },
          { t: "block", label: "Expert block, same layer index as Gemma", n: "18", rows: [
            { t: "norm", label: "RMSNorm" },
            { t: "attn", label: "Joint attention over [prefix ‖ state ‖ actions]", note: "Q, K, V of the action tokens use the expert's weights; they attend to Gemma's K, V under the block mask" },
            { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 1024 → 4096 → 1024" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "Action output projection", dims: "1024 → 32 (padded)" },
          { t: "out", label: "velocity vθ for 50 actions", dims: "Euler step: A ← A + δ·vθ", c: "data-3" } ],
          facts: [["Width / depth", ["1024 / 18", "p2", "c1"]], ["MLP", ["4096", "p2", "c1"]], ["Heads", ["8 query, 1 KV, head dim 256", "c1"]], ["Time input", ["concat with sinusoid(τ), then 2-layer swish MLP", "p2", "c2"]], ["Attention among actions", ["full bidirectional", "p1"]], ["Init", ["from scratch", "p1"]]] } }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "2–3 camera images", n: "256 tokens each", k: 5 },
      { to: "gemma", mod: "lang", label: "instruction ℓ", n: "≤ 48 tokens", k: 3 },
      { to: "expert", mod: "state", label: "state qₜ", n: "1 token", k: 1 },
      { to: "expert", mod: "action", label: "noisy chunk Aτ, time τ", n: "H = 50", k: 5, noisy: true }
    ],
    outputs: [{ from: "expert", mod: "action", label: "velocity vθ", n: "50 × 32", k: 5 }],
    links: [
      { from: "siglip", to: "gemma", kind: "prefix", label: "linear → 2048|256 tokens / image" },
      { from: "gemma", to: "expert", kind: "joint-attn", label: "shared self-attn", note: "the two experts only interact inside attention" }
    ],
    mask: { name: "Blockwise causal", ref: "p2", axes: [{ label: "images + text", short: "img+ℓ", mod: "vision" }, { label: "state", short: "q", mod: "state" }, { label: "actions", short: "A", mod: "action" }], m: ["100", "110", "111"],
      note: "Prefix never sees robot tokens, so it stays close to VLM pretraining; state is its own block so its keys can be cached." },
    callouts: [
      "Paper App. B lists num_heads = 18 for Gemma 2B; the released config uses 8 query heads and 1 KV head.",
      "Time convention differs: the paper integrates τ from 0 (noise) to 1 (actions); openpi's code runs t from 1 (noise) to 0. This site uses the paper's."
    ]
  });
})();
