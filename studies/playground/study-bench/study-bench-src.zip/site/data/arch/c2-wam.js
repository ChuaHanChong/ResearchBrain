/* Architecture specs, topic 11 (world action models). Numbers from the paper and the official code; see sources. */
(function () {
  var RB = window.RB;
  RB.arch.spec({
    id: "uwm", method: "uwm", name: "UWM", year: 2025, parent: "diffusion-policy",
    diffRows: ["vision", "backbone", "head", "output", "attention", "cond", "steps", "train"],
    figRef: "Zhu et al. Figs. 1–3 · §III-C · App. A, Table V", prov: "",
    lede: "One diffusion transformer denoises an action chunk and the future frames' latents together, each with its own timestep. Setting a timestep to T hides that modality; setting it to 0 conditions on it. One network, four models.",
    sources: {
      p1: { kind: "paper", ref: "Zhu et al. 2025, §III-B (decoupled timesteps)", url: "https://arxiv.org/abs/2504.02792" },
      p2: { kind: "paper", ref: "Zhu et al. 2025, §III-C and Fig. 3", url: "https://arxiv.org/abs/2504.02792" },
      p3: { kind: "paper", ref: "Zhu et al. 2025, App. A, Table V", url: "https://arxiv.org/abs/2504.02792" },
      c1: { kind: "code", repo: "WEIRDLabUW/unified-world-model", path: "configs/model/uwm.yaml", commit: "b7d4067", url: "https://github.com/WEIRDLabUW/unified-world-model/blob/b7d4067/configs/model/uwm.yaml" },
      c2: { kind: "code", repo: "WEIRDLabUW/unified-world-model", path: "models/uwm/uwm.py", commit: "b7d4067", url: "https://github.com/WEIRDLabUW/unified-world-model/blob/b7d4067/models/uwm/uwm.py" },
      c3: { kind: "code", repo: "WEIRDLabUW/unified-world-model", path: "models/common/adaln_attention.py", commit: "b7d4067", url: "https://github.com/WEIRDLabUW/unified-world-model/blob/b7d4067/models/common/adaln_attention.py" },
      c4: { kind: "code", repo: "WEIRDLabUW/unified-world-model", path: "models/common/transforms.py", commit: "b7d4067", url: "https://github.com/WEIRDLabUW/unified-world-model/blob/b7d4067/models/common/transforms.py" }
    },
    summary: {
      pattern: ["Single-system joint DiT (video + action in one sequence)", "p2"],
      params: null,
      vision: ["Current frames: ResNet-18 (ImageNet init, trained). Future frames: frozen SDXL VAE → 28 × 28 × 4 latents", "p2", "p3"],
      backbone: ["DiT: 12 layers, width 768, 12 heads, MLP ratio 4, AdaLN", "p3", "c1"],
      head: ["Shallow MLPs decode action tokens; a linear unpatchify decodes latent patches", "p2", "c2"],
      output: ["Noise εₐ on 16 actions and εₒ′ on future-frame latents", "p1", "p3"],
      attention: ["Full bidirectional over [actions ‖ future patches ‖ 8 registers]", "p2", "c2"],
      cond: ["AdaLN from [obs features ‖ emb(tₐ) ‖ emb(tₒ′)]", "p2", "c3"],
      steps: ["100 train / 10 inference (DDIM), squared-cosine schedule", "p3"],
      chunk: ["hₐ = 16 predicted, 8 executed; hₒ = 2 frames", "p3"],
      rate: null, latency: null,
      train: ["Pretrain on DROID; co-train with action-free video by fixing tₐ = T", "p1", "p3"]
    },
    changes: [
      "The action net is no longer a conv U-Net: actions become 16 tokens in a <b>transformer</b> sequence.",
      "The model also <b>denoises the future frames</b> (VAE latents), so it is a video model too.",
      "Two independent timesteps: tₒ′ = T gives the policy, tₐ = T gives video prediction, tₐ = 0 gives forward dynamics, tₒ′ = 0 gives inverse dynamics.",
      "Observation conditioning moves from FiLM on conv blocks to <b>AdaLN</b> on transformer blocks; the ResNet-18 encoder stays.",
      "8 register tokens give the two modalities scratch space to exchange information."
    ],
    blueprint: {
      headline: "UWM: one transformer, two timesteps",
      note: "Action tokens, future-frame latent patches and 8 registers form one sequence with full attention. The current frames and both timesteps never enter the sequence: they modulate every block through AdaLN.",
      towers: [
        { mod: "resnet", title: "ResNet-18", sub: "per view, ImageNet init", compact: true,
          input: { label: "Frame crop 224 × 224", caption: "current frames, hₒ = 2" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "conv", label: "Residual stage (2 blocks)" }] },
            { t: "pool", label: "Global average pool" },
            { t: "linear", label: "Linear 512 → 768", call: ["768-d per frame", "c1"] } ],
          output: { label: "obs features, all frames and views" } },
        { mod: "dit", title: "UWM transformer", sub: "joint video + action DiT",
          input: { label: "Noisy tokens", caption: "16 actions · latent patches · 8 registers" },
          rows: [
            { id: "patch", t: "conv", label: "Action MLP · 3-D patchify", call: ["Actions: d → 3,072 → 768. Latents: patch (2, 4, 4) → 49 per view", "c2", "p3"] },
            { t: "embed", label: "+ learned position embedding" },
            { t: "block", n: "12", rows: [
              { id: "n1", t: "norm", label: "LayerNorm 1 · shift, scale", side: "AdaLN", zoom: { k: "adaln", d: "768", title: "AdaLN modulation" } },
              { t: "attn", label: "Multi-head self-attention", call: ["12 heads, width 768, full attention", "p3"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "Attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm 2 · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 3,072", "p3"], zoom: { k: "mlp", act: "GELU", d: "768", ff: "3,072", title: "Feed forward (MLP)" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "AdaLN final layer" },
            { t: "linear", label: "Action MLP · unpatchify", call: ["Registers are discarded", "c2"] } ],
          output: { label: "εₐ for 16 actions, εₒ′ for latents" } },
        { mod: "vae", title: "SDXL VAE", sub: "frozen", compact: true,
          input: { label: "Future frames o′", caption: "224 × 224 × 3, hₒ = 2" },
          rows: [{ t: "conv", label: "VAE encoder (frozen)", call: ["→ 28 × 28 × 4 latents", "p3"] }],
          output: { label: "latents, noised to tₒ′" } }
      ],
      links: [
        { from: "resnet", to: "dit", toRow: "n1", label: "obs ‖ emb(tₐ) ‖ emb(tₒ′)" },
        { from: "vae", to: "dit", toRow: "input", label: "future latents" }
      ]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet-18 per view", sub: "→ 768-d per frame", col: 0, frozen: false, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "current frames, crop 224 × 224", dims: "hₒ = 2 per camera", c: "data-1" },
          { t: "conv", label: "ResNet-18 (4 stages, 64 → 512 ch)", dims: "ImageNet init, BatchNorm replaced" },
          { t: "pool", label: "Global average pool" },
          { t: "linear", label: "fc: 512 → 768", dims: "one feature per frame" },
          { t: "out", label: "concat over frames and views", dims: "cameras × hₒ × 768", c: "data-1" } ],
          facts: [["Init", ["ImageNet, updated during training", "p3", "c2"]], ["Embed dim", ["768", "c1"]], ["Frames", ["hₒ = 2", "p3"]]] } },
      { id: "dit", role: "joint", roleLabel: "Joint video + action DiT", name: "UWM transformer", sub: "12 × 768 · 12 heads", col: 1, frozen: false, main: true, short: "DiT",
        stack: { rows: [
          { t: "in", label: "[16 action tok | future patches | 8 registers]", dims: "+ learned position embedding", c: "data-4" },
          { t: "mlp", label: "Action encoder: Linear → Mish → Linear", dims: "action dim → 3072 → 768" },
          { t: "conv", label: "Latent patchify: Conv3d (2, 4, 4)", dims: "per view: 7 × 7 = 49 tokens" },
          { t: "block", label: "AdaLN attention block", n: "12", rows: [
            { t: "norm", label: "LayerNorm (no affine) · shift, scale from cond" },
            { t: "attn", label: "MHA · 12 heads · bidirectional · qkv bias" },
            { t: "adaln", label: "× gate_msa", side: "cond" },
            { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm (no affine) · shift, scale from cond" },
            { t: "ffn", label: "MLP 768 → 3072 → 768 · GELU" },
            { t: "adaln", label: "× gate_mlp", side: "cond" },
            { t: "add", span: 3 } ], note: "cond → SiLU → Linear → 6 × 768" },
          { t: "norm", label: "AdaLN final layer" },
          { t: "linear", label: "Action decoder MLP · latent unpatchify", dims: "registers discarded" },
          { t: "out", label: "εₐ (16 actions) · εₒ′ (latents)", dims: "decode o′ with the VAE only at the end", c: "data-4" } ],
          facts: [["Width / depth / heads", ["768 / 12 / 12", "p3", "c1"]], ["MLP ratio", ["4 (GELU)", "p3", "c3"]], ["Timestep embedding", ["512-d per timestep, sinusoid + MLP", "c1", "c2"]], ["Registers", ["8", "p3"]], ["Patch shape", ["(2, 4, 4) on 28 × 28 × 4 latents", "p3", "c1"]], ["Loss weights", ["wₐ = wₒ′ = 1", "p3"]]] } },
      { id: "vae", role: "codec", name: "SDXL VAE", sub: "224² × 3 → 28² × 4", col: 2, frozen: true, short: "SDXL VAE",
        note: "Encodes future frames for training; decodes predicted latents only when video is wanted." }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "current frames o", n: "hₒ = 2 per view", k: 4 },
      { to: "dit", mod: "action", label: "noisy actions", n: "16 tokens", k: 4, noisy: true },
      { to: "dit", mod: "time", label: "tₐ and tₒ′", n: "two timesteps", k: 2 },
      { to: "vae", mod: "future", label: "future frames o′", n: "hₒ = 2 per view", k: 4 }
    ],
    outputs: [
      { from: "dit", mod: "action", label: "εₐ → action chunk", n: "16", k: 4 },
      { from: "dit", mod: "future", label: "εₒ′ → future latents", n: "49 / view", k: 4 }
    ],
    links: [
      { from: "resnet", to: "dit", kind: "adaln", label: "obs features" },
      { from: "vae", to: "dit", kind: "latent", label: "noisy latents|patchify (2, 4, 4)" }
    ],
    mask: { name: "Mutual (no mask)", ref: "p2", axes: [{ label: "actions", short: "a", mod: "action" }, { label: "future patches", short: "o′", mod: "future" }, { label: "registers", short: "reg", mod: "other" }], m: ["111", "111", "111"],
      note: "Masking happens through the timesteps instead: t = T turns a modality into pure noise." },
    callouts: [
      "Policy: set tₒ′ = T and denoise actions. Video: set tₐ = T. Forward dynamics: tₐ = 0. Inverse dynamics: tₒ′ = 0 (Eqs. 2–5).",
      "OpenWAM calls this pattern Single-System Vanilla: one shared DiT carries video and action tokens."
    ]
  });
})();
