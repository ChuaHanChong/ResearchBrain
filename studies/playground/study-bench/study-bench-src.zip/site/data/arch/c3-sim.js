/* Architecture specs, topic C3 (world models as simulators, data generators and evaluators).
   Numbers from the papers and the official code; see each spec's sources. */
(function () {
  var RB = window.RB;
  function ax(id) { return "https://arxiv.org/abs/" + id; }
  function gh(repo, commit, path) { return { kind: "code", repo: repo, path: path, commit: commit, url: "https://github.com/" + repo + "/blob/" + commit + "/" + path }; }

  /* ------------------------------------------------------------------ DreamGen */
  var DG = "NVIDIA/GR00T-Dreams", DGC = "ec3881d";
  RB.arch.spec({
    id: "dreamgen", method: "dreamgen", name: "DreamGen", year: 2025, parent: "gr00t-n1",
    figRef: "Jang et al. Figs. 2–3 · §2 · App. C–D", prov: "released IDM config",
    lede: "A four-step data pipeline: fine-tune a video world model on the robot, prompt it with new frames and instructions, label the dreamed videos with an inverse dynamics model, and train an ordinary policy on the result.",
    sources: {
      p1: { kind: "paper", ref: "Jang et al. 2025, §2.1–2.4 and Fig. 3 (pipeline, IDM, latent actions)", url: ax("2505.12705") },
      p2: { kind: "paper", ref: "Jang et al. 2025, App. C–D (2 × 2 view grid, WAN2.1 LoRA hyperparameters)", url: ax("2505.12705") },
      p3: { kind: "paper", ref: "Jang et al. 2025, §2.4 and App. F (policies, co-training, data)", url: ax("2505.12705") },
      c1: gh(DG, DGC, "IDM_dump/base.yaml"),
      c2: gh(DG, DGC, "gr00t/model/action_head/flow_matching_action_head_idm.py"),
      c3: gh(DG, DGC, "gr00t/model/action_head/cross_attention_dit.py"),
      c4: gh(DG, DGC, "README.md"),
      c5: gh(DG, DGC, "gr00t/model/action_head/multimodal_projector.py")
    },
    summary: {
      pattern: ["Cascaded WAM: video then inverse dynamics", "p1"],
      params: null,
      vision: ["IDM: SigLIP-2 large, patch 16, at 256 × 256; two frames per sample", "p1", "c1"],
      backbone: ["WAN2.1 image-to-video model with LoRA rank 4 (paper); the release ships Cosmos-Predict2", "p2", "c4"],
      head: ["IDM: flow-matching DiT, 8 layers, 16 heads × 64, AdaLN on τ", "c1", "c3"],
      output: ["Pseudo-action chunk of 16 steps (action dim padded to 32), or LAPA latent actions", "c1", "p1"],
      attention: ["IDM DiT: even blocks cross-attend to image tokens, odd blocks self-attend over actions", "c1", "c3"],
      cond: ["IDM sees only the two frames: no language, no proprioception", "p1"],
      steps: ["IDM: 16 integration steps; training τ ~ Beta(1.5, 1)", "c1"],
      chunk: ["IDM labels H actions between sₜ and sₜ₊H, then slides the window by 1", "p1"],
      rate: null, latency: null,
      train: ["WAN LoRA lr 10⁻⁴ (GR1: 75 epochs, batch 64); policies co-train 1:1 with real data", "p2", "p3"]
    },
    changes: [
      "A fine-tuned <b>video world model</b> now makes the training data: one initial frame plus an instruction becomes a robot video.",
      "GR00T N1's flow-matching DiT is reused as an <b>inverse dynamics model</b>: two frames in, an action chunk out, with no VLM and no language.",
      "Vision is <b>SigLIP-2</b> (large, patch 16) instead of the Eagle VLM; image tokens are merged 2 × 2 twice before the DiT.",
      "The downstream policy (GR00T N1, π0 or Diffusion Policy) is unchanged; it trains on neural trajectories with the state set to zero."
    ],
    diffRows: ["vision", "backbone", "head", "cond", "train"],
    blueprint: {
      headline: "DreamGen: dream the video, infer the actions",
      note: "The video world model runs first and to completion. Its videos are cut into frame pairs; the IDM turns each pair into an action chunk. The labelled videos (neural trajectories) then train any visuomotor policy.",
      towers: [
        { mod: "wm", title: "WAN2.1 image-to-video", sub: "fine-tuned with LoRA", compact: true,
          input: { label: "Initial frame + instruction", caption: "multi-view data: 2 × 2 grid" },
          rows: [
            { t: "conv", label: "Pretrained video DiT", note: "Frozen base weights; the paper also benchmarks CogVideoX, HunyuanVideo and Cosmos." },
            { t: "adaln", label: "+ LoRA adapters", call: ["LoRA rank 4, alpha 4, lr 10⁻⁴", "p2"] } ],
          output: { label: "dreamed robot video" } },
        { mod: "idm", title: "Inverse dynamics model", sub: "GR00T-style flow-matching DiT",
          input: { label: "Frames sₜ and sₜ₊H", caption: "two frames, no language, no state" },
          rows: [
            { t: "embed", label: "SigLIP-2 ViT-L/16 encoder", call: ["256 × 256 → 16 × 16 = 256 patches, width 1,024", "c1"] },
            { t: "mlp", label: "Projector: 2 × 2 merge, twice", call: ["256 → 16 tokens per frame", "c1", "c5"],
              zoom: { k: "rows", title: "Token merging projector", rows: ["patch tokens 16 × 16 × 1,024", "2 × 2 merge → LayerNorm → MLP", "2 × 2 merge → LayerNorm → MLP", "16 image tokens × 1,024"] } },
            { id: "vl", t: "attn", label: "Image self-attention", call: ["4 layers, 16 heads × 64", "c1"] },
            { t: "mlp", label: "Action encoder [aτ ‖ emb(τ)]", side: "τ", call: ["16 noisy actions, dim padded to 32", "c1"] },
            { t: "block", n: "8", rows: [
              { t: "norm", label: "AdaLayerNorm (τ)", side: "AdaLN" },
              { t: "attn", label: "Cross-attn ↔ self-attn", call: ["16 heads × 64 = 1,024; odd blocks self-attend", "c1", "c3"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward (GELU-tanh)" },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final AdaLN (τ)" },
            { t: "linear", label: "Action decoder MLP", call: ["velocity for 16 × 32; 16 steps at test time", "c1"],
              zoom: { k: "rows", title: "Sliding-window labelling", rows: ["dreamed video s₁ … sₙ", "IDM(sₜ, sₜ₊H) → âₜ … âₜ₊H", "slide by one frame, repeat", "video + labels = neural trajectory"] } } ],
          output: { label: "pseudo-action chunk âₜ … âₜ₊H" } },
        { mod: "policy", title: "Downstream policy", sub: "GR00T N1 · π0 · Diffusion Policy", compact: true,
          input: { label: "Neural trajectories", caption: "video + pseudo-actions, state = 0" },
          rows: [
            { t: "embed", label: "Policy (architecture unchanged)", call: ["co-trained 1:1 with real trajectories", "p3"] } ],
          output: { label: "robot actions" } }
      ],
      links: [
        { from: "wm", to: "idm", toRow: "input", label: "frame pairs" }
      ]
    },
    modules: [
      { id: "wm", role: "video-gen", roleLabel: "Video world model", name: "WAN2.1 I2V", sub: "LoRA rank 4 · 2 × 2 views", col: 0, frozen: "lora", short: "WAN2.1" },
      { id: "idm", role: "net", roleLabel: "Inverse dynamics model", name: "IDM (flow DiT)", sub: "SigLIP-2 · 8 × 1,024", col: 1, frozen: false, main: true, short: "IDM",
        stack: { rows: [
          { t: "in", label: "frames sₜ, sₜ₊H", dims: "256 × 256 each", c: "data-1" },
          { t: "embed", label: "SigLIP-2 large/16 → 256 patch tokens", dims: "width 1,024, tuned" },
          { t: "mlp", label: "Projector: two 2 × 2 merges + MLPs", dims: "→ 16 tokens per frame, + view embedding" },
          { t: "attn", label: "Self-attention transformer, 4 layers", dims: "16 heads × 64" },
          { t: "mlp", label: "Action encoder on [aτ ‖ emb(τ)]", dims: "per-embodiment weights" },
          { t: "block", label: "DiT block", n: "8", rows: [
            { t: "norm", label: "AdaLayerNorm from τ" }, { t: "attn", label: "Cross-attn to image tokens (even) / self-attn (odd)" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "Feed forward, GELU-tanh" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "Per-embodiment action decoder MLP" },
          { t: "out", label: "velocity on 16 × 32 action chunk", dims: "16 Euler steps", c: "data-3" } ],
          facts: [["Vision", ["google/siglip2-large-patch16-256", "c1"]], ["DiT", ["8 layers, 16 heads × 64, AdaLayerNorm, interleaved self-attention", "c1"]], ["Action chunk", ["16 × 32 (padded)", "c1"]], ["τ sampling", ["Beta(1.5, 1), s = 0.999, 1,000 buckets", "c1"]], ["Inputs", ["two frames only", "p1"]]] } },
      { id: "policy", role: "vlm", roleLabel: "Downstream policy", name: "GR00T N1 / π0 / DP", sub: "trained on dreams", col: 2, frozen: false, short: "Policy" }
    ],
    inputs: [
      { to: "wm", mod: "vision", label: "initial frame", n: "1 new", k: 1 },
      { to: "wm", mod: "lang", label: "instruction", n: "new verbs", k: 3 },
      { to: "idm", mod: "vision", label: "frame pair", n: "sₜ, sₜ₊H", k: 2 },
      { to: "idm", mod: "action", label: "noisy chunk", n: "16", k: 4, noisy: true },
      { to: "policy", mod: "vision", label: "dreamed frames", n: "per step", k: 2 }
    ],
    outputs: [
      { from: "wm", mod: "future", label: "robot video", n: "synthetic", k: 4 },
      { from: "idm", mod: "action", label: "pseudo-actions", n: "16 per window", k: 4 },
      { from: "policy", mod: "action", label: "action chunk", n: "policy-specific", k: 3 }
    ],
    links: [
      { from: "wm", to: "idm", kind: "two-stage", label: "dreamed video|frame pairs" },
      { from: "idm", to: "policy", kind: "two-stage", label: "neural|trajectories" }
    ],
    callouts: [
      "<b>Paper vs code:</b> the paper fine-tunes WAN2.1 by default; the released GR00T-Dreams repository runs the same pipeline with Cosmos-Predict2 (14B) as the video world model.",
      "Latent-action variant: instead of the IDM, LAPA's VQ-VAE encoder labels (current frame, frame 1 s ahead) with its pre-quantised embedding, so no robot actions are needed to train the labeller."
    ]
  });

  /* ------------------------------------------------------------------ World-Env */
  var WE = "amap-cvlab/world-env", WEC = "55bc757";
  RB.arch.spec({
    id: "world-env", method: "world-env", name: "World-Env", year: 2025, parent: "openvla-oft",
    figRef: "Xiao et al. Figs. 3–4, 9–10 · §4 · App. 9", prov: "LIBERO, released config",
    lede: "RL post-training of OpenVLA-OFT with no real environment: a video diffusion simulator renders the next frames from each action, and a frozen video VLM with a small reward head says when the task is done.",
    sources: {
      p1: { kind: "paper", ref: "Xiao et al. 2025, §4.1 and Fig. 4 (world simulator)", url: ax("2509.24948") },
      p2: { kind: "paper", ref: "Xiao et al. 2025, §4.2, App. 9.2 and Fig. 10 (instant reflector)", url: ax("2509.24948") },
      p3: { kind: "paper", ref: "Xiao et al. 2025, §4.3–4.4, App. 9.1 and Fig. 9 (scale head, LOOP)", url: ax("2509.24948") },
      p4: { kind: "paper", ref: "Xiao et al. 2025, Table 1 (5 demonstrations per task)", url: ax("2509.24948") },
      c1: gh(WE, WEC, "lib/enerverse/train_config_iros_challenge_wm.yaml"),
      c2: gh(WE, WEC, "lib/LLaVA/predict_reward.py"),
      c3: gh(WE, WEC, "config/train_rl_openvla_oft_all_task_goal.yaml"),
      c4: gh(WE, WEC, "lib/enerverse/infer_video.py")
    },
    summary: {
      pattern: ["World-model RL loop (policy + simulator + reward)", "p1"],
      params: null,
      vision: ["Policy: RGB + 6-D EE pose + gripper. Simulator: 384 × 384 frames → 48 × 48 × 4 latents", "p1", "c1"],
      backbone: ["Simulator: EnerVerse-AC video U-Net, 320 base channels × (1, 2, 4, 4)", "c1"],
      head: ["OpenVLA-OFT action head μₜ + a parallel scale head (same MLP) for log βₜ", "p3"],
      output: ["aₜ ~ Laplace(μₜ, βₜ); next frames; p(success) ∈ [0, 1]", "p1", "p2", "p3"],
      attention: ["Simulator: spatial + temporal attention; cross-attention to CLIP image and action tokens", "p1", "c1"],
      cond: ["Action → forward kinematics → pose drawn on black (action map); a memory frame from a bank", "p1"],
      steps: ["DDIM 27 steps, guidance 7.5; v-prediction", "c1", "c4"],
      chunk: ["Simulator predicts 8 frames per call from 4 previous frames", "c1"],
      rate: null, latency: null,
      train: ["5 demos per task + policy-explored rollouts; LOOP (RLOO + PPO), groups of 8", "p4", "p1", "p3", "c3"]
    },
    changes: [
      "A <b>scale head</b> with the same MLP as the action head predicts log β, turning the deterministic L1 policy into a Laplace policy that can explore.",
      "Rollouts happen in a <b>video diffusion simulator</b>: each action becomes an end-effector pose, drawn as an action map that conditions the next frames.",
      "A frozen <b>LLaVA-Video</b> VLM plus a trained reward head scores the imagined video and ends the episode once p(success) > 0.5.",
      "RL uses LOOP (leave-one-out baseline + PPO clipping); the VLA backbone is tuned with LoRA rank 32."
    ],
    diffRows: ["head", "output", "cond", "train"],
    blueprint: {
      headline: "World-Env: act, imagine, reflect",
      note: "The policy's action is turned into a pose by forward kinematics and drawn as an action map; the simulator renders the next frames and hands the last one back to the policy. After every step the reflector reads the whole imagined video and returns p(success), which is both the reward and the stop signal.",
      towers: [
        { mod: "policy", title: "OpenVLA-OFT + scale head", sub: "policy being post-trained", compact: true,
          input: { label: "Imagined frame + sₜ + g", caption: "RGB, 6-D EE pose + gripper" },
          rows: [
            { t: "embed", label: "OpenVLA-OFT backbone", call: ["LoRA rank 32 during RL", "p3"] },
            { t: "mlp", label: "Action head → μₜ" },
            { t: "mlp", label: "Scale head → log βₜ", call: ["same MLP as the action head; Laplace NLL", "p3"],
              zoom: { k: "rows", title: "Laplace exploration head", rows: ["hidden states f from the VLA", "action MLP → μ (L1-trained)", "scale MLP → β (log-scale)", "a ~ Laplace(μ, eᵝ) per dim"] } } ],
          output: { label: "aₜ → FK pose sₜ₊₁" } },
        { mod: "sim", title: "World simulator", sub: "EnerVerse-AC video diffusion U-Net",
          input: { label: "Noisy latents + memory frames", caption: "4 previous frames, 8 to predict" },
          rows: [
            { t: "conv", label: "VAE encoder (frozen)", call: ["384 × 384 → 48 × 48 × 4 latents", "c1"] },
            { id: "act", t: "conv", label: "Concat action map + rays", call: ["19 input channels: 4 + 1 + 4 + 4 + 6", "c1"],
              zoom: { k: "rows", title: "U-Net input channels", rows: ["noisy frame latent (4)", "conditioning mask (1)", "memory-frame latent (4)", "action-map latent (4)", "ray maps: direction + origin (6)"] } },
            { t: "group", label: "Down path · 4 levels × 2", rows: [
              { t: "conv", label: "ResBlock + temporal conv", call: ["320 → 640 → 1,280 → 1,280 channels", "c1"] },
              { t: "attn", label: "Spatial self + cross-attn", side: "CLIP", call: ["CLIP ViT-H/14 image tokens, context 1,024", "c1"] },
              { t: "attn", label: "Temporal self-attention", call: ["heads of 64 channels", "c1"] } ] },
            { t: "attn", label: "Middle block" },
            { t: "group", label: "Up path · skips from down path", rows: [
              { t: "conv", label: "ResBlock + temporal conv" },
              { t: "attn", label: "Spatial + temporal attention" } ] },
            { t: "conv", label: "Out conv → v-prediction", call: ["1,000-step schedule, zero terminal SNR", "c1"] } ],
          output: { label: "8 future frames (VAE decode)" } },
        { mod: "refl", title: "Instant reflector", sub: "LLaVA-Video 7B (frozen) + reward head", compact: true,
          input: { label: "Imagined video + task g", caption: "prompt: answer only Yes or No" },
          rows: [
            { t: "embed", label: "SigLIP So400m/14 at 384", call: ["32 sampled frames, spatial pool stride 2", "p2", "c2"] },
            { t: "attn", label: "Qwen2 LLM (frozen)", call: ["pooled hidden state, 3,584-d", "c2"] },
            { t: "mlp", label: "Reward head: MLP-ResNet", call: ["3,584 → 4,096, 2 residual blocks → 1", "c2"],
              zoom: { k: "rows", title: "Reward head", rows: ["pooled LLM state (3,584)", "LN → Linear 4,096 → ReLU", "2 residual blocks (LN, Linear, ReLU)", "LN → Linear 4,096 → Linear → 1", "sigmoid → p(success)"] } },
            { t: "linear", label: "Sigmoid → p(success)", call: ["stop when p > η = 0.5", "p2"] } ],
          output: { label: "reward Rₙ and end signal" } }
      ],
      links: [
        { from: "policy", to: "sim", toRow: "act", label: "pose → action map" }
      ]
    },
    modules: [
      { id: "policy", role: "vlm", roleLabel: "Policy (VLA)", name: "OpenVLA-OFT", sub: "+ Laplace scale head", col: 0, frozen: "lora", short: "Policy" },
      { id: "sim", role: "world", roleLabel: "World simulator", name: "Video diffusion U-Net", sub: "EnerVerse-AC · 48² latents", col: 1, frozen: true, main: true, short: "Simulator",
        stack: { rows: [
          { t: "in", label: "[noisy latents | mask | memory latent | action map | rays]", dims: "19 channels at 48 × 48", c: "data-4" },
          { t: "group", label: "Down path, 4 levels", rows: [
            { t: "conv", label: "2 ResBlocks + temporal conv per level", dims: "320 → 640 → 1,280 → 1,280" },
            { t: "attn", label: "Spatial self-attn + cross-attn (CLIP image, action tokens)" },
            { t: "attn", label: "Temporal self-attention" } ] },
          { t: "attn", label: "Middle block" },
          { t: "group", label: "Up path with skips", rows: [{ t: "conv", label: "ResBlocks + temporal conv" }, { t: "attn", label: "Spatial + temporal attention" }] },
          { t: "conv", label: "Out conv → v" },
          { t: "out", label: "8 future frame latents", dims: "VAE decode to 384 × 384", c: "data-4" } ],
          facts: [["Base channels / multipliers", ["320 / (1, 2, 4, 4)", "c1"]], ["Attention resolutions", ["4, 2, 1; 64 channels per head", "c1"]], ["Context", ["1,024-d; CLIP ViT-H/14 image embedder", "c1"]], ["Chunk / memory", ["8 frames / 4 previous", "c1"]], ["Sampler", ["DDIM 27 steps, CFG 7.5, rescale 0.7", "c1", "c4"]]] } },
      { id: "refl", role: "critic", roleLabel: "Instant reflector", name: "LLaVA-Video + head", sub: "frozen VLM · MLP reward", col: 2, frozen: "partial", short: "Reflector" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "imagined frame", n: "1", k: 1 },
      { to: "policy", mod: "state", label: "EE pose + gripper", n: "6 + 1", k: 2 },
      { to: "policy", mod: "lang", label: "instruction g", n: "tokens", k: 3 },
      { to: "sim", mod: "vision", label: "memory frames", n: "4", k: 2 },
      { to: "sim", mod: "action", label: "action map", n: "per frame", k: 2 },
      { to: "refl", mod: "future", label: "imagined video", n: "32 frames", k: 4 }
    ],
    outputs: [
      { from: "policy", mod: "action", label: "aₜ ~ Laplace", n: "7-D", k: 2 },
      { from: "sim", mod: "future", label: "next frames", n: "8", k: 4 },
      { from: "refl", mod: "other", label: "p(success)", n: "[0, 1]", k: 1 }
    ],
    links: [
      { from: "policy", to: "sim", kind: "feeds", label: "pose → action map" },
      { from: "sim", to: "refl", kind: "feeds", label: "imagined video" }
    ],
    callouts: [
      "<b>Paper vs code:</b> §4.1 injects VGGT geometry features next to CLIP through cross-attention; the released simulator config (EnerVerse-AC) has CLIP image cross-attention and ray maps but no VGGT encoder.",
      "The return is one reward at the step where the reflector fires (or at T), so success reached early is not followed by redundant actions."
    ]
  });

  /* ------------------------------------------------------------------ VLA-RFT */
  var VR = "OpenHelix-Team/VLA-RFT", VRC = "376693e", VA = "train/verl/vla-adapter/openvla-oft/prismatic/";
  RB.arch.spec({
    id: "vla-rft", method: "vla-rft", name: "VLA-RFT", year: 2025,
    figRef: "Li et al. Figs. 2, 5 · §3 · App. A, Tables 5–7", prov: "LIBERO, released config",
    lede: "A small autoregressive video model (138M) is the simulator. The policy's action chunk and the ground-truth chunk are both rolled out in it; the pixel and perceptual distance between the two videos is the reward for GRPO on a flow-matching VLA.",
    sources: {
      p1: { kind: "paper", ref: "Li et al. 2025, §3.1–3.3 (SDE policy, verified reward, GRPO)", url: ax("2510.00406") },
      p2: { kind: "paper", ref: "Li et al. 2025, App. A.1–A.2, Tables 5–7 (architectures, training)", url: ax("2510.00406") },
      c1: gh(VR, VRC, "train/verl/examples/grpo_trainer/run_vla_rft.sh"),
      c2: gh(VR, VRC, "train/verl/ivideogpt/processor.py"),
      c3: gh(VR, VRC, VA + "models/action_heads.py"),
      c4: gh(VR, VRC, VA + "models/noise_net.py"),
      c5: gh(VR, VRC, VA + "models/diffusion_transformer.py"),
      c6: gh(VR, VRC, "train/verl/verl/trainer/config/vla_rft_grpo_trainer.yaml"),
      c7: gh(VR, VRC, VA + "vla/constants.py"),
      c8: gh(VR, VRC, "train/verl/ivideogpt/configs/llama_small.json")
    },
    summary: {
      pattern: ["World-model RL loop (policy + simulator + reward)", "p1"],
      params: ["World model 138M; policy VLM Qwen2.5-0.5B", "p2"],
      vision: ["Policy: DINOv2 + SigLIP at 224 × 224. World model: VQ tokenizer, 64 tokens per predicted frame", "p2", "c1"],
      backbone: ["Policy VLM: 24 layers, width 896, 14 heads / 2 KV. World model: LLaMA-style, 12 × 768", "p2"],
      head: ["Flow DiT: 8 blocks, width 512, 8 heads; Sigma Net of the same shape outputs σ", "c3", "c4", "c5"],
      output: ["Chunk of 8 × 7-D actions; the world model predicts 8 frames", "c7", "p2"],
      attention: ["World model: causal over [context tokens | 64 frame + 7 action tokens per step]", "c2", "c1"],
      cond: ["Flow head: AdaLN from τ + proprio + pooled VLM context; cross-attention to VLM hidden states", "c5"],
      steps: ["K = 10 Euler steps, δ = 0.1; each step sampled from N(μₖ, σₖ²) during RFT", "p1"],
      chunk: ["T = 8 actions; 16 rollouts per start state", "c7", "p2"],
      rate: null, latency: null,
      train: ["World model 150k steps on LIBERO; RFT 400 GRPO steps, lr 10⁻⁶ (Sigma Net 10⁻⁵)", "p2"]
    },
    blueprint: {
      headline: "VLA-RFT: reward = match the reference rollout",
      note: "The frozen VLM encodes image and instruction once; the flow head and its twin Sigma Net turn noise into an action chunk in 10 stochastic steps. The chunk is tokenised and fed to the world model, which generates 8 frames token by token. The same is done for the dataset's own actions, and the two videos are compared with L1 + LPIPS.",
      towers: [
        { mod: "vlm", title: "VLA-Adapter VLM", sub: "Qwen2.5-0.5B · frozen in RFT", compact: true,
          input: { label: "Image + instruction", caption: "224 × 224 RGB" },
          rows: [
            { t: "embed", label: "DINOv2 + SigLIP encoders", call: ["dinosiglip-vit-so-224px", "p2"] },
            { t: "block", n: "24", rows: [
              { t: "attn", label: "Grouped-query attention", call: ["14 query heads, 2 KV heads, width 896", "p2"], zoom: { k: "heads", q: 14, kv: 2, hd: 64, title: "Grouped-query attention (VLM)" } },
              { t: "ffn", label: "Feed forward", call: ["Hidden layer dimension of 4,864", "p2"] } ] } ],
          output: { label: "hidden states, 896-d" } },
        { mod: "head", title: "Flow-matching action head", sub: "DiT · updated by GRPO",
          input: { label: "Noisy chunk aτ", caption: "8 action tokens, flow time τ" },
          rows: [
            { t: "linear", label: "Action embed + temporal pos.", call: ["→ width 512", "c3", "c5"] },
            { t: "mlp", label: "cond = emb(τ) + emb(proprio)", side: "τ, q" },
            { t: "block", n: "8", rows: [
              { t: "norm", label: "LayerNorm · AdaLN", side: "AdaLN" },
              { t: "attn", label: "Self-attention over actions", call: ["8 heads × 64, width 512", "c3", "c5"], zoom: { k: "heads", q: 8, kv: 8, hd: 64, title: "Attention heads (action DiT)" } },
              { t: "add", span: 2 },
              { id: "xa", t: "attn", label: "Cross-attn to VLM states", call: ["blocks 1, 3, 5, 7 and the last; layer-scaled residual", "c5"] },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm · AdaLN" },
              { t: "ffn", label: "Feed forward (GELU-tanh)", call: ["512 → 2,048 → 512", "c5"], zoom: { k: "mlp", act: "GELU-tanh", d: "512", ff: "2,048", title: "Feed forward (action DiT)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final AdaLN layer" },
            { t: "linear", label: "Linear → velocity μₖ", call: ["8 × 7 per step; K = 10 steps", "c7", "p1"] },
            { t: "mlp", label: "Sigma Net (twin DiT) → σₖ", call: ["σ clipped to [10⁻³, 0.5] per dimension", "c4"],
              zoom: { k: "rows", title: "SDE policy step", rows: ["μₖ = aₖδ + δ · vθ(o, ℓ, s, aₖδ)", "σₖ = SigmaNet(z, s, k)", "aₖ₊₁ ~ N(μₖ, σₖ²)", "log π = mean of K step log-probs"] } } ],
          output: { label: "action chunk (8 × 7)" } },
        { mod: "wm", title: "World model", sub: "LLaMA-style autoregressive, 138M",
          input: { label: "Frame tokens + action tokens", caption: "actions in 256 bins per dimension" },
          rows: [
            { t: "embed", label: "VQ tokenizer (frozen)", call: ["64 tokens per predicted frame", "c1"] },
            { t: "embed", label: "Token embedding", call: ["Vocabulary 9,008 = 2 × 4,375 + 256 + 2", "p2", "c6", "c1"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "RMSNorm" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["12 heads × 64, width 768", "p2"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "Attention heads (world model)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm" },
              { t: "ffn", label: "Feed forward (SiLU)", call: ["Hidden layer dimension of 3,072", "p2", "c8"], zoom: { k: "glu", act: "SiLU", d: "768", ff: "3,072", title: "Feed forward (world model)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head → next token", call: ["8 steps × (64 + 7) = 568 generated tokens", "c1"] } ],
          output: { label: "8 predicted frames → L1 + LPIPS" } }
      ],
      links: [
        { from: "vlm", to: "head", toRow: "xa", label: "hidden states" }
      ]
    },
    modules: [
      { id: "vlm", role: "vlm", roleLabel: "Policy VLM", name: "Qwen2.5-0.5B VLM", sub: "24 × 896 · frozen in RFT", col: 0, frozen: true, short: "VLM" },
      { id: "head", role: "action-head", roleLabel: "Flow action head", name: "Action DiT", sub: "8 × 512 · 8 heads", col: 1, frozen: false, main: true, short: "Flow head",
        stack: { rows: [
          { t: "in", label: "noisy chunk aτ (8 × 7) + τ + proprio", dims: "token per action", c: "data-3" },
          { t: "linear", label: "x-embedder + temporal embedding", dims: "→ 512" },
          { t: "block", label: "DiT block", n: "8", rows: [
            { t: "norm", label: "LayerNorm · shift, scale (AdaLN)" }, { t: "attn", label: "Self-attention · 8 heads" }, { t: "add", span: 2 },
            { t: "attn", label: "Cross-attn to VLM states (every 2nd block + last)" },
            { t: "norm", label: "LayerNorm · shift, scale" }, { t: "ffn", label: "MLP 512 → 2,048 → 512" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final AdaLN layer" },
          { t: "out", label: "velocity vθ (8 × 7)", dims: "10 Euler steps", c: "data-3" } ],
          facts: [["Depth / width / heads", ["8 / 512 / 8", "c3", "c5"]], ["Cross-attention", ["every 2nd block (+ first and last)", "c5"]], ["τ sampling", ["Beta(1.5, 1)", "c3"]], ["Chunk", ["8 × 7", "c7"]], ["RFT losses", ["GRPO + 0.01 · flow MSE − 0.003 · entropy", "p2", "c1"]]] } },
      { id: "sigma", role: "net", roleLabel: "Sigma Net", name: "Sigma Net", sub: "twin DiT → σ per dim", col: 2, frozen: false, short: "Sigma Net" },
      { id: "wm", role: "world", roleLabel: "Autoregressive world model", name: "LLaMA video model", sub: "12 × 768 · 138M", col: 3, frozen: true, short: "World model",
        stack: { rows: [
          { t: "in", label: "[context frame tokens | per step: 64 frame + 7 action tokens]", dims: "vocabulary 9,008", c: "data-4" },
          { t: "block", label: "LLaMA decoder block", n: "12", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "Causal MHA · 12 heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 768 → 3,072 → 768" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "LM head" },
          { t: "out", label: "next frame tokens → decoder", dims: "8 frames per rollout", c: "data-4" } ],
          facts: [["Layers / width / heads", ["12 / 768 / 12", "p2"]], ["FFN", ["3,072, SiLU", "p2"]], ["Max positions", ["8,192", "p2"]], ["Pretraining", ["150k steps, batch 16, lr 5 × 10⁻⁵, segments of 8", "p2"]]] } }
    ],
    inputs: [
      { to: "vlm", mod: "vision", label: "initial image", n: "224 × 224", k: 2 },
      { to: "vlm", mod: "lang", label: "instruction", n: "tokens", k: 3 },
      { to: "head", mod: "action", label: "noisy chunk", n: "8 × 7", k: 4, noisy: true },
      { to: "head", mod: "state", label: "proprio", n: "1", k: 1 },
      { to: "wm", mod: "vision", label: "initial frame tokens", n: "context", k: 3 }
    ],
    outputs: [
      { from: "head", mod: "action", label: "μₖ (velocity)", n: "8 × 7", k: 4 },
      { from: "sigma", mod: "other", label: "σₖ", n: "8 × 7", k: 2 },
      { from: "wm", mod: "future", label: "predicted frames", n: "8", k: 4 }
    ],
    links: [
      { from: "vlm", to: "head", kind: "cross-attn", label: "VLM hidden states" },
      { from: "head", to: "sigma", kind: "feeds", label: "same inputs|μₖ + σₖ" },
      { from: "sigma", to: "wm", kind: "feeds", label: "sampled chunk|→ 256-bin tokens" }
    ],
    mask: { name: "Causal (world model)", ref: "c2", axes: [{ label: "context frame", short: "ctx", mod: "vision" }, { label: "frame tokens", short: "o", mod: "future" }, { label: "action tokens", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "Token-level causal: each predicted frame's tokens follow the actions that caused them, step after step." },
    callouts: [
      "Verified reward: R = −Σₜ [λ₁ · L1(ôₜ₊₁, oₜ₊₁) + λlp · LPIPS(ôₜ₊₁, oₜ₊₁)], with both weights set to 1 in the released script; the reference frames come from rolling out the ground-truth actions.",
      "The paper's Table 5 lists vocabulary 9,008; the repository's small LLaMA config file still says 4,633, but the training script overrides it to 9,008 (2 × 4,375 visual codes + 256 action bins + BOS/EOS)."
    ]
  });

  /* ------------------------------------------------------------------ WMPO */
  var WM = "WM-PO/WMPO", WMC = "c836d74";
  RB.arch.spec({
    id: "wmpo", method: "wmpo", name: "WMPO", year: 2025, parent: "irasim",
    figRef: "Zhu et al. Fig. 2 · §3 · App. A, Tables 3–4", prov: "MimicGen Coffee, P = 128",
    lede: "On-policy GRPO for OpenVLA-OFT entirely inside a pixel-space video world model: an OpenSora DiT with per-frame action AdaLN, fine-tuned on the policy's own rollouts, plus a VideoMAE classifier that says whether the imagined trial succeeded.",
    sources: {
      p1: { kind: "paper", ref: "Zhu et al. 2025, §3.1–3.2 (MDP, world model, noisy-frame conditioning, frame-level AdaLN)", url: ax("2511.09515") },
      p2: { kind: "paper", ref: "Zhu et al. 2025, §3.3–3.4 (reward model, GRPO)", url: ax("2511.09515") },
      p3: { kind: "paper", ref: "Zhu et al. 2025, §4.1 and App. A, Tables 3–4", url: ax("2511.09515") },
      c1: gh(WM, WMC, "dependencies/opensora/opensora/models/stdit/stdit3.py"),
      c2: gh(WM, WMC, "verl/workers/fsdp_workers.py"),
      c3: gh(WM, WMC, "examples/mimicgen/coffee/train_wmpo_128.sh"),
      c4: { kind: "code", repo: "fangqi/WMPO (Hugging Face)", path: "checkpoint_files/world_models/coffee/P_128/train_mimicgen_cfg.py", commit: "44da159", url: "https://huggingface.co/fangqi/WMPO/blob/44da159/checkpoint_files/world_models/coffee/P_128/train_mimicgen_cfg.py" },
      c5: { kind: "code", repo: "fangqi/WMPO (Hugging Face)", path: "checkpoint_files/world_models/coffee/P_128/inference_cfg.py", commit: "44da159", url: "https://huggingface.co/fangqi/WMPO/blob/44da159/checkpoint_files/world_models/coffee/P_128/inference_cfg.py" },
      c6: gh(WM, WMC, "reward_model/videomae.py"),
      c7: gh(WM, WMC, "dependencies/opensora/opensora/models/vae/vae.py")
    },
    summary: {
      pattern: ["World-model RL loop (policy + simulator + reward)", "p1"],
      params: null,
      vision: ["Frozen SDXL 2-D VAE on 256 × 256 frames (÷ 8 → 32 × 32 latents)", "p1", "c4", "c7"],
      backbone: ["OpenSora STDiT3-XL/2: 28 spatial + 28 temporal blocks, width 1,152, 16 heads", "c1", "c4"],
      head: ["Final AdaLN layer + linear unpatchify; the text cross-attention is switched off", "c1"],
      output: ["K = 8 future frames from c = 4 conditioning frames", "p3", "c4"],
      attention: ["Spatial within a frame; causal temporal per patch with RoPE", "c1"],
      cond: ["Frame-level AdaLN: emb(t) + emb(aᵢ) per frame; 4 learned null actions for the context frames", "p1", "c1", "c4"],
      steps: ["Rectified flow, 30 sampling steps; context frames noised to step 50 of 1,000 in training", "c5", "p1"],
      chunk: ["Policy chunk K = 8; each of the 7 dimensions in 256 bins", "p1", "p3", "c3"],
      rate: null, latency: null,
      train: ["Pretrain on OXE, fine-tune on 128 or 1,280 policy rollouts; GRPO G = 8, lr 5 × 10⁻⁶, T = 1.6", "p3", "c3"]
    },
    changes: [
      "Initialised from <b>OpenSora STDiT3</b> (spatial blocks + causal temporal blocks) and pretrained on OXE instead of trained per dataset.",
      "The same <b>frame-level AdaLN</b> idea: each frame's spatial blocks get emb(t) + emb(aᵢ); the 4 context frames get a learned null-action embedding.",
      "<b>Noisy-frame conditioning</b>: context frames are perturbed during training so autoregressive rollouts of hundreds of frames stay stable.",
      "Fine-tuned on the policy's own rollouts, failures included, then used as the environment for GRPO on OpenVLA-OFT.",
      "A <b>VideoMAE</b> classifier over 8-frame clips supplies the binary success reward."
    ],
    diffRows: ["backbone", "cond", "steps", "output", "train"],
    blueprint: {
      headline: "WMPO: GRPO inside a pixel world model",
      note: "The policy reads the latest imagined frame and emits 8 actions; each action modulates its own frame's spatial blocks. The world model denoises those 8 frames given the last 4, decodes them to pixels, and the loop repeats until the horizon. VideoMAE then slides over the imagined trial and scores it 0 or 1 for GRPO.",
      towers: [
        { mod: "policy", title: "OpenVLA-OFT", sub: "parallel discrete action head", compact: true,
          input: { label: "Latest imagined frame + g", caption: "one camera, no proprio" },
          rows: [
            { t: "embed", label: "OpenVLA-OFT backbone" },
            { t: "linear", label: "Parallel action tokens", call: ["8 × 7 tokens, 256 bins each", "p1", "c3"] },
            { t: "linear", label: "Sample at temperature 1.6", call: ["GRPO group G = 8; clip 0.2 / 0.28", "p3"] } ],
          output: { label: "action chunk (8 × 7)" } },
        { mod: "wm", title: "STDiT3 world model", sub: "OpenSora init · frame-level action AdaLN",
          input: { label: "4 context + 8 noisy frames", caption: "SDXL VAE latents, 256 × 256" },
          rows: [
            { t: "conv", label: "SDXL VAE encode (frozen)", call: ["256 × 256 → 32 × 32 latents", "c4", "c7"] },
            { t: "conv", label: "Patchify 1 × 2 × 2 · Linear", call: ["→ 1,152 per token", "c1", "c4"] },
            { t: "embed", label: "+ 2-D sin-cos position" },
            { t: "block", n: "28", label: "spatial + temporal pair", rows: [
              { id: "n1", t: "norm", label: "LN · per-frame AdaLN",
                zoom: { k: "rows", title: "Frame-level action AdaLN", rows: ["aᵢ (7-D) → MLP 4,608 → 1,152", "context frames: learned null action", "cᵢ = emb(t) + emb(aᵢ)", "SiLU → Linear → 6 × 1,152", "frame i: own shift, scale, gate"] } },
              { t: "attn", label: "Spatial attention (in frame)", call: ["16 heads × 72, qk-norm", "c1", "c4"], zoom: { k: "heads", q: 16, kv: 16, hd: 72, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 4,608", "c1"], zoom: { k: "mlp", act: "GELU", d: "1,152", ff: "4,608", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LN · AdaLN (t only)", side: "AdaLN" },
              { t: "attn", label: "Causal temporal attention", side: "RoPE", call: ["per patch, across 4 + 8 = 12 frames", "c1", "c4"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale" },
              { t: "ffn", label: "Feed forward (GELU)" },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final AdaLN layer" },
            { t: "linear", label: "Linear · unpatchify" } ],
          output: { label: "8 future frames → decode to pixels" } },
        { mod: "rm", title: "VideoMAE reward", sub: "success classifier", compact: true,
          input: { label: "8-frame clips, sliding", caption: "224 × 224, stride 1" },
          rows: [
            { t: "embed", label: "VideoMAE-Base encoder", call: ["8-frame clips at 224 × 224", "c2", "c6"] },
            { t: "linear", label: "Linear head → success", call: ["success if any clip > τthr (0.82 on Coffee)", "p2", "c3"] } ],
          output: { label: "R(τ) ∈ {0, 1}" } }
      ],
      links: [
        { from: "policy", to: "wm", toRow: "n1", label: "aᵢ per frame" }
      ]
    },
    modules: [
      { id: "policy", role: "vlm", roleLabel: "Policy (VLA)", name: "OpenVLA-OFT", sub: "parallel 8 × 7 tokens", col: 0, frozen: false, short: "Policy" },
      { id: "wm", role: "world", roleLabel: "Pixel-space world model", name: "STDiT3-XL/2", sub: "28 pairs × 1,152 · 16 heads", col: 1, frozen: false, main: true, short: "World model",
        stack: { rows: [
          { t: "in", label: "[4 context latents | 8 noisy latents]", dims: "patch 1 × 2 × 2", c: "data-4" },
          { t: "conv", label: "Patch embed → 1,152 + 2-D position" },
          { t: "block", label: "Spatial + temporal pair", n: "28", rows: [
            { t: "norm", label: "LayerNorm · per-frame AdaLN (t + aᵢ)" }, { t: "attn", label: "Spatial MHA · 16 heads · qk-norm" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · per-frame AdaLN" }, { t: "ffn", label: "MLP 1,152 → 4,608 → 1,152" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN (t)" }, { t: "attn", label: "Causal temporal MHA · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN (t)" }, { t: "ffn", label: "MLP 1,152 → 4,608 → 1,152" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final AdaLN layer" },
          { t: "linear", label: "Linear, unpatchify" },
          { t: "out", label: "8 future frame latents", dims: "SDXL decode; repeat to horizon", c: "data-4" } ],
          facts: [["Depth / width / heads", ["28 spatial + 28 temporal / 1,152 / 16", "c1", "c4"]], ["Action encoder", ["7 → 4,608 → 1,152, SiLU", "c1", "c4"]], ["Training", ["AdamW 10⁻⁴, batch 128, 12M pretrain + 3M fine-tune steps", "p3"]], ["Sampler", ["rectified flow, 30 steps", "c5"]], ["Noisy conditioning", ["context frames at step 50 / 1,000", "p1"]]] } },
      { id: "rm", role: "critic", roleLabel: "Reward model", name: "VideoMAE classifier", sub: "8-frame clips → success", col: 2, frozen: false, short: "Reward" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "imagined frame", n: "1", k: 1 },
      { to: "policy", mod: "lang", label: "instruction g", n: "tokens", k: 3 },
      { to: "wm", mod: "vision", label: "context frames", n: "c = 4", k: 4 },
      { to: "wm", mod: "time", label: "flow step t", n: "shared", k: 1 },
      { to: "rm", mod: "future", label: "imagined clips", n: "8 frames", k: 4 }
    ],
    outputs: [
      { from: "policy", mod: "action", label: "action chunk", n: "8 × 7", k: 4 },
      { from: "wm", mod: "future", label: "future frames", n: "K = 8", k: 4 },
      { from: "rm", mod: "other", label: "success", n: "0 / 1", k: 1 }
    ],
    links: [
      { from: "policy", to: "wm", kind: "adaln", label: "aᵢ → frame AdaLN" },
      { from: "wm", to: "rm", kind: "feeds", label: "imagined trial" }
    ],
    mask: { name: "Temporal blocks: causal", ref: "c1", axes: [{ label: "context frames", short: "ctx", mod: "vision" }, { label: "predicted frames", short: "o′", mod: "future" }], m: ["10", "11"],
      note: "Spatial blocks see only their own frame; temporal blocks are causal across frames at each patch." },
    callouts: [
      "<b>Paper vs code:</b> Table 3 lists the prediction target as ε and EMA 0.9999; the released world-model config trains with OpenSora's rectified-flow scheduler (velocity) and EMA decay 0.99.",
      "Paper: VideoMAE encoder + linear head with binary cross-entropy. Code: a 2-class VideoMAE-Base classification head with cross-entropy, which is the same decision rule."
    ]
  });

  /* ------------------------------------------------------------------ Ctrl-World */
  var CW = "Robert-gyj/Ctrl-World", CWC = "99fb206";
  RB.arch.spec({
    id: "ctrl-world", method: "ctrl-world", name: "Ctrl-World", year: 2025,
    figRef: "Guo et al. Fig. 2 · §4.1 · App. A–C", prov: "DROID, released model",
    lede: "Stable Video Diffusion turned into an interactive simulator for generalist VLAs: it predicts three camera views at once, reads one pose token per frame through cross-attention, and keeps sparse history frames in context as memory.",
    sources: {
      p1: { kind: "paper", ref: "Guo et al. 2026, §4.1 and Fig. 2 (multi-view, memory, frame-level conditioning)", url: ax("2510.10125") },
      p2: { kind: "paper", ref: "Guo et al. 2026, App. A (architecture, tokens, training)", url: ax("2510.10125") },
      p3: { kind: "paper", ref: "Guo et al. 2026, §5.1 (DROID, views, history, chunk)", url: ax("2510.10125") },
      p4: { kind: "paper", ref: "Guo et al. 2026, App. B–C (policy adapter, fine-tuning)", url: ax("2510.10125") },
      c1: gh(CW, CWC, "models/ctrl_world.py"),
      c2: gh(CW, CWC, "config.py"),
      c3: gh(CW, CWC, "models/unet_spatio_temporal_condition.py")
    },
    summary: {
      pattern: ["Action-conditioned video world model (latent U-Net)", "p1"],
      params: ["1.5B (initialised from Stable Video Diffusion)", "p1"],
      vision: ["3 views (2 third-person + wrist) at 192 × 320 → 24 × 40 latents each", "p2", "p3"],
      backbone: ["SVD spatio-temporal U-Net: 320 → 640 → 1,280 → 1,280 channels, 2 layers per level", "c3"],
      head: ["Conv out → denoised latents (EDM preconditioning, x₀ loss)", "p1", "c1"],
      output: ["5 future frames per view per call (15 actions downsampled to 5)", "p2"],
      attention: ["Spatial attention over the 3 views' tokens together; temporal attention across 7 + 5 frames", "p1", "p2"],
      cond: ["Frame-level cross-attention: each frame reads its own pose token (history poses | future action poses) + CLIP text", "p1", "c1"],
      steps: ["50 sampling steps", "c2"],
      chunk: ["15-step (1 s) action chunk per call; k = 7 history frames", "p2", "p3"],
      rate: ["DROID actions at 15 Hz; world-model frames at 5 Hz", "c2"],
      latency: null,
      train: ["95k DROID trajectories; 100k steps, batch 64, lr 10⁻⁵ on 2 × 8 H100", "p2", "p3"]
    },
    blueprint: {
      headline: "Ctrl-World: one pose token per frame",
      note: "A frozen generalist policy proposes joint velocities; an adapter and forward kinematics turn them into Cartesian poses. The pose encoder makes one token per frame, and every frame of the U-Net cross-attends only to its own token. History frames sit in the same sequence, so temporal attention can retrieve a past frame with a matching pose.",
      towers: [
        { mod: "policy", title: "π0.5-DROID (frozen)", sub: "also π0, π0-FAST", compact: true,
          input: { label: "2 views + wrist, joints", caption: "the policy's own observation" },
          rows: [
            { t: "embed", label: "Generalist VLA policy", call: ["outputs H joint velocities", "p4"] },
            { t: "mlp", label: "Adapter MLP + Franka FK", call: ["2-layer MLP → joints → Cartesian pose", "p4"] } ],
          output: { label: "future poses a′ₜ₊₁ … a′ₜ₊H" } },
        { mod: "enc", title: "Pose encoder", sub: "the only new module", compact: true,
          input: { label: "History + future poses", caption: "7 history poses | 5 action poses" },
          rows: [
            { t: "mlp", label: "3-layer MLP (SiLU)", call: ["7 → 1,024 → 1,024 → 1,024", "p2", "c1"],
              zoom: { k: "rows", title: "Pose tokens", rows: ["7-D Cartesian pose per frame", "Linear 7 → 1,024 · SiLU", "Linear 1,024 → 1,024 · SiLU", "Linear 1,024 → 1,024", "+ CLIP text embedding (512 × 2)"] } },
            { t: "embed", label: "+ CLIP text embedding", call: ["ViT-B/32 text: 512, repeated to 1,024", "c1", "c2"] } ],
          output: { label: "one 1,024-d token per frame" } },
        { mod: "unet", title: "SVD spatio-temporal U-Net", sub: "1.5B · from Stable Video Diffusion",
          input: { label: "History latents ‖ noisy future", caption: "(7 + 5) frames × 3 views" },
          rows: [
            { t: "conv", label: "VAE encoder (frozen)", call: ["÷ 8: 192 × 320 → 24 × 40 per view", "p2"] },
            { t: "conv", label: "Views joined along tokens", call: ["P = 3 × 24 × 40 = 2,880 tokens per frame", "p2"],
              zoom: { k: "rows", title: "Multi-view sequence", rows: ["3 views: 2 third-person + wrist", "24 × 40 latent tokens per view", "joined: 2,880 tokens per frame", "12 frames: 7 history + 5 future"] } },
            { t: "conv", label: "Conv in: frame ‖ current latent", call: ["8 input channels (4 + 4)", "c3", "c1"] },
            { t: "group", label: "Down · mid · up, 4 levels", rows: [
              { t: "conv", label: "ResBlock + temporal ResBlock", call: ["320 → 640 → 1,280 → 1,280 channels", "c3"] },
              { t: "attn", label: "Spatial self-attention", call: ["heads 5, 10, 20, 20 by level", "c3"] },
              { id: "xa", t: "attn", label: "Cross-attn to pose token", call: ["frame i attends only to pose token i", "p1"] },
              { t: "attn", label: "Temporal self-attention", call: ["across all 12 frames", "p2"],
                zoom: { k: "rows", title: "Pose-conditioned memory", rows: ["k = 7 history frames, 1–2 s apart", "each tagged with its arm pose", "future frames: action poses a′", "attention finds same-pose past"] } } ] },
            { t: "conv", label: "GroupNorm · conv out", call: ["4 latent channels", "c3"] } ],
          output: { label: "5 future frames × 3 views" } }
      ],
      links: [
        { from: "enc", to: "unet", toRow: "xa", label: "pose tokens" },
        { from: "policy", to: "enc", toRow: "input", label: "poses" }
      ]
    },
    modules: [
      { id: "policy", role: "vlm", roleLabel: "Policy under test", name: "π0.5-DROID", sub: "frozen · + joint→pose adapter", col: 0, frozen: true, short: "Policy" },
      { id: "enc", role: "net", roleLabel: "Pose encoder", name: "Pose MLP", sub: "7 → 1,024 per frame", col: 1, frozen: false, short: "Pose MLP" },
      { id: "unet", role: "world", roleLabel: "Multi-view world model", name: "SVD U-Net", sub: "1.5B · 3 views · 12 frames", col: 2, frozen: false, main: true, params: "1.5B", short: "U-Net",
        stack: { rows: [
          { t: "in", label: "[7 history latents | 5 noisy latents] ‖ current latent", dims: "3 × 24 × 40 tokens per frame", c: "data-4" },
          { t: "conv", label: "Conv in: 8 → 320 channels" },
          { t: "group", label: "Down path, 4 levels", rows: [
            { t: "conv", label: "2 × (ResBlock + temporal ResBlock)", dims: "320, 640, 1,280, 1,280" },
            { t: "attn", label: "Spatial self-attn · cross-attn to pose token · temporal attn", dims: "first 3 levels" } ] },
          { t: "attn", label: "Mid block: ResBlocks + spatio-temporal transformer" },
          { t: "group", label: "Up path with skips", rows: [{ t: "conv", label: "ResBlocks + temporal ResBlocks" }, { t: "attn", label: "Same attention stack" }] },
          { t: "conv", label: "GroupNorm → conv out" },
          { t: "out", label: "denoised future latents", dims: "VAE decode → 192 × 320 × 3 views", c: "data-4" } ],
          facts: [["Init", ["Stable Video Diffusion img2vid, 1.5B", "p1", "c2"]], ["Cross-attention dim", ["1,024", "c3"]], ["New parameters", ["only the pose MLP", "p2"]], ["Noise", ["EDM: log σ ~ N(0.7, 1.6²); history noise σ up to 0.3", "c1"]], ["Training", ["100k steps, batch 64, lr 10⁻⁵", "p2"]]] } }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "3 camera views", n: "current", k: 3 },
      { to: "enc", mod: "state", label: "history poses", n: "7", k: 3 },
      { to: "enc", mod: "action", label: "action poses", n: "5 (of 15)", k: 3 },
      { to: "unet", mod: "vision", label: "history frames", n: "7 × 3 views", k: 4 },
      { to: "unet", mod: "time", label: "noise level σ", n: "shared", k: 1 }
    ],
    outputs: [
      { from: "policy", mod: "action", label: "joint velocities", n: "H steps", k: 3 },
      { from: "unet", mod: "future", label: "future frames", n: "5 × 3 views", k: 5 }
    ],
    links: [
      { from: "policy", to: "enc", kind: "feeds", label: "Cartesian poses|adapter + FK" },
      { from: "enc", to: "unet", kind: "cross-attn", label: "pose token|per frame" }
    ],
    callouts: [
      "<b>Paper vs code:</b> the paper describes the backbone as a spatial-temporal transformer; the released code loads SVD's UNetSpatioTemporalConditionModel, a U-Net whose levels hold spatial and temporal transformer blocks.",
      "Success of imagined rollouts is judged by humans in the paper; there is no learned reward model. Successful imagined trajectories fine-tune π0.5 (2k steps) and raise success by 44.7 % on average."
    ]
  });

  /* ------------------------------------------------------------------ GPC */
  var GP = "han20192019/gpc_code", GPC = "a96146e";
  RB.arch.spec({
    id: "gpc", method: "gpc", name: "GPC", year: 2025, parent: "diffusion-policy",
    figRef: "Qi et al. Figs. 1–2 · §III–IV · §V-B", prov: "Push-T (vision), released",
    lede: "A frozen Diffusion Policy proposes action chunks; an action-conditioned image diffusion model (EDM U-Net) predicts what each chunk would do; a small reward network or a VLM picks the best, or its gradient refines one.",
    sources: {
      p1: { kind: "paper", ref: "Qi et al. 2026, §III (policy, GPC-RANK, GPC-OPT)", url: ax("2502.00622") },
      p2: { kind: "paper", ref: "Qi et al. 2026, §IV and Fig. 2 (visual world model)", url: ax("2502.00622") },
      p3: { kind: "paper", ref: "Qi et al. 2026, §V-B, Table II (reward predictor, VLM, K)", url: ax("2502.00622") },
      p4: { kind: "paper", ref: "Qi et al. 2026, §VII (limitations, runtime)", url: ax("2502.00622") },
      c1: gh(GP, GPC, "gpc_rank_evaluation/eval_baseline.py"),
      c2: gh(GP, GPC, "world_model_train_phase_one/train.py"),
      c3: gh(GP, GPC, "world_model_train_phase_one/diffusion/inner_model.py"),
      c4: gh(GP, GPC, "gpc_rank_evaluation/configs/gpc_rank_evaluation_config.yml"),
      c5: gh(GP, GPC, "gpc_rank_evaluation/models.py"),
      c6: gh(GP, GPC, "world_model_train_phase_one/diffusion/blocks.py")
    },
    summary: {
      pattern: ["Generative policy + world-model planner (rank / optimise)", "p1"],
      params: null,
      vision: ["96 × 96 images; ResNet-18 with GroupNorm in the policy", "p1", "c1", "c4"],
      backbone: ["World model: EDM image U-Net, 4 levels × 96 channels, 2 ResBlocks each (as in DIAMOND)", "p2", "c2"],
      head: ["Frozen Diffusion Policy head proposes K chunks; a ResNet-18 + MLP reward ranks them", "p1", "c1"],
      output: ["Best of K proposals (RANK) or a gradient-refined chunk (OPT)", "p1"],
      attention: ["World-model U-Net: self-attention only in the two coarsest levels and the middle", "c2", "c6"],
      cond: ["cond = Fourier(σ) + Fourier(σ of context) + action embedding; 4 past frames concatenated as channels", "c3", "c2"],
      steps: ["Policy: DDPM, 100 steps. World model: 3 EDM denoising steps, noise frozen to 0 at test time", "p1", "p2"],
      chunk: ["H = 2 observations, T = 16 predicted, 9 executed (code config: 8)", "p1", "c4"],
      rate: null,
      latency: ["≈3 s per decision cycle in real-world GPC-RANK", "p4"],
      train: ["World model on expert + random-exploration data; phase 1 single-step, phase 2 T-step", "p2"]
    },
    changes: [
      "The Diffusion Policy is <b>frozen</b>; it only proposes K action chunks.",
      "A new <b>action-conditioned image diffusion world model</b> (EDM U-Net, as in DIAMOND) predicts the next frame and is applied recursively T times.",
      "A <b>reward predictor</b> (ResNet-18 + MLP) or a VLM scores the predicted frames.",
      "GPC-RANK keeps the best of K proposals; GPC-OPT back-propagates the reward through the world model into the actions, with the diffusion noise fixed at 0."
    ],
    diffRows: ["backbone", "head", "output", "steps", "train"],
    blueprint: {
      headline: "GPC: propose, imagine, pick",
      note: "The policy samples K chunks. For each, the world model predicts one frame per action by 3-step denoising, feeding each prediction back as the newest of 4 context frames. The reward net reads the last predicted frame; GPC-RANK takes the argmax, GPC-OPT follows the reward gradient back into the actions.",
      towers: [
        { mod: "policy", title: "Diffusion Policy (frozen)", sub: "ResNet-18 + 1-D conv U-Net", compact: true,
          input: { label: "2 past images + agent pos", caption: "96 × 96" },
          rows: [
            { t: "conv", label: "ResNet-18 (GroupNorm)", call: ["512-d per image", "c1"] },
            { t: "conv", label: "1-D conv U-Net (FiLM)", call: ["DDPM, 100 denoising steps", "p1", "c4"] },
            { t: "linear", label: "Sample K proposals", call: ["K = 100 (learned reward), 10 (VLM)", "p3"] } ],
          output: { label: "K action chunks a⁽ᵏ⁾" } },
        { mod: "wm", title: "Visual world model", sub: "EDM denoiser U-Net (DIAMOND-style)",
          input: { label: "Noisy next frame ‖ 4 past frames", caption: "96 × 96 RGB, channel concat" },
          rows: [
            { id: "cond", t: "mlp", label: "cond = Fourier(σ) + emb(a)", side: "σ, aₜ", call: ["action MLP 2 → 64 per step × 4 = 256", "c3", "c2"],
              zoom: { k: "rows", title: "Denoiser conditioning", rows: ["σ → Fourier features (256)", "+ Fourier(σ of noised context)", "+ 4 actions: Linear 2 → 64 each", "Linear → SiLU → Linear (256)", "AdaGroupNorm in every ResBlock"] } },
            { t: "conv", label: "Conv 3 × 3 in", call: ["(4 + 1) × 3 = 15 → 96 channels", "c3", "c2"] },
            { t: "block", n: "4", label: "down levels", rows: [
              { t: "norm", label: "AdaGroupNorm → SiLU", side: "cond" },
              { t: "conv", label: "Conv 3 × 3 (× 2)", call: ["96 channels, 2 ResBlocks per level", "c2", "c6"] },
              { t: "add", span: 2 },
              { t: "attn", label: "Self-attention (levels 3–4)" } ] },
            { t: "attn", label: "Middle ResBlocks + attn" },
            { t: "group", label: "Up path (mirror + skips)", rows: [{ t: "conv", label: "ResBlocks, 96 channels" }] },
            { t: "norm", label: "GroupNorm · conv out", call: ["96 → 3 channels", "c3"] } ],
          output: { label: "ôₜ₊₁ after 3 denoising steps; repeat T times" } },
        { mod: "rw", title: "Reward predictor", sub: "or a VLM choosing among K", compact: true,
          input: { label: "Predicted final frame", caption: "96 × 96" },
          rows: [
            { t: "conv", label: "ResNet-18", call: ["512-d pooled feature", "c1"] },
            { t: "mlp", label: "MLP 512 → 256 → 128 → 2", call: ["one net for x, y; one for the angle", "c1"],
              zoom: { k: "rows", title: "GPC-OPT update", rows: ["â⁽⁰⁾ ~ policy P(Iₜ)", "r = R(W(Iₜ, â)), noise = 0", "â ← â + η ∇ₐ r", "M steps, then rank the K results"] } },
            { t: "linear", label: "Registration reward → argmax", call: ["VLM option: GPT-4o at temperature 0.2", "p3"] } ],
          output: { label: "chosen chunk a⁽ᵏ*⁾" } }
      ],
      links: [
        { from: "policy", to: "wm", toRow: "cond", label: "proposals" }
      ]
    },
    modules: [
      { id: "policy", role: "action-head", roleLabel: "Proposal policy", name: "Diffusion Policy", sub: "frozen · K samples", col: 0, frozen: true, short: "Policy" },
      { id: "wm", role: "world", roleLabel: "Visual world model", name: "EDM image U-Net", sub: "4 levels × 96 ch · 3 steps", col: 1, frozen: false, main: true, short: "World model",
        stack: { rows: [
          { t: "in", label: "[4 past frames | noisy next frame]", dims: "15 channels at 96 × 96", c: "data-4" },
          { t: "conv", label: "Conv 3 × 3 → 96 channels" },
          { t: "group", label: "Down path, 4 levels", rows: [
            { t: "conv", label: "2 ResBlocks (AdaGroupNorm from cond)", dims: "96 channels each" },
            { t: "attn", label: "Self-attention at levels 3 and 4" } ] },
          { t: "attn", label: "Middle: 2 ResBlocks + attention" },
          { t: "group", label: "Up path with skips", rows: [{ t: "conv", label: "ResBlocks mirroring the down path" }] },
          { t: "conv", label: "GroupNorm → SiLU → conv 3 × 3 → 3" },
          { t: "out", label: "denoised next frame", dims: "recursive for T steps", c: "data-4" } ],
          facts: [["Levels / channels", ["4 / 96 each, depths 2, 2, 2, 2", "c2"]], ["Conditioning", ["256-d cond, 4 past frames and actions", "c2", "c3"]], ["Sampler", ["EDM, 3 steps, σ ∈ [0.002, 5], ρ = 7", "p2", "c2"]], ["Training", ["phase 1 single-step, phase 2 recursive T-step", "p2"]]] } },
      { id: "rw", role: "critic", roleLabel: "Reward model", name: "ResNet-18 + MLP", sub: "pose → registration reward", col: 2, frozen: false, short: "Reward" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "past images", n: "H = 2", k: 2 },
      { to: "policy", mod: "state", label: "agent position", n: "2-D", k: 1 },
      { to: "wm", mod: "vision", label: "past frames", n: "4", k: 4 },
      { to: "wm", mod: "time", label: "noise level σ", n: "3 steps", k: 1 },
      { to: "rw", mod: "future", label: "predicted frame", n: "final", k: 1 }
    ],
    outputs: [
      { from: "policy", mod: "action", label: "proposals", n: "K chunks", k: 4 },
      { from: "wm", mod: "future", label: "predicted frames", n: "T", k: 4 },
      { from: "rw", mod: "other", label: "reward", n: "per proposal", k: 1 }
    ],
    links: [
      { from: "policy", to: "wm", kind: "feeds", label: "K proposals" },
      { from: "wm", to: "rw", kind: "feeds", label: "predicted frames|(∇ for OPT)" }
    ],
    callouts: [
      "<b>Paper vs code:</b> §III gives an action horizon of 9; the released rank-evaluation config sets an action horizon of 8.",
      "Freezing the world model's initial noise to 0 makes it deterministic; the paper reports that GPC-OPT fails without this, because stochastic gradients destabilise the reward ascent."
    ]
  });

  /* ------------------------------------------------------------------ WorldEval */
  var EV = "liyaxuanliyaxuan/Worldeval", EVC = "4608426";
  RB.arch.spec({
    id: "worldeval", method: "worldeval", name: "WorldEval", year: 2025,
    figRef: "Li, Zhu et al. Fig. 2 · §3.2–3.3 · App. C", prov: "Wan2.1-I2V-14B, DexVLA",
    lede: "A 14B image-to-video DiT learns to render what a specific policy would do: the policy's own latent action (Policy2Vec) is projected, scaled by a learnable α and added to the text tokens. Gemini-2.0 then judges the generated rollout.",
    sources: {
      p1: { kind: "paper", ref: "Li, Zhu et al. 2025, §3.2 (Policy2Vec, injection into Wan2.1)", url: ax("2505.19017") },
      p2: { kind: "paper", ref: "Li, Zhu et al. 2025, §3.3 (Gemini-2.0 success detector)", url: ax("2505.19017") },
      p3: { kind: "paper", ref: "Li, Zhu et al. 2025, §4 and App. C (setup, implementation)", url: ax("2505.19017") },
      c1: gh(EV, EVC, "diffsynth/models/wan_video_dit_act_embed.py"),
      c2: gh(EV, EVC, "diffsynth/pipelines/wan_video_act_embed.py"),
      c3: gh(EV, EVC, "wanvideo/scripts/train.bash"),
      c4: gh(EV, EVC, "diffsynth/models/wan_video_dit.py"),
      c5: gh(EV, EVC, "wanvideo/scripts/data_process.sh")
    },
    summary: {
      pattern: ["Action-conditioned video world model (latent DiT)", "p1"],
      params: ["14B (Wan2.1 image-to-video), LoRA fine-tuned", "p1", "p3"],
      vision: ["First frame from the top camera; Wan2.1 VAE latents with 16 channels", "p3", "c4"],
      backbone: ["Wan2.1-I2V DiT: 40 layers, width 5,120, 40 heads, FFN 13,824", "c4"],
      head: ["Wan head: modulated LayerNorm + linear unpatchify (patch 1 × 2 × 2)", "c4"],
      output: ["81-frame video at 480 × 480; Gemini-2.0 says success or failure", "p3", "p2"],
      attention: ["Full self-attention over video tokens (3-D RoPE); cross-attention to [CLIP image ‖ text + action]", "c4", "c2"],
      cond: ["Policy2Vec: time-mean policy latent → MLP → × α (learnable) → added to every text token", "p1", "c1", "c2"],
      steps: ["50 diffusion steps per video", "p3"],
      chunk: null,
      rate: null, latency: null,
      train: ["1,400 real trajectories; LoRA rank 16, α 16, lr 10⁻⁴, batch 8, 30 epochs", "p3"]
    },
    blueprint: {
      headline: "WorldEval: the policy's latent drives the video",
      note: "The policy under test runs once on the initial frame and instruction; its latent action (taken before the action decoder) is averaged over time, projected to the DiT width and added, scaled by α, to all text tokens. The DiT generates the whole 81-frame rollout, which Gemini-2.0 then judges.",
      towers: [
        { mod: "policy", title: "Policy under test", sub: "π0 · DexVLA · Diffusion Policy", compact: true,
          input: { label: "Initial frame + instruction", caption: "top camera, AgileX bimanual" },
          rows: [
            { t: "embed", label: "Policy encoders (frozen)" },
            { t: "linear", label: "Latent action z", call: ["taken just before the action decoder", "p1"] } ],
          output: { label: "z (no actions decoded)" } },
        { mod: "dit", title: "Wan2.1 I2V DiT", sub: "14B · LoRA + action projection",
          input: { label: "Noisy video latents ‖ image cond", caption: "81 frames; first frame given" },
          rows: [
            { t: "conv", label: "VAE latents · patchify", call: ["patch 1 × 2 × 2; 36 channels (16 noisy + 20 image cond)", "c4"] },
            { id: "ctx", t: "mlp", label: "Context: text + α · MLP(z̄)", side: "α", call: ["z̄: time-mean of z; 1,280 → 5,120 → 5,120", "c2", "c1", "c3"],
              zoom: { k: "rows", title: "Policy2Vec injection", rows: ["policy latent z (T × 1,280, DexVLA)", "mean over time → z̄", "MLP 1,280 → 5,120 → 5,120", "× α (learnable, init 0.3)", "added to every text token"] } },
            { t: "block", n: "40", rows: [
              { t: "norm", label: "LayerNorm · AdaLN (t)", side: "AdaLN" },
              { t: "attn", label: "3-D self-attention", side: "RoPE", call: ["40 heads × 128 (5,120 ÷ 40)", "c4"], zoom: { k: "heads", q: 40, kv: 40, hd: 128, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "attn", label: "Cross-attn: CLIP ‖ text+action" },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm · shift, scale" },
              { t: "ffn", label: "Feed forward (GELU-tanh)", call: ["Hidden layer dimension of 13,824", "c4"], zoom: { k: "mlp", act: "GELU-tanh", d: "5,120", ff: "13,824", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Head: modulated LayerNorm" },
            { t: "linear", label: "Linear · unpatchify" } ],
          output: { label: "rollout video, 81 frames" } },
        { mod: "judge", title: "Gemini-2.0 judge", sub: "closed VLM, video input", compact: true,
          input: { label: "Generated video + question", caption: "e.g. is the apple on the plate?" },
          rows: [
            { t: "attn", label: "Gemini-2.0 (closed)", call: ["architecture not disclosed"] },
            { t: "linear", label: "Yes / No → success rate", call: ["cheap proxy: FID of generated videos", "p3"] } ],
          output: { label: "policy ranking" } }
      ],
      links: [
        { from: "policy", to: "dit", toRow: "ctx", label: "latent z" }
      ]
    },
    modules: [
      { id: "policy", role: "vlm", roleLabel: "Policy under test", name: "π0 / DexVLA / DP", sub: "frozen · pre-decoder latent", col: 0, frozen: true, short: "Policy" },
      { id: "dit", role: "world", roleLabel: "Video world model", name: "Wan2.1-I2V DiT", sub: "40 × 5,120 · 40 heads", col: 1, frozen: "lora", main: true, params: "14B", short: "Wan2.1",
        stack: { rows: [
          { t: "in", label: "[noisy latents ‖ first-frame latent + mask]", dims: "36 channels, patch 1 × 2 × 2", c: "data-4" },
          { t: "mlp", label: "Context = [CLIP image tokens ‖ text tokens + α · MLP(z̄)]" },
          { t: "block", label: "Wan DiT block", n: "40", rows: [
            { t: "norm", label: "LayerNorm · shift, scale (t)" }, { t: "attn", label: "Self-attention · 40 heads · RoPE" }, { t: "add", span: 2 },
            { t: "attn", label: "Cross-attention to context" }, { t: "add", span: 1 },
            { t: "norm", label: "LayerNorm · shift, scale" }, { t: "ffn", label: "MLP 5,120 → 13,824 → 5,120" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Head: modulated LayerNorm" },
          { t: "linear", label: "Linear, unpatchify" },
          { t: "out", label: "video latents", dims: "81 frames after VAE decode", c: "data-4" } ],
          facts: [["Depth / width / heads", ["40 / 5,120 / 40", "c4"]], ["FFN", ["13,824", "c4"]], ["Text encoder", ["umT5-XXL, 4,096-d", "c4", "c5"]], ["Action projection", ["Linear 1,280 → 5,120 → 5,120, α learnable", "c1", "c3"]], ["LoRA", ["rank 16 on q, k, v, o, FFN and the projection", "p3", "c3"]]] } },
      { id: "judge", role: "critic", roleLabel: "Success detector", name: "Gemini-2.0", sub: "closed VLM", col: 2, frozen: true, short: "Judge" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "initial frame", n: "1", k: 1 },
      { to: "policy", mod: "lang", label: "instruction", n: "tokens", k: 3 },
      { to: "dit", mod: "vision", label: "first frame", n: "1", k: 1 },
      { to: "dit", mod: "lang", label: "instruction (umT5)", n: "text tokens", k: 3 },
      { to: "judge", mod: "future", label: "generated video", n: "81 frames", k: 4 }
    ],
    outputs: [
      { from: "policy", mod: "latent", label: "latent action z", n: "per policy", k: 2 },
      { from: "dit", mod: "future", label: "rollout video", n: "81 frames", k: 5 },
      { from: "judge", mod: "other", label: "success", n: "yes / no", k: 1 }
    ],
    links: [
      { from: "policy", to: "dit", kind: "cross-attn", label: "α · MLP(z̄)|added to text" },
      { from: "dit", to: "judge", kind: "feeds", label: "generated rollout" }
    ],
    callouts: [
      "<b>Paper vs code:</b> App. C trains at 480 × 480 for 30 epochs; the released scripts preprocess at 480 × 832 and train for up to 40 epochs, with α initialised to 0.3.",
      "Ablation: raw actions encoded by a VQ-VAE or one-hot bins follow the policy far less well than the policy's own latent (Table 2)."
    ]
  });

  /* ------------------------------------------------------------------ WorldGym */
  var WG = "world-model-eval/world-model-eval", WGC = "709665b", WGP = "src/world_model_eval/";
  RB.arch.spec({
    id: "worldgym", method: "worldgym", name: "WorldGym", year: 2025,
    figRef: "Quevedo et al. §3.1 · App. A, Table 2 · App. B", prov: "Open-X, released model",
    lede: "One autoregressive latent video DiT, trained with Diffusion Forcing on nine Open-X datasets, acts as the environment: the policy acts, the model generates one frame per action, and GPT-4o scores the finished rollout.",
    sources: {
      p1: { kind: "paper", ref: "Quevedo et al. 2025, §3.1 (architecture, horizon matching, rollout)", url: ax("2506.00613") },
      p2: { kind: "paper", ref: "Quevedo et al. 2025, App. A, Table 2 (hyperparameters)", url: ax("2506.00613") },
      p3: { kind: "paper", ref: "Quevedo et al. 2025, §3.1.3 and App. B (GPT-4o reward)", url: ax("2506.00613") },
      c1: gh(WG, WGC, WGP + "model.py"),
      c2: gh(WG, WGC, WGP + "world_model.py"),
      c3: gh(WG, WGC, WGP + "vae.py"),
      c4: gh(WG, WGC, WGP + "diffusion.py")
    },
    summary: {
      pattern: ["Action-conditioned video world model (latent DiT)", "p1"],
      params: ["609M", "p2"],
      vision: ["256 × 256 frames → Stable Diffusion 3 VAE latents, 16 channels", "p2", "c3", "c2"],
      backbone: ["DiT: 16 layers, each a spatial + a causal temporal block; width 1,024, 16 heads, MLP ratio 4", "p2", "c1"],
      head: ["AdaLN final layer + linear unpatchify (patch 2)", "c1"],
      output: ["One frame per action; prediction horizon = the policy's chunk size", "p1"],
      attention: ["Spatial inside a frame; causal temporal across up to 20 frames; RoPE on both", "p2", "c1", "c2"],
      cond: ["AdaLN-Zero from emb(tᵢ) + Linear(aᵢ) per frame; whole-clip action dropout + classifier-free guidance", "p1", "c1"],
      steps: ["10 DDIM steps, v-prediction, sigmoid noise schedule", "p2", "c4"],
      chunk: ["Context of 20 frames; a sliding window for longer rollouts", "p2"],
      rate: null, latency: null,
      train: ["9 Open-X datasets (Bridge V2, RT-1, …); 300k steps, batch 16, lr 8 × 10⁻⁵", "p2"]
    },
    blueprint: {
      headline: "WorldGym: a learned environment for evaluation",
      note: "Each frame carries its own noise level (Diffusion Forcing), so the model can denoise exactly as many frames as the policy has actions. The action for frame i is projected and added to that frame's timestep embedding; the result modulates every spatial and temporal block through AdaLN-Zero.",
      towers: [
        { mod: "policy", title: "Policy under test", sub: "RT-1-X · Octo · OpenVLA", compact: true,
          input: { label: "Latest generated frame + g", caption: "starts from one real frame" },
          rows: [
            { t: "embed", label: "VLA policy (frozen)", call: ["its chunk size sets the horizon h", "p1"] } ],
          output: { label: "actions aᵢ (6-D EE + gripper)" } },
        { mod: "dit", title: "Autoregressive video DiT", sub: "609M · Diffusion Forcing",
          input: { label: "Clean context ‖ noisy chunk", caption: "up to 20 frames of latents" },
          rows: [
            { t: "conv", label: "SD3 VAE encode (frozen)", call: ["256 × 256 frames, 16 latent channels", "p2", "c3"] },
            { t: "conv", label: "Patchify 2 × 2 (Conv2d)", call: ["16 × 2 × 2 → 1,024", "c1", "c2"] },
            { id: "cond", t: "mlp", label: "cond = emb(tᵢ) + Linear(aᵢ)", side: "aᵢ, tᵢ", call: ["per frame; each frame has its own noise level", "p1", "c1"] },
            { t: "block", n: "16", label: "spatial + temporal pair", rows: [
              { t: "norm", label: "LN · AdaLN-Zero (per frame)", side: "AdaLN",
                zoom: { k: "rows", title: "AdaLN-Zero with actions", rows: ["tᵢ → sinusoid → MLP → 1,024", "+ Linear(aᵢ), 10-D in code", "SiLU → Linear → 6 × 1,024", "zero-init shift, scale, gate"] } },
              { t: "attn", label: "Spatial self-attention", side: "RoPE", call: ["16 heads × 64, 2-D RoPE", "p2", "c1"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LN · AdaLN-Zero" },
              { t: "ffn", label: "Feed forward (GELU-tanh)", call: ["Hidden layer dimension of 4,096", "p2", "c1"], zoom: { k: "mlp", act: "GELU-tanh", d: "1,024", ff: "4,096", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LN · AdaLN-Zero", side: "AdaLN" },
              { t: "attn", label: "Causal temporal attention", side: "RoPE", call: ["per patch, across frames", "c1"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LN · AdaLN-Zero" },
              { t: "ffn", label: "Feed forward (GELU-tanh)" },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final AdaLN layer" },
            { t: "linear", label: "Linear · unpatchify → v", call: ["v-prediction, 10 sampling steps", "p2"] } ],
          output: { label: "h new frames → SD3 decode" } },
        { mod: "judge", title: "GPT-4o reward", sub: "VLM judge", compact: true,
          input: { label: "Rollout frames + instruction", caption: "rubric, optional partial credit" },
          rows: [
            { t: "attn", label: "GPT-4o (closed)", call: ["final score 0, 0.5 or 1", "p3"] },
            { t: "linear", label: "Monte-Carlo mean → ρ̂(π)" } ],
          output: { label: "policy value estimate" } }
      ],
      links: [
        { from: "policy", to: "dit", toRow: "cond", label: "aᵢ" }
      ]
    },
    modules: [
      { id: "policy", role: "vlm", roleLabel: "Policy under test", name: "RT-1-X / Octo / OpenVLA", sub: "frozen", col: 0, frozen: true, short: "Policy" },
      { id: "dit", role: "world", roleLabel: "Autoregressive video DiT", name: "WorldGym DiT", sub: "16 × 1,024 · 16 heads", col: 1, frozen: false, main: true, params: "609M", short: "DiT",
        stack: { rows: [
          { t: "in", label: "[clean context latents | noisy chunk latents]", dims: "per-frame noise levels", c: "data-4" },
          { t: "conv", label: "Conv2d patchify 2 × 2 → 1,024" },
          { t: "block", label: "Spatial + temporal pair", n: "16", rows: [
            { t: "norm", label: "LayerNorm · AdaLN-Zero (tᵢ + aᵢ)" }, { t: "attn", label: "Spatial MHA · 16 heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN-Zero" }, { t: "ffn", label: "MLP 1,024 → 4,096 → 1,024" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN-Zero" }, { t: "attn", label: "Causal temporal MHA · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN-Zero" }, { t: "ffn", label: "MLP 1,024 → 4,096 → 1,024" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final AdaLN layer" },
          { t: "linear", label: "Linear, unpatchify" },
          { t: "out", label: "v for the noisy frames", dims: "SD3 VAE decode", c: "data-4" } ],
          facts: [["Layers / width / heads", ["16 / 1,024 / 16", "p2", "c1"]], ["Parameters", ["609M", "p2"]], ["Context", ["20 frames", "p2", "c2"]], ["Training", ["AdamW 8 × 10⁻⁵, batch 16, 300k steps on 2 A100", "p2"]], ["Sampler", ["DDIM 10 steps, sigmoid schedule, v target", "p2", "c4"]]] } },
      { id: "judge", role: "critic", roleLabel: "Reward (VLM)", name: "GPT-4o", sub: "closed · rubric prompt", col: 2, frozen: true, short: "Judge" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "generated frame", n: "latest", k: 1 },
      { to: "policy", mod: "lang", label: "goal g", n: "tokens", k: 3 },
      { to: "dit", mod: "vision", label: "context frames", n: "≤ 20", k: 4 },
      { to: "dit", mod: "time", label: "noise level tᵢ", n: "per frame", k: 2 },
      { to: "judge", mod: "future", label: "rollout frames", n: "whole episode", k: 4 }
    ],
    outputs: [
      { from: "policy", mod: "action", label: "action chunk", n: "chunk size", k: 3 },
      { from: "dit", mod: "future", label: "next frames", n: "h = chunk size", k: 3 },
      { from: "judge", mod: "other", label: "score", n: "0 / 0.5 / 1", k: 1 }
    ],
    links: [
      { from: "policy", to: "dit", kind: "adaln", label: "Linear(aᵢ) + emb(tᵢ)" },
      { from: "dit", to: "judge", kind: "feeds", label: "rollout video" }
    ],
    mask: { name: "Temporal blocks: causal", ref: "c1", axes: [{ label: "context frames", short: "ctx", mod: "vision" }, { label: "new chunk", short: "o′", mod: "future" }], m: ["10", "11"],
      note: "Spatial blocks attend within a frame; temporal blocks are causal, so any number of trailing frames can be denoised." },
    callouts: [
      "<b>Paper vs code:</b> App. A describes 7-D actions (6-D end effector + gripper); the released model is built with a 10-D action input and reserves the last component as a null-action flag for classifier-free guidance.",
      "Horizon matching: unlike a fixed 16-frame bidirectional model, the causal Diffusion Forcing DiT denoises exactly as many frames as the policy returns actions."
    ]
  });
})();
