/* Architecture specs, topics b1 (imitation learning at scale) and b3 (action representations and cross-embodiment policies).
   Numbers from the papers and the official code; see sources. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ BC-Z */
  RB.arch.spec({
    id: "bc-z", method: "bc-z", name: "BC-Z", year: 2021,
    figRef: "Jang et al. Fig. 3 · §5 · App. C–E", prov: "language-conditioned gin config",
    lede: "A ResNet-18 reads one head-camera image. A frozen sentence encoder (or a video encoder) turns the task into a 512-d vector that sets FiLM scales and shifts in every residual block. Three small MLP heads regress the end-effector action.",
    sources: {
      p1: { kind: "paper", ref: "Jang et al. 2021, §5.3 and Fig. 3 (network)", url: "https://arxiv.org/abs/2202.02005" },
      p2: { kind: "paper", ref: "Jang et al. 2021, §5.1 (language and video encoders)", url: "https://arxiv.org/abs/2202.02005" },
      p3: { kind: "paper", ref: "Jang et al. 2021, §5.2 (open-loop auxiliary, state differences)", url: "https://arxiv.org/abs/2202.02005" },
      p4: { kind: "paper", ref: "Jang et al. 2021, App. C–D (featurization, training)", url: "https://arxiv.org/abs/2202.02005" },
      p5: { kind: "paper", ref: "Jang et al. 2021, App. E.1 (video encoder)", url: "https://arxiv.org/abs/2202.02005" },
      p6: { kind: "paper", ref: "Jang et al. 2021, §4 (HG-DAgger data collection)", url: "https://arxiv.org/abs/2202.02005" },
      c1: { kind: "code", repo: "google-research/tensor2robot", path: "research/bcz/model.py", commit: "034f49c", url: "https://github.com/google-research/tensor2robot/blob/034f49c/research/bcz/model.py" },
      c2: { kind: "code", repo: "google-research/tensor2robot", path: "research/bcz/configs/run_train_bc_gtcond_trajectory.gin", commit: "034f49c", url: "https://github.com/google-research/tensor2robot/blob/034f49c/research/bcz/configs/run_train_bc_gtcond_trajectory.gin" },
      c3: { kind: "code", repo: "google-research/tensor2robot", path: "research/bcz/configs/run_train_bc_langcond_trajectory.gin", commit: "034f49c", url: "https://github.com/google-research/tensor2robot/blob/034f49c/research/bcz/configs/run_train_bc_langcond_trajectory.gin" },
      c4: { kind: "code", repo: "google-research/tensor2robot", path: "layers/film_resnet_model.py", commit: "034f49c", url: "https://github.com/google-research/tensor2robot/blob/034f49c/layers/film_resnet_model.py" },
      c5: { kind: "code", repo: "google-research/tensor2robot", path: "layers/resnet.py", commit: "034f49c", url: "https://github.com/google-research/tensor2robot/blob/034f49c/layers/resnet.py" },
      c6: { kind: "code", repo: "google-research/tensor2robot", path: "layers/bcz_networks.py", commit: "034f49c", url: "https://github.com/google-research/tensor2robot/blob/034f49c/layers/bcz_networks.py" }
    },
    summary: {
      pattern: ["FiLM-conditioned ResNet policy (behaviour cloning)", "p1"],
      params: null,
      vision: ["ResNet-18 from scratch on one head-camera RGB image; 450 × 450 crop resized to 200 × 200 (language config)", "p1", "p4", "c2", "c3"],
      backbone: ["None: a ResNet-18 (v2, pre-activation) torso, mean-pooled to 512", "p1", "c4", "c5"],
      head: ["3 MLP heads (Δxyz, Δaxis-angle, gripper), 2 hidden layers of 256, ReLU", "p1", "c2", "c6"],
      output: ["Next action plus a 10-step open-loop trajectory (auxiliary)", "p3", "c2"],
      attention: "None (convolutions only)",
      cond: ["FiLM from a 512-d task embedding on every residual unit, (1 + γ)·x + β", "p1", "c4", "c5"],
      steps: "One forward pass per control step",
      chunk: ["Only the first action is executed (closed loop)", "p3"],
      rate: ["10 Hz", "p3"],
      latency: null,
      train: ["25,877 robot demos (11,108 expert + 14,769 HG-DAgger) over 100 tasks; 18,726 human videos", "p6", "p2"]
    },
    blueprint: {
      headline: "BC-Z: a ResNet steered by the task",
      note: "The task is embedded once: a frozen sentence encoder for language, or a trained ResNet-18 over 20 tiled frames for a human video. A linear layer turns that 512-d vector into a γ and β per channel for each residual unit of the policy ResNet; the pooled image feature feeds three MLP heads.",
      towers: [
        { mod: "task", title: "Task encoder", sub: "frozen sentence encoder (language)", compact: true,
          input: { label: "Instruction ℓ", caption: "or a human video, 20 frames" },
          rows: [
            { t: "embed", label: "Multilingual USE (frozen)", call: ["512-d vector", "p2", "c1"],
              zoom: { k: "rows", title: "Video encoder (alternative)", rows: ["20 frames tiled 4 × 5", "ResNet-18 (trained)", "mean pool", "FC 32 · ReLU", "Linear → 512", "L2 normalise"] } },
            { t: "norm", label: "L2 normalise + noise", call: ["N(0, 0.1) noise in training", "p4", "c3"] },
            { id: "gen", t: "linear", label: "FiLM generator (linear)", call: ["γ, β per residual unit", "c5"] } ],
          output: { label: "γ, β for every unit" } },
        { mod: "resnet", title: "ResNet-18 torso", sub: "v2 pre-activation, from scratch",
          input: { label: "Image 200 × 200", caption: "crop 450 × 450 of the 512 × 640 frame" },
          rows: [
            { t: "conv", label: "Conv 7×7 /2 · max pool", call: ["64 filters, kernel 7", "c5"] },
            { t: "block", n: "8", label: "2 units × 4 stages", rows: [
              { t: "norm", label: "BatchNorm · ReLU" },
              { t: "conv", label: "Conv 3×3" },
              { t: "norm", label: "BatchNorm" },
              { id: "film", t: "film", label: "FiLM: (1 + γ) ⊙ x + β", side: "FiLM", call: ["Enabled in all 4 stages", "c2"], zoom: { k: "rows", title: "FiLM in a residual unit", rows: ["task z (512)", "Linear → γ, β for this unit", "BatchNorm(Conv 3×3(x))", "(1 + γ) ⊙ x + β, per channel", "ReLU → Conv 3×3 → ⊕ skip"] } },
              { t: "conv", label: "ReLU · Conv 3×3" },
              { t: "add", span: 5 } ] },
            { t: "pool", label: "Mean pool", call: ["Channels 64 → 128 → 256 → 512", "c4", "c5"] } ],
          output: { label: "512-d image feature" } },
        { mod: "heads", title: "Action heads", sub: "one MLP per action part", compact: true,
          input: { label: "512-d feature", caption: "same feature for all 3 heads" },
          rows: [
            { t: "mlp", label: "Linear 256 · ReLU", call: ["2 hidden layers of 256", "p1", "c2"] },
            { t: "mlp", label: "Linear 256 · ReLU" },
            { t: "linear", label: "Linear → size × 10", call: ["Δxyz 3 · Δaxis-angle 3 · gripper 1", "c2"],
              zoom: { k: "rows", title: "Action labels", rows: ["future pose N steps ahead", "grow N until arm moves > 0.05", "or gripper changes > 0.01", "Δxyz, Δaxis-angle, gripper", "Huber ×100, ×10 · log loss ×0.5"] } } ],
          output: { label: "10 waypoints; execute the first" } }
      ],
      links: [
        { from: "task", to: "resnet", toRow: "film", label: "γ, β" },
        { from: "resnet", to: "heads", toRow: "input", label: "pooled feature" }
      ]
    },
    modules: [
      { id: "task", role: "lang", name: "Task encoder", sub: "USE (frozen) · 512-d", col: 0, frozen: true, short: "Task enc.",
        note: "Language: pretrained Multilingual Universal Sentence Encoder. Video: a ResNet-18 over 20 tiled frames, trained with the BC loss plus a cosine loss to the language vector.",
        stack: { rows: [
          { t: "in", label: "instruction or human video", c: "data-2" },
          { t: "embed", label: "Multilingual USE (language)", dims: "→ 512" },
          { t: "norm", label: "L2 normalise; + N(0, 0.1) in training" },
          { t: "out", label: "task embedding z", dims: "512", c: "data-2" } ],
          facts: [["Language encoder", ["Multilingual Universal Sentence Encoder, pretrained", "p2"]], ["Embedding", ["512-d", "p1", "c1"]], ["Video encoder", ["ResNet-18 on a 4 × 5 grid of 20 frames → FC 32 → 512", "p5"]], ["Video alignment", ["cosine loss to the language vector", "p2"]], ["Noise", ["N(0, 0.1) on z during training", "p4"]]] } },
      { id: "resnet", role: "vision-enc", roleLabel: "Policy torso", name: "ResNet-18 + FiLM", sub: "v2 · 64 → 512 ch", col: 1, frozen: false, main: true, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "RGB 200 × 200", dims: "crop 450 × 450, photometric aug.", c: "data-1" },
          { t: "conv", label: "Conv 7×7 /2 → max pool 3×3 /2", dims: "64 ch" },
          { t: "block", label: "Pre-activation residual unit", n: "8", rows: [
            { t: "norm", label: "BatchNorm → ReLU" }, { t: "conv", label: "Conv 3×3" },
            { t: "norm", label: "BatchNorm" }, { t: "film", label: "FiLM (1 + γ)·x + β", side: "cond" },
            { t: "conv", label: "ReLU → Conv 3×3" }, { t: "add", span: 5 } ], note: "2 units per stage; strides 1, 2, 2, 2" },
          { t: "pool", label: "Global mean pool", dims: "→ 512" },
          { t: "out", label: "image feature", c: "data-1" } ],
          facts: [["Depth", ["ResNet-18 (blocks 2, 2, 2, 2)", "p1", "c2", "c5"]], ["Version", ["v2 (pre-activation)", "c4"]], ["FiLM", ["per unit, all 4 stages, from one linear layer", "c2", "c5"]], ["Pooling", ["mean (spatial softmax was tried and removed)", "p1", "p4"]], ["Pretraining", ["none (ImageNet init did not help)", "p4"]]] } },
      { id: "heads", role: "action-head", name: "3 MLP heads", sub: "2 × 256 · ReLU", col: 2, frozen: false, short: "Heads",
        stack: { rows: [
          { t: "in", label: "512-d feature", c: "data-1" },
          { t: "mlp", label: "Linear 256 → ReLU → Linear 256 → ReLU", dims: "one MLP per head" },
          { t: "linear", label: "Linear → size × 10 waypoints" },
          { t: "out", label: "Δxyz (3), Δaxis-angle (3), gripper (1)", c: "data-3" } ],
          facts: [["Hidden", ["2 layers of 256, ReLU", "p1", "c2"]], ["Waypoints", ["10 (first executed)", "p3", "c2"]], ["Loss", ["Huber on xyz and angle, log loss on gripper; weights 100, 10, 0.5", "p4", "c2"]], ["Labels", ["adaptive state differences N > 1 steps ahead", "p3", "p4"]]] } }
    ],
    inputs: [
      { to: "task", mod: "lang", label: "instruction or video", n: "one per task", k: 2 },
      { to: "resnet", mod: "vision", label: "head-camera image", n: "200 × 200", k: 4 }
    ],
    outputs: [{ from: "heads", mod: "action", label: "EE action + 10-step plan", n: "7 × 10", k: 5 }],
    links: [
      { from: "task", to: "resnet", kind: "film", label: "z → γ, β|every unit" },
      { from: "resnet", to: "heads", kind: "feeds", label: "512-d feature" }
    ],
    callouts: [
      "No proprioception: conditioning on robot state or past poses did not help, possibly through causal confusion (App.).",
      "Paper App. D trains multi-task policies with batch 4,096 and learning rate 5e-3 on a TPU pod; the released gin config uses batch 32 and 2.5e-4. The paper's 20-pixel cutout is <b>not implemented</b> in the open-source preprocessor (config comment).",
      "The code places FiLM on every residual unit (2 per stage); the paper describes it as per-channel FiLM on each of the 4 ResNet blocks."
    ]
  });

  /* ------------------------------------------------------------------ π0-FAST */
  RB.arch.spec({
    id: "fast", method: "fast", name: "π0-FAST", year: 2025, parent: "pi0",
    diffRows: ["head", "output", "attention", "cond", "steps", "latency", "train"],
    figRef: "Pertsch et al. Fig. 4 · Alg. 1 · §V–VI", prov: "openpi pi0_fast",
    lede: "FAST is a tokenizer, not a network: DCT per action dimension, scale and round, flatten low frequencies first, then BPE. π0-FAST drops π0's action expert and lets PaliGemma write those tokens autoregressively.",
    sources: {
      p1: { kind: "paper", ref: "Pertsch et al. 2025, §V-B, Fig. 4 and Alg. 1 (tokenizer)", url: "https://arxiv.org/abs/2501.09747" },
      p2: { kind: "paper", ref: "Pertsch et al. 2025, §VI-A (policy implementation)", url: "https://arxiv.org/abs/2501.09747" },
      p3: { kind: "paper", ref: "Pertsch et al. 2025, §VI-B, Table I (token counts)", url: "https://arxiv.org/abs/2501.09747" },
      p4: { kind: "paper", ref: "Pertsch et al. 2025, §VI-E (inference speed)", url: "https://arxiv.org/abs/2501.09747" },
      p5: { kind: "paper", ref: "Pertsch et al. 2025, §V-C and §VI-F (FAST+, generalist)", url: "https://arxiv.org/abs/2501.09747" },
      c1: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/pi0_fast.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/pi0_fast.py" },
      c2: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/gemma_fast.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/gemma_fast.py" },
      c3: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/tokenizer.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/tokenizer.py" },
      c4: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/siglip.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/siglip.py" },
      c5: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/model.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/model.py" },
      c6: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/training/config.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/training/config.py" }
    },
    summary: {
      pattern: ["Autoregressive token VLA", "p2"],
      params: ["PaliGemma-3B based; the 2B language model decodes every action token", "p2", "p4"],
      vision: ["SigLIP So400m/14 at 224 × 224 → 256 tokens per image; 3 image slots", "c1", "c4", "c5"],
      backbone: ["Gemma 2B: 18 layers, width 2,048, MQA (8 query, 1 KV head)", "c2"],
      head: ["None: the LM head; FAST ids map to the top of the 257,152 vocabulary, skipping the last 128", "c2", "c3"],
      output: ["≈ 30 tokens per arm per 1-s chunk (DROID 29, T-shirt 53 vs 105 and 700 bins)", "p3"],
      attention: ["Prefix [images, prompt, state] bidirectional; action tokens causal", "c1", "c3"],
      cond: ["State as text: 256-bin integers inside the prompt", "c3"],
      steps: ["30–60 autoregressive action tokens per chunk (≤ 256 decode steps in code)", "p4", "c1"],
      chunk: ["1-second chunks (openpi DROID config: horizon 10)", "p1", "c6"],
      rate: null,
      latency: ["≈ 750 ms per chunk on an RTX 4090 (π0: ≈ 100 ms)", "p4"],
      train: ["π0 mixture (10k h); 5× fewer GPU hours than π0 to match it", "p5"]
    },
    changes: [
      "The <b>action expert is removed</b>: Gemma 2B itself writes the actions.",
      "Actions become <b>discrete FAST tokens</b> (DCT + BPE) predicted with next-token cross-entropy, not a flow-matching velocity.",
      "The robot state enters as <b>text</b>: 256-bin integers in the prompt instead of a state token.",
      "Mask: images, prompt and state stay bidirectional; action tokens are causal.",
      "About 5× cheaper to train, but ≈ 750 ms instead of ≈ 100 ms per chunk at inference."
    ],
    blueprint: {
      headline: "π0-FAST: PaliGemma writes compressed actions",
      note: "SigLIP tokens and the prompt (instruction plus discretised state) form a bidirectional prefix. Gemma 2B then decodes FAST tokens one at a time; the fixed FAST decoder inverts BPE, rounding and the DCT to recover a continuous 1-second chunk.",
      towers: [
        { mod: "siglip", title: "SigLIP So400m/14", sub: "vision encoder", compact: true,
          input: { label: "Image patches 14 × 14", caption: "up to 3 images, 224 × 224" },
          rows: [
            { t: "embed", label: "Patch embedding layer", call: ["224 / 14 = 16 → 256 patches, width 1,152", "c4", "c5"] },
            { t: "block", n: "27", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["16 heads, bidirectional", "c4"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 4,304", "c4"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Linear projection", call: ["1,152 → 2,048, no pooling", "c1"] } ],
          output: { label: "256 image tokens per image" } },
        { mod: "gemma", title: "Gemma 2B", sub: "PaliGemma LM, decodes actions",
          input: { label: "Images + prompt + state", caption: "then “Action:” and FAST tokens" },
          rows: [
            { t: "embed", label: "Token embedding layer", call: ["Vocabulary of 257,152 · width 2,048", "c2"],
              zoom: { k: "rows", title: "Token layout", rows: ["image tokens (bidirectional)", "“Task: …, State: 256-bin ints;”", "“Action: ” (causal from here)", "FAST tokens (loss only here)", "“|” + EOS"] } },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Prefix-causal MQA", side: "RoPE", call: ["8 query heads share 1 KV head (dim 256)", "c2"], zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Hidden layer dimension of 16,384", "c2"], zoom: { k: "glu", act: "GELU", d: "2,048", ff: "16,384", title: "Feed forward (GeGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head (tied embedding)", call: ["Greedy decoding, temperature 0 by default", "c1"] } ],
          output: { label: "FAST token ids, one per step" } },
        { mod: "fast", title: "FAST decoder", sub: "fixed, invertible; BPE is learned", compact: true,
          input: { label: "FAST tokens", caption: "≈ 30 per arm per second" },
          rows: [
            { t: "embed", label: "BPE decode", call: ["BPE vocabulary of 1,024", "p1"] },
            { t: "linear", label: "Unflatten to |A| × H" },
            { t: "linear", label: "Divide by γ", call: ["Rounding scale γ = 10", "p1"],
              zoom: { k: "rows", title: "FAST encoder (training)", rows: ["quantile-normalise to [−1, 1]", "DCT per action dimension", "round(γ · C)", "flatten low frequencies first", "BPE → dense tokens"] } },
            { t: "linear", label: "Inverse DCT per dimension" },
            { t: "norm", label: "Un-normalise (q01, q99)", call: ["1st and 99th percentiles → ±1", "p1"] } ],
          output: { label: "continuous 1-s action chunk" } }
      ],
      links: [
        { from: "siglip", to: "gemma", toRow: "input", label: "image tokens" },
        { from: "gemma", to: "fast", toRow: "input", label: "action token ids" }
      ]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "27 × 1152 · 16 heads", col: 0, frozen: false, short: "SigLIP",
        stack: { rows: [
          { t: "in", label: "image 224 × 224 × 3", dims: "base_0, base_1, wrist_0 slots", c: "data-1" },
          { t: "embed", label: "Patch embed 14 × 14", dims: "→ 256 × 1152" },
          { t: "block", label: "ViT block", n: "27", rows: [{ t: "attn", label: "MHA · 16 heads" }, { t: "ffn", label: "MLP 1152 → 4304 → 1152" }] },
          { t: "linear", label: "Linear head (pool = none)", dims: "1152 → 2048" },
          { t: "out", label: "256 tokens per image", c: "data-1" } ],
          facts: [["Variant", ["So400m/14, pool none", "c1"]], ["Width / depth / heads", ["1,152 / 27 / 16", "c4"]], ["Resolution", ["224 × 224", "c5"]]] } },
      { id: "gemma", role: "vlm", name: "Gemma 2B (PaliGemma)", sub: "18 × 2048 · MQA", col: 1, frozen: false, main: true, short: "Gemma 2B",
        stack: { rows: [
          { t: "in", label: "[images | Task … State …; | Action: …]", dims: "max_token_len 250 (default)", c: "data-2" },
          { t: "embed", label: "Token embedding", dims: "vocab 257,152 → 2048" },
          { t: "block", label: "Gemma decoder block", n: "18", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MQA · 8 query, 1 KV, head 256 · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 2048 → 16,384 → 2048" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "LM head", dims: "next-token cross-entropy on the postfix" },
          { t: "out", label: "FAST token ids", dims: "id = vocab − 1 − 128 − fast_id", c: "data-3" } ],
          facts: [["Width / depth", ["2,048 / 18", "c2"]], ["Heads", ["8 query, 1 KV, head dim 256", "c2"]], ["MLP", ["16,384", "c2"]], ["Loss", ["cross-entropy on “Action: …|” only", "c3"]], ["Decoding", ["KV-cached prefill, then ≤ 256 greedy steps", "c1"]]] } },
      { id: "fast", role: "codec", roleLabel: "Action tokenizer", name: "FAST / FAST+", sub: "DCT · round · BPE 1,024", col: 2, frozen: true, short: "FAST",
        note: "Not a neural network: the only learned part is the BPE vocabulary. FAST+ is one BPE fitted on ≈ 1M one-second chunks from many robots.",
        stack: { rows: [
          { t: "in", label: "action chunk a₁:H", dims: "quantile-normalised to [−1, 1]", c: "data-3" },
          { t: "linear", label: "DCT per action dimension" },
          { t: "linear", label: "round(γ · C), γ = 10" },
          { t: "linear", label: "flatten, low frequencies of all dims first" },
          { t: "embed", label: "BPE", dims: "vocab 1,024" },
          { t: "out", label: "dense action tokens", c: "data-3" } ],
          facts: [["Hyper-parameters", ["scale γ = 10, BPE vocab 1,024", "p1"]], ["Order", ["column-first: lowest frequencies of every dimension first", "p1"]], ["Universal version", ["FAST+ fitted on ≈ 1M 1-s chunks", "p5"]], ["Compression", ["DROID 105 → 29 tokens, T-shirt fold 700 → 53", "p3"]]] } }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "up to 3 camera images", n: "256 tokens each", k: 5 },
      { to: "gemma", mod: "lang", label: "instruction ℓ", n: "text tokens", k: 3 },
      { to: "gemma", mod: "state", label: "state (text bins)", n: "in the prompt", k: 2 }
    ],
    outputs: [{ from: "fast", mod: "action", label: "1-second chunk", n: "H × action dim", k: 5 }],
    links: [
      { from: "siglip", to: "gemma", kind: "prefix", label: "linear → 2048|256 tokens / image" },
      { from: "gemma", to: "fast", kind: "feeds", label: "FAST ids|→ inverse DCT" }
    ],
    mask: { name: "Prefix LM", ref: "c3", axes: [{ label: "prefix", short: "pre", mod: "vision" }, { label: "actions", short: "a", mod: "action" }], m: ["10", "11"],
      note: "The prefix is bidirectional (ar_mask 0); each action token sees the prefix and only earlier action tokens (ar_mask 1)." },
    callouts: [
      "Paper §VI-A says action tokens <b>overwrite the least-used</b> VLM vocabulary entries; openpi maps FAST id k to <b>vocab − 1 − 128 − k</b>, i.e. the top of the vocabulary below the last 128 special tokens.",
      "FAST was also bolted onto OpenVLA for T-shirt folding (§VI-D); the drawing shows the π0 (PaliGemma) instantiation."
    ]
  });

  /* ------------------------------------------------------------------ OpenVLA-OFT */
  RB.arch.spec({
    id: "openvla-oft", method: "openvla-oft", name: "OpenVLA-OFT", year: 2025, parent: "openvla",
    diffRows: ["vision", "head", "output", "attention", "cond", "steps", "chunk", "rate", "latency", "train"],
    figRef: "Kim, Finn, Liang Fig. 1–2, 8 · §IV · App. A–D", prov: "LIBERO (K = 8) · ALOHA OFT+ (K = 25)",
    lede: "OpenVLA fine-tuned with LoRA, but Llama 2 no longer writes tokens: K·D empty action slots are filled in one bidirectional pass and a 4-layer MLP regresses continuous actions with L1. OFT+ adds FiLM from the language inside both ViTs.",
    sources: {
      p1: { kind: "paper", ref: "Kim, Finn, Liang 2025, §IV-B (parallel decoding, L1 head, inputs)", url: "https://arxiv.org/abs/2502.19645" },
      p2: { kind: "paper", ref: "Kim, Finn, Liang 2025, §IV-C and App. C (FiLM)", url: "https://arxiv.org/abs/2502.19645" },
      p3: { kind: "paper", ref: "Kim, Finn, Liang 2025, App. A–B (architecture, implementation)", url: "https://arxiv.org/abs/2502.19645" },
      p4: { kind: "paper", ref: "Kim, Finn, Liang 2025, App. D, Tables IV–V (hyper-parameters)", url: "https://arxiv.org/abs/2502.19645" },
      p5: { kind: "paper", ref: "Kim, Finn, Liang 2025, §V-D (throughput with extra inputs)", url: "https://arxiv.org/abs/2502.19645" },
      p6: { kind: "paper", ref: "Kim, Finn, Liang 2025, §VI-A (ALOHA setup)", url: "https://arxiv.org/abs/2502.19645" },
      p7: { kind: "paper", ref: "Touvron et al. 2023a (LLaMA), §2.2 and Table 2", url: "https://arxiv.org/abs/2302.13971" },
      c1: { kind: "code", repo: "moojink/openvla-oft", path: "prismatic/models/action_heads.py", commit: "e4287e9", url: "https://github.com/moojink/openvla-oft/blob/e4287e9/prismatic/models/action_heads.py" },
      c2: { kind: "code", repo: "moojink/openvla-oft", path: "prismatic/models/projectors.py", commit: "e4287e9", url: "https://github.com/moojink/openvla-oft/blob/e4287e9/prismatic/models/projectors.py" },
      c3: { kind: "code", repo: "moojink/openvla-oft", path: "prismatic/models/film_vit_wrapper.py", commit: "e4287e9", url: "https://github.com/moojink/openvla-oft/blob/e4287e9/prismatic/models/film_vit_wrapper.py" },
      c4: { kind: "code", repo: "moojink/openvla-oft", path: "prismatic/vla/constants.py", commit: "e4287e9", url: "https://github.com/moojink/openvla-oft/blob/e4287e9/prismatic/vla/constants.py" },
      c5: { kind: "code", repo: "moojink/openvla-oft", path: "prismatic/extern/hf/modeling_prismatic.py", commit: "e4287e9", url: "https://github.com/moojink/openvla-oft/blob/e4287e9/prismatic/extern/hf/modeling_prismatic.py" },
      c6: { kind: "code", repo: "moojink/openvla-oft", path: "vla-scripts/finetune.py", commit: "e4287e9", url: "https://github.com/moojink/openvla-oft/blob/e4287e9/vla-scripts/finetune.py" },
      c7: { kind: "code", repo: "moojink/openvla-oft", path: "prismatic/util/nn_utils.py", commit: "e4287e9", url: "https://github.com/moojink/openvla-oft/blob/e4287e9/prismatic/util/nn_utils.py" },
      c8: { kind: "code", repo: "moojink/openvla-oft", path: "pyproject.toml", commit: "e4287e9", url: "https://github.com/moojink/openvla-oft/blob/e4287e9/pyproject.toml" }
    },
    summary: {
      pattern: ["Parallel-decoding VLA + MLP regression head", "p1"],
      params: ["7.5B base; LIBERO trains 279M (111M LoRA + 151M head + 17M proprio)", "p4"],
      vision: ["DINOv2 ‖ SigLIP per view, 256 patches each; 1–3 views at 224 × 224; FiLM in OFT+", "p1", "p2", "p4"],
      backbone: ["Llama 2 7B (32 layers, width 4,096), LoRA rank 32, causal mask removed", "p4", "p7", "c6"],
      head: ["MLP on the K·D slot states: LN → 28,672 → 4,096 → 2 residual blocks → D", "p3", "c1"],
      output: ["K × D continuous actions in one pass: LIBERO 8 × 7, ALOHA 25 × 14", "p4", "c4"],
      attention: ["Bidirectional over [images | proprio | prompt | action slots]", "p3", "c8"],
      cond: ["OFT+: FiLM (1 + γ)·x + β from the mean language embedding in every ViT block", "p2", "c3"],
      steps: "One forward pass per chunk (no decoding loop)",
      chunk: ["Whole chunk executed open loop: 8 (LIBERO), 25 (ALOHA)", "p4"],
      rate: ["71.4 Hz action throughput with wrist image + proprio (A100); ALOHA runs at 25 Hz", "p5", "p6"],
      latency: ["0.112 s per 8-action chunk with 2 images + proprio (A100)", "p5"],
      train: ["LoRA fine-tune per task suite: LIBERO 50–150K steps, batch 64; ALOHA 20–300 demos per task", "p4"]
    },
    changes: [
      "<b>Parallel decoding</b>: K·D empty action embeddings replace teacher-forced tokens and the causal mask becomes bidirectional.",
      "The LM head is replaced by a <b>4-layer MLP</b> that regresses continuous actions with an <b>L1</b> loss.",
      "<b>Action chunks</b>: K = 8 (LIBERO) or 25 (ALOHA) actions per pass instead of one action per 7 decoding steps.",
      "More inputs: <b>several camera views</b> and a <b>proprio token</b> from a 2-layer MLP.",
      "OFT+: <b>FiLM</b> from the averaged language embedding inside every SigLIP and DINOv2 block."
    ],
    blueprint: {
      headline: "OpenVLA-OFT: one pass, many actions",
      note: "Each view goes through both ViTs (FiLM-modulated in OFT+), and a 3-layer MLP maps the fused patches to Llama tokens. Llama 2 runs once with a bidirectional mask; the final hidden states of the K·D empty action slots are regrouped per timestep and regressed by the MLP head.",
      towers: [
        { mod: "vis", title: "DINOv2 ‖ SigLIP", sub: "fused ViTs, LoRA + FiLM (OFT+)", compact: true,
          input: { label: "Image 224 × 224", caption: "third-person (+ 1–2 wrist views)" },
          rows: [
            { t: "embed", label: "Patch embed 14 × 14, ×2", call: ["256 patches per view", "p1"] },
            { t: "group", label: "every block, both ViTs", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Self-attention" },
              { t: "add", span: 2 },
              { id: "film", t: "film", label: "FiLM: (1 + γ) ⊙ x + β", side: "FiLM", call: ["One γ, β per hidden unit, all patches", "p2", "c3"], zoom: { k: "rows", title: "FiLM inside a ViT block (OFT+)", rows: ["mean language embedding ℓ̄", "γ = W_γ ℓ̄, β = W_β ℓ̄ (per block)", "x ← x + Attn(LN(x))", "x ← (1 + γ) ⊙ x + β", "x ← x + MLP(LN(x))"] } },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)" },
              { t: "add", span: 2 } ] },
            { t: "mlp", label: "3-layer GELU projector", call: ["concat(DINOv2, SigLIP) → 4,096", "p3", "c7"] } ],
          output: { label: "256 tokens per view" } },
        { mod: "llama", title: "Llama 2 7B", sub: "LoRA r = 32, bidirectional",
          input: { label: "Image, proprio, prompt, slots", caption: "K·D empty action embeddings + stop token" },
          rows: [
            { t: "mlp", label: "Proprio projector", call: ["2-layer GELU MLP → 1 token of 4,096", "p3", "c2"] },
            { t: "embed", label: "Token embedding", call: ["Action slots zeroed; only positions differ", "p3", "c5"],
              zoom: { k: "rows", title: "Input sequence", rows: ["BOS", "256 × views image tokens", "1 proprio token", "prompt tokens", "K·D empty action slots", "stop token"] } },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Bidirectional attention", side: "RoPE", call: ["32 heads, head dim 128; causal mask removed", "p7", "p1"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Attention (MHA at 7B)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden ⅔ · 4d (LLaMA)", "p7"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm", call: ["LM head removed", "p3"] } ],
          output: { label: "K·D slot hidden states" } },
        { mod: "head", title: "L1 action head", sub: "MLP-ResNet, ReLU", compact: true,
          input: { label: "K × (D × 4,096)", caption: "D slot states concatenated per step" },
          rows: [
            { t: "norm", label: "LayerNorm" },
            { t: "linear", label: "Linear 28,672 → 4,096", call: ["7 × 4,096 = 28,672 in (LIBERO)", "c1", "c4"] },
            { t: "block", n: "2", rows: [
              { t: "norm", label: "LayerNorm" },
              { t: "mlp", label: "Linear 4,096 · ReLU" },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "LayerNorm" },
            { t: "linear", label: "Linear 4,096 → D", call: ["D = 7 (LIBERO) or 14 (ALOHA)", "c4"],
              zoom: { k: "rows", title: "Head variants studied", rows: ["discrete: LM head, 256 bins", "L1 regression (OFT)", "diffusion: same MLP, 50 DDIM steps"] } } ],
          output: { label: "K continuous actions" } }
      ],
      links: [
        { from: "vis", to: "llama", toRow: "input", label: "image tokens" },
        { from: "llama", to: "head", toRow: "input", label: "slot states" }
      ]
    },
    modules: [
      { id: "vis", role: "vision-enc", name: "DINOv2 + SigLIP", sub: "per view · FiLM (OFT+)", col: 0, frozen: "lora", short: "Vision",
        stack: { rows: [
          { t: "in", label: "each view 224 × 224", dims: "1 third-person + up to 2 wrist", c: "data-1" },
          { t: "group", label: "two ViTs, same patches", rows: [
            { t: "attn", label: "DINOv2 ViT-L/14 (reg4)", note: "FiLM after attention, before the MLP, in every block (OFT+)" },
            { t: "attn", label: "SigLIP So400m/14", note: "FiLM after attention, before the MLP, in every block (OFT+)" } ] },
          { t: "film", label: "FiLM: γ, β = affine(mean language embedding)", side: "cond", note: "separate projector per block" },
          { t: "mlp", label: "Fused 3-layer GELU projector", dims: "→ 4,096" },
          { t: "out", label: "256 tokens per view", c: "data-1" } ],
          facts: [["Patches", ["256 per view, shared projector", "p1"]], ["Projector", ["3-layer MLP, GELU", "p3", "c7"]], ["FiLM", ["(1 + γ)·x + β on each hidden unit across all patches", "p2", "c3"]], ["FiLM params", ["456M (ALOHA OFT+)", "p4"]]] } },
      { id: "llama", role: "vlm", name: "Llama 2 7B", sub: "32 × 4096 · bidirectional", col: 1, frozen: "lora", main: true, params: "7B", short: "Llama 2",
        stack: { rows: [
          { t: "in", label: "[image | proprio | prompt | K·D empty slots | stop]", c: "data-2" },
          { t: "mlp", label: "Proprio projector: Linear → GELU → Linear", dims: "state → 4,096" },
          { t: "block", label: "Llama decoder block, LoRA r = 32", n: "32", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MHA · 32 heads · RoPE · no causal mask" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU" }, { t: "add", span: 2 } ] },
          { t: "out", label: "hidden states of the K·D slots", c: "data-3" } ],
          facts: [["Layers / width / heads", ["32 / 4,096 / 32", "p7"]], ["LoRA", ["rank 32, all linear layers, 111M params", "p4", "c6"]], ["Mask", ["bidirectional (patched transformers fork)", "p3", "c8"]], ["Slots", ["K·D zero embeddings; positions differ", "p3", "c5"]]] } },
      { id: "head", role: "action-head", name: "L1 MLP head", sub: "4 Linear · ReLU · LN", col: 2, frozen: false, short: "MLP head",
        stack: { rows: [
          { t: "in", label: "per step: D slot states concatenated", dims: "D × 4,096", c: "data-3" },
          { t: "norm", label: "LayerNorm" },
          { t: "linear", label: "Linear D·4,096 → 4,096 → ReLU" },
          { t: "block", label: "Residual MLP block", n: "2", rows: [{ t: "norm", label: "LayerNorm" }, { t: "mlp", label: "Linear 4,096 → 4,096 → ReLU" }, { t: "add", span: 2 }] },
          { t: "norm", label: "LayerNorm" },
          { t: "linear", label: "Linear 4,096 → D" },
          { t: "out", label: "K × D normalised actions", dims: "L1 loss", c: "data-3" } ],
          facts: [["Depth", ["4 Linear layers, ReLU", "p3", "c1"]], ["Width", ["4,096", "c1"]], ["Params", ["151M (LIBERO), 269M (ALOHA)", "p4"]], ["Loss", ["mean L1", "p1"]]] } }
    ],
    inputs: [
      { to: "vis", mod: "vision", label: "1–3 camera views", n: "256 tokens each", k: 5 },
      { to: "llama", mod: "lang", label: "instruction", n: "prompt tokens", k: 3 },
      { to: "llama", mod: "state", label: "proprio state", n: "1 token", k: 1 }
    ],
    outputs: [{ from: "head", mod: "action", label: "action chunk", n: "8 × 7 or 25 × 14", k: 5 }],
    links: [
      { from: "vis", to: "llama", kind: "prefix", label: "MLP → 4,096|256 tok / view" },
      { from: "llama", to: "head", kind: "feeds", label: "K·D slot states" }
    ],
    mask: { name: "Bidirectional (no mask)", ref: "p3", axes: [{ label: "images", short: "img", mod: "vision" }, { label: "q + prompt", short: "q+ℓ", mod: "lang" }, { label: "slots", short: "A", mod: "action" }], m: ["111", "111", "111"],
      note: "The causal mask is replaced by full attention, so every action slot sees every other slot and all inputs in one pass." },
    callouts: [
      "Paper App. A calls the head a <b>4-layer MLP (ReLU)</b>; the code builds it as LayerNorm → Linear → 2 pre-LayerNorm residual blocks → LayerNorm → Linear, i.e. 4 Linear layers with residual connections the paper does not mention.",
      "Bidirectional attention is not in the repo itself: pyproject pins a <b>patched transformers fork</b> “for bidirectional attn”.",
      "§II quotes latency as “0.07 ms” and “0.321 ms”; the efficiency table reports seconds (e.g. 0.0729 s)."
    ]
  });

  /* ------------------------------------------------------------------ CrossFormer */
  RB.arch.spec({
    id: "crossformer", method: "crossformer", name: "CrossFormer", year: 2024,
    figRef: "Doshi et al. Fig. 2 · §3.2–3.4 · App. B, Table 2", prov: "pretrain config, size detr",
    lede: "One causal transformer for arms, bimanual rigs, wheeled robots, quadrupeds and drones. Every sensor becomes tokens; each embodiment gets its own readout tokens, whose embeddings a per-embodiment linear head maps to an action chunk.",
    sources: {
      p1: { kind: "paper", ref: "Doshi et al. 2024, §3.2 (tokenizers)", url: "https://arxiv.org/abs/2408.11812" },
      p2: { kind: "paper", ref: "Doshi et al. 2024, §3.3 (readouts, heads, mask)", url: "https://arxiv.org/abs/2408.11812" },
      p3: { kind: "paper", ref: "Doshi et al. 2024, §3.4 and App. B, Table 2 (sizes, training)", url: "https://arxiv.org/abs/2408.11812" },
      p4: { kind: "paper", ref: "Doshi et al. 2024, §3.1 and App. A (data)", url: "https://arxiv.org/abs/2408.11812" },
      c1: { kind: "code", repo: "rail-berkeley/crossformer", path: "scripts/configs/pretrain_config.py", commit: "4a56b64", url: "https://github.com/rail-berkeley/crossformer/blob/4a56b64/scripts/configs/pretrain_config.py" },
      c2: { kind: "code", repo: "rail-berkeley/crossformer", path: "crossformer/model/components/transformer.py", commit: "4a56b64", url: "https://github.com/rail-berkeley/crossformer/blob/4a56b64/crossformer/model/components/transformer.py" },
      c3: { kind: "code", repo: "rail-berkeley/crossformer", path: "crossformer/model/components/vit_encoders.py", commit: "4a56b64", url: "https://github.com/rail-berkeley/crossformer/blob/4a56b64/crossformer/model/components/vit_encoders.py" },
      c4: { kind: "code", repo: "rail-berkeley/crossformer", path: "crossformer/model/components/film_conditioning_layer.py", commit: "4a56b64", url: "https://github.com/rail-berkeley/crossformer/blob/4a56b64/crossformer/model/components/film_conditioning_layer.py" },
      c5: { kind: "code", repo: "rail-berkeley/crossformer", path: "crossformer/model/crossformer_module.py", commit: "4a56b64", url: "https://github.com/rail-berkeley/crossformer/blob/4a56b64/crossformer/model/crossformer_module.py" },
      c6: { kind: "code", repo: "rail-berkeley/crossformer", path: "crossformer/model/components/action_heads.py", commit: "4a56b64", url: "https://github.com/rail-berkeley/crossformer/blob/4a56b64/crossformer/model/components/action_heads.py" },
      c7: { kind: "code", repo: "rail-berkeley/crossformer", path: "crossformer/model/components/tokenizers.py", commit: "4a56b64", url: "https://github.com/rail-berkeley/crossformer/blob/4a56b64/crossformer/model/components/tokenizers.py" },
      c8: { kind: "code", repo: "rail-berkeley/crossformer", path: "crossformer/data/utils/text_processing.py", commit: "4a56b64", url: "https://github.com/rail-berkeley/crossformer/blob/4a56b64/crossformer/data/utils/text_processing.py" }
    },
    summary: {
      pattern: ["Cross-embodiment transformer policy (readout tokens + per-embodiment heads)", "p2"],
      params: ["130M including ResNet-26 encoders and heads", "p3"],
      vision: ["ResNet-26 (ImageNet init) per camera type at 224 × 224 → 7 × 7 = 49 tokens; FiLM from language", "p1", "p3", "c1", "c3"],
      backbone: ["12 layers, 8 heads, width 512, MLP 2,048", "p3", "c2"],
      head: ["4 linear heads on readout tokens: single arm, navigation, bimanual, quadruped", "p2", "c1", "c6"],
      output: ["Single arm 4 × 7, nav 4 × 2, bimanual 100 × 14, quadruped 1 × 12", "p2", "c1"],
      attention: ["Block-causal over time; each readout group sees observations and itself only", "p2", "c5"],
      cond: ["Language via FiLM in the image encoders, or a goal image stacked on the channels", "p1", "c1"],
      steps: "One forward pass per control step",
      chunk: ["Chunk sizes follow prior work: 4, 4, 100, 1", "p2"],
      rate: ["5–15 Hz single arm, 4 Hz navigation, 20 Hz bimanual and quadruped", "p2"],
      latency: null,
      train: ["900K trajectories, 20 embodiments; 300K steps, batch 512, TPU v5e-256", "p3", "p4"]
    },
    blueprint: {
      headline: "CrossFormer: tokens in, readouts out",
      note: "Each image slot has its own ResNet-26 (shared across robots with the same camera type), language enters those ResNets through FiLM, and proprio values become one token each. Five timesteps of tokens plus readout groups go through a 12-layer block-causal transformer; each head reads only its own readouts.",
      towers: [
        { mod: "resnet", title: "ResNet-26 tokenizer", sub: "one per camera type, ImageNet init", compact: true,
          input: { label: "Image 224 × 224", caption: "goal image stacked on channels" },
          rows: [
            { t: "conv", label: "StdConv 7×7 /2 · GN · pool", call: ["Width 64, GroupNorm", "c3"] },
            { t: "block", n: "4", label: "stage: 2 bottleneck units", rows: [
              { t: "conv", label: "1×1 · 3×3 · 1×1 convs" },
              { id: "film", t: "film", label: "FiLM after stages 2–4", side: "FiLM", call: ["x · (1 + a) + b, zero-init", "c3", "c4"], zoom: { k: "rows", title: "FiLM on ResNet features", rows: ["USE sentence embedding e", "a, b = Dense(e), zero-init", "x ← x · (1 + a) + b", "same a, b at all 7 × 7 positions"] } } ] },
            { t: "linear", label: "Flatten 7 × 7 → Dense 512", call: ["49 tokens × 2,048 ch → 512", "c3", "c5"] } ],
          output: { label: "49 tokens per image" } },
        { mod: "tf", title: "Cross-embodied transformer", sub: "decoder-only, block-causal",
          input: { label: "5 steps × 427 tokens", caption: "obs + proprio + readout tokens" },
          rows: [
            { t: "embed", label: "+ learned position embedding", call: ["Context 2,135 tokens (5 steps)", "p3"],
              zoom: { k: "rows", title: "Tokens per timestep", rows: ["5 image slots × 49 = 245", "proprio 14 + 59 = 73", "readouts: 4 + 4 + 100 + 1 = 109", "245 + 73 + 109 = 427", "× 5 steps = 2,135"] } },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Block-causal attention", call: ["8 heads, width 512", "p3", "c2"], zoom: { k: "heads", q: 8, kv: 8, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 2,048", "p3", "c2"], zoom: { k: "mlp", act: "GELU", d: "512", ff: "2,048", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" } ],
          output: { label: "readout embeddings" } },
        { mod: "heads", title: "Action heads", sub: "one Dense per action type", compact: true,
          input: { label: "own readout tokens", caption: "one token per predicted step" },
          rows: [
            { t: "linear", label: "Dense 512 → action dim", call: ["Arm 7 · nav 2 · bimanual 14 · legs 12", "p2", "c1"] },
            { t: "linear", label: "L1 loss per head", call: ["Readouts = chunk: 4, 4, 100, 1", "c1"] } ],
          output: { label: "chunk for that robot" } }
      ],
      links: [
        { from: "resnet", to: "tf", toRow: "input", label: "image tokens" },
        { from: "tf", to: "heads", toRow: "input", label: "readouts" }
      ]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet-26 + FiLM", sub: "per camera type · 49 tok", col: 0, frozen: false, short: "ResNet-26",
        stack: { rows: [
          { t: "in", label: "image 224 × 224 (+ goal on channels)", c: "data-1" },
          { t: "conv", label: "StdConv 7×7 /2 → GroupNorm → ReLU → max pool", dims: "64 ch" },
          { t: "block", label: "Stage of 2 bottleneck units", n: "4", rows: [{ t: "conv", label: "StdConv 1×1 → 3×3 → 1×1, GroupNorm" }, { t: "film", label: "FiLM after stages 2, 3, 4", side: "cond" }] },
          { t: "linear", label: "flatten 7 × 7, Dense → 512" },
          { t: "out", label: "49 tokens per image", c: "data-1" } ],
          facts: [["Language", ["universal-sentence-encoder-large/5 → FiLM (not nav)", "c1", "c8"]], ["Blocks", ["(2, 2, 2, 2) bottleneck units", "c3"]], ["Init", ["ImageNet", "p3", "c1"]], ["Norm", ["GroupNorm, weight-standardised convs", "c3"]], ["Encoders", ["primary, high, nav, left and right wrist", "c1"]]] } },
      { id: "tf", role: "net", roleLabel: "Policy transformer", name: "Cross-embodied transformer", sub: "12 × 512 · 8 heads", col: 1, frozen: false, main: true, short: "Transformer",
        stack: { rows: [
          { t: "in", label: "[obs, proprio, readouts] × 5 steps", dims: "2,135 tokens", c: "data-4" },
          { t: "embed", label: "Dense → 512 + position embedding" },
          { t: "block", label: "Pre-norm transformer block", n: "12", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 8 heads · block-causal" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 512 → 2048 → 512 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final LayerNorm" },
          { t: "out", label: "readout embeddings", c: "data-3" } ],
          facts: [["Layers / heads / width / MLP", ["12 / 8 / 512 / 2,048", "p3", "c2"]], ["Context", ["2,135 tokens = 5 timesteps", "p3"]], ["Dropout", ["0.1", "c2"]], ["Missing sensors", ["masked; token groups keep fixed slots", "p3"]]] } },
      { id: "heads", role: "action-head", name: "4 linear heads", sub: "L1 · per action type", col: 2, frozen: false, short: "Heads",
        stack: { rows: [
          { t: "in", label: "readout tokens of that head", c: "data-3" },
          { t: "linear", label: "Dense 512 → action dim, per readout" },
          { t: "out", label: "action chunk", dims: "4 × 7 · 4 × 2 · 100 × 14 · 1 × 12", c: "data-3" } ],
          facts: [["Heads", ["single arm, navigation, bimanual, quadruped", "p2", "c1"]], ["Pooling", ["none: one readout per action step", "c1", "c6"]], ["Loss", ["L1", "p2"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "lang", label: "instruction", n: "USE → FiLM", k: 2 },
      { to: "resnet", mod: "vision", label: "≤ 5 cameras", n: "49 tok each", k: 4 },
      { to: "tf", mod: "state", label: "proprio", n: "1 token per value", k: 3 }
    ],
    outputs: [{ from: "heads", mod: "action", label: "embodiment's chunk", n: "4 to 100 steps", k: 5 }],
    links: [
      { from: "resnet", to: "tf", kind: "prefix", label: "49 tokens / image" },
      { from: "tf", to: "heads", kind: "feeds", label: "readout tokens" }
    ],
    mask: { name: "Readouts see observations only", ref: "p2", axes: [{ label: "obs ≤ t", short: "obs", mod: "vision" }, { label: "arm readouts", short: "R₁", mod: "action" }, { label: "bimanual RO", short: "R₂", mod: "action" }], m: ["100", "110", "101"],
      note: "Observations attend causally over timesteps and never to readouts; each readout group sees current and past observations and itself, not other groups." },
    callouts: [
      "Paper §3.2 says <b>four</b> image encoders (workspace, navigation, two wrists); the pretraining config builds <b>five</b> image tokenizers (primary, high, nav, left wrist, right wrist), and the nav encoder has no FiLM.",
      "Training time is reported as <b>47 hours</b> in §3.4 but <b>80 hours</b> in App. B for the same TPU v5e-256 run.",
      "Heads project each readout token straight to one action step; the paper's “readout count = chunk size” is literal (100 bimanual readouts)."
    ]
  });

  /* ------------------------------------------------------------------ UniAct */
  RB.arch.spec({
    id: "uniact", method: "uniact", name: "UniAct", year: 2025,
    figRef: "Zheng et al. Fig. 2 · §3.2–3.3 · §4.1 · App. A", prov: "0.5B release + Bridge MLP head",
    lede: "A 0.5B VLM picks one of 256 learned “universal actions” with Gumbel-softmax. A tiny embodiment-specific MLP turns that 128-d code plus ResNet-18 image features into the robot's own commands.",
    sources: {
      p1: { kind: "paper", ref: "Zheng et al. 2025, §3.1–3.2 (codebook, Gumbel-softmax)", url: "https://arxiv.org/abs/2501.10105" },
      p2: { kind: "paper", ref: "Zheng et al. 2025, §3.3 (heterogeneous heads)", url: "https://arxiv.org/abs/2501.10105" },
      p3: { kind: "paper", ref: "Zheng et al. 2025, §4.1 (implementation)", url: "https://arxiv.org/abs/2501.10105" },
      p4: { kind: "paper", ref: "Zheng et al. 2025, App. A (training details)", url: "https://arxiv.org/abs/2501.10105" },
      p5: { kind: "paper", ref: "Zheng et al. 2025, §4.3–4.4 (fast adaptation, ACT head)", url: "https://arxiv.org/abs/2501.10105" },
      p6: { kind: "paper", ref: "Qwen Team 2024 (Qwen2), §2.2 and Table 1", url: "https://arxiv.org/abs/2407.10671" },
      p7: { kind: "paper", ref: "Li et al. 2024 (LLaVA-OneVision), §3.1 and Fig. 3", url: "https://arxiv.org/abs/2408.03326" },
      c1: { kind: "code", repo: "2toinf/UniAct", path: "models/UniAct_V1.py", commit: "bde6d2c", url: "https://github.com/2toinf/UniAct/blob/bde6d2c/models/UniAct_V1.py" },
      c2: { kind: "code", repo: "2toinf/UniAct", path: "models/decoders/MLP_decoder.py", commit: "bde6d2c", url: "https://github.com/2toinf/UniAct/blob/bde6d2c/models/decoders/MLP_decoder.py" },
      c3: { kind: "code", repo: "2toinf/UniAct", path: "models/model_config.py", commit: "bde6d2c", url: "https://github.com/2toinf/UniAct/blob/bde6d2c/models/model_config.py" }
    },
    summary: {
      pattern: ["VLM + discrete universal-action codebook + per-embodiment heads", "p1"],
      params: ["0.5B (LLaVA-OneVision-0.5B); a new head for fast adaptation trains 4M", "p3", "p5"],
      vision: ["VLM: SigLIP at 384 × 384 (729 tokens). Heads: ResNet-18 at 224 × 224, trained jointly", "p4", "p7", "c1"],
      backbone: ["Qwen2-0.5B: 24 layers, width 896, GQA 14 / 2 heads", "p6", "c1"],
      head: ["Per-embodiment MLP on [mean ResNet feature 512 ‖ u* 128]; ACT head for bimanual", "p2", "p5", "c2"],
      output: ["Bridge / LIBERO head: 4 future 7-DoF actions", "c2", "c3"],
      attention: ["Causal (Qwen2 decoder); the last token's hidden state picks the code", "p6", "c1"],
      cond: ["Universal action u* concatenated with pooled image features", "p2", "c2"],
      steps: "One VLM pass + one head pass per step",
      chunk: ["4 actions (MLP_1RGB_7DoFs_4FutureAction)", "c2"],
      rate: null, latency: null,
      train: ["≈ 1M demos, 28 embodiments; 64 A100 × 10 days, batch 1,024, 500K iters", "p3", "p4"]
    },
    blueprint: {
      headline: "UniAct: one code, many robots",
      note: "LLaVA-OneVision reads the image and instruction; the hidden state of the last token is projected to 256 logits, and Gumbel-softmax mixes the 128-d codebook vectors into one universal action u*. A per-embodiment MLP adds the robot's own visual details from a separate ResNet-18.",
      towers: [
        { mod: "vlm", title: "LLaVA-OneVision-0.5B", sub: "universal action extractor",
          input: { label: "Image 384 × 384 + text", caption: "third-person view, instruction" },
          rows: [
            { t: "embed", label: "SigLIP So400m/14", call: ["729 tokens per 384 × 384 image", "p7"] },
            { t: "mlp", label: "2-layer MLP projector", call: ["Vision features → word embeddings", "p7"] },
            { t: "embed", label: "Qwen2 token embedding", call: ["Vocabulary 151,646 · width 896", "p6"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal GQA (QKV bias)", side: "RoPE", call: ["14 query heads, 2 KV heads, head 64", "p6"], zoom: { k: "heads", q: 14, kv: 2, hd: 64, title: "Grouped-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Intermediate size 4,864", "p6"], zoom: { k: "glu", act: "SiLU", d: "896", ff: "4,864", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" } ],
          output: { label: "last-token hidden state (896)" } },
        { mod: "code", title: "Universal action codebook", sub: "Gumbel VQ", compact: true,
          input: { label: "hidden state h", caption: "896-d" },
          rows: [
            { t: "linear", label: "Linear 896 → 256 logits", call: ["p(u | o, g) over 256 codes", "p1", "c1"] },
            { t: "mlp", label: "Gumbel-softmax, τ", call: ["τ: 2.0 → 0.1 (train), 1.4 (release)", "c1"],
              zoom: { k: "rows", title: "Picking u*", rows: ["logits = W h", "add Gumbel noise ε", "w = softmax((log p + ε) / τ)", "u* = Σ wᵢ uᵢ (soft)", "argmax code (fast adaptation)"] } },
            { t: "embed", label: "Codebook U", call: ["256 codes × 128-d", "p3", "c1"] } ],
          output: { label: "universal action u* (128)" } },
        { mod: "head", title: "Embodiment head", sub: "Bridge / LIBERO MLP", compact: true,
          input: { label: "Image 224 × 224", caption: "same frame, own backbone" },
          rows: [
            { t: "conv", label: "ResNet-18 (ImageNet)", call: ["Trained during pretraining", "p4", "c1"] },
            { t: "pool", label: "Mean over positions, views", call: ["→ 512", "c2"] },
            { id: "cat", t: "linear", label: "Concat [512 ‖ u*]", call: ["→ 640", "c2"] },
            { t: "mlp", label: "MLP 640 → 112 → 28", call: ["GELU; 28 = 4 steps × 7-DoF", "c2"],
              zoom: { k: "rows", title: "Heads used in the paper", rows: ["MLP per training domain", "new MLP per robot (4M)", "ACT head (AIRBOT, LIBERO)"] } } ],
          output: { label: "4 × 7 actions (Huber loss)" } }
      ],
      links: [
        { from: "vlm", to: "code", toRow: "input", label: "last-token state" },
        { from: "code", to: "head", toRow: "cat", label: "u*" }
      ]
    },
    modules: [
      { id: "vlm", role: "vlm", roleLabel: "Universal action extractor", name: "LLaVA-OV-0.5B", sub: "SigLIP + Qwen2-0.5B", col: 0, frozen: false, main: true, params: "0.5B", short: "LLaVA-OV",
        stack: { rows: [
          { t: "in", label: "third-person image + instruction", c: "data-1" },
          { t: "embed", label: "SigLIP So400m/14 → 2-layer MLP projector", dims: "729 tokens per 384² crop" },
          { t: "block", label: "Qwen2 decoder block", n: "24", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "GQA 14 / 2 heads · RoPE · QKV bias" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 896 → 4,864 → 896" }, { t: "add", span: 2 } ] },
          { t: "out", label: "hidden state of the last token", dims: "896", c: "data-5" } ],
          facts: [["LLM", ["Qwen2-0.5B: 24 layers, width 896", "p6"]], ["Heads", ["14 query, 2 KV, head 64", "p6"]], ["Vision", ["SigLIP, 384 × 384", "p4", "p7"]], ["Init", ["llava-onevision-qwen2-0.5b-ov", "p3", "c1"]]] } },
      { id: "code", role: "latent", roleLabel: "Universal action space", name: "Gumbel-VQ codebook", sub: "256 × 128", col: 1, frozen: false, short: "Codebook",
        stack: { rows: [
          { t: "in", label: "h (896)", c: "data-5" },
          { t: "linear", label: "pre_proj: Linear 896 → 256" },
          { t: "mlp", label: "Gumbel-softmax (soft) or argmax (hard)" },
          { t: "embed", label: "weighted sum of 256 × 128 codes" },
          { t: "out", label: "u* (128)", c: "data-5" } ],
          facts: [["Size", ["256 codes × 128-d", "p3", "c1"]], ["Selection", ["Gumbel-softmax with decaying τ", "p1", "c1"]], ["Regulariser", ["entropy term, weight 5e-4", "c1"]], ["Fast adaptation", ["codebook and VLM frozen, hard argmax", "p5", "c1"]]] } },
      { id: "head", role: "action-head", name: "Embodiment MLP head", sub: "ResNet-18 + MLP", col: 2, frozen: false, short: "Head",
        stack: { rows: [
          { t: "in", label: "image 224 × 224 (+ proprio in some heads)", c: "data-1" },
          { t: "conv", label: "ResNet-18 features, mean-pooled", dims: "512" },
          { t: "linear", label: "concat u*", dims: "640" },
          { t: "mlp", label: "timm Mlp: 640 → 112 → 28, GELU" },
          { t: "out", label: "4 × 7 actions", c: "data-3" } ],
          facts: [["Backbone", ["ResNet-18 (resnet18.a1_in1k)", "p4", "c1"]], ["Hidden", ["4 × output size = 112", "c2"]], ["Loss", ["Huber, δ = 0.1", "c1"]], ["Domains", ["one head per dataset (e.g. Bridge, LIBERO)", "p2", "c3"]]] } }
    ],
    inputs: [
      { to: "vlm", mod: "vision", label: "third-person image", n: "384 × 384", k: 4 },
      { to: "vlm", mod: "lang", label: "instruction", n: "text tokens", k: 3 },
      { to: "head", mod: "vision", label: "image for ResNet-18", n: "224 × 224", k: 3 }
    ],
    outputs: [{ from: "head", mod: "action", label: "robot-native actions", n: "4 × 7", k: 4 }],
    links: [
      { from: "vlm", to: "code", kind: "latent", label: "last-token state|→ 256 logits" },
      { from: "code", to: "head", kind: "feeds", label: "u* (128)" }
    ],
    callouts: [
      "Paper §3.2 describes Gumbel-softmax with a temperature that decays during training; the released inference model fixes <b>τ = 1.4</b> (initial = final) and uses the soft mixture unless fast adaptation turns on hard argmax.",
      "The paper leaves the head loss open (cross-entropy, MSE, Huber or diffusion); the released training loss is <b>Huber with δ = 0.1</b>.",
      "OpenWAM-style reading: the codebook is a learned discrete <b>action</b> space supervised by real actions, unlike latent actions inferred from frame differences (LAPA, IGOR)."
    ]
  });

  /* ------------------------------------------------------------------ SpatialVLA */
  RB.arch.spec({
    id: "spatialvla", method: "spatialvla", name: "SpatialVLA", year: 2025, parent: "openvla",
    diffRows: ["params", "vision", "backbone", "output", "chunk", "rate", "train"],
    figRef: "Qu et al. Fig. 2–3 · §III-A · App. B, Table VII", prov: "pretraining script defaults",
    lede: "PaliGemma 2 with two spatial add-ons: ZoeDepth back-projects every patch to egocentric 3D and adds a position embedding to SigLIP's tokens, and actions become 3 tokens per step from Gaussian-adaptive grids.",
    sources: {
      p1: { kind: "paper", ref: "Qu et al. 2025, §III-A (Ego3D PE, adaptive action grids)", url: "https://arxiv.org/abs/2501.15830" },
      p2: { kind: "paper", ref: "Qu et al. 2025, §IV (implementation details)", url: "https://arxiv.org/abs/2501.15830" },
      p3: { kind: "paper", ref: "Qu et al. 2025, App. B and Table VII (architecture, grids)", url: "https://arxiv.org/abs/2501.15830" },
      p4: { kind: "paper", ref: "Qu et al. 2025, App. C–D (ZoeDepth, pre-training)", url: "https://arxiv.org/abs/2501.15830" },
      p5: { kind: "paper", ref: "Qu et al. 2025, §III-B (pre- and post-training)", url: "https://arxiv.org/abs/2501.15830" },
      p6: { kind: "paper", ref: "Gemma Team 2024 (Gemma 2), §2 and Table 1", url: "https://arxiv.org/abs/2408.00118" },
      c1: { kind: "code", repo: "SpatialVLA/SpatialVLA", path: "model/modeling_spatialvla.py", commit: "18fd74b", url: "https://github.com/SpatialVLA/SpatialVLA/blob/18fd74b/model/modeling_spatialvla.py" },
      c2: { kind: "code", repo: "SpatialVLA/SpatialVLA", path: "scripts/action_config.json", commit: "18fd74b", url: "https://github.com/SpatialVLA/SpatialVLA/blob/18fd74b/scripts/action_config.json" },
      c3: { kind: "code", repo: "SpatialVLA/SpatialVLA", path: "train/spatialvla_pretrain.py", commit: "18fd74b", url: "https://github.com/SpatialVLA/SpatialVLA/blob/18fd74b/train/spatialvla_pretrain.py" },
      c4: { kind: "code", repo: "SpatialVLA/SpatialVLA", path: "scripts/spatialvla_4b_pretrain/torchrun_pretrain.sh", commit: "18fd74b", url: "https://github.com/SpatialVLA/SpatialVLA/blob/18fd74b/scripts/spatialvla_4b_pretrain/torchrun_pretrain.sh" },
      c5: { kind: "code", repo: "SpatialVLA/SpatialVLA", path: "model/configuration_spatialvla.py", commit: "18fd74b", url: "https://github.com/SpatialVLA/SpatialVLA/blob/18fd74b/model/configuration_spatialvla.py" },
      c6: { kind: "code", repo: "Physical-Intelligence/openpi", path: "src/openpi/models/siglip.py", commit: "215abfb", url: "https://github.com/Physical-Intelligence/openpi/blob/215abfb/src/openpi/models/siglip.py" }
    },
    summary: {
      pattern: ["Autoregressive token VLA", "p1"],
      params: ["3.5B", "p2"],
      vision: ["SigLIP (27 × 1,152) at 224 × 224 → 256 patches, plus Ego3D position embedding from ZoeDepth", "p3", "c1"],
      backbone: ["Gemma 2 (PaliGemma 2): 26 layers, width 2,304, GQA 8 / 4 heads", "p3", "p6"],
      head: ["None: LM head over 8,194 spatial action tokens sharing the embedding table", "p3", "c1"],
      output: ["3 tokens per step (translation, rotation, gripper); 4 steps = 12 tokens", "p1", "p2"],
      attention: null,
      cond: ["Ego3D: sin/cos(8 freqs) of back-projected xyz → MLP → added to SigLIP patches", "p1", "p3", "c1", "c3"],
      steps: ["12 autoregressive tokens per chunk", "p2"],
      chunk: ["T = 4 actions per inference, ensembled", "p2", "c4"],
      rate: ["≈ 20 Hz on one RTX 4090, 8.5 GB", "p2"],
      latency: null,
      train: ["1.1M episodes (OXE subset + RH20T); 64 A100 × 10 days, batch 2,048; 160K + 40K steps", "p2", "p4"]
    },
    changes: [
      "Backbone switches from Prismatic (DINOv2 ‖ SigLIP + Llama 2 7B) to <b>PaliGemma 2</b> (SigLIP + Gemma 2, 3.5B).",
      "<b>Ego3D position encoding</b>: frozen ZoeDepth depth, back-projected with the intrinsics, is encoded and added to every SigLIP patch.",
      "<b>3 tokens per step</b> instead of 7: translation (φ, θ, r) and rotation (roll, pitch, yaw) are each one joint grid token, plus a gripper token.",
      "Bins are <b>Gaussian equal-probability</b> grids fitted to the data, and can be re-fitted for a new robot (spatial embedding adaption).",
      "<b>4-action chunks</b> (12 tokens) per call; ≈ 20 Hz on an RTX 4090."
    ],
    blueprint: {
      headline: "SpatialVLA: depth-aware tokens, 3D action grids",
      note: "The same 224² image goes to SigLIP and to a frozen ZoeDepth. Each patch's 2 × 2 sub-patch 3D points are frequency-encoded and mapped by an MLP to 1,152-d, then added to the SigLIP token. Gemma 2 then writes 3 spatial action tokens per step from an 8,194-entry grid vocabulary.",
      towers: [
        { mod: "zoe", title: "ZoeDepth + Ego3D MLP", sub: "depth frozen, MLP trained", compact: true,
          input: { label: "Image 224 × 224", caption: "camera intrinsics K" },
          rows: [
            { t: "conv", label: "ZoeDepth (NYU + KITTI)", call: ["Frozen; 8.6 % of parameters", "p4", "c4"] },
            { t: "linear", label: "Back-project with K", call: ["2 × 2 sub-patches × xyz = 12", "c1", "c3"] },
            { t: "embed", label: "x, sin, cos of 8 freqs", call: ["12 × 17 = 204 inputs", "p3", "c1"] },
            { t: "mlp", label: "Linear · LN · ReLU · Linear", call: ["204 → 1,152 → 1,152", "p3", "c1"],
              zoom: { k: "rows", title: "Ego3D position encoding", rows: ["depth D = ZoeDepth(I)", "p = K⁻¹ · [u, v, 1] · D", "average per 2 × 2 sub-patch", "γ(p): x, sin 2ᵏx, cos 2ᵏx", "MLP → P′ (1,152)", "O₃d = X + P′"] } } ],
          output: { label: "3D position embedding P′" } },
        { mod: "siglip", title: "SigLIP So400m/14", sub: "PaliGemma 2 vision tower", compact: true,
          input: { label: "Image patches 14 × 14", caption: "224 / 14 = 16 → 256 patches" },
          rows: [
            { t: "embed", label: "Patch embedding layer", call: ["Embedding dimension of 1,152", "p3"] },
            { t: "block", n: "27", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["16 heads (So400m)", "c6"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 4,304", "c6"] },
              { t: "add", span: 2 } ] },
            { id: "ego", t: "embed", label: "+ Ego3D position embedding", side: "cond" },
            { t: "linear", label: "Projector 1,152 → 2,304", call: ["then ÷ √2,304", "p3", "c1"] } ],
          output: { label: "256 spatial image tokens" } },
        { mod: "gemma", title: "Gemma 2 (2B)", sub: "PaliGemma 2 language model",
          input: { label: "Image tokens + instruction", caption: "then 12 action tokens" },
          rows: [
            { t: "embed", label: "Token + spatial embedding", call: ["8,194 action embeddings, text embeddings frozen", "p3", "p5"],
              zoom: { k: "rows", title: "Adaptive action grids", rows: ["normalise to [−1, 1]", "Δxyz → polar (φ, θ, r)", "fit a Gaussian per variable", "bins θ 16, φ 32, r 8", "roll, pitch, yaw 16 each", "4,096 + 4,096 + 2 = 8,194 tokens"] } },
            { t: "block", n: "26", rows: [
              { t: "norm", label: "RMSNorm (pre)" },
              { t: "attn", label: "GQA, local ↔ global", side: "RoPE", call: ["8 heads, 4 KV heads, head 256", "p6"], zoom: { k: "heads", q: 8, kv: 4, hd: 256, title: "Grouped-query attention" } },
              { t: "norm", label: "RMSNorm (post)" },
              { t: "add", span: 3 },
              { t: "norm", label: "RMSNorm (pre)" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Feedforward dim 18,432", "p6"], zoom: { k: "glu", act: "GELU", d: "2,304", ff: "18,432", title: "Feed forward (GeGLU)" } },
              { t: "norm", label: "RMSNorm (post)" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head", call: ["3 tokens per step: ΔT, ΔR, gripper", "p1"] } ],
          output: { label: "12 tokens → 4 actions" } }
      ],
      links: [
        { from: "zoe", to: "siglip", toRow: "ego", label: "P′" },
        { from: "siglip", to: "gemma", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "zoe", role: "net", roleLabel: "Depth + 3D encoding", name: "ZoeDepth + Ego3D", sub: "frozen depth · MLP", col: 0, frozen: "partial", short: "Ego3D",
        stack: { rows: [
          { t: "in", label: "image 224 × 224 + intrinsics", c: "data-1" },
          { t: "conv", label: "ZoeDepthForDepthEstimation (frozen)", dims: "→ depth map" },
          { t: "linear", label: "back-project, average per 2 × 2 sub-patch", dims: "12 per patch" },
          { t: "embed", label: "frequency encoding, 8 bands (+ identity)", dims: "204" },
          { t: "mlp", label: "Linear → LayerNorm → ReLU → Linear", dims: "→ 1,152" },
          { t: "out", label: "P′ per patch", c: "data-1" } ],
          facts: [["Depth model", ["ZoeDepth NYU+KITTI, fixed", "p4", "c4"]], ["Frequencies", ["8", "c3"]], ["Sub-patch grid", ["2 × 2 (pretraining default)", "c3"]], ["MLP", ["204 → 1,152 → 1,152", "p3"]]] } },
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "27 × 1152 · + Ego3D", col: 1, frozen: false, short: "SigLIP",
        stack: { rows: [
          { t: "in", label: "image 224 × 224", c: "data-1" },
          { t: "embed", label: "patch embed 14 × 14", dims: "→ 256 × 1152" },
          { t: "block", label: "ViT block", n: "27", rows: [{ t: "attn", label: "MHA · 16 heads" }, { t: "ffn", label: "MLP 1152 → 4304" }] },
          { t: "add", label: "+ Ego3D position embedding", side: "cond" },
          { t: "linear", label: "projector 1152 → 2304, ÷ √2304" },
          { t: "out", label: "256 image tokens", c: "data-2" } ],
          facts: [["Layers / width", ["27 / 1,152", "p3"]], ["Projector", ["single Linear 1,152 → 2,304", "p3"]], ["Tokens", ["256 per image (one third-person camera)", "p2", "p3"]]] } },
      { id: "gemma", role: "vlm", name: "Gemma 2 (PaliGemma 2)", sub: "26 × 2304 · GQA 8/4", col: 2, frozen: false, main: true, short: "Gemma 2",
        stack: { rows: [
          { t: "in", label: "[image tokens | instruction | action tokens]", c: "data-2" },
          { t: "embed", label: "token embedding; spatial tokens use their own table", dims: "8,194 action ids" },
          { t: "block", label: "Gemma 2 decoder block", n: "26", rows: [
            { t: "norm", label: "RMSNorm pre + post" }, { t: "attn", label: "GQA 8 / 4 · sliding 4,096 ↔ global" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm pre + post" }, { t: "ffn", label: "GeGLU, feedforward 18,432" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "out", label: "3 tokens per step, 4 steps", dims: "de-tokenise by grid centres", c: "data-3" } ],
          facts: [["Layers / width", ["26 / 2,304", "p3", "p6"]], ["Heads", ["8 query, 4 KV, head size 256", "p6"]], ["Attention", ["alternating sliding-window 4,096 and global", "p6"]], ["Text embeddings", ["frozen in pretraining", "p5"]], ["Action vocab", ["8,194 (θ 16 · φ 32 · r 8 + 16³ + 2)", "p3", "c2"]]] } }
    ],
    inputs: [
      { to: "zoe", mod: "vision", label: "image + intrinsics", n: "224 × 224", k: 3 },
      { to: "siglip", mod: "vision", label: "same image", n: "256 patches", k: 4 },
      { to: "gemma", mod: "lang", label: "instruction", n: "text tokens", k: 3 }
    ],
    outputs: [{ from: "gemma", mod: "action", label: "spatial action tokens", n: "4 × 3 = 12", k: 4 }],
    links: [
      { from: "zoe", to: "siglip", kind: "feeds", label: "Ego3D P′|added to patches" },
      { from: "siglip", to: "gemma", kind: "prefix", label: "Linear → 2304|256 tokens" }
    ],
    callouts: [
      "Paper Table VII lists the Ego3D MLP input as <b>204</b> (2 × 2 sub-patches, 8 frequencies); the model config class defaults to <b>ego3d_patch_reso = 4</b> (816 inputs), while the pretraining script's default is 2.",
      "App. C speaks of adding action tokens to a “<b>128k</b> vocabulary”; Gemma 2's tokenizer has <b>256,128</b> entries (Gemma 2 Table 1).",
      "App. B gives the rotation bin range as “[−1, −1]”, evidently a typo for [−1, 1]."
    ]
  });
})();
