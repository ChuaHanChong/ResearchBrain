/* Architecture specs, topic B4 (generalist policies and VLAs, part A): Gato, VIMA, RT-1, RT-2, Octo, OpenVLA, RDT-1B.
   Numbers from the papers and the official code; see sources. RT-X is covered by callouts in RT-1 and RT-2. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ Gato */
  RB.arch.spec({
    id: "gato", method: "gato", name: "Gato", year: 2022,
    figRef: "Reed et al. Figs. 2, 3, 16 · §2 · App. B, C, G", prov: "1.18B model (Table 5)",
    lede: "One decoder-only transformer reads every modality as tokens: text, image patches, joint values and actions share one sequence and one set of weights, and actions come out as next tokens.",
    sources: {
      p1: { kind: "paper", ref: "Reed et al. 2022, §2.1–2.4 (tokens, embedding, training, deployment)", url: "https://arxiv.org/abs/2205.06175" },
      p2: { kind: "paper", ref: "Reed et al. 2022, App. C.1–C.2, Table 5 (hyperparameters, ResNet block)", url: "https://arxiv.org/abs/2205.06175" },
      p3: { kind: "paper", ref: "Reed et al. 2022, App. B and C.3 (value tokens, position encodings)", url: "https://arxiv.org/abs/2205.06175" },
      p4: { kind: "paper", ref: "Reed et al. 2022, App. G (real-robot inference)", url: "https://arxiv.org/abs/2205.06175" },
      p5: { kind: "paper", ref: "Reed et al. 2022, App. D (pretraining setup)", url: "https://arxiv.org/abs/2205.06175" }
    },
    summary: {
      pattern: ["Autoregressive token VLA", "p1"],
      params: ["1.18B (the paper also trains 364M and 79M)", "p2"],
      vision: ["16 × 16 patches, pixels scaled to [−1, 1] ÷ 4, each embedded by one ResNet v2 block", "p1", "p2"],
      backbone: ["Decoder-only transformer: 24 layers, width 2,048, 16 heads, GEGLU 8,192", "p2"],
      head: ["No separate head: next-token logits over the shared vocabulary (shared embedding)", "p2"],
      output: ["Tokens: text in [0, 32,000); actions in 1,024 bins at [32,000, 33,024)", "p1"],
      attention: ["Causal over a 1,024-token window", "p1"],
      cond: ["Prompt: a demonstration episode prepended to 25 % of training sequences", "p1"],
      steps: ["One token per pass; on the robot all action tokens of a step in one pass", "p1", "p4"],
      chunk: ["One timestep of actions per call", "p1"],
      rate: ["20 Hz robot; the 1.18B model overran it by ≈ 0.01 s on an RTX 3090", "p4"],
      latency: null,
      train: ["604 tasks; 1M steps, batch 512, 16 × 16 TPU v3 slice, ≈ 4 days", "p1"]
    },
    blueprint: {
      headline: "Gato: everything is a token",
      note: "Image patches go through one ResNet block; every other value is looked up in a single embedding table. The 24-layer causal transformer then predicts the next token, and only text and action tokens carry loss.",
      towers: [
        { mod: "resnet", title: "ResNet patch embedder", sub: "one v2 block per patch", compact: true,
          input: { label: "Image patch 16 × 16", caption: "raster order, pixels ÷ 4" },
          rows: [
            { t: "group", label: "ResNet v2 block", rows: [
              { t: "norm", label: "GroupNorm · GELU", call: ["GroupNorm with 32 groups", "p2"] },
              { t: "conv", label: "Convolution" },
              { t: "norm", label: "GroupNorm · GELU" },
              { t: "conv", label: "Convolution" },
              { t: "add", span: 4 } ] },
            { t: "embed", label: "+ row / column position", call: ["Row and column tables of 128 bins", "p3"] } ],
          output: { label: "one embedding per patch" } },
        { mod: "gato", title: "Gato transformer", sub: "decoder-only, 1.18B",
          input: { label: "Token sequence", caption: "[prompt | obs₁ | ‘|’ | a₁ | obs₂ …] ≤ 1,024" },
          rows: [
            { t: "embed", label: "Lookup embedding", call: ["Vocab 33,024: 32,000 text + 1,024 bins", "p1"], callDy: 6,
              zoom: { k: "rows", title: "Continuous value → token", rows: ["joint value or torque x", "μ-law: μ = 100, M = 256", "clip to [−1, 1]", "1,024 uniform bins", "shift by 32,000 → token id"] } },
            { t: "embed", label: "+ local position encoding", call: ["Index within a timestep", "p3"], callDy: -6 },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "LayerNorm (pre-norm)" },
              { t: "attn", label: "Causal self-attention", call: ["16 heads, key/value size 128", "p2"], zoom: { k: "heads", q: 16, kv: 16, hd: 128, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward (GEGLU)", call: ["Hidden size 8,192 (Table 5)", "p2"], zoom: { k: "glu", act: "GELU", d: "2,048", ff: "8,192", title: "Feed forward (GEGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Next-token logits", call: ["Loss only on text and action tokens", "p1"] } ],
          output: { label: "next token: text or action bin" } }
      ],
      links: [{ from: "resnet", to: "gato", toRow: "input", label: "patch embeddings" }]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet patch embed", sub: "1 v2 block · GN · GELU", col: 0, frozen: false, short: "ResNet block",
        stack: { rows: [
          { t: "in", label: "image patch 16 × 16", dims: "pixels in [−1, 1], ÷ √16", c: "data-1" },
          { t: "group", label: "ResNet v2 block (pre-activation)", rows: [
            { t: "norm", label: "GroupNorm (32 groups) → GELU" }, { t: "conv", label: "convolution" },
            { t: "norm", label: "GroupNorm (32 groups) → GELU" }, { t: "conv", label: "convolution" }, { t: "add", span: 4 } ] },
          { t: "embed", label: "+ learned row and column position", dims: "128 bins each; random within interval in training" },
          { t: "out", label: "patch token embedding", dims: "width 2,048", c: "data-1" } ],
          facts: [["Patch size", ["16 × 16", "p1"]], ["Normalisation", ["GroupNorm, 32 groups (not LayerNorm)", "p2"]], ["Activation", ["GELU (not ReLU)", "p2"]], ["Patch position", ["row and column tables, 128 bins", "p3"]]] } },
      { id: "gato", role: "vlm", roleLabel: "Sequence model", name: "Gato transformer", sub: "24 × 2048 · 16 heads", col: 1, frozen: false, main: true, params: "1.18B", short: "Transformer",
        stack: { rows: [
          { t: "in", label: "[text | patches | values | ‘|’ | actions] per step", dims: "≤ 1,024 tokens", c: "data-2" },
          { t: "embed", label: "Lookup table (text, discrete, continuous)", dims: "33,024 ids → 2,048" },
          { t: "embed", label: "+ local observation position", dims: "table of 512; actions share one code" },
          { t: "block", label: "Decoder block (pre-norm)", n: "24", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "Causal MHA · 16 heads · key/value 128" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "GEGLU 2,048 → 8,192 → 2,048" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "Logits over the shared vocabulary", dims: "masked loss: text + actions" },
          { t: "out", label: "next token", dims: "action tokens decoded by inverting the binning", c: "data-3" } ],
          facts: [["Layers / width / heads", ["24 / 2,048 / 16", "p2"]], ["Feed-forward", ["GEGLU, 8,192", "p2"]], ["Key/value size", ["128", "p2"]], ["Context", ["1,024 tokens", "p1"]], ["Norm", ["pre-norm LayerNorm", "p2"]], ["Regularisation", ["stochastic depth 0.1 on each sub-layer", "p5"]], ["Smaller variants", ["364M: 12 × 1,536; 79M: 8 × 768", "p2"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "camera image", n: "16 × 16 patches", k: 4 },
      { to: "gato", mod: "lang", label: "text or prompt", n: "32k pieces", k: 3 },
      { to: "gato", mod: "state", label: "proprio (μ-law)", n: "binned", k: 2 },
      { to: "gato", mod: "action", label: "past actions", n: "binned", k: 3 }
    ],
    outputs: [
      { from: "gato", mod: "action", label: "action tokens", n: "1,024 bins", k: 4 },
      { from: "gato", mod: "lang", label: "text tokens", n: "captions", k: 2 }
    ],
    links: [{ from: "resnet", to: "gato", kind: "prefix", label: "patch embeddings|join the sequence" }],
    mask: { name: "Causal (token level)", ref: "p1", axes: [{ label: "prompt episode", short: "P", mod: "other" }, { label: "observation tokens", short: "o", mod: "vision" }, { label: "action tokens", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "An ordinary language-model mask: every token sees only earlier tokens." },
    callouts: [
      "Paper §2.3 gives the feed-forward hidden size as <b>8196</b>; App. C, Table 5 gives <b>8192</b>. The table value is used here.",
      "No official code or weights were released; every number comes from the paper.",
      "On the real robot the context is cut to one timestep, and all action tokens of a step are sampled in one pass, because action tokens were zeroed in training (App. G).",
      "The Skill Mastery results use an earlier variant that embedded patches with a local transformer instead of the ResNet block (App. H)."
    ]
  });

  /* ------------------------------------------------------------------ VIMA */
  RB.arch.spec({
    id: "vima", method: "vima", name: "VIMA", year: 2022,
    figRef: "Jiang et al. Fig. 3 · §4 · App. C, D", prov: "200M checkpoint (Table 8)",
    lede: "A mostly frozen T5 encodes a multimodal prompt of words and object tokens. A causal decoder reads the interaction history and cross-attends to that prompt in every layer, then discrete heads pick two SE(2) poses.",
    sources: {
      p1: { kind: "paper", ref: "Jiang et al. 2023, §3–4 and §5.2", url: "https://arxiv.org/abs/2210.03094" },
      p2: { kind: "paper", ref: "Jiang et al. 2023, App. C.2 (Tables 2–4, Pseudocode 1)", url: "https://arxiv.org/abs/2210.03094" },
      p3: { kind: "paper", ref: "Jiang et al. 2023, App. D (Tables 7–8)", url: "https://arxiv.org/abs/2210.03094" },
      c1: { kind: "code", repo: "vimalabs/VIMA", path: "vima/policy/vima_policy.py", commit: "8449837", url: "https://github.com/vimalabs/VIMA/blob/8449837/vima/policy/vima_policy.py" },
      c2: { kind: "code", repo: "vimalabs/VIMA", path: "vima/nn/seq_modeling/xattn_gpt/xattn_gpt.py", commit: "8449837", url: "https://github.com/vimalabs/VIMA/blob/8449837/vima/nn/seq_modeling/xattn_gpt/xattn_gpt.py" },
      c3: { kind: "code", repo: "vimalabs/VIMA", path: "vima/nn/seq_modeling/xattn_gpt/components.py", commit: "8449837", url: "https://github.com/vimalabs/VIMA/blob/8449837/vima/nn/seq_modeling/xattn_gpt/components.py" },
      c4: { kind: "code", repo: "vimalabs/VIMA", path: "vima/nn/prompt_encoder/prompt_encoder.py", commit: "8449837", url: "https://github.com/vimalabs/VIMA/blob/8449837/vima/nn/prompt_encoder/prompt_encoder.py" }
    },
    summary: {
      pattern: ["Encoder–decoder transformer (cross-attention to the prompt)", "p1"],
      params: ["2M–200M decoder variants; the T5-base encoder (111M) is not counted", "p1"],
      vision: ["Object tokens: Mask R-CNN boxes → bbox MLP + ViT on 32 × 32 crops (4 layers, width 768)", "p2", "c1"],
      backbone: ["T5-base prompt encoder; only the last 2 layers fine-tuned", "p2"],
      head: ["Per-pose MLP heads (hidden 512, depth 2): x 50, y 100, rotation 4 × 50 bins", "p2", "c1"],
      output: ["Two SE(2) poses per step (pick and place, or push start and end)", "p2"],
      attention: ["Decoder alternates cross-attention to the prompt and causal self-attention", "p2", "c2"],
      cond: ["Queries from the history, keys and values from the encoded prompt", "p1"],
      steps: ["One decoder pass per step; the last token becomes the action", "p2"],
      chunk: ["One motor primitive per interaction step", "p1"],
      rate: null, latency: null,
      train: ["650K expert trajectories in VIMA-Bench, 50K per task", "p1"]
    },
    blueprint: {
      headline: "VIMA: decode actions, attend to the prompt",
      note: "Words and object tokens form the prompt, which T5 encodes once. The controller's sequence is the history of observation object tokens and past actions; each of its 11 layers first cross-attends to the prompt, then self-attends causally.",
      towers: [
        { mod: "obj", title: "Object encoder", sub: "per detected object", compact: true,
          input: { label: "Crop 32 × 32 + box", caption: "from Mask R-CNN, 2 views" },
          rows: [
            { t: "mlp", label: "Bounding-box MLP", call: ["Hidden 768, depth 2", "p2", "c1"] },
            { t: "block", n: "4", label: "ViT", rows: [
              { t: "attn", label: "ViT self-attention", call: ["24 heads, width 768, patch 16", "p2", "c1"] } ] },
            { t: "linear", label: "Concat → token", call: ["Box feature ‖ crop feature", "p2"] } ],
          output: { label: "one token per object" } },
        { mod: "t5", title: "T5-base encoder", sub: "prompt encoder",
          input: { label: "Prompt tokens", caption: "words + object tokens, interleaved" },
          rows: [
            { t: "embed", label: "T5 word embedding", call: ["Embedding dimension of 768", "p2"] },
            { t: "mlp", label: "Adapter MLP (objects)", call: ["Depth 2, between object tokens and T5", "p2"] },
            { t: "group", label: "Lower layers, frozen", rows: [
              { t: "attn", label: "T5 self-attention" }, { t: "ffn", label: "T5 feed forward" } ] },
            { t: "block", n: "2", label: "last layers, tuned", rows: [
              { t: "attn", label: "T5 self-attention" }, { t: "ffn", label: "T5 feed forward" } ] } ],
          output: { label: "encoded prompt: keys and values" } },
        { mod: "dec", title: "Robot controller", sub: "causal decoder, 200M model",
          input: { label: "History tokens", caption: "[obs objects | a₁ | obs objects | a₂ …]" },
          rows: [
            { t: "linear", label: "Obs fusion: objects ‖ EE", call: ["End-effector embedding of 2", "p2", "c1"] },
            { t: "embed", label: "+ learned position" },
            { t: "block", n: "11", rows: [
              { id: "xa", t: "attn", label: "Cross-attention to prompt", side: "cond", call: ["24 heads; queries from the history", "p3", "c2"], zoom: { k: "heads", q: 24, kv: 24, hd: 32, title: "Cross-attention heads" } },
              { t: "add", span: 1 },
              { t: "ffn", label: "Feed forward (GEGLU)", call: ["4× expansion: 768 → 3,072", "c1", "c3"], zoom: { k: "glu", act: "GELU", d: "768", ff: "3,072", title: "Feed forward (GEGLU)" } },
              { t: "add", span: 1 },
              { t: "attn", label: "Causal self-attention", call: ["24 heads, width 768", "p3"] },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm (post-norm)" },
              { t: "ffn", label: "Feed forward (GEGLU)" },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "mlp", label: "Action heads, per pose", call: ["Hidden 512, depth 2, ReLU", "p2", "c1"],
              zoom: { k: "rows", title: "Discrete action heads", rows: ["last token of the sequence", "MLP 512 · 512 (ReLU)", "x: 50 bins · y: 100 bins", "rotation: 4 × 50 bins", "affine map → SE(2) pose"] } } ],
          output: { label: "pose₀ and pose₁ for one primitive" } }
      ],
      links: [
        { from: "obj", to: "t5", toRow: "input", label: "object tokens" },
        { from: "t5", to: "dec", toRow: "xa", label: "prompt (K, V)" }
      ]
    },
    modules: [
      { id: "obj", role: "vision-enc", name: "Object encoder", sub: "ViT 4 × 768 + bbox MLP", col: 0, frozen: false, short: "Objects",
        note: "The same encoder tokenises prompt images and the observation's objects; the observation tokens go straight to the controller.",
        stack: { rows: [
          { t: "in", label: "object crop (padded square) + box", dims: "box = (x, y, h, w) in [0, 1]", c: "data-1" },
          { t: "mlp", label: "Bounding-box MLP", dims: "hidden 768, depth 2" },
          { t: "block", label: "ViT on the crop (trained from scratch)", n: "4", rows: [
            { t: "attn", label: "MHA · 24 heads · width 768" }, { t: "ffn", label: "MLP" } ] },
          { t: "linear", label: "concat box ‖ crop features → token", dims: "→ embedding dimension" },
          { t: "out", label: "object token", dims: "3–8 per step typical", c: "data-1" } ],
          facts: [["Crop size", ["32 × 32, patch 16", "p2", "c1"]], ["ViT", ["4 layers, width 768, 24 heads", "p2", "c1"]], ["Bbox MLP", ["hidden 768, depth 2", "p2", "c1"]], ["Detector", ["Mask R-CNN, fine-tuned in domain", "p1"]], ["Tokens per step", ["number of objects, typically 3 to 8", "p2"]]] } },
      { id: "t5", role: "lang", roleLabel: "Prompt encoder", name: "T5-base encoder", sub: "last 2 layers tuned", col: 1, frozen: "partial", short: "T5-base",
        stack: { rows: [
          { t: "in", label: "words + object tokens", dims: "t5-base tokenizer; adapter MLP for objects", c: "data-2" },
          { t: "embed", label: "T5 word embedding", dims: "768" },
          { t: "group", label: "T5-base encoder layers", rows: [{ t: "attn", label: "self-attention (frozen except last 2 layers)" }, { t: "ffn", label: "feed forward" }] },
          { t: "out", label: "encoded prompt", dims: "keys and values for every decoder layer", c: "data-2" } ],
          facts: [["Model", ["t5-base, 111M", "p1", "c4"]], ["Tuned layers", ["last 2, layer-wise lr decay", "p2"]], ["Position", ["learned absolute", "p2"]], ["Size ablation", ["small 30M / base 111M / large 368M: no significant difference", "p1"]]] } },
      { id: "dec", role: "action-head", roleLabel: "Robot controller", name: "Cross-attn decoder", sub: "11 × 768 · 24 heads", col: 2, frozen: false, main: true, params: "200M", short: "Controller",
        stack: { rows: [
          { t: "in", label: "[obs object tokens ‖ EE state | action tokens]", dims: "interleaved over time", c: "data-3" },
          { t: "linear", label: "obs fusion: objects ‖ end-effector (2) → 768" },
          { t: "mlp", label: "action embedding: MLP, hidden 256" },
          { t: "block", label: "Decoder layer", n: "11", rows: [
            { t: "attn", label: "cross-attention: Q = history, K, V = prompt" }, { t: "add", span: 1 }, { t: "ffn", label: "GEGLU feed forward, 4×" }, { t: "add", span: 1 },
            { t: "attn", label: "causal self-attention · 24 heads" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" },
            { t: "ffn", label: "GEGLU 768 → 3,072 → 768" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" } ] },
          { t: "mlp", label: "action heads: MLP 512 × 2 per pose", dims: "x 50 · y 100 · rot 4 × 50" },
          { t: "out", label: "two SE(2) poses", c: "data-3" } ],
          facts: [["Width / layers / heads", ["768 / 11 / 24 (200M)", "p3"]], ["Other sizes", ["2M: 256 × 1 … 92M: 640 × 7", "p3"]], ["Activation", ["GEGLU in all transformers", "p3", "c2"]], ["Action bins", ["x 50, y 100, rotation 50 per quaternion element", "p2", "c1"]], ["Dropout", ["0.1", "p3", "c1"]]] } }
    ],
    inputs: [
      { to: "obj", mod: "vision", label: "prompt images and scene", n: "crops + boxes", k: 4 },
      { to: "t5", mod: "lang", label: "prompt words", n: "t5-base tokens", k: 3 },
      { to: "dec", mod: "vision", label: "obs objects", n: "2 views", k: 4 },
      { to: "dec", mod: "action", label: "past actions", n: "embedded", k: 2 }
    ],
    outputs: [{ from: "dec", mod: "action", label: "pose₀, pose₁ bins", n: "x 50 · y 100 · rot 4 × 50", k: 4 }],
    links: [
      { from: "obj", to: "t5", kind: "prefix", label: "object tokens|+ adapter MLP" },
      { from: "t5", to: "dec", kind: "cross-attn", label: "encoded prompt", note: "every decoder layer starts with cross-attention to the prompt" }
    ],
    callouts: [
      "Each decoder layer is cross-attention then causal self-attention, each followed by a GEGLU feed-forward (Pseudocode 1). Cross-attention beat a GPT-style decoder mostly at small sizes and on novel tasks (Fig. 7).",
      "The paper fine-tunes only the last two T5 layers. The public repo holds inference code only, so that freeze cannot be checked in code.",
      "Variants scale by width and depth only: 2M uses 256 × 1 layer, 200M uses 768 × 11 layers (Table 8)."
    ]
  });

  /* ------------------------------------------------------------------ RT-1 */
  RB.arch.spec({
    id: "rt-1", method: "rt-1", name: "RT-1", year: 2022,
    figRef: "Brohan et al. Figs. 1a, 3 · §5.1 · App. C", prov: "released gin config",
    lede: "A 35M real-time policy. A FiLM-conditioned EfficientNet turns each of 6 images into 81 instruction-aware tokens, TokenLearner keeps 8, and an 8-layer causal transformer reads 48 of them to emit 256-bin action tokens.",
    sources: {
      p1: { kind: "paper", ref: "Brohan et al. 2022, §5.1 and Fig. 3", url: "https://arxiv.org/abs/2212.06817" },
      p2: { kind: "paper", ref: "Brohan et al. 2022, §4 (system, action space)", url: "https://arxiv.org/abs/2212.06817" },
      p3: { kind: "paper", ref: "Brohan et al. 2022, §5.1 inference speed and §5.2 data", url: "https://arxiv.org/abs/2212.06817" },
      p4: { kind: "paper", ref: "Brohan et al. 2022, App. C.1", url: "https://arxiv.org/abs/2212.06817" },
      p5: { kind: "paper", ref: "Open X-Embodiment Collaboration 2023, §IV (RT-1-X)", url: "https://arxiv.org/abs/2310.08864" },
      c1: { kind: "code", repo: "google-research/robotics_transformer", path: "configs/transformer_mixin.gin", commit: "4569641", url: "https://github.com/google-research/robotics_transformer/blob/4569641/configs/transformer_mixin.gin" },
      c2: { kind: "code", repo: "google-research/robotics_transformer", path: "transformer.py", commit: "4569641", url: "https://github.com/google-research/robotics_transformer/blob/4569641/transformer.py" },
      c3: { kind: "code", repo: "google-research/robotics_transformer", path: "transformer_network.py", commit: "4569641", url: "https://github.com/google-research/robotics_transformer/blob/4569641/transformer_network.py" },
      c4: { kind: "code", repo: "google-research/robotics_transformer", path: "film_efficientnet/pretrained_efficientnet_encoder.py", commit: "4569641", url: "https://github.com/google-research/robotics_transformer/blob/4569641/film_efficientnet/pretrained_efficientnet_encoder.py" },
      c5: { kind: "code", repo: "google-research/robotics_transformer", path: "film_efficientnet/film_conditioning_layer.py", commit: "4569641", url: "https://github.com/google-research/robotics_transformer/blob/4569641/film_efficientnet/film_conditioning_layer.py" },
      c6: { kind: "code", repo: "google-research/robotics_transformer", path: "tokenizers/token_learner.py", commit: "4569641", url: "https://github.com/google-research/robotics_transformer/blob/4569641/tokenizers/token_learner.py" }
    },
    summary: {
      pattern: ["Discrete-token transformer policy (FiLM EfficientNet + TokenLearner)", "p1"],
      params: ["35M: FiLM EfficientNet-B3 16M + transformer 19M", "p1"],
      vision: ["EfficientNet-B3 (ImageNet) at 300 × 300 → 9 × 9 × 512 = 81 tokens → TokenLearner 8", "p1", "c4"],
      backbone: ["Decoder-only transformer: 8 layers, 8 heads, token width 512", "p1", "c1"],
      head: ["Dense layer to 256 logits per action dimension", "c2", "p1"],
      output: ["11 action dims × 256 bins: arm 7, base 3, mode 1", "p2", "p1"],
      attention: ["Causal over 6 × (8 image + action) tokens; action slots never see action slots", "c3"],
      cond: ["Instruction → Universal Sentence Encoder → FiLM in the EfficientNet (identity init)", "p1", "c5"],
      steps: ["One action per step; image tokens reused across overlapping windows", "p3"],
      chunk: ["One action per step", "p2"],
      rate: ["3 Hz closed loop; model budget under 100 ms", "p2", "p3"],
      latency: ["Fixed 280 ms wait between capture and acting", "p4"],
      train: ["≈ 130k demos, 744 instructions, 13 robots, 17 months", "p3"]
    },
    blueprint: {
      headline: "RT-1: few tokens, fast transformer",
      note: "The instruction never enters the transformer as text: its sentence embedding sets FiLM scales and shifts inside every EfficientNet block. Each image becomes 8 tokens; the transformer sees 6 images (48 tokens) plus zeroed action slots and reads each action bin from its slot.",
      towers: [
        { mod: "use", title: "Universal Sentence Encoder", sub: "pretrained, not trained here", compact: true,
          input: { label: "Instruction", caption: "\u201cpick apple from top drawer…\u201d" },
          rows: [{ t: "embed", label: "Sentence embedding" }],
          output: { label: "one embedding per instruction" } },
        { mod: "effnet", title: "FiLM EfficientNet-B3", sub: "image tokenizer, 16M",
          input: { label: "Image 300 × 300", caption: "each of the last 6 frames" },
          rows: [
            { t: "block", n: "26", label: "MBConv + FiLM", rows: [
              { t: "conv", label: "MBConv block", call: ["ImageNet-pretrained EfficientNet-B3", "p1"] },
              { id: "film", t: "film", label: "FiLM: (1 + γ) ⊙ x + β", side: "FiLM", call: ["γ, β layers start at zero: identity", "p1", "c5"], zoom: { k: "rows", title: "FiLM from the sentence", rows: ["sentence embedding", "Dense → γ (zero init)", "Dense → β (zero init)", "(1 + γ) ⊙ x + β"] } } ] },
            { t: "conv", label: "1 × 1 conv → 512 + FiLM", call: ["9 × 9 × 512 = 81 tokens", "p1", "c4"] },
            { t: "pool", label: "TokenLearner", call: ["81 → 8 tokens, bottleneck MLP 64", "p1", "c6"],
              zoom: { k: "rows", title: "TokenLearner", rows: ["81 tokens × 512", "LayerNorm", "MLP (64) → 8 maps", "softmax over 81 positions", "8 weighted sums = 8 tokens"] } } ],
          output: { label: "8 tokens per image" } },
        { mod: "xf", title: "RT-1 transformer", sub: "decoder-only, 19M",
          input: { label: "48 image tokens + slots", caption: "6 × (8 image + action slots, zeroed)" },
          rows: [
            { t: "linear", label: "Token embedding (Dense)", call: ["Token width 512", "c1", "c2"] },
            { t: "embed", label: "+ position (one-hot → Dense)" },
            { t: "block", n: "8", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Masked self-attention", call: ["8 heads, key dim 128 per head", "c1", "c2"], zoom: { k: "heads", q: 8, kv: 8, hd: 128, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward: one Dense", call: ["Single Dense 512, no activation", "c1", "c2"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Dense → action logits", call: ["256 bins per action dimension", "c1", "p1"] } ],
          output: { label: "11 action tokens → de-tokenize" } }
      ],
      links: [
        { from: "use", to: "effnet", toRow: "film", label: "sentence embedding" },
        { from: "effnet", to: "xf", toRow: "input", label: "8 tokens / image" }
      ]
    },
    modules: [
      { id: "use", role: "lang", name: "Universal Sentence Encoder", sub: "instruction embedding", col: 0, frozen: true, short: "USE",
        note: "The code takes the embedding as a precomputed observation, so the encoder itself is not trained." },
      { id: "effnet", role: "vision-enc", name: "FiLM EfficientNet-B3", sub: "81 → 8 tokens / image", col: 1, frozen: false, params: "16M", short: "EfficientNet",
        stack: { rows: [
          { t: "in", label: "image, resized to 300 × 300", dims: "one of 6 history frames", c: "data-1" },
          { t: "block", label: "MBConv + FiLM (ImageNet init)", n: "26", rows: [
            { t: "conv", label: "MBConv block" }, { t: "film", label: "FiLM: (1 + γ(ℓ)) · x + β(ℓ)", side: "USE", note: "γ and β come from zero-initialised Dense layers on the sentence embedding" } ] },
          { t: "conv", label: "1 × 1 conv → 512 channels, then FiLM", dims: "9 × 9 × 512" },
          { t: "pool", label: "TokenLearner: 8 soft spatial selections", dims: "81 → 8 tokens" },
          { t: "out", label: "8 vision-language tokens", dims: "cached and reused across windows", c: "data-1" } ],
          facts: [["Backbone", ["EfficientNet-B3, ImageNet-pretrained", "p1"]], ["Input", ["300 × 300", "p1", "c4"]], ["Feature map", ["9 × 9 × 512 = 81 tokens", "p1"]], ["FiLM", ["identity-initialised (zero Dense)", "p1", "c5"]], ["TokenLearner", ["8 tokens, bottleneck 64", "p1", "c6"]], ["Parameters", ["16M incl. FiLM", "p1"]]] } },
      { id: "xf", role: "action-head", roleLabel: "Policy transformer", name: "RT-1 transformer", sub: "8 layers · 8 heads · 512", col: 2, frozen: false, main: true, params: "19M", short: "Transformer",
        stack: { rows: [
          { t: "in", label: "6 × [8 image tokens | action slots]", dims: "action slots are zero vectors", c: "data-3" },
          { t: "linear", label: "Dense token embedding → 512" },
          { t: "embed", label: "+ position: one-hot index → Dense" },
          { t: "block", label: "Transformer layer (pre-norm)", n: "8", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 8 heads · key dim 128 · causal mask" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "Dense 512 (no activation)" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "Dense → 256 logits", dims: "one per action dimension" },
          { t: "out", label: "action tokens", dims: "arm 7 · base 3 · mode 1", c: "data-3" } ],
          facts: [["Layers / heads", ["8 / 8", "p1", "c1"]], ["Token width", ["512", "c1"]], ["Key dim per head", ["128", "c1", "c2"]], ["Feed-forward", ["one Dense(512), no activation", "c2"]], ["History", ["6 images", "p1", "c1"]], ["Vocabulary", ["256 bins", "p1", "c1"]], ["Dropout", ["0.1", "c1"]]] } }
    ],
    inputs: [
      { to: "use", mod: "lang", label: "instruction", n: "free text", k: 2 },
      { to: "effnet", mod: "vision", label: "6 recent images", n: "300 × 300", k: 5 }
    ],
    outputs: [{ from: "xf", mod: "action", label: "action tokens", n: "11 × 256 bins", k: 5 }],
    links: [
      { from: "use", to: "effnet", kind: "film", label: "USE vector|γ, β per block" },
      { from: "effnet", to: "xf", kind: "prefix", label: "8 tokens / image|× 6 images = 48" }
    ],
    mask: { name: "Causal, action slots isolated", ref: "p1", axes: [{ label: "image tokens", short: "img", mod: "vision" }, { label: "action slots", short: "a", mod: "action" }], m: ["10", "10"],
      note: "Code removes every action-to-action link (transformer_network.py). Slots are zero vectors, so each bin is read from the image tokens of the current and earlier steps." },
    callouts: [
      "The released code's feed-forward sub-layer is a <b>single Dense(512) with no activation</b>. Keras key_dim = 128 is per head, so Q, K, V are 8 × 128 = 1,024 wide and project back to 512.",
      "History length: the RT-1 paper and the released gin config use <b>6</b> images; the Open X-Embodiment paper describes RT-1 with a history of <b>15</b> images.",
      "<b>RT-1-X</b> (Open X-Embodiment) is this same 35M network trained on a 9-robot mixture, with a 7-DoF end-effector action plus terminate, 256 bins each; it underfits the large Bridge and RT-1 datasets (Table I)."
    ]
  });

  /* ------------------------------------------------------------------ RT-2 */
  RB.arch.spec({
    id: "rt-2", method: "rt-2", name: "RT-2", year: 2023, parent: "rt-1",
    diffRows: ["pattern", "params", "vision", "backbone", "head", "output", "cond", "rate", "train"],
    figRef: "Brohan et al. Fig. 1 · §3 · App. B, D, E", prov: "RT-2-PaLI-X 55B",
    lede: "A web-scale vision-language model fine-tuned to answer \u201cwhat action should the robot take?\u201d with 8 number tokens. No new layers: actions are words in the VLM's own vocabulary, trained together with web VQA data.",
    sources: {
      p1: { kind: "paper", ref: "Brohan et al. 2023, §3.1–3.2 and §4", url: "https://arxiv.org/abs/2307.15818" },
      p2: { kind: "paper", ref: "Brohan et al. 2023, §3.3 (real-time inference)", url: "https://arxiv.org/abs/2307.15818" },
      p3: { kind: "paper", ref: "Brohan et al. 2023, App. D (VLM architectures)", url: "https://arxiv.org/abs/2307.15818" },
      p4: { kind: "paper", ref: "Brohan et al. 2023, App. B and E (data mixture, training)", url: "https://arxiv.org/abs/2307.15818" },
      p5: { kind: "paper", ref: "Open X-Embodiment Collaboration 2023, §IV (RT-2-X)", url: "https://arxiv.org/abs/2310.08864" }
    },
    summary: {
      pattern: ["Autoregressive token VLA", "p1"],
      params: ["55B (RT-2-PaLI-X); also 5B PaLI-X and 12B PaLM-E", "p1", "p2"],
      vision: ["ViT-22B, n images → n × k patch tokens (PaLI-X); ViT-4B for PaLM-E", "p3"],
      backbone: ["PaLI-X: UL2-like encoder–decoder, 32B, 50 layers", "p3"],
      head: ["None: actions are ordinary output tokens, no new parameters", "p1"],
      output: ["8 tokens: terminate, Δpos (3), Δrot (3), gripper; 256 uniform bins", "p1"],
      attention: null,
      cond: ["VQA prompt: \u201cQ: what action should the robot take to [task]? A:\u201d", "p1"],
      steps: ["Autoregressive decoding, sampling restricted to valid action tokens", "p1"],
      chunk: ["One action per query", "p1"],
      rate: ["1–3 Hz (55B) · ≈ 5 Hz (5B), served from a multi-TPU cloud", "p2"],
      latency: null,
      train: ["Co-fine-tuned with web data; robot share ≈ 50 % (PaLI-X), ≈ 66 % (PaLM-E)", "p4"]
    },
    changes: [
      "The FiLM EfficientNet and 19M transformer give way to a <b>web-pretrained VLM</b>: ViT-22B plus a 32B UL2-style encoder–decoder.",
      "Actions become <b>text tokens</b> in the VLM's vocabulary; there is no action head and no new parameter.",
      "The action drops RT-1's base and mode dimensions: terminate + 6-DoF end-effector delta + gripper = 8 tokens.",
      "Training co-fine-tunes on web VQA and captioning data alongside RT-1's robot demonstrations.",
      "Inference moves off the robot to a TPU cloud: 1–3 Hz for 55B."
    ],
    blueprint: {
      headline: "RT-2: actions are just more words",
      note: "RT-2 does not change the VLM. Image tokens from the ViT pass a projection into the UL2-style encoder–decoder with the prompt; the decoder writes 8 integers, which are de-tokenised into an end-effector command. Layer-level sizes are not given in the RT-2 paper.",
      towers: [
        { mod: "vit", title: "ViT-22B", sub: "PaLI-X image encoder", compact: true,
          input: { label: "Robot camera image", caption: "n images → n × k patches" },
          rows: [
            { t: "embed", label: "Patch embedding" },
            { t: "group", label: "ViT-22B layers", rows: [
              { t: "attn", label: "Self-attention", call: ["Layer sizes not given in RT-2", "p3"] },
              { t: "ffn", label: "MLP" } ] },
            { t: "linear", label: "Projection layer", zoom: { k: "rows", title: "Image tokens into the LM", rows: ["n camera images", "ViT-22B: k patches each", "n × k image tokens", "projection layer", "joins the text embeddings"] } } ],
          output: { label: "image tokens" } },
        { mod: "ul2", title: "PaLI-X backbone", sub: "UL2-like encoder–decoder, 32B",
          input: { label: "Image tokens + prompt", caption: "\u201cQ: what action should the robot take to …? A:\u201d" },
          rows: [
            { t: "group", label: "Encoder", rows: [
              { t: "attn", label: "Encoder self-attention", call: ["32B params and 50 layers in total", "p3"] },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "group", label: "Decoder (autoregressive)", rows: [
              { t: "attn", label: "Causal self-attention" },
              { t: "attn", label: "Cross-attn to encoder", zoom: { k: "rows", title: "RT-2-PaLM-E variant", rows: ["ViT-4B image encoder", "project into word space", "decoder-only PaLM", "12B parameters in total"] } },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "Constrained softmax", call: ["Only 256 action tokens on robot prompts", "p1"],
              zoom: { k: "rows", title: "Action → tokens", rows: ["8 dims: stop, Δpos, Δrot, grip", "256 uniform bins each", "PaLI-X: integers 0 … 255", "PaLM-E: 256 rare tokens reused", "\u201c1 128 91 241 5 101 127\u201d"] } } ],
          output: { label: "8 action tokens → de-tokenize" } }
      ],
      links: [{ from: "vit", to: "ul2", toRow: "input", label: "projected image tokens" }]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "ViT-22B", sub: "n × k patch tokens", col: 0, frozen: false, short: "ViT-22B",
        note: "Whether the ViT is frozen during co-fine-tuning is not stated in the RT-2 paper.",
        stack: { rows: [
          { t: "in", label: "robot camera image(s)", dims: "n images", c: "data-1" },
          { t: "embed", label: "patch embedding", dims: "k patches per image" },
          { t: "group", label: "ViT-22B transformer (sizes not given in RT-2)", rows: [{ t: "attn", label: "self-attention" }, { t: "ffn", label: "MLP" }] },
          { t: "linear", label: "projection layer", dims: "into the backbone's embedding space" },
          { t: "out", label: "n × k image tokens", c: "data-1" } ],
          facts: [["Encoder", ["ViT-22B (PaLI-X)", "p3"]], ["PaLM-E variant", ["ViT-4B", "p3"]], ["Language-Table variant", ["ViT-G/14, 2B (PaLI-3B)", "p3"]]] } },
      { id: "ul2", role: "vlm", name: "UL2-style enc–dec", sub: "32B · 50 layers", col: 1, frozen: false, main: true, params: "32B", short: "PaLI-X LM",
        stack: { rows: [
          { t: "in", label: "[image tokens | VQA prompt]", dims: "\u201cQ: what action should the robot take to …? A:\u201d", c: "data-2" },
          { t: "group", label: "Encoder–decoder, 50 layers (UL2-like)", rows: [{ t: "attn", label: "encoder self-attention" }, { t: "attn", label: "decoder: causal + cross-attention" }, { t: "ffn", label: "feed forward" }] },
          { t: "linear", label: "output softmax, restricted to action tokens", dims: "on robot prompts only" },
          { t: "out", label: "\u201cterminate Δx Δy Δz Δrx Δry Δrz grip\u201d", dims: "8 integers in 0 … 255", c: "data-3" } ],
          facts: [["Backbone", ["32B, 50 layers, UL2-like", "p3"]], ["Action vocab", ["PaLI-X: integer tokens; PaLM-E: 256 least-used tokens", "p1"]], ["55B training", ["lr 1e-3, batch 2,048, 80K steps", "p4"]], ["5B training", ["lr 1e-3, batch 2,048, 270K steps", "p4"]], ["PaLM-E-12B training", ["lr 4e-4, batch 512, 1M steps", "p4"]]] } }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "robot camera image", n: "one per query", k: 4 },
      { to: "ul2", mod: "lang", label: "VQA-style prompt", n: "task instruction", k: 3 }
    ],
    outputs: [{ from: "ul2", mod: "action", label: "8 action tokens", n: "256 bins each", k: 5 }],
    links: [{ from: "vit", to: "ul2", kind: "prefix", label: "projection|image tokens" }],
    callouts: [
      "RT-2 is closed: no code or weights. The paper names the parts (ViT-22B, a 32B 50-layer UL2-like backbone) but gives no layer widths or head counts.",
      "§3.2 defines an action as <b>8</b> integers, but its example target \u201c1 128 91 241 5 101 127\u201d has only <b>7</b>; the chain-of-thought examples in Fig. 7 show 8.",
      "<b>RT-2-X</b> (Open X-Embodiment) is RT-2-PaLI-X 55B (plus a 5B ablation) co-fine-tuned about 1 : 1 with web data on a 9-robot mixture, 7-DoF end-effector + terminate, 256 bins each."
    ]
  });

  /* ------------------------------------------------------------------ Octo */
  RB.arch.spec({
    id: "octo", method: "octo", name: "Octo", year: 2024, parent: "rt-1",
    diffRows: ["pattern", "params", "vision", "backbone", "head", "output", "attention", "cond", "chunk", "train"],
    figRef: "Octo Model Team Fig. 2 · §III · App. D, E", prov: "Octo-Base (93M), pretrain config",
    lede: "A ViT-B-sized transformer over task tokens, image patch tokens and one readout token per step. Readouts see everything but nothing sees them; a small diffusion MLP turns the readout into a 4-step action chunk.",
    sources: {
      p1: { kind: "paper", ref: "Octo Model Team 2024, §III-A–B (architecture, data)", url: "https://arxiv.org/abs/2405.12213" },
      p2: { kind: "paper", ref: "Octo Model Team 2024, §III-C–E (objective, training)", url: "https://arxiv.org/abs/2405.12213" },
      p3: { kind: "paper", ref: "Octo Model Team 2024, App. D, Table V", url: "https://arxiv.org/abs/2405.12213" },
      c1: { kind: "code", repo: "octo-models/octo", path: "scripts/configs/octo_pretrain_config.py", commit: "241fb35", url: "https://github.com/octo-models/octo/blob/241fb35/scripts/configs/octo_pretrain_config.py" },
      c2: { kind: "code", repo: "octo-models/octo", path: "octo/model/components/transformer.py", commit: "241fb35", url: "https://github.com/octo-models/octo/blob/241fb35/octo/model/components/transformer.py" },
      c3: { kind: "code", repo: "octo-models/octo", path: "octo/model/components/action_heads.py", commit: "241fb35", url: "https://github.com/octo-models/octo/blob/241fb35/octo/model/components/action_heads.py" },
      c4: { kind: "code", repo: "octo-models/octo", path: "octo/model/components/diffusion.py", commit: "241fb35", url: "https://github.com/octo-models/octo/blob/241fb35/octo/model/components/diffusion.py" },
      c5: { kind: "code", repo: "octo-models/octo", path: "octo/model/components/vit_encoders.py", commit: "241fb35", url: "https://github.com/octo-models/octo/blob/241fb35/octo/model/components/vit_encoders.py" },
      c6: { kind: "code", repo: "octo-models/octo", path: "octo/model/octo_module.py", commit: "241fb35", url: "https://github.com/octo-models/octo/blob/241fb35/octo/model/octo_module.py" },
      c7: { kind: "code", repo: "octo-models/octo", path: "octo/model/components/tokenizers.py", commit: "241fb35", url: "https://github.com/octo-models/octo/blob/241fb35/octo/model/components/tokenizers.py" }
    },
    summary: {
      pattern: ["Transformer policy + diffusion MLP head (readout tokens)", "p1"],
      params: ["93M (Octo-Base); Octo-Small 27M", "p2"],
      vision: ["Conv stem, then 16 × 16 patches: 256 tokens (3rd person, 256²), 64 (wrist, 128²)", "p3", "c1", "c5"],
      backbone: ["ViT-B-sized: 12 layers, width 768, 12 heads, MLP 3,072", "p3", "c2"],
      head: ["Diffusion MLP: 3 residual blocks, width 256, LayerNorm, swish", "p3", "c4"],
      output: ["Noise ε for a chunk of 4 actions × 7 dims", "c1"],
      attention: ["Block-wise causal: obs see task + obs ≤ t; readouts read, are never read", "p1", "c6"],
      cond: ["Mean-pooled readout embedding ‖ Fourier(k) → head input", "c3", "c4"],
      steps: ["20 DDPM steps, cosine schedule; the transformer runs once", "p3", "p2"],
      chunk: ["2-frame history → 4-action chunk", "p2", "c1"],
      rate: null, latency: null,
      train: ["800k OXE trajectories (25 datasets); 300k steps, batch 2,048, TPU v4-128, 14 h", "p1", "p2"]
    },
    changes: [
      "The FiLM EfficientNet is replaced by a <b>shallow conv stem + 16 × 16 patches</b>: 256 + 64 tokens per frame instead of 8.",
      "Language enters as 16 frozen T5 tokens in the sequence, not as FiLM inside the image encoder.",
      "The 256-bin action tokens give way to a <b>diffusion MLP head</b> on a readout token, predicting a chunk of 4 continuous actions.",
      "Block-wise masking lets finetuning add or drop cameras, tasks and heads without touching pretrained weights.",
      "Trained on 800k trajectories from 25 OXE datasets instead of one robot fleet's 130k demos."
    ],
    blueprint: {
      headline: "Octo: tokens in, readout out",
      note: "Each camera frame is patchified by its own conv stem (goal image stacked as extra channels). Task tokens, observation tokens and one readout token per step share a 12-layer transformer; the diffusion head sees only the readout and runs 20 denoising steps.",
      towers: [
        { mod: "stem", title: "Conv stem (SmallStem16)", sub: "per camera, trained from scratch", compact: true,
          input: { label: "Image 256 × 256 ‖ goal", caption: "obs and goal stacked channel-wise" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "conv", label: "StdConv 3×3 s2 · GN · ReLU", call: ["Channels 32 → 96 → 192 → 384", "c5"] }] },
            { t: "conv", label: "Patch conv → 512", call: ["16 × 16 patches: 256 tokens", "p3", "c5"] },
            { t: "linear", label: "Dense → 768 + position", call: ["Learned position embedding", "p1", "c6"] } ],
          output: { label: "256 tokens (wrist: 64)" } },
        { mod: "xf", title: "Octo transformer", sub: "ViT-B size, block-wise mask",
          input: { label: "Token sequence", caption: "[task 16 | obs t | readout t | obs t+1 | readout]" },
          rows: [
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Block-wise attention", call: ["12 heads, width 768", "p3", "c2"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 3,072, GELU", "p3", "c2"], zoom: { k: "mlp", act: "GELU", d: "768", ff: "3,072", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "pool", label: "Readout tokens, mean-pooled", call: ["1 action readout per timestep", "c1", "c3"] } ],
          output: { label: "readout embedding (768)" } },
        { mod: "head", title: "Diffusion action head", sub: "εθ(xᵏ, e, k), small MLP", compact: true,
          input: { label: "Noisy chunk xᵏ, step k", caption: "4 actions × 7 dims" },
          rows: [
            { t: "mlp", label: "Fourier(k) → MLP", call: ["Time features 32 → 64 → 32", "c4"] },
            { id: "cat", t: "linear", label: "[t ‖ readout ‖ xᵏ] → 256", call: ["Hidden dimension of 256", "p3", "c4"] },
            { t: "block", n: "3", rows: [
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Dense · swish · Dense", zoom: { k: "mlp", act: "swish", d: "256", ff: "1,024", title: "Residual MLP block (head)" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "swish → Dense → 28", call: ["4 × 7 = 28 outputs: ε for the chunk", "c1", "c3"] } ],
          output: { label: "ε; 20 DDPM steps" } }
      ],
      links: [
        { from: "stem", to: "xf", toRow: "input", label: "patch tokens" },
        { from: "xf", to: "head", toRow: "cat", label: "readout e" }
      ]
    },
    modules: [
      { id: "stem", role: "vision-enc", name: "Conv stem + patchify", sub: "256 + 64 tokens / frame", col: 0, frozen: false, short: "Conv stem",
        note: "Language comes from a frozen t5-base (111M) that produces 16 tokens; it is shown as an input token group.",
        stack: { rows: [
          { t: "in", label: "image ‖ goal image (channels)", dims: "3rd person 256², wrist 128²", c: "data-1" },
          { t: "block", label: "StdConv 3×3, stride 2 → GroupNorm → ReLU", n: "4", rows: [{ t: "conv", label: "channels 32 / 96 / 192 / 384" }] },
          { t: "conv", label: "patch conv (1 × 1 after 16× downsampling) → 512" },
          { t: "linear", label: "Dense → 768, + learned position" },
          { t: "out", label: "observation tokens", dims: "256 (3rd person) + 64 (wrist) per frame", c: "data-1" } ],
          facts: [["Stem", ["SmallStem16: 4 strided convs, GroupNorm, ReLU", "c5"]], ["Patch size", ["16 × 16", "p3", "c5"]], ["Tokens", ["256 third-person, 64 wrist", "p3"]], ["Goal image", ["stacked channel-wise with the observation", "c1", "c7"]], ["Missing cameras", ["zero-padded", "p1"]]] } },
      { id: "xf", role: "net", roleLabel: "Transformer backbone", name: "Octo-Base transformer", sub: "12 × 768 · 12 heads", col: 1, frozen: false, main: true, params: "93M", short: "Transformer",
        stack: { rows: [
          { t: "in", label: "[task | obs t=1 | readout | obs t=2 | readout]", dims: "window of 2 steps", c: "data-2" },
          { t: "block", label: "Encoder block (pre-norm)", n: "12", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 12 heads · block-wise mask" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 768 → 3,072 → 768 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final LayerNorm" },
          { t: "pool", label: "mean-pool readout tokens", dims: "use_map = False" },
          { t: "out", label: "readout embedding e", dims: "768", c: "data-2" } ],
          facts: [["Layers / width / heads", ["12 / 768 / 12", "p3", "c2"]], ["MLP", ["3,072, GELU", "p3", "c2"]], ["Octo-Small", ["12 / 384 / 6, MLP 1,536", "p3", "c2"]], ["Language tokens", ["16 from frozen t5-base (111M)", "p3", "c1"]], ["History window", ["2 frames", "p2", "c1"]], ["Readouts", ["1 action readout per step", "c1"]]] } },
      { id: "head", role: "action-head", name: "Diffusion MLP head", sub: "3 × 256 residual blocks", col: 2, frozen: false, short: "Diffusion head",
        stack: { rows: [
          { t: "in", label: "noisy chunk xᵏ, step k, readout e", dims: "4 × 7 actions", c: "data-3" },
          { t: "mlp", label: "learnable Fourier features (32) → MLP (64, 32)" },
          { t: "linear", label: "concat [t ‖ e ‖ xᵏ] → Dense 256" },
          { t: "block", label: "MLPResNet block", n: "3", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "Dense 1,024 → swish → Dense 256" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "swish → Dense → 28" },
          { t: "out", label: "predicted noise ε", dims: "reverse DDPM, 20 steps", c: "data-3" } ],
          facts: [["Blocks / width", ["3 / 256 (inner 1,024)", "p3", "c4"]], ["Activation", ["swish", "c4"]], ["Time embedding", ["learnable Fourier, 32", "c3", "c4"]], ["Diffusion steps", ["20, cosine schedule", "p3", "c3"]], ["Chunk", ["4 actions × 7 dims", "c1"]]] } }
    ],
    inputs: [
      { to: "stem", mod: "vision", label: "3rd-person + wrist", n: "2 frames", k: 4 },
      { to: "xf", mod: "lang", label: "instruction (frozen T5)", n: "16 tokens", k: 3 },
      { to: "head", mod: "action", label: "noisy chunk xᵏ", n: "4 × 7", k: 4, noisy: true },
      { to: "head", mod: "time", label: "step k", n: "Fourier 32", k: 2 }
    ],
    outputs: [{ from: "head", mod: "action", label: "noise ε → chunk", n: "4 × 7", k: 4 }],
    links: [
      { from: "stem", to: "xf", kind: "prefix", label: "patch tokens|256 + 64 / frame" },
      { from: "xf", to: "head", kind: "feeds", label: "readout e|mean-pooled 768" }
    ],
    mask: { name: "Block-wise causal", ref: "p1", axes: [{ label: "task tokens", short: "task", mod: "lang" }, { label: "observation tokens", short: "obs", mod: "vision" }, { label: "readout tokens", short: "R", mod: "action" }], m: ["100", "110", "111"],
      note: "Across time, observations see only the same or earlier steps. Nothing attends to a readout, so new heads can be added without changing the backbone." },
    callouts: [
      "Paper App. D calls the head a \u201c3-layer MLP with hidden dimension 256\u201d; the code builds 3 <b>residual blocks</b> (LayerNorm → Dense 1,024 → swish → Dense 256) between an input and an output Dense.",
      "The paper found proprioceptive inputs hurt and a frozen t5-base beat larger or fine-tuned T5 encoders (App. E)."
    ]
  });

  /* ------------------------------------------------------------------ OpenVLA */
  RB.arch.spec({
    id: "openvla", method: "openvla", name: "OpenVLA", year: 2024, parent: "rt-2",
    diffRows: ["params", "vision", "backbone", "output", "rate", "train"],
    figRef: "Kim et al. Fig. 2 · §3 · Llama papers", prov: "prism-dinosiglip-224px+7b backbone",
    lede: "An open RT-2-style VLA. DINOv2 and SigLIP features of one 224² image are concatenated per patch, projected into Llama 2 7B, and the LM writes 7 action tokens that reuse its 256 least-used vocabulary ids.",
    sources: {
      p1: { kind: "paper", ref: "Kim et al. 2024, §3.1 and Fig. 2", url: "https://arxiv.org/abs/2406.09246" },
      p2: { kind: "paper", ref: "Kim et al. 2024, §3.2 (action tokens)", url: "https://arxiv.org/abs/2406.09246" },
      p3: { kind: "paper", ref: "Kim et al. 2024, §3.3–3.5 (data, design, infrastructure)", url: "https://arxiv.org/abs/2406.09246" },
      p4: { kind: "paper", ref: "Touvron et al. 2023a (LLaMA), §2.2 and Table 2", url: "https://arxiv.org/abs/2302.13971" },
      p5: { kind: "paper", ref: "Touvron et al. 2023b (Llama 2), §2.2 and Table 1", url: "https://arxiv.org/abs/2307.09288" },
      c1: { kind: "code", repo: "openvla/openvla", path: "prismatic/models/backbones/vision/dinosiglip_vit.py", commit: "c8f03f4", url: "https://github.com/openvla/openvla/blob/c8f03f4/prismatic/models/backbones/vision/dinosiglip_vit.py" },
      c2: { kind: "code", repo: "openvla/openvla", path: "prismatic/util/nn_utils.py", commit: "c8f03f4", url: "https://github.com/openvla/openvla/blob/c8f03f4/prismatic/util/nn_utils.py" },
      c3: { kind: "code", repo: "openvla/openvla", path: "prismatic/conf/models.py", commit: "c8f03f4", url: "https://github.com/openvla/openvla/blob/c8f03f4/prismatic/conf/models.py" },
      c4: { kind: "code", repo: "openvla/openvla", path: "prismatic/vla/action_tokenizer.py", commit: "c8f03f4", url: "https://github.com/openvla/openvla/blob/c8f03f4/prismatic/vla/action_tokenizer.py" },
      c5: { kind: "code", repo: "openvla/openvla", path: "prismatic/conf/vla.py", commit: "c8f03f4", url: "https://github.com/openvla/openvla/blob/c8f03f4/prismatic/conf/vla.py" }
    },
    summary: {
      pattern: ["Autoregressive token VLA", "p1"],
      params: ["7B: ≈ 600M fused vision encoder + projector + Llama 2 7B", "p1"],
      vision: ["DINOv2 ViT-L/14 ‖ SigLIP So400m/14 at 224 × 224 → 256 fused patch tokens", "p1", "p3", "c1"],
      backbone: ["Llama 2 7B: 32 layers, width 4,096, 32 heads, SwiGLU, RoPE", "p4", "p5"],
      head: ["None: the LM head; the last 256 vocabulary ids are the action bins", "p2", "c4"],
      output: ["7 tokens: Δpos (3), Δrot (3), gripper; 256 bins over the 1st–99th percentile", "p1", "p2"],
      attention: ["Causal (Llama decoder) over [image patches | prompt | action tokens]", "p1"],
      cond: ["Prompt: \u201cWhat should the robot do to {task}? A:\u201d", "p1"],
      steps: ["7 autoregressive decoding steps per action", "p2"],
      chunk: ["One action per step", "p2"],
      rate: ["≈ 6 Hz on one RTX 4090 in bfloat16 (15 GB)", "p3"],
      latency: null,
      train: ["970k OXE episodes; 64 A100 × 14 days, batch 2,048, lr 2e-5, 27 epochs", "p3", "c5"]
    },
    changes: [
      "Open weights: a <b>7B Prismatic VLM</b> (Llama 2 7B) replaces the closed 55B PaLI-X.",
      "Vision uses <b>two encoders side by side</b>: DINOv2 (spatial) and SigLIP (semantic) features are concatenated per patch.",
      "Actions are still 256-bin tokens, but the bins span the 1st–99th percentile instead of min–max, and 256 least-used Llama tokens are overwritten.",
      "Trained on 970k Open X-Embodiment episodes, with the vision encoder fine-tuned rather than frozen.",
      "Runs on one consumer GPU: ≈ 6 Hz on an RTX 4090 instead of a TPU cloud."
    ],
    blueprint: {
      headline: "OpenVLA: two ViTs into Llama 2",
      note: "One image goes through DINOv2 and SigLIP in parallel; their patch features are concatenated channel-wise and an MLP maps each of the 256 patches to a Llama token. Llama 2 then decodes 7 action tokens one at a time.",
      towers: [
        { mod: "vis", title: "DINOv2 ‖ SigLIP", sub: "fused vision encoder, ≈ 600M", compact: true,
          input: { label: "Image 224 × 224", caption: "one third-person camera" },
          rows: [
            { t: "embed", label: "Patch embed 14 × 14, ×2", call: ["224 / 14 = 16 → 256 patches each", "p3", "c1"] },
            { t: "group", label: "Two ViTs in parallel", rows: [
              { t: "attn", label: "DINOv2 ViT-L/14 (reg4)" },
              { t: "attn", label: "SigLIP So400m/14" } ] },
            { t: "linear", label: "Concat channels per patch", call: ["Both from the second-to-last layer", "c1"] } ],
          output: { label: "256 fused patch features" } },
        { mod: "proj", title: "MLP projector", sub: "fused-gelu-mlp", compact: true,
          input: { label: "Fused patch feature", caption: "d_v = DINOv2 ‖ SigLIP width" },
          rows: [
            { t: "linear", label: "Linear d_v → 4 d_v · GELU", call: ["Code: 3 Linear layers (paper: 2)", "c2", "c3", "p1"] },
            { t: "linear", label: "Linear → 4,096 · GELU" },
            { t: "linear", label: "Linear 4,096 → 4,096", call: ["Llama width 4,096", "p4"] } ],
          output: { label: "256 image tokens" } },
        { mod: "llama", title: "Llama 2 7B", sub: "decoder-only LM",
          input: { label: "Image + prompt tokens", caption: "then 7 action tokens, one at a time" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["Vocabulary 32k; last 256 ids = action bins", "p5", "c4"] },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm 1 (pre-norm)" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["32 heads, head dim 128", "p4", "p5"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Attention (MHA at 7B)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden ⅔ · 4d (LLaMA)", "p4"], zoom: { k: "glu", act: "SiLU", d: "4,096", ff: "⅔·4d", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "LM head", call: ["Loss on the action tokens only", "p2"],
              zoom: { k: "rows", title: "Action de-tokenizer", rows: ["logits over the last 256 ids", "argmax → bin index", "bin centre in [−1, 1]", "un-normalise with q01, q99", "7-D action: Δx, Δθ, gripper"] } } ],
          output: { label: "7 action tokens → de-tokenize" } }
      ],
      links: [
        { from: "vis", to: "proj", toRow: "input", label: "fused features" },
        { from: "proj", to: "llama", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "vis", role: "vision-enc", name: "DINOv2 + SigLIP", sub: "ViT-L/14 ‖ So400m/14", col: 0, frozen: false, params: "≈ 600M", short: "Vision",
        stack: { rows: [
          { t: "in", label: "image 224 × 224", dims: "resize-naive", c: "data-1" },
          { t: "group", label: "two featurizers, same patches", rows: [
            { t: "attn", label: "DINOv2 ViT-L/14 + 4 registers", note: "features from the second-to-last block" },
            { t: "attn", label: "SigLIP So400m/14", note: "features from the second-to-last block" } ] },
          { t: "linear", label: "concatenate channel-wise per patch" },
          { t: "out", label: "256 fused patch features", c: "data-1" } ],
          facts: [["Encoders", ["vit_large_patch14_reg4_dinov2 + vit_so400m_patch14_siglip_224", "c1"]], ["Layer used", ["second-to-last", "c1"]], ["Resolution", ["224 × 224 (384 gave no gain, 3× cost)", "p3"]], ["Fine-tuned", ["yes: freezing hurt", "p3"]]] } },
      { id: "proj", role: "net", roleLabel: "Projector", name: "MLP projector", sub: "3 Linear · GELU", col: 1, frozen: false, short: "Projector",
        stack: { rows: [
          { t: "in", label: "fused patch feature d_v", c: "data-1" },
          { t: "linear", label: "Linear d_v → 4 d_v" }, { t: "mlp", label: "GELU" },
          { t: "linear", label: "Linear 4 d_v → 4,096" }, { t: "mlp", label: "GELU" },
          { t: "linear", label: "Linear 4,096 → 4,096" },
          { t: "out", label: "image token in Llama space", c: "data-2" } ],
          facts: [["Type", ["fused-gelu-mlp (3 Linear)", "c2", "c3"]], ["Paper wording", ["\u201csmall 2-layer MLP projector\u201d", "p1"]]] } },
      { id: "llama", role: "vlm", name: "Llama 2 7B", sub: "32 × 4096 · 32 heads", col: 2, frozen: false, main: true, params: "7B", short: "Llama 2",
        stack: { rows: [
          { t: "in", label: "[256 image tokens | prompt | action tokens]", dims: "causal", c: "data-2" },
          { t: "embed", label: "token embedding", dims: "vocab 32k" },
          { t: "block", label: "Llama decoder block (pre-norm)", n: "32", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "causal MHA · 32 heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU, hidden ⅔ · 4d" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "LM head", dims: "action ids = last 256 of the vocabulary" },
          { t: "out", label: "7 action tokens", dims: "256 bins, 1st–99th percentile", c: "data-3" } ],
          facts: [["Layers / width / heads", ["32 / 4,096 / 32", "p4"]], ["Attention", ["multi-head (GQA only at 34B, 70B)", "p5"]], ["Norm, FFN, positions", ["RMSNorm pre-norm, SwiGLU, RoPE", "p4", "p5"]], ["Vocabulary", ["32k BPE", "p5"]], ["Action ids", ["last 256 tokens overwritten", "p2", "c4"]]] } }
    ],
    inputs: [
      { to: "vis", mod: "vision", label: "third-person image", n: "224 × 224", k: 4 },
      { to: "llama", mod: "lang", label: "instruction prompt", n: "Llama tokens", k: 3 }
    ],
    outputs: [{ from: "llama", mod: "action", label: "7 action tokens", n: "256 bins each", k: 5 }],
    links: [
      { from: "vis", to: "proj", kind: "feeds", label: "DINOv2 ‖ SigLIP|per patch" },
      { from: "proj", to: "llama", kind: "prefix", label: "256 image tokens" }
    ],
    mask: { name: "Causal (LM)", ref: "p1", axes: [{ label: "image patches", short: "img", mod: "vision" }, { label: "prompt", short: "ℓ", mod: "lang" }, { label: "action tokens", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "A plain decoder mask: action tokens are generated one at a time after the image and prompt." },
    callouts: [
      "Paper §3.1 calls the projector a <b>2-layer MLP</b>; the released config (arch_specifier \u201cno-align+fused-gelu-mlp\u201d) builds <b>3 Linear layers</b> with GELU between them.",
      "Bins: the tokenizer bins uniformly on [−1, 1]; the data pipeline first maps each action dimension's 1st–99th percentile to [−1, 1] (bounds_q99), which gives the paper's quantile bins.",
      "The LoRA and quantisation experiments (§5.3–5.4) use a smaller SigLIP-only variant trained on the Octo mixture, not the DINOv2 + SigLIP model drawn here."
    ]
  });

  /* ------------------------------------------------------------------ RDT-1B */
  RB.arch.spec({
    id: "rdt-1b", method: "rdt-1b", name: "RDT-1B", year: 2024,
    figRef: "Liu et al. Fig. 3 · §4.1 · App. B, C, F", prov: "base.yaml (1B)",
    lede: "A 1.2B diffusion transformer denoises a 64-step chunk in a 128-D unified action space. Its self-attention sees only time, frequency, state and action tokens; frozen SigLIP and T5-XXL tokens enter by cross-attention, alternating language and images by layer.",
    sources: {
      p1: { kind: "paper", ref: "Liu et al. 2025, §4.1 and Fig. 3", url: "https://arxiv.org/abs/2410.07864" },
      p2: { kind: "paper", ref: "Liu et al. 2025, App. B (architecture details)", url: "https://arxiv.org/abs/2410.07864" },
      p3: { kind: "paper", ref: "Liu et al. 2025, App. F, Tables 8–9 (hyperparameters)", url: "https://arxiv.org/abs/2410.07864" },
      p4: { kind: "paper", ref: "Liu et al. 2025, §5.1 (training and inference)", url: "https://arxiv.org/abs/2410.07864" },
      p5: { kind: "paper", ref: "Liu et al. 2025, §4.2 and App. C (unified action space, data)", url: "https://arxiv.org/abs/2410.07864" },
      c1: { kind: "code", repo: "thu-ml/RoboticsDiffusionTransformer", path: "configs/base.yaml", commit: "cd79363", url: "https://github.com/thu-ml/RoboticsDiffusionTransformer/blob/cd79363/configs/base.yaml" },
      c2: { kind: "code", repo: "thu-ml/RoboticsDiffusionTransformer", path: "models/rdt/model.py", commit: "cd79363", url: "https://github.com/thu-ml/RoboticsDiffusionTransformer/blob/cd79363/models/rdt/model.py" },
      c3: { kind: "code", repo: "thu-ml/RoboticsDiffusionTransformer", path: "models/rdt/blocks.py", commit: "cd79363", url: "https://github.com/thu-ml/RoboticsDiffusionTransformer/blob/cd79363/models/rdt/blocks.py" },
      c4: { kind: "code", repo: "thu-ml/RoboticsDiffusionTransformer", path: "models/rdt_runner.py", commit: "cd79363", url: "https://github.com/thu-ml/RoboticsDiffusionTransformer/blob/cd79363/models/rdt_runner.py" },
      c5: { kind: "code", repo: "thu-ml/RoboticsDiffusionTransformer", path: "finetune.sh", commit: "cd79363", url: "https://github.com/thu-ml/RoboticsDiffusionTransformer/blob/cd79363/finetune.sh" }
    },
    summary: {
      pattern: ["Diffusion transformer policy", "p1"],
      params: ["1.2B (the DiT); frozen SigLIP and T5-XXL on top", "p3", "p1"],
      vision: ["Frozen SigLIP So400m/14 at 384²: 3 cameras × 2 frames × 729 = 4,374 tokens", "p1", "c1", "c5"],
      backbone: ["DiT: 28 layers, width 2,048, 32 heads, QKNorm + RMSNorm", "p3", "c1", "c3"],
      head: ["Nonlinear MLP decoder (RMSNorm → MLP) on the action tokens", "p1", "c3"],
      output: ["Clean chunk a₀ (sample prediction): 64 × 128-D unified vector", "p3", "p5", "c1"],
      attention: ["Self-attention over [k, freq, state, 64 actions]; cross-attention alternates language / images", "p2", "c2"],
      cond: ["ACI: block 1 cross-attends to T5-XXL tokens, block 2 to SigLIP tokens, and so on", "p1", "c2"],
      steps: ["Train DDPM 1,000 steps; inference DPM-Solver++ 5 steps", "p3", "c1"],
      chunk: ["Tₐ = 64 actions; 2-frame image history", "p3", "c1"],
      rate: ["6 chunks/s = 381 actions/s on the robot's RTX 4090", "p4"],
      latency: null,
      train: ["Pretrain 46 datasets, 1M+ trajectories (48 H100, 1M steps); fine-tune 6K+ bimanual episodes", "p5", "p4", "p3"]
    },
    blueprint: {
      headline: "RDT: a DiT that reads by cross-attention",
      note: "The denoised sequence is short: diffusion step, control frequency, one state token and 64 action tokens. Every one of the 28 blocks runs self-attention on it, then cross-attention to either the language tokens or the image tokens (alternating), then an MLP.",
      towers: [
        { mod: "siglip", title: "SigLIP So400m/14", sub: "frozen, 384 × 384", compact: true,
          input: { label: "6 images", caption: "3 cameras × 2 frames" },
          rows: [
            { t: "group", label: "SigLIP ViT (frozen)", rows: [{ t: "attn", label: "ViT blocks", call: ["729 tokens per image", "c1", "c5"] }] },
            { t: "mlp", label: "Adaptor: 2-layer MLP", call: ["1,152 → 2,048, GELU", "p3", "c1"] },
            { t: "embed", label: "+ grid position (t, cam, patch)" } ],
          output: { label: "4,374 image tokens" } },
        { mod: "dit", title: "RDT diffusion transformer", sub: "1.2B, x₀-prediction",
          input: { label: "[k | freq | zₜ | ãₜ:ₜ₊₆₄]", caption: "1 + 1 + 1 + 64 = 67 tokens" },
          rows: [
            { t: "mlp", label: "State/action MLP (shared)", call: ["3-layer GELU MLP on [value ‖ mask]", "p3", "c4"] },
            { t: "mlp", label: "k, freq: sinusoid → MLP", call: ["256-d sinusoid → SiLU MLP", "c3"] },
            { t: "embed", label: "+ position embedding" },
            { t: "block", n: "28", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Self-attention · QKNorm", call: ["32 heads, head dim 64", "p3", "c3"], zoom: { k: "heads", q: 32, kv: 32, hd: 64, title: "Self-attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { id: "xa", t: "attn", label: "Cross-attention · QKNorm", side: "cond",
                zoom: { k: "rows", title: "Alternating condition injection", rows: ["odd blocks → T5-XXL tokens", "even blocks → SigLIP tokens", "language pad tokens masked", "Q: chunk · K, V: condition"] } },
              { t: "add", span: 2 },
              { t: "ffn", label: "RMSNorm 3 → feed forward", call: ["2,048 → 2,048 → 2,048, tanh-GELU", "c3"], zoom: { k: "mlp", act: "GELU (tanh)", d: "2,048", ff: "2,048", title: "Feed forward (ratio 1)" } },
              { t: "add", span: 1 } ] },
            { t: "mlp", label: "RMSNorm → MLP decoder", call: ["Keeps the 64 action tokens → 128-D", "c2", "c3"] } ],
          output: { label: "clean chunk a₀: 64 × 128" } },
        { mod: "t5", title: "T5-XXL encoder", sub: "frozen", compact: true,
          input: { label: "Instruction", caption: "up to 1,024 tokens" },
          rows: [
            { t: "group", label: "T5-XXL (frozen)", rows: [{ t: "attn", label: "Encoder blocks", call: ["4,096-d token outputs", "p3", "c1"] }] },
            { t: "mlp", label: "Adaptor: 2-layer MLP", call: ["4,096 → 2,048, GELU", "p3", "c1"] } ],
          output: { label: "language tokens" } }
      ],
      links: [
        { from: "siglip", to: "dit", toRow: "xa", label: "image tokens" },
        { from: "t5", to: "dit", toRow: "xa", label: "language tokens" }
      ]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "384² · 729 tok / image", col: 0, frozen: true, short: "SigLIP" },
      { id: "dit", role: "action-head", roleLabel: "Diffusion transformer", name: "RDT DiT", sub: "28 × 2048 · 32 heads", col: 1, frozen: false, main: true, params: "1.2B", short: "DiT",
        stack: { rows: [
          { t: "in", label: "[k | freq | state zₜ | 64 noisy actions]", dims: "unified 128-D + validity mask", c: "data-3" },
          { t: "mlp", label: "state/action adaptor: 3-layer GELU MLP", dims: "(128 + 128) → 2,048" },
          { t: "mlp", label: "k and freq: sinusoid 256 → Linear · SiLU · Linear", dims: "→ 2,048 each" },
          { t: "embed", label: "+ position embedding", dims: "67 positions" },
          { t: "block", label: "RDT block", n: "28", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "self-attention · 32 heads · QKNorm" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "cross-attention → language or images", side: "cond" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "MLP 2,048 → 2,048 · tanh-GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "final RMSNorm" },
          { t: "mlp", label: "MLP decoder → 128", dims: "last 64 tokens kept" },
          { t: "out", label: "clean action chunk a₀", dims: "DPM-Solver++, 5 steps", c: "data-3" } ],
          facts: [["Layers / width / heads", ["28 / 2,048 / 32", "p3", "c1"]], ["Norms", ["RMSNorm + QKNorm", "p1", "c3"]], ["FFN hidden", ["2,048 (ratio 1)", "c3"]], ["Prediction", ["sample (x₀), MSE", "p1", "c1"]], ["Schedule", ["squaredcos_cap_v2, 1,000 train steps", "p3", "c1"]], ["Action space", ["128-D unified, chunk 64", "p5", "c1"]], ["Modality dropout", ["each input masked with p = 10 %", "p2"]]] } },
      { id: "t5", role: "lang", name: "T5-XXL", sub: "4,096-d · ≤ 1,024 tokens", col: 2, frozen: true, short: "T5-XXL" }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "3 cameras × 2 frames", n: "384 × 384", k: 5 },
      { to: "dit", mod: "state", label: "proprio zₜ", n: "128-D", k: 1 },
      { to: "dit", mod: "action", label: "noisy chunk", n: "64 × 128", k: 5, noisy: true },
      { to: "dit", mod: "time", label: "step k, freq", n: "sinusoid", k: 2 },
      { to: "t5", mod: "lang", label: "instruction", n: "≤ 1,024 tokens", k: 3 }
    ],
    outputs: [{ from: "dit", mod: "action", label: "clean chunk a₀", n: "64 × 128", k: 5 }],
    links: [
      { from: "siglip", to: "dit", kind: "cross-attn", label: "MLP adaptor|even blocks" },
      { from: "t5", to: "dit", kind: "cross-attn", label: "MLP adaptor|odd blocks" }
    ],
    mask: { name: "Full (self-attention)", ref: "p2", axes: [{ label: "k + freq", short: "k,f", mod: "time" }, { label: "state", short: "z", mod: "state" }, { label: "actions", short: "a", mod: "action" }], m: ["111", "111", "111"],
      note: "Conditions never enter the self-attention sequence; images and language arrive only through cross-attention." },
    callouts: [
      "Paper App. B encodes low-dimensional inputs with \u201cMLPs (with Fourier features)\u201d; in the code the state/action adaptor is a plain <b>3-layer GELU MLP</b>, and only k and the control frequency get sinusoidal embeddings.",
      "Every block's feed-forward keeps width 2,048 (hidden = hidden_size in blocks.py), not the usual 4×.",
      "Image tokens outnumber language tokens: 4,374 versus at most 1,024. Alternating the cross-attention stops the images from drowning out the instruction (Fig. 4b)."
    ]
  });
})();
