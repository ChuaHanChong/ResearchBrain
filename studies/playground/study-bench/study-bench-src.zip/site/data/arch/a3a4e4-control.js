/* Architecture specs, topics A3 (deep RL), A4 (sim-to-real) and E4 (humanoid control). Numbers from the papers and, where released, the official code; see sources. */
(function () {
  var RB = window.RB;
  function gh(repo, commit, path) { return { kind: "code", repo: repo, path: path, commit: commit, url: "https://github.com/" + repo + "/blob/" + commit + "/" + path }; }
  function ax(ref, id) { return { kind: "paper", ref: ref, url: "https://arxiv.org/abs/" + id }; }

  /* ───────────────────────── A3 · DQN ───────────────────────── */
  RB.arch.spec({
    id: "dqn", method: "dqn", name: "DQN", year: 2013,
    figRef: "Mnih et al. §4.1 · §5 · Alg. 1", prov: "Paper only; no official code",
    lede: "A small CNN reads the last four grayscale frames and outputs one Q-value per joystick action, so a single forward pass scores every action. Experience replay and ε-greedy exploration make Q-learning with a deep net stable.",
    sources: {
      p1: ax("Mnih et al. 2013, §4.1 (preprocessing and architecture)", "1312.5602"),
      p2: ax("Mnih et al. 2013, §5 (training details)", "1312.5602"),
      p3: ax("Mnih et al. 2013, §4 and Algorithm 1 (experience replay)", "1312.5602")
    },
    summary: {
      pattern: ["Q-network (value-based RL)", "p1"],
      params: null,
      vision: ["84 × 84 × 4: last 4 grayscale frames, downsampled and cropped", "p1"],
      backbone: ["Conv 16 × 8×8 /4 → Conv 32 × 4×4 /2 → FC 256, all ReLU", "p1"],
      head: ["Linear layer: one Q-value per valid action (4–18 per game)", "p1"],
      output: ["Q(φ, a) for all actions in one pass; ε-greedy action", "p1", "p3"],
      attention: "None (convolutions only)",
      cond: "None: the action is an output index, not an input",
      steps: null, chunk: null,
      rate: ["Frame skip k = 4 (k = 3 for Space Invaders)", "p2"],
      latency: null,
      train: ["RMSProp, minibatch 32, replay of the last 1M frames, 10M frames per game", "p2"]
    },
    blueprint: {
      headline: "DQN: pixels in, one Q per action",
      note: "The conv torso turns a stack of four frames into a 256-unit feature; a linear head scores every action at once. Targets come from the same network (no separate target net in this paper), and minibatches are drawn uniformly from a replay memory.",
      towers: [
        { mod: "torso", title: "Conv torso", sub: "shared by all actions", compact: true,
          input: { label: "Frame stack φ(s)", caption: "84 × 84 × 4 grayscale" },
          rows: [
            { t: "conv", label: "Conv 8×8, stride 4 · ReLU", call: ["16 filters", "p1"], zoom: { k: "rows", title: "Preprocessing φ", rows: ["Atari frame 210 × 160, 128 colours", "grayscale, downsample to 110 × 84", "crop 84 × 84 playing area", "stack the last 4 frames"] } },
            { t: "conv", label: "Conv 4×4, stride 2 · ReLU", call: ["32 filters", "p1"] },
            { t: "linear", label: "Fully connected · ReLU", call: ["256 rectifier units", "p1"] } ],
          output: { label: "256-d state feature" } },
        { mod: "qhead", title: "Q head", sub: "separate output unit per action", compact: true,
          input: { label: "256-d feature", caption: "no action input" },
          rows: [
            { id: "q", t: "linear", label: "Linear → |A| Q-values", call: ["4 to 18 valid actions per game", "p1"], zoom: { k: "rows", title: "Replay and target", rows: ["store (φₜ, aₜ, rₜ, φₜ₊₁) in memory D", "sample a minibatch of 32 from D", "y = r + γ · maxₐ′ Q(φ′, a′)", "gradient step on (y − Q(φ, a))²"] } },
            { t: "mlp", label: "ε-greedy over the Q-values", call: ["ε: 1 → 0.1 over the first 1M frames", "p2"] } ],
          output: { label: "action aₜ" } }
      ],
      links: [{ from: "torso", to: "qhead", toRow: "input", label: "256-d feature" }]
    },
    modules: [
      { id: "torso", role: "vision-enc", name: "Conv torso", sub: "2 conv + FC 256", col: 0, frozen: false, short: "CNN",
        stack: { rows: [
          { t: "in", label: "4 stacked frames", dims: "84 × 84 × 4", c: "data-1" },
          { t: "conv", label: "Conv 16 filters 8×8, stride 4 · ReLU" },
          { t: "conv", label: "Conv 32 filters 4×4, stride 2 · ReLU" },
          { t: "linear", label: "Fully connected 256 · ReLU" },
          { t: "out", label: "state feature", dims: "256", c: "data-1" } ],
          facts: [["Input", ["84 × 84 × 4", "p1"]], ["Conv 1", ["16 × 8×8, stride 4", "p1"]], ["Conv 2", ["32 × 4×4, stride 2", "p1"]], ["Hidden", ["256 ReLU", "p1"]]] } },
      { id: "qhead", role: "critic", roleLabel: "Q-values", name: "Linear Q head", sub: "one unit per action", col: 1, frozen: false, main: true, short: "Q head",
        stack: { rows: [
          { t: "in", label: "256-d feature", dims: "from the torso", c: "data-1" },
          { t: "linear", label: "Linear → one Q per action", dims: "4–18 outputs" },
          { t: "out", label: "Q(φ, a) for every a", dims: "argmax or ε-greedy", c: "data-3" } ],
          facts: [["Outputs", ["4–18 (per game)", "p1"]], ["Optimizer", ["RMSProp, minibatch 32", "p2"]], ["Replay", ["last 1M frames, uniform sampling", "p2", "p3"]], ["Exploration", ["ε 1 → 0.1 over 1M frames, then 0.1", "p2"]], ["Rewards", ["clipped to −1, 0, +1", "p2"]]] } }
    ],
    inputs: [{ to: "torso", mod: "vision", label: "4 grayscale frames", n: "84 × 84 × 4", k: 4 }],
    outputs: [{ from: "qhead", mod: "action", label: "Q per action", n: "4–18", k: 3 }],
    links: [{ from: "torso", to: "qhead", kind: "feeds", label: "256-d feature" }],
    callouts: [
      "The same architecture and hyperparameters were used for all seven Atari games; only the frame skip changes for Space Invaders.",
      "This is the 2013 workshop network; the 2015 Nature DQN is a separate paper and is not drawn here."
    ]
  });

  /* ───────────────────────── A3 · DDPG ───────────────────────── */
  RB.arch.spec({
    id: "ddpg", method: "ddpg", name: "DDPG", year: 2015, parent: "dqn",
    diffRows: ["pattern", "vision", "backbone", "head", "output", "cond", "train"],
    figRef: "Lillicrap et al. §3 · Alg. 1 · Supp. §7", prov: "Paper supplement; no official code",
    lede: "A deterministic actor μ(s) and a critic Q(s, a), both small MLPs (400 → 300). The actor climbs the critic's action-gradient; replay, soft target copies and batch norm keep it stable.",
    sources: {
      p1: ax("Lillicrap et al. 2015, §3 and Algorithm 1", "1509.02971"),
      p2: ax("Lillicrap et al. 2015, Supplement §7 (experiment details)", "1509.02971"),
      p3: ax("Lillicrap et al. 2015, §4 (pixel inputs, action repeat)", "1509.02971")
    },
    summary: {
      pattern: ["Actor–critic", "p1"],
      params: ["≈130,000 (low-d) · ≈430,000 (pixels)", "p2"],
      vision: ["Pixels: 3 conv layers of 32 filters, no pooling, on 64 × 64 RGB × 3 repeats", "p2", "p3"],
      backbone: ["Low-d: 2 hidden layers of 400 and 300 ReLU units (actor and critic)", "p2"],
      head: ["Actor: tanh output; critic: scalar Q, action enters at the 2nd hidden layer", "p2"],
      output: ["Continuous action a = μ(s) + Ornstein–Uhlenbeck noise", "p1", "p2"],
      attention: "None (MLP / conv)",
      cond: ["Critic takes a only from its 2nd hidden layer (low-d) or at the FC layers (pixels)", "p2"],
      steps: null, chunk: null,
      rate: ["Pixels: each agent step repeats the action for 3 simulator steps", "p3"],
      latency: null,
      train: ["Adam 10⁻⁴ (actor) / 10⁻³ (critic), γ 0.99, τ 0.001, replay 10⁶", "p2"]
    },
    changes: [
      "The action becomes a <b>continuous input</b> to the critic instead of one output unit per action.",
      "A separate <b>actor network μ(s)</b> replaces the argmax, trained by the critic's gradient ∇ₐQ.",
      "<b>Soft target copies</b> μ′ and Q′ track the learned nets with τ = 0.001.",
      "Batch normalization on the state input and hidden layers handles mixed physical units.",
      "Exploration uses temporally correlated Ornstein–Uhlenbeck noise instead of ε-greedy."
    ],
    blueprint: {
      headline: "DDPG: a deterministic actor on a Q critic",
      note: "The actor maps the state to an action; the critic scores (s, a), with the action joining after the first hidden layer. The actor is updated by back-propagating ∇ₐQ through μ, and both have slowly tracking target copies used only for the Bellman target.",
      towers: [
        { mod: "actor", title: "Actor μ(s | θμ)", sub: "low-dimensional version",
          input: { label: "State s", caption: "joint angles, positions (low-d)" },
          rows: [
            { t: "norm", label: "Batch norm on the state input" },
            { t: "linear", label: "Hidden 1 · ReLU", call: ["400 units", "p2"] },
            { t: "linear", label: "Hidden 2 · ReLU", call: ["300 units", "p2"] },
            { t: "linear", label: "Output · tanh", call: ["Final weights U[−3·10⁻³, 3·10⁻³]", "p2"], zoom: { k: "rows", title: "Ornstein–Uhlenbeck exploration", rows: ["μ′(sₜ) = μ(sₜ | θμ) + 𝒩ₜ", "d𝒩 = θ(0 − 𝒩)dt + σ dW", "θ = 0.15, σ = 0.2", "noise off at evaluation"] } } ],
          output: { label: "action a = μ(s)" } },
        { mod: "critic", title: "Critic Q(s, a | θQ)", sub: "action joins at the 2nd layer",
          input: { label: "State s", caption: "same observation as the actor" },
          rows: [
            { t: "norm", label: "Batch norm before the action input" },
            { t: "linear", label: "Hidden 1 · ReLU", call: ["400 units, L2 decay 10⁻²", "p2"] },
            { id: "a", t: "linear", label: "Hidden 2 · ReLU, [h₁ ‖ a]", side: "cond", call: ["300 units", "p2"] },
            { t: "linear", label: "Output: scalar Q", zoom: { k: "rows", title: "Soft target update", rows: ["y = r + γ Q′(s′, μ′(s′))", "critic: minimize (y − Q(s, a))²", "actor: ascend ∇ₐQ · ∇θμ", "θ′ ← τθ + (1 − τ)θ′, τ = 0.001"] } } ],
          output: { label: "Q(s, a); ∇ₐQ to the actor" } }
      ],
      links: [{ from: "actor", to: "critic", toRow: "a", label: "a = μ(s)" }]
    },
    modules: [
      { id: "actor", role: "action-head", roleLabel: "Actor", name: "Actor μ(s)", sub: "400 → 300 · tanh", col: 0, frozen: false, main: true, short: "μ",
        stack: { rows: [
          { t: "in", label: "state s (or 3 conv layers on pixels)", dims: "low-d or 64 × 64 × 9", c: "data-5" },
          { t: "norm", label: "Batch norm (input and hidden layers)" },
          { t: "linear", label: "Linear 400 · ReLU" }, { t: "linear", label: "Linear 300 · ReLU" },
          { t: "linear", label: "Linear → action dim · tanh" },
          { t: "out", label: "deterministic action μ(s)", dims: "+ OU noise when acting", c: "data-3" } ],
          facts: [["Hidden", ["400, 300 (low-d); 200, 200 after 3 convs (pixels)", "p2"]], ["Learning rate", ["10⁻⁴", "p2"]], ["Minibatch", ["64 (low-d), 16 (pixels)", "p2"]], ["Output init", ["U[−3 × 10⁻³, 3 × 10⁻³] (low-d)", "p2"]]] } },
      { id: "critic", role: "critic", name: "Critic Q(s, a)", sub: "400 → [·‖a] 300", col: 1, frozen: false, short: "Q",
        stack: { rows: [
          { t: "in", label: "state s", dims: "same as the actor", c: "data-5" },
          { t: "norm", label: "Batch norm (layers before the action)" },
          { t: "linear", label: "Linear 400 · ReLU" },
          { t: "linear", label: "concat action a → Linear 300 · ReLU", side: "cond" },
          { t: "linear", label: "Linear → 1" },
          { t: "out", label: "Q(s, a)", dims: "∇ₐQ drives the actor", c: "data-8" } ],
          facts: [["Learning rate", ["10⁻³, L2 weight decay 10⁻²", "p2"]], ["Discount", ["γ = 0.99", "p2"]], ["Targets", ["soft copies, τ = 0.001", "p2"]], ["Replay", ["10⁶ transitions", "p2"]]] } }
    ],
    inputs: [
      { to: "actor", mod: "state", label: "state s", n: "low-d or pixels", k: 3 },
      { to: "critic", mod: "state", label: "state s", n: "same obs", k: 3 }
    ],
    outputs: [{ from: "actor", mod: "action", label: "continuous a", n: "tanh-bounded", k: 3 }, { from: "critic", mod: "other", label: "Q(s, a)", n: "scalar", k: 1 }],
    links: [{ from: "actor", to: "critic", kind: "feeds", label: "a = μ(s)|∇ₐQ back" }],
    callouts: [
      "Replay buffer + target networks come from DQN; the new piece is the deterministic policy gradient ∇θJ ≈ E[∇ₐQ · ∇θμ].",
      "The paper learns 20+ MuJoCo tasks with one set of hyperparameters, and many of them from pixels as well."
    ]
  });

  /* ───────────────────────── A3 · SAC ───────────────────────── */
  RB.arch.spec({
    id: "sac", method: "sac", name: "SAC", year: 2018, parent: "ddpg",
    diffRows: ["head", "output", "cond", "train"],
    figRef: "Haarnoja et al. §4.2 · Alg. 1 · App. C, D", prov: "Gaussian policy, MuJoCo runner",
    lede: "Soft actor-critic: a tanh-squashed Gaussian policy, two soft Q-networks and a soft value network with an EMA target, all 2 × 256 ReLU MLPs. The policy maximizes Q plus entropy through reparameterized samples.",
    sources: {
      p1: ax("Haarnoja et al. 2018, §4.2 and Algorithm 1", "1801.01290"),
      p2: ax("Haarnoja et al. 2018, App. D, Tables 1–2 (hyperparameters)", "1801.01290"),
      p3: ax("Haarnoja et al. 2018, App. C (tanh squashing)", "1801.01290"),
      c1: gh("haarnoja/sac", "8258e33", "examples/variants.py"),
      c2: gh("haarnoja/sac", "8258e33", "examples/mujoco_all_sac.py"),
      c3: gh("haarnoja/sac", "8258e33", "sac/distributions/normal.py")
    },
    summary: {
      pattern: ["Actor–critic (maximum entropy)", "p1"],
      params: null,
      vision: "None: low-dimensional MuJoCo state",
      backbone: ["All networks: 2 hidden layers × 256 units, ReLU", "p2", "c1", "c2"],
      head: ["Policy: Gaussian mean and log σ (clipped to [−20, 2]); two Q heads; one V head", "p1", "c3"],
      output: ["a = tanh(u), u ~ 𝒩(μφ(s), σφ(s)); mean action at evaluation", "p3"],
      attention: "None (MLPs)",
      cond: ["Q-nets take [s ‖ a]; V and π take s", "p1", "c2"],
      steps: ["1 gradient step per environment step (4 for the hard-update variant)", "p2"],
      chunk: null, rate: null, latency: null,
      train: ["Adam 3 × 10⁻⁴, γ 0.99, batch 256, replay 10⁶, τ 0.005, reward scale 5–20", "p2", "c1"]
    },
    changes: [
      "The deterministic actor becomes a <b>stochastic tanh-Gaussian policy</b> trained through the reparameterization trick.",
      "The objective adds <b>policy entropy</b>; the reward scale sets its temperature.",
      "<b>Two Q-networks</b>; the minimum is used for the value and policy gradients (clipped double-Q).",
      "A separate <b>soft value network V</b> with an EMA target V̄ supplies the Bellman target.",
      "Hidden layers grow from 400/300 to 256/256 and batch norm is dropped."
    ],
    blueprint: {
      headline: "SAC: entropy-seeking actor, twin critics",
      note: "Every network is a 2 × 256 ReLU MLP. The policy samples ã = tanh(μ + σ·ε); the twin critics score it and their minimum trains both V and π. V's slow copy V̄ provides the target for the critics, so no target actor is needed.",
      towers: [
        { mod: "policy", title: "Policy πφ(a | s)", sub: "tanh-squashed Gaussian",
          input: { label: "State sₜ", caption: "MuJoCo observation" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "linear", label: "Linear · ReLU", call: ["256 units", "p2", "c1"] }] },
            { t: "linear", label: "Heads: mean μ, log σ", call: ["log σ clipped to [−20, 2]", "c3"] },
            { t: "mlp", label: "ã = tanh(μ + σ ⊙ ε)", zoom: { k: "rows", title: "Tanh squashing (App. C)", rows: ["u ~ 𝒩(μφ(s), σφ(s))", "a = tanh(u) ∈ (−1, 1)", "log π −= Σᵢ log(1 − tanh² uᵢ)", "evaluate with the mean action"] } } ],
          output: { label: "action ã, log π(ã | s)" } },
        { mod: "critics", title: "Twin soft Q-functions", sub: "Qθ₁, Qθ₂ trained independently",
          input: { label: "[sₜ ‖ aₜ]", caption: "state and action" },
          rows: [
            { id: "qin", t: "linear", label: "Concat state and action", side: "cond" },
            { t: "block", n: "2", rows: [{ t: "linear", label: "Linear · ReLU", call: ["256 units", "p2", "c2"] }] },
            { t: "linear", label: "Linear → Q (×2 networks)", zoom: { k: "rows", title: "Soft Bellman targets", rows: ["Q̂ = r + γ V̄(s′)", "V target: min Qᵢ(s, ã) − log π(ã|s)", "π loss: log π(ã|s) − min Qᵢ(s, ã)", "V̄ ← τV + (1 − τ)V̄, τ = 0.005"] } } ],
          output: { label: "min(Q₁, Q₂) for V and π" } },
        { mod: "value", title: "Soft value Vψ", sub: "plus EMA target V̄ψ̄", compact: true,
          input: { label: "State sₜ", caption: "no action input" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "linear", label: "Linear · ReLU", call: ["256 units", "p2", "c2"] }] },
            { t: "linear", label: "Linear → V(s)" } ],
          output: { label: "V̄(s′) for the Q target" } }
      ],
      links: [{ from: "policy", to: "critics", toRow: "qin", label: "reparameterized ã" }]
    },
    modules: [
      { id: "policy", role: "action-head", roleLabel: "Stochastic actor", name: "Gaussian policy π", sub: "2 × 256 · tanh squash", col: 0, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "state s", dims: "MuJoCo observation", c: "data-5" },
          { t: "linear", label: "Linear 256 · ReLU" }, { t: "linear", label: "Linear 256 · ReLU" },
          { t: "linear", label: "mean μ and log σ heads", dims: "2 × action dim" },
          { t: "mlp", label: "u = μ + σ ⊙ ε, a = tanh(u)" },
          { t: "out", label: "action a and log π(a|s)", dims: "change-of-variables correction", c: "data-3" } ],
          facts: [["Hidden", ["2 × 256 ReLU", "p2", "c1"]], ["log σ range", ["[−20, 2]", "c3"]], ["Regularization", ["1e-3 on the Gaussian parameters (code)", "c1"]], ["Learning rate", ["3 × 10⁻⁴ (Adam)", "p2"]]] } },
      { id: "critics", role: "critic", name: "Twin Q-networks", sub: "2 × (2 × 256) on [s‖a]", col: 1, frozen: false, short: "Q₁, Q₂",
        stack: { rows: [
          { t: "in", label: "[s ‖ a]", dims: "state and action", c: "data-3" },
          { t: "linear", label: "Linear 256 · ReLU" }, { t: "linear", label: "Linear 256 · ReLU" },
          { t: "linear", label: "Linear → scalar Q" },
          { t: "out", label: "Q₁, Q₂", dims: "min used downstream", c: "data-8" } ],
          facts: [["Count", ["2 Q-functions", "p1", "c2"]], ["Hidden", ["2 × 256", "p2", "c2"]], ["Batch", ["256", "p2"]], ["Replay", ["10⁶", "p2"]]] } },
      { id: "value", role: "critic", roleLabel: "State value", name: "Soft value V", sub: "2 × 256 + EMA target", col: 2, frozen: false, short: "V",
        stack: { rows: [
          { t: "in", label: "state s", dims: "", c: "data-5" },
          { t: "linear", label: "Linear 256 · ReLU" }, { t: "linear", label: "Linear 256 · ReLU" },
          { t: "linear", label: "Linear → V(s)" },
          { t: "out", label: "V(s); target V̄ via EMA", dims: "τ = 0.005", c: "data-8" } ],
          facts: [["Target", ["EMA, τ = 0.005, every step", "p2", "c1"]], ["Hard-update variant", ["copy every 1,000 steps", "p2"]]] } }
    ],
    inputs: [
      { to: "policy", mod: "state", label: "state s", n: "MuJoCo", k: 3 },
      { to: "critics", mod: "action", label: "action a", n: "3–21 dims", k: 2 },
      { to: "value", mod: "state", label: "state s", n: "MuJoCo", k: 3 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "tanh-Gaussian action", n: "(−1, 1)ᵈ", k: 3 }],
    links: [
      { from: "policy", to: "critics", kind: "feeds", label: "ã, log π" },
      { from: "critics", to: "value", kind: "feeds", label: "min Q − log π|→ V target" }
    ],
    callouts: [
      "The reward scale acts as the inverse temperature: 5 for most MuJoCo tasks, 20 for Humanoid (gym) and 10 for Humanoid (rllab) (App. D, Table 2).",
      "Later SAC versions (Haarnoja et al. 2018b) drop V and learn the temperature α automatically; HIL-SERL and RLPD use that form."
    ]
  });

  /* ───────────────────────── A3 · QT-Opt ───────────────────────── */
  RB.arch.spec({
    id: "qt-opt", method: "qt-opt", name: "QT-Opt", year: 2018, parent: "dqn",
    diffRows: ["vision", "backbone", "head", "output", "cond", "train"],
    figRef: "Kalashnikov et al. Fig. 13 · §4–5 · App. E, F", prov: "Critic code in tensor2robot",
    lede: "No actor: a 1.2M-parameter conv Q-function scores (image, action) pairs, and the cross-entropy method searches for the best action both for Bellman targets and on the robot. Action and gripper state enter mid-network by broadcast addition.",
    sources: {
      p1: ax("Kalashnikov et al. 2018, §4.1–4.2 (QT-Opt, CEM)", "1806.10293"),
      p2: ax("Kalashnikov et al. 2018, §5 (grasping MDP, data)", "1806.10293"),
      p3: ax("Kalashnikov et al. 2018, App. E, Fig. 13 (Q-network)", "1806.10293"),
      p4: ax("Kalashnikov et al. 2018, §4.3 and App. F (distributed system)", "1806.10293"),
      c1: gh("google-research/tensor2robot", "034f49c", "research/qtopt/networks.py")
    },
    summary: {
      pattern: ["Q-network (value-based RL)", "p1"],
      params: ["1.2M (Q-function)", "p2"],
      vision: ["Over-the-shoulder RGB 472 × 472; 7 conv layers before the action merge", "p2", "p3"],
      backbone: ["Conv 64 6×6/2 → pool → 6 × conv 5×5 → pool → ⊕ action → 6 × conv 3×3 → pool → 3 × conv 3×3", "p3", "c1"],
      head: ["FC 64 → FC 64 → 1 logit → sigmoid, Q ∈ [0, 1]", "p3", "c1"],
      output: ["Q(s, a); the action is argmaxₐ Q found by CEM", "p1"],
      attention: "None (convolutions)",
      cond: ["Action + gripper open + height → FC 256 (summed) → FC 64 → tiled and added to the conv map", "p3", "c1"],
      steps: ["CEM: 64 samples, 6 elites, 2 iterations", "p1"],
      chunk: ["Episodes of up to 20 time steps", "p2"],
      rate: null, latency: null,
      train: ["580k real grasps from 7 robots; 10 GPUs, batch 32; log loss; 2 target nets", "p1", "p4"]
    },
    changes: [
      "The Q-network takes the <b>action as an input</b> (continuous 3-D move, rotation, gripper and stop commands), not one output per action.",
      "The argmax over actions is done by the <b>cross-entropy method</b>, not by reading output units.",
      "The action embedding is <b>added to the conv feature map</b> halfway up the network.",
      "Output is a <b>sigmoid</b> trained with cross-entropy, since returns lie in [0, 1].",
      "Two target networks (Polyak 0.9999 and a ~6,000-step lagged copy) give clipped double-Q targets."
    ],
    blueprint: {
      headline: "QT-Opt: a Q-function, no actor",
      note: "The image goes up seven conv layers; the action and the gripper state are embedded by fully connected layers, tiled over the map and added. Nine more conv layers and two FC layers produce a sigmoid Q. CEM calls this network many times per decision, reusing the image features for every sampled action.",
      towers: [
        { mod: "act", title: "Action + state embed", sub: "FC layers, then tiled", compact: true,
          input: { label: "a = (t, r, g_open, g_close, e)", caption: "+ gripper open? + gripper height" },
          rows: [
            { t: "linear", label: "FC per input, summed", call: ["256 units each", "p3", "c1"] },
            { t: "norm", label: "BatchNorm · ReLU" },
            { t: "linear", label: "FC → reshape 1 × 1 × 64", call: ["64 channels", "p3", "c1"], zoom: { k: "rows", title: "Action space", rows: ["t ∈ ℝ³: gripper translation", "r ∈ ℝ²: sin/cos of the yaw change", "g_open, g_close: gripper", "e: terminate the episode"] } } ],
          output: { label: "64-d action context" } },
        { mod: "qnet", title: "Grasping Q-function", sub: "conv stack, 1.2M parameters",
          input: { label: "RGB image 472 × 472", caption: "over-the-shoulder camera" },
          rows: [
            { t: "conv", label: "Conv 6×6, stride 2 · pool 3", call: ["64 filters, then max-pool 3 × 3 / 3", "p3", "c1"] },
            { t: "block", n: "6", rows: [{ t: "conv", label: "Conv 5×5 · BN · ReLU", call: ["64 filters", "p3", "c1"] }] },
            { t: "pool", label: "Max-pool 3 × 3, stride 3" },
            { id: "merge", t: "linear", label: "⊕ tiled action embedding", side: "cond" },
            { t: "block", n: "6", rows: [{ t: "conv", label: "Conv 3×3 · BN · ReLU", call: ["64 filters", "p3", "c1"] }] },
            { t: "pool", label: "Max-pool 2 × 2, stride 2" },
            { t: "block", n: "3", rows: [{ t: "conv", label: "Conv 3×3 (valid)", call: ["64 filters", "c1"] }] },
            { t: "linear", label: "FC 64 · FC 64", call: ["2 hidden FC layers of 64", "p3", "c1"] },
            { t: "linear", label: "Linear → 1 · sigmoid", zoom: { k: "rows", title: "CEM action search", rows: ["sample N = 64 actions", "score all with Q(s, ·)", "refit to the best M = 6", "2 iterations; take the best"] } } ],
          output: { label: "Q(s, a) ∈ [0, 1]" } }
      ],
      links: [{ from: "act", to: "qnet", toRow: "merge", label: "broadcast add" }]
    },
    modules: [
      { id: "act", role: "state-enc", roleLabel: "Action / state embed", name: "Action embedding", sub: "FC 256 (sum) → FC 64", col: 0, frozen: false, short: "embed",
        stack: { rows: [
          { t: "in", label: "action + gripper aperture + height", dims: "grasp parameters", c: "data-3" },
          { t: "linear", label: "FC 256 per input block, summed" },
          { t: "norm", label: "BatchNorm · ReLU" },
          { t: "linear", label: "FC 64 · reshape to 1 × 1 × 64" },
          { t: "out", label: "tiled over the conv map", dims: "added element-wise", c: "data-3" } ],
          facts: [["First FC", ["256, one per input block, summed", "c1"]], ["Second FC", ["64", "p3", "c1"]], ["Merge", ["broadcast element-wise addition", "p3"]]] } },
      { id: "qnet", role: "critic", roleLabel: "Q-function", name: "Grasping Q-network", sub: "16 conv + 2 FC · 64 ch", col: 1, frozen: false, main: true, short: "Q",
        stack: { rows: [
          { t: "in", label: "RGB image", dims: "472 × 472 × 3", c: "data-1" },
          { t: "conv", label: "Conv 64, 6×6 stride 2 → max-pool 3" },
          { t: "block", label: "Conv 64, 5×5", n: "6", rows: [{ t: "conv", label: "Conv · BatchNorm · ReLU" }] },
          { t: "pool", label: "Max-pool 3" },
          { t: "linear", label: "+ action context (tiled)", side: "cond" },
          { t: "block", label: "Conv 64, 3×3", n: "6", rows: [{ t: "conv", label: "Conv · BatchNorm · ReLU" }] },
          { t: "pool", label: "Max-pool 2" },
          { t: "block", label: "Conv 64, 3×3 valid", n: "3", rows: [{ t: "conv", label: "Conv · BatchNorm · ReLU" }] },
          { t: "linear", label: "Flatten → FC 64 → FC 64" },
          { t: "linear", label: "FC → 1 logit → sigmoid" },
          { t: "out", label: "Q(s, a)", dims: "grasp success probability", c: "data-8" } ],
          facts: [["Parameters", ["1.2M", "p2"]], ["Conv layers", ["7 before the merge, 9 after", "p3", "c1"]], ["Init / L2", ["truncated normal σ 0.01, L2 7e−5", "p3"]], ["Optimizer", ["SGD + momentum 0.9, lr 10⁻⁴", "p3"]], ["Targets", ["Polyak 0.9999 + lagged copy, clipped double-Q", "p1"]]] } }
    ],
    inputs: [
      { to: "qnet", mod: "vision", label: "RGB image", n: "472 × 472", k: 4 },
      { to: "act", mod: "action", label: "candidate action", n: "3 + 2 + 3 dims", k: 3 },
      { to: "act", mod: "state", label: "gripper open, height", n: "2", k: 1 }
    ],
    outputs: [{ from: "qnet", mod: "other", label: "Q(s, a)", n: "∈ [0, 1]", k: 1 }],
    links: [{ from: "act", to: "qnet", kind: "film", label: "tiled + added|mid-network" }],
    callouts: [
      "1,000 Bellman-updater jobs run CEM with the target network to label replayed transitions; 10 GPU workers train on them asynchronously (§4.3).",
      "OpenWAM-style reading: the action is a conditioning input to a perception network, not a token; the \"policy\" is an optimizer over that network."
    ]
  });

  /* ───────────────────────── A3 · HIL-SERL ───────────────────────── */
  RB.arch.spec({
    id: "hil-serl", method: "hil-serl", name: "HIL-SERL", year: 2024, parent: "sac",
    diffRows: ["vision", "backbone", "head", "output", "train", "rate"],
    figRef: "Luo et al. Fig. 2 · §3.2–3.5 · App. A, B", prov: "Single-arm hybrid SAC agent",
    lede: "RLPD-style SAC on real robots: a frozen ImageNet ResNet-10 encodes each 128 × 128 camera crop, a 64-d proprio embedding joins it, and 256 × 256 MLPs form the actor and the critic ensemble. A separate DQN grasp critic picks the discrete gripper command.",
    sources: {
      p1: ax("Luo et al. 2024, §3.1–3.3 and Fig. 2", "2410.21845"),
      p2: ax("Luo et al. 2024, §3.5 (training process)", "2410.21845"),
      p3: ax("Luo et al. 2024, App. A, Tables 2–12 (per-task settings)", "2410.21845"),
      p4: ax("Luo et al. 2024, App. B (reward classifier)", "2410.21845"),
      c1: gh("rail-berkeley/hil-serl", "c32939b", "serl_launcher/serl_launcher/utils/launcher.py"),
      c2: gh("rail-berkeley/hil-serl", "c32939b", "serl_launcher/serl_launcher/vision/resnet_v1.py"),
      c3: gh("rail-berkeley/hil-serl", "c32939b", "serl_launcher/serl_launcher/common/encoding.py"),
      c4: gh("rail-berkeley/hil-serl", "c32939b", "serl_launcher/serl_launcher/agents/continuous/sac_hybrid_single.py")
    },
    summary: {
      pattern: ["Actor–critic", "p1"],
      params: null,
      vision: ["ImageNet ResNet-10 (frozen, GroupNorm), 128 × 128 crops per wrist/side camera", "p1", "p2", "c2", "c4"],
      backbone: ["Per camera: 8 learned spatial embeddings → Dense 256 · LayerNorm · tanh; proprio → Dense 64", "c2", "c3", "c4"],
      head: ["Actor and 2-critic ensemble: MLP 256 × 256, tanh + LayerNorm; grasp critic MLP 256 × 256 → 3", "p3", "c1", "c4"],
      output: ["6-D or 12-D end-effector twist (tanh-Gaussian) + discrete gripper {open, close, stay}", "p1", "p3"],
      attention: "None (conv + MLPs)",
      cond: ["Image embeddings concatenated with the 64-d proprio embedding", "p1", "c3"],
      steps: null, chunk: null,
      rate: ["10 Hz policy over an impedance controller", "p1", "p3"],
      latency: null,
      train: ["RLPD, 50/50 demo and RL buffers, 20–30 demos + SpaceMouse corrections; 1–2.5 h per task", "p1", "p2"]
    },
    changes: [
      "Adds <b>pixels</b>: a frozen, pretrained ResNet-10 per camera instead of a low-dimensional state.",
      "Critics use <b>LayerNorm and tanh</b> hidden layers (RLPD recipe) and a 2-network ensemble; the temperature α is learned.",
      "A separate <b>DQN grasp critic</b> handles the discrete gripper action.",
      "Training batches mix a <b>demo/intervention buffer</b> and an RL buffer 50/50; a human can take over with a SpaceMouse.",
      "The reward is a <b>learned binary success classifier</b> (ResNet-10 + 2-layer MLP), not a shaped function."
    ],
    blueprint: {
      headline: "HIL-SERL: frozen ResNet-10, small MLP heads",
      note: "Each camera crop goes through the same frozen ResNet-10; learned spatial embeddings and a 256-d bottleneck make one vector per camera. Those vectors plus a 64-d proprio embedding feed the actor, the critic ensemble and the grasp critic, each with its own MLP. The continuous twist comes from the actor, the gripper command from the grasp critic's argmax.",
      towers: [
        { mod: "enc", title: "Image encoder", sub: "one per camera, frozen trunk", compact: true,
          input: { label: "RGB crop 128 × 128", caption: "wrist and side cameras" },
          rows: [
            { t: "conv", label: "ResNet-10 trunk (frozen)", call: ["ImageNet init, 64 → 512 ch", "p1", "c2", "c4"], zoom: { k: "rows", title: "ResNet-10 (pre-pooling)", rows: ["Conv 7×7 /2 · GN(4) · ReLU", "max-pool 3×3 /2", "1 block per stage: 64 … 512", "stop-gradient: frozen trunk"] } },
            { t: "pool", label: "Spatial learned embeddings", call: ["8 features, dropout 0.1", "c2", "c4"] },
            { t: "linear", label: "Dense · LayerNorm · tanh", call: ["bottleneck 256", "c2", "c4"] } ],
          output: { label: "256-d per camera" } },
        { mod: "actor", title: "Actor π(a | s)", sub: "tanh-Gaussian motion policy",
          input: { label: "[image embeds ‖ proprio]", caption: "proprio: TCP pose, velocity, F/T" },
          rows: [
            { t: "linear", label: "Proprio Dense · LN · tanh", call: ["64-d proprio embedding", "p3", "c3"] },
            { t: "block", n: "2", rows: [{ t: "linear", label: "Dense · LayerNorm · tanh", call: ["256 units", "p3", "c1"] }] },
            { t: "linear", label: "Mean and σ heads · tanh", call: ["σ via exp, clipped to [10⁻⁵, 5]", "c1"] } ],
          output: { label: "EE twist, 10 Hz" } },
        { mod: "critic", title: "Critics", sub: "same encoders, own MLPs",
          input: { label: "[image embeds ‖ proprio]", caption: "+ action for the twist critic" },
          rows: [
            { id: "q", t: "group", label: "Twist critic, ensemble of 2", rows: [
              { t: "linear", label: "[features ‖ a] → 2 × 256", call: ["tanh + LayerNorm", "c1"], zoom: { k: "rows", title: "RLPD update", rows: ["batch: 50 % demos, 50 % RL", "Q target: r + γ Q̄(s′, a′), a′ ~ π", "actor: max Q + α·H, α learned", "γ 0.96–0.985 per task"] } } ] },
            { t: "group", label: "Grasp critic (DQN)", rows: [
              { t: "linear", label: "2 × 256 → 3 Q-values", call: ["open, close, stay (3² = 9 dual-arm)", "p1", "p3"] } ] } ],
          output: { label: "Q(s, a) · argmax gripper" } }
      ],
      links: [
        { from: "enc", to: "actor", toRow: "input", label: "camera embeds" },
        { from: "actor", to: "critic", toRow: "q", label: "a ~ π" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "ResNet-10 per camera", sub: "frozen · 8 spatial emb → 256", col: 0, frozen: "partial", short: "ResNet-10",
        note: "The ResNet trunk is frozen (stop-gradient); the spatial embeddings and the 256-d bottleneck are trained.",
        stack: { rows: [
          { t: "in", label: "RGB crop per camera", dims: "128 × 128", c: "data-1" },
          { t: "conv", label: "Conv 7×7 /2 · GroupNorm · ReLU · max-pool" },
          { t: "block", label: "Basic residual block per stage", n: "4", rows: [{ t: "conv", label: "3×3 convs · GroupNorm(4)", dims: "64 → 128 → 256 → 512" }] },
          { t: "pool", label: "SpatialLearnedEmbeddings", dims: "8 features · dropout 0.1" },
          { t: "linear", label: "Dense 256 · LayerNorm · tanh" },
          { t: "out", label: "camera embedding", dims: "256", c: "data-1" } ],
          facts: [["Trunk", ["ResNet-10, stages (1, 1, 1, 1), ImageNet", "p1", "c2"]], ["Frozen", ["yes, stop-gradient on the trunk", "c2"]], ["Norm", ["GroupNorm, 4 groups", "c2"]], ["Bottleneck", ["256, LayerNorm + tanh", "c2", "c4"]], ["Augmentation", ["random crop", "p3"]]] } },
      { id: "actor", role: "action-head", roleLabel: "Actor", name: "Motion policy π", sub: "MLP 256 × 256 · tanh", col: 1, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "camera embeddings ‖ proprio embedding", dims: "256 per camera + 64", c: "data-5" },
          { t: "linear", label: "Dense 256 · LayerNorm · tanh" }, { t: "linear", label: "Dense 256 · LayerNorm · tanh" },
          { t: "linear", label: "mean, std heads (exp, [10⁻⁵, 5])" },
          { t: "out", label: "tanh-Gaussian twist", dims: "6-D or 12-D", c: "data-3" } ],
          facts: [["MLP", ["256 × 256", "p3", "c1"]], ["Proprio encoder", ["64", "p3", "c3"]], ["Temperature init", ["10⁻²", "c1"]], ["Optimizer", ["Adam 3 × 10⁻⁴", "p3"]]] } },
      { id: "critic", role: "critic", name: "Critic ensemble + grasp critic", sub: "2 × MLP 256² · DQN 256² → 3", col: 2, frozen: false, short: "Q",
        stack: { rows: [
          { t: "in", label: "features ‖ action", dims: "twist critic", c: "data-3" },
          { t: "block", label: "Ensemble member", n: "2", rows: [{ t: "linear", label: "Dense 256 × 2 · LN · tanh → Q" }] },
          { t: "linear", label: "Grasp critic: Dense 256 × 2 → 3 Q-values", side: "cond" },
          { t: "out", label: "Q(s, a); gripper = argmax", dims: "discrete + continuous action", c: "data-8" } ],
          facts: [["Ensemble", ["2 critics", "c1"]], ["Grasp critic", ["256 × 256 → 3 (9 for two grippers)", "p1", "p3"]], ["Grasp loss", ["double-DQN with a target network", "p1"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "wrist + side crops", n: "128 × 128 each", k: 4 },
      { to: "actor", mod: "state", label: "TCP pose, vel, F/T", n: "→ 64-d", k: 2 }
    ],
    outputs: [{ from: "actor", mod: "action", label: "EE twist", n: "6 or 12", k: 3 }, { from: "critic", mod: "action", label: "gripper cmd", n: "3 or 9", k: 1 }],
    links: [
      { from: "enc", to: "actor", kind: "feeds", label: "256-d per camera" },
      { from: "actor", to: "critic", kind: "feeds", label: "a ~ π" }
    ],
    callouts: [
      "The reward classifier is its own network: pretrained ResNet-10 + a 2-layer MLP, trained on about 200 positive and 1,000 negative frames (App. B, §3.5).",
      "SERL (the predecessor stack) uses the same RLPD agent and ResNet-10 encoder; HIL-SERL adds human corrections and the grasp critic."
    ]
  });

  /* ───────────────────────── A3 · Residual RL ───────────────────────── */
  RB.arch.spec({
    id: "residual-rl", method: "residual-rl", name: "Residual RL", year: 2018,
    figRef: "Johannink et al. Fig. 1 · §III · Alg. 1", prov: "Paper only; sizes not stated",
    lede: "The command is the sum of a fixed hand-designed controller and a learned residual: u = πH(sₘ) + πθ(sₘ, sₒ). The controller handles the geometry; TD3 learns the correction for contacts and object motion.",
    sources: {
      p1: ax("Johannink et al. 2018, §III (residual RL) and Algorithm 1", "1812.03201"),
      p2: ax("Johannink et al. 2018, §IV (setups, rewards, controllers)", "1812.03201"),
      p3: ax("Johannink et al. 2018, §VI (results)", "1812.03201")
    },
    summary: {
      pattern: ["Residual policy on a fixed controller", "p1"],
      params: "not stated",
      vision: ["No pixels in the policy: block poses come from a camera tracking system (real) or the simulator", "p2"],
      backbone: "Neural network policy; layers and widths not stated",
      head: ["Residual action added to πH's command", "p1"],
      output: ["u = πH(sₘ) + πθ(sₘ, sₒ)", "p1"],
      attention: "None",
      cond: ["πθ sees the robot state sₘ and the object state sₒ; πH sees only sₘ", "p1"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["TD3 (rlkit), off-policy replay; ≈8,000 real samples (≈3 h) for the misaligned-block task", "p1", "p3"]
    },
    blueprint: {
      headline: "Residual RL: controller plus learned correction",
      note: "Two branches act in parallel every step. πH is a Cartesian position controller in simulation and a compliant joint-impedance controller on the real Sawyer. The replay buffer stores only the residual action uₜ, so TD3 learns what to add to πH.",
      towers: [
        { mod: "ctrl", title: "Hand-designed πH", sub: "fixed, not learned", compact: true,
          input: { label: "Robot state sₘ", caption: "end-effector pose" },
          rows: [
            { t: "mlp", label: "Cartesian position ctrl (sim)" },
            { t: "mlp", label: "Joint impedance ctrl (real)" } ],
          output: { label: "πH(sₘ)" } },
        { mod: "res", title: "Residual policy πθ", sub: "TD3, sizes not stated",
          input: { label: "sₘ ‖ sₒ", caption: "EE pose, forces, block poses, goal" },
          rows: [
            { t: "mlp", label: "Actor MLP (width not stated)", zoom: { k: "rows", title: "Algorithm 1", rows: ["uₜ = πθ(sₜ) + 𝒩ₜ", "execute uₜ′ = uₜ + πH(sₜ)", "store (sₜ, uₜ, sₜ₊₁) in replay", "TD3 update of θ"] } },
            { id: "sum", t: "linear", label: "⊕ add πH(sₘ)", side: "cond" },
            { t: "linear", label: "u = πH(sₘ) + πθ(sₘ, sₒ)", call: ["Misaligned blocks: 15/20 vs 2/20 for πH alone", "p3"] } ],
          output: { label: "commanded control u" } }
      ],
      links: [{ from: "ctrl", to: "res", toRow: "sum", label: "πH(sₘ)" }]
    },
    modules: [
      { id: "ctrl", role: "planner", roleLabel: "Hand-designed controller", name: "Controller πH", sub: "position / impedance", col: 0, frozen: true, short: "πH",
        note: "Not a network: a conventional feedback controller that solves the robot-state part of the reward." },
      { id: "res", role: "action-head", roleLabel: "Residual policy", name: "Residual πθ", sub: "TD3 actor", col: 1, frozen: false, main: true, short: "πθ",
        stack: { rows: [
          { t: "in", label: "robot state sₘ ‖ object state sₒ", dims: "sim: EE pose, F/T, blocks, goal", c: "data-5" },
          { t: "mlp", label: "Actor network (sizes not stated)" },
          { t: "add", label: "+ πH(sₘ)", span: 1 },
          { t: "out", label: "control u", dims: "sent to the robot", c: "data-3" } ],
          facts: [["RL algorithm", ["TD3 (rlkit)", "p1"]], ["Real training", ["≈8,000 samples, ≈3 h", "p3"]], ["Sim reward", ["−‖x_g − x_t‖² − λ(‖θₗ‖₁ + ‖θᵣ‖₁)", "p2"]]] } }
    ],
    inputs: [
      { to: "ctrl", mod: "state", label: "robot state sₘ", n: "EE pose", k: 2 },
      { to: "res", mod: "state", label: "sₘ ‖ sₒ", n: "robot + blocks", k: 3 }
    ],
    outputs: [{ from: "res", mod: "action", label: "u = πH + πθ", n: "Cartesian / joint", k: 3 }],
    links: [{ from: "ctrl", to: "res", kind: "feeds", label: "added to|πθ's output" }],
    callouts: [
      "The same superposition returns in sim-to-real: ASAP's delta-action model adds a learned correction to the actions inside the simulator instead of on the robot."
    ]
  });

  /* ───────────────────────── A3 · DayDreamer ───────────────────────── */
  RB.arch.spec({
    id: "daydreamer", method: "daydreamer", name: "DayDreamer", year: 2022, parent: "dreamer",
    diffRows: ["vision", "backbone", "head", "cond", "steps", "rate", "train"],
    figRef: "Wu et al. Figs. 2–3 · §2 · App. D", prov: "dreamerv2plus agent config",
    lede: "DreamerV2 on four real robots, online and without a simulator. An encoder fuses camera and proprioception into 32 × 32 discrete latents, an RSSM learns the dynamics, and an actor-critic learns from 15-step imagined rollouts while a separate thread drives the robot.",
    sources: {
      p1: ax("Wu et al. 2022, §2 (world model, actor-critic, threads)", "2206.14176"),
      p2: ax("Wu et al. 2022, App. D (hyperparameters)", "2206.14176"),
      p3: ax("Wu et al. 2022, §3 (robots, rates, action spaces)", "2206.14176"),
      c1: gh("danijar/daydreamer", "709016c", "embodied/agents/dreamerv2plus/configs.yaml"),
      c2: gh("danijar/daydreamer", "709016c", "embodied/agents/dreamerv2plus/nets.py")
    },
    summary: {
      pattern: ["RSSM world model", "p1"],
      params: null,
      vision: ["CNN: 4 convs, kernel 4, stride 2, depth 64 → 512 (images and depth); MLP 4 × 512 for vectors", "c1", "c2"],
      backbone: ["RSSM: GRU deterministic state + 32 latents × 32 classes; LayerNorm + ELU", "p2", "c1"],
      head: ["Decoder, reward and continue heads; actor and critic MLPs 4 × 512", "p2", "c1"],
      output: ["Actor: Gaussian (A1, Sphero) or one-hot (UR5, XArm) actions", "p3", "c1"],
      attention: "None (recurrent)",
      cond: ["Action aₜ₋₁ enters the GRU; the posterior adds the encoded observation", "p1"],
      steps: ["Imagination horizon H = 15; λ-returns, λ 0.95", "p2"],
      chunk: null,
      rate: ["A1 20 Hz · UR5 2 Hz · Sphero 2 Hz · XArm ≈0.5 Hz", "p3"],
      latency: null,
      train: ["Batch 32 × 32 steps, replay 10⁶ (FIFO), Adam 10⁻⁴; same settings on all robots", "p2"]
    },
    changes: [
      "Latents become <b>discrete</b>: 32 categorical variables with 32 classes (DreamerV2) instead of a 30-D Gaussian.",
      "The encoder <b>fuses several sensors</b> (RGB, depth, joint and Cartesian readings) through a CNN plus an MLP.",
      "Actor and critic are <b>4 × 512 LayerNorm + ELU</b> MLPs; discrete actions use Reinforce, continuous ones back-propagate.",
      "Learning is <b>asynchronous</b>: a learner thread trains while an actor thread steps the robot, so no train-every ratio.",
      "Everything runs <b>online on hardware</b> (A1, UR5, XArm, Sphero) with one hyperparameter set."
    ],
    blueprint: {
      headline: "DayDreamer: DreamerV2 on the real robot",
      note: "The encoder turns each observation into features; the RSSM's posterior samples discrete latents zₜ and its GRU carries hₜ. The world model trains on replayed sequences; the actor and critic see only imagined (hₜ, zₜ) rollouts of 15 steps and never decode pixels.",
      towers: [
        { mod: "enc", title: "Multi-sensor encoder", sub: "CNN for images, MLP for vectors", compact: true,
          input: { label: "xₜ: RGB/depth + proprio", caption: "64 × 64 images; joints, EE pose" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "conv", label: "Conv 4×4 /2 · LN · ELU", call: ["depth 64 → 128 → 256 → 512", "c1", "c2"] }] },
            { t: "block", n: "4", rows: [{ t: "linear", label: "Dense 512 · LN · ELU", call: ["vector inputs", "c1"] }] },
            { t: "linear", label: "Concat CNN and MLP features" } ],
          output: { label: "embedding eₜ" } },
        { mod: "rssm", title: "RSSM world model", sub: "trained on replayed sequences",
          input: { label: "hₜ₋₁, zₜ₋₁, aₜ₋₁", caption: "previous latent state and action" },
          rows: [
            { t: "linear", label: "Dense on [zₜ₋₁ ‖ aₜ₋₁]", call: ["GRU state 1,024 (code); paper: 512", "p2", "c1"] },
            { id: "gru", t: "attn", label: "GRU state hₜ", zoom: { k: "rows", title: "RSSM step", rows: ["hₜ = GRU(hₜ₋₁, [zₜ₋₁ ‖ aₜ₋₁])", "prior ẑₜ ~ p(ẑₜ | hₜ)  (3 layers)", "posterior zₜ ~ q(zₜ | hₜ, eₜ)  (1 layer)", "KL balancing 0.8"] } },
            { id: "post", t: "linear", label: "Posterior / prior: 32 × 32", side: "cond", call: ["32 latents × 32 classes", "p2", "c1"], zoom: { k: "rows", title: "Discrete latent", rows: ["logits 32 × 32", "sample one class per latent", "flatten to a 1,024-d one-hot", "prior learns to predict it (KL)"] } },
            { t: "mlp", label: "Decoder · reward · continue", call: ["4 × 512 MLPs (+ transposed CNN)", "p2", "c1"] } ],
          output: { label: "sₜ = (hₜ, zₜ), r̂ₜ" } },
        { mod: "ac", title: "Actor-critic", sub: "on imagined latents only", compact: true,
          input: { label: "sₜ = [hₜ ‖ zₜ]", caption: "imagined, 15 steps" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "linear", label: "Dense 512 · LN · ELU", call: ["actor and critic, separate", "p2", "c1"] }] },
            { t: "linear", label: "π(a|s) and v(s) heads", zoom: { k: "rows", title: "Behaviour learning", rows: ["imagine 15 steps from replay", "Vλ = r + γ((1 − λ)v + λVλ)", "critic regresses Vλ (slow target)", "actor: maximise Vλ + η·entropy"] } } ],
          output: { label: "action to the robot" } }
      ],
      links: [
        { from: "enc", to: "rssm", toRow: "post", label: "eₜ" },
        { from: "rssm", to: "ac", toRow: "input", label: "latent state" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "Multi-sensor encoder", sub: "CNN 64 → 512 + MLP 4 × 512", col: 0, frozen: false, short: "Encoder",
        stack: { rows: [
          { t: "in", label: "RGB (and depth) 64 × 64 · proprio vector", dims: "per robot", c: "data-1" },
          { t: "conv", label: "4 × Conv 4×4 stride 2 · LayerNorm · ELU", dims: "64 → 128 → 256 → 512" },
          { t: "linear", label: "4 × Dense 512 · LayerNorm · ELU (vectors)" },
          { t: "out", label: "concatenated embedding eₜ", dims: "to the posterior", c: "data-1" } ],
          facts: [["CNN depth", ["64, doubling per layer", "c1", "c2"]], ["Kernels", ["4, 4, 4, 4, stride 2", "c1", "c2"]], ["MLP", ["4 × 512", "p2", "c1"]], ["Image size", ["64 × 64", "c1"]]] } },
      { id: "rssm", role: "world", name: "RSSM", sub: "GRU + 32 × 32 discrete", col: 1, frozen: false, main: true, short: "RSSM",
        stack: { rows: [
          { t: "in", label: "hₜ₋₁, zₜ₋₁, aₜ₋₁ (+ eₜ)", dims: "one step", c: "data-7" },
          { t: "linear", label: "Dense 1,024 · LayerNorm · ELU" },
          { t: "attn", label: "GRU → hₜ", dims: "deter 1,024 (code)" },
          { t: "mlp", label: "Prior MLP (3 layers) / posterior MLP (1 layer)" },
          { t: "linear", label: "32 × 32 categorical logits → zₜ" },
          { t: "mlp", label: "Decoder, reward (symlog) and continue heads" },
          { t: "out", label: "latent state sₜ = (hₜ, zₜ)", dims: "reconstructions, r̂", c: "data-7" } ],
          facts: [["Latents", ["32 × 32 classes", "p2", "c1"]], ["Deterministic size", ["1,024 (code) · 512 (paper App. D)", "p2", "c1"]], ["KL balance", ["0.8", "p2", "c1"]], ["Heads", ["4 × 512, LayerNorm + ELU", "p2", "c1"]], ["Batch", ["32 sequences × 32 steps", "p2"]]] } },
      { id: "ac", role: "action-head", roleLabel: "Actor-critic", name: "Actor and critic", sub: "4 × 512 MLPs each", col: 2, frozen: false, short: "π, v",
        stack: { rows: [
          { t: "in", label: "imagined states [hₜ ‖ zₜ]", dims: "H = 15", c: "data-7" },
          { t: "linear", label: "Actor: 4 × Dense 512 · LN · ELU → π(a|s)" },
          { t: "linear", label: "Critic: 4 × Dense 512 · LN · ELU → v(s)" },
          { t: "out", label: "action (one-hot or Gaussian)", dims: "and value", c: "data-3" } ],
          facts: [["Horizon", ["15", "p2"]], ["λ", ["0.95", "p2"]], ["Target critic", ["updated every 100 steps", "p2"]], ["Gradients", ["Reinforce (discrete) / backprop (continuous)", "p1", "c1"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "camera (RGB, depth)", n: "64 × 64", k: 3 },
      { to: "enc", mod: "state", label: "joints, EE pose, gripper", n: "vector", k: 2 },
      { to: "rssm", mod: "action", label: "previous action", n: "aₜ₋₁", k: 1 }
    ],
    outputs: [{ from: "ac", mod: "action", label: "robot action", n: "2–20 Hz", k: 3 }],
    links: [
      { from: "enc", to: "rssm", kind: "latent", label: "eₜ → posterior" },
      { from: "rssm", to: "ac", kind: "latent", label: "imagined sₜ" }
    ],
    callouts: [
      "<b>Paper vs code:</b> App. D lists RSSM size 512, discount γ = 0.95 and horizon 15; the released config uses deter 1,024, γ = 0.998 by default (0.995 for the UR5, XArm and Sphero configs), and §2 mentions H = 16.",
      "The A1 learns to roll over, stand up and walk in about 1 hour, with no simulator and no resets (§3.1)."
    ]
  });

  /* ───────────────────────── A4 · RMA ───────────────────────── */
  RB.arch.spec({
    id: "rma", method: "rma", name: "RMA", year: 2021, parent: "teacher-student-terrain",
    diffRows: ["backbone", "head", "output", "cond", "rate", "train"],
    figRef: "Kumar et al. Fig. 2 · §III · §IV-B", prov: "Paper only; no official code",
    lede: "A base policy takes the state, the previous action and an 8-D extrinsics vector. In simulation μ encodes 17 privileged environment factors into it; on the robot a 1-D CNN over 0.5 s of state-action history estimates it at 10 Hz.",
    sources: {
      p1: ax("Kumar et al. 2021, §III-A–C (base policy, adaptation module)", "2107.04034"),
      p2: ax("Kumar et al. 2021, §IV-A (A1, state-action space, factors)", "2107.04034"),
      p3: ax("Kumar et al. 2021, §IV-B (architectures, training)", "2107.04034")
    },
    summary: {
      pattern: ["Teacher–student policy", "p1"],
      params: null,
      vision: "None: blind, proprioception only",
      backbone: ["Base policy π: 3-layer MLP, hidden 128", "p3"],
      head: ["12 target joint angles, PD with Kp 55, Kd 0.8", "p2", "p3"],
      output: ["aₜ ∈ ℝ¹² desired joint positions at 100 Hz", "p1", "p2"],
      attention: "None (MLP and temporal CNN)",
      cond: ["Extrinsics zₜ ∈ ℝ⁸: μ(eₜ) in phase 1, φ(50-step history) in phase 2 and on the robot", "p1", "p3"],
      steps: null, chunk: null,
      rate: ["π at 100 Hz, φ at 10 Hz, asynchronous on the A1", "p1"],
      latency: null,
      train: ["PPO 15,000 iterations × 80,000 steps (1.2B steps, ~24 h); φ: 1,000 iterations supervised", "p3"]
    },
    changes: [
      "The student no longer copies the teacher's layers: it only has to <b>predict the teacher's latent</b> zₜ, and the base policy is reused as is.",
      "The latent is tiny (<b>8-D</b>) and encodes 17 environment factors (mass, CoM, motor strength, friction, terrain height).",
      "Actions are <b>joint targets directly</b>; no foot trajectory generator or actuator network.",
      "The adaptation module runs <b>asynchronously at 10 Hz</b> while the policy runs at 100 Hz.",
      "No reference gait or curriculum on terrain: bioenergetic rewards on a fractal terrain."
    ],
    blueprint: {
      headline: "RMA: estimate the extrinsics, reuse the policy",
      note: "Phase 1 trains π and μ jointly with PPO, feeding zₜ = μ(eₜ). Phase 2 freezes both and regresses φ's estimate ẑₜ onto zₜ with on-policy rollouts of π driven by ẑₜ. On the robot only φ and π run.",
      towers: [
        { mod: "adapt", title: "Adaptation module φ", sub: "10 Hz, deployed", compact: true,
          input: { label: "History x, a (50 steps)", caption: "0.5 s of states and actions" },
          rows: [
            { t: "mlp", label: "2-layer MLP per step", call: ["→ 32-d embedding", "p3"] },
            { t: "conv", label: "Conv1d k8 s4", call: ["32 → 32 channels", "p3"] },
            { t: "conv", label: "2 × Conv1d k5 s1", call: ["32 → 32 channels each", "p3"], zoom: { k: "rows", title: "Temporal CNN", rows: ["50 × 42 (xₜ ‖ aₜ₋₁) per step", "MLP → 50 × 32", "3 convs: k8 s4, k5 s1, k5 s1", "flatten → linear → ẑₜ ∈ ℝ⁸"] } },
            { t: "linear", label: "Flatten → Linear", call: ["ẑₜ ∈ ℝ⁸", "p3"] } ],
          output: { label: "ẑₜ (deploy)" } },
        { mod: "policy", title: "Base policy π", sub: "100 Hz on the A1",
          input: { label: "xₜ ‖ aₜ₋₁ ‖ zₜ", caption: "30 + 12 + 8 dims" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense layer", call: ["hidden 128", "p3"] }] },
            { t: "linear", label: "Output: 12 joint targets", call: ["PD: Kp 55, Kd 0.8", "p2"], zoom: { k: "rows", title: "State xₜ (30-D)", rows: ["12 joint positions", "12 joint velocities", "roll and pitch", "4 binary foot contacts"] } } ],
          output: { label: "aₜ ∈ ℝ¹²" } },
        { mod: "enc", title: "Env factor encoder μ", sub: "simulation only", compact: true,
          input: { label: "Privileged eₜ ∈ ℝ¹⁷", caption: "mass, CoM, friction, motors, terrain" },
          rows: [
            { t: "linear", label: "3-layer MLP", call: ["hidden 256, 128", "p3"], zoom: { k: "rows", title: "eₜ (17-D)", rows: ["mass and its position: 3", "motor strength: 12", "friction: 1", "local terrain height: 1"] } },
            { t: "linear", label: "→ zₜ", call: ["zₜ ∈ ℝ⁸", "p1"] } ],
          output: { label: "zₜ (train)" } }
      ],
      links: [
        { from: "adapt", to: "policy", toRow: "input", label: "ẑₜ (deploy)" },
        { from: "enc", to: "policy", toRow: "input", label: "zₜ (train)" }
      ]
    },
    modules: [
      { id: "adapt", role: "state-enc", roleLabel: "Adaptation module", name: "φ: 1-D CNN", sub: "50 steps → 8-D", col: 0, frozen: false, short: "φ",
        stack: { rows: [
          { t: "in", label: "states and actions, last 50 steps", dims: "k = 50 (0.5 s)", c: "data-5" },
          { t: "mlp", label: "2-layer MLP → 32 per step" },
          { t: "conv", label: "Conv1d 32 → 32, k8 s4" }, { t: "conv", label: "Conv1d 32 → 32, k5 s1" }, { t: "conv", label: "Conv1d 32 → 32, k5 s1" },
          { t: "linear", label: "Flatten → Linear → 8" },
          { t: "out", label: "ẑₜ", dims: "10 Hz", c: "data-7" } ],
          facts: [["History", ["50 steps = 0.5 s", "p1"]], ["Conv layers", ["[32, 32, 8, 4], [32, 32, 5, 1], [32, 32, 5, 1]", "p3"]], ["Loss", ["MSE(ẑₜ, zₜ), on-policy data", "p1"]], ["Training", ["1,000 iterations, 80M steps, ~3 h", "p3"]]] } },
      { id: "policy", role: "action-head", roleLabel: "Base policy", name: "Base policy π", sub: "3-layer MLP · 128", col: 1, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "xₜ ∈ ℝ³⁰ ‖ aₜ₋₁ ∈ ℝ¹² ‖ zₜ ∈ ℝ⁸", dims: "50 inputs", c: "data-5" },
          { t: "linear", label: "3-layer MLP, hidden 128" },
          { t: "out", label: "12 desired joint angles", dims: "PD Kp 55, Kd 0.8", c: "data-3" } ],
          facts: [["Hidden", ["128", "p3"]], ["PPO", ["15,000 iterations, batch 80,000, lr 5e−4", "p3"]], ["Sim", ["RaiSim, fractal terrain", "p2"]], ["Rate", ["100 Hz", "p1"]]] } },
      { id: "enc", role: "state-enc", roleLabel: "Privileged encoder", name: "μ: factor encoder", sub: "17 → 256 → 128 → 8", col: 2, frozen: false, short: "μ",
        stack: { rows: [
          { t: "in", label: "environment factors eₜ", dims: "17-D", c: "data-8" },
          { t: "linear", label: "3-layer MLP (256, 128 hidden)" },
          { t: "out", label: "extrinsics zₜ", dims: "8-D", c: "data-7" } ],
          facts: [["Input", ["17-D", "p2"]], ["Hidden", ["256, 128", "p3"]], ["Output", ["8-D", "p1"]]] } }
    ],
    inputs: [
      { to: "adapt", mod: "state", label: "state-action history", n: "50 steps", k: 4 },
      { to: "policy", mod: "state", label: "xₜ, aₜ₋₁", n: "30 + 12", k: 3 },
      { to: "enc", mod: "other", label: "env factors eₜ", n: "17", k: 2 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint targets", n: "12", k: 3 }],
    links: [
      { from: "adapt", to: "policy", kind: "latent", label: "ẑₜ (8-D)|deploy, 10 Hz" },
      { from: "enc", to: "policy", kind: "latent", label: "zₜ (8-D)|phase 1" }
    ],
    callouts: [
      "RMA does not distil actions: φ regresses a latent. The ROA variant in Deep Whole-Body Control trains μ and φ together instead of in two phases."
    ]
  });

  /* ───────────────────────── A4 · Teacher–student terrain ───────────────────────── */
  RB.arch.spec({
    id: "teacher-student-terrain", method: "teacher-student-terrain", name: "Teacher–student terrain (Lee 2020)", year: 2020,
    figRef: "Lee et al. Fig. 4 · §4 · Tables S4, S5", prov: "Released c100 policy and env",
    lede: "A privileged MLP teacher, trained with TRPO, sees terrain heights, contacts and friction; a blind student TCN over a long proprioceptive history learns its latent and actions. The last MLP layers are copied from teacher to student; outputs modulate four foot-trajectory generators.",
    sources: {
      p1: ax("Lee et al. 2020, §4 (overview, teacher, student)", "2010.11251"),
      p2: ax("Lee et al. 2020, Table S5 (network architectures)", "2010.11251"),
      p3: ax("Lee et al. 2020, Table S4 (state and privileged information)", "2010.11251"),
      p4: ax("Lee et al. 2020, §4 Motion synthesis and Fig. 4C (PMTG, IK, rates)", "2010.11251"),
      c1: gh("leggedrobotics/learning_quadrupedal_locomotion_over_challenging_terrain_supplementary", "277d19b", "include/environment/environment_c100.hpp"),
      c2: gh("leggedrobotics/learning_quadrupedal_locomotion_over_challenging_terrain_supplementary", "277d19b", "applications/test_c100.cpp")
    },
    summary: {
      pattern: ["Teacher–student policy", "p1"],
      params: null,
      vision: "None: proprioception only (the teacher also gets terrain heights)",
      backbone: ["Student: TCN of 6 causal convs (filter 5, dilations 1, 2, 4 with stride-2 layers) → tanh 64", "p2"],
      head: ["Shared head tanh 256 → 128 → 64 → output, copied from the teacher", "p2"],
      output: ["16-D: 4 leg frequency offsets + 12 foot-position residuals → IK → joint PD", "p1", "p4", "c1"],
      attention: "None (causal dilated convolutions)",
      cond: ["Teacher: privileged xₜ → tanh 72 → tanh 64 latent l̄ₜ, concatenated with oₜ", "p2", "p3"],
      steps: null, chunk: null,
      rate: ["Proprioceptive history sampled every 0.02 s", "p1"],
      latency: null,
      train: ["Teacher: TRPO with an adaptive terrain curriculum; student: imitate l̄ₜ and āₜ", "p1"]
    },
    blueprint: {
      headline: "Lee 2020: privileged teacher, TCN student",
      note: "The teacher embeds privileged terrain and contact information into l̄ₜ and acts through an MLP. The student's TCN turns 60-D proprioceptive history into a 64-d vector that replaces l̄ₜ; the layers marked * in Table S5 are copied from the teacher, so the student mainly learns the encoder.",
      towers: [
        { mod: "tcn", title: "Student TCN encoder", sub: "deployed, blind", compact: true,
          input: { label: "History h: 60 × N", caption: "proprio every 0.02 s" },
          rows: [
            { t: "conv", label: "Conv dil 1 · conv stride 2", call: ["filter 5, ReLU", "p2"] },
            { t: "conv", label: "Conv dil 2 · conv stride 2", call: ["dilated causal convs", "p2"] },
            { t: "conv", label: "Conv dil 4 · conv stride 2", zoom: { k: "rows", title: "TCN (Table S5)", rows: ["input 60 × N (N = 100, c100)", "conv dil 1 → conv stride 2", "conv dil 2 → conv stride 2", "conv dil 4 → stride 2 → tanh 64"] } },
            { t: "linear", label: "tanh 64", call: ["replaces the teacher's l̄ₜ", "p1", "p2"] } ],
          output: { label: "student latent lₜ" } },
        { mod: "head", title: "Policy MLP (shared)", sub: "layers copied teacher → student",
          input: { label: "oₜ ‖ latent", caption: "command, IMU, joints, FTG phases" },
          rows: [
            { t: "linear", label: "tanh 256 *", call: ["* = copied from the teacher", "p2"] },
            { t: "linear", label: "tanh 128 *" },
            { t: "linear", label: "tanh 64 *" },
            { t: "linear", label: "Output * (16-D)", call: ["4 leg frequencies + 12 foot residuals", "p1", "c1"], zoom: { k: "rows", title: "PMTG control", rows: ["φᵢ = φᵢ,₀ + (f₀ + fᵢ)t, f₀ 1.25 Hz", "foot target F(φᵢ) + Δr (policy)", "analytic IK → joint targets", "joint PD (actuator net in sim)"] } } ],
          output: { label: "fᵢ, Δr_f → IK → PD" } },
        { mod: "priv", title: "Teacher encoder", sub: "simulation only", compact: true,
          input: { label: "Privileged xₜ", caption: "heights, contacts, friction, forces" },
          rows: [
            { t: "linear", label: "tanh 72", call: ["72 then 64 units", "p2"], zoom: { k: "rows", title: "Privileged xₜ (Table S4)", rows: ["height scan: 9 × 4 feet = 36", "terrain normals 12, friction 4", "foot / thigh / shank contacts", "contact forces 4, external force 3"] } },
            { t: "linear", label: "tanh 64 → l̄ₜ" } ],
          output: { label: "l̄ₜ (teacher)" } }
      ],
      links: [
        { from: "tcn", to: "head", toRow: "input", label: "lₜ (student)" },
        { from: "priv", to: "head", toRow: "input", label: "l̄ₜ (teacher)" }
      ]
    },
    modules: [
      { id: "tcn", role: "state-enc", roleLabel: "Student encoder", name: "TCN over history", sub: "60 × N → 64", col: 0, frozen: false, short: "TCN",
        stack: { rows: [
          { t: "in", label: "proprioceptive history", dims: "60-D × N steps", c: "data-5" },
          { t: "conv", label: "1D conv, dilation 1" }, { t: "conv", label: "1D conv, stride 2" },
          { t: "conv", label: "1D conv, dilation 2" }, { t: "conv", label: "1D conv, stride 2" },
          { t: "conv", label: "1D conv, dilation 4" }, { t: "conv", label: "1D conv, stride 2" },
          { t: "linear", label: "tanh 64" },
          { t: "out", label: "latent lₜ", dims: "imitates l̄ₜ", c: "data-7" } ],
          facts: [["Filter size", ["5, ReLU after each conv", "p2"]], ["History entry", ["60-D", "p2", "c1"]], ["History length", ["100 steps in the released c100 test", "c2"]], ["Sampling", ["every 0.02 s", "p4"]]] } },
      { id: "head", role: "action-head", roleLabel: "Policy head", name: "Shared MLP head", sub: "256 → 128 → 64 → 16", col: 1, frozen: false, main: true, short: "MLP",
        note: "Copied from the teacher after teacher training (Table S5, layers marked *).",
        stack: { rows: [
          { t: "in", label: "oₜ ‖ latent", dims: "oₜ from Table S4", c: "data-5" },
          { t: "linear", label: "tanh 256" }, { t: "linear", label: "tanh 128" }, { t: "linear", label: "tanh 64" },
          { t: "linear", label: "Output 16" },
          { t: "out", label: "leg frequencies + foot residuals", dims: "→ FTG + IK + PD", c: "data-3" } ],
          facts: [["Hidden", ["tanh 256, 128, 64", "p2"]], ["Action", ["16-D", "p1", "c1"]], ["Base frequency", ["f₀ = 1.25 Hz", "p4"]], ["Actuator model", ["learned SEA net (MLP 32, 32) in sim", "p4", "c1"]]] } },
      { id: "priv", role: "state-enc", roleLabel: "Privileged encoder", name: "Teacher encoder", sub: "tanh 72 → 64", col: 2, frozen: false, short: "Teacher",
        stack: { rows: [
          { t: "in", label: "privileged xₜ", dims: "terrain + contacts + forces", c: "data-8" },
          { t: "linear", label: "tanh 72" }, { t: "linear", label: "tanh 64" },
          { t: "out", label: "l̄ₜ", dims: "teacher latent", c: "data-7" } ],
          facts: [["Layers", ["tanh 72, tanh 64", "p2"]], ["Height scan", ["9 points per foot, 10 cm circle", "p1", "p3"]], ["RL", ["TRPO", "p1"]]] } }
    ],
    inputs: [
      { to: "tcn", mod: "state", label: "proprio history", n: "60 × N", k: 4 },
      { to: "head", mod: "state", label: "oₜ: command + robot state", n: "per step", k: 3 },
      { to: "priv", mod: "other", label: "privileged xₜ", n: "terrain, contacts", k: 2 }
    ],
    outputs: [{ from: "head", mod: "action", label: "fᵢ + Δr (16-D)", n: "→ IK → 12 joints", k: 3 }],
    links: [
      { from: "tcn", to: "head", kind: "latent", label: "lₜ (student)" },
      { from: "priv", to: "head", kind: "latent", label: "l̄ₜ (teacher)" }
    ],
    callouts: [
      "<b>Paper vs code:</b> the oₜ entries of Table S4 sum to 121 dimensions; the released c100 environment declares StateDim = 133 (with a 60-D history entry and a 16-D action, as in the paper).",
      "The student is trained on both the teacher's action āₜ and its latent l̄ₜ; Table S5 lists a GRU student as an alternative to the TCN."
    ]
  });

  /* ───────────────────────── A4 · Asymmetric actor-critic ───────────────────────── */
  RB.arch.spec({
    id: "asymmetric-actor-critic", method: "asymmetric-actor-critic", name: "Asymmetric actor-critic", year: 2017, parent: "ddpg",
    diffRows: ["vision", "backbone", "cond", "train"],
    figRef: "Pinto et al. Fig. 2 · §IV · §V-H", prov: "Paper only; no official code",
    lede: "DDPG + HER where the two networks see different things: the actor, a CNN, gets rendered RGB(D) images of the scene and the goal; the critic, an MLP, gets the full simulator state and goal. Only the actor goes to the real robot.",
    sources: {
      p1: ax("Pinto et al. 2017, §IV-A–C (method, bottleneck, randomization)", "1710.06542"),
      p2: ax("Pinto et al. 2017, §V-H (implementation details)", "1710.06542"),
      p3: ax("Pinto et al. 2017, §V-A (environments)", "1710.06542")
    },
    summary: {
      pattern: ["Actor–critic (asymmetric inputs)", "p1"],
      params: null,
      vision: ["Actor CNN: 4 conv layers, 64 filters, 2 × 2 kernels, on 100 × 100 RGB or RGBD", "p2", "p3"],
      backbone: ["Actor: [CNN(oₜ) ‖ CNN(g_o)] → 3 FC × 512 ReLU", "p2"],
      head: ["Actor: tanh, rescaled to the action range; critic: 3 FC × 512 ReLU → Q", "p2"],
      output: ["4-D action for Fetch (relative gripper xyz + finger distance)", "p3"],
      attention: "None",
      cond: ["Critic input: [state sₜ ‖ goal state g ‖ action aₜ]", "p2"],
      steps: null, chunk: ["Fixed horizon T = 50", "p2"],
      rate: null, latency: null,
      train: ["DDPG + HER; 16 rollouts, 40 steps of batch 128, buffer 10⁵, Polyak 0.98, Adam 10⁻³, γ 0.98", "p2"]
    },
    changes: [
      "The actor becomes a <b>CNN on rendered images</b> of the current scene and of the goal.",
      "The critic stays an MLP but reads the <b>full simulator state</b> plus the goal state: asymmetric inputs.",
      "<b>Hindsight Experience Replay</b> relabels goals, so a sparse 0/1 reward works.",
      "An optional <b>bottleneck</b> layer in the actor regresses the full state as an auxiliary loss.",
      "Visual <b>domain randomization</b> (textures, lights, camera, depth noise) enables zero-shot transfer."
    ],
    blueprint: {
      headline: "Asymmetric AC: pixels for the actor, state for the critic",
      note: "The same 4-layer CNN is applied to the current observation and to the goal image; their features are concatenated and passed through three 512-unit layers to a tanh action. The critic never sees pixels, so it learns Q quickly and gives the actor better gradients; it is discarded after training.",
      towers: [
        { mod: "actor", title: "Actor (image policy)", sub: "deployed on the Fetch",
          input: { label: "oₜ and goal image g_o", caption: "100 × 100 × 3 (×4 with depth)" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "conv", label: "Conv 2×2 · ReLU", call: ["64 filters", "p2"] }] },
            { t: "linear", label: "Concat CNN(oₜ) ‖ CNN(g_o)" },
            { t: "block", n: "3", rows: [{ t: "linear", label: "FC · ReLU", call: ["512 units", "p2"] }] },
            { t: "linear", label: "tanh → action range", call: ["pre-activation penalty against saturation", "p2"], zoom: { k: "rows", title: "Optional bottleneck", rows: ["an intermediate actor layer", "is regressed to the full state", "extra L2 loss", "speeds up training (Fig. 6)"] } } ],
          output: { label: "aₜ (4-D on Fetch)" } },
        { mod: "critic", title: "Critic (full state)", sub: "simulation only", compact: true,
          input: { label: "[sₜ ‖ g ‖ aₜ]", caption: "full state, goal state, action" },
          rows: [
            { id: "a", t: "block", n: "3", rows: [{ t: "linear", label: "FC · ReLU", call: ["512 units", "p2"] }] },
            { t: "linear", label: "Linear → Q", zoom: { k: "rows", title: "HER + DDPG step", rows: ["16 rollouts, then 40 updates", "relabel goals with achieved states", "critic on (s, a, r, s′, g)", "actor on (o, g_o) via ∇ₐQ"] } } ],
          output: { label: "Q(s, a, g)" } }
      ],
      links: [{ from: "actor", to: "critic", toRow: "input", label: "aₜ" }]
    },
    modules: [
      { id: "actor", role: "action-head", roleLabel: "Image actor", name: "CNN actor", sub: "4 conv 64 · 3 × FC 512", col: 0, frozen: false, main: true, short: "Actor",
        stack: { rows: [
          { t: "in", label: "observation and goal images", dims: "100 × 100 × 3 or × 4", c: "data-1" },
          { t: "block", label: "Conv applied to each image", n: "4", rows: [{ t: "conv", label: "Conv 64 filters, 2 × 2 · ReLU" }] },
          { t: "linear", label: "Concatenate the two feature vectors" },
          { t: "block", label: "Fully connected", n: "3", rows: [{ t: "linear", label: "FC 512 · ReLU" }] },
          { t: "linear", label: "tanh, rescaled to the action limits" },
          { t: "out", label: "action aₜ", dims: "4-D (Fetch)", c: "data-3" } ],
          facts: [["Conv", ["4 layers, 64 filters, 2 × 2", "p2"]], ["FC", ["3 × 512 ReLU", "p2"]], ["Exploration", ["20 % uniform random, else + 5 % Gaussian noise", "p2"]], ["Inputs normalised", ["running mean and std", "p2"]]] } },
      { id: "critic", role: "critic", roleLabel: "State critic", name: "MLP critic", sub: "3 × FC 512 on [s‖g‖a]", col: 1, frozen: false, short: "Critic",
        stack: { rows: [
          { t: "in", label: "full state ‖ goal state ‖ action", dims: "simulator only", c: "data-5" },
          { t: "block", label: "Fully connected", n: "3", rows: [{ t: "linear", label: "FC 512 · ReLU" }] },
          { t: "linear", label: "Linear → Q" },
          { t: "out", label: "Q(s, a, g)", dims: "discarded at test time", c: "data-8" } ],
          facts: [["Hidden", ["3 × 512 ReLU", "p2"]], ["Targets", ["Polyak 0.98 every iteration", "p2"]], ["Batch", ["128 from a 10⁵ buffer", "p2"]]] } }
    ],
    inputs: [
      { to: "actor", mod: "vision", label: "scene + goal images", n: "100 × 100", k: 4 },
      { to: "critic", mod: "state", label: "full state + goal", n: "simulator", k: 3 }
    ],
    outputs: [{ from: "actor", mod: "action", label: "gripper command", n: "4-D", k: 2 }],
    links: [{ from: "actor", to: "critic", kind: "feeds", label: "aₜ|∇ₐQ back" }],
    callouts: [
      "Real Fetch results: Pick, Forward Push and Block Move each succeed 5/5 with asymmetric HER; symmetric HER and asymmetric DDPG score 0/5 (Table I).",
      "The same critic-sees-more trick appears in OpenAI's Rubik's-cube policy and in ASAP's motion-tracking critic."
    ]
  });

  /* ───────────────────────── A4 · ADR (Rubik's cube) ───────────────────────── */
  RB.arch.spec({
    id: "adr-solving-rubik-s-cube", method: "adr-solving-rubik-s-cube", name: "ADR / Rubik's cube (OpenAI)", year: 2019, parent: "asymmetric-actor-critic",
    diffRows: ["vision", "backbone", "head", "output", "train"],
    figRef: "OpenAI et al. Figs. 12, 14 · §6–7 · App. C", prov: "Paper only; no code released",
    lede: "An LSTM policy and a separate LSTM value network, each embedding every input type to 512-d and adding them. The policy sees noisy observations; the value network also sees the true simulator state. A ResNet-50 on three cameras estimates the cube's pose and face angles.",
    sources: {
      p1: ax("OpenAI et al. 2019, §6.1–6.2 and Fig. 12 (policy, value)", "1910.07113"),
      p2: ax("OpenAI et al. 2019, Table 1 (inputs)", "1910.07113"),
      p3: ax("OpenAI et al. 2019, App. C, Tables 13–14 (sizes, PPO)", "1910.07113"),
      p4: ax("OpenAI et al. 2019, §7.1, Fig. 14, Tables 16–17 (vision model)", "1910.07113"),
      p5: ax("OpenAI et al. 2019, §6.3 (Rapid training scale)", "1910.07113")
    },
    summary: {
      pattern: ["Actor–critic (asymmetric, recurrent)", "p1"],
      params: ["Policy 13,863,132 · value 13,638,657 · input embeddings 267,776", "p3"],
      vision: ["ResNet-50 shared over 3 cameras, 200 × 200 RGB → pose + face angles", "p4"],
      backbone: ["Embed-and-add (512 per input) → ReLU → FC 2,048 → LSTM 1,024", "p1"],
      head: ["Policy: 20 joints × 11 bins categorical; value: scalar", "p1", "p3"],
      output: ["Relative joint-position changes for the 20 actuated joints", "p1"],
      attention: "None (recurrent)",
      cond: ["Value net also gets noiseless state (qpos 170-D, qvel 168-D, hand joints 48-D)", "p2"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["PPO on Rapid: 64 V100 + 29,440 CPU cores; ≈13 thousand years of experience", "p3", "p5"]
    },
    changes: [
      "Both networks are <b>recurrent</b> (LSTM 1,024), so the policy can adapt in context (emergent meta-learning).",
      "Inputs are <b>embedded separately to 512-d and summed</b>, so new observations can be added to a trained policy.",
      "Actions are <b>discrete</b>: 11 bins for each of 20 joints.",
      "The state estimate comes from a <b>ResNet-50 vision model</b> trained only on rendered images.",
      "Training runs on a distribution widened by <b>automatic domain randomization</b>, for months, with policy cloning between architecture changes."
    ],
    blueprint: {
      headline: "Rubik's cube: two LSTMs and a vision net",
      note: "The vision model estimates cube position, orientation and face angles from three cameras; those estimates plus noisy fingertip positions and the goal feed the policy. The value network has the same shape but reads privileged simulator state as well; it shares input embeddings with the policy for inputs they both use.",
      towers: [
        { mod: "vision", title: "Vision state estimator", sub: "3 cameras, shared weights", compact: true,
          input: { label: "3 RGB images 200 × 200", caption: "left, right, top cameras" },
          rows: [
            { t: "conv", label: "Conv 5×5 /2 · pool", call: ["64 filters", "p4"] },
            { t: "conv", label: "ResNet-50 bottlenecks", call: ["3, 4, 6, 3 blocks", "p4"] },
            { t: "linear", label: "Concat 3 → FC 512 → FC 256", call: ["280 outputs", "p4"], zoom: { k: "rows", title: "Vision outputs (280 units)", rows: ["position 3 + quaternion 4", "top face angle: 180 bins", "active face angles: 90", "active axis: 3"] } } ],
          output: { label: "cube pose, face angles" } },
        { mod: "policy", title: "Policy network", sub: "noisy, robot-available inputs",
          input: { label: "Noisy observations + goal", caption: "fingertips, cube pose, goal faces" },
          rows: [
            { id: "emb", t: "embed", label: "Normalize · embed each input", call: ["512-d per input, no weight sharing", "p1"] },
            { t: "linear", label: "Sum of embeddings · ReLU" },
            { t: "linear", label: "Fully connected · ReLU", call: ["FC 2,048 → LSTM 1,024", "p1"] },
            { t: "attn", label: "LSTM (recurrent state)" },
            { t: "linear", label: "Action distribution", call: ["11 bins × 20 joints", "p1", "p3"], zoom: { k: "rows", title: "Discrete actions", rows: ["20 actuated joints", "11 bins each: relative joint targets", "multi-categorical distribution", "PPO: γ 0.998, λ 0.95, clip 0.2"] } } ],
          output: { label: "action logits 11 × 20" } },
        { mod: "value", title: "Value network", sub: "same shape, privileged inputs", compact: true,
          input: { label: "Noisy + true state", caption: "qpos 170, qvel 168, …" },
          rows: [
            { t: "embed", label: "Embed and add", call: ["512 per input", "p1"] },
            { t: "linear", label: "FC 2,048 · LSTM 1,024" },
            { t: "linear", label: "Value (1)" } ],
          output: { label: "V(s) for PPO" } }
      ],
      links: [{ from: "vision", to: "policy", toRow: "emb", label: "cube estimates" }]
    },
    modules: [
      { id: "vision", role: "vision-enc", name: "ResNet-50 estimator", sub: "3 views · 280 outputs", col: 0, frozen: false, short: "ResNet-50",
        stack: { rows: [
          { t: "in", label: "RGB per camera", dims: "200 × 200 × 3, three cameras", c: "data-1" },
          { t: "conv", label: "BatchNorm · Conv 64 5×5 /2 · dropout · max-pool" },
          { t: "conv", label: "ResNet bottlenecks: 3 × 64, 4 × 128, 6 × 256, 3 × 512" },
          { t: "pool", label: "Max-pool → flatten; concat 3 towers" },
          { t: "linear", label: "FC 512 · BN → FC 256 · BN → 280 outputs" },
          { t: "out", label: "position, orientation, face angles", dims: "to the policy", c: "data-1" } ],
          facts: [["Shared weights", ["across the 3 cameras", "p4"]], ["Optimizer", ["LARS, lr 0.5 halved every 40,000 batches", "p4"]], ["Batch", ["256 × 3 = 768 images", "p4"]], ["Loss weighting", ["focal-loss auto-balancer", "p4"]]] } },
      { id: "policy", role: "action-head", roleLabel: "Recurrent policy", name: "LSTM policy", sub: "512 emb → 2,048 → LSTM 1,024", col: 1, frozen: false, main: true, params: "13,863,132", short: "Policy",
        stack: { rows: [
          { t: "in", label: "noisy fingertips, cube pose, goal", dims: "Table 1", c: "data-5" },
          { t: "embed", label: "Normalize → Embedding 512, per input" },
          { t: "add", label: "sum of embeddings", span: 1 },
          { t: "linear", label: "ReLU → FC 2,048 → ReLU" },
          { t: "attn", label: "LSTM 1,024" },
          { t: "linear", label: "Linear → 20 × 11 logits" },
          { t: "out", label: "categorical action per joint", dims: "relative joint targets", c: "data-3" } ],
          facts: [["Parameters", ["13,863,132", "p3"]], ["FC / LSTM", ["2,048 / 1,024", "p1"]], ["Action bins", ["11 per joint, 20 joints", "p1"]], ["L2", ["10⁻⁶", "p1", "p3"]], ["Batch", ["5,120 chunks × 10 transitions per GPU", "p3"]]] } },
      { id: "value", role: "critic", roleLabel: "Privileged value", name: "LSTM value net", sub: "same shape · scalar out", col: 2, frozen: false, short: "Value",
        stack: { rows: [
          { t: "in", label: "noisy + noiseless state", dims: "incl. qpos, qvel", c: "data-8" },
          { t: "embed", label: "Embed 512 per input · add · ReLU" },
          { t: "linear", label: "FC 2,048 → LSTM 1,024" },
          { t: "linear", label: "Linear → 1" },
          { t: "out", label: "V(s)", dims: "training only", c: "data-8" } ],
          facts: [["Parameters", ["13,638,657", "p3"]], ["Privileged inputs", ["qpos 170-D, qvel 168-D, hand angles 48-D", "p2"]]] } }
    ],
    inputs: [
      { to: "vision", mod: "vision", label: "3 camera images", n: "200 × 200", k: 4 },
      { to: "policy", mod: "state", label: "noisy fingertips + goal", n: "15 + 4 + 12", k: 3 },
      { to: "value", mod: "other", label: "simulator state", n: "privileged", k: 3 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint deltas", n: "20 × 11 bins", k: 4 }],
    links: [
      { from: "vision", to: "policy", kind: "feeds", label: "cube pose,|face angles" },
      { from: "policy", to: "value", kind: "feeds", label: "shared input|embeddings" }
    ],
    callouts: [
      "The vision and control networks are trained separately and only meet on the robot; face angles can also come from the sensorised Giiker cube.",
      "ADR itself is not a network: it widens each randomization range when performance at its boundary exceeds a threshold (step Δ 0.02)."
    ]
  });

  /* ───────────────────────── A4 · ASAP ───────────────────────── */
  RB.arch.spec({
    id: "asap", method: "asap", name: "ASAP", year: 2025, parent: "h2o-omnih2o",
    diffRows: ["backbone", "cond", "rate", "train"],
    figRef: "He et al. Figs. 2–4 · §II–III", prov: "HumanoidVerse configs",
    lede: "A phase-conditioned PPO tracking policy for the 23-DoF Unitree G1, trained with an asymmetric critic. Real rollouts then train a second RL policy, the delta-action model, whose corrections are added to actions inside the simulator before fine-tuning.",
    sources: {
      p1: ax("He et al. 2025, §II-B (phase-based tracking policy)", "2502.01143"),
      p2: ax("He et al. 2025, §III (delta action model, fine-tuning)", "2502.01143"),
      p3: ax("He et al. 2025, §II-A (video → SMPL → G1 retargeting)", "2502.01143"),
      p4: ax("He et al. 2025, §IV-C (real-world data, 4-DoF ankle model)", "2502.01143"),
      c1: gh("LeCAR-Lab/ASAP", "df5320c", "humanoidverse/config/algo/ppo.yaml"),
      c2: gh("LeCAR-Lab/ASAP", "df5320c", "humanoidverse/config/obs/motion_tracking/deepmimic_a2c_nolinvel_LARGEnoise_history.yaml"),
      c3: gh("LeCAR-Lab/ASAP", "df5320c", "humanoidverse/config/algo/ppo_train_delta_a.yaml"),
      c4: gh("LeCAR-Lab/ASAP", "df5320c", "humanoidverse/config/obs/delta_a/open_loop.yaml"),
      c5: gh("LeCAR-Lab/ASAP", "df5320c", "humanoidverse/config/simulator/isaacgym.yaml")
    },
    summary: {
      pattern: ["Actor–critic + learned delta-action simulator correction", "p1", "p2"],
      params: null,
      vision: "None: proprioception and a motion phase",
      backbone: ["Actor and critic MLPs [512, 256, 128], ELU", "c1"],
      head: ["23 target joint positions for PD control", "p1"],
      output: ["aₜ ∈ ℝ²³ joint targets; delta model outputs Δaₜ", "p1", "p2"],
      attention: "None (MLPs)",
      cond: ["Actor: 5-step proprio history + phase ϕ ∈ [0, 1]; critic adds root velocity and reference body positions", "p1", "c2"],
      steps: null, chunk: null,
      rate: ["50 Hz policy (200 Hz sim, decimation 4)", "c5"],
      latency: null,
      train: ["PPO; termination tolerance 1.5 m → 0.3 m curriculum; delta model on real rollouts", "p1", "p2"]
    },
    changes: [
      "The goal is a single <b>time phase ϕ</b> per motion instead of streamed keypoints, so no odometry is needed on the robot.",
      "An <b>asymmetric critic</b> gets reference body positions and root velocity; the actor only proprioception.",
      "A second RL policy, the <b>delta-action model</b> πΔ(s, a), learns corrections that make the simulator reproduce real trajectories.",
      "The tracking policy is <b>fine-tuned inside the corrected simulator</b>, then deployed without πΔ.",
      "Motions come from <b>videos</b> (TRAM → SMPL), cleaned in simulation with MaskedMimic, then retargeted."
    ],
    blueprint: {
      headline: "ASAP: fix the simulator with a delta action",
      note: "Stage 1 trains the tracking policy and its asymmetric critic with PPO. Stage 2 replays real actions in simulation and trains πΔ so that sim states match real ones. Stage 3 freezes πΔ inside the simulator (a + Δa) and fine-tunes the tracking policy. Only the tracking policy runs on the G1.",
      towers: [
        { mod: "policy", title: "Motion-tracking policy", sub: "actor, deployed on the G1",
          input: { label: "Proprio (5 steps) + phase ϕ", caption: "ω, gravity, q, q̇, last action" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense · ELU", call: ["512 → 256 → 128", "c1"] }] },
            { t: "linear", label: "Linear → 23 joint targets", call: ["PD-tracked, 23 DoF", "p1"], zoom: { k: "rows", title: "Actor observation (per step)", rows: ["root angular velocity 3, gravity 3", "joint positions 23, velocities 23", "last action 23, phase ϕ 1", "5 steps × 76 = 380"] } } ],
          output: { label: "aₜ ∈ ℝ²³, 50 Hz" } },
        { mod: "delta", title: "Delta-action model πΔ", sub: "RL policy inside the simulator", compact: true,
          input: { label: "sₜ, aₜ (real replay)", caption: "base, contacts, joints, action" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense · ELU", call: ["512 → 256 → 128", "c3"] }] },
            { id: "d", t: "linear", label: "Δaₜ (4 ankle DoF on G1)", call: ["full model would be 23-DoF", "p4"], zoom: { k: "rows", title: "Delta-action training", rows: ["init sim at the real state sʳₜ", "sₜ₊₁ = f_sim(sₜ, aʳₜ + Δaₜ)", "reward: match sʳₜ₊₁, small ‖Δa‖", "PPO; then freeze πΔ in the sim"] } } ],
          output: { label: "a + Δa in simulation" } },
        { mod: "critic", title: "Asymmetric critic", sub: "training only", compact: true,
          input: { label: "Actor obs + privileged", caption: "root lin. vel., reference bodies" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense · ELU", call: ["512 → 256 → 128", "c1"] }] },
            { t: "linear", label: "Value" } ],
          output: { label: "V(s)" } }
      ],
      links: [{ from: "policy", to: "delta", toRow: "input", label: "aₜ (fine-tuning)" }]
    },
    modules: [
      { id: "policy", role: "action-head", roleLabel: "Tracking policy", name: "Phase tracking actor", sub: "MLP 512-256-128 · ELU", col: 1, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "5-step proprio history + phase ϕ", dims: "380-D (derived from config)", c: "data-5" },
          { t: "linear", label: "Dense 512 · ELU" }, { t: "linear", label: "Dense 256 · ELU" }, { t: "linear", label: "Dense 128 · ELU" },
          { t: "linear", label: "Linear → 23" },
          { t: "out", label: "23 joint position targets", dims: "PD, 50 Hz", c: "data-3" } ],
          facts: [["MLP", ["[512, 256, 128], ELU", "c1"]], ["History", ["q, q̇, ω, g, a over t−4:t", "p1", "c2"]], ["PPO", ["lr 10⁻³, γ 0.99, λ 0.95, 24 steps / env", "c1"]], ["Termination curriculum", ["1.5 m → 0.3 m", "p1"]]] } },
      { id: "critic", role: "critic", roleLabel: "Asymmetric critic", name: "Privileged critic", sub: "MLP 512-256-128", col: 0, frozen: false, short: "V",
        stack: { rows: [
          { t: "in", label: "actor obs + root lin. vel. + ref. bodies", dims: "privileged", c: "data-8" },
          { t: "linear", label: "Dense 512 · 256 · 128, ELU" },
          { t: "out", label: "V(s)", dims: "training only", c: "data-8" } ],
          facts: [["Privileged", ["reference global body positions, root linear velocity", "p1", "c2"]]] } },
      { id: "delta", role: "net", roleLabel: "Delta-action model", name: "πΔ(s, a)", sub: "MLP 512-256-128 → Δa", col: 2, frozen: "partial", short: "πΔ",
        note: "Trained with PPO on real rollouts, then frozen inside the simulator while the tracking policy is fine-tuned.",
        stack: { rows: [
          { t: "in", label: "base height, feet forces, velocities, joints, a", dims: "open-loop replay", c: "data-5" },
          { t: "linear", label: "Dense 512 · 256 · 128, ELU" },
          { t: "linear", label: "Linear → Δa" },
          { t: "out", label: "corrective action", dims: "added to aʳₜ in sim", c: "data-3" } ],
          facts: [["MLP", ["[512, 256, 128], ELU", "c3"]], ["Real data", ["100 clips → 4-DoF ankle model", "p4"]], ["Inputs", ["base z, feet contact force, velocities, joints, actions", "c4"]]] } }
    ],
    inputs: [
      { to: "policy", mod: "state", label: "proprio", n: "5 steps", k: 4 },
      { to: "policy", mod: "time", label: "phase ϕ", n: "[0, 1]", k: 1 },
      { to: "delta", mod: "state", label: "real (s, a) replay", n: "MoCap + onboard", k: 3 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint targets", n: "23", k: 3 }],
    links: [
      { from: "critic", to: "policy", kind: "feeds", label: "PPO value|(training)" },
      { from: "policy", to: "delta", kind: "two-stage", label: "a + Δa|in the simulator" }
    ],
    callouts: [
      "Only a <b>4-DoF ankle</b> delta model was trained for the real G1: collecting the ≥400 clips needed for the 23-DoF model broke two robots (§IV-C).",
      "Delta action vs residual RL: the correction here lives in the simulator, not in the deployed controller."
    ]
  });

  /* ───────────────────────── E4 · H2O / OmniH2O ───────────────────────── */
  RB.arch.spec({
    id: "h2o-omnih2o", method: "h2o-omnih2o", name: "H2O / OmniH2O", year: 2024,
    figRef: "He et al. OmniH2O Fig. 3 · §3 · App. C · H2O §V", prov: "OmniH2O student and teacher",
    lede: "Whole-body teleoperation of the 19-DoF Unitree H1 by tracking kinematic keypoints. A privileged RL teacher (913-D state) is distilled with DAgger into an MLP student that sees only 25 steps of proprioception and three head/hand targets.",
    sources: {
      p1: ax("He et al. 2024 (OmniH2O), §3 (teacher, student, DAgger)", "2406.08858"),
      p2: ax("He et al. 2024 (OmniH2O), App. C, Tables 4–6 (state spaces)", "2406.08858"),
      p3: ax("He et al. 2024 (OmniH2O), Fig. 3 and §4.3 (rates, autonomy)", "2406.08858"),
      p4: ax("He et al. 2024 (H2O), §III-A, §V-A (state and action)", "2403.04436"),
      c1: gh("LeCAR-Lab/human2humanoid", "750f1fa", "legged_gym/legged_gym/envs/h1/h1_teleop_config.py"),
      c2: gh("LeCAR-Lab/human2humanoid", "750f1fa", "README.md")
    },
    summary: {
      pattern: ["Teacher–student policy", "p1"],
      params: null,
      vision: "None in the controller; VR, RGB pose estimation or a learned policy supplies the targets",
      backbone: ["Teacher and student MLPs [512, 256, 128], ELU", "c1"],
      head: ["19 joint position targets; hands by IK to an off-the-shelf controller", "p1", "p4"],
      output: ["aₜ ∈ ℝ¹⁹ PD targets at 50 Hz; PD at 200 Hz", "p3", "p4"],
      attention: "None (MLPs)",
      cond: ["Student goal: head + 2 hands (27-D); proprio history 25 steps × 63-D", "p2"],
      steps: null, chunk: null,
      rate: ["Policy 50 Hz, PD controller 200 Hz", "p3"],
      latency: null,
      train: ["Teacher: PPO on retargeted AMASS; student: DAgger, L = ‖a_priv − a‖²", "p1"]
    },
    blueprint: {
      headline: "OmniH2O: distil a privileged tracker",
      note: "The teacher tracks full-body references with privileged rigid-body states. The student rolls out in simulation and regresses the teacher's action at every visited state (DAgger). Its input is 25 steps of proprioception without global linear velocity plus three sparse targets, which VR, an RGB pose estimator, a language-to-motion model or a Diffusion Policy can provide.",
      towers: [
        { mod: "goal", title: "Motion-goal source", sub: "any kinematic pose provider", compact: true,
          input: { label: "VR, RGB, MDM or policy", caption: "human operator or autonomy" },
          rows: [
            { t: "mlp", label: "Retarget to H1 keypoints", call: ["head + 2 hands for the student", "p1"], zoom: { k: "rows", title: "Goal sources", rows: ["Vision Pro VR: head and hands", "RGB + pose estimator (HybrIK)", "MDM text-to-motion, GPT-4o", "Diffusion Policy on OmniH2O-6"] } } ],
          output: { label: "3-point motion goal" } },
        { mod: "student", title: "Student policy π_OmniH2O", sub: "deployed on the H1",
          input: { label: "Proprio history + goal", caption: "90 + 25 × 63 = 1,665-D" },
          rows: [
            { id: "g", t: "linear", label: "Concat goal and history", side: "cond", call: ["1,665-D input", "p2", "c2"], zoom: { k: "rows", title: "Student input (Table 6)", rows: ["now: q 19, q̇ 19, ω 3, g 3", "+ goal 27 + last action 19 = 90", "history step: q, q̇, ω, g, a = 63", "25 steps → 1,575; no lin. vel."] } },
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense · ELU", call: ["512 → 256 → 128", "c1"] }] },
            { t: "linear", label: "Linear → 19 joint targets", call: ["PD at 200 Hz", "p3"] } ],
          output: { label: "aₜ ∈ ℝ¹⁹, 50 Hz" } },
        { mod: "teacher", title: "Privileged teacher", sub: "simulation only", compact: true,
          input: { label: "Privileged state", caption: "913-D: all rigid bodies" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense · ELU", call: ["512 → 256 → 128", "c1"] }] },
            { t: "linear", label: "→ a_priv (19)", zoom: { k: "rows", title: "DAgger distillation", rows: ["roll out the student in sim", "privileged state at each step", "query teacher → a_priv", "minimise ‖a_priv − a‖²"] } } ],
          output: { label: "a_priv labels" } }
      ],
      links: [
        { from: "goal", to: "student", toRow: "g", label: "3-point goal" },
        { from: "teacher", to: "student", toRow: "input", label: "DAgger labels" }
      ]
    },
    modules: [
      { id: "goal", role: "planner", roleLabel: "Goal source", name: "Kinematic goal source", sub: "VR · RGB · text · policy", col: 0, frozen: true, short: "Goals",
        note: "Not trained with the controller: any source of head and hand targets (the dexterous hands are driven separately by IK)." },
      { id: "student", role: "action-head", roleLabel: "Student policy", name: "π_OmniH2O", sub: "MLP 512-256-128 · 1,665-D in", col: 1, frozen: false, main: true, short: "Student",
        stack: { rows: [
          { t: "in", label: "25-step proprio history + 3-point goal", dims: "1,665-D", c: "data-5" },
          { t: "linear", label: "Dense 512 · ELU" }, { t: "linear", label: "Dense 256 · ELU" }, { t: "linear", label: "Dense 128 · ELU" },
          { t: "linear", label: "Linear → 19" },
          { t: "out", label: "19 joint targets", dims: "PD 200 Hz", c: "data-3" } ],
          facts: [["Input", ["1,665 = 90 + 25 × 63", "p2", "c2"]], ["MLP", ["[512, 256, 128], ELU", "c1"]], ["History", ["25 steps (best of 0/5/25/50)", "p1"]], ["Training", ["DAgger from the teacher", "p1", "c2"]]] } },
      { id: "teacher", role: "net", roleLabel: "Privileged teacher", name: "π_privileged", sub: "MLP 512-256-128 · 913-D in", col: 2, frozen: true, short: "Teacher",
        note: "Trained first with PPO, then frozen and queried as the DAgger expert.",
        stack: { rows: [
          { t: "in", label: "rigid-body states + full motion goal", dims: "913-D", c: "data-8" },
          { t: "linear", label: "Dense 512 · 256 · 128, ELU" },
          { t: "out", label: "a_priv", dims: "19", c: "data-3" } ],
          facts: [["Input", ["913-D (Table 4)", "p2", "c2"]], ["RL", ["PPO", "p1"]], ["H2O predecessor", ["138-D input, 8 keypoints + root velocity, RL only", "p2", "p4"]]] } }
    ],
    inputs: [
      { to: "goal", mod: "vision", label: "operator / camera", n: "30 Hz goals", k: 2 },
      { to: "student", mod: "state", label: "proprio history", n: "25 steps", k: 4 },
      { to: "teacher", mod: "other", label: "privileged state", n: "913-D", k: 3 }
    ],
    outputs: [{ from: "student", mod: "action", label: "joint targets", n: "19", k: 3 }],
    links: [
      { from: "goal", to: "student", kind: "feeds", label: "head + hands|27-D" },
      { from: "student", to: "teacher", kind: "two-stage", label: "visited states ↔|DAgger labels" }
    ],
    callouts: [
      "<b>Paper vs code:</b> the tracking-point ablation lists 1,710-D (8 points) and 1,836-D (22 points) inputs; the README commands use 1,719-D and 1,845-D (23 points).",
      "H2O (the predecessor) is the RL-only, 138-D version that still needs MoCap for root linear velocity; OmniH2O removes it with the 25-step history."
    ]
  });

  /* ───────────────────────── E4 · HumanPlus ───────────────────────── */
  RB.arch.spec({
    id: "humanplus", method: "humanplus", name: "HumanPlus", year: 2024, parent: "act",
    diffRows: ["vision", "backbone", "head", "output", "attention", "chunk", "train"],
    figRef: "Fu et al. Fig. 4 · §5–6", prov: "HST and HIT code",
    lede: "Two small transformers. HST, trained with PPO on 40 h of AMASS, turns 8 steps of proprioception and a target pose into 19 joint setpoints at 50 Hz. HIT, trained by imitation, reads two egocentric cameras and predicts 50 target poses plus future image features.",
    sources: {
      p1: ax("Fu et al. 2024, §5 (Humanoid Shadowing Transformer)", "2406.10454"),
      p2: ax("Fu et al. 2024, §6 (Humanoid Imitation Transformer)", "2406.10454"),
      p3: ax("Fu et al. 2024, §3–4 (hardware, data, retargeting)", "2406.10454"),
      c1: gh("MarkFzp/humanplus", "ff71489", "HST/rsl_rl/rsl_rl/modules/actor_critic_transformer.py"),
      c2: gh("MarkFzp/humanplus", "ff71489", "HST/legged_gym/legged_gym/envs/h1/h1_config.py"),
      c3: gh("MarkFzp/humanplus", "ff71489", "HIT/detr/models/transformer_bert.py"),
      c4: gh("MarkFzp/humanplus", "ff71489", "HIT/detr/models/detr_vae.py"),
      c5: gh("MarkFzp/humanplus", "ff71489", "README.md"),
      c6: gh("MarkFzp/humanplus", "ff71489", "HIT/imitate_episodes_h1_train.py"),
      c7: gh("MarkFzp/humanplus", "ff71489", "HIT/constants.py")
    },
    summary: {
      pattern: ["Imitation transformer over an RL tracking transformer", "p1", "p2"],
      params: null,
      vision: ["ResNet-18 shared by 2 head cameras (binocular), 1 × 1 conv to 512", "p2", "c4", "c5"],
      backbone: ["HIT: 6 blocks, width 512, 8 heads, MLP 2,048 (GELU); HST: 4 blocks, width 128, 4 heads", "c1", "c3", "c5"],
      head: ["HIT: 50 action queries → Linear → 40-D pose targets; image tokens → L2 feature loss", "p2", "c4", "c5"],
      output: ["HIT: chunk of 50 target poses at 25 Hz → HST: 19 joint setpoints at 50 Hz", "p1", "p2"],
      attention: ["Code: full self-attention over each context (no causal mask)", "c1", "c3"],
      cond: ["HST: last token of an 8-step context of [proprio ‖ target pose]", "p1", "c1", "c2"],
      steps: ["One forward pass per chunk", "p2"],
      chunk: ["50 target poses per call", "p2", "c5"],
      rate: ["HIT 25 Hz · HST 50 Hz · PD 1,000 Hz", "p1", "p2"],
      latency: null,
      train: ["HST: PPO in sim on AMASS; HIT: ≤ 40 demos per task, feature-loss weight 0.005", "p1", "p2", "c5"]
    },
    changes: [
      "The CVAE encoder is removed: HIT is a <b>single decoder-style stack</b> over [proprio ‖ image tokens ‖ 50 queries].",
      "Besides actions, HIT <b>predicts future image-feature tokens</b> (forward dynamics) with an L2 loss.",
      "Two <b>egocentric cameras</b> share one ResNet-18 instead of four fixed cameras.",
      "HIT outputs <b>target poses</b>, not joint commands; a second transformer (HST, trained with RL) executes them.",
      "The chunk is 50 steps instead of 100, and the width stays 512."
    ],
    blueprint: {
      headline: "HumanPlus: imitation on top of shadowing",
      note: "HIT turns two camera frames and proprioception into 50 future target poses and discards its predicted image tokens at run time. Each target pose goes into HST, whose 8-step context of proprioception and targets yields the next 19 joint setpoints; the hands and wrists bypass HST and go straight to the PD controller.",
      towers: [
        { mod: "hit", title: "Humanoid Imitation Transformer", sub: "vision → 50 target poses",
          input: { label: "2 RGB frames + proprio", caption: "binocular head cameras" },
          rows: [
            { t: "conv", label: "ResNet-18 (shared) · 1×1 conv", call: ["features → 512 channels", "c4", "c5"] },
            { t: "embed", label: "[proprio ‖ image tokens ‖ 50 queries]", call: ["183 prefix tokens + 50 queries", "c6"] },
            { t: "block", n: "6", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head self-attention", call: ["8 heads, width 512", "c5", "c6"], zoom: { k: "heads", q: 8, kv: 8, hd: 64, title: "HIT attention" } },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["hidden 2,048, GELU", "c3"], zoom: { k: "mlp", act: "GELU", d: "512", ff: "2,048", title: "HIT feed forward" } },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm 3" } ] },
            { t: "linear", label: "Action head · feature tokens", call: ["L2 feature loss weight 0.005", "c5"] } ],
          output: { label: "50 target poses, 25 Hz" } },
        { mod: "hst", title: "Humanoid Shadowing Transformer", sub: "RL low-level policy",
          input: { label: "8 × [proprio ‖ target]", caption: "84-D per step (code)" },
          rows: [
            { id: "tin", t: "linear", label: "Linear + learned position", call: ["→ 128, context 8", "c1", "c2"] },
            { t: "block", n: "4", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head self-attention", call: ["4 heads, width 128", "c1"], zoom: { k: "heads", q: 4, kv: 4, hd: 32, title: "HST attention" } },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["hidden 512, GELU", "c1"] },
              { t: "add", span: 1 } ] },
            { t: "linear", label: "LayerNorm · Linear (last token)", call: ["→ 19 joint setpoints", "p1", "c2"] } ],
          output: { label: "19 setpoints, 50 Hz" } }
      ],
      links: [{ from: "hit", to: "hst", toRow: "tin", label: "target pose" }]
    },
    modules: [
      { id: "hit", role: "action-expert", roleLabel: "Imitation transformer", name: "HIT", sub: "6 × 512 · 8 heads", col: 0, frozen: false, main: true, short: "HIT",
        stack: { rows: [
          { t: "in", label: "2 egocentric RGB frames + proprio", dims: "state 35-D (task config)", c: "data-1" },
          { t: "conv", label: "ResNet-18 (shared, lr 10⁻⁵) → 1 × 1 conv 512" },
          { t: "linear", label: "proprio → Linear 512" },
          { t: "embed", label: "+ 50 query embeddings, sinusoidal positions" },
          { t: "block", label: "Transformer block", n: "6", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 8 heads · no mask" }, { t: "add", span: 1 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 512 → 2,048 → 512 · GELU" }, { t: "add", span: 1 },
            { t: "norm", label: "LayerNorm" } ] },
          { t: "linear", label: "action head (query tokens) · image tokens" },
          { t: "out", label: "50 target poses + predicted image features", dims: "40-D action (task config)", c: "data-3" } ],
          facts: [["Width / depth / heads", ["512 / 6 / 8", "c5", "c6"]], ["MLP", ["4 × width = 2,048, GELU", "c3"]], ["Chunk", ["50", "p2", "c5"]], ["Feature loss", ["L2 on future image tokens, weight 0.005", "p2", "c5"]], ["Onboard rate", ["25 Hz", "p2"]], ["State / action dims", ["35 / 40 (task config)", "c7"]]] } },
      { id: "hst", role: "action-head", roleLabel: "Low-level RL policy", name: "HST", sub: "4 × 128 · 4 heads · ctx 8", col: 1, frozen: true, short: "HST",
        note: "Trained first with PPO in simulation and then used as a fixed low-level controller.",
        stack: { rows: [
          { t: "in", label: "8 steps of [proprio ‖ target pose]", dims: "84-D per step (65 + 19)", c: "data-5" },
          { t: "linear", label: "Linear → 128 · dropout 0.1 · + learned positions" },
          { t: "block", label: "Transformer block", n: "4", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 4 heads" }, { t: "add", span: 1 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 128 → 512 → 128 · GELU" }, { t: "add", span: 1 } ] },
          { t: "norm", label: "LayerNorm" },
          { t: "linear", label: "Linear → 19 (last token)" },
          { t: "out", label: "19 body joint setpoints", dims: "PD 1,000 Hz; Kp 100, Kd 5 in sim", c: "data-3" } ],
          facts: [["Width / depth / heads", ["128 / 4 / 4", "c1"]], ["Context", ["8", "p1", "c2"]], ["Envs", ["2,048 in IsaacGym", "c2"]], ["Data", ["40 h AMASS, retargeted", "p1", "p3"]], ["Sim PD gains", ["Kp 100, Kd 5", "c2"]]] } }
    ],
    inputs: [
      { to: "hit", mod: "vision", label: "2 cameras", n: "binocular", k: 3 },
      { to: "hit", mod: "state", label: "proprio", n: "35-D", k: 2 },
      { to: "hst", mod: "state", label: "proprio history", n: "8 steps", k: 3 }
    ],
    outputs: [{ from: "hst", mod: "action", label: "joint setpoints", n: "19", k: 3 }, { from: "hit", mod: "future", label: "future image tokens", n: "train only", k: 2 }],
    links: [{ from: "hit", to: "hst", kind: "two-stage", label: "target poses|25 → 50 Hz" }],
    mask: { name: "HIT: full (no mask in code)", ref: "c3", axes: [{ label: "proprio token", short: "q", mod: "state" }, { label: "image tokens", short: "img", mod: "vision" }, { label: "50 action queries", short: "A", mod: "action" }], m: ["111", "111", "111"],
      note: "The paper calls both models decoder-only; the released blocks pass no attention mask." },
    callouts: [
      "<b>Paper vs code:</b> HST and HIT are described as decoder-only transformers, but the released blocks call nn.MultiheadAttention without a causal mask, so every token sees the whole context. The blocks also normalise first and add the residual to the normalised input.",
      "HIT's dim_feedforward flag is ignored by its block: the MLP is fixed at 4 × width (2,048)."
    ]
  });

  /* ───────────────────────── E4 · ExBody2 ───────────────────────── */
  RB.arch.spec({
    id: "exbody2", method: "exbody2", name: "ExBody2", year: 2024, parent: "h2o-omnih2o",
    diffRows: ["backbone", "cond", "train"],
    figRef: "Ji et al. Fig. 3 · §III-B · App. B, D", prov: "Paper only; no public code",
    lede: "A PPO teacher with privileged root velocity and body positions, distilled by DAgger into a larger MLP student with 10 steps of proprioception. Keypoints are tracked in the robot's local frame, while the root follows a velocity command.",
    sources: {
      p1: ax("Ji et al. 2024, §III-B (teacher, student, decoupled control)", "2412.13196"),
      p2: ax("Ji et al. 2024, App. B, Tables V–VII (state spaces)", "2412.13196"),
      p3: ax("Ji et al. 2024, App. D, Table VIII (hyperparameters)", "2412.13196"),
      p4: ax("Ji et al. 2024, App. A (deployment)", "2412.13196")
    },
    summary: {
      pattern: ["Teacher–student policy", "p1"],
      params: null,
      vision: "None: proprioception + motion targets",
      backbone: ["Teacher actor and value MLP [512, 256, 128]; student MLP [1,024, 1,024, 512]", "p3"],
      head: ["23 target joint positions for PD", "p2"],
      output: ["aₜ ∈ ℝ²³ on the Unitree G1; 50 Hz inference", "p2", "p4"],
      attention: "None (MLPs)",
      cond: ["Target: 23 joints, 36-D local keypoints, root velocity and pose (69-D)", "p2"],
      steps: null, chunk: null,
      rate: ["Policy 50 Hz, low-level interface 500 Hz", "p4"],
      latency: null,
      train: ["Teacher: PPO; student: DAgger with MSE on actions; Adam 10⁻⁴, batch 4,096", "p1", "p3"]
    },
    changes: [
      "Keypoints are tracked <b>in the robot's local frame</b>; global motion is tracked through <b>root velocity</b>, not global keypoints.",
      "The student is <b>larger</b> (1,024-1,024-512) than the teacher and sees 10 steps of history.",
      "Privileged information is small: joint and keybody differences plus root velocity (62-D).",
      "Training data are <b>curated automatically</b> by the base policy's tracking error; specialists are fine-tuned per motion group.",
      "Hardware moves from the H1 (19 DoF) to the <b>G1 (23 DoF)</b>."
    ],
    blueprint: {
      headline: "ExBody2: local keypoints, velocity root",
      note: "The teacher reads proprioception, the 69-D motion target and 62-D of privileged state. The student replaces the privileged part with 10 steps of 75-D proprioception and is trained by DAgger on the teacher's actions; both output 23 PD targets.",
      towers: [
        { mod: "student", title: "Student policy", sub: "deployed on the G1",
          input: { label: "10 × proprio ‖ target", caption: "750 + 69 dims" },
          rows: [
            { id: "in", t: "linear", label: "Concat history and target", zoom: { k: "rows", title: "Inputs (Tables V, VII)", rows: ["proprio: q, q̇, a 3 × 23 + ω, rpy = 75", "× 10 history steps = 750", "target: joints, keypoints, root = 69", "keypoints in the local frame"] } },
            { t: "linear", label: "Dense 1,024", call: ["MLP [1,024, 1,024, 512]", "p3"] },
            { t: "linear", label: "Dense 1,024" },
            { t: "linear", label: "Dense 512" },
            { t: "linear", label: "Linear → 23 PD targets", call: ["50 Hz, 18–30 ms command delay", "p4"] } ],
          output: { label: "aₜ ∈ ℝ²³" } },
        { mod: "teacher", title: "Teacher policy", sub: "PPO, simulation only", compact: true,
          input: { label: "Proprio + target + privileged", caption: "privileged 62-D" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense", call: ["512 → 256 → 128", "p3"] }] },
            { t: "linear", label: "→ âₜ (23)", zoom: { k: "rows", title: "Teacher-student", rows: ["teacher: PPO, γ 0.99, clip 0.2", "privileged 62-D: DoF, keybody, v", "student rolled out (DAgger)", "loss ‖aₜ − âₜ‖²"] } } ],
          output: { label: "âₜ labels" } }
      ],
      links: [{ from: "teacher", to: "student", toRow: "in", label: "DAgger labels" }]
    },
    modules: [
      { id: "teacher", role: "net", roleLabel: "Privileged teacher", name: "Teacher MLP", sub: "512-256-128", col: 0, frozen: true, short: "Teacher",
        stack: { rows: [
          { t: "in", label: "proprio + target + privileged", dims: "privileged 62-D", c: "data-8" },
          { t: "linear", label: "Dense 512 → 256 → 128" },
          { t: "out", label: "âₜ", dims: "23", c: "data-3" } ],
          facts: [["Actor / value MLP", ["[512, 256, 128]", "p3"]], ["Privileged", ["62-D: DoF diff, keybody diff, root velocity", "p2"]], ["PPO", ["γ 0.99, clip 0.2, entropy 0.005, 5 epochs", "p3"]]] } },
      { id: "student", role: "action-head", roleLabel: "Student policy", name: "Student MLP", sub: "1,024-1,024-512 · 10 steps", col: 1, frozen: false, main: true, short: "Student",
        stack: { rows: [
          { t: "in", label: "10-step proprio history ‖ motion target", dims: "750 + 69", c: "data-5" },
          { t: "linear", label: "Dense 1,024" }, { t: "linear", label: "Dense 1,024" }, { t: "linear", label: "Dense 512" },
          { t: "linear", label: "Linear → 23" },
          { t: "out", label: "23 joint targets", dims: "PD on the G1", c: "data-3" } ],
          facts: [["MLP", ["[1,024, 1,024, 512]", "p3"]], ["History", ["10 steps (best of 0/10/25/50/100)", "p2"]], ["Optimizer", ["Adam 10⁻⁴, batch 4,096", "p3"]]] } }
    ],
    inputs: [
      { to: "student", mod: "state", label: "proprio history", n: "10 × 75", k: 4 },
      { to: "student", mod: "other", label: "motion target", n: "69-D", k: 2 },
      { to: "teacher", mod: "other", label: "privileged state", n: "62-D", k: 2 }
    ],
    outputs: [{ from: "student", mod: "action", label: "joint targets", n: "23", k: 3 }],
    links: [{ from: "teacher", to: "student", kind: "two-stage", label: "DAgger|labels" }],
    callouts: [
      "The paper states a teacher–student pipeline with concatenated inputs into MLPs; activations are not given."
    ]
  });

  /* ───────────────────────── E4 · WoCoCo ───────────────────────── */
  RB.arch.spec({
    id: "wococo", method: "wococo", name: "WoCoCo", year: 2024,
    figRef: "Zhang et al. §2–3 · App. H–L", prov: "Released H1 task config",
    lede: "End-to-end PPO for tasks split into contact stages. The actor and critic are plain [512, 256, 128] MLPs; exploration comes from a frozen random hash network that counts visits to 2¹⁶ buckets of the robot's base and end-effector state.",
    sources: {
      p1: ax("Zhang et al. 2024, §2–3.1 (contact stages, rewards, curiosity)", "2406.06005"),
      p2: ax("Zhang et al. 2024, App. H–I (observations, networks)", "2406.06005"),
      p3: ax("Zhang et al. 2024, §3.2 and App. L (sim-to-real, control)", "2406.06005"),
      p4: ax("Zhang et al. 2024, App. E (reward weights)", "2406.06005"),
      c1: gh("LeCAR-Lab/wococo", "c44d312", "legged_gym/legged_gym/envs/h1/h1_jumpjack_config.py"),
      c2: gh("LeCAR-Lab/wococo", "c44d312", "legged_gym/legged_gym/envs/base/curiosity.py")
    },
    summary: {
      pattern: ["Actor–critic", "p1"],
      params: null,
      vision: "None: proprioception + goal representations (MoCap)",
      backbone: ["Actor and critic MLPs [512, 256, 128], ELU", "p2", "c1"],
      head: ["19 joint targets on the Unitree H1", "p1", "c1"],
      output: ["PD targets, 4 Hz Butterworth-filtered", "p3"],
      attention: "None (MLPs)",
      cond: ["Goal: contact and task goals of the current (and next) stage; 3-step stacked joint history", "p2", "p3"],
      steps: null, chunk: null,
      rate: ["Policy 50 Hz, PD 200 Hz", "p3"],
      latency: null,
      train: ["PPO + symmetry augmentation; 3-phase sim-to-real curriculum", "p1", "p3"]
    },
    blueprint: {
      headline: "WoCoCo: contact stages and a hash curiosity",
      note: "The policy is a standard MLP. What is new sits around it: dense contact rewards, a stage-count reward, and a count-based curiosity bonus from a frozen random network that hashes 29 base and end-effector features into 16 bits.",
      towers: [
        { mod: "policy", title: "Actor", sub: "end-to-end MLP",
          input: { label: "Proprio (3-step stack) + goals", caption: "187-D in the released config" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense · ELU", call: ["512 → 256 → 128", "p2", "c1"] }] },
            { t: "linear", label: "Linear → 19 joint targets", call: ["Butterworth low-pass 4 Hz on targets", "p3"], zoom: { k: "rows", title: "WoCoCo rewards", rows: ["r_con: + correct, − wrong contacts", "r_stage = n_stage · F_task", "r_curi = 1 / √visits(bucket)", "+ 1–2 task terms, + regularisers"] } } ],
          output: { label: "aₜ ∈ ℝ¹⁹, 50 Hz" } },
        { mod: "critic", title: "Critic", sub: "same shape", compact: true,
          input: { label: "Same observations", caption: "symmetric PPO" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Dense · ELU", call: ["512 → 256 → 128", "c1"] }] },
            { t: "linear", label: "Value" } ],
          output: { label: "V(s)" } },
        { mod: "hash", title: "Curiosity hash", sub: "random, frozen", compact: true,
          input: { label: "o_curi (29 → sin, cos)", caption: "base pose, velocities, EE states" },
          rows: [
            { t: "linear", label: "Hidden layer", call: ["32 units", "p2", "c1"] },
            { t: "linear", label: "→ 16-d, sign → bucket", call: ["2¹⁶ buckets", "c1", "c2"], zoom: { k: "rows", title: "Count-based hash", rows: ["f_curi(o) ∈ ℝ¹⁶ (random, frozen)", "bits = f_curi(o) > 0", "bucket = BIN2DEC(bits)", "bonus 1/√count, phase 1 only"] } } ],
          output: { label: "curiosity reward" } }
      ],
      links: [{ from: "hash", to: "critic", toRow: "input", label: "r_curi" }]
    },
    modules: [
      { id: "policy", role: "action-head", roleLabel: "Actor", name: "MLP actor", sub: "512-256-128 · ELU", col: 0, frozen: false, main: true, short: "π",
        stack: { rows: [
          { t: "in", label: "proprio ×3 steps + goal representation", dims: "187-D (released config)", c: "data-5" },
          { t: "linear", label: "Dense 512 · ELU" }, { t: "linear", label: "Dense 256 · ELU" }, { t: "linear", label: "Dense 128 · ELU" },
          { t: "linear", label: "Linear → 19" },
          { t: "out", label: "joint targets", dims: "PD 200 Hz", c: "data-3" } ],
          facts: [["MLP", ["[512, 256, 128], ELU", "p2", "c1"]], ["Actions", ["19", "c1"]], ["History", ["3 control steps of joints and actions", "p3"]], ["Symmetry", ["left-right augmentation in PPO", "p1"]]] } },
      { id: "critic", role: "critic", name: "MLP critic", sub: "512-256-128", col: 1, frozen: false, short: "V",
        stack: { rows: [
          { t: "in", label: "observations", dims: "", c: "data-5" },
          { t: "linear", label: "Dense 512 · 256 · 128, ELU" },
          { t: "out", label: "V(s)", dims: "", c: "data-8" } ],
          facts: [["MLP", ["[512, 256, 128]", "p2", "c1"]]] } },
      { id: "hash", role: "net", roleLabel: "Curiosity hash", name: "Random hash net", sub: "58 → 32 → 16 bits", col: 2, frozen: true, short: "hash",
        stack: { rows: [
          { t: "in", label: "curiosity obs, sin/cos encoded", dims: "29 × 2 = 58", c: "data-8" },
          { t: "linear", label: "Linear 32 (random, frozen)" },
          { t: "linear", label: "Linear → 16" },
          { t: "out", label: "16-bit bucket id", dims: "count → 1/√n bonus", c: "data-8" } ],
          facts: [["Hidden", ["32", "p2", "c1"]], ["Output", ["16-d → 2¹⁶ buckets", "p2", "c2"]], ["Curiosity weight", ["5,000–40,000 per task", "p4"]]] } }
    ],
    inputs: [
      { to: "policy", mod: "state", label: "proprio + goals", n: "187-D", k: 4 },
      { to: "hash", mod: "state", label: "base + end effectors", n: "29", k: 2 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint targets", n: "19", k: 3 }],
    links: [
      { from: "policy", to: "critic", kind: "feeds", label: "PPO" },
      { from: "hash", to: "critic", kind: "feeds", label: "r_curi into|the return" }
    ],
    callouts: [
      "Curiosity is on only in the first curriculum phase; phase 2 adds domain randomization and phase 3 doubles the regularisation weights in 20 % steps (§3.2).",
      "RND-based curiosity made the robot over-explore risky leaning; the hash count did not (§5)."
    ]
  });

  /* ───────────────────────── E4 · Real-world humanoid locomotion ───────────────────────── */
  RB.arch.spec({
    id: "real-world-humanoid-locomotion", method: "real-world-humanoid-locomotion", name: "Real-world humanoid locomotion", year: 2023,
    figRef: "Radosavovic et al. Fig. 7 · Materials and Methods", prov: "Paper only; no public code",
    lede: "A 1.4M-parameter causal transformer reads the last 16 observation-action pairs and outputs PD setpoints and gains for the Digit humanoid. It is trained with PPO plus a KL term to an MLP state-teacher that is annealed to zero.",
    sources: {
      p1: ax("Radosavovic et al. 2023, Model architecture", "2303.03381"),
      p2: ax("Radosavovic et al. 2023, Joint optimization and action space", "2303.03381"),
      p3: ax("Radosavovic et al. 2023, Sim-to-real transfer (rates)", "2303.03381"),
      p4: ax("Radosavovic et al. 2023, Results: Digit robot", "2303.03381")
    },
    summary: {
      pattern: ["Teacher–student policy (causal transformer)", "p1"],
      params: ["1.4M (student)", "p1"],
      vision: "None: blind, proprioception only",
      backbone: ["4 blocks, embedding 192, 4 heads, MLP ratio 2", "p1"],
      head: ["Action MLP [256, 128] → 16 joint setpoints + 8 leg PD gains", "p1", "p2"],
      output: ["PD setpoints for 16 actuated joints and PD gains for 8 leg joints", "p2"],
      attention: ["Causal over a 16-token context of (observation, action) pairs", "p1"],
      cond: ["Each token: MLP [512, 512] embedding of oₜ and aₜ₋₁ + sinusoidal position", "p1"],
      steps: null, chunk: null,
      rate: ["Policy 50 Hz, joint PD 1 kHz", "p3"],
      latency: null,
      train: ["L = L_RL + λ·KL(π_o ‖ π_s), λ annealed to 0 by mid-training; PPO", "p2"]
    },
    blueprint: {
      headline: "Digit: a causal transformer over history",
      note: "Each (observation, previous action) pair becomes one token. Four causal blocks attend over the last 16 tokens and the newest token's output is decoded into setpoints and gains. The MLP teacher on full state only supervises training through the annealed KL term.",
      towers: [
        { mod: "student", title: "Causal transformer policy", sub: "1.4M parameters, deployed",
          input: { label: "16 × (oₜ, aₜ₋₁) tokens", caption: "proprioceptive history" },
          rows: [
            { t: "mlp", label: "Token embed MLP", call: ["hidden [512, 512] → 192", "p1"] },
            { t: "embed", label: "+ sinusoidal position" },
            { t: "block", n: "4", rows: [
              { t: "norm", label: "Norm" },
              { t: "attn", label: "Causal self-attention", call: ["4 heads, embedding 192", "p1"], zoom: { k: "heads", q: 4, kv: 4, hd: 48, title: "Causal attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "Norm" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["MLP ratio 2 → 384", "p1"], zoom: { k: "rows", title: "Feed forward", rows: ["Linear 192 → 384", "activation not stated", "Linear 384 → 192"] } },
              { t: "add", span: 2 } ] },
            { t: "mlp", label: "Action MLP", call: ["[256, 128] → 16 + 8", "p1", "p2"] } ],
          output: { label: "setpoints + gains, 50 Hz" } },
        { mod: "teacher", title: "State teacher π_s", sub: "simulation only", compact: true,
          input: { label: "Full state sₜ", caption: "robot + env parameters" },
          rows: [
            { t: "mlp", label: "MLP", call: ["[512, 512, 256, 128]", "p1"], zoom: { k: "rows", title: "Training objective", rows: ["train π_s with RL on full state", "student: L_RL(π_o)", "+ λ · KL(π_o ‖ π_s)", "λ annealed to 0 by mid-training"] } } ],
          output: { label: "π_s(a | s)" } }
      ],
      links: [{ from: "teacher", to: "student", toRow: "input", label: "KL (annealed)" }]
    },
    modules: [
      { id: "student", role: "action-head", roleLabel: "Transformer policy", name: "Causal transformer", sub: "4 × 192 · 4 heads · ctx 16", col: 0, frozen: false, main: true, params: "1.4M", short: "π_o",
        stack: { rows: [
          { t: "in", label: "(oₜ, aₜ₋₁) … (oₜ₋₁₅, aₜ₋₁₆)", dims: "16 tokens", c: "data-5" },
          { t: "mlp", label: "Embedding MLP [512, 512] → 192" },
          { t: "embed", label: "+ sinusoidal positional encoding" },
          { t: "block", label: "Transformer block", n: "4", rows: [
            { t: "attn", label: "Causal MHA · 4 heads · 192" }, { t: "ffn", label: "MLP 192 → 384 → 192" } ] },
          { t: "mlp", label: "Action MLP [256, 128]" },
          { t: "out", label: "16 setpoints + 8 PD gains", dims: "50 Hz", c: "data-3" } ],
          facts: [["Parameters", ["1.4M", "p1"]], ["Blocks / width / heads", ["4 / 192 / 4", "p1"]], ["MLP ratio", ["2.0", "p1"]], ["Context", ["16", "p1"]], ["Robot", ["Digit, 30 DoF, 16 actuated in the policy", "p2", "p4"]]] } },
      { id: "teacher", role: "net", roleLabel: "State teacher", name: "MLP teacher", sub: "512-512-256-128", col: 1, frozen: true, short: "π_s",
        stack: { rows: [
          { t: "in", label: "full simulator state", dims: "privileged", c: "data-8" },
          { t: "mlp", label: "MLP [512, 512, 256, 128]" },
          { t: "out", label: "teacher action distribution", dims: "KL target", c: "data-3" } ],
          facts: [["MLP", ["[512, 512, 256, 128]", "p1"]], ["Role", ["KL supervision, annealed away", "p2"]]] } }
    ],
    inputs: [{ to: "student", mod: "state", label: "obs-action history", n: "16 tokens", k: 5 }, { to: "teacher", mod: "other", label: "full state", n: "sim only", k: 2 }],
    outputs: [{ from: "student", mod: "action", label: "setpoints + gains", n: "16 + 8", k: 3 }],
    links: [{ from: "student", to: "teacher", kind: "two-stage", label: "KL to π_s|(training)" }],
    mask: { name: "Causal (history)", ref: "p1", axes: [{ label: "older pairs", short: "t−15…", mod: "state" }, { label: "recent pairs", short: "…t−1", mod: "state" }, { label: "current (oₜ, aₜ₋₁)", short: "t", mod: "state" }], m: ["100", "110", "111"],
      note: "Each token attends only to preceding tokens; the action is read from the newest one." },
    callouts: [
      "Ablations: the transformer beats MLP, TCN and LSTM students, and longer context helps (Fig. 8).",
      "The block's normalisation type and activation are not stated in the paper."
    ]
  });

  /* ───────────────────────── E4 · FLAM ───────────────────────── */
  RB.arch.spec({
    id: "flam", method: "flam", name: "FLAM", year: 2025, parent: "td-mpc2",
    diffRows: ["train", "cond"],
    figRef: "Zhang et al. Figs. 1–3 · §III · Table I", prov: "TD-MPC2 + RoHM code",
    lede: "TD-MPC2 on HumanoidBench's H1 with an extra reward: the robot pose is mapped to SMPL-X, the pretrained RoHM diffusion model reconstructs a stable human motion, and joints that stay close earn reward.",
    sources: {
      p1: ax("Zhang et al. 2025, §III-A (stabilizing reward)", "2503.22249"),
      p2: ax("Zhang et al. 2025, §III-B (basic policy, reward combination)", "2503.22249"),
      p3: ax("Zhang et al. 2025, §IV-A and Table I (setup, hyperparameters)", "2503.22249"),
      c1: gh("xianqi-zhang/FLAM", "19bd4d8", "src/configs/config_model.py"),
      c2: gh("xianqi-zhang/FLAM", "19bd4d8", "src/rewards/stabilize_reward.py")
    },
    summary: {
      pattern: ["Latent world model (JEPA / TD-MPC)", "p2"],
      params: ["TD-MPC2 5M configuration (model_size 5)", "c1"],
      vision: "None: HumanoidBench state observations",
      backbone: ["TD-MPC2: encoder 2 × 256 → latent 512 (SimNorm 8); MLPs 512", "c1"],
      head: ["Reward, 5 Q-functions (101 bins), policy prior", "p2", "c1"],
      output: ["Action for the 61-DoF H1 (21 body + 40 hand) from MPPI planning", "p3"],
      attention: "None (MLPs; RoHM is a diffusion model used only for the reward)",
      cond: ["R = R_T + λ · (q / l_e) · R_S, λ ∈ [0.5, 1.0], l_e = 1,000", "p2", "p3"],
      steps: ["MPPI: horizon 3, 6 iterations, 512 samples, 64 elites", "c1"],
      chunk: ["Reward computed on segments of l_s = 145 steps", "p3"],
      rate: null, latency: null,
      train: ["2M steps per task on HumanoidBench, batch 256", "p3", "c1"]
    },
    changes: [
      "The world model and planner are TD-MPC2's; what changes is the <b>reward</b>.",
      "A frozen human-motion <b>diffusion model (RoHM)</b> judges posture stability from 145-step segments.",
      "Robot poses are <b>mapped to SMPL-X</b> joint by joint before RoHM sees them.",
      "The stabilizing reward is scaled by the task's expected per-step return (q / l_e) and added to the task reward."
    ],
    blueprint: {
      headline: "FLAM: a human-motion prior as reward",
      note: "Every 145 steps the collected robot trajectory goes through the reward pipeline; the resulting stabilizing reward is added to HumanoidBench's task reward before the transitions enter TD-MPC2's replay buffer. The policy itself is unchanged TD-MPC2.",
      towers: [
        { mod: "reward", title: "Stabilizing reward", sub: "frozen foundation model", compact: true,
          input: { label: "Robot trajectory segment", caption: "l_s = 145 states" },
          rows: [
            { t: "mlp", label: "F_M: robot → SMPL-X pose", call: ["joint-by-joint rotation mapping", "p1"] },
            { t: "conv", label: "F_R: RoHM diffusion", call: ["pretrained, frozen", "p1"], zoom: { k: "rows", title: "RoHM reconstruction", rows: ["input: noisy SMPL-X segment S", "diffusion trajectory + pose nets", "output: stable segment Ŝ", "pretrained on human motion"] } },
            { t: "linear", label: "F_S: joint similarity", call: ["r_j 0.1, t_j 0.1, t_s 1.5", "p3", "c2"], zoom: { k: "rows", title: "Similarity reward", rows: ["Γ = r_j if ‖sⁱ − ŝⁱ‖² ≤ t_j", "F_S = Σ Γ over joints", "R_S = F_S if F_S ≥ t_s, else 0", "19 mapped joints → max 1.9 (code)"] } } ],
          output: { label: "R_S per step" } },
        { mod: "tdmpc", title: "TD-MPC2 policy", sub: "5M configuration",
          input: { label: "State s", caption: "HumanoidBench H1" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "linear", label: "Encoder dense", call: ["256 units", "c1"] }] },
            { t: "norm", label: "Latent z · SimNorm", call: ["512-d, groups of 8", "c1"] },
            { id: "r", t: "mlp", label: "Dynamics, reward, 5 Q, prior", side: "cond", call: ["MLP width 512; Q in 101 bins", "c1"] },
            { t: "mlp", label: "MPPI planner", call: ["horizon 3, 512 samples, 64 elites", "c1"] } ],
          output: { label: "action (61 DoF)" } }
      ],
      links: [{ from: "reward", to: "tdmpc", toRow: "r", label: "R_T + λ(q/l_e)R_S" }]
    },
    modules: [
      { id: "reward", role: "critic", roleLabel: "Stabilizing reward", name: "SMPL-X map + RoHM", sub: "frozen · segments of 145", col: 0, frozen: true, short: "R_S",
        stack: { rows: [
          { t: "in", label: "robot pose trajectory", dims: "145 steps", c: "data-5" },
          { t: "mlp", label: "F_M: map joints to SMPL-X" },
          { t: "conv", label: "F_R: RoHM diffusion reconstruction" },
          { t: "linear", label: "F_S: count joints within threshold" },
          { t: "out", label: "stabilizing reward R_S", dims: "0 unless ≥ t_s", c: "data-8" } ],
          facts: [["Segment", ["145 steps", "p3"]], ["Joint reward / threshold", ["0.1 / 0.1", "p3", "c2"]], ["Similarity threshold", ["1.5", "p3", "c2"]], ["Scale λ", ["1.0 (0.5 for Crawl, Sit)", "p3"]], ["Expected return q", ["750 locomotion, 350 manipulation", "p3", "c1"]]] } },
      { id: "tdmpc", role: "world", roleLabel: "World model + planner", name: "TD-MPC2", sub: "latent 512 · 5 Q · MPPI", col: 1, frozen: false, main: true, short: "TD-MPC2",
        stack: { rows: [
          { t: "in", label: "state s", dims: "H1 with hands", c: "data-5" },
          { t: "linear", label: "Encoder: 2 × 256 → latent 512 · SimNorm" },
          { t: "mlp", label: "Latent dynamics, reward, 5 Q (101 bins), policy prior" },
          { t: "mlp", label: "MPPI: horizon 3, 6 iterations" },
          { t: "out", label: "action", dims: "61 DoF", c: "data-3" } ],
          facts: [["Model size", ["5M configuration", "c1"]], ["Latent", ["512, SimNorm dim 8", "c1"]], ["Q ensemble", ["5", "c1"]], ["Planner", ["6 iterations, 512 samples, 64 elites, 24 π trajectories", "c1"]], ["Batch", ["256", "c1"]]] } }
    ],
    inputs: [
      { to: "reward", mod: "state", label: "robot trajectory", n: "145 steps", k: 3 },
      { to: "tdmpc", mod: "state", label: "state s", n: "per step", k: 3 }
    ],
    outputs: [{ from: "tdmpc", mod: "action", label: "joint actions", n: "61 DoF", k: 3 }],
    links: [{ from: "reward", to: "tdmpc", kind: "feeds", label: "reward shaping|R_S" }],
    callouts: [
      "The stabilizing reward helps most on Walk, Stand, Run, Sit-Hard and Pole; on Stair, Slide and Balance-Hard RoHM's planar training data limit it (§IV-B)."
    ]
  });
})();
