/* Architecture specs, topic D2 (learning from human video). Numbers from the papers and the official code; see sources. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ TCN */
  RB.arch.spec({
    id: "time-contrastive-networks", method: "time-contrastive-networks", name: "TCN", year: 2017,
    figRef: "Sermanet et al. Fig. 8 · §IV · App. D", prov: "",
    lede: "An ImageNet Inception trunk, two conv layers, a spatial soft-argmax and an FC layer map one frame to a 32-d unit vector. A multi-view triplet loss pulls simultaneous views together and pushes nearby moments apart.",
    sources: {
      p1: { kind: "paper", ref: "Sermanet et al. 2018, §IV-A.2 (models)", url: "https://arxiv.org/abs/1704.06888" },
      p2: { kind: "paper", ref: "Sermanet et al. 2018, §III-B and App. B (reward, PILQR)", url: "https://arxiv.org/abs/1704.06888" },
      p3: { kind: "paper", ref: "Sermanet et al. 2018, App. D.2 (joints decoder)", url: "https://arxiv.org/abs/1704.06888" },
      p4: { kind: "paper", ref: "Sermanet et al. 2018, §IV-A.1 (pouring data)", url: "https://arxiv.org/abs/1704.06888" },
      c1: { kind: "code", repo: "tensorflow/models", path: "research/tcn/configs/tcn_default.yml", commit: "57e0752", url: "https://github.com/tensorflow/models/blob/57e0752/research/tcn/configs/tcn_default.yml" },
      c2: { kind: "code", repo: "tensorflow/models", path: "research/tcn/model.py", commit: "57e0752", url: "https://github.com/tensorflow/models/blob/57e0752/research/tcn/model.py" },
      c3: { kind: "code", repo: "tensorflow/models", path: "research/tcn/configs/pouring.yml", commit: "57e0752", url: "https://github.com/tensorflow/models/blob/57e0752/research/tcn/configs/pouring.yml" }
    },
    summary: {
      pattern: ["Visual representation encoder", "p1"],
      params: null,
      vision: ["Inception v3 (ImageNet) up to Mixed_5d; 299 × 299 input", "p1", "c1"],
      backbone: ["2 conv layers (512 ch) → spatial softmax → FC 2,048", "p1", "c1", "c2"],
      head: ["FC → 32-d embedding, L2-normalized", "p1", "c1", "c2"],
      output: ["32-d embedding; used as a reward or decoded to 8 robot joints", "p1", "p2", "p3"],
      attention: "None (convolutions only)",
      cond: "None",
      steps: null, chunk: null, rate: null, latency: null,
      train: ["Multi-view triplet loss, margin 0.2; pouring set: 133 training sequences (~11 min)", "p1", "p4"]
    },
    blueprint: {
      headline: "TCN: time decides what to embed",
      note: "A frozen Inception trunk gives Mixed_5d features. The trained head adds two conv layers, a spatial soft-argmax, a 2,048-unit FC and a 32-unit embedding. For pose imitation a small joints decoder reads that embedding; for RL the embedding distance to a human demo is the reward.",
      towers: [
        { mod: "inception", title: "Inception v3", sub: "ImageNet weights", compact: true,
          input: { label: "Image 299 × 299", caption: "one frame, any viewpoint" },
          rows: [
            { t: "conv", label: "Inception stem", call: ["ImageNet-pretrained", "p1"] },
            { t: "conv", label: "Mixed_5b → Mixed_5d", call: ["Not fine-tuned in the released config", "c1", "c2"] } ],
          output: { label: "Mixed_5d feature map" } },
        { mod: "tcn", title: "TCN head", sub: "the trained adaptation layers",
          input: { label: "Mixed_5d features", caption: "from the Inception trunk" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "conv", label: "Conv 3×3 · BN · ReLU", call: ["512 filters, stride 1", "c1", "c2"] }] },
            { t: "pool", label: "Spatial softmax", call: ["(x, y) per channel: 2 × 512 = 1,024", "c2"],
              zoom: { k: "rows", title: "Spatial soft-argmax", rows: ["512 feature maps", "softmax over pixels, per map", "expected (x, y) per map", "1,024 keypoint coordinates"] } },
            { t: "mlp", label: "FC · BN · ReLU", call: ["2,048 units", "c1", "c2"] },
            { id: "emb", t: "linear", label: "Embedding FC", call: ["32 units, no activation", "p1", "c2"],
              zoom: { k: "rows", title: "Imitation reward (PILQR)", rows: ["robot frame → wₜ", "human demo frame → vₜ", "d = ‖wₜ − vₜ‖²", "R = −α·d − β·√(γ + d)"] } },
            { t: "norm", label: "L2 normalize", call: ["Unit-length embedding", "c1", "c2"],
              zoom: { k: "rows", title: "Multi-view triplet loss", rows: ["anchor: view 1 at time t", "positive: view 2 at time t", "negative: view 1 at t′ ≠ t", "‖a − p‖² + 0.2 < ‖a − n‖²"] } } ],
          output: { label: "32-d TCN embedding" } },
        { mod: "joints", title: "Joints decoder", sub: "pose imitation only", compact: true,
          input: { label: "32-d embedding", caption: "trained by self-regression" },
          rows: [
            { t: "mlp", label: "FC layer", call: ["32 → 128", "p3"] },
            { t: "linear", label: "FC → joint values", call: ["128 → 8 joints, L2 loss", "p3"] } ],
          output: { label: "8 robot joint targets" } }
      ],
      links: [
        { from: "inception", to: "tcn", toRow: "input", label: "Mixed_5d" },
        { from: "tcn", to: "joints", toRow: "input", label: "embedding" }
      ]
    },
    modules: [
      { id: "inception", role: "vision-enc", name: "Inception v3", sub: "to Mixed_5d · ImageNet", col: 0, frozen: true, short: "Inception",
        note: "The paper says the trunk is initialized from ImageNet; the released configs do not fine-tune it.",
        stack: { rows: [
          { t: "in", label: "RGB frame 299 × 299", dims: "single view at test time", c: "data-1" },
          { t: "conv", label: "Inception v3 stem and Mixed_5b–5d", dims: "ImageNet checkpoint" },
          { t: "out", label: "Mixed_5d feature map", dims: "input to the TCN head", c: "data-1" } ],
          facts: [["Init", ["ImageNet (Inception v3 checkpoint)", "p1", "c1"]], ["Cut layer", ["Mixed_5d", "p1", "c1"]], ["Fine-tuned", ["no (finetune: false)", "c1", "c3"]], ["Input", ["299 × 299", "c1"]]] } },
      { id: "tcn", role: "vision-enc", roleLabel: "Embedding head", name: "TCN head", sub: "2 conv · SSM · FC → 32", col: 1, frozen: false, main: true, short: "TCN head",
        stack: { rows: [
          { t: "in", label: "Mixed_5d features", c: "data-1" },
          { t: "block", label: "Adaptation conv", n: "2", rows: [{ t: "conv", label: "Conv 3×3, 512 filters · BatchNorm · ReLU" }] },
          { t: "pool", label: "Spatial softmax", dims: "2 × 512 = 1,024 coordinates" },
          { t: "mlp", label: "FC 2,048 · BatchNorm · ReLU" },
          { t: "linear", label: "FC → 32, no activation" },
          { t: "norm", label: "L2 normalize" },
          { t: "out", label: "32-d embedding", dims: "triplet, npairs or lifted-structure loss", c: "data-7" } ],
          facts: [["Embedding", ["32-d, unit length", "p1", "c1"]], ["Conv sizes", ["512, 512", "c1"]], ["FC hidden", ["2,048", "c1"]], ["Triplet margin", ["0.2", "p1", "c1"]], ["Weight decay", ["L2 1e-6", "c1"]], ["Batch", ["36 (default), 32 (pouring)", "c1", "c3"]]] } },
      { id: "joints", role: "action-head", roleLabel: "Joints decoder", name: "Joints decoder", sub: "FC 128 → 8 joints", col: 2, frozen: false, short: "Joints",
        stack: { rows: [
          { t: "in", label: "32-d TCN embedding", c: "data-7" },
          { t: "mlp", label: "FC → 128" },
          { t: "linear", label: "FC → 8 joint values" },
          { t: "out", label: "robot joint vector", dims: "L2 regression", c: "data-3" } ],
          facts: [["Layers", ["2 FC: → 128 → 8", "p3"]], ["Supervision", ["self-regression, human labels, or both", "p3"]]] } }
    ],
    inputs: [{ to: "inception", mod: "vision", label: "one frame", n: "299 × 299", k: 4 }],
    outputs: [
      { from: "tcn", mod: "latent", label: "32-d embedding", n: "reward for PILQR", k: 3 },
      { from: "joints", mod: "action", label: "robot joints", n: "8 values", k: 3 }
    ],
    links: [
      { from: "inception", to: "tcn", kind: "feeds", label: "Mixed_5d features" },
      { from: "tcn", to: "joints", kind: "feeds", label: "32-d embedding|self-regression" }
    ],
    callouts: [
      "The released <code>pouring.yml</code> trains with the <b>npairs</b> loss at learning rate 1e-4; the paper's headline model uses the <b>triplet</b> loss with margin 0.2 (Table I).",
      "Paper §IV-A.2 says the Inception trunk is initialized from ImageNet; the released configs keep it frozen (<code>finetune: false</code>).",
      "For RL, the 32-d embedding joins joint angles and velocities in the PILQR state (App. B).",
      "Code: the TCN release lives in <code>tensorflow/models</code> v1.13.0 (<code>research/tcn</code>); later releases removed it."
    ]
  });

  /* ------------------------------------------------------------------ R3M */
  RB.arch.spec({
    id: "r3m", method: "r3m", name: "R3M", year: 2022,
    figRef: "Nair et al. Fig. 2 · §3.3 · App. A", prov: "",
    lede: "A ResNet-50 trained on Ego4D with time-contrastive learning, a language-alignment head and L1/L2 penalties, then frozen. A tiny BatchNorm + MLP policy reads its 2,048-d vector plus proprioception.",
    sources: {
      p1: { kind: "paper", ref: "Nair et al. 2022, §3.3 (objective, Eqs. 1–3)", url: "https://arxiv.org/abs/2203.12601" },
      p2: { kind: "paper", ref: "Nair et al. 2022, App. A.2–A.3 (architecture, hyperparameters)", url: "https://arxiv.org/abs/2203.12601" },
      p3: { kind: "paper", ref: "Nair et al. 2022, §4.1 and App. B.5 (BC policy)", url: "https://arxiv.org/abs/2203.12601" },
      c1: { kind: "code", repo: "facebookresearch/r3m", path: "r3m/models/models_r3m.py", commit: "b2334e7", url: "https://github.com/facebookresearch/r3m/blob/b2334e7/r3m/models/models_r3m.py" },
      c2: { kind: "code", repo: "facebookresearch/r3m", path: "r3m/models/models_language.py", commit: "b2334e7", url: "https://github.com/facebookresearch/r3m/blob/b2334e7/r3m/models/models_language.py" },
      c3: { kind: "code", repo: "facebookresearch/r3m", path: "r3m/cfgs/config_rep.yaml", commit: "b2334e7", url: "https://github.com/facebookresearch/r3m/blob/b2334e7/r3m/cfgs/config_rep.yaml" }
    },
    summary: {
      pattern: ["Visual representation encoder", "p1"],
      params: null,
      vision: ["ResNet-50 (torchvision), 224 × 224, fc removed → 2,048-d", "p2", "c1"],
      backbone: "None: a frozen encoder plus a small policy MLP",
      head: ["Pretraining only: 5-layer MLP Gθ scores (I₀, Iⱼ, ℓ)", "p2", "c2"],
      output: ["z = Fφ(I), 2,048-d, frozen for downstream use", "p3", "c1"],
      attention: "None (convolutions only)",
      cond: ["Language used only in pretraining: DistilBERT 768-d sentence vector", "p2", "c2"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["Ego4D clips; batch 16 clips × 5 frames, lr 1e-4, 1.5M steps (released models)", "p2"]
    },
    blueprint: {
      headline: "R3M: ResNet-50 taught by time and words",
      note: "Only the ResNet-50 survives pretraining. The language head Gθ exists to shape it and is discarded. Downstream the encoder is frozen and a BatchNorm + two-layer MLP maps [z ‖ proprio] to an action.",
      towers: [
        { mod: "resnet", title: "ResNet-50 Fφ", sub: "the pretrained representation",
          input: { label: "Image 224 × 224", caption: "Ego4D frame, crop shared per clip" },
          rows: [
            { t: "conv", label: "Conv 7×7 /2 · BN · ReLU" },
            { t: "block", n: "4", rows: [{ t: "conv", label: "Bottleneck stage" }] },
            { t: "pool", label: "Global average pool",
              zoom: { k: "rows", title: "Full objective (Eq. 3)", rows: ["λ₁ = 1 · time-contrastive", "λ₂ = 1 · language alignment", "λ₃ = 1e-5 · ‖z‖₁", "λ₄ = 1e-5 · ‖z‖₂"] } },
            { t: "linear", label: "fc = Identity", call: ["z ∈ ℝ²⁰⁴⁸, no projection", "c1"],
              zoom: { k: "rows", title: "Time-contrastive InfoNCE", rows: ["frames Iᵢ < Iⱼ < Iₖ from one clip", "similarity S = −‖z − z′‖₂", "pull (zᵢ, zⱼ), push (zᵢ, zₖ)", "+ 3 negatives from other clips"] } } ],
          output: { label: "z = Fφ(I), 2,048-d" } },
        { mod: "policy", title: "BC policy", sub: "downstream, encoder frozen", compact: true,
          input: { label: "[z ‖ proprio pₜ]", caption: "no gradient into Fφ" },
          rows: [
            { t: "norm", label: "BatchNorm on input", call: ["Before the MLP", "p3"] },
            { t: "block", n: "2", rows: [{ t: "mlp", label: "Hidden layer", call: ["256 units each", "p3"] }] },
            { t: "linear", label: "Linear → action aₜ", call: ["MSE BC, 20,000 steps", "p3"] } ],
          output: { label: "action aₜ" } },
        { mod: "lang", title: "Language head Gθ", sub: "pretraining only", compact: true,
          input: { label: "[z₀ ‖ zⱼ ‖ ℓ]", caption: "2 × 2,048 + 768 = 4,864" },
          rows: [
            { t: "embed", label: "DistilBERT (frozen)", call: ["768-d, mean over tokens", "c2"] },
            { t: "block", n: "4", rows: [{ t: "mlp", label: "Linear · ReLU", call: ["Width 1,024", "p2", "c2"] }] },
            { t: "linear", label: "Linear → score", call: ["One scalar per (z₀, zⱼ, ℓ)", "p2", "c2"],
              zoom: { k: "rows", title: "Video–language alignment", rows: ["I₀ and later Iⱼ from one clip", "score should rise over time", "and beat mismatched clips", "InfoNCE, 3 negatives"] } } ],
          output: { label: "progress score" } }
      ],
      links: [{ from: "resnet", to: "policy", toRow: "input", label: "frozen z" }]
    },
    modules: [
      { id: "lang", role: "critic", roleLabel: "Language score head", name: "Gθ language head", sub: "5-layer MLP · 1,024", col: 0, frozen: false, short: "Gθ",
        note: "Used only to shape the representation during pretraining.",
        stack: { rows: [
          { t: "in", label: "[z₀ ‖ zⱼ ‖ DistilBERT(ℓ)]", dims: "2 × 2,048 + 768", c: "data-2" },
          { t: "block", label: "MLP", n: "4", rows: [{ t: "mlp", label: "Linear → 1,024 · ReLU" }] },
          { t: "linear", label: "Linear → 1" },
          { t: "out", label: "score", dims: "contrastive loss", c: "data-8" } ],
          facts: [["Sizes", ["[2E + L, 1,024, 1,024, 1,024, 1,024] → 1", "p2", "c2"]], ["Sentence encoder", ["DistilBERT, 768-d, frozen", "p2", "c2"]]] } },
      { id: "resnet", role: "vision-enc", name: "ResNet-50 Fφ", sub: "fc removed · 2,048-d", col: 1, frozen: false, main: true, short: "ResNet-50",
        note: "Trained during pretraining, frozen for every downstream task.",
        stack: { rows: [
          { t: "in", label: "RGB 224 × 224", dims: "ImageNet mean/std normalization", c: "data-1" },
          { t: "conv", label: "torchvision ResNet-50 (random init)" },
          { t: "pool", label: "Global average pool" },
          { t: "linear", label: "fc = Identity" },
          { t: "out", label: "z ∈ ℝ²⁰⁴⁸", c: "data-7" } ],
          facts: [["Variants released", ["ResNet-18, 34, 50", "p1"]], ["Output", ["2,048-d (ResNet-50)", "c1"]], ["Distance", ["negative L2", "p1", "c1"]], ["Negatives", ["3 per example", "p2", "c1"]], ["Loss weights", ["1, 1, 1e-5, 1e-5", "p2"]]] } },
      { id: "policy", role: "action-head", name: "BC policy MLP", sub: "BatchNorm · 256 · 256", col: 2, frozen: false, short: "Policy",
        stack: { rows: [
          { t: "in", label: "[z ‖ proprioception]", c: "data-5" },
          { t: "norm", label: "BatchNorm" },
          { t: "mlp", label: "MLP [256, 256]" },
          { t: "out", label: "action", c: "data-3" } ],
          facts: [["Hidden", ["[256, 256]", "p3"]], ["Training", ["lr 0.001, batch 32, 20,000 steps", "p3"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "video frames", n: "224 × 224", k: 5 },
      { to: "lang", mod: "lang", label: "narration ℓ", n: "DistilBERT", k: 3 },
      { to: "policy", mod: "state", label: "proprioception", n: "joints / EE", k: 2 }
    ],
    outputs: [
      { from: "lang", mod: "other", label: "progress score", n: "scalar", k: 1 },
      { from: "policy", mod: "action", label: "action aₜ", n: "BC", k: 3 }
    ],
    links: [
      { from: "resnet", to: "lang", kind: "feeds", label: "z₀ ‖ zⱼ|pretraining only" },
      { from: "resnet", to: "policy", kind: "feeds", label: "frozen z|‖ proprio" }
    ],
    callouts: [
      "The default training config (<code>config_rep.yaml</code>) builds ResNet-34 with batch 32 and language weight 0; the paper's released models use ResNet-50, batches of 16 clips and λ₂ = 1 (App. A.2).",
      "Downstream the encoder is <b>frozen</b>; only the BatchNorm + MLP policy trains (§4.1)."
    ]
  });

  /* ------------------------------------------------------------------ VIP */
  RB.arch.spec({
    id: "vip", method: "vip", name: "VIP", year: 2022, parent: "r3m",
    diffRows: ["vision", "head", "output", "cond", "train"],
    figRef: "Ma et al. Alg. 1 · §4.3 · App. D", prov: "",
    lede: "R3M's ResNet-50 with a 1,024-d FC, trained on Ego4D by a goal-conditioned value objective that needs no actions. The value is the negative embedding distance, so the same encoder also yields a dense reward toward a goal image.",
    sources: {
      p1: { kind: "paper", ref: "Ma et al. 2023, §4.3 (Eq. 6, Alg. 1)", url: "https://arxiv.org/abs/2210.00030" },
      p2: { kind: "paper", ref: "Ma et al. 2023, App. D (Table 2)", url: "https://arxiv.org/abs/2210.00030" },
      p3: { kind: "paper", ref: "Ma et al. 2023, §3 (Eq. 1, reward)", url: "https://arxiv.org/abs/2210.00030" },
      p4: { kind: "paper", ref: "Ma et al. 2023, §5.2 and App. E (MPPI, NPG, RWR)", url: "https://arxiv.org/abs/2210.00030" },
      c1: { kind: "code", repo: "facebookresearch/vip", path: "vip/models/model_vip.py", commit: "81b0520", url: "https://github.com/facebookresearch/vip/blob/81b0520/vip/models/model_vip.py" },
      c2: { kind: "code", repo: "facebookresearch/vip", path: "vip/cfgs/config_vip_ego4d.yaml", commit: "81b0520", url: "https://github.com/facebookresearch/vip/blob/81b0520/vip/cfgs/config_vip_ego4d.yaml" },
      c3: { kind: "code", repo: "facebookresearch/vip", path: "vip/trainer.py", commit: "81b0520", url: "https://github.com/facebookresearch/vip/blob/81b0520/vip/trainer.py" }
    },
    summary: {
      pattern: ["Visual representation encoder", "p1"],
      params: null,
      vision: ["ResNet-50 → trained FC 2,048 → 1,024; 224 × 224", "p2", "c1", "c2"],
      backbone: "None: the value is a distance, not a network",
      head: ["V(φ(o); φ(g)) = −‖φ(o) − φ(g)‖₂, no parameters", "p1", "c3"],
      output: ["1,024-d embedding and reward R = S(oₜ₊₁; g) − S(oₜ; g)", "p2", "p3"],
      attention: "None (convolutions only)",
      cond: "Goal image g, embedded by the same φ",
      steps: null, chunk: null, rate: null, latency: null,
      train: ["Ego4D, ~4.3M frames; batch 32, lr 1e-4, γ = 0.98, L1 = L2 = 0.001", "p2", "c2"]
    },
    changes: [
      "The language head and DistilBERT are gone: pretraining is fully <b>self-supervised</b>.",
      "A trained <b>FC 2,048 → 1,024</b> sits on top of ResNet-50; R3M uses an identity.",
      "InfoNCE time-contrast is replaced by a <b>dual goal-conditioned value</b> loss with γ = 0.98.",
      "Distance to a goal-image embedding becomes a <b>dense reward</b> for MPPI, NPG or RWR.",
      "Same Ego4D frames, optimizer, learning rate and 3 negatives as R3M."
    ],
    blueprint: {
      headline: "VIP: an encoder whose distance is value",
      note: "One ResNet-50 embeds both the observation and the goal image. Their negative L2 distance is the value; its change over one step is the reward. No value network, no actions.",
      towers: [
        { mod: "phi", title: "ResNet-50 φ", sub: "shared for observation and goal",
          input: { label: "Image 224 × 224", caption: "observation o or goal g" },
          rows: [
            { t: "conv", label: "Conv 7×7 /2 · BN · ReLU" },
            { t: "block", n: "4", rows: [{ t: "conv", label: "Bottleneck stage" }] },
            { t: "pool", label: "Global average pool" },
            { t: "linear", label: "FC 2,048 → 1,024", call: ["Trained layer (R3M: identity)", "p2", "c1"],
              zoom: { k: "rows", title: "VIP objective (Alg. 1)", rows: ["sub-clip: start oₜ, goal = last", "(1 − γ)·‖φ(oₜ) − φ(g)‖", "+ log mean exp(TD residual)", "γ = 0.98, 3 extra negatives"] } } ],
          output: { label: "φ(o), 1,024-d" } },
        { mod: "value", title: "Implicit value", sub: "no weights", compact: true,
          input: { label: "φ(o), φ(g)", caption: "same encoder for both" },
          rows: [
            { t: "linear", label: "d = ‖φ(o) − φ(g)‖₂", call: ["L2 distance", "p1"] },
            { t: "linear", label: "V = −d", call: ["The goal-conditioned value", "p1"] },
            { t: "linear", label: "R = V(oₜ₊₁) − V(oₜ)", call: ["Dense reward toward g", "p3"],
              zoom: { k: "rows", title: "Where the reward is used", rows: ["MPPI trajectory optimization", "NPG online RL", "RWR offline RL, ~20 demos", "weights exp(τ·R) per transition"] } } ],
          output: { label: "reward for any goal image" } }
      ],
      links: [{ from: "phi", to: "value", toRow: "input", label: "embeddings" }]
    },
    modules: [
      { id: "phi", role: "vision-enc", name: "ResNet-50 φ", sub: "FC 2,048 → 1,024", col: 0, frozen: false, main: true, short: "ResNet-50",
        stack: { rows: [
          { t: "in", label: "RGB 224 × 224", dims: "resize 256, center crop", c: "data-1" },
          { t: "conv", label: "torchvision ResNet-50 (random init)" },
          { t: "pool", label: "Global average pool" },
          { t: "linear", label: "FC 2,048 → 1,024" },
          { t: "out", label: "φ(o) ∈ ℝ¹⁰²⁴", c: "data-7" } ],
          facts: [["Output", ["1,024-d", "p2", "c1", "c2"]], ["Weight penalties", ["L1 0.001, L2 0.001", "p2", "c2"]], ["Discount", ["γ = 0.98", "p2", "c1"]], ["Negatives", ["3", "p2", "c2"]], ["Batch / lr", ["32 / 1e-4", "p2", "c2"]]] } },
      { id: "value", role: "critic", roleLabel: "Implicit value", name: "Embedding distance", sub: "V = −‖φ(o) − φ(g)‖₂", col: 1, frozen: false, short: "Value",
        note: "Not a network: the value is defined by the encoder." },
      { id: "ctrl", role: "action-head", name: "Downstream policy", sub: "MPPI · NPG · RWR", col: 2, frozen: false, short: "Policy",
        note: "The controller is the downstream method's own; VIP supplies its state embedding and reward." }
    ],
    inputs: [{ to: "phi", mod: "vision", label: "observation + goal", n: "224 × 224", k: 4 }],
    outputs: [
      { from: "value", mod: "other", label: "reward R", n: "per transition", k: 2 },
      { from: "ctrl", mod: "action", label: "actions", n: "robot", k: 3 }
    ],
    links: [
      { from: "phi", to: "value", kind: "feeds", label: "φ(o), φ(g)" },
      { from: "value", to: "ctrl", kind: "feeds", label: "dense reward" }
    ],
    callouts: [
      "Paper Table 2 lists \"L1 weight penalty 0.001\" twice; the Ego4D config sets both <code>l1weight</code> and <code>l2weight</code> to 0.001, so one row is the L2 penalty.",
      "VIP uses the exact Ego4D subset and optimizer settings of R3M (App. D), so the two differ only in objective and the FC layer."
    ]
  });

  /* ------------------------------------------------------------------ MVP */
  RB.arch.spec({
    id: "mvp", method: "mvp", name: "MVP", year: 2022,
    figRef: "Xiao et al. Fig. 2 · §4", prov: "",
    lede: "A ViT-S/16 pretrained as a masked autoencoder on in-the-wild hand–object frames, then frozen. Its CLS feature and the proprioception are each projected to 128-d and a small SELU MLP actor-critic learns control with PPO.",
    sources: {
      p1: { kind: "paper", ref: "Xiao et al. 2022, §4 (Encoder, Controller, RL)", url: "https://arxiv.org/abs/2203.06173" },
      p2: { kind: "paper", ref: "Xiao et al. 2022, §3.4 (observations and actions)", url: "https://arxiv.org/abs/2203.06173" },
      p3: { kind: "paper", ref: "Xiao et al. 2022, §2.1 and §4 (MAE pretraining)", url: "https://arxiv.org/abs/2203.06173" },
      c1: { kind: "code", repo: "ir413/mvp", path: "mvp/backbones/vit.py", commit: "5746656", url: "https://github.com/ir413/mvp/blob/5746656/mvp/backbones/vit.py" },
      c2: { kind: "code", repo: "ir413/mvp", path: "mvp/ppo/actor_critic.py", commit: "5746656", url: "https://github.com/ir413/mvp/blob/5746656/mvp/ppo/actor_critic.py" },
      c3: { kind: "code", repo: "ir413/mvp", path: "configs/ppo/train/FrankaPickPixels.yaml", commit: "5746656", url: "https://github.com/ir413/mvp/blob/5746656/configs/ppo/train/FrankaPickPixels.yaml" }
    },
    summary: {
      pattern: ["Visual representation encoder", "p1"],
      params: null,
      vision: ["ViT-S/16 MAE, 224 × 224 wrist image, frozen; CLS token", "p1", "c1", "c2"],
      backbone: ["12 blocks, width 384, MLP ratio 4", "p1", "c1"],
      head: ["Actor MLP [256, 128, 64] with SELU; separate critic (PPO)", "p1", "c3"],
      output: ["Δ joint angles, Gaussian policy", "p1", "c2"],
      attention: ["Bidirectional ViT; 6 heads in the paper, 12 in the code", "p1", "c1"],
      cond: ["[CLS → 128 ‖ proprio → 128]", "p1", "c2"],
      steps: null, chunk: null,
      rate: ["60 Hz joint position control", "p2"],
      latency: null,
      train: ["MAE on ~700K HOI frames, 1,600 epochs; PPO with 256 environments", "p1"]
    },
    blueprint: {
      headline: "MVP: frozen MAE eyes, tiny RL brain",
      note: "All patches pass through the frozen ViT (no masking at control time). Only the two 128-d projections, the actor and the critic train with PPO.",
      towers: [
        { mod: "vit", title: "ViT-S/16", sub: "MAE-pretrained, frozen",
          input: { label: "Image patches 16 × 16", caption: "wrist camera 224 × 224" },
          rows: [
            { t: "embed", label: "Patch embedding + CLS", call: ["196 patches + CLS, width 384", "p1", "c1"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["12 heads in code (paper: 6)", "c1", "p1"], zoom: { k: "heads", q: 12, kv: 12, hd: 32, title: "Attention heads (code)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden 1,536 (ratio 4)", "p1", "c1"], zoom: { k: "mlp", act: "GELU", d: "384", ff: "1,536", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm", call: ["Applied to the CLS token", "c1", "c2"] } ],
          output: { label: "CLS feature, 384-d, no gradient" } },
        { mod: "ctrl", title: "Actor-critic", sub: "trained with PPO", compact: true,
          input: { label: "CLS + joint pos / vel", caption: "two linear projections" },
          rows: [
            { id: "iproj", t: "linear", label: "Image proj 384 → 128", call: ["Linear on CLS", "p1", "c2"] },
            { t: "linear", label: "Proprio proj → 128", call: ["Joint positions + velocities", "p1", "c2"] },
            { t: "block", n: "3", rows: [{ t: "mlp", label: "Linear · SELU", call: ["256 → 128 → 64", "p1", "c3"] }] },
            { t: "linear", label: "Linear → Δ joint mean", call: ["Gaussian, initial std 1.0", "p1", "c3"],
              zoom: { k: "rows", title: "PPO loop", rows: ["256 envs × 32 steps", "10 epochs × 4 minibatches", "minibatch 2,048", "critic: same MLP, own weights"] } } ],
          output: { label: "Δ joint angles, 60 Hz" } }
      ],
      links: [{ from: "vit", to: "ctrl", toRow: "iproj", label: "CLS" }]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "ViT-S/16 (MAE)", sub: "12 × 384 · frozen", col: 0, frozen: true, main: true, short: "ViT-S",
        stack: { rows: [
          { t: "in", label: "wrist image 224 × 224", c: "data-1" },
          { t: "embed", label: "Patch 16 × 16 + CLS + position", dims: "197 × 384" },
          { t: "block", label: "ViT block (pre-norm)", n: "12", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · bidirectional · qkv bias" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 384 → 1,536 → 384" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "LayerNorm on CLS" },
          { t: "out", label: "CLS feature", c: "data-1" } ],
          facts: [["Width / depth", ["384 / 12", "p1", "c1"]], ["Heads", ["6 (paper) · 12 (code)", "p1", "c1"]], ["Patch", ["16 × 16", "p1", "c1"]], ["FLOPs", ["4.6 GFLOPs at 224 × 224", "p1"]]] } },
      { id: "ctrl", role: "action-head", roleLabel: "Actor-critic", name: "Actor-critic MLPs", sub: "256 · 128 · 64 · SELU", col: 1, frozen: false, short: "Controller",
        stack: { rows: [
          { t: "in", label: "[CLS → 128 ‖ proprio → 128]", c: "data-5" },
          { t: "mlp", label: "Linear 256 · SELU" }, { t: "mlp", label: "Linear 128 · SELU" }, { t: "mlp", label: "Linear 64 · SELU" },
          { t: "linear", label: "Linear → action mean (critic: → 1)" },
          { t: "out", label: "Δ joint angles", c: "data-3" } ],
          facts: [["Actor / critic", ["[256, 128, 64], no weight sharing", "p1", "c3"]], ["Activation", ["SELU", "p1", "c2"]], ["Embedding", ["128 each for image and state", "p1", "c3"]], ["PPO clip", ["0.1", "c3"]]] } }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "wrist image", n: "224 × 224", k: 5 },
      { to: "ctrl", mod: "state", label: "joint pos + vel", n: "→ 128", k: 2 }
    ],
    outputs: [{ from: "ctrl", mod: "action", label: "Δ joint angles", n: "60 Hz", k: 3 }],
    links: [{ from: "vit", to: "ctrl", kind: "feeds", label: "CLS → Linear 128" }],
    callouts: [
      "Paper §4 specifies ViT-Small with <b>6 heads</b>; the released <code>vit_s16</code> builds it with <b>12 heads</b> (head dim 32).",
      "Fine-tuning the ViT end to end with RL gave zero success on FrankaPick (§5), so the encoder stays frozen."
    ]
  });

  /* ------------------------------------------------------------------ VC-1 */
  RB.arch.spec({
    id: "vc-1", method: "vc-1", name: "VC-1", year: 2023, parent: "mvp",
    diffRows: ["params", "vision", "backbone", "head", "attention", "train"],
    figRef: "Majumdar et al. §5–6 · App. A.5", prov: "",
    lede: "MVP's recipe scaled up: a ViT-L/16 (307M) masked autoencoder trained on 5.6M egocentric, navigation and ImageNet frames. Its CLS token feeds each benchmark's own policy, frozen or adapted.",
    sources: {
      p1: { kind: "paper", ref: "Majumdar et al. 2023, §5 (scaling, Tables 3–4)", url: "https://arxiv.org/abs/2303.18240" },
      p2: { kind: "paper", ref: "Majumdar et al. 2023, §6 (adaptation, Table 5)", url: "https://arxiv.org/abs/2303.18240" },
      p3: { kind: "paper", ref: "Majumdar et al. 2023, App. A.5 (Tables 6–7)", url: "https://arxiv.org/abs/2303.18240" },
      c1: { kind: "code", repo: "facebookresearch/eai-vc", path: "vc_models/src/vc_models/models/vit/vit.py", commit: "76fe35e", url: "https://github.com/facebookresearch/eai-vc/blob/76fe35e/vc_models/src/vc_models/models/vit/vit.py" },
      c2: { kind: "code", repo: "facebookresearch/eai-vc", path: "vc_models/src/vc_models/conf/model/vc1_vitl.yaml", commit: "76fe35e", url: "https://github.com/facebookresearch/eai-vc/blob/76fe35e/vc_models/src/vc_models/conf/model/vc1_vitl.yaml" },
      c3: { kind: "code", repo: "facebookresearch/eai-vc", path: "vc_models/src/vc_models/transforms/__init__.py", commit: "76fe35e", url: "https://github.com/facebookresearch/eai-vc/blob/76fe35e/vc_models/src/vc_models/transforms/__init__.py" }
    },
    summary: {
      pattern: ["Visual representation encoder", "p1"],
      params: ["307M (ViT-L); ViT-B variant 86M", "p1"],
      vision: ["ViT-L/16 MAE; resize 256, crop 224 × 224", "c1", "c2", "c3"],
      backbone: ["24 blocks, width 1,024, 16 heads, MLP ratio 4", "c1"],
      head: "Each benchmark's own policy (CortexBench protocol)",
      output: ["CLS token after the final LayerNorm, 1,024-d", "c1", "c2"],
      attention: "Bidirectional ViT self-attention",
      cond: "None",
      steps: null, chunk: null, rate: null, latency: null,
      train: ["MAE on Ego4D+MNI, 5,621,987 frames, 182 epochs; >10,000 GPU-hours for all models", "p1", "p3", "c2"]
    },
    changes: [
      "Encoder grows from ViT-S/16 (384-d, 12 blocks) to <b>ViT-L/16</b> (1,024-d, 24 blocks, 307M).",
      "Pretraining data grows from ~700K HOI frames to <b>5.6M frames</b>: Ego4D, manipulation, navigation and ImageNet.",
      "Evaluated frozen on 17 CortexBench tasks (IL and RL, arms, hands, navigation), not only PixMC PPO.",
      "Adds <b>adaptation</b>: continued MAE on task frames, or end-to-end fine-tuning."
    ],
    blueprint: {
      headline: "VC-1: one big MAE ViT for every task",
      note: "The ViT-L runs on all 196 patches and returns its normalized CLS token. Each benchmark then trains its own policy; the encoder is frozen by default, MAE-adapted for few-shot IL, or fine-tuned end to end for large IL/RL.",
      towers: [
        { mod: "vit", title: "ViT-L/16", sub: "MAE on Ego4D+MNI",
          input: { label: "Image patches 16 × 16", caption: "RGB 224 × 224" },
          rows: [
            { t: "embed", label: "Patch embedding + CLS", call: ["196 patches + CLS, width 1,024", "c1", "c2"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["16 heads, head dim 64", "c1"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden 4,096 (ratio 4)", "c1"], zoom: { k: "mlp", act: "GELU", d: "1,024", ff: "4,096", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm", call: ["Then take the CLS token", "c1"],
              zoom: { k: "rows", title: "Pretraining mix (Table 6)", rows: ["Ego4D: 2,790,520 frames", "+ 100DOH, SS-v2, Epic Kitchens", "+ OpenHouse24, RealEstate10K", "+ ImageNet: 1,281,167"] } } ],
          output: { label: "CLS token, 1,024-d" } },
        { mod: "policy", title: "Task policy", sub: "per benchmark", compact: true,
          input: { label: "VC-1 embedding", caption: "+ proprio or goal, per task" },
          rows: [
            { t: "linear", label: "Frozen VC-1 (default)", call: ["Mean success 68.7", "p1"] },
            { t: "linear", label: "or MAE adaptation", call: ["100 epochs on task frames", "p2"] },
            { t: "linear", label: "or end-to-end fine-tune", call: ["Helps large-scale IL and RL", "p2"] },
            { t: "mlp", label: "Benchmark policy" } ],
          output: { label: "actions" } }
      ],
      links: [{ from: "vit", to: "policy", toRow: "input", label: "CLS" }]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "ViT-L/16 (MAE)", sub: "24 × 1024 · 16 heads", col: 0, frozen: true, main: true, params: "307M", short: "ViT-L",
        stack: { rows: [
          { t: "in", label: "RGB 224 × 224", dims: "bicubic resize 256, crop", c: "data-1" },
          { t: "embed", label: "Patch 16 × 16 + position; CLS appended", dims: "197 × 1,024" },
          { t: "block", label: "ViT block (pre-norm)", n: "24", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 16 heads · qkv bias" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 1,024 → 4,096 → 1,024" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final LayerNorm" },
          { t: "out", label: "CLS token", dims: "1,024-d", c: "data-1" } ],
          facts: [["Width / depth / heads", ["1,024 / 24 / 16", "c1"]], ["Params", ["307M", "p1"]], ["Pretraining", ["MAE, 182 epochs", "p3", "c2"]], ["Frames", ["5,621,987", "p1", "p3"]], ["Feature", ["CLS token (use_cls: True)", "c2"]]] } },
      { id: "policy", role: "action-head", name: "Task policy", sub: "per benchmark", col: 1, frozen: false, short: "Policy",
        note: "Each CortexBench task keeps its standard policy and training protocol." }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "RGB frame", n: "224 × 224", k: 5 },
      { to: "policy", mod: "state", label: "proprio / goal", n: "task-dependent", k: 2 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "actions", n: "IL or RL", k: 3 }],
    links: [{ from: "vit", to: "policy", kind: "feeds", label: "CLS, 1,024-d" }],
    callouts: [
      "End-to-end fine-tuning lifts ObjectNav, ImageNav and Mobile Pick but collapses few-shot IL (Adroit 59.3 → 15.9); MAE adaptation helps those instead (Table 5).",
      "The VC-1 paper notes that MVP differs from it mainly by a convolutional stem (§5.3)."
    ]
  });

  /* ------------------------------------------------------------------ LAPA */
  RB.arch.spec({
    id: "lapa", method: "lapa", name: "LAPA", year: 2024,
    figRef: "Ye et al. Figs. 2, 8 · §3 · App. A", prov: "",
    lede: "A ~300M quantizer turns the change between two frames into 4 discrete latent tokens. A 7B LWM is then trained to predict those tokens from image and instruction, and finally finetuned to output real robot actions.",
    sources: {
      p1: { kind: "paper", ref: "Ye et al. 2025, §3.1–3.3", url: "https://arxiv.org/abs/2410.11758" },
      p2: { kind: "paper", ref: "Ye et al. 2025, App. A (Fig. 8, Eqs. 1–4)", url: "https://arxiv.org/abs/2410.11758" },
      p3: { kind: "paper", ref: "Ye et al. 2025, §4.2, §5.1 and App. F", url: "https://arxiv.org/abs/2410.11758" },
      c1: { kind: "code", repo: "LatentActionPretraining/LAPA", path: "laq/train_sthv2.py", commit: "46aca51", url: "https://github.com/LatentActionPretraining/LAPA/blob/46aca51/laq/train_sthv2.py" },
      c2: { kind: "code", repo: "LatentActionPretraining/LAPA", path: "laq/laq_model/latent_action_quantization.py", commit: "46aca51", url: "https://github.com/LatentActionPretraining/LAPA/blob/46aca51/laq/laq_model/latent_action_quantization.py" },
      c3: { kind: "code", repo: "LatentActionPretraining/LAPA", path: "laq/laq_model/nsvq.py", commit: "46aca51", url: "https://github.com/LatentActionPretraining/LAPA/blob/46aca51/laq/laq_model/nsvq.py" },
      c4: { kind: "code", repo: "LatentActionPretraining/LAPA", path: "laq/laq_model/attention.py", commit: "46aca51", url: "https://github.com/LatentActionPretraining/LAPA/blob/46aca51/laq/laq_model/attention.py" },
      c5: { kind: "code", repo: "LatentActionPretraining/LAPA", path: "latent_pretraining/llama.py", commit: "46aca51", url: "https://github.com/LatentActionPretraining/LAPA/blob/46aca51/latent_pretraining/llama.py" },
      c6: { kind: "code", repo: "LatentActionPretraining/LAPA", path: "scripts/latent_pretrain_openx.sh", commit: "46aca51", url: "https://github.com/LatentActionPretraining/LAPA/blob/46aca51/scripts/latent_pretrain_openx.sh" },
      c7: { kind: "code", repo: "LatentActionPretraining/LAPA", path: "latent_pretraining/data.py", commit: "46aca51", url: "https://github.com/LatentActionPretraining/LAPA/blob/46aca51/latent_pretraining/data.py" },
      c8: { kind: "code", repo: "LatentActionPretraining/LAPA", path: "scripts/finetune_simpler.sh", commit: "46aca51", url: "https://github.com/LatentActionPretraining/LAPA/blob/46aca51/scripts/finetune_simpler.sh" }
    },
    summary: {
      pattern: ["Latent-action pretraining", "p1"],
      params: ["7B VLM (LWM-Chat-1M) + ~300M latent action quantizer", "p3"],
      vision: ["LWM image tokens: VQGAN, 256 × 256 → 16 × 16 = 256 tokens", "p3", "c7"],
      backbone: ["LLaMA-style 7B: 32 layers, width 4,096, 32 heads, RMSNorm, RoPE", "c5", "c6"],
      head: ["One Dense latent head, vocab 8; replaced by an action head for finetuning", "p1", "c6"],
      output: ["4 latent tokens from an 8-code vocabulary (8⁴ space)", "p3", "c1"],
      attention: ["LLM: causal. Quantizer: spatial + causal temporal transformer", "p1", "p2"],
      cond: "Instruction and current frame as prefix",
      steps: null,
      chunk: ["One latent action per step; frames 0.6 s apart (robot) or 2.4 s (human)", "p3"],
      rate: null, latency: null,
      train: ["Quantizer, then latent pretraining on unlabeled video (Bridge, OXE or SSv2), then action finetuning", "p1"]
    },
    blueprint: {
      headline: "LAPA: tokenize motion, then imitate tokens",
      note: "Stage 1 trains the quantizer: the encoder (inverse dynamics) compresses the change between xₜ and xₜ₊H into 4 tokens, and the decoder rebuilds xₜ₊H from xₜ and those tokens. Stage 2 labels every frame with the encoder and trains the 7B LWM's single latent head on those labels.",
      towers: [
        { mod: "dec", title: "LAQ decoder", sub: "latent forward model", compact: true,
          input: { label: "xₜ patches + z", caption: "stop-gradient on xₜ" },
          rows: [
            { t: "embed", label: "Patch embed xₜ", call: ["Stop-gradient avoids collapse", "p2"] },
            { t: "block", n: "8", rows: [
              { t: "attn", label: "Self-attention" },
              { t: "attn", label: "Cross-attention to z", call: ["Replaces Genie's additive z", "p1", "c2"] } ] },
            { t: "linear", label: "Linear → pixels", call: ["L2 loss on x̂ₜ₊H", "p2"] } ],
          output: { label: "x̂ₜ₊H (a world model)" } },
        { mod: "enc", title: "LAQ encoder", sub: "inverse dynamics, C-ViViT style",
          input: { label: "Frames xₜ, xₜ₊H", caption: "256 × 256 each" },
          rows: [
            { t: "embed", label: "Patch embed 32 × 32 · LN", call: ["8 × 8 = 64 patches, width 1,024", "c1", "c2"] },
            { t: "block", n: "8", label: "spatial", rows: [
              { t: "attn", label: "Self-attention per frame", call: ["16 heads × 64 = 1,024", "c1"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Attention heads" } },
              { t: "ffn", label: "Feed forward (GEGLU)", call: ["Inner 2,730 = ⅔ × 4 × 1,024", "c4"], zoom: { k: "glu", act: "GELU", d: "1,024", ff: "2,730", title: "Feed forward (GEGLU)" } } ] },
            { t: "block", n: "8", label: "temporal", rows: [{ t: "attn", label: "Causal attention in time" }] },
            { t: "conv", label: "Conv s2 → Conv 3×3", call: ["8 × 8 → 4 × 4 → 2 × 2 = 4 tokens", "c3"] },
            { t: "linear", label: "NSVQ on d = eₜ₊H − eₜ", call: ["Codebook of 8 codes, 32-d", "c1", "c3"],
              zoom: { k: "rows", title: "NSVQ quantization", rows: ["eₜ, eₜ₊H after temporal layers", "d = eₜ₊H − eₜ", "nearest code zₖ of 8", "d̂ = d + ‖d − zₖ‖·v/‖v‖"] } } ],
          output: { label: "latent action z: 4 tokens" } },
        { mod: "vlm", title: "LWM-Chat-1M 7B", sub: "vision encoder frozen, LM trained",
          input: { label: "Image tokens + instruction", caption: "VQGAN: 256 tokens per 256 × 256 frame" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["Width 4,096; text vocab 32,000", "c5"] },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["32 heads, head dim 128", "c5"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden 11,008", "c5"], zoom: { k: "glu", act: "SiLU", d: "4,096", ff: "11,008", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { id: "head", t: "linear", label: "Latent action head", call: ["One Dense layer, vocab 8", "p1", "c6"] } ],
          output: { label: "4 latent tokens; after finetuning, action bins" } }
      ],
      links: [{ from: "enc", to: "vlm", toRow: "head", label: "latent labels" }]
    },
    modules: [
      { id: "dec", role: "world", roleLabel: "Latent forward model", name: "LAQ decoder", sub: "8 layers · cross-attn to z", col: 0, frozen: false, short: "Decoder",
        stack: { rows: [
          { t: "in", label: "xₜ patch tokens (stop-grad) + d̂", c: "data-1" },
          { t: "block", label: "Spatial transformer", n: "8", rows: [{ t: "attn", label: "Self-attention" }, { t: "attn", label: "Cross-attention to d̂" }, { t: "ffn", label: "GEGLU feed forward" }] },
          { t: "linear", label: "Linear → 32 × 32 × 3 pixels per patch" },
          { t: "out", label: "x̂ₜ₊H", dims: "L2 reconstruction", c: "data-4" } ],
          facts: [["Depth", ["8 spatial layers", "c1", "c2"]], ["Conditioning", ["cross-attention to the latent", "p1", "p2"]], ["Loss", ["L2 on x̂ₜ₊H", "p2"]]] } },
      { id: "enc", role: "latent", roleLabel: "Latent action encoder", name: "LAQ encoder (IDM)", sub: "8 + 8 × 1024 · NSVQ", col: 1, frozen: false, short: "Encoder",
        stack: { rows: [
          { t: "in", label: "xₜ, xₜ₊H at 256 × 256", c: "data-1" },
          { t: "embed", label: "Patch 32 × 32 → 1,024 (LN, Linear, LN)", dims: "64 patches per frame" },
          { t: "block", label: "Spatial transformer", n: "8", rows: [{ t: "attn", label: "MHA · 16 heads · PEG" }, { t: "ffn", label: "GEGLU 1,024 → 2,730" }] },
          { t: "block", label: "Causal temporal transformer", n: "8", rows: [{ t: "attn", label: "Causal MHA over the 2 frames" }] },
          { t: "linear", label: "Project 1,024 → 32" },
          { t: "conv", label: "2 convs: 8 × 8 → 2 × 2" },
          { t: "linear", label: "NSVQ, 8 codes" },
          { t: "out", label: "4 latent tokens", c: "data-7" } ],
          facts: [["Width / heads", ["1,024 / 16 × 64", "c1"]], ["Depth", ["8 spatial + 8 temporal", "c1"]], ["Codebook", ["8 codes × 32-d", "c1", "c3"]], ["Tokens", ["4 per transition", "p3", "c1"]], ["Size", ["~300M", "p3"]], ["Quantizer", ["NSVQ with codebook replacement", "p1", "c3"]]] } },
      { id: "vlm", role: "vlm", name: "LWM-Chat-1M 7B", sub: "32 × 4096 · VQGAN tokens", col: 2, frozen: "partial", main: true, params: "7B", short: "LWM 7B",
        stack: { rows: [
          { t: "in", label: "[VQGAN image tokens | instruction]", dims: "256 image tokens", c: "data-2" },
          { t: "embed", label: "Token embedding", dims: "→ 4,096" },
          { t: "block", label: "LLaMA decoder block", n: "32", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "Causal MHA · 32 heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 4,096 → 11,008 → 4,096" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "Latent head (Dense, vocab 8)" },
          { t: "out", label: "4 latent tokens", c: "data-7" } ],
          facts: [["Width / depth / heads", ["4,096 / 32 / 32", "c5"]], ["FFN", ["11,008, SwiGLU", "c5"]], ["RoPE θ", ["50,000,000", "c6"]], ["Frozen", ["vision encoder only", "p1"]], ["Pretraining run", ["70,000 steps, batch 256, lr 2e-5 (OXE script)", "c6"]]] } }
    ],
    inputs: [
      { to: "dec", mod: "vision", label: "frame xₜ", n: "stop-gradient", k: 3 },
      { to: "enc", mod: "vision", label: "xₜ and xₜ₊H", n: "256 × 256", k: 4 },
      { to: "vlm", mod: "vision", label: "current frame", n: "VQGAN", k: 4 },
      { to: "vlm", mod: "lang", label: "instruction ℓ", n: "text", k: 3 }
    ],
    outputs: [
      { from: "dec", mod: "future", label: "x̂ₜ₊H", n: "L2 recon", k: 3 },
      { from: "vlm", mod: "latent", label: "latent action z", n: "4 tokens · vocab 8", k: 4 }
    ],
    links: [
      { from: "enc", to: "dec", kind: "cross-attn", label: "d̂ (4 × 32-d)" },
      { from: "enc", to: "vlm", kind: "two-stage", label: "latent labels|pseudo-actions" }
    ],
    callouts: [
      "At finetuning the latent head is discarded and a new head predicts per-dimension action bins (§3.3); the released SIMPLER script sets an action vocabulary of 245.",
      "The quantizer follows Genie's latent action model but feeds the latent to the decoder through <b>cross-attention</b>, not an additive embedding (§3.1).",
      "Only the vision encoder is frozen in latent pretraining; the whole language model trains (§3.2)."
    ]
  });

  /* ------------------------------------------------------------------ MimicPlay */
  RB.arch.spec({
    id: "mimicplay", method: "mimicplay", name: "MimicPlay", year: 2023,
    figRef: "Wang et al. Fig. 2 · §3 · App. F–G", prov: "",
    lede: "A goal-conditioned latent planner, trained on 10 minutes of human play to predict 3-D hand paths, emits a 400-d plan. A 4-layer GPT fuses that plan with the wrist image and pose and outputs robot actions through a GMM.",
    sources: {
      p1: { kind: "paper", ref: "Wang et al. 2023, §3.2–3.3", url: "https://arxiv.org/abs/2302.12422" },
      p2: { kind: "paper", ref: "Wang et al. 2023, App. A (data, training, testing)", url: "https://arxiv.org/abs/2302.12422" },
      p3: { kind: "paper", ref: "Wang et al. 2023, App. F, Tables 5–6", url: "https://arxiv.org/abs/2302.12422" },
      p4: { kind: "paper", ref: "Wang et al. 2023, App. G (network architecture)", url: "https://arxiv.org/abs/2302.12422" },
      c1: { kind: "code", repo: "j96w/MimicPlay", path: "mimicplay/algo/GPT.py", commit: "334ad94", url: "https://github.com/j96w/MimicPlay/blob/334ad94/mimicplay/algo/GPT.py" },
      c2: { kind: "code", repo: "j96w/MimicPlay", path: "mimicplay/configs/lowlevel.json", commit: "334ad94", url: "https://github.com/j96w/MimicPlay/blob/334ad94/mimicplay/configs/lowlevel.json" },
      c3: { kind: "code", repo: "j96w/MimicPlay", path: "mimicplay/configs/highlevel_human.json", commit: "334ad94", url: "https://github.com/j96w/MimicPlay/blob/334ad94/mimicplay/configs/highlevel_human.json" },
      c4: { kind: "code", repo: "j96w/MimicPlay", path: "mimicplay/algo/mimicplay.py", commit: "334ad94", url: "https://github.com/j96w/MimicPlay/blob/334ad94/mimicplay/algo/mimicplay.py" }
    },
    summary: {
      pattern: "Hierarchical: latent planner + transformer policy",
      params: null,
      vision: ["ResNet-18 per view: planner 2 views (64-d each); policy wrist view + spatial softmax", "p3", "c1"],
      backbone: ["GPT: 4 layers, 4 heads, width 656, context 10 steps", "p3", "c2"],
      head: ["GMM with 5 modes (planner: hand trajectory; policy: action)", "p2", "p3", "c2"],
      output: ["6-DoF end-effector + gripper command (OSC)", "p2"],
      attention: ["Causal over 10 steps of [plan ‖ wrist ‖ pose] tokens", "p4", "c1"],
      cond: ["Goal image → 400-d latent plan pₜ from the frozen planner", "p1", "c2"],
      steps: null, chunk: null,
      rate: ["17 Hz on the Franka (arm 17–20 Hz, gripper 2 Hz)", "p2"],
      latency: null,
      train: ["10 min human play per scene (~36k frames) + 20 teleop demos per task", "p2"]
    },
    blueprint: {
      headline: "MimicPlay: human plans, robot hands",
      note: "Stage 1 trains the planner on human play: two ResNet-18s and an MLP make a 400-d plan that a GMM decodes into the future 3-D hand path. Stage 2 freezes it and feeds the plan into every token of a GPT policy trained on robot demos.",
      towers: [
        { mod: "planner", title: "Latent planner", sub: "trained on human play, then frozen",
          input: { label: "Current + goal image", caption: "two calibrated views" },
          rows: [
            { t: "conv", label: "ResNet-18 × 2 views", call: ["64-d feature per image", "p3"] },
            { t: "mlp", label: "MLP encoder", call: ["[400, 400] → plan pₜ, 400-d", "p3", "c3"] },
            { t: "mlp", label: "GMM decoder (MLP)", call: ["5 modes over the 3-D hand path", "p1", "p3"],
              zoom: { k: "rows", title: "Planner losses", rows: ["GMM negative log-likelihood", "of the future hand trajectory", "+ λ·KL(robot ‖ human features)", "λ = 1,000"] } } ],
          output: { label: "latent plan pₜ (GMM used in training)" } },
        { mod: "policy", title: "GPT policy", sub: "trained on robot teleop",
          input: { label: "Wrist image + EE pose", caption: "10-step history" },
          rows: [
            { t: "conv", label: "Wrist ResNet-18 + spatial softmax", call: ["64 keypoints → 128", "c1", "c2"] },
            { t: "mlp", label: "Pose MLP 32 → 64 → 128", call: ["EE position + quaternion", "c1"] },
            { id: "tok", t: "embed", label: "Token [pₜ ‖ wrist ‖ pose]", call: ["400 + 128 + 128 = 656", "c1", "c2"] },
            { t: "block", n: "4", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Causal self-attention", call: ["4 heads × 164; context 10", "p3", "c2"], zoom: { k: "heads", q: 4, kv: 4, hd: 164, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["656 → 2,624 → 656", "c1"], zoom: { k: "mlp", act: "GELU", d: "656", ff: "2,624", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "mlp", label: "GMM action head", call: ["MLP 256 → 128; 5 modes", "c1", "c2"],
              zoom: { k: "rows", title: "GMM action head", rows: ["action embedding xₜ (656-d)", "3 MLPs: means, scales, logits", "5 modes × 7-D (LIBERO config)", "sample aₜ"] } } ],
          output: { label: "robot action aₜ" } }
      ],
      links: [{ from: "planner", to: "policy", toRow: "tok", label: "plan pₜ" }]
    },
    modules: [
      { id: "planner", role: "planner", roleLabel: "Latent planner", name: "Latent planner", sub: "2 × ResNet-18 · MLP 400", col: 0, frozen: true, short: "Planner",
        note: "Trained in stage 1 on human play; frozen while the policy trains.",
        stack: { rows: [
          { t: "in", label: "current + goal image, 2 views", c: "data-1" },
          { t: "conv", label: "ResNet-18 per view", dims: "64-d features" },
          { t: "mlp", label: "MLP [400, 400]", dims: "latent plan pₜ" },
          { t: "mlp", label: "GMM decoder, 5 modes" },
          { t: "out", label: "future 3-D hand trajectory", dims: "training target only", c: "data-4" } ],
          facts: [["Plan size", ["400", "c3"]], ["GMM modes", ["5, min std 1e-4", "p3", "c3"]], ["KL weight", ["1,000", "p3"]], ["Training", ["100k iterations, 12 h on one GPU", "p2"]], ["Target", ["flattened future path: 40 values (human config)", "c3"]]] } },
      { id: "policy", role: "action-head", name: "GPT policy", sub: "4 × 656 · 4 heads", col: 1, frozen: false, main: true, short: "GPT",
        stack: { rows: [
          { t: "in", label: "[pₜ ‖ wrist 128 ‖ pose 128] × 10 steps", c: "data-5" },
          { t: "block", label: "GPT block", n: "4", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "Causal MHA · 4 heads" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 656 → 2,624 → 656 · GELU" }, { t: "add", span: 2 } ] },
          { t: "mlp", label: "GMM heads: mean, scale, logits" },
          { t: "out", label: "action", dims: "5-mode GMM", c: "data-3" } ],
          facts: [["Layers / heads / width", ["4 / 4 / 656", "p3", "c2"]], ["Context", ["10 steps", "p3", "c2"]], ["Dropout", ["0.1", "p3", "c2"]], ["Wrist keypoints", ["64 (→ 128 values)", "c1", "c2"]], ["Control", ["OSC, 17 Hz", "p2"]]] } }
    ],
    inputs: [
      { to: "planner", mod: "vision", label: "current + goal image", n: "2 views", k: 4 },
      { to: "planner", mod: "state", label: "hand / EE location", n: "3-D", k: 1 },
      { to: "policy", mod: "vision", label: "wrist image", n: "ResNet-18", k: 3 },
      { to: "policy", mod: "state", label: "EE pose", n: "→ 128", k: 2 }
    ],
    outputs: [
      { from: "planner", mod: "future", label: "3-D hand path", n: "GMM, training", k: 3 },
      { from: "policy", mod: "action", label: "robot action", n: "GMM, 5 modes", k: 3 }
    ],
    links: [{ from: "planner", to: "policy", kind: "feeds", label: "latent plan pₜ|400-d, frozen" }],
    callouts: [
      "At test time a one-shot human or robot video is the prompt: each of its frames in turn becomes the goal image (App. A).",
      "Human and robot image features are aligned by a KL loss on their batch statistics, so no paired data is needed (§3.2).",
      "The released configs target LIBERO in simulation; the numbers from the paper describe the real Franka setup."
    ]
  });

  /* ------------------------------------------------------------------ ATM */
  RB.arch.spec({
    id: "atm", method: "atm", name: "ATM", year: 2024,
    figRef: "Wen et al. Figs. 2, 12 · §IV · App. B", prov: "LIBERO configs",
    lede: "A Track Transformer, trained on action-free video, predicts where 32 query points will move over the next 16 steps. A ViLT-style policy trained on a few demos reads the image and those predicted tracks, early and late, and regresses the action.",
    sources: {
      p1: { kind: "paper", ref: "Wen et al. 2024, §IV-A–B", url: "https://arxiv.org/abs/2401.00025" },
      p2: { kind: "paper", ref: "Wen et al. 2024, §V-A (data, observations, actions)", url: "https://arxiv.org/abs/2401.00025" },
      p3: { kind: "paper", ref: "Wen et al. 2024, App. B (Fig. 12, Tables VII–VIII)", url: "https://arxiv.org/abs/2401.00025" },
      c1: { kind: "code", repo: "Large-Trajectory-Model/ATM", path: "conf/train_track_transformer/libero_track_transformer.yaml", commit: "b1f2117", url: "https://github.com/Large-Trajectory-Model/ATM/blob/b1f2117/conf/train_track_transformer/libero_track_transformer.yaml" },
      c2: { kind: "code", repo: "Large-Trajectory-Model/ATM", path: "atm/model/transformer.py", commit: "b1f2117", url: "https://github.com/Large-Trajectory-Model/ATM/blob/b1f2117/atm/model/transformer.py" },
      c3: { kind: "code", repo: "Large-Trajectory-Model/ATM", path: "atm/model/track_transformer.py", commit: "b1f2117", url: "https://github.com/Large-Trajectory-Model/ATM/blob/b1f2117/atm/model/track_transformer.py" },
      c4: { kind: "code", repo: "Large-Trajectory-Model/ATM", path: "conf/train_bc/libero_vilt.yaml", commit: "b1f2117", url: "https://github.com/Large-Trajectory-Model/ATM/blob/b1f2117/conf/train_bc/libero_vilt.yaml" },
      c5: { kind: "code", repo: "Large-Trajectory-Model/ATM", path: "atm/policy/vilt.py", commit: "b1f2117", url: "https://github.com/Large-Trajectory-Model/ATM/blob/b1f2117/atm/policy/vilt.py" }
    },
    summary: {
      pattern: "Track prediction + track-guided policy",
      params: null,
      vision: ["128 × 128 base + wrist views; patch 16 (tracker), 8 (policy)", "p2", "c1", "c4"],
      backbone: ["Track Transformer: 8 layers, width 384, 8 query heads sharing 1 KV head", "c1", "c2"],
      head: ["ViLT policy: 7 spatial layers → 4 causal temporal layers → MLP", "p3", "c4"],
      output: ["7-D end-effector action per step, MSE loss", "p1", "p2"],
      attention: ["Tracker bidirectional; policy temporal stage causal", "c2", "p3"],
      cond: ["Language (BERT 768 → MLP → 1 token) conditions the tracker only", "p1", "c1"],
      steps: null,
      chunk: ["Tracks of 32 points × 16 future steps", "p3", "c1"],
      rate: null, latency: null,
      train: ["CoTracker labels; per LIBERO task 50 action-free videos + 10 action-labelled demos", "p2", "p3"]
    },
    blueprint: {
      headline: "ATM: predict point tracks, then follow them",
      note: "The Track Transformer sees track tokens (future positions masked to the current one), half-masked image patches and one language token, and decodes future point positions. The frozen tracker then feeds its predicted tracks into the policy twice: as tokens in the spatial transformer and concatenated before the action MLP.",
      towers: [
        { mod: "track", title: "Track Transformer", sub: "trained on action-free video",
          input: { label: "Track + image + text tokens", caption: "32 grid points on the current frame" },
          rows: [
            { t: "embed", label: "Track patch embed", call: ["32 points × (16 ÷ 4) = 128 tokens", "c1", "c3"] },
            { t: "embed", label: "Image patch embed", call: ["(128 ÷ 16)² = 64 tokens, 50 % masked", "p1", "c1"] },
            { t: "embed", label: "Language token", call: ["BERT 768 → MLP → 384", "p1", "c1"] },
            { t: "block", n: "8", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-query attention", call: ["8 query heads, 1 KV head, dim 48", "c1", "c2"], zoom: { k: "heads", q: 8, kv: 1, hd: 48, title: "Multi-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["384 → 1,536 → 384", "c2"], zoom: { k: "mlp", act: "GELU", d: "384", ff: "1,536", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Track + pixel decoders", call: ["Each track token → 4 steps × (x, y)", "c3"] } ],
          output: { label: "future tracks 16 × 32 × 2" } },
        { mod: "policy", title: "Track-guided policy", sub: "ViT-T style, from scratch",
          input: { label: "Frames, tracks, proprio", caption: "2 views × 10 stacked frames" },
          rows: [
            { t: "embed", label: "Patch encoder 8 × 8 + tracks", call: ["Embed 128; modality embeddings", "c4", "c5"] },
            { t: "block", n: "7", label: "spatial", rows: [{ t: "attn", label: "Self-attention per step", call: ["8 heads × 120, MLP 256", "c4"] }] },
            { t: "linear", label: "Spatial CLS 128 → 64", call: ["Downsample before time", "c4", "c5"] },
            { t: "block", n: "4", label: "temporal", rows: [{ t: "attn", label: "Causal attention in time", call: ["6 heads × 64, MLP 256", "c4"] }] },
            { t: "mlp", label: "Action MLP (late fusion)", call: ["2,112 → 1,024 → 7-D", "c4", "c5"],
              zoom: { k: "rows", title: "Late fusion into the head", rows: ["action CLS token, 64-d", "‖ predicted tracks, 2 views", "2 × 16 × 32 × 2 = 2,048", "MLP, hidden 1,024 → 7-D"] } } ],
          output: { label: "action aₜ (7-D)" } }
      ],
      links: [{ from: "track", to: "policy", toRow: "input", label: "predicted tracks" }]
    },
    modules: [
      { id: "track", role: "world", roleLabel: "Track predictor", name: "Track Transformer", sub: "8 × 384 · MQA", col: 0, frozen: true, main: true, short: "Tracker",
        note: "Trained first on videos; frozen while the policy trains.",
        stack: { rows: [
          { t: "in", label: "[128 track | 64 image | 1 text] tokens", c: "data-4" },
          { t: "block", label: "Transformer block (pre-norm)", n: "8", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "8 query heads, 1 shared KV head, dim 48" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 384 → 1,536 → 384 · GELU" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "Track decoder: 384 → 4 × 2" },
          { t: "linear", label: "Pixel decoder: 384 → 16 × 16 × 3 (auxiliary MAE)" },
          { t: "out", label: "future tracks", dims: "16 × 32 × 2", c: "data-4" } ],
          facts: [["Width / depth / heads", ["384 / 8 / 8", "c1"]], ["KV heads", ["1 (multi-query)", "c2"]], ["Track length / points", ["16 / 32", "p3", "c1"]], ["Image mask ratio", ["0.5", "p3", "c1"]], ["Loss weights", ["track 10, image 1", "c1"]], ["Labels", ["CoTracker", "p3"]]] } },
      { id: "policy", role: "action-head", name: "Track-guided ViLT", sub: "7 + 4 layers · MLP", col: 1, frozen: false, short: "Policy",
        stack: { rows: [
          { t: "in", label: "patches + track tokens per step", dims: "2 views, 10 frames", c: "data-1" },
          { t: "block", label: "Spatial transformer", n: "7", rows: [{ t: "attn", label: "MHA · 8 heads × 120" }, { t: "ffn", label: "MLP 256" }] },
          { t: "linear", label: "Spatial CLS → 64" },
          { t: "block", label: "Temporal transformer (causal)", n: "4", rows: [{ t: "attn", label: "MHA · 6 heads × 64" }, { t: "ffn", label: "MLP 256" }] },
          { t: "mlp", label: "[action CLS ‖ tracks] → 1,024 → 1,024 → 7" },
          { t: "out", label: "action", dims: "MSE", c: "data-3" } ],
          facts: [["Frame stack", ["10", "p3", "c4"]], ["Proprio", ["joint + gripper states", "c4"]], ["Head", ["2 layers, hidden 1,024", "c4"]], ["Init", ["from scratch, not from the tracker", "p1"]], ["Variant", ["ATM + Diffusion Policy also reported", "p2"]]] } }
    ],
    inputs: [
      { to: "track", mod: "vision", label: "current frame", n: "64 patches", k: 4 },
      { to: "track", mod: "lang", label: "instruction", n: "BERT → 1 token", k: 2 },
      { to: "track", mod: "other", label: "32 query points", n: "grid", k: 3 },
      { to: "policy", mod: "vision", label: "base + wrist frames", n: "10-frame stack", k: 4 },
      { to: "policy", mod: "state", label: "joint + gripper", n: "per step", k: 2 }
    ],
    outputs: [
      { from: "track", mod: "future", label: "future tracks", n: "16 × 32 × 2", k: 4 },
      { from: "policy", mod: "action", label: "action aₜ", n: "7-D", k: 3 }
    ],
    links: [{ from: "track", to: "policy", kind: "feeds", label: "predicted tracks|early + late fusion" }],
    callouts: [
      "Paper Table VII trains the tracker with batch 1,024 for 100 epochs (AdamW, weight decay 1e-4); the released config uses batch 512, 1,001 epochs, Adam, weight decay 0. Table VIII's policy batch is 512; the config uses 128.",
      "The tracker's attention shares <b>one key/value head</b> across its 8 query heads (multi-query); the paper does not mention this.",
      "With tracks as sub-goals the policy drops the language input: tracks already say what to do (§IV-B)."
    ]
  });

  /* ------------------------------------------------------------------ EgoMimic */
  RB.arch.spec({
    id: "egomimic", method: "egomimic", name: "EgoMimic", year: 2024,
    figRef: "Kareer et al. Fig. 4 · §III · Table V", prov: "Object-in-Bowl config",
    lede: "One ACT-style CVAE transformer co-trained on Aria-glasses hand data and robot teleop. A shared ResNet-18 reads masked frames; two linear heads predict a 100-step pose chunk for both embodiments and a joint chunk for the robot.",
    sources: {
      p1: { kind: "paper", ref: "Kareer et al. 2024, §III-C (Fig. 4, Alg. 1)", url: "https://arxiv.org/abs/2410.24221" },
      p2: { kind: "paper", ref: "Kareer et al. 2024, App. VI-A, C, D (Table V)", url: "https://arxiv.org/abs/2410.24221" },
      p3: { kind: "paper", ref: "Kareer et al. 2024, App. VI-F (Table VII)", url: "https://arxiv.org/abs/2410.24221" },
      p4: { kind: "paper", ref: "Kareer et al. 2024, §III-B (alignment)", url: "https://arxiv.org/abs/2410.24221" },
      c1: { kind: "code", repo: "SimarKareer/EgoMimic", path: "egomimic/configs/egomimic_oboo.json", commit: "6d63e9a", url: "https://github.com/SimarKareer/EgoMimic/blob/6d63e9a/egomimic/configs/egomimic_oboo.json" },
      c2: { kind: "code", repo: "SimarKareer/EgoMimic", path: "egomimic/algo/egomimic.py", commit: "6d63e9a", url: "https://github.com/SimarKareer/EgoMimic/blob/6d63e9a/egomimic/algo/egomimic.py" },
      c3: { kind: "code", repo: "SimarKareer/EgoMimic", path: "egomimic/models/act_nets.py", commit: "6d63e9a", url: "https://github.com/SimarKareer/EgoMimic/blob/6d63e9a/egomimic/models/act_nets.py" },
      c4: { kind: "code", repo: "SimarKareer/EgoMimic", path: "egomimic/algo/act.py", commit: "6d63e9a", url: "https://github.com/SimarKareer/EgoMimic/blob/6d63e9a/egomimic/algo/act.py" }
    },
    summary: {
      pattern: ["Encoder–decoder transformer (CVAE)", "p1"],
      params: null,
      vision: ["ResNet-18 on SAM-masked Aria frames with a red line; robot adds wrist views", "p2", "p4", "c1"],
      backbone: ["ACT transformer: hidden 512, 8 heads, FFN 3,200; 4 encoder / 7 decoder layers (paper)", "p2", "c1"],
      head: ["Two linear heads: pose (hand + robot) and joints (robot only)", "p1", "c2"],
      output: ["Chunk of 100 actions: 4 s for the robot, 1 s for the hand", "p2", "c1"],
      attention: ["Bidirectional encoder; decoder with 100 learned action queries", "c3", "c4"],
      cond: ["CVAE style token z (latent 32, KL weight 20 in the config)", "p2", "c1"],
      steps: null,
      chunk: ["100 actions; first 1 s executed, receding horizon", "p2", "p3"],
      rate: ["Inference 1 Hz, control 25 Hz", "p3"],
      latency: null,
      train: ["Co-train: L1 pose on hand + robot, L1 joints on robot, + KL; 120k iterations on 4 A40s", "p2"]
    },
    blueprint: {
      headline: "EgoMimic: hands and robot, one ACT",
      note: "Hand and robot batches share the ResNet-18 and the whole transformer; only the thin input projections and the two output heads differ. The CVAE style encoder follows ACT and is used only in training.",
      towers: [
        { mod: "resnet", title: "ResNet-18", sub: "shared by hand and robot", compact: true,
          input: { label: "Masked Aria frame", caption: "SAM mask + red line; robot wrist too" },
          rows: [
            { t: "conv", label: "ResNet-18 backbone", call: ["One per camera view", "c1", "c2"] },
            { t: "linear", label: "Features → tokens", call: ["Width 512", "c1"] } ],
          output: { label: "visual tokens" } },
        { mod: "act", title: "ACT transformer", sub: "encoder–decoder",
          input: { label: "[z ‖ proprio ‖ image tokens]", caption: "Gaussian-normalized per embodiment" },
          rows: [
            { t: "linear", label: "Input head per embodiment", call: ["hand or robot proprio → 512", "p1", "c2"] },
            { t: "block", n: "4", label: "encoder", rows: [
              { t: "attn", label: "Multi-head self-attention", call: ["8 heads, width 512", "p2", "c1"], zoom: { k: "heads", q: 8, kv: 8, hd: 64, title: "Attention heads" } },
              { t: "ffn", label: "Feed forward (ReLU)", call: ["Hidden 3,200", "p2", "c1"], zoom: { k: "mlp", act: "ReLU", d: "512", ff: "3,200", title: "Feed forward" } } ] },
            { t: "block", n: "7", label: "decoder", rows: [{ t: "attn", label: "Self + cross-attention", call: ["100 learned action queries", "c1", "c4"] }] },
            { t: "linear", label: "Pose head · joint head", call: ["One linear layer each", "p1", "c2"],
              zoom: { k: "rows", title: "Co-training losses", rows: ["robot: L1 pose + L1 joints + KL", "hand: L1 pose + KL", "gripper learned from robot only", "one step = one hand + one robot batch"] } } ],
          output: { label: "pose chunk (both) · joint chunk (robot)" } },
        { mod: "style", title: "CVAE style encoder", sub: "training only", compact: true,
          input: { label: "[CLS ‖ action chunk]", caption: "ground-truth actions" },
          rows: [
            { t: "attn", label: "Transformer encoder", call: ["enc_layers = 4", "c1", "c2"] },
            { t: "linear", label: "CLS → μ, log σ²", call: ["Latent 32", "c1", "c3"] } ],
          output: { label: "style token z" } }
      ],
      links: [
        { from: "resnet", to: "act", toRow: "input", label: "image tokens" },
        { from: "style", to: "act", toRow: "input", label: "z" }
      ]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet-18", sub: "shared hand + robot", col: 0, frozen: false, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "Aria RGB (masked, red line) · robot wrist", c: "data-1" },
          { t: "conv", label: "ResNet-18 per camera view" },
          { t: "out", label: "feature tokens", c: "data-1" } ],
          facts: [["Backbone", ["ResNet-18", "p1", "c1"]], ["Sharing", ["same weights for hand and robot frames", "p1"]], ["Augmentation", ["color jitter", "p2"]]] } },
      { id: "act", role: "action-head", roleLabel: "ACT policy", name: "ACT transformer", sub: "512 · 8 heads · FFN 3200", col: 1, frozen: false, main: true, short: "ACT",
        stack: { rows: [
          { t: "in", label: "[z | proprio | image tokens]", c: "data-5" },
          { t: "linear", label: "Embodiment-specific input projection → 512" },
          { t: "block", label: "Encoder", n: "4", rows: [{ t: "attn", label: "MHA · 8 heads" }, { t: "ffn", label: "FFN 512 → 3,200 → 512 · ReLU" }] },
          { t: "block", label: "Decoder", n: "7", rows: [{ t: "attn", label: "Self-attention over 100 queries" }, { t: "attn", label: "Cross-attention to encoder" }, { t: "ffn", label: "FFN 3,200" }] },
          { t: "linear", label: "Pose head (hand + robot) · joint head (robot)" },
          { t: "out", label: "100-step chunks", c: "data-3" } ],
          facts: [["Hidden / heads / FFN", ["512 / 8 / 3,200", "p2", "c1"]], ["Layers", ["4 enc / 7 dec (paper); code builds 7 / 7", "p2", "c2"]], ["Chunk", ["100", "p2", "c1"]], ["KL weight", ["20", "c1"]], ["Optimizer", ["AdamW, lr 5e-5, linear schedule", "p2", "c1"]]] } },
      { id: "style", role: "latent", roleLabel: "CVAE encoder", name: "Style encoder", sub: "4 layers · latent 32", col: 2, frozen: false, short: "CVAE",
        note: "As in ACT: encodes the true action chunk into z during training; z = 0 prior at test time." }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "masked Aria frame", n: "+ wrist (robot)", k: 4 },
      { to: "act", mod: "state", label: "normalized proprio", n: "hand or robot", k: 2 },
      { to: "style", mod: "action", label: "true chunk", n: "training only", k: 4 }
    ],
    outputs: [
      { from: "act", mod: "action", label: "pose chunk", n: "both", k: 3 },
      { from: "act", mod: "action", label: "joint chunk", n: "robot only", k: 3 }
    ],
    links: [
      { from: "resnet", to: "act", kind: "prefix", label: "image tokens" },
      { from: "style", to: "act", kind: "latent", label: "style z" }
    ],
    callouts: [
      "Paper Table V: 4 encoder and 7 decoder layers. In the released code the main transformer is built with <code>num_layers = dec_layers</code> (7) for both stacks, and <code>enc_layers</code> (4) sizes the CVAE style encoder.",
      "Human data is slowed down 4×: the same 100-step chunk spans 1 s of hand motion and 4 s of robot motion (App. VI-A).",
      "The robot is driven by the joint head; the pose head exists so that hand and robot share one output space (§III-C)."
    ]
  });

  /* ------------------------------------------------------------------ Being-H0 */
  RB.arch.spec({
    id: "being-h0", method: "being-h0", name: "Being-H0", year: 2025,
    figRef: "Luo et al. Fig. 2 · §4.1 · §6.1.1", prov: "",
    lede: "InternVL3 with its vocabulary extended by 8,192 hand-motion codes. It learns to write MANO hand motion as tokens from human video; for robots, learnable action queries and an MLP regress a 16-step action chunk instead.",
    sources: {
      p1: { kind: "paper", ref: "Luo et al. 2025, §4.1.1 (architecture)", url: "https://arxiv.org/abs/2507.15597" },
      p2: { kind: "paper", ref: "Luo et al. 2025, §4.1.3 (vision and motion tokens, fusion)", url: "https://arxiv.org/abs/2507.15597" },
      p3: { kind: "paper", ref: "Luo et al. 2025, §6.1.1 (implementation)", url: "https://arxiv.org/abs/2507.15597" },
      p4: { kind: "paper", ref: "Luo et al. 2025, §3.2 and Fig. 2 (robot control transfer)", url: "https://arxiv.org/abs/2507.15597" },
      p5: { kind: "paper", ref: "Luo et al. 2025, §6.4.1 (tokenizer ablation)", url: "https://arxiv.org/abs/2507.15597" },
      c1: { kind: "code", repo: "BeingBeyond/Being-H0", path: "beingvla/models/vla/being_vla_model.py", commit: "ae92e46", url: "https://github.com/BeingBeyond/Being-H0/blob/ae92e46/beingvla/models/vla/being_vla_model.py" },
      c2: { kind: "code", repo: "BeingBeyond/Being-H0", path: "beingvla/models/vla/config.py", commit: "ae92e46", url: "https://github.com/BeingBeyond/Being-H0/blob/ae92e46/beingvla/models/vla/config.py" },
      c3: { kind: "code", repo: "BeingBeyond/Being-H0", path: "README.md", commit: "ae92e46", url: "https://github.com/BeingBeyond/Being-H0/blob/ae92e46/README.md" }
    },
    summary: {
      pattern: ["Autoregressive token VLA", "p1"],
      params: ["1B, 8B or 14B (InternVL3 scales)", "p3", "c3"],
      vision: ["InternViT-300M on 448 × 448 tiles + thumbnail; pixel shuffle 0.5 → 256 tokens per tile", "p1", "p2", "c1"],
      backbone: ["InternVL3 LLM; one shared attention over vision, text and motion", "p1", "p2"],
      head: ["Pretraining: LM head over text + motion codes. Robot: action queries → MLP regression", "p1", "p4", "c1"],
      output: ["MANO-D162 hand motion at 15 FPS, 128 tokens per hand per second", "p3"],
      attention: "Causal, shared across all three modalities",
      cond: "Scene image and instruction as prefix",
      steps: null,
      chunk: ["Robot: 16 actions per call (released default)", "c2", "c3"],
      rate: null, latency: null,
      train: ["UniHand-2.5M; AdamW lr 1e-5, batch 128, 32 A800 GPUs", "p3"]
    },
    blueprint: {
      headline: "Being-H0: hand motion as a language",
      note: "Image tiles become 256 tokens each through InternViT and an MLP. Hand motion is tokenized by a part-level GRQ tokenizer and inserted between <MOT> and </MOT>. The LLM predicts the next token of any kind; for robots a set of learnable queries reads out an action chunk.",
      towers: [
        { mod: "vit", title: "InternViT-300M", sub: "vision encoder", compact: true,
          input: { label: "Tile 448 × 448", caption: "dynamic tiles + thumbnail" },
          rows: [
            { t: "embed", label: "Patch embed 14 × 14", call: ["(448 ÷ 14)² = 1,024 patches", "c1"] },
            { t: "group", label: "InternViT layers", rows: [{ t: "attn", label: "Self-attention" }, { t: "ffn", label: "Feed forward" }] },
            { t: "conv", label: "Pixel shuffle 0.5", call: ["1,024 → 256 tokens", "p2", "c1"] },
            { t: "mlp", label: "2-layer MLP projector", call: ["Into the LLM width", "p1"] } ],
          output: { label: "256 tokens per tile" } },
        { mod: "llm", title: "InternVL3 LLM", sub: "1B / 8B / 14B",
          input: { label: "[image | text | motion]", caption: "motion inside <MOT> … </MOT>" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["+ 8,192 motion codes, <MOT>, </MOT>", "p1", "p5"] },
            { t: "group", label: "LLM decoder layers", rows: [
              { t: "attn", label: "Shared causal attention", call: ["One Q, K, V over all modalities", "p2"] },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "LM head → next token", call: ["Text or motion code", "p1"] },
            { t: "mlp", label: "Robot: action queries → MLP", call: ["16-step chunk, L1 loss", "p4", "c2"],
              zoom: { k: "rows", title: "Robot post-training head", rows: ["proprio → MLP (h/2) → h", "learnable action-query tokens", "LLM hidden states at the queries", "MLP (h/2) → chunk × action dim"] } } ],
          output: { label: "motion tokens · robot action chunk" } },
        { mod: "tok", title: "Part-level GRQ", sub: "hand motion tokenizer", compact: true,
          input: { label: "MANO-D162 motion", caption: "15 FPS, one-second windows" },
          rows: [
            { t: "conv", label: "Temporal conv encoder", call: ["Downsample α = 4", "p3"] },
            { t: "group", label: "Grouped residual VQ", rows: [
              { t: "linear", label: "Wrist codebook", call: ["4,096 codes, dim 512", "p3"] },
              { t: "linear", label: "Finger codebook", call: ["4,096 codes, 8 RQ layers", "p3"],
                zoom: { k: "rows", title: "Tokens per second", rows: ["2 parts (wrist, fingers)", "× 2 groups × 8 residual layers", "× ⌈15 ÷ 4⌉ = 4 steps", "= 128 tokens per hand"] } } ] } ],
          output: { label: "128 tokens per hand per second" } }
      ],
      links: [
        { from: "vit", to: "llm", toRow: "input", label: "image tokens" },
        { from: "tok", to: "llm", toRow: "input", label: "motion tokens" }
      ]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "InternViT-300M", sub: "448² tiles · shuffle 0.5", col: 0, frozen: false, params: "300M", short: "InternViT",
        stack: { rows: [
          { t: "in", label: "448 × 448 tiles + thumbnail", c: "data-1" },
          { t: "embed", label: "Patch 14 × 14", dims: "1,024 patches" },
          { t: "conv", label: "Pixel shuffle 0.5", dims: "→ 256 tokens" },
          { t: "mlp", label: "2-layer MLP projector" },
          { t: "out", label: "image tokens", c: "data-1" } ],
          facts: [["Encoder", ["InternViT-300M", "p1"]], ["Resolution", ["448 × 448", "p3", "c1"]], ["Tokens per tile", ["256", "c1"]], ["Trained", ["ViT adapter + LLM jointly fine-tuned", "p3"]]] } },
      { id: "llm", role: "vlm", name: "InternVL3 LLM", sub: "1B / 8B / 14B", col: 1, frozen: false, main: true, short: "LLM",
        stack: { rows: [
          { t: "in", label: "[image | text | <MOT> motion </MOT>]", c: "data-2" },
          { t: "embed", label: "Token embedding + motion codes" },
          { t: "group", label: "LLM decoder layers", rows: [{ t: "attn", label: "Causal attention shared by all modalities" }, { t: "ffn", label: "Feed forward" }] },
          { t: "linear", label: "LM head (pretraining)" },
          { t: "mlp", label: "Action-query MLP head (robot post-training)" },
          { t: "out", label: "motion tokens / action chunk", c: "data-3" } ],
          facts: [["Scales", ["1B, 8B, 14B", "p3", "c3"]], ["Motion codes", ["8,192 = 4,096 wrist + 4,096 finger", "p3", "p5"]], ["Logit masking", ["vocabulary-level, p = 0.5", "p3"]], ["Robot head", ["MLP, chunk 16, L1", "c2"]]] } },
      { id: "tok", role: "codec", roleLabel: "Motion tokenizer", name: "Part-level GRQ", sub: "wrist + finger · 2 × 4096", col: 2, frozen: true, short: "GRQ",
        stack: { rows: [
          { t: "in", label: "MANO-D162 features, 15 FPS", c: "data-3" },
          { t: "conv", label: "Temporal conv encoder, ↓4" },
          { t: "linear", label: "GRQ: 8 layers × 2 groups per part" },
          { t: "out", label: "128 tokens per hand per second", c: "data-7" } ],
          facts: [["Layers / groups", ["8 / 2", "p3"]], ["Codebooks", ["4,096 wrist + 4,096 finger, dim 512", "p3"]], ["Loss weights", ["λ₁ = 0.02, λ₂ = 1.0", "p3"]], ["Batch / lr", ["2,048 / 2e-4", "p3"]]] } }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "scene image", n: "448 × 448", k: 5 },
      { to: "llm", mod: "lang", label: "instruction", n: "text tokens", k: 3 },
      { to: "llm", mod: "state", label: "robot proprio", n: "post-training", k: 1 },
      { to: "tok", mod: "action", label: "hand motion", n: "MANO-D162", k: 4 }
    ],
    outputs: [
      { from: "llm", mod: "action", label: "motion tokens / actions", n: "128 per s · 16 steps", k: 4 },
      { from: "tok", mod: "action", label: "decoded MANO motion", n: "15 FPS", k: 3 }
    ],
    links: [
      { from: "vit", to: "llm", kind: "prefix", label: "MLP projector|256 tokens / tile" },
      { from: "tok", to: "llm", kind: "latent", label: "motion codes|<MOT> … </MOT>" }
    ],
    callouts: [
      "Pretraining decodes hand motion autoregressively; robot post-training switches to a non-autoregressive regression head over learnable queries (§3.2, Fig. 2).",
      "The part-level tokenizer reconstructs worse than whole-hand variants on MPJPE but generates better motion (Tables 5–6)."
    ]
  });

  /* ------------------------------------------------------------------ villa-X */
  RB.arch.spec({
    id: "villa-x", method: "villa-x", name: "villa-X", year: 2025, parent: "lapa",
    diffRows: ["params", "vision", "backbone", "head", "output", "attention", "chunk"],
    figRef: "Chen et al. Fig. 2 · §3 · App. A–B", prov: "",
    lede: "A latent action model grounded by a proprioceptive decoder, then a π0-style policy with two experts: ACT-latent diffuses a 6-step latent plan, and ACT-robot diffuses a 4-step action chunk while attending to that plan.",
    sources: {
      p1: { kind: "paper", ref: "Chen et al. 2025, §3.1 (latent action model)", url: "https://arxiv.org/abs/2507.23682" },
      p2: { kind: "paper", ref: "Chen et al. 2025, §3.2 (ACT, Eq. 4)", url: "https://arxiv.org/abs/2507.23682" },
      p3: { kind: "paper", ref: "Chen et al. 2025, App. A.1–A.2 (LAM)", url: "https://arxiv.org/abs/2507.23682" },
      p4: { kind: "paper", ref: "Chen et al. 2025, App. B (actor module)", url: "https://arxiv.org/abs/2507.23682" },
      p5: { kind: "paper", ref: "Chen et al. 2025, App. C (data mixture)", url: "https://arxiv.org/abs/2507.23682" },
      c1: { kind: "code", repo: "microsoft/villa-x", path: "lam/model.py", commit: "9b44899", url: "https://github.com/microsoft/villa-x/blob/9b44899/lam/model.py" },
      c2: { kind: "code", repo: "microsoft/villa-x (Hugging Face)", path: "lam/model_config.json", commit: "5dd493c", url: "https://huggingface.co/microsoft/villa-x/blob/5dd493c2d376264a39b9399e6a6939b21bb56e60/lam/model_config.json" }
    },
    summary: {
      pattern: ["Latent-action pretraining", "p1"],
      params: ["~3.6B: PaliGemma 3B + two ~300M experts", "p4"],
      vision: ["PaliGemma at 224 × 224; optional wrist ResNet-18 → 16 tokens by cross-attention", "p4"],
      backbone: ["PaliGemma 3B VLM", "p4"],
      head: ["ACT-latent and ACT-robot experts: 18 layers, width 1,024, 8 heads each", "p4"],
      output: ["Joint diffusion over 6 latent actions and 4 robot actions", "p2", "p4"],
      attention: ["Block-causal: VLM → latent expert → robot expert", "p2"],
      cond: "Robot expert also sees state q, embodiment context cₑ and the predicted latents",
      steps: null,
      chunk: ["n = 6 latent actions, m = 4 robot actions", "p4"],
      rate: null, latency: null,
      train: ["LAM on 1.6M robot trajectories + 3.6M human clips; policy 4 days on 64 A100s", "p3", "p4", "p5"]
    },
    changes: [
      "Latents are <b>continuous</b> codebook centers, predicted by a diffusion expert instead of discrete tokens from the LM.",
      "The latent model adds a <b>proprio-FDM</b> (2-layer MLP) that predicts future states and actions, so latents track physical motion.",
      "Latents come from an ST-Transformer over <b>8-frame clips</b> instead of a 2-frame C-ViViT encoder.",
      "The policy keeps latents at test time: ACT-robot <b>attends to the latent plan</b> rather than only inheriting weights.",
      "Backbone switches from LWM 7B to <b>PaliGemma 3B</b> with two ~300M experts."
    ],
    blueprint: {
      headline: "villa-X: plan in latents, act in joints",
      note: "The latent action model is trained first and provides latent targets. In the policy, PaliGemma, the latent expert and the robot expert run layer by layer in one masked self-attention, like π0 with an extra expert: latents see the VLM, robot actions see both.",
      towers: [
        { mod: "lam", title: "Latent action model", sub: "IDM + VQ + two decoders", compact: true,
          input: { label: "8-frame clip", caption: "224 × 224 per frame" },
          rows: [
            { t: "embed", label: "Patch embed 14 × 14", call: ["16 × 16 = 256 patches per frame", "p3", "c2"] },
            { t: "block", n: "12", rows: [{ t: "attn", label: "Spatial + temporal attention", call: ["768-d, 12 heads (config)", "c2"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "ST-block heads (config)" } }] },
            { t: "pool", label: "MAP pooling", call: ["2 tokens × 32-d per step", "c2"] },
            { t: "linear", label: "VQ, 32 codes", call: ["Centers used downstream", "p1", "p3"] },
            { t: "group", label: "Decoders (training only)", rows: [
              { t: "conv", label: "Visual FDM (ViT-B)", call: ["12 layers → ôₜ₊K", "p3", "c2"] },
              { t: "mlp", label: "Proprio-FDM", call: ["2-layer MLP, two heads", "p3"],
                zoom: { k: "rows", title: "Proprio-FDM grounding", rows: ["current state qₜ", "+ latent zₜ + context cₑ", "2-layer MLP, two heads", "future states and actions"] } } ] } ],
          output: { label: "latent targets" } },
        { mod: "lat", title: "ACT-latent", sub: "latent action expert, ~300M", compact: true,
          input: { label: "Noisy latent plan", caption: "n = 6 latents, diffusion time τ" },
          rows: [
            { t: "linear", label: "Latent input projection" },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "Norm" },
              { id: "att", t: "attn", label: "Masked self-attention", zoom: { k: "heads", q: 8, kv: 8, hd: 128, title: "Expert attention heads" } },
              { t: "ffn", label: "Feed forward", call: ["Width 1,024, 8 heads", "p4"] } ] },
            { t: "linear", label: "Output projection" } ],
          output: { label: "denoised latent plan (6)" } },
        { mod: "vlm", title: "PaliGemma 3B", sub: "VLM prefix",
          input: { label: "Image + instruction", caption: "224 × 224, 128-token text" },
          rows: [
            { t: "embed", label: "SigLIP image tokens", call: ["224 × 224 input; prefix sees only itself", "p4", "p2"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "Norm" },
              { id: "att", t: "attn", label: "Masked self-attention" },
              { t: "ffn", label: "Feed forward" } ] } ],
          output: { label: "prefix keys and values" } },
        { mod: "rob", title: "ACT-robot", sub: "robot action expert, ~300M", compact: true,
          input: { label: "q, cₑ, noisy actions", caption: "m = 4 actions" },
          rows: [
            { t: "linear", label: "Per-embodiment state proj", call: ["HPT-style, one per embodiment", "p4"] },
            { t: "attn", label: "Wrist cross-attention", call: ["ResNet-18 → 16 tokens, dropped 50 %", "p4"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "Norm" },
              { id: "att", t: "attn", label: "Masked self-attention", call: ["Sees prefix and latents", "p2", "p4"],
                zoom: { k: "rows", title: "Embodiment context cₑ", rows: ["dataset ID → learned embedding", "control frequency → sinusoid", "→ MLP", "cₑ joins qₜ at the input"] } },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "Per-embodiment action proj", call: ["4-step robot chunk", "p4"] } ],
          output: { label: "robot action chunk" } }
      ],
      links: [{ from: "lam", to: "lat", toRow: "input", label: "targets" }],
      shared: [
        { a: ["lat", "att"], b: ["vlm", "att"], label: "shared attention" },
        { a: ["vlm", "att"], b: ["rob", "att"], label: "shared attention" }
      ]
    },
    modules: [
      { id: "lam", role: "latent", roleLabel: "Latent action model", name: "Latent action model", sub: "ST 12 × 768 · 32 codes", col: 0, frozen: true, short: "LAM",
        note: "Pretrained first; its codebook centers are the targets for ACT-latent.",
        stack: { rows: [
          { t: "in", label: "clip of 8 frames, 224 × 224", c: "data-1" },
          { t: "embed", label: "Patch 14 × 14", dims: "256 per frame, 768-d" },
          { t: "block", label: "ST-Transformer IDM", n: "12", rows: [{ t: "attn", label: "Spatial attention" }, { t: "attn", label: "Temporal attention" }, { t: "ffn", label: "MLP ratio 4" }] },
          { t: "pool", label: "MAP pooling → latent tokens" },
          { t: "linear", label: "VQ codebook, 32 codes" },
          { t: "out", label: "7 latent actions per clip", dims: "T − 1 for T = 8", c: "data-7" } ],
          facts: [["IDM", ["12 ST-blocks, width 768", "p3", "c2"]], ["Heads", ["32 (paper) · 12 (released config)", "p3", "c2"]], ["Codebook", ["32 codes", "p3", "c2"]], ["Visual FDM", ["ViT-B, 12 layers", "p3", "c2"]], ["Proprio-FDM", ["2-layer MLP", "p3"]], ["Training", ["batch 512, lr 1.5e-4, 128 A100s × 4 days", "p3"]]] } },
      { id: "lat", role: "action-expert", roleLabel: "Latent action expert", name: "ACT-latent", sub: "18 × 1024 · 8 heads", col: 1, frozen: false, params: "≈300M", short: "ACT-latent",
        stack: { rows: [
          { t: "in", label: "noisy latent plan (6) + τ", c: "data-7" },
          { t: "block", label: "Expert block, same layer index as the VLM", n: "18", rows: [{ t: "attn", label: "Masked joint attention" }, { t: "ffn", label: "Feed forward" }] },
          { t: "out", label: "latent plan", c: "data-7" } ],
          facts: [["Width / depth / heads", ["1,024 / 18 / 8", "p4"]], ["Init", ["from scratch", "p4"]], ["τ sampling", ["beta, biased toward noisier latents", "p4"]]] } },
      { id: "vlm", role: "vlm", name: "PaliGemma 3B", sub: "SigLIP + Gemma", col: 2, frozen: false, main: true, params: "3B", short: "PaliGemma" },
      { id: "rob", role: "action-expert", roleLabel: "Robot action expert", name: "ACT-robot", sub: "18 × 1024 · 8 heads", col: 3, frozen: false, params: "≈300M", short: "ACT-robot",
        stack: { rows: [
          { t: "in", label: "state q, cₑ, noisy actions (4)", c: "data-3" },
          { t: "linear", label: "Per-embodiment state projection" },
          { t: "attn", label: "Cross-attention to 16 wrist tokens" },
          { t: "block", label: "Expert block", n: "18", rows: [{ t: "attn", label: "Masked joint attention" }, { t: "ffn", label: "Feed forward" }] },
          { t: "linear", label: "Per-embodiment action projection" },
          { t: "out", label: "robot action chunk", c: "data-3" } ],
          facts: [["Width / depth / heads", ["1,024 / 18 / 8", "p4"]], ["Chunk", ["4 actions", "p4"]], ["Latent dropout", ["50 % attention dropout + 50 % token masking", "p4"]], ["Wrist view", ["ResNet-18 → 16 tokens, masked 50 %", "p4"]]] } }
    ],
    inputs: [
      { to: "lam", mod: "vision", label: "8-frame clip", n: "224 × 224", k: 5 },
      { to: "lat", mod: "latent", label: "noisy latents", n: "n = 6", k: 4, noisy: true },
      { to: "vlm", mod: "vision", label: "image", n: "224 × 224", k: 4 },
      { to: "vlm", mod: "lang", label: "instruction", n: "text", k: 3 },
      { to: "rob", mod: "action", label: "noisy actions", n: "m = 4", k: 4, noisy: true },
      { to: "rob", mod: "state", label: "state q + cₑ", n: "per embodiment", k: 2 }
    ],
    outputs: [
      { from: "lat", mod: "latent", label: "latent plan", n: "6 latents", k: 4 },
      { from: "rob", mod: "action", label: "robot actions", n: "4 steps", k: 4 }
    ],
    links: [
      { from: "lam", to: "lat", kind: "two-stage", label: "latent targets|codebook centers" },
      { from: "vlm", to: "lat", kind: "joint-attn", label: "shared attn" },
      { from: "vlm", to: "rob", kind: "joint-attn", label: "shared attn" }
    ],
    mask: { name: "Blockwise causal", ref: "p2", axes: [{ label: "image + text", short: "img+ℓ", mod: "vision" }, { label: "latent actions", short: "z", mod: "latent" }, { label: "state + actions", short: "q, a", mod: "action" }], m: ["100", "110", "111"],
      note: "Latents are conditioned only on image and text (Eq. 4); robot actions see the latent plan, which is regularized by 50 % attention dropout." },
    callouts: [
      "Paper App. A.1 gives the IDM <b>32 heads</b>; the released latent action model config uses <b>12</b>, with 2 learned latent tokens of dim 32 per step.",
      "Only the latent action model is released (GitHub + Hugging Face); the policy numbers come from the paper alone.",
      "OpenWAM-style reading: a π0-type two-expert VLA with a third, latent-planning expert between the VLM and the action expert."
    ]
  });
})();
