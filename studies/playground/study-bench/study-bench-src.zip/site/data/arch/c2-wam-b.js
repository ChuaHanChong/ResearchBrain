/* Architecture specs, topic 11 (world action models), part B. Numbers from the papers and the official code; see sources.
   Models: CoT-VLA, WorldVLA, F1, Motus, Cosmos Policy, LingBot-VA, DreamZero, Fast-WAM, mimic-video, VideoVLA. */
(function () {
  var RB = window.RB;
  function gh(repo, commit, path) { return { kind: "code", repo: repo, path: path, commit: commit, url: "https://github.com/" + repo + "/blob/" + commit + "/" + path }; }

  /* ------------------------------------------------------------------ CoT-VLA */
  RB.arch.spec({
    id: "cot-vla", method: "cot-vla", name: "CoT-VLA", year: 2025, parent: "openvla",
    diffRows: ["vision", "backbone", "head", "output", "attention", "chunk", "train"],
    figRef: "Zhao et al. Figs. 2–3 · §3 · Supp. §6", prov: "Paper only (no code)",
    lede: "A 7B unified autoregressive model (VILA-U) that first writes a subgoal image as 256 residual-quantized tokens, then a 10-step action chunk in one parallel pass. Images are causal tokens; the action chunk attends to itself fully.",
    sources: {
      p1: { kind: "paper", ref: "Zhao et al. 2025, §3.1–3.2 and Figs. 2–3", url: "https://arxiv.org/abs/2503.22020" },
      p2: { kind: "paper", ref: "Zhao et al. 2025, §3.3 (training, action tokens)", url: "https://arxiv.org/abs/2503.22020" },
      p3: { kind: "paper", ref: "Zhao et al. 2025, §5 and Supp. §6 (Tables 4–5)", url: "https://arxiv.org/abs/2503.22020" },
      p4: { kind: "paper", ref: "Wu et al. 2024 (VILA-U), §3.1–3.2 and §4.1", url: "https://arxiv.org/abs/2409.04429" },
      p5: { kind: "paper", ref: "Touvron et al. 2023a (LLaMA), §2.2 and Table 2", url: "https://arxiv.org/abs/2302.13971" },
      p6: { kind: "paper", ref: "Touvron et al. 2023b (Llama 2), §2.2", url: "https://arxiv.org/abs/2307.09288" }
    },
    summary: {
      pattern: ["Autoregressive unified video-action model", "p1"],
      params: ["7B", "p1"],
      vision: ["VILA-U vision tower (SigLIP-Large/16 init), frozen: 256 × 256 → 16 × 16 × 4 residual codes", "p2", "p4"],
      backbone: ["VILA-U LLM = LLaMA-2-7B: 32 layers, width 4,096, 32 heads", "p4", "p5", "p6"],
      head: ["RQ depth transformer writes 4 residual codes per image position; LM head writes action bins", "p2", "p4"],
      output: ["Subgoal image ŝₜ₊ₙ (256 positions × 4 codes), then 10 actions × 7 tokens", "p1", "p2", "p3"],
      attention: ["Hybrid: causal for text and image tokens, full inside the action chunk", "p1", "p2"],
      cond: ["Instruction ℓ and current image sₜ as the prefix", "p1"],
      steps: ["256 image positions decoded one by one; the chunk in one parallel pass", "p2", "p3"],
      chunk: ["m = 10 actions, all executed before re-planning", "p2", "p3"],
      rate: null,
      latency: ["≈ 7× slower than direct action generation (chunk 10)", "p3"],
      train: ["OXE subset + EPIC-KITCHENS + SSv2; 11K A100 GPU hours; batch 2,048, lr 1e-4", "p3"]
    },
    changes: [
      "Backbone is <b>VILA-U 7B</b>, a unified model that can also <b>generate</b> images as residual-quantized tokens.",
      "Before acting it writes a <b>subgoal image</b> n frames ahead: a visual chain of thought.",
      "Predicts a <b>chunk of 10 actions</b> in one parallel pass with full attention, not token by token.",
      "Subgoal generation also trains on <b>action-less video</b> (EPIC-KITCHENS, Something-Something V2).",
      "The vision tower stays frozen; LLM, projector and depth transformer are trained."
    ],
    blueprint: {
      headline: "CoT-VLA: imagine the subgoal, then act",
      note: "The frozen vision tower turns the current frame into 256 code embeddings that join the instruction in LLaMA's sequence. The LLM first writes the subgoal image position by position (the depth transformer resolves 4 residual codes each), then fills 10 × 7 action slots in one pass.",
      towers: [
        { mod: "vt", title: "VILA-U vision tower", sub: "frozen, SigLIP-Large init", compact: true,
          input: { label: "Image 256 × 256", caption: "current frame sₜ" },
          rows: [
            { t: "embed", label: "Patch embedding 16 × 16", call: ["256 / 16 = 16 → 16 × 16 positions", "p4"] },
            { t: "attn", label: "SigLIP-Large ViT encoder" },
            { t: "linear", label: "Residual quantizer, depth 4", call: ["Codebook 16,384; 4 codes per position", "p4"],
              zoom: { k: "rows", title: "Residual quantization", rows: ["r₀ = z (encoder feature)", "k₁ = argmin ‖r₀ − e(k)‖", "r₁ = r₀ − e(k₁)", "repeat to depth D = 4", "ẑ = sum of the 4 code vectors"] } } ],
          output: { label: "256 code embeddings" } },
        { mod: "llm", title: "VILA-U LLM (LLaMA-2-7B)", sub: "decoder-only, trained",
          input: { label: "[ℓ | sₜ | ŝₜ₊ₙ | actions]", caption: "one sequence; special tokens mark actions" },
          rows: [
            { t: "linear", label: "Projector → 4,096", call: ["LLaMA 7B width 4,096", "p1", "p5"] },
            { t: "embed", label: "Token embedding", call: ["256 least-used ids become action bins", "p2"] },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm 1 (pre-norm)" },
              { t: "attn", label: "Hybrid-masked self-attention", side: "RoPE", call: ["32 heads, head dim 128", "p5"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Attention (MHA at 7B)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden ⅔ · 4d (LLaMA)", "p5"], zoom: { k: "glu", act: "SiLU", d: "4,096", ff: "⅔·4d", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head → action bins", call: ["7 tokens per action, 256 bins (1st–99th pct)", "p2"],
              zoom: { k: "rows", title: "Parallel action decoding", rows: ["10 × 7 action slots ([x], [θ], [g])", "full attention inside the chunk", "one forward pass for all slots", "argmax → bin index", "de-normalise → 7-DoF actions"] } } ],
          output: { label: "subgoal codes hⱼ, then 70 action tokens" } },
        { mod: "rq", title: "RQ depth transformer", sub: "+ RQ-VAE decoder", compact: true,
          input: { label: "Code embedding hⱼ", caption: "from the LLM, one per position" },
          rows: [
            { t: "attn", label: "Depth transformer", call: ["Writes D = 4 residual codes in turn", "p2", "p4"] },
            { t: "conv", label: "RQ-VAE decoder", call: ["16 × 16 × 4 codes → 256² image", "p1", "p4"] } ],
          output: { label: "subgoal image ŝₜ₊ₙ" } }
      ],
      links: [{ from: "vt", to: "llm", toRow: "input", label: "256 code embeddings" }]
    },
    modules: [
      { id: "vt", role: "vision-enc", name: "VILA-U vision tower", sub: "SigLIP-L/16 · RQ depth 4", col: 0, frozen: true, short: "Vision tower",
        note: "Text-aligned discrete tokenizer: SigLIP encoder, residual quantizer (codebook 16,384) and RQ-VAE decoder." },
      { id: "llm", role: "vlm", name: "VILA-U LLM (LLaMA-2-7B)", sub: "32 × 4096 · 32 heads", col: 1, frozen: false, main: true, short: "LLM",
        stack: { rows: [
          { t: "in", label: "[ℓ | sₜ codes | subgoal codes | action slots]", dims: "causal except the action block", c: "data-2" },
          { t: "linear", label: "Projector: code embedding → 4,096" },
          { t: "block", label: "LLaMA decoder block (pre-norm)", n: "32", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MHA · 32 heads · RoPE · hybrid mask" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU feed-forward" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "LM head (text, action bins) · hⱼ for image positions" },
          { t: "out", label: "subgoal image codes, then 70 action tokens", dims: "10 actions × 7", c: "data-3" } ],
          facts: [["Base", ["VILA-U 7B (LLaMA-2-7B)", "p1", "p4"]], ["Width / depth / heads", ["4,096 / 32 / 32", "p5"]], ["Action bins", ["256 per dim, 1st–99th percentile", "p2"]], ["Chunk", ["10 actions", "p2"]], ["Trained parts", ["LLM, projector, depth transformer", "p2"]]] } },
      { id: "rq", role: "codec", name: "RQ depth transformer", sub: "4 codes / position", col: 2, frozen: false, short: "Depth tf.",
        note: "Predicts the residual codes of each image position from the LLM's code embedding; the RQ-VAE decoder turns codes into pixels." }
    ],
    inputs: [
      { to: "vt", mod: "vision", label: "current image sₜ", n: "256 × 256", k: 4 },
      { to: "llm", mod: "lang", label: "instruction ℓ", n: "text tokens", k: 3 }
    ],
    outputs: [
      { from: "llm", mod: "action", label: "action chunk", n: "10 × 7 tokens", k: 5 },
      { from: "rq", mod: "future", label: "subgoal image ŝₜ₊ₙ", n: "16 × 16 × 4 codes", k: 4 }
    ],
    links: [
      { from: "vt", to: "llm", kind: "prefix", label: "projector|256 positions" },
      { from: "llm", to: "rq", kind: "feeds", label: "code embedding hⱼ" }
    ],
    mask: { name: "Hybrid (causal + full action block)", ref: "p1", axes: [{ label: "ℓ + image", short: "ℓ+sₜ", mod: "vision" }, { label: "subgoal image", short: "ŝ", mod: "future" }, { label: "actions", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "Inside the prefix and the subgoal image attention is causal (next-token); inside the action block it is full (Fig. 3)." },
    callouts: [
      "<b>No official code</b> was released; layer sizes come from the VILA-U paper (LLaMA-2-7B, SigLIP-Large, codebook 16,384) and the LLaMA papers.",
      "Writing 256 image positions before the actions costs about <b>7×</b> the time of direct action generation (§5)."
    ]
  });

  /* ------------------------------------------------------------------ WorldVLA */
  var WV = "alibaba-damo-academy/WorldVLA", WVC = "ebdc36d";
  RB.arch.spec({
    id: "worldvla", method: "worldvla", name: "WorldVLA", year: 2025, parent: "openvla",
    diffRows: ["vision", "backbone", "output", "attention", "chunk", "train"],
    figRef: "Cen et al. Figs. 2–3 · §3.2–3.3 · §4.1", prov: "worldvla branch",
    lede: "Chameleon with one shared vocabulary of text, image and action tokens. The same weights act as a policy (image → action tokens) and as a world model (image + action → next frame), and an attention mask hides earlier actions in a chunk.",
    sources: {
      p1: { kind: "paper", ref: "Cen et al. 2025, §3.2 (architecture, tokenizers)", url: "https://arxiv.org/abs/2506.21539" },
      p2: { kind: "paper", ref: "Cen et al. 2025, §3.3 and Fig. 3 (data, mask, loss)", url: "https://arxiv.org/abs/2506.21539" },
      p3: { kind: "paper", ref: "Cen et al. 2025, §4.1 training setting and Table 5", url: "https://arxiv.org/abs/2506.21539" },
      c1: gh(WV, WVC, "worldvla/model/chameleon/configuration_chameleon.py"),
      c2: gh(WV, WVC, "worldvla/model/modeling_xllmx_chameleon_ck.py"),
      c3: gh(WV, WVC, "worldvla/pretrain_solver_awm_w_ck.py"),
      c4: gh(WV, WVC, "worldvla/model/chameleon/modeling_chameleon.py"),
      c5: gh(WV, WVC, "worldvla/data/item_processor.py")
    },
    summary: {
      pattern: ["Autoregressive unified video-action model", "p1"],
      params: ["7B (Chameleon-7B initialisation, --model_size 7B)", "c3"],
      vision: ["Chameleon VQ-GAN, frozen: 16× down, codebook 8,192 → 256 tokens at 256², 1,024 at 512²", "p1", "c1", "c5"],
      backbone: ["Chameleon 7B: 32 layers, width 4,096, 32 heads, SwiGLU 11,008, QK-norm", "c1", "c4"],
      head: ["None: the LM head over one 65,536-token vocabulary", "p1"],
      output: ["K actions × 7 tokens (policy) or next-frame image tokens (world model)", "p1", "p2"],
      attention: ["Causal; an action block cannot see earlier action blocks", "p2", "c2"],
      cond: ["Prompt + M = 2 history images (policy); image + action + prompt (world model)", "p2", "p3"],
      steps: ["Token-by-token decoding", "p2"],
      chunk: ["K = 5 (K = 10 on LIBERO-Long)", "p3"],
      rate: ["3.13 FPS with 2 frames and chunking", "p3"],
      latency: null,
      train: ["LIBERO only; mixed data; loss = action + 0.04 × world", "p2", "p3"]
    },
    changes: [
      "Backbone is <b>Chameleon</b>, an early-fusion model that already reads and writes image tokens (VQ-GAN, codebook 8,192).",
      "Adds a <b>world-model task</b> in the same weights: given an image and an action, write the next frame's tokens.",
      "Actions come in <b>chunks</b> (K = 5 or 10) under a mask that hides earlier actions of the chunk.",
      "Reads <b>M = 2</b> history images instead of one.",
      "Trained from Chameleon on LIBERO only, with no robot pretraining."
    ],
    blueprint: {
      headline: "WorldVLA: one vocabulary, two jobs",
      note: "Images are tokenized offline by the frozen VQ-GAN and spliced between [BOI]/[EOI] into Chameleon's sequence. Action-model samples end in K action blocks of 7 tokens; world-model samples end in the next frame's image tokens. Only the target tokens carry loss.",
      towers: [
        { mod: "vq", title: "Chameleon VQ-GAN", sub: "image tokenizer, frozen", compact: true,
          input: { label: "Image 512 × 512", caption: "M = 2 history frames" },
          rows: [
            { t: "conv", label: "Conv encoder, 5 levels", call: ["Channel mult 1, 1, 2, 2, 4 → 16× down", "p1", "c1"] },
            { t: "linear", label: "Vector quantizer", call: ["Codebook 8,192, code dim 256", "p1", "c1"] } ],
          output: { label: "1,024 tokens per 512² image" } },
        { mod: "lm", title: "Chameleon 7B", sub: "early-fusion decoder, one vocabulary",
          input: { label: "[text | images | actions]", caption: "[BOS] prompt [BOI] … [EOI] [BOA] … [EOA]" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["Vocab 65,536: 8,192 image + 256 action ids", "p1", "c1"] },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Masked self-attention · QK-norm", side: "RoPE", call: ["32 heads, head dim 128, LayerNorm on q, k", "c1", "c4"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Attention (MHA)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden layer dimension of 11,008", "c1", "c4"], zoom: { k: "glu", act: "SiLU", d: "4,096", ff: "11,008", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head (65,536)", call: ["Loss on action or image tokens only", "p2"],
              zoom: { k: "rows", title: "Action chunk decoding", rows: ["[BOA] opens an action block", "7 tokens: 3 Δpos, 3 Δrot, gripper", "256 bins over the data range", "[EOA]; the next block starts", "earlier action blocks masked out"] } } ],
          output: { label: "action tokens or next-frame tokens" } }
      ],
      links: [{ from: "vq", to: "lm", toRow: "input", label: "image tokens" }]
    },
    modules: [
      { id: "vq", role: "codec", name: "Chameleon VQ-GAN", sub: "512² → 32 × 32 codes", col: 0, frozen: true, short: "VQ-GAN",
        note: "Images are tokenized under no_grad in the data pipeline (item_processor.py)." },
      { id: "lm", role: "vlm", roleLabel: "Unified AR model", name: "Chameleon 7B", sub: "32 × 4096 · 32 heads", col: 1, frozen: false, main: true, short: "Chameleon",
        stack: { rows: [
          { t: "in", label: "[prompt | M images | K action blocks]", dims: "or [prompt | image | action | next image]", c: "data-2" },
          { t: "embed", label: "Token embedding", dims: "65,536 × 4,096" },
          { t: "block", label: "Chameleon decoder block", n: "32", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MHA · 32 heads · QK LayerNorm · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 4,096 → 11,008 → 4,096" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "LM head", dims: "→ 65,536 logits" },
          { t: "out", label: "action tokens or image tokens", dims: "7 per action · 1,024 per 512² frame", c: "data-3" } ],
          facts: [["Width / depth / heads", ["4,096 / 32 / 32", "c1"]], ["FFN", ["11,008, SiLU gate", "c1", "c4"]], ["Vocabulary", ["65,536 incl. 8,192 image + 256 action", "p1"]], ["Loss weight α", ["0.04 on world-model tokens", "p3"]], ["Mask", ["action block ⟂ earlier action blocks", "c2"]]] } },
      { id: "act", role: "codec", name: "Action tokenizer", sub: "7 dims × 256 bins", col: 2, frozen: true, short: "Action tok.",
        note: "3 relative positions, 3 relative angles, 1 absolute gripper state; bin widths from the training range." }
    ],
    inputs: [
      { to: "vq", mod: "vision", label: "M = 2 history images", n: "256² or 512²", k: 4 },
      { to: "lm", mod: "lang", label: "task prompt", n: "BPE text", k: 3 },
      { to: "lm", mod: "action", label: "action (world model)", n: "7 tokens", k: 2 }
    ],
    outputs: [
      { from: "lm", mod: "future", label: "next-frame tokens", n: "world model", k: 4 },
      { from: "act", mod: "action", label: "K actions", n: "7 tokens each", k: 5 }
    ],
    links: [
      { from: "vq", to: "lm", kind: "prefix", label: "image tokens|256 or 1,024 / image" },
      { from: "lm", to: "act", kind: "feeds", label: "action ids → bins" }
    ],
    mask: { name: "Causal, earlier actions hidden", ref: "p2", axes: [{ label: "text", short: "ℓ", mod: "lang" }, { label: "images", short: "img", mod: "vision" }, { label: "action 1", short: "a₁", mod: "action" }, { label: "action 2", short: "a₂", mod: "action" }], m: ["1000", "1100", "1110", "1101"],
      note: "Within each block attention stays causal. World-model sequences use the plain causal mask (Fig. 3c)." },
    callouts: [
      "The released forward pass builds the mask in <code>generate_att_mask_3</code>: token ids 10004 / 15004 open and close each action block, and every action block after the last image is cut off from earlier action blocks.",
      "Code is on the repository's <code>worldvla</code> branch; <code>main</code> now hosts the successor RynnVLA-002.",
      "Higher resolution helps: 512² inputs (1,024 tokens) beat 256² (Table 2), matching Chameleon's 512² pretraining."
    ]
  });

  /* ------------------------------------------------------------------ F1 */
  var F1 = "InternRobotics/F1-VLA", F1C = "633ef63";
  RB.arch.spec({
    id: "f1", method: "f1", name: "F1", year: 2025, parent: "pi0",
    diffRows: ["params", "vision", "head", "output", "attention", "steps", "train"],
    figRef: "Lv et al. Fig. 2 · §2.2–2.4 · App. B, Table 8", prov: "f1_config.json",
    lede: "π0 plus a third expert. A Gemma-style generation expert predicts a foresight image of the next frame by next-scale (VAR) token prediction; the action expert then denoises the chunk while attending to both the VLM and the foresight tokens.",
    sources: {
      p1: { kind: "paper", ref: "Lv et al. 2025, §2.1–2.2 and Fig. 2", url: "https://arxiv.org/abs/2509.06951" },
      p2: { kind: "paper", ref: "Lv et al. 2025, §2.3 (training objectives)", url: "https://arxiv.org/abs/2509.06951" },
      p3: { kind: "paper", ref: "Lv et al. 2025, §2.4 (implementation)", url: "https://arxiv.org/abs/2509.06951" },
      p4: { kind: "paper", ref: "Lv et al. 2025, App. B, Table 8", url: "https://arxiv.org/abs/2509.06951" },
      c1: gh(F1, F1C, "f1_vla/config/f1_config.json"),
      c2: gh(F1, F1C, "f1_vla/src/models/modeling_f1.py"),
      c3: gh(F1, F1C, "f1_vla/src/models/paligemma_with_expert.py")
    },
    summary: {
      pattern: ["Three-expert MoT VLA (understanding + foresight + action)", "p1"],
      params: ["4.2B", "p1"],
      vision: ["SigLIP So400m/14 at 224² (understanding); VAR residual VQ-VAE, codebook 4,096, at 256² (foresight)", "p4", "c1"],
      backbone: ["Gemma 2B (PaliGemma, from π0): 18 layers, width 2,048, 8 query / 1 KV heads", "p3", "c1"],
      head: ["Generation and action experts: Gemma, 18 layers, width 1,024, MLP 4,096", "c1"],
      output: ["Foresight ôₜ₊₁ (VQ tokens, next-scale) and velocity on an action chunk", "p1", "p2"],
      attention: ["UGA progressive: gen → und, act → und + gen, nothing flows back", "p1"],
      cond: ["Flow time τ via an MLP on [action ‖ sinusoid(τ)] (π0 style)", "c2"],
      steps: ["Foresight: 4 scales at inference (10 in Stage I). Actions: 10 flow steps", "p3", "p4"],
      chunk: ["50 real robots · 4 LIBERO · 8 SimplerEnv", "p4"],
      rate: null, latency: null,
      train: ["Stage I: align gen expert (und frozen). Stage II: ≈ 330k episodes. Post-train; Gen:Act loss 0.1:1", "p3", "p4"]
    },
    changes: [
      "Adds a <b>generation expert</b> (Gemma-style, width 1,024, random init) between the VLM and the action expert.",
      "It predicts a <b>foresight image</b> of the next frame by VAR next-scale prediction over residual VQ tokens.",
      "Attention is <b>progressive</b>: generation sees understanding, actions see both, nothing flows back.",
      "A 1-D temporal conv folds 4 history frames into one set of multi-scale tokens.",
      "Actions become <b>inverse dynamics toward the foresight</b>; a 3-stage recipe first aligns the new expert."
    ],
    blueprint: {
      headline: "F1: understand, foresee, then act",
      note: "Three Gemma-style experts run layer by layer in lockstep and meet only in self-attention. The understanding tokens are the prefix; foresight tokens see them; action tokens see both. Each expert keeps its own weights.",
      towers: [
        { mod: "und", title: "Gemma 2B (PaliGemma)", sub: "understanding expert, from π0",
          input: { label: "Image + text tokens", caption: "SigLIP 224², instruction ℓ" },
          rows: [
            { t: "embed", label: "SigLIP tokens + text embed", call: ["256 image tokens · vocab 257,152", "c1"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Multi-query attention", side: "RoPE", call: ["8 query heads share 1 KV head (dim 256)", "c1"], callDy: -26, zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Hidden layer dimension of 16,384", "c1"], zoom: { k: "glu", act: "GELU", d: "2,048", ff: "16,384", title: "Feed forward (GeGLU), und." } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" } ],
          output: { label: "keys and values for gen and act" } },
        { mod: "gen", title: "Generation expert", sub: "Gemma-style, random init",
          input: { label: "Multi-scale VQ tokens", caption: "4 history frames, 10 scales each" },
          rows: [
            { t: "conv", label: "Temporal conv (k 4, stride 4)", call: ["4 frames → 679 history tokens", "c1", "c2"] },
            { t: "linear", label: "Linear 32 → 1,024 + pos, level", call: ["VQ latent 32-d, codebook 4,096", "c1"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Scale-causal attention", call: ["Sees und tokens; 8 query / 1 KV heads", "p1", "c1"], callDy: -26 },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Width 1,024 · hidden 4,096", "c1"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "LayerNorm · logits (4,096)", call: ["Scales 1–4 at inference", "p3", "c1"],
              zoom: { k: "rows", title: "Next-scale foresight (VAR)", rows: ["scale 1: 1 × 1 token", "scale 2: 2 × 2 tokens", "scale 3: 3 × 3 tokens", "scale 4: 4 × 4, inference stops", "Stage I: 10 scales up to 16 × 16"] } } ],
          output: { label: "foresight tokens ôₜ₊₁" } },
        { mod: "act", title: "Action expert", sub: "Gemma-style, from π0",
          input: { label: "State q + noisy actions Aτ", caption: "chunk 4–50 by task, time τ" },
          rows: [
            { t: "linear", label: "State projection", call: ["q (padded 32) → 1,024", "c1", "c2"] },
            { t: "mlp", label: "Action + time MLP", call: ["[W aτ ‖ sinusoid(τ)] → 2 Linear → 1,024", "c2"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Multi-query attention", call: ["Sees und + gen tokens; own weights", "p1", "c3"], callDy: -26 },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Width 1,024 · hidden 4,096", "c1"], zoom: { k: "glu", act: "GELU", d: "1,024", ff: "4,096", title: "Feed forward (GeGLU), act." } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Action output projection", call: ["1,024 → 32 (padded action dim)", "c1", "c2"] } ],
          output: { label: "velocity vθ; 10 Euler steps" } }
      ],
      shared: [
        { a: ["und", "att"], b: ["gen", "att"], label: "shared self-attention" },
        { a: ["gen", "att"], b: ["act", "att"], label: "shared self-attention" }
      ]
    },
    modules: [
      { id: "und", role: "vlm", name: "PaliGemma (und.)", sub: "18 × 2048 · MQA", col: 0, frozen: false, short: "Und. expert",
        note: "SigLIP So400m/14 + Gemma 2B, inherited from π0; frozen in Stage I, trained afterwards." },
      { id: "gen", role: "video-gen", roleLabel: "Foresight expert", name: "Generation expert", sub: "18 × 1024 · VAR tokens", col: 1, frozen: false, main: true, short: "Gen. expert",
        stack: { rows: [
          { t: "in", label: "residual VQ tokens of 4 history frames", dims: "10 scales, 1 × 1 … 16 × 16", c: "data-4" },
          { t: "conv", label: "Temporal Conv1d, kernel 4, stride 4", dims: "4 frames → 1" },
          { t: "linear", label: "Linear 32 → 1,024 · + SOS, position, level embeddings" },
          { t: "block", label: "Gemma block (own weights)", n: "18", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MQA · 8 q / 1 KV · scale-causal · joint with und" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 1,024 → 4,096 → 1,024" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "LayerNorm" },
          { t: "linear", label: "Linear 1,024 → 4,096 code logits" },
          { t: "out", label: "foresight tokens, scales 1–4", dims: "decoded to ôₜ₊₁ by the VQ-VAE", c: "data-4" } ],
          facts: [["Width / depth", ["1,024 / 18", "c1"]], ["Heads", ["8 query, 1 KV, head dim 256", "c1"]], ["Scales", ["1, 2, 3, 4, 5, 6, 8, 10, 13, 16", "c1"]], ["VQ-VAE", ["from VAR, codebook 4,096, z 32", "p3", "c1"]], ["Init", ["random", "p3"]]] } },
      { id: "act", role: "action-expert", name: "Action expert", sub: "18 × 1024 · MLP 4096", col: 2, frozen: false, short: "Act. expert" }
    ],
    inputs: [
      { to: "und", mod: "vision", label: "current image oₜ", n: "256 tokens", k: 4 },
      { to: "und", mod: "lang", label: "instruction ℓ", n: "≤ 48 tokens", k: 3 },
      { to: "gen", mod: "vision", label: "history frames", n: "4 → temporal conv", k: 4 },
      { to: "act", mod: "state", label: "state qₜ", n: "1 token", k: 1 },
      { to: "act", mod: "action", label: "noisy chunk Aτ", n: "4–50 steps", k: 5, noisy: true }
    ],
    outputs: [
      { from: "gen", mod: "future", label: "foresight ôₜ₊₁", n: "scales 1–4 = 30 tokens", k: 3 },
      { from: "act", mod: "action", label: "velocity vθ", n: "chunk × 32", k: 5 }
    ],
    links: [
      { from: "und", to: "gen", kind: "joint-attn", label: "shared self-attn|gen sees und" },
      { from: "gen", to: "act", kind: "joint-attn", label: "shared self-attn|act sees und + gen" }
    ],
    mask: { name: "UGA progressive", ref: "p1", axes: [{ label: "image + text", short: "und", mod: "vision" }, { label: "foresight", short: "gen", mod: "future" }, { label: "state + actions", short: "act", mod: "action" }], m: ["100", "110", "111"],
      note: "Inside the foresight block attention is scale-causal; inside und and act it is bidirectional (§2.2)." },
    callouts: [
      "Inference stops foresight at scale 4: 1 + 4 + 9 + 16 = <b>30 tokens</b> instead of all 680 of the 10-scale pyramid.",
      "Understanding and action experts start from π0; only the generation expert is new."
    ]
  });

  /* ------------------------------------------------------------------ Motus */
  var MO = "thu-ml/Motus", MOC = "f771216";
  RB.arch.spec({
    id: "motus", method: "motus", name: "Motus", year: 2025, parent: "uwm",
    diffRows: ["params", "vision", "backbone", "head", "attention", "cond", "steps", "chunk", "train"],
    figRef: "Bi et al. Figs. 1–3 · §4 · App. Table 11", prov: "configs/ac_one.yaml (real robot)",
    lede: "Three pretrained experts in one Mixture-of-Transformers: Wan2.2-5B for video, a new action expert, and a small understanding expert on Qwen3-VL-2B features. Their tokens share one self-attention per layer; separate flow times pick the mode.",
    sources: {
      p1: { kind: "paper", ref: "Bi et al. 2025, §4.1 and Fig. 1", url: "https://arxiv.org/abs/2512.13030" },
      p2: { kind: "paper", ref: "Bi et al. 2025, §4.2 and Fig. 3 (latent actions)", url: "https://arxiv.org/abs/2512.13030" },
      p3: { kind: "paper", ref: "Bi et al. 2025, §4.3 and Table 1 (training)", url: "https://arxiv.org/abs/2512.13030" },
      p4: { kind: "paper", ref: "Bi et al. 2025, App. §9.1, Table 11", url: "https://arxiv.org/abs/2512.13030" },
      c1: gh(MO, MOC, "configs/ac_one.yaml"),
      c2: gh(MO, MOC, "models/action_expert.py"),
      c3: gh(MO, MOC, "models/motus.py"),
      c4: gh(MO, MOC, "models/und_expert.py"),
      c5: gh(MO, MOC, "bak/wan/configs/wan_ti2v_5B.py"),
      c6: gh(MO, MOC, "configs/robotwin.yaml")
    },
    summary: {
      pattern: ["Dual-system WAM: joint self-attention (MoT)", "p1"],
      params: ["≈ 8B: video 5.00B, VLM 2.13B, action expert 641.5M, und. expert 253.5M", "p4"],
      vision: ["Wan2.2 VAE latents (48 ch) for video; frozen Qwen3-VL-2B reads image + instruction", "p1", "c1", "c3"],
      backbone: ["Wan2.2-TI2V-5B DiT: 30 layers, width 3,072, 24 heads, FFN 14,336", "p1", "c5"],
      head: ["Action expert: 30 layers, width 1,024, FFN 4,096, AdaLN. Und. expert: 30 layers, width 512", "p4", "c1", "c2"],
      output: ["Velocities on 8 video frames (5 Hz) and 48 actions (30 Hz)", "p4", "c1"],
      attention: ["Tri-model joint attention: all experts' tokens in one bidirectional self-attention per layer", "p1", "c3"],
      cond: ["Separate flow times τᵥ, τₐ via AdaLN (UniDiffuser-style); umT5 text into the video expert", "p1", "c3", "c5"],
      steps: ["10 rectified-flow steps; logit-normal time sampling", "p4", "c6"],
      chunk: ["8 frames + 48 actions (real robots); the RoboTwin config uses 16 actions", "p4", "c1", "c6"],
      rate: null, latency: null,
      train: ["3 stages: video only → latent actions (VLM frozen) → target-robot SFT; 6-level data pyramid", "p3"]
    },
    changes: [
      "Three <b>pretrained experts</b> (Wan2.2-5B video, Qwen3-VL-2B understanding, a new action expert) replace UWM's single DiT trained from scratch.",
      "Experts keep separate weights and meet only in <b>Tri-model Joint Attention</b> (MoT).",
      "Keeps UWM's <b>per-modality timesteps</b> to switch among VLA, world model, IDM, video generator and joint modes.",
      "The action expert pretrains on <b>optical-flow latent actions</b> (14-D) from action-less video.",
      "Video is sparse (5 Hz), actions dense (30 Hz), to balance token counts."
    ],
    blueprint: {
      headline: "Motus: three experts, one attention",
      note: "At every one of the 30 layers the understanding, video and action tokens are projected into Wan's 24 heads and attend to one another in a single softmax; each expert then applies its own output projection and FFN. Video and action tokens are AdaLN-modulated by their own flow times.",
      towers: [
        { mod: "und", title: "Understanding expert", sub: "on Qwen3-VL-2B features", compact: true,
          input: { label: "Qwen3-VL-2B tokens", caption: "image + instruction; VLM frozen" },
          rows: [
            { t: "mlp", label: "Adapter MLP (3 layers)", call: ["2,048 → 512", "c1", "c4"] },
            { t: "block", n: "30", rows: [
              { t: "norm", label: "LayerNorm" },
              { id: "att", t: "attn", label: "Joint attention", call: ["Into Wan's 24 heads × 128", "c4"], callDy: -26 },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "FFN (GELU)", call: ["512 → 2,048 → 512", "c1", "c4"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "und tokens (no output head)" } },
        { mod: "wan", title: "Wan2.2-5B video DiT", sub: "video generation expert",
          input: { label: "Frame latents", caption: "Wan2.2 VAE, 48 ch; first frame clean" },
          rows: [
            { t: "conv", label: "Patchify (1, 2, 2)", call: ["48 × 4 → 3,072", "c5", "c3"] },
            { t: "block", n: "30", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { id: "att", t: "attn", label: "Tri-model joint attention", side: "RoPE", call: ["24 heads × 128, RMSNorm on q, k", "c5", "c3"], callDy: -26, zoom: { k: "heads", q: 24, kv: 24, hd: 128, title: "Joint attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm (affine)" },
              { t: "attn", label: "Cross-attention to umT5", call: ["umT5-XXL instruction tokens", "c5"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 14,336", "c5"], zoom: { k: "mlp", act: "GELU (tanh)", d: "3,072", ff: "14,336", title: "Feed forward, video expert" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Head LayerNorm · shift, scale" },
            { t: "linear", label: "Unpatchify → 48-ch latents" } ],
          output: { label: "velocity on 8 future frames" } },
        { mod: "act", title: "Action expert", sub: "new, same depth as Wan",
          input: { label: "State + noisy actions", caption: "+ 4 registers when fine-tuning" },
          rows: [
            { t: "mlp", label: "State / action encoder", call: ["14-D → 1,024", "c1", "c2"],
              zoom: { k: "rows", title: "Latent actions (pretraining)", rows: ["DPFlow optical flow → RGB image", "DC-AE encoder → 4 × 512 tokens", "small encoder → 14-D action", "replaces real actions in Stage 2", "10 % labelled data anchors it"] } },
            { t: "block", n: "30", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN",
                zoom: { k: "rows", title: "AdaLN from τₐ", rows: ["sinusoid(τₐ), 256-d → MLP → 1,024", "SiLU → Linear → 6 × 1,024", "+ learned per-block table", "shift, scale, gate: attention", "shift, scale, gate: FFN"] } },
              { id: "att", t: "attn", label: "Tri-model joint attention", call: ["QKV 1,024 → 24 × 128; out 3,072 → 1,024", "c2", "c3"], callDy: -26 },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["1,024 → 4,096 → 1,024", "p4", "c1", "c2"], zoom: { k: "mlp", act: "GELU (tanh)", d: "1,024", ff: "4,096", title: "Feed forward, action expert" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "linear", label: "Action decoder (AdaLN head)", call: ["→ 14-D actions", "c1", "c2"] } ],
          output: { label: "velocity on 48 actions" } }
      ],
      shared: [
        { a: ["und", "att"], b: ["wan", "att"], label: "one softmax" },
        { a: ["wan", "att"], b: ["act", "att"], label: "one softmax" }
      ]
    },
    modules: [
      { id: "vlm", role: "vlm", name: "Qwen3-VL-2B", sub: "last-layer tokens", col: 0, frozen: true, short: "Qwen3-VL" },
      { id: "und", role: "net", roleLabel: "Understanding expert", name: "Und. expert", sub: "30 × 512 · no AdaLN", col: 1, frozen: false, short: "Und. expert" },
      { id: "wan", role: "video-gen", name: "Wan2.2-5B video DiT", sub: "30 × 3072 · 24 heads", col: 2, frozen: false, main: true, short: "Wan2.2-5B",
        stack: { rows: [
          { t: "in", label: "[clean first frame | noisy future latents]", dims: "8 frames @ 5 Hz, 48-ch VAE latents", c: "data-4" },
          { t: "conv", label: "Patch embedding (1, 2, 2)", dims: "192 → 3,072" },
          { t: "block", label: "Wan block, joint with und + act", n: "30", rows: [
            { t: "norm", label: "LayerNorm · AdaLN(τᵥ)" }, { t: "attn", label: "Joint self-attention · 24 heads · RoPE · QK RMSNorm" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "Cross-attention to umT5" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN(τᵥ)" }, { t: "ffn", label: "FFN 3,072 → 14,336 → 3,072 · GELU" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "linear", label: "Head: AdaLN · unpatchify" },
          { t: "out", label: "velocity on future latents", dims: "loss masks the first frame", c: "data-4" } ],
          facts: [["Width / depth / heads", ["3,072 / 30 / 24", "c5"]], ["FFN", ["14,336", "c5"]], ["VAE stride", ["(4, 16, 16)", "c5"]], ["Params", ["5.00B", "p4"]], ["Loss weights", ["video 1.0, action 1.0", "c6"]]] } },
      { id: "act", role: "action-expert", name: "Action expert", sub: "30 × 1024 · AdaLN", col: 3, frozen: false, params: "641.5M", short: "Act. expert" }
    ],
    inputs: [
      { to: "vlm", mod: "vision", label: "image + instruction", n: "Qwen3-VL input", k: 4 },
      { to: "wan", mod: "vision", label: "first frame", n: "clean", k: 2 },
      { to: "wan", mod: "future", label: "noisy frames", n: "8 @ 5 Hz", k: 4, noisy: true },
      { to: "act", mod: "state", label: "state qₜ", n: "1 token", k: 1 },
      { to: "act", mod: "action", label: "noisy (latent) actions", n: "48 @ 30 Hz", k: 5, noisy: true }
    ],
    outputs: [
      { from: "wan", mod: "future", label: "vₒ → future video", n: "8 frames", k: 4 },
      { from: "act", mod: "action", label: "vₐ → action chunk", n: "48", k: 5 }
    ],
    links: [
      { from: "vlm", to: "und", kind: "feeds", label: "last-layer tokens|MLP 2,048 → 512" },
      { from: "und", to: "wan", kind: "joint-attn", label: "tri-model|joint attention" },
      { from: "wan", to: "act", kind: "joint-attn", label: "tri-model|joint attention" }
    ],
    mask: { name: "Mutual (no mask)", ref: "p1", axes: [{ label: "understanding", short: "und", mod: "lang" }, { label: "video", short: "o", mod: "future" }, { label: "actions", short: "a", mod: "action" }], m: ["111", "111", "111"],
      note: "The released joint attention concatenates all three token sets without a mask; modes are picked by setting τᵥ or τₐ." },
    callouts: [
      "Chunk sizes are per embodiment: the real-robot configs use 8 frames × ratio 6 = <b>48 actions</b>; the RoboTwin config uses ratio 2 and a 3× downsample (16 actions).",
      "OpenWAM calls this pattern Dual-System MoT: pretrained video and action experts share self-attention layer by layer."
    ]
  });

  /* ------------------------------------------------------------------ Cosmos Policy */
  var CP = "NVlabs/cosmos-policy", CPC = "18a2acc";
  RB.arch.spec({
    id: "cosmos-policy", method: "cosmos-policy", name: "Cosmos Policy", year: 2026, parent: "uwm",
    diffRows: ["params", "vision", "backbone", "head", "output", "cond", "steps", "train"],
    figRef: "Kim et al. Figs. 2, 8, 12 · §3–4 · App. A", prov: "2B LIBERO config",
    lede: "Cosmos-Predict2-2B fine-tuned with no new layers. Proprioception, the action chunk and the value are written into latent frames of the video diffusion sequence, so one denoiser is policy, world model and value function.",
    sources: {
      p1: { kind: "paper", ref: "Kim et al. 2026, §3 (Cosmos-Predict2 preliminaries)", url: "https://arxiv.org/abs/2601.16163" },
      p2: { kind: "paper", ref: "Kim et al. 2026, §4.1 and Fig. 2 (latent injection)", url: "https://arxiv.org/abs/2601.16163" },
      p3: { kind: "paper", ref: "Kim et al. 2026, §4.2 (joint training, decoding)", url: "https://arxiv.org/abs/2601.16163" },
      p4: { kind: "paper", ref: "Kim et al. 2026, App. A.1–A.2.1 (injection, noise)", url: "https://arxiv.org/abs/2601.16163" },
      p5: { kind: "paper", ref: "Kim et al. 2026, App. A.2.2–A.3.1 (training, evaluation)", url: "https://arxiv.org/abs/2601.16163" },
      p6: { kind: "paper", ref: "Kim et al. 2026, App. A.4.2 (latency)", url: "https://arxiv.org/abs/2601.16163" },
      c1: gh(CP, CPC, "cosmos_policy/config/experiment/cosmos_policy_experiment_configs.py"),
      c2: gh(CP, CPC, "cosmos_policy/_src/predict2/configs/video2world/defaults/net.py"),
      c3: gh(CP, CPC, "cosmos_policy/_src/predict2/networks/minimal_v4_dit.py"),
      c4: gh(CP, CPC, "cosmos_policy/tokenizers/wan2pt1.py")
    },
    summary: {
      pattern: ["Single-system joint DiT (video + action in one sequence)", "p2"],
      params: ["2B (Cosmos-Predict2-2B-Video2World), all weights fine-tuned", "p1", "p5"],
      vision: ["Wan2.1 VAE, frozen: 4× time, 8× space, 16 channels; one latent frame per camera", "p1", "p2", "c4"],
      backbone: ["Cosmos-Predict2-2B DiT: 28 blocks, width 2,048, 16 heads, MLP ratio 4", "c2", "c3"],
      head: ["None: actions, proprio and value are latent frames, read back by averaging the copies", "p2", "p4"],
      output: ["Clean latents x̂₀ (EDM denoiser) for actions, future state and value", "p1", "p2"],
      attention: ["Full self-attention over all latent frames; cross-attention to T5-XXL text", "p1", "c3"],
      cond: ["Clean conditioning frames (frame replace); noise level σ via AdaLN-LoRA", "p1", "c1", "c3"],
      steps: ["5 (LIBERO, RoboCasa) or 10 (ALOHA) steps; σ from 80 down to 4", "p4", "p5"],
      chunk: ["16 LIBERO · 32 (16 run) RoboCasa · 50 ALOHA at 25 Hz", "p5"],
      rate: null,
      latency: ["0.61 s (5 steps) or 0.95 s (10 steps) per chunk on one H100", "p6"],
      train: ["One stage; batches 50 % demos (policy), 25 % world model, 25 % value", "p3", "p5"]
    },
    changes: [
      "Starts from a <b>pretrained 2B video model</b> (Cosmos-Predict2) instead of training a DiT from scratch.",
      "No new modules: actions, proprioception and value are <b>written into latent frames</b> (normalised, duplicated to fill H′ × W′ × 16).",
      "Each camera view is its own latent frame: 11 frames for three cameras, 9 in the LIBERO config.",
      "Also predicts a <b>value</b> V(s′), so best-of-N planning can rank imagined futures.",
      "EDM denoising with a heavier high-noise tail; conditioning is by clean frames rather than separate timesteps."
    ],
    blueprint: {
      headline: "Cosmos Policy: actions as video frames",
      note: "Blank placeholder images take the slots of proprio, actions and value; after VAE encoding those latent frames are overwritten with the normalised vectors. The DiT denoises the target frames while the conditioning frames stay clean; which frames are clean decides whether it acts as policy, world model or value function.",
      towers: [
        { mod: "vae", title: "Wan2.1 VAE", sub: "tokenizer, frozen", compact: true,
          input: { label: "Frames, 4 copies each", caption: "blank · s · a · s′ · V slots" },
          rows: [
            { t: "conv", label: "Causal 3-D VAE encoder", call: ["4× time, 8× space, 16 ch", "p1"] },
            { t: "linear", label: "Latent injection", call: ["Vectors overwrite placeholders", "p2", "p4"],
              zoom: { k: "rows", title: "Latent injection", rows: ["action chunk K × d → [−1, 1]", "flatten to K · d values", "duplicate to fill H′ × W′ × 16", "overwrite the placeholder frame", "read back: mean of the copies"] } } ],
          output: { label: "latent frame sequence" } },
        { mod: "dit", title: "Cosmos-Predict2-2B DiT", sub: "EDM denoiser, fully fine-tuned",
          input: { label: "Latent frames", caption: "LIBERO: blank, s (3), a, s′ (3), V = 9" },
          rows: [
            { t: "conv", label: "Patchify (1, 2, 2) · 3-D RoPE", call: ["16 ch × 4 → 2,048", "c2"] },
            { t: "block", n: "28", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN",
                zoom: { k: "rows", title: "AdaLN-LoRA from σ", rows: ["emb(σ) → shared time features", "SiLU → Linear 2,048 → 256", "Linear 256 → 3 × 2,048", "shift, scale, gate"] } },
              { t: "attn", label: "Full self-attention", side: "RoPE", call: ["16 heads, head dim 128", "c2"], zoom: { k: "heads", q: 16, kv: 16, hd: 128, title: "Self-attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "attn", label: "Cross-attention to T5-XXL", call: ["Context width 1,024", "c3"] },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 8,192", "c2", "c3"], zoom: { k: "mlp", act: "GELU", d: "2,048", ff: "8,192", title: "Feed forward (MLP)" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Final AdaLN layer" },
            { t: "linear", label: "Unpatchify → x̂₀ latents", call: ["Lowest σ raised to 4 at sampling", "p4"] } ],
          output: { label: "denoised a, s′ and V frames" } }
      ],
      links: [{ from: "vae", to: "dit", toRow: "input", label: "latent frames" }]
    },
    modules: [
      { id: "t5", role: "lang", name: "T5-XXL", sub: "task description", col: 0, frozen: true, short: "T5-XXL" },
      { id: "dit", role: "joint", roleLabel: "Joint video + action DiT", name: "Cosmos-Predict2-2B", sub: "28 × 2048 · 16 heads", col: 1, frozen: false, main: true, short: "DiT",
        stack: { rows: [
          { t: "in", label: "[blank | s | a | s′ | V] latent frames", dims: "targets noised, conditions clean", c: "data-4" },
          { t: "conv", label: "Patch embedding (1, 2, 2) + 3-D RoPE", dims: "→ 2,048" },
          { t: "block", label: "Cosmos DiT block", n: "28", rows: [
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(σ)" }, { t: "attn", label: "Self-attention · 16 heads" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(σ)" }, { t: "attn", label: "Cross-attention to T5-XXL" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(σ)" }, { t: "ffn", label: "MLP 2,048 → 8,192 → 2,048 · GELU" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "linear", label: "Final layer · unpatchify" },
          { t: "out", label: "x̂₀ for every target frame", dims: "actions / value read without VAE decoding", c: "data-3" } ],
          facts: [["Width / depth / heads", ["2,048 / 28 / 16", "c2"]], ["AdaLN-LoRA rank", ["256", "c2"]], ["Noise", ["log-normal (p 0.7) + U[1, 85] (p 0.3)", "p4", "c1"]], ["Sampling σ", ["80 → 4", "p4"]], ["LIBERO frames", ["9 latent frames, 224 px", "c1"]]] } },
      { id: "vae", role: "codec", name: "Wan2.1 VAE", sub: "4× time · 8× space · 16 ch", col: 2, frozen: true, short: "VAE" }
    ],
    inputs: [
      { to: "t5", mod: "lang", label: "task description", n: "T5 tokens", k: 3 },
      { to: "dit", mod: "state", label: "proprio frame", n: "clean", k: 1 },
      { to: "dit", mod: "action", label: "noisy action frame", n: "chunk K × d", k: 4, noisy: true },
      { to: "dit", mod: "time", label: "noise level σ", n: "EDM", k: 1 },
      { to: "vae", mod: "vision", label: "camera images", n: "wrist + third-person", k: 4 }
    ],
    outputs: [
      { from: "dit", mod: "action", label: "action chunk", n: "mean of copies", k: 4 },
      { from: "dit", mod: "future", label: "future proprio + images", n: "s′ at t + K", k: 4 },
      { from: "dit", mod: "other", label: "value V(s′)", n: "scalar", k: 1 }
    ],
    links: [
      { from: "t5", to: "dit", kind: "cross-attn", label: "T5-XXL embeddings" },
      { from: "vae", to: "dit", kind: "latent", label: "latent frames|+ injected vectors" }
    ],
    mask: { name: "Mutual (no mask)", ref: "p3", axes: [{ label: "state s", short: "s", mod: "vision" }, { label: "action a", short: "a", mod: "action" }, { label: "future s′", short: "s′", mod: "future" }, { label: "value V", short: "V", mod: "other" }], m: ["1111", "1111", "1111", "1111"],
      note: "Which frames are clean decides the task: policy p(a, s′, V | s), world model p(s′, V | s, a), value p(V | s, a, s′)." },
    callouts: [
      "The paper's example has <b>11 latent frames</b> (three cameras); the released LIBERO config sets state_t = 9 (wrist + one third-person camera) at 224 px.",
      "Planning runs best-of-N with N = 8 on 8 H100s: candidate actions, then 3 future-state and value samples per candidate (App. A.4.2)."
    ]
  });

  /* ------------------------------------------------------------------ LingBot-VA */
  var LB = "robbyant/lingbot-va", LBC = "7c6ffa9";
  RB.arch.spec({
    id: "lingbot-va", method: "lingbot-va", name: "LingBot-VA", year: 2026, parent: "motus",
    diffRows: ["params", "head", "attention", "steps", "chunk", "train"],
    figRef: "Li et al. Fig. 2 · §3.2–3.4 · §4.1–4.2", prov: "Paper architecture",
    lede: "An autoregressive video-action world model on Wan2.2-5B. Each chunk interleaves video latents with the 4 actions per frame; a causal mask and KV cache carry real observations forward, and actions are decoded from only partly denoised video.",
    sources: {
      p1: { kind: "paper", ref: "Li et al. 2026, §3.2 (autoregressive formulation)", url: "https://arxiv.org/abs/2601.21998" },
      p2: { kind: "paper", ref: "Li et al. 2026, §3.3 (MoT architecture, sparsification)", url: "https://arxiv.org/abs/2601.21998" },
      p3: { kind: "paper", ref: "Li et al. 2026, §4.2 (implementation details)", url: "https://arxiv.org/abs/2601.21998" },
      p4: { kind: "paper", ref: "Li et al. 2026, §4.1 (unified action space, data)", url: "https://arxiv.org/abs/2601.21998" },
      c1: gh(LB, LBC, "wan_va/modules/model.py"),
      c2: gh(LB, LBC, "wan_va/configs/va_robotwin_cfg.py"),
      c3: gh(LB, LBC, "wan_va/configs/va_libero_cfg.py")
    },
    summary: {
      pattern: ["Autoregressive unified video-action model", "p1"],
      params: ["5.3B = Wan2.2-5B + ≈ 350M action stream (paper)", "p3"],
      vision: ["Wan2.2 causal VAE 4 × 16 × 16, patchify 2 → 192 tokens per frame, views side by side", "p3"],
      backbone: ["Wan2.2-5B video stream: 30 layers, width 3,072, 24 heads", "p3", "c1"],
      head: ["Action stream: same depth, width 768 (paper); single-layer MLP encoder and decoder", "p2", "p3"],
      output: ["Velocities on the next video-latent chunk and its 4 actions per frame", "p1", "p2"],
      attention: ["Causal across chunks (KV cache), bidirectional inside a chunk; T5 by cross-attention", "p1", "p3"],
      cond: ["Separate flow-time embedders for video and action tokens", "c1"],
      steps: ["Paper: 3 Euler video steps (to s = 0.6), 10 action steps; CFG 5.0 / 1.0", "p3"],
      chunk: ["K ~ U[1, 4] frames in training; τ = 4 actions per video frame", "p2", "p3"],
      rate: null, latency: null,
      train: ["≈ 16K h robot data from 6 sources; 30-D dual-arm actions; noisy-history augmentation p = 0.5", "p3", "p4"]
    },
    changes: [
      "<b>Autoregressive</b>: video-action chunks come one after another under a causal mask and KV cache, fed with real observations.",
      "Two streams instead of three: no VLM expert; text enters by <b>T5 cross-attention</b>.",
      "The action stream is thinner (<b>768</b> vs Motus' 1,024) and initialised from scaled video weights.",
      "Video and action tokens are <b>interleaved</b> in time: each video latent frame is followed by its τ = 4 actions.",
      "<b>Partial denoising</b>: actions are decoded from video latents integrated only to s = 0.6."
    ],
    blueprint: {
      headline: "LingBot-VA: world model, one chunk at a time",
      note: "The video stream is Wan2.2-5B; the action stream has the same 30 layers at a quarter of the width. In every layer the two streams attend jointly (action tokens projected up to 3,072 and back), under a mask that is bidirectional inside the current chunk and causal toward the cached past.",
      towers: [
        { mod: "vid", title: "Wan2.2-5B video stream", sub: "30 layers, width 3,072",
          input: { label: "Video latent tokens", caption: "causal VAE, 192 tokens per frame" },
          rows: [
            { t: "linear", label: "Patchify (1, 2, 2) → 3,072", call: ["VAE 4 × 16 × 16, then 2 × 2 patches", "p3"] },
            { t: "block", n: "30", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { id: "att", t: "attn", label: "Chunk-causal joint attention", side: "RoPE", call: ["24 heads × 128; KV cache of past chunks", "c1", "p1"], callDy: -26, zoom: { k: "heads", q: 24, kv: 24, hd: 128, title: "Attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm (affine)" },
              { t: "attn", label: "Cross-attention to T5", call: ["Frozen T5; 4,096-d text features", "p3", "c1"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 14,336", "c1"], zoom: { k: "mlp", act: "GELU (tanh)", d: "3,072", ff: "14,336", title: "Feed forward, video stream" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Output LayerNorm · shift, scale" },
            { t: "linear", label: "Unpatchify → latent velocity",
              zoom: { k: "rows", title: "Partial denoising at inference", rows: ["video: 3 Euler steps, s → 0.6", "actions: 10 Euler steps, s → 1", "video CFG 5.0, action CFG 1.0", "runs chunk k, predicts k + 1"] } } ],
          output: { label: "next video chunk (partly denoised)" } },
        { mod: "act", title: "Action stream", sub: "paper: width 768, ≈ 350M",
          input: { label: "Action tokens", caption: "τ = 4 actions per video frame" },
          rows: [
            { t: "mlp", label: "Action encoder MLP", call: ["Single layer, hidden 256; 30-D actions", "p3", "p4"] },
            { t: "block", n: "30", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "linear", label: "Linear 768 → 3,072", call: ["Up to video width for attention", "p2"] },
              { id: "att", t: "attn", label: "Joint attention, own QKV", call: ["Same heads as the video stream", "p2"], callDy: -26,
                zoom: { k: "rows", title: "Autoregressive chunks", rows: ["cache: real frames + past actions", "chunk k: noisy video latents", "chunk k: noisy actions, 4 / frame", "bidirectional inside chunk k", "causal toward the cache"] } },
              { t: "linear", label: "Linear 3,072 → 768" },
              { t: "add", span: 4 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Linear action head", call: ["(7 EEF + 7 joints + 1 gripper) × 2 = 30", "p4"] } ],
          output: { label: "velocity on 4K actions" } }
      ],
      shared: [{ a: ["vid", "att"], b: ["act", "att"], label: "shared causal attention" }]
    },
    modules: [
      { id: "t5", role: "lang", name: "T5 text encoder", sub: "instruction", col: 0, frozen: true, short: "T5" },
      { id: "vid", role: "video-gen", name: "Wan2.2-5B video stream", sub: "30 × 3072 · 24 heads", col: 1, frozen: false, main: true, short: "Video stream",
        stack: { rows: [
          { t: "in", label: "[cached chunks | chunk k: video latents, actions]", dims: "192 tokens per frame + 4 actions per frame", c: "data-4" },
          { t: "linear", label: "Patch embedding: Linear(48 · 4 → 3,072)" },
          { t: "block", label: "Wan block (MoT with the action stream)", n: "30", rows: [
            { t: "norm", label: "LayerNorm · AdaLN" }, { t: "attn", label: "Self-attention · 24 heads · RoPE · chunk-causal" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "Cross-attention to T5" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN" }, { t: "ffn", label: "FFN 3,072 → 14,336 → 3,072 · GELU" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "linear", label: "Output head: AdaLN · Linear → latent patches" },
          { t: "out", label: "next-chunk video velocity", dims: "integrated only to s = 0.6", c: "data-4" } ],
          facts: [["Width / depth", ["3,072 / 30", "p3"]], ["Heads", ["24 × 128", "c1"]], ["FFN", ["14,336", "c1"]], ["Tokens / frame", ["192 (views side by side)", "p3"]], ["Packing", ["up to 10K tokens per sequence", "p3"]]] } },
      { id: "act", role: "action-expert", name: "Action stream", sub: "30 × 768 (paper)", col: 2, frozen: false, short: "Action stream" }
    ],
    inputs: [
      { to: "t5", mod: "lang", label: "instruction", n: "T5 tokens", k: 3 },
      { to: "vid", mod: "vision", label: "real frames", n: "KV cache", k: 3 },
      { to: "vid", mod: "future", label: "noisy chunk", n: "K frames", k: 4, noisy: true },
      { to: "act", mod: "action", label: "past actions (cache)", n: "executed", k: 2 },
      { to: "act", mod: "action", label: "noisy actions", n: "4 per frame", k: 4, noisy: true }
    ],
    outputs: [
      { from: "vid", mod: "future", label: "next video latents", n: "partly denoised", k: 4 },
      { from: "act", mod: "action", label: "action chunk", n: "30-D", k: 4 }
    ],
    links: [
      { from: "t5", to: "vid", kind: "cross-attn", label: "T5 tokens" },
      { from: "vid", to: "act", kind: "joint-attn", label: "shared causal|self-attention" }
    ],
    mask: { name: "Chunk-causal", ref: "p1", axes: [{ label: "past (cache)", short: "past", mod: "vision" }, { label: "chunk k", short: "k", mod: "future" }], m: ["10", "11"],
      note: "Inside a chunk video and action tokens are denoised in parallel with bidirectional attention; across chunks attention is causal." },
    callouts: [
      "<b>Paper vs code.</b> §3.3 and §4.2 describe a separate action stream of width 768 (≈ 350M). The released <code>wan_va/modules/model.py</code> embeds actions with Linear(30 → 3,072) and runs them through the same 30 blocks as the video tokens, with their own time embedder and output head.",
      "<b>Paper vs code.</b> §4.2 uses 3 video steps (to s = 0.6) and 10 action steps; the released RoboTwin config sets 25 video / 50 action steps and the LIBERO config 20 / 50."
    ]
  });

  /* ------------------------------------------------------------------ DreamZero */
  var DZ = "dreamzero0/dreamzero", DZC = "ab790c1";
  RB.arch.spec({
    id: "dreamzero", method: "dreamzero", name: "DreamZero", year: 2026, parent: "lingbot-va",
    diffRows: ["params", "vision", "backbone", "head", "cond", "steps", "chunk", "latency"],
    figRef: "Ye et al. Fig. 4, Fig. 14 · §3 · App. C–D", prov: "wan_flow_matching_action_tf.yaml",
    lede: "Wan2.1-I2V-14B made chunk-autoregressive. Small state and action encoders add proprioception and noisy actions to the video sequence; one shared flow time denoises video and actions together, and real frames replace predictions in the KV cache.",
    sources: {
      p1: { kind: "paper", ref: "Ye et al. 2026, §3.1 and Fig. 4", url: "https://arxiv.org/abs/2602.15922" },
      p2: { kind: "paper", ref: "Ye et al. 2026, §3.2 (real-time execution, Flash)", url: "https://arxiv.org/abs/2602.15922" },
      p3: { kind: "paper", ref: "Ye et al. 2026, §4 (training setup)", url: "https://arxiv.org/abs/2602.15922" },
      p4: { kind: "paper", ref: "Ye et al. 2026, App. C and Fig. 14", url: "https://arxiv.org/abs/2602.15922" },
      c1: gh(DZ, DZC, "groot/vla/configs/model/dreamzero/action_head/wan_flow_matching_action_tf.yaml"),
      c2: gh(DZ, DZC, "groot/vla/model/dreamzero/modules/wan_video_dit_action_casual_chunk.py"),
      c3: gh(DZ, DZC, "scripts/train/agibot_training.sh")
    },
    summary: {
      pattern: ["Autoregressive unified video-action model", "p1"],
      params: ["14B", "p1", "p3"],
      vision: ["Wan2.1 VAE and CLIP image encoder, frozen; camera views concatenated into one frame", "p1", "p3", "c3"],
      backbone: ["Wan2.1-I2V-14B DiT: 40 layers, width 5,120, 40 heads, FFN 13,824", "p3", "c1"],
      head: ["Added state encoder, action encoder (with flow time) and action decoder MLPs", "p1", "c2"],
      output: ["Joint velocity on the next video chunk and its action chunk", "p1"],
      attention: ["Chunk-causal: noisy chunk k sees clean chunks < k; real frames replace predictions in the cache", "p1", "p4"],
      cond: ["One shared flow time for video and action (Flash: video t = 1 − Beta(7, 1))", "p1", "p2"],
      steps: ["16 nominal → 4 with DiT caching → 1 with DreamZero-Flash", "p2"],
      chunk: ["K = 2 latent frames + H = 48 actions at 30 Hz (1.6 s); ≤ 4 chunks of context", "p4"],
      rate: ["≈ 7 Hz chunk generation, 30 Hz execution", "p2"],
      latency: ["5.7 s naive → ≈ 150 ms (GB200, Flash, 1 step)", "p2"],
      train: ["≈ 500 h AgiBot G1 or DROID; 100K steps, batch 128; DiT blocks + new encoders updated", "p3"]
    },
    changes: [
      "One <b>14B</b> Wan2.1 image-to-video DiT carries both modalities; there is no separate action stream.",
      "Video and action share <b>one flow time</b> per chunk (DreamZero-Flash decouples them for 1-step inference).",
      "Adds a <b>state encoder</b> for proprioception, and keeps the I2V model's CLIP image branch.",
      "Chunks hold K = 2 latent frames at the native frame rate; context up to 4 chunks (6.6 s).",
      "System work (CFG parallelism, DiT caching, NVFP4, Flash) brings latency to about 150 ms."
    ],
    blueprint: {
      headline: "DreamZero: a 14B video model as policy",
      note: "Each chunk's noisy video latents, state token and noisy action tokens enter the same 40 Wan blocks. Attention is chunk-causal, so chunk k reads the cached clean context; after execution the real frames are encoded and written into the cache.",
      towers: [
        { mod: "enc", title: "Frozen encoders", sub: "Wan2.1 VAE · CLIP · umT5", compact: true,
          input: { label: "Frames + instruction", caption: "views tiled into one frame" },
          rows: [
            { t: "conv", label: "Wan2.1 VAE encoder", call: ["Context + noisy targets", "p1"] },
            { t: "embed", label: "CLIP ViT-H/14 image encoder", call: ["1,280 → 5,120", "c2", "c3"] },
            { t: "embed", label: "umT5-XXL text encoder", call: ["2-layer MLP → 5,120", "c2"] } ],
          output: { label: "latents + image, text embeddings" } },
        { mod: "dit", title: "Wan2.1-I2V-14B DiT", sub: "chunk-autoregressive, trained",
          input: { label: "[context | video | q | actions]", caption: "I2V input: noisy ‖ cond ‖ mask = 36 ch" },
          rows: [
            { t: "conv", label: "Patch embedding (Conv3d)", call: ["36 input channels → 5,120", "c1", "c2"] },
            { t: "block", n: "40", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "attn", label: "Chunk-causal attention", side: "RoPE", call: ["40 heads × 128; KV cache of clean chunks", "c1", "p1"], zoom: { k: "heads", q: 40, kv: 40, hd: 128, title: "Attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "Cross-attention: text + CLIP" },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 13,824", "c1"], zoom: { k: "mlp", act: "GELU (tanh)", d: "5,120", ff: "13,824", title: "Feed forward (MLP)" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "linear", label: "Video head → 16-ch latents", call: ["16 output channels", "c1"],
              zoom: { k: "rows", title: "DreamZero-Flash", rows: ["base: one t ~ U(0, 1) for both", "Flash: video t = 1 − Beta(7, 1)", "action t ~ U(0, 1) unchanged", "clean actions from noisy video", "4 steps → 1: ≈ 350 → 150 ms"] } } ],
          output: { label: "joint velocity: video + actions" } },
        { mod: "io", title: "State / action MLPs", sub: "new parameters", compact: true,
          input: { label: "State q + noisy actions", caption: "shared flow time t" },
          rows: [
            { t: "mlp", label: "State encoder", call: ["state → 64 → 5,120", "c1", "c2"] },
            { t: "mlp", label: "Action encoder (with t)",
              zoom: { k: "rows", title: "Action encoder (π0 style)", rows: ["W₁: action → 5,120", "concat sinusoid(t) → 10,240", "W₂: 10,240 → 5,120, swish", "W₃: 5,120 → 5,120"] } },
            { t: "mlp", label: "Action decoder", call: ["5,120 → 64 → action dim", "c1", "c2"] } ],
          output: { label: "state + action tokens" } }
      ],
      links: [
        { from: "enc", to: "dit", toRow: "input", label: "clean context" },
        { from: "io", to: "dit", toRow: "input", label: "q + action tokens" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "VAE · CLIP · umT5", sub: "frozen encoders", col: 0, frozen: true, short: "Encoders" },
      { id: "dit", role: "joint", roleLabel: "Joint video + action DiT", name: "Wan2.1-I2V-14B DiT", sub: "40 × 5120 · 40 heads", col: 1, frozen: false, main: true, short: "DiT",
        stack: { rows: [
          { t: "in", label: "[clean chunks < k | chunk k: video, state, actions]", dims: "K = 2 latent frames, H = 48 actions per chunk", c: "data-4" },
          { t: "conv", label: "Patch embedding, 36 ch → 5,120 · state / action MLPs → 5,120" },
          { t: "block", label: "Causal Wan block", n: "40", rows: [
            { t: "norm", label: "LayerNorm · AdaLN(t)" }, { t: "attn", label: "Self-attention · 40 heads · RoPE · chunk-causal" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "Cross-attention: umT5 text + CLIP image" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN(t)" }, { t: "ffn", label: "FFN 5,120 → 13,824 → 5,120 · GELU" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "linear", label: "Video head (16 ch) · action decoder MLP" },
          { t: "out", label: "velocity on video latents and actions", dims: "one shared flow time", c: "data-3" } ],
          facts: [["Width / depth / heads", ["5,120 / 40 / 40", "c1"]], ["FFN", ["13,824", "c1"]], ["Input channels", ["36 (I2V)", "c1"]], ["Context", ["≤ 8 latent frames = 33 raw frames, 6.6 s", "p4"]], ["Video / action rate", ["5 FPS / 30 Hz (AgiBot)", "p4"]]] } },
      { id: "io", role: "state-enc", roleLabel: "Action / state I/O", name: "State, action MLPs", sub: "hidden 64 · → 5120", col: 2, frozen: false, short: "I/O MLPs" }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "frames, views tiled", n: "context + targets", k: 4 },
      { to: "enc", mod: "lang", label: "instruction", n: "umT5", k: 3 },
      { to: "dit", mod: "future", label: "noisy video chunk", n: "K = 2 latent frames", k: 4, noisy: true },
      { to: "io", mod: "state", label: "proprio qₖ", n: "1 token", k: 1 },
      { to: "io", mod: "action", label: "noisy actions", n: "H = 48", k: 5, noisy: true }
    ],
    outputs: [
      { from: "dit", mod: "future", label: "next video chunk", n: "discarded at run time", k: 4 },
      { from: "io", mod: "action", label: "action chunk", n: "48 @ 30 Hz", k: 5 }
    ],
    links: [
      { from: "enc", to: "dit", kind: "latent", label: "clean context|KV cache" },
      { from: "io", to: "dit", kind: "prefix", label: "state + action|tokens" }
    ],
    mask: { name: "Chunk-causal (teacher forcing)", ref: "p4", axes: [{ label: "context < k", short: "C", mod: "vision" }, { label: "chunk k", short: "Z,Y", mod: "future" }], m: ["10", "11"],
      note: "Training uses teacher forcing over all chunks at once; at run time the clean context is the KV cache of real observations (Fig. 14)." },
    callouts: [
      "<b>Paper vs code.</b> §4 and App. C train AgiBot with H = 48 actions per chunk and update all DiT blocks (LoRA was 'suboptimal'). The released <code>agibot_training.sh</code> uses action_horizon = 24, num_action_per_block = 24 and train_architecture = lora (rank 4 in the default config).",
      "Unlike UWM, LingBot-VA and mimic-video, video and action share <b>one flow time</b> (§3.1); only the Flash variant decouples them."
    ]
  });

  /* ------------------------------------------------------------------ Fast-WAM */
  var FW = "yuantianyuan01/FastWAM", FWC = "7faa711";
  RB.arch.spec({
    id: "fast-wam", method: "fast-wam", name: "Fast-WAM", year: 2026, parent: "lingbot-va",
    diffRows: ["params", "head", "output", "attention", "steps", "latency", "train"],
    figRef: "Yuan et al. Figs. 1–2 · §3.2 · §4.1", prov: "fastwam.yaml · LIBERO",
    lede: "A Wan2.2-5B video DiT and a 1B action DiT share attention (MoT). Future video is denoised only in training; at test time the video DiT encodes the current frame once and the action expert denoises the chunk from that cache.",
    sources: {
      p1: { kind: "paper", ref: "Yuan et al. 2026, §3.2 and Fig. 2", url: "https://arxiv.org/abs/2603.16666" },
      p2: { kind: "paper", ref: "Yuan et al. 2026, §3.3 (controlled variants)", url: "https://arxiv.org/abs/2603.16666" },
      p3: { kind: "paper", ref: "Yuan et al. 2026, §4.1 (implementation)", url: "https://arxiv.org/abs/2603.16666" },
      p4: { kind: "paper", ref: "Yuan et al. 2026, §4.3.3 and Fig. 4 (latency)", url: "https://arxiv.org/abs/2603.16666" },
      c1: gh(FW, FWC, "configs/model/fastwam.yaml"),
      c2: gh(FW, FWC, "src/fastwam/models/wan22/action_dit.py"),
      c3: gh(FW, FWC, "configs/data/libero_2cam.yaml"),
      c4: gh(FW, FWC, "src/fastwam/models/wan22/fastwam.py")
    },
    summary: {
      pattern: ["Dual-system WAM: joint self-attention (MoT)", "p1"],
      params: ["6B = 5B video DiT + 1B action expert", "p3"],
      vision: ["Wan2.2 VAE (frozen); cameras concatenated into one image, LIBERO 224 × 448", "p3", "c3", "c4"],
      backbone: ["Wan2.2-5B video DiT: 30 layers, width 3,072, 24 heads, FFN 14,336", "c1"],
      head: ["Action DiT: 30 layers, width 1,024, FFN 4,096, attention in 24 × 128 heads", "p3", "c1"],
      output: ["Velocity on h = 32 actions; future video is only a training target", "p3"],
      attention: ["Structured mask: actions see the clean first frame, never future video; first frame sees only itself", "p1"],
      cond: ["T5 cross-attention for all tokens; separate flow times per branch", "p1", "c1"],
      steps: ["10 denoising steps, CFG 1.0, logit-normal t", "p3"],
      chunk: ["h = 32 actions; 9 latent video frames in training (4× temporal down)", "p3"],
      rate: null,
      latency: ["190 ms on one RTX 5090D (imagine-then-execute variants: 580–810 ms)", "p4"],
      train: ["No embodied pretraining; loss = action + λ × video; AdamW lr 1e-4, cosine", "p1", "p3"]
    },
    changes: [
      "No future imagination at test time: the video DiT runs <b>once</b> on the current frame, and its keys and values condition action denoising.",
      "Future video latents are only a <b>training target</b> (video co-training).",
      "An attention mask stops action tokens from ever seeing future video tokens.",
      "A single bidirectional chunk: no autoregressive KV-cache rollout over chunks.",
      "The action expert is wider (1,024) and trained without embodied pretraining."
    ],
    blueprint: {
      headline: "Fast-WAM: learn to imagine, act without it",
      note: "Training: clean first-frame tokens, noisy future-frame tokens and noisy action tokens share each layer's attention under a structured mask. Inference: the future group is dropped, the video DiT runs once on the first frame, and only the action DiT iterates.",
      towers: [
        { mod: "vae", title: "Wan2.2 VAE", sub: "+ T5 text encoder, frozen", compact: true,
          input: { label: "Frames 224 × 448", caption: "2 cameras side by side (LIBERO)" },
          rows: [
            { t: "conv", label: "Wan2.2 VAE encoder", call: ["48 latent channels", "c1"] } ],
          output: { label: "f₀ (clean) + future latents" } },
        { mod: "vid", title: "Wan2.2-5B video DiT", sub: "world encoder at test time",
          input: { label: "[f₀ | f₁ … fₕ]", caption: "future latents only in training" },
          rows: [
            { t: "linear", label: "Patchify (1, 2, 2)", call: ["48 × 4 → 3,072", "c1"] },
            { t: "block", n: "30", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { id: "att", t: "attn", label: "Masked MoT attention", side: "RoPE", call: ["24 heads × 128", "c1"], callDy: -26, zoom: { k: "heads", q: 24, kv: 24, hd: 128, title: "Shared attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "Cross-attention to T5", call: ["Text width 4,096", "c1"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward", call: ["Hidden layer dimension of 14,336", "c1"], zoom: { k: "mlp", act: "GELU (tanh)", d: "3,072", ff: "14,336", title: "Feed forward, video DiT" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "linear", label: "Video head (training only)" } ],
          output: { label: "f₀ keys and values, cached" } },
        { mod: "act", title: "Action expert DiT", sub: "≈ 1B, same depth as video",
          input: { label: "Noisy actions Aτ", caption: "h = 32, own flow time" },
          rows: [
            { t: "linear", label: "Action encoder", call: ["Linear: action dim → 1,024", "c2"] },
            { t: "block", n: "30", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { id: "att", t: "attn", label: "Masked MoT attention", call: ["QKV into 24 × 128 heads; sees f₀ only", "c1", "p1"], callDy: -26 },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "Cross-attention to T5" },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward", call: ["1,024 → 4,096 → 1,024", "c1"], zoom: { k: "mlp", act: "GELU (tanh)", d: "1,024", ff: "4,096", title: "Feed forward, action DiT" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "linear", label: "Action head (AdaLN)", call: ["→ 7-D on LIBERO (6 EEF + gripper)", "c2", "c3"],
              zoom: { k: "rows", title: "Test-time path", rows: ["VAE-encode f₀, T5-encode ℓ", "one video pass on f₀ → KV cache", "10 action steps read the cache", "no future video is generated"] } } ],
          output: { label: "velocity; 10 steps" } }
      ],
      links: [{ from: "vae", to: "vid", toRow: "input", label: "latents" }],
      shared: [{ a: ["vid", "att"], b: ["act", "att"], label: "shared, masked attention" }]
    },
    modules: [
      { id: "vae", role: "codec", name: "Wan2.2 VAE", sub: "48-ch latents", col: 0, frozen: true, short: "VAE",
        note: "Encoding runs under no_grad; the optimizer covers only the MoT (fastwam.py)." },
      { id: "vid", role: "video-gen", name: "Wan2.2-5B video DiT", sub: "30 × 3072 · 24 heads", col: 1, frozen: false, main: true, short: "Video DiT",
        stack: { rows: [
          { t: "in", label: "[clean f₀ | noisy f₁ … fₕ]", dims: "9 latent frames in training; f₀ only at test time", c: "data-4" },
          { t: "linear", label: "Patch embedding (1, 2, 2) → 3,072" },
          { t: "block", label: "Wan block (MoT with the action DiT)", n: "30", rows: [
            { t: "norm", label: "LayerNorm · AdaLN" }, { t: "attn", label: "Masked joint attention · 24 heads · RoPE" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "Cross-attention to T5" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN" }, { t: "ffn", label: "FFN 3,072 → 14,336 → 3,072" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "linear", label: "Video head (training only)" },
          { t: "out", label: "future-latent velocity · f₀ KV cache", dims: "", c: "data-4" } ],
          facts: [["Width / depth / heads", ["3,072 / 30 / 24", "c1"]], ["FFN", ["14,336", "c1"]], ["Mask mode", ["first_frame_causal", "c1"]], ["Video shift", ["5.0 (train and test)", "c1"]], ["Params", ["≈ 5B", "p3"]]] } },
      { id: "act", role: "action-expert", name: "Action expert DiT", sub: "30 × 1024 · FFN 4096", col: 2, frozen: false, params: "≈ 1B", short: "Action DiT" }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "current frame f₀", n: "cameras tiled", k: 3 },
      { to: "vae", mod: "future", label: "future frames", n: "training only", k: 4 },
      { to: "vid", mod: "lang", label: "instruction (T5)", n: "cross-attention", k: 3 },
      { to: "act", mod: "action", label: "noisy action chunk", n: "h = 32", k: 5, noisy: true }
    ],
    outputs: [
      { from: "vid", mod: "future", label: "future latents", n: "training only", k: 4 },
      { from: "act", mod: "action", label: "velocity → actions", n: "32", k: 5 }
    ],
    links: [
      { from: "vae", to: "vid", kind: "latent", label: "f₀ + future|latents" },
      { from: "vid", to: "act", kind: "joint-attn", label: "shared attention|(masked)" }
    ],
    mask: { name: "Structured (training)", ref: "p1", axes: [{ label: "first frame", short: "f₀", mod: "vision" }, { label: "future frames", short: "f₁…ₕ", mod: "future" }, { label: "actions", short: "a", mod: "action" }], m: ["100", "110", "101"],
      note: "At inference the future row and column disappear; actions read only the cached f₀ tokens." },
    callouts: [
      "The released code also appends a <b>proprioception token</b> to the T5 context (Linear proprio → 4,096 in fastwam.py); the paper does not mention proprioception.",
      "The code README reports a later speed-up: RTX 4090 end-to-end 190 → 110 ms."
    ]
  });

  /* ------------------------------------------------------------------ mimic-video */
  var MV = "mimic-video/mimic-video", MVC = "e3355db";
  RB.arch.spec({
    id: "mimic-video", method: "mimic-video", name: "mimic-video", year: 2025, parent: "pi0",
    diffRows: ["vision", "backbone", "head", "attention", "cond", "steps", "train"],
    figRef: "Pai et al. Fig. 3 · §IV · App. A–C", prov: "w2a_libero action pipe",
    lede: "A Video-Action Model: Cosmos-Predict2 2B is LoRA-tuned on robot video and frozen. An action DiT cross-attends to the hidden states of one of its layers, taken at a chosen video flow time, and denoises the action chunk as inverse dynamics.",
    sources: {
      p1: { kind: "paper", ref: "Pai et al. 2025, §IV-B–D and Fig. 3", url: "https://arxiv.org/abs/2512.15692" },
      p2: { kind: "paper", ref: "Pai et al. 2025, §IV-E–F (sampling, training)", url: "https://arxiv.org/abs/2512.15692" },
      p3: { kind: "paper", ref: "Pai et al. 2025, App. A–C (Table IV, preprocessing, layer k)", url: "https://arxiv.org/abs/2512.15692" },
      c1: gh(MV, MVC, "model/cosmos_predict2/configs/defaults/world2action_pipe.py"),
      c2: gh(MV, MVC, "model/cosmos_predict2/configs/config_video2world.py"),
      c3: gh(MV, MVC, "model/cosmos_predict2/models/world2action_dit.py"),
      c4: gh(MV, MVC, "model/cosmos_predict2/configs/experiment/world2action.py"),
      c5: gh(MV, MVC, "model/cosmos_predict2/configs/dataloading/policy_io/libero.yaml"),
      c6: gh(MV, MVC, "model/cosmos_predict2/configs/defaults/world2action_model.py")
    },
    summary: {
      pattern: ["Dual-system WAM: cross-attention", "p1"],
      params: ["2B video backbone; action decoder size not stated", "p1"],
      vision: ["Cosmos tokenizer latents of 5 context frames (480 × 640)", "p1", "p3"],
      backbone: ["Cosmos-Predict2-2B DiT: 28 blocks, width 2,048, 16 heads; LoRA-tuned, then frozen", "p1", "c2"],
      head: ["Action DiT: 24 blocks, width 1,024, 8 heads, MLP ratio 4; AdaLN on (τᵥ, τₐ)", "c1", "c3"],
      output: ["Velocity on the action chunk (LIBERO config: 60 steps at 20 Hz)", "p1", "c5"],
      attention: ["Action self-attention + cross-attention to layer-k video hidden states", "p1"],
      cond: ["Low-rank bilinear-affine embedding of τᵥ and τₐ drives AdaLN", "p1", "c1"],
      steps: ["Video: partial, default τᵥ = 1 (one backbone pass). Actions: 10 flow steps", "p2", "c1"],
      chunk: ["LIBERO config: 60 actions at 20 Hz", "c5"],
      rate: null, latency: null,
      train: ["Stage 1: LoRA video fine-tune (rank 256). Stage 2: action decoder from scratch, video frozen", "p2", "c6"]
    },
    changes: [
      "The backbone is a <b>video diffusion model</b> (Cosmos-Predict2 2B), not a VLM.",
      "The action decoder <b>cross-attends</b> to one intermediate layer's hidden states instead of sharing self-attention.",
      "Video and action have <b>independent flow times</b>; at τᵥ = 1 one backbone pass is enough.",
      "Two-stage training: LoRA video fine-tune, then decoder training with the backbone frozen.",
      "Proprioception is one decoder token, randomly swapped for a mask token during training."
    ],
    blueprint: {
      headline: "mimic-video: act from a video model's mind",
      note: "The video DiT runs on 5 clean context latents plus future latents at flow time τᵥ, but only up to layer k. Those hidden states are the context that every action-decoder block cross-attends to, at each of the 10 action flow steps.",
      towers: [
        { mod: "vid", title: "Cosmos-Predict2 2B", sub: "video DiT, LoRA then frozen",
          input: { label: "[5 clean | noisy future]", caption: "480 × 640 frames; T5 instruction" },
          rows: [
            { t: "conv", label: "Patchify (1, 2, 2)", call: ["16 latent channels → 2,048", "c2"] },
            { t: "block", n: "28", label: "run up to layer k", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "attn", label: "Self-attention (video)", side: "RoPE", call: ["16 heads, head dim 128", "c2"], zoom: { k: "heads", q: 16, kv: 16, hd: 128, title: "Video self-attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "attn", label: "Cross-attention to T5" },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 8,192", "c2"], zoom: { k: "mlp", act: "GELU", d: "2,048", ff: "8,192", title: "Feed forward, video DiT" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Hidden states of layer k", call: ["Paper k = 19; config xattn_layer_idx = 20", "p3", "c4"] } ],
          output: { label: "h(τᵥ) (layer k)" } },
        { mod: "act", title: "Action decoder DiT", sub: "inverse dynamics, from scratch",
          input: { label: "State token + noisy actions", caption: "learned absolute positions" },
          rows: [
            { t: "mlp", label: "State MLP · action MLP", call: ["Two separate MLP encoders", "p1"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN",
                zoom: { k: "rows", title: "AdaLN on two flow times", rows: ["τᵥ, τₐ → low-rank bilinear-affine", "pair-time feature, rank 1,024", "per sub-layer AdaLN-LoRA, 128", "shift, scale, gate"] } },
              { id: "xa", t: "attn", label: "Cross-attention to video", call: ["Context width 2,048 (video DiT)", "c1"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "attn", label: "Self-attention (actions)", call: ["8 heads, head dim 128", "c1"], zoom: { k: "heads", q: 8, kv: 8, hd: 128, title: "Action self-attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["1,024 → 4,096 → 1,024", "c1"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Output projection", call: ["→ 10-D: 3 pos + 6-D rot + gripper", "c1", "p3"],
              zoom: { k: "rows", title: "Action sampling (Alg. 1)", rows: ["video flow 1 → τᵥ (none if τᵥ = 1)", "run video layers 1 … k once", "action flow 1 → 0 in 10 steps", "every step reads the same h(τᵥ)"] } } ],
          output: { label: "velocity; 10 steps" } }
      ],
      links: [{ from: "vid", to: "act", toRow: "xa", label: "h(τᵥ)" }]
    },
    modules: [
      { id: "vid", role: "video-gen", name: "Cosmos-Predict2 2B", sub: "28 × 2048 · 16 heads", col: 0, frozen: "lora", short: "Video DiT",
        note: "LoRA fine-tuned on robot video (rank 256 in the released checkpoints), then frozen while the action decoder trains." },
      { id: "act", role: "action-head", roleLabel: "Action decoder (IDM)", name: "Action decoder DiT", sub: "24 × 1024 · 8 heads", col: 1, frozen: false, main: true, short: "Action DiT",
        stack: { rows: [
          { t: "in", label: "[proprio token | noisy action chunk]", dims: "LIBERO: 1 + 60 tokens (max_horizon 61)", c: "data-3" },
          { t: "mlp", label: "Proprio MLP · action MLP → 1,024 · + learned positions" },
          { t: "block", label: "World2Action block", n: "24", rows: [
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(τᵥ, τₐ)" }, { t: "attn", label: "Cross-attention to h(τᵥ) (2,048-d)" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(τᵥ, τₐ)" }, { t: "attn", label: "Self-attention · 8 heads" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(τᵥ, τₐ)" }, { t: "ffn", label: "MLP 1,024 → 4,096 → 1,024" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "Final layer → 10-D per step" },
          { t: "out", label: "action velocity", dims: "10 flow steps", c: "data-3" } ],
          facts: [["Width / depth / heads", ["1,024 / 24 / 8", "c1"]], ["MLP ratio", ["4", "c1"]], ["AdaLN-LoRA dim", ["128", "c1"]], ["Pair-time rank", ["1,024", "c1"]], ["Action time density", ["∝ √(τₐ − 0.001)", "p2"]]] } }
    ],
    inputs: [
      { to: "vid", mod: "vision", label: "context frames", n: "5, clean", k: 4 },
      { to: "vid", mod: "future", label: "future latents", n: "at τᵥ", k: 3, noisy: true },
      { to: "act", mod: "state", label: "proprio qₜ", n: "1 token", k: 1 },
      { to: "act", mod: "action", label: "noisy chunk", n: "60 × 10-D", k: 5, noisy: true }
    ],
    outputs: [
      { from: "vid", mod: "latent", label: "layer-k hidden states", n: "h(τᵥ)", k: 3 },
      { from: "act", mod: "action", label: "velocity → chunk", n: "10 steps", k: 5 }
    ],
    links: [{ from: "vid", to: "act", kind: "cross-attn", label: "layer-k hidden|states h(τᵥ)" }],
    callouts: [
      "<b>Paper vs code.</b> App. C names layer k = 19; the released world2action config sets xattn_layer_idx = 20, where index 0 is the patch embedding, so the context is the output of the 20th block.",
      "Time convention: the paper puts clean data at τ = 0 and noise at τ = 1, the reverse of this site; τᵥ = 1 therefore means the future video is pure noise."
    ]
  });

  /* ------------------------------------------------------------------ VideoVLA */
  var VV = "VideoVLA-Project/VideoVLA", VVC = "05b5cca";
  RB.arch.spec({
    id: "videovla", method: "videovla", name: "VideoVLA", year: 2025, parent: "uwm",
    diffRows: ["params", "vision", "backbone", "head", "output", "cond", "steps", "chunk"],
    figRef: "Shen et al. Fig. 2 · §3 · §4 · App. B, D", prov: "videovla_config.yaml",
    lede: "CogVideoX-5B turned into a VLA: T5 text tokens, video patches and 6 raw 7-D action vectors form one sequence, and a single DDPM timestep denoises the future frame latents and the action chunk together.",
    sources: {
      p1: { kind: "paper", ref: "Shen et al. 2025, §3.1–3.4 and Fig. 2", url: "https://arxiv.org/abs/2512.06963" },
      p2: { kind: "paper", ref: "Shen et al. 2025, §4 (data, implementation details)", url: "https://arxiv.org/abs/2512.06963" },
      p3: { kind: "paper", ref: "Shen et al. 2025, App. Tables 13–14 and App. D", url: "https://arxiv.org/abs/2512.06963" },
      c1: gh(VV, VVC, "config_use/action_config/videovla_config.yaml"),
      c2: gh(VV, VVC, "dit_video_concat_withact.py"),
      c3: gh(VV, VVC, "diffusion_video.py"),
      c4: gh(VV, VVC, "config_use/action_config/inference_config/inference.yaml")
    },
    summary: {
      pattern: ["Single-system joint DiT (video + action in one sequence)", "p1"],
      params: ["CogVideoX-5B backbone", "p2"],
      vision: ["CogVideoX 3-D causal VAE (16 latent channels, frozen); first latent = current observation", "p1", "c1", "c3"],
      backbone: ["CogVideoX-5B expert DiT: 42 layers, width 3,072, 48 heads, patch 2", "c1"],
      head: ["Linear 7 → 3,072 action embedding; Linear action head with its own AdaLN", "c1", "c2"],
      output: ["DDPM noise on 13 future latents (49 frames) and 6 × 7-D actions", "p1", "p2"],
      attention: ["Full self-attention over [226 text | video patches | 6 actions]", "p1", "c1", "p3"],
      cond: ["T5 tokens in the sequence; timestep via expert AdaLN (text vs video-and-action)", "p1", "c2"],
      steps: ["DDIM: 50 steps (simulation), 10 steps (real robot)", "p2", "p3"],
      chunk: ["6 actions predicted, first 3 executed", "p2"],
      rate: ["≈ 3 Hz effective control (real robot)", "p3"],
      latency: ["≈ 1.1 s per inference on one H100 (4 latents, 10 steps)", "p3"],
      train: ["OXE subset (22.5M frames): 100K iters; fine-tune 15K; lr 1e-5, batch 256", "p2"]
    },
    changes: [
      "The backbone is a <b>pretrained CogVideoX-5B</b> video generator (42 layers, width 3,072), not a 12-layer DiT from scratch.",
      "Language enters as <b>T5 tokens in the sequence</b>; the current frame is the first latent of the video.",
      "Video and actions share <b>one timestep</b> (synchronous DDPM); decoupled schedules scored lower (Table 14).",
      "Actions are raw 7-D vectors embedded by one Linear layer; no tokenizer.",
      "Predicts long futures: 13 latents (49 frames) in simulation."
    ],
    blueprint: {
      headline: "VideoVLA: a video generator that also acts",
      note: "The CogVideoX expert transformer keeps its layout: text tokens and vision tokens share every attention and MLP but get separate AdaLN modulation. The 6 action tokens are appended after the video patches and ride with the vision group.",
      towers: [
        { mod: "vae", title: "CogVideoX 3-D VAE", sub: "causal, frozen", compact: true,
          input: { label: "Frames 256 × 256", caption: "current frame (+ 48 future in training)" },
          rows: [
            { t: "conv", label: "3-D causal conv encoder", call: ["Channel mult 1, 2, 2, 4; 4× time, 8× space", "c1", "c4"] } ],
          output: { label: "13 latents × 32 × 32 × 16" } },
        { mod: "dit", title: "CogVideoX-5B expert DiT", sub: "video + action, one sequence",
          input: { label: "[text | video | actions]", caption: "226 T5 · 13 × 256 patches · 6 actions" },
          rows: [
            { t: "conv", label: "Patch embed 2 × 2", call: ["32 ch in: noisy 16 ‖ first-frame 16", "c1", "c3"] },
            { t: "linear", label: "Text and action projections", call: ["T5 4,096 → 3,072 · action 7 → 3,072", "c1", "c2"] },
            { t: "block", n: "42", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN",
                zoom: { k: "rows", title: "Expert AdaLN (12 vectors)", rows: ["emb(t), 512-d → SiLU → Linear", "→ 12 × 3,072 per layer", "6 for video + action tokens", "6 for text tokens", "shift, scale, gate × (attn, MLP)"] } },
              { t: "attn", label: "Full 3-D attention · QK-LN", side: "RoPE", call: ["48 heads, head dim 64", "c1"], zoom: { k: "heads", q: 48, kv: 48, hd: 64, title: "Attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 12,288", "c2"], zoom: { k: "mlp", act: "GELU (tanh)", d: "3,072", ff: "12,288", title: "Feed forward (MLP)" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Final AdaLN (video, action)" },
            { t: "linear", label: "Unpatchify · action Linear", call: ["Action head 3,072 → 7, own AdaLN", "c2"],
              zoom: { k: "rows", title: "Inference", rows: ["encode the current frame → V₁", "noise 12 latents + 6 actions", "DDIM 50 (sim) or 10 (real) steps", "execute the first 3 actions", "decode video only to visualise"] } } ],
          output: { label: "ε for future latents and 6 actions" } }
      ],
      links: [{ from: "vae", to: "dit", toRow: "input", label: "latents" }]
    },
    modules: [
      { id: "t5", role: "lang", name: "T5-XXL", sub: "226 tokens", col: 0, frozen: true, short: "T5" },
      { id: "dit", role: "joint", roleLabel: "Joint video + action DiT", name: "CogVideoX-5B DiT", sub: "42 × 3072 · 48 heads", col: 1, frozen: false, main: true, short: "DiT",
        stack: { rows: [
          { t: "in", label: "[226 text | 13 × 256 video patches | 6 actions]", dims: "noisy video ‖ first-frame latent, 32 ch", c: "data-4" },
          { t: "conv", label: "Patch embed 2 × 2 → 3,072 · T5 Linear · action Linear" },
          { t: "block", label: "CogVideoX expert block", n: "42", rows: [
            { t: "norm", label: "LayerNorm · expert AdaLN(t)" }, { t: "attn", label: "Full 3-D attention · 48 heads · RoPE · QK-LN" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm · expert AdaLN(t)" }, { t: "ffn", label: "MLP 3,072 → 12,288 → 3,072 · GELU" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "norm", label: "Final AdaLN" },
          { t: "linear", label: "Unpatchify (16 ch) · action Linear (7)" },
          { t: "out", label: "ε for future latents and actions", dims: "one shared DDPM timestep", c: "data-3" } ],
          facts: [["Width / depth / heads", ["3,072 / 42 / 48", "c1"]], ["Head dim", ["64", "c1"]], ["Time embedding", ["512-d", "c1"]], ["Text tokens", ["226", "p1", "c1"]], ["Frames", ["49 → 13 latents (sim); 13 → 4 (real)", "p2"]]] } },
      { id: "vae", role: "codec", name: "CogVideoX 3-D VAE", sub: "causal · 16 ch", col: 2, frozen: true, short: "VAE" }
    ],
    inputs: [
      { to: "t5", mod: "lang", label: "instruction", n: "226 tokens", k: 3 },
      { to: "dit", mod: "action", label: "noisy actions", n: "6 × 7-D", k: 3, noisy: true },
      { to: "dit", mod: "time", label: "timestep t", n: "shared", k: 1 },
      { to: "vae", mod: "vision", label: "current frame", n: "256 × 256", k: 2 },
      { to: "vae", mod: "future", label: "future frames", n: "training only", k: 4 }
    ],
    outputs: [
      { from: "dit", mod: "future", label: "ε on future latents", n: "12 (sim)", k: 4 },
      { from: "dit", mod: "action", label: "ε on actions", n: "6 × 7-D", k: 3 }
    ],
    links: [
      { from: "t5", to: "dit", kind: "prefix", label: "226 text tokens" },
      { from: "vae", to: "dit", kind: "latent", label: "first frame + noisy|future latents" }
    ],
    mask: { name: "Mutual (no mask)", ref: "p1", axes: [{ label: "text", short: "ℓ", mod: "lang" }, { label: "video latents", short: "V", mod: "future" }, { label: "actions", short: "a", mod: "action" }], m: ["111", "111", "111"],
      note: "A causal-mask variant scored lower in simulation (App. Table 13)." },
    callouts: [
      "<b>Paper vs code.</b> §3.4 describes the current-frame latent as tokens in the sequence; the released config (noised_image_input, in_channels = 32) follows CogVideoX image-to-video and concatenates the first-frame latent channel-wise with the noisy video latents.",
      "Asynchronous video/action schedules lowered the average from 80.4 % to 73.8 % or 71.0 % (App. Table 14)."
    ]
  });
})();
