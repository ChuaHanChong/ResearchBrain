/* Architecture specs on the Evolution lineage map: world-model lane (TD-MPC, Dreamer 4, DreamDojo, LeWorldModel)
   and verification lane (SuccessVQA, RoVer, MG-Select, Foresight, Tri-Info). Numbers from the papers and, where released,
   the official code; see sources. Dreamer 4, SuccessVQA, RoVer, MG-Select, Foresight and Tri-Info have no public code. */
(function () {
  var RB = window.RB;
  function P(ref, id) { return { kind: "paper", ref: ref, url: "https://arxiv.org/abs/" + id }; }
  function C(repo, commit, path) { return { kind: "code", repo: repo, path: path, commit: commit, url: "https://github.com/" + repo + "/blob/" + commit + "/" + path }; }

  /* ------------------------------------------------------------------ TD-MPC */
  var TD = "nicklashansen/tdmpc", TDC = "f4d85ec";
  RB.arch.spec({
    id: "td-mpc", method: "td-mpc", name: "TD-MPC", year: 2022, parent: "dreamer",
    diffRows: ["pattern", "vision", "backbone", "head", "output", "steps", "train"],
    figRef: "Hansen et al. Figs. 1–2 · §3–4 · Table 4 · App. F", prov: "State defaults; pixels override",
    lede: "Five small deterministic MLPs and no decoder: an encoder, latent dynamics, reward, twin Q and a policy. MPPI plans five steps in latent space and bootstraps the rest with Q; the latent is trained only by reward, value and self-consistency.",
    sources: {
      p1: P("Hansen et al. 2022, §3 (MPPI planning, Alg. 1, Eqs. 3–5)", "2203.04955"),
      p2: P("Hansen et al. 2022, §4 (TOLD components and losses, Eqs. 6–11)", "2203.04955"),
      p3: P("Hansen et al. 2022, App. F (architecture listing, Walker Run)", "2203.04955"),
      p4: P("Hansen et al. 2022, Table 4 (hyperparameters)", "2203.04955"),
      c1: C(TD, TDC, "cfgs/default.yaml"),
      c2: C(TD, TDC, "src/algorithm/helper.py"),
      c3: C(TD, TDC, "cfgs/pixels.yaml"),
      c4: C(TD, TDC, "src/algorithm/tdmpc.py")
    },
    summary: {
      pattern: ["Latent world model (JEPA / TD-MPC)", "p2"],
      params: ["≈1.5M for the whole TOLD model (1,507,000 listed, Walker Run)", "p3"],
      vision: ["State: MLP S → 256 → Z. Pixels: 4-layer CNN, 32 filters, kernels 7-5-3-3, stride 2, 3 stacked 84 × 84 frames", "p3", "c2", "c3"],
      backbone: ["Latent dynamics d(z, a): MLP 512 → 512 → Z, ELU, deterministic", "p3", "c2"],
      head: ["Reward R, twin Q (LayerNorm + tanh first layer) and policy π, each a 2-hidden-layer 512 MLP", "p3", "c2"],
      output: ["First action of the MPPI plan, replanned every step", "p1"],
      attention: "None (MLPs only)",
      cond: "Action concatenated to the latent: [z ‖ a]",
      steps: ["MPPI: horizon 5, 6 iterations (12 Humanoid, 8 Dog and pixels), 512 samples + 5 % from π, 64 elites, temperature 0.5", "p4", "c1"],
      chunk: null, rate: null, latency: null,
      train: ["Online RL; reward c₁ = 0.5, value c₂ = 0.1, consistency c₃ = 2, weights ρ = 0.5 over H = 5", "p4", "c1"]
    },
    changes: [
      "<b>No decoder</b>: the latent is trained by reward, value and latent-consistency losses instead of reconstructing observations.",
      "The recurrent stochastic RSSM becomes a <b>deterministic MLP</b> z′ = d(z, a).",
      "Acts by <b>planning</b>: MPPI over 5 latent steps with a terminal Q, rather than running a learned actor.",
      "Twin <b>Q-functions</b> learned by TD, with slow-moving target networks for the value and consistency targets.",
      "A policy π adds 5 % of the sampled trajectories to guide the planner."
    ],
    blueprint: {
      headline: "TD-MPC: plan in a task-shaped latent",
      note: "The encoder maps a state (or 3 stacked frames) to z. Dynamics, reward and both Qs read [z ‖ a]; the policy reads z. MPPI rolls d forward 5 steps, sums predicted rewards and adds γᴴ·Q at the end. Only the first observation is encoded; later latents come from d.",
      towers: [
        { mod: "enc", title: "Encoder h", sub: "state MLP or pixel CNN", compact: true,
          input: { label: "State s or pixels", caption: "S-dim, or 3 × 84 × 84 frames" },
          rows: [
            { t: "conv", label: "4 conv layers, stride 2", call: ["32 filters, kernels 7, 5, 3, 3", "p3", "c2", "c3"],
              zoom: { k: "rows", title: "Pixel encoder", rows: ["3 stacked 84 × 84 RGB frames", "Conv 7 × 7, stride 2, ReLU", "Conv 5 × 5, stride 2, ReLU", "Conv 3 × 3, stride 2, ReLU (× 2)", "Flatten → Linear → z"] } },
            { t: "linear", label: "Linear → z", call: ["Latent 50; 100 Humanoid, Dog", "p4", "c1"] } ],
          output: { label: "z₀" } },
        { mod: "dyn", title: "Latent dynamics d", sub: "deterministic, never decoded",
          input: { label: "[zₜ ‖ aₜ]", caption: "Z + A" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "mlp", label: "Linear 512 · ELU", call: ["MLP hidden size 512", "p3", "p4"] }] },
            { t: "linear", label: "Linear 512 → Z (zₜ₊₁)", call: ["Loss c₃‖zₜ₊₁ − h⁻(sₜ₊₁)‖², c₃ = 2", "p2", "p4"],
              zoom: { k: "rows", title: "TOLD training", rows: ["sample a 5-step clip", "encode only s₀ with h", "roll d; predict r̂, q̂, â per step", "reward + TD + consistency, × ρⁱ", "targets from EMA nets h⁻, Q⁻"] } } ],
          output: { label: "zₜ₊₁" } },
        { mod: "q", title: "Q₁, Q₂ (and R)", sub: "R has the same shape without LN", compact: true,
          input: { label: "[z ‖ a]", caption: "twin Q-functions" },
          rows: [
            { t: "mlp", label: "Linear 512 · LayerNorm · tanh", call: ["LayerNorm on the value function only", "p3", "c2"],
              zoom: { k: "rows", title: "Q-function MLP", rows: ["[z ‖ a]", "Linear 512 · LayerNorm · tanh", "Linear 512 · ELU", "Linear → 1 (zero-init)", "two copies: Q₁, Q₂"] } },
            { t: "mlp", label: "Linear 512 · ELU" },
            { t: "linear", label: "Linear → 1", call: ["Last layer zero-initialised", "p3"],
              zoom: { k: "rows", title: "MPPI planning", rows: ["512 Gaussian plans of 5 actions", "+ 25 plans from π (5 %)", "score Σ γᵗ R + γ⁵ Q", "refit to 64 elites (τ = 0.5)", "6 iterations; run first action"] } } ],
          output: { label: "Q̂ and r̂" } }
      ],
      links: [
        { from: "enc", to: "dyn", toRow: "input", label: "z₀" },
        { from: "dyn", to: "q", toRow: "input", label: "zₜ, aₜ" }
      ]
    },
    modules: [
      { id: "enc", role: "state-enc", roleLabel: "Encoder h", name: "State MLP / CNN", sub: "→ latent 50 or 100", col: 0, frozen: false, short: "Encoder" },
      { id: "dyn", role: "world", roleLabel: "Latent dynamics d", name: "Dynamics MLP", sub: "2 × 512 · ELU", col: 1, frozen: false, main: true, short: "Dynamics",
        stack: { rows: [
          { t: "in", label: "[zₜ ‖ aₜ]", dims: "Z + A", c: "data-7" },
          { t: "block", label: "Hidden layers", n: "2", rows: [{ t: "mlp", label: "Linear 512 · ELU" }] },
          { t: "linear", label: "Linear 512 → Z" },
          { t: "out", label: "zₜ₊₁", dims: "matched to h⁻(sₜ₊₁)", c: "data-7" } ],
          facts: [["Hidden size / activation", ["512 / ELU", "p4", "c1"]], ["Latent dim", ["50 (100 Humanoid, Dog)", "p4", "c1"]], ["Loss weights", ["reward 0.5, value 0.1, consistency 2", "p4", "c1"]], ["Temporal weight ρ", ["0.5", "p4", "c1"]], ["Batch", ["512 (2,048 Dog, 256 pixels)", "p4"]]] } },
      { id: "q", role: "critic", roleLabel: "Reward + twin Q", name: "R, Q₁, Q₂", sub: "2 × 512 MLPs", col: 2, frozen: false, short: "Q",
        stack: { rows: [
          { t: "in", label: "[z ‖ a]", c: "data-7" },
          { t: "mlp", label: "Linear 512 · LayerNorm · tanh", dims: "Q only; R uses ELU" },
          { t: "mlp", label: "Linear 512 · ELU" },
          { t: "linear", label: "Linear → 1", dims: "zero-initialised" },
          { t: "out", label: "Q̂ (TD target r + γQ⁻(z′, π(z′)))", c: "data-8" } ],
          facts: [["Discount γ", ["0.99", "p4", "c1"]], ["Target momentum", ["0.99 (τ = 0.01 in code)", "p4", "c1"]]] } },
      { id: "pi", role: "action-head", roleLabel: "Policy π", name: "Policy MLP", sub: "deterministic + noise", col: 3, frozen: false, short: "π" }
    ],
    inputs: [
      { to: "enc", mod: "state", label: "state or 3 frames", n: "S-dim or 84 × 84", k: 3 },
      { to: "dyn", mod: "action", label: "action aₜ", n: "A-dim, up to 38", k: 2 }
    ],
    outputs: [
      { from: "q", mod: "other", label: "Q̂ and r̂", n: "scalars", k: 2 },
      { from: "pi", mod: "action", label: "π(z)", n: "→ 5 % of MPPI", k: 2 }
    ],
    links: [
      { from: "enc", to: "dyn", kind: "latent", label: "z (50 or 100)" },
      { from: "dyn", to: "q", kind: "feeds", label: "zₜ, aₜ" },
      { from: "pi", to: "q", kind: "feeds", label: "a = π(z)|max Q" }
    ],
    callouts: [
      "The paper lists 1,507,000 parameters for Walker Run (S = 24, A = 6); TD-MPC2 later adds SimNorm, a Q ensemble and task embeddings to scale this recipe.",
      "The pixel encoder's ReLU activations come from the released code; the paper gives only kernels, strides and filters. No other paper-vs-code difference found."
    ]
  });

  /* ------------------------------------------------------------------ Dreamer 4 */
  var D4 = "2509.24527";
  RB.arch.spec({
    id: "dreamer-4", method: "dreamer-4", name: "Dreamer 4", year: 2025, parent: "dreamerv3",
    diffRows: ["pattern", "params", "vision", "backbone", "head", "steps", "train"],
    figRef: "Hafner et al. Fig. 2 · §3 · Table 2 · App. A", prov: "Minecraft (VPT) setup",
    lede: "A causal video tokenizer and a block-causal transformer world model trained by shortcut forcing, fast enough to run at 21 FPS on one GPU. Policy, reward and value heads sit on agent tokens inside it, and the policy improves by RL purely in imagination.",
    sources: {
      p1: P("Hafner et al. 2025, §3.1 (causal tokenizer, Eq. 5)", D4),
      p2: P("Hafner et al. 2025, §3.2 (interactive dynamics, shortcut forcing, Eqs. 6–8)", D4),
      p3: P("Hafner et al. 2025, §3.3 (agent tokens, heads, PMPO, Eqs. 9–11)", D4),
      p4: P("Hafner et al. 2025, §3.4 (efficient transformer)", D4),
      p5: P("Hafner et al. 2025, §4 (model sizes, spatial tokens, context)", D4),
      p6: P("Hafner et al. 2025, Table 2 (design cascade, H100 FPS)", D4),
      p7: P("Hafner et al. 2025, App. A (VPT data, tokenization)", D4),
      p8: P("Hafner et al. 2025, Table 3 (Minecraft agent inputs)", D4)
    },
    summary: {
      pattern: ["Transformer world model agent (imagination RL)", "p3"],
      params: ["2B: tokenizer 400M + dynamics 1.6B", "p5"],
      vision: ["Causal tokenizer: 360 × 640 frames padded to 384 × 640, 16 × 16 patches → 960 tokens, bottleneck 512 × 16", "p1", "p7"],
      backbone: ["Block-causal 2-D transformer: space-only layers, time attention every 4th layer, GQA, RMSNorm, RoPE, SwiGLU, QKNorm", "p4"],
      head: ["Policy, reward and value MLP heads on agent tokens; reward and value as symexp twohot; MTP length 8", "p3"],
      output: ["Clean next-frame latents (x-prediction); mouse and keyboard actions", "p2", "p7"],
      attention: ["Causal in time, full within a frame; agent tokens read everything, nothing reads them", "p3", "p4"],
      cond: ["Per frame: action tokens (components summed), one token for signal level τ and step size d, registers", "p2"],
      steps: ["K = 4 shortcut steps per frame (d = 1/4); past frames noised to τ = 0.1", "p2"],
      chunk: null,
      rate: ["VPT video and actions at 20 FPS; context 192 frames", "p5", "p7"],
      latency: ["21.4 FPS on one H100 (final design, Table 2)", "p6"],
      train: ["Pretrain on 2,541 h of VPT video, finetune heads, then PMPO in imagination (α = 0.5, β = 0.3) with the transformer frozen", "p3", "p7"]
    },
    changes: [
      "The RSSM (GRU plus stochastic latents) is replaced by a <b>block-causal transformer</b> over a learned video tokenizer's latents.",
      "Frames are generated by <b>shortcut forcing</b> in x-space: 4 sampling steps per frame, with a ramp loss weight.",
      "Learns from <b>offline video only</b> (2,541 h VPT); action labels are needed for only part of the data.",
      "Policy and reward become <b>heads on agent tokens</b> inside the world model; RL uses PMPO with a KL to the BC prior.",
      "Input grows from 64 × 64 images to 360 × 640 frames, and the model to 2B parameters."
    ],
    blueprint: {
      headline: "Dreamer 4: one fast transformer world",
      note: "The tokenizer squeezes each frame's latent tokens through a tanh bottleneck. The dynamics transformer reads, per frame, 256 spatial tokens, registers, a τ/d token and action tokens, and denoises the next frame in 4 steps. Agent tokens carry the task and feed the policy, reward and value heads.",
      towers: [
        { mod: "tok", title: "Causal tokenizer", sub: "400M · masked autoencoder", compact: true,
          input: { label: "Frame patches", caption: "384 × 640, 16 × 16 → 960 tokens" },
          rows: [
            { t: "attn", label: "Block-causal encoder", call: ["Patch dropout p ~ U(0, 0.9)", "p1"],
              zoom: { k: "rows", title: "Tokenizer training", rows: ["drop patches with p ~ U(0, 0.9)", "encoder: patches + latent tokens", "Linear → narrow, tanh bottleneck", "decoder reads patches back out", "loss MSE + 0.2 · LPIPS"] } },
            { t: "linear", label: "Linear → tanh bottleneck", call: ["512 × 16, reshaped to 256 × 32", "p7"] } ],
          output: { label: "z per frame" } },
        { mod: "dyn", title: "Interactive dynamics", sub: "1.6B · block-causal · shortcut forcing",
          input: { label: "Interleaved frame tokens", caption: "z̃ (noised) · actions · τ, d · registers" },
          rows: [
            { t: "embed", label: "Linear → 256 spatial tokens", call: ["Sz = 256 for Minecraft", "p5", "p7"] },
            { id: "cond", t: "embed", label: "+ τ, d token · action tokens", side: "cond", call: ["τ, d: discrete embeddings", "p2"] },
            { t: "block", n: "L/4", label: "3 space + 1 time layer", rows: [
              { t: "attn", label: "3 × space-only attention", call: ["Within the frame only", "p4"],
                zoom: { k: "rows", title: "One transformer layer", rows: ["RMSNorm (pre-norm)", "attention: QKNorm, RoPE, soft-cap", "GQA: query heads share KV heads", "RMSNorm", "SwiGLU feed-forward", "residual adds"] } },
              { t: "attn", label: "1 × causal time attention", call: ["Temporal attention every 4 layers", "p4"] },
              { t: "ffn", label: "SwiGLU after each attention" } ] },
            { t: "linear", label: "Predict clean z (x-space)", call: ["Loss weight w(τ) = 0.9τ + 0.1", "p2"],
              zoom: { k: "rows", title: "Shortcut forcing", rows: ["τ = 0 noise, τ = 1 clean", "d = d_min: flow loss in x-space", "else: bootstrap from two d/2 steps", "sample with K = 4 steps, d = 1/4", "context frames noised to τ = 0.1"] } } ],
          output: { label: "ẑ next frame · agent-token outputs" } },
        { mod: "heads", title: "Agent heads", sub: "on agent tokens", compact: true,
          input: { label: "Agent tokens hₜ", caption: "task embedding in" },
          rows: [
            { t: "mlp", label: "Policy MLP", call: ["Keys: binary; mouse: 121-way", "p3", "p7"] },
            { t: "mlp", label: "Reward and value MLPs", call: ["Symexp twohot outputs", "p3"],
              zoom: { k: "rows", title: "Imagination RL (PMPO)", rows: ["imagine with the policy head", "λ-returns with γ = 0.997", "split states by sign of advantage", "α = 0.5 between the two sets", "+ β = 0.3 · KL to BC prior"] } } ],
          output: { label: "actions, r̂, v̂" } }
      ],
      links: [
        { from: "tok", to: "dyn", toRow: "input", label: "frame latents z" },
        { from: "dyn", to: "heads", toRow: "input", label: "agent tokens" }
      ]
    },
    modules: [
      { id: "tok", role: "codec", roleLabel: "Causal tokenizer", name: "Video tokenizer", sub: "400M · tanh bottleneck", col: 0, frozen: true, short: "Tokenizer",
        note: "Trained first, then frozen while the dynamics model trains." },
      { id: "dyn", role: "world", roleLabel: "Interactive dynamics", name: "Block-causal transformer", sub: "1.6B · 4 steps per frame", col: 1, frozen: "partial", main: true, short: "Dynamics",
        note: "Trained in phases 1–2; frozen during imagination RL, where only the policy and value heads update.",
        stack: { rows: [
          { t: "in", label: "per frame: z̃ · actions · τ, d · registers · agent", dims: "256 spatial tokens (Minecraft)", c: "data-4" },
          { t: "block", label: "Space + time group", n: "L/4", rows: [
            { t: "attn", label: "space-only attention (× 3)", dims: "GQA, QKNorm, RoPE" },
            { t: "attn", label: "causal time attention (× 1)", dims: "long context" },
            { t: "ffn", label: "SwiGLU after every attention" } ] },
          { t: "linear", label: "x-prediction head", dims: "clean latents ẑ" },
          { t: "out", label: "next frame ẑ, agent outputs", dims: "context 192 frames", c: "data-4" } ],
          facts: [["Parameters", ["1.6B", "p5"]], ["Sampling", ["K = 4 steps per frame", "p2"]], ["Spatial tokens", ["256 (Minecraft), 512 (SOAR, Epic Kitchens)", "p5", "p7"]], ["Context", ["192 frames Minecraft, 96 real-world", "p5"]], ["Layers / width / heads", "not disclosed"]] } },
      { id: "heads", role: "action-head", roleLabel: "Agent heads", name: "Policy, reward, value", sub: "MLPs · MTP L = 8", col: 2, frozen: false, short: "Heads" }
    ],
    inputs: [
      { to: "tok", mod: "vision", label: "frames", n: "360 × 640 at 20 FPS", k: 4 },
      { to: "dyn", mod: "action", label: "mouse + keyboard", n: "per frame", k: 2 },
      { to: "dyn", mod: "time", label: "τ and d", n: "shortcut level, step", k: 2 }
    ],
    outputs: [
      { from: "dyn", mod: "future", label: "next-frame latents", n: "4 steps each", k: 4 },
      { from: "heads", mod: "action", label: "actions, r̂, v̂", n: "from agent tokens", k: 3 }
    ],
    links: [
      { from: "tok", to: "dyn", kind: "latent", label: "z per frame|tanh bottleneck" },
      { from: "dyn", to: "heads", kind: "feeds", label: "agent-token outputs" }
    ],
    mask: { name: "Within a frame (causal across frames)", ref: "p3", axes: [{ label: "frame tokens", short: "z", mod: "future" }, { label: "actions", short: "a", mod: "action" }, { label: "agent tokens", short: "ag", mod: "other" }], m: ["110", "110", "111"],
      note: "Agent tokens attend to every modality, but no modality attends back to them, so the task cannot leak into the world model's predictions." },
    callouts: [
      "The paper gives parameter totals, token counts and design choices but <b>no layer count, width or head numbers</b>, and no official code; those rows show as not disclosed.",
      "Table 2: shortcut forcing plus x-space loss and the efficient transformer take FVD from 306 to 57 while inference rises from 0.8 to 21.4 FPS."
    ]
  });

  /* ------------------------------------------------------------------ DreamDojo */
  var DD = "NVIDIA/DreamDojo", DDC = "02f119b", DDP = "2602.06949";
  RB.arch.spec({
    id: "dreamdojo", method: "dreamdojo", name: "DreamDojo", year: 2026, parent: "cosmos-world-foundation-models",
    diffRows: ["pattern", "params", "backbone", "cond", "chunk", "latency", "train"],
    figRef: "Gao et al. Figs. 1, 3 · §2–4.1 · Table 6", prov: "2B action-chunk config",
    lede: "Cosmos-Predict2.5 turned into an action-conditioned world model: 4 actions per latent frame go through an MLP into the timestep embedding. Pretraining on 44k hours of human video uses 32-d latent actions from a separate 700M VAE as labels.",
    sources: {
      p1: P("Gao et al. 2026, §2 (Cosmos-Predict2.5, flow matching)", DDP),
      p2: P("Gao et al. 2026, §3.3.1 (relative, chunked actions)", DDP),
      p3: P("Gao et al. 2026, §3.3.2 (latent actions, Eqs. 3–5)", DDP),
      p4: P("Gao et al. 2026, §3.3.3 (post-training)", DDP),
      p5: P("Gao et al. 2026, §4.1 (training setup)", DDP),
      p6: P("Gao et al. 2026, Table 6 (distillation)", DDP),
      c1: C(DD, DDC, "cosmos_predict2/_src/predict2/action/configs/action_conditioned/net.py"),
      c2: C(DD, DDC, "cosmos_predict2/_src/predict2/action/networks/action_conditioned_minimal_v1_lvg_dit.py"),
      c3: C(DD, DDC, "configs/2b_480_640_pretrain.yaml"),
      c4: C(DD, DDC, "external/lam_project/config/lam_0.yaml"),
      c5: C(DD, DDC, "external/lam/modules/lam.py")
    },
    summary: {
      pattern: ["Video world foundation model", "p1"],
      params: ["2B and 14B world models; latent action model 700M", "p5"],
      vision: ["WAN2.2 tokenizer latents (4 frames per latent frame), 640 × 480 video, 13-frame clips", "p1", "p2", "p5"],
      backbone: ["Cosmos-Predict2.5 DiT. 2B: 28 blocks × 2,048, 16 heads. 14B: 36 × 5,120, 40 heads", "c1"],
      head: ["Velocity on video latents (flow matching) + temporal-consistency loss, λ = 0.1", "p1", "p3"],
      output: ["Future frames at 640 × 480", "p5"],
      attention: ["Distilled student is causal: 4 predicted frames from a 12-frame context", "p6"],
      cond: ["4 actions per latent frame → MLP, added to the timestep embedding that drives AdaLN; empty text prompt", "p2", "p3", "p5", "c2"],
      steps: null,
      chunk: ["12 relative actions per 13-frame clip; first frame is the condition", "p5", "c3"],
      rate: ["Robot video sampled at about 10 Hz", "p5"],
      latency: ["Student 10.81 FPS vs teacher 2.72 FPS on one H100", "p6"],
      train: ["Pretrain 140k steps on 44,711 h human video with latent actions (256 H100); post-train 50k steps on the target robot", "p5"]
    },
    changes: [
      "Starts from <b>Cosmos-Predict2.5</b> (2B or 14B) and makes it <b>action-conditioned</b>: an action MLP adds to the timestep embedding in every block.",
      "Pretrains on <b>44k hours of egocentric human video</b>, labelled with 32-d continuous <b>latent actions</b> from a 700M VAE.",
      "Actions are <b>relative</b> and <b>chunked</b>: 4 actions go to each latent frame instead of one global condition.",
      "Adds a <b>temporal-consistency loss</b> (λ = 0.1) on frame-to-frame velocity differences.",
      "A Self Forcing distillation yields a <b>causal student</b> at 10.81 FPS."
    ],
    blueprint: {
      headline: "DreamDojo: human video, latent actions, DiT",
      note: "The latent action model looks at two frames and squeezes the change into a 32-d vector. During pretraining those vectors, 4 per latent frame, pass through an MLP and are added to the timestep embedding, which modulates every DiT block. Post-training swaps in the robot's own relative actions.",
      towers: [
        { mod: "lam", title: "Latent action model", sub: "700M VAE · labels human video", compact: true,
          input: { label: "Frames fₜ, fₜ₊₁", caption: "320 × 240, random frame skip 1–4" },
          rows: [
            { t: "embed", label: "Patchify 16 + action prompt", call: ["Patch 16, model dim 1,024", "c4", "c5"] },
            { t: "block", n: "24", rows: [{ t: "attn", label: "Spatiotemporal block", call: ["16 heads", "c4"] }] },
            { t: "linear", label: "Linear → μ, σ (32-d)", call: ["Latent action 32-d, β = 10⁻⁶", "p5", "c4"],
              zoom: { k: "rows", title: "LAM decoder (training only)", rows: ["â (32-d) → Linear → 1,024", "add to patches of frame fₜ", "24 spatial transformer blocks", "predict patches of fₜ₊₁", "loss: reconstruction + β · KL"] } } ],
          output: { label: "latent action âₜ" } },
        { mod: "dit", title: "Cosmos-Predict2.5 DiT", sub: "2B · rectified flow · action-conditioned",
          input: { label: "Noisy video latents", caption: "1 condition + 3 predicted latent frames" },
          rows: [
            { t: "conv", label: "Patchify 2 × 2", call: ["16 latent channels, patch 2", "c1"] },
            { t: "block", n: "28", rows: [
              { id: "n1", t: "norm", label: "Norm · shift, scale", side: "AdaLN", call: ["AdaLN-LoRA, rank 256", "c1"],
                zoom: { k: "rows", title: "Action injection", rows: ["4 actions per latent frame, flat", "MLP: → 8,192 → 2,048 (GELU-tanh)", "add to its timestep embedding", "2nd MLP → 6,144 adds to AdaLN-LoRA", "last layer zero-init (pretrain)"] } },
              { t: "attn", label: "Self-attention (3-D RoPE)", call: ["2,048 wide, 16 heads", "c1"], zoom: { k: "heads", q: 16, kv: 16, hd: 128, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "attn", label: "Cross-attention to text", call: ["Prompt fixed to empty", "p5"] },
              { t: "add", span: 1 },
              { t: "norm", label: "Norm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (MLP)" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Unpatchify → velocity", call: ["Flow loss + 0.1 × temporal loss", "p3"] } ],
          output: { label: "velocity on future latents" } },
        { mod: "student", title: "Distilled student", sub: "Self Forcing · causal", compact: true,
          input: { label: "12 context frames", caption: "same DiT architecture" },
          rows: [
            { t: "attn", label: "Causal, autoregressive", call: ["4 frames per step, 12-frame context", "p6"] },
            { t: "linear", label: "Few-step sampling", call: ["10.81 FPS vs 2.72 teacher", "p6"] } ],
          output: { label: "streaming video" } }
      ],
      links: [
        { from: "lam", to: "dit", toRow: "n1", label: "4 actions per latent frame" },
        { from: "dit", to: "student", toRow: "input", label: "distil (teacher)" }
      ]
    },
    modules: [
      { id: "lam", role: "latent", roleLabel: "Latent action model", name: "Spatiotemporal VAE", sub: "24 + 24 blocks · 32-d", col: 0, frozen: true, short: "LAM",
        note: "Trained first on human and robot video; then used as a fixed labeller for pretraining." },
      { id: "dit", role: "world", roleLabel: "World model (DiT)", name: "Cosmos-Predict2.5 DiT", sub: "2B: 28 × 2,048 · 16 heads", col: 1, frozen: false, main: true, short: "DiT",
        stack: { rows: [
          { t: "in", label: "[condition latent | 3 noisy latents]", dims: "13 frames → 4 latent frames", c: "data-4" },
          { t: "conv", label: "Patchify 2 × 2", dims: "16 channels in" },
          { t: "block", label: "DiT block", n: "28", rows: [
            { t: "norm", label: "Norm · AdaLN (timestep + action)", side: "AdaLN" },
            { t: "attn", label: "Self-attention · 16 heads · RoPE-3D" },
            { t: "add", span: 2 },
            { t: "attn", label: "Cross-attention (empty text)" },
            { t: "add", span: 1 },
            { t: "norm", label: "Norm · AdaLN", side: "AdaLN" },
            { t: "ffn", label: "MLP" },
            { t: "add", span: 2 } ] },
          { t: "linear", label: "Unpatchify → velocity" },
          { t: "out", label: "future latents → WAN2.2 decoder", dims: "640 × 480", c: "data-4" } ],
          facts: [["2B / 14B", ["28 × 2,048 × 16 heads / 36 × 5,120 × 40 heads", "c1"]], ["Action MLP", ["hidden 4 × width = 8,192 (2B)", "c2"]], ["Temporal loss weight λ", ["0.1", "p3"]], ["Pretraining", ["140k steps, batch 1,024, lr 1.6 × 10⁻⁴", "p5"]], ["Post-training", ["50k steps, batch 512, 128 H100", "p5"]]] } },
      { id: "student", role: "video-gen", roleLabel: "Real-time student", name: "Causal student DiT", sub: "Self Forcing distilled", col: 2, frozen: false, short: "Student" }
    ],
    inputs: [
      { to: "lam", mod: "vision", label: "frame pairs", n: "320 × 240", k: 2 },
      { to: "dit", mod: "vision", label: "condition frame", n: "640 × 480", k: 2 },
      { to: "dit", mod: "action", label: "robot actions", n: "12 relative (post-train)", k: 3 }
    ],
    outputs: [
      { from: "lam", mod: "latent", label: "latent actions", n: "32-d each", k: 2 },
      { from: "dit", mod: "future", label: "future frames", n: "12 per clip", k: 4 },
      { from: "student", mod: "future", label: "streamed frames", n: "10.81 FPS", k: 3 }
    ],
    links: [
      { from: "lam", to: "dit", kind: "adaln", label: "latent actions|→ MLP → timestep emb." },
      { from: "dit", to: "student", kind: "two-stage", label: "Self Forcing|distillation" }
    ],
    callouts: [
      "Paper (§3.3.3): post-training re-initialises the first layer of the action MLP to match the robot's action space and fine-tunes all weights.",
      "Layer sizes come from the released net configs (2B: 28 blocks, width 2,048, 16 heads); the paper itself states only the 2B / 14B totals. No paper-vs-code difference found."
    ]
  });

  /* ------------------------------------------------------------------ LeWorldModel */
  var LW = "lucas-maes/le-wm", LWC = "8edfeb3", LWP = "2603.19312";
  RB.arch.spec({
    id: "leworldmodel", method: "leworldmodel", name: "LeWorldModel", year: 2026, parent: "dino-wm",
    diffRows: ["params", "vision", "backbone", "cond", "steps", "latency", "train"],
    figRef: "Maes et al. Fig. 1 · §3 · App. A, B, D, G", prov: "PushT config",
    lede: "A 15M-parameter JEPA trained end-to-end from pixels: a tiny ViT encodes each frame to one 192-d vector, an AdaLN transformer predicts the next vector from the action, and SIGReg keeps the embeddings Gaussian so they cannot collapse.",
    sources: {
      p1: P("Maes et al. 2026, §3.1 (architecture, objective, Eqs. 1–3)", LWP),
      p2: P("Maes et al. 2026, Alg. 1 (λ, M)", LWP),
      p3: P("Maes et al. 2026, §3.2 and App. B (CEM planning)", LWP),
      p4: P("Maes et al. 2026, App. D (implementation)", LWP),
      p5: P("Maes et al. 2026, App. A (SIGReg, Epps–Pulley)", LWP),
      p6: P("Maes et al. 2026, App. G, Tables 6 and 9", LWP),
      p7: P("Maes et al. 2026, abstract and §4.2 (planning time)", LWP),
      c1: C(LW, LWC, "config/train/model/lewm.yaml"),
      c2: C(LW, LWC, "config/train/lewm.yaml"),
      c3: C(LW, LWC, "module.py"),
      c4: C(LW, LWC, "jepa.py"),
      c5: C(LW, LWC, "config/eval/solver/cem.yaml"),
      c6: C(LW, LWC, "config/eval/pusht.yaml")
    },
    summary: {
      pattern: ["Latent world model (JEPA / TD-MPC)", "p1"],
      params: ["≈15M: encoder ≈5M, predictor ≈10M", "p1"],
      vision: ["ViT-Tiny from scratch: 224 × 224, patch 14, 12 layers, 3 heads, width 192; CLS → BatchNorm projector", "p1", "p4", "c1"],
      backbone: ["Predictor: 6 transformer layers, 16 heads, AdaLN-zero action conditioning, causal over 3 frames", "p1", "c1", "c2"],
      head: ["BatchNorm MLP projector 192 → 2,048 → 192 after the predictor", "p1", "c1", "c3"],
      output: ["Next-frame embedding ẑₜ₊₁ (192-d)", "p1", "c2"],
      attention: ["Temporal causal mask over the frame history", "p1", "c3"],
      cond: ["Action block (5 actions, frame-skip 5) → Conv1d + MLP embedder → AdaLN in every layer", "p4", "c3"],
      steps: ["CEM: 300 samples, 30 elites, 30 iterations on PushT (10 elsewhere), horizon 5", "p4", "c5", "c6"],
      chunk: ["Executes all 5 planned action blocks before replanning", "p4", "c6"],
      rate: null,
      latency: ["Under 1 s per plan; up to 48× faster than DINO-WM", "p7"],
      train: ["End to end from pixels: MSE + λ · SIGReg (λ = 0.1, 1,024 projections); batch 128, 4-frame clips", "p2", "p4"]
    },
    changes: [
      "The encoder is <b>trained from scratch</b> (ViT-Tiny, 5M) instead of a frozen DINOv2.",
      "Each frame becomes <b>one 192-d CLS embedding</b>, not a grid of patch features.",
      "Only <b>two loss terms</b>: next-embedding MSE and SIGReg, with no EMA, stop-gradient or decoder.",
      "Actions enter the predictor through <b>AdaLN-zero</b> in every layer.",
      "Planning is up to <b>48× faster</b>, under a second per plan."
    ],
    blueprint: {
      headline: "LeWorldModel: a tiny JEPA from pixels",
      note: "The ViT's CLS token passes through a BatchNorm projector to give zₜ. The predictor takes the last 3 embeddings, adds learned positions, and is modulated by the action embedding in all 6 layers. A second projector maps its output to ẑₜ₊₁. SIGReg acts on the encoder embeddings only.",
      towers: [
        { mod: "enc", title: "Encoder (ViT-Tiny)", sub: "≈5M · trained from scratch",
          input: { label: "Frame oₜ", caption: "224 × 224 RGB" },
          rows: [
            { t: "conv", label: "Patchify 14 × 14 + CLS", call: ["224 / 14 = 16 → 256 patches", "p1", "c1"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "Multi-head self-attention", call: ["3 heads, width 192", "p1"], zoom: { k: "heads", q: 3, kv: 3, hd: 64, title: "Encoder heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward (MLP)" },
              { t: "add", span: 2 } ] },
            { t: "mlp", label: "Projector: BatchNorm MLP", call: ["192 → 2,048 → 192", "c1", "c3"],
              zoom: { k: "rows", title: "SIGReg on zₜ", rows: ["Z: history × batch × 192", "1,024 random unit directions", "Epps–Pulley test per projection", "average → push toward N(0, I)", "total loss = MSE + λ · SIGReg"] } } ],
          output: { label: "zₜ (192-d)" } },
        { mod: "pred", title: "Predictor", sub: "≈10M · AdaLN-zero · causal",
          input: { label: "zₜ₋₂, zₜ₋₁, zₜ", caption: "history 3 (1 for TwoRoom)" },
          rows: [
            { t: "embed", label: "+ learned position embedding" },
            { t: "block", n: "6", rows: [
              { id: "n1", t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN", zoom: { k: "rows", title: "AdaLN-zero", rows: ["action embedding c (192-d)", "SiLU → Linear → 6 × 192", "shift, scale, gate × 2", "zero-init: starts as identity", "x + gate · f(modulate(LN(x)))"] } },
              { t: "attn", label: "Causal self-attention", call: ["16 heads × 64, dropout 0.1", "c1", "p6"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Predictor heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["192 → 2,048 → 192, GELU", "c1", "c3"] },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "mlp", label: "Projector: BatchNorm MLP", call: ["Same shape as the encoder's", "p1", "c1"],
              zoom: { k: "rows", title: "CEM planning", rows: ["encode o₁ and the goal image", "300 action plans, horizon 5 blocks", "roll the predictor forward", "cost ‖ẑ_H − z_goal‖²", "30 elites; 30 iterations (PushT)"] } } ],
          output: { label: "ẑₜ₊₁" } },
        { mod: "act", title: "Action embedder", sub: "per block of 5 actions", compact: true,
          input: { label: "Action block aₜ", caption: "5 actions (frame-skip 5)" },
          rows: [
            { t: "conv", label: "Conv1d, kernel 1", call: ["→ 10 channels", "c3"] },
            { t: "mlp", label: "Linear · SiLU · Linear", call: ["10 → 768 → 192", "c1", "c3"] } ],
          output: { label: "action embedding" } }
      ],
      links: [
        { from: "enc", to: "pred", toRow: "input", label: "zₜ (192-d)" },
        { from: "act", to: "pred", toRow: "n1", label: "cond c" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", roleLabel: "Encoder", name: "ViT-Tiny + projector", sub: "12 × 192 · 3 heads · p14", col: 0, frozen: false, short: "ViT-T" },
      { id: "pred", role: "world", roleLabel: "Latent predictor", name: "AdaLN transformer", sub: "6 layers · 16 heads", col: 1, frozen: false, main: true, short: "Predictor",
        stack: { rows: [
          { t: "in", label: "[zₜ₋₂, zₜ₋₁, zₜ] + positions", dims: "3 × 192", c: "data-7" },
          { t: "block", label: "Conditional block", n: "6", rows: [
            { t: "norm", label: "LayerNorm (no affine) · shift, scale", side: "cond" },
            { t: "attn", label: "Causal MHA · 16 × 64", dims: "dropout 0.1" },
            { t: "adaln", label: "× gate_msa" },
            { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm (no affine) · shift, scale", side: "cond" },
            { t: "ffn", label: "MLP 192 → 2,048 → 192 · GELU" },
            { t: "adaln", label: "× gate_mlp" },
            { t: "add", span: 3 } ], note: "cond → SiLU → Linear → 6 × 192, zero-initialised" },
          { t: "norm", label: "LayerNorm" },
          { t: "mlp", label: "Projector: Linear → BN → GELU → Linear" },
          { t: "out", label: "ẑₜ₊₁", dims: "loss ‖ẑₜ₊₁ − zₜ₊₁‖²", c: "data-7" } ],
          facts: [["Depth / heads / head dim", ["6 / 16 / 64", "p1", "c1"]], ["Width", ["192 (config); paper App. D says ViT-S", "c1", "p4"]], ["Dropout", ["0.1 (best in Table 9)", "p6", "c1"]], ["SIGReg weight", ["λ = 0.1 (paper), 0.09 (config)", "p2", "c2"]], ["Optimiser", ["AdamW, lr 5 × 10⁻⁵, bf16", "c2"]]] } },
      { id: "act", role: "net", roleLabel: "Action embedder", name: "Conv1d + MLP", sub: "→ 192-d", col: 2, frozen: false, short: "Actions" }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "frames", n: "224 × 224", k: 3 },
      { to: "act", mod: "action", label: "action blocks", n: "5 actions each", k: 2 }
    ],
    outputs: [
      { from: "enc", mod: "latent", label: "zₜ", n: "192-d, SIGReg", k: 2 },
      { from: "pred", mod: "latent", label: "ẑₜ₊₁", n: "192-d", k: 2 }
    ],
    links: [
      { from: "enc", to: "pred", kind: "latent", label: "CLS → projector|zₜ" },
      { from: "act", to: "pred", kind: "adaln", label: "action embedding" }
    ],
    mask: { name: "Temporal causal", ref: "p1", axes: [{ label: "zₜ₋₂", short: "t−2", mod: "latent" }, { label: "zₜ₋₁", short: "t−1", mod: "latent" }, { label: "zₜ", short: "t", mod: "latent" }], m: ["100", "110", "111"],
      note: "Each frame embedding attends only to itself and earlier frames; actions enter through AdaLN, not as tokens." },
    callouts: [
      "Paper App. D calls the predictor a <b>ViT-S</b> backbone; the released config builds it at width <b>192</b> (ViT-Tiny width) with 16 heads × 64 and an MLP of 2,048.",
      "Paper Alg. 1 sets λ = 0.1; the released training config uses <b>0.09</b> (Fig. 16 notes the peak near 0.09). App. A integrates Epps–Pulley on [0.2, 4]; the code uses 17 knots on [0, 3]."
    ]
  });

  /* ------------------------------------------------------------------ SuccessVQA */
  var SV = "2303.07280";
  RB.arch.spec({
    id: "successvqa", method: "successvqa", name: "SuccessVQA", year: 2023,
    figRef: "Du et al. Figs. 2–3, 6 · §3, §5.1", prov: "Robotics setting",
    lede: "Success detection as video question answering: a fine-tuned Flamingo 3B watches an 8-frame clip and answers “Did the robot successfully {task}?” with yes or no. The vision side is fine-tuned; the language model stays frozen.",
    sources: {
      p1: P("Du et al. 2023, §3 (SuccessVQA format, fine-tuning)", SV),
      p2: P("Du et al. 2023, §5.1 (robotics data, episode rule)", SV),
      p3: P("Du et al. 2023, §2 (Flamingo: resampler, cross-attention, frozen LM)", SV),
      p4: P("Du et al. 2023, §6 (Ego4D, zero-shot Flamingo)", SV)
    },
    summary: {
      pattern: ["Learned verifier / failure detector (VLM success detector)", "p1"],
      params: ["3B (Flamingo 3B)", "p1"],
      vision: ["Flamingo vision encoder + Perceiver Resampler, both fine-tuned", "p1", "p3"],
      backbone: ["Frozen Flamingo language model with interleaved cross-attention layers (fine-tuned)", "p1", "p3"],
      head: "The language model's answer text: “yes” or “no”",
      output: ["Clip-level yes / no; robot episode succeeds if the first clip is “no” and the last is “yes”", "p2"],
      attention: ["Text tokens cross-attend to resampled visual tokens", "p3"],
      cond: "Question template “Did the robot / agent / person successfully {task}?”",
      steps: null,
      chunk: ["8-frame clips: 211 frames at 30 FPS subsampled to 1 FPS", "p1"],
      rate: null, latency: null,
      train: ["One model per domain on human success labels; robotics: 101,789 demos over 6 gear tasks", "p2"]
    },
    blueprint: {
      headline: "SuccessVQA: ask a VLM whether it worked",
      note: "A clip of 8 frames is encoded and resampled into a fixed set of visual tokens. The question is fed to the frozen language model, whose layers are interleaved with gated cross-attention to those tokens. Its next-token answer is the success label; an episode rule turns clip labels into a verdict.",
      towers: [
        { mod: "vis", title: "Vision side", sub: "fine-tuned", compact: true,
          input: { label: "8-frame clip", caption: "211 frames at 30 FPS → 1 FPS" },
          rows: [
            { t: "conv", label: "Vision encoder (per frame)", call: ["Contrastively pretrained, fine-tuned", "p1", "p3"] },
            { t: "attn", label: "Perceiver Resampler", call: ["Fine-tuned", "p1"] } ],
          output: { label: "visual tokens" } },
        { mod: "lm", title: "Flamingo 3B language side", sub: "LM frozen · cross-attention trained",
          input: { label: "Question tokens", caption: "“Did the robot successfully insert medium gear?”" },
          rows: [
            { t: "group", label: "Interleaved (depth not given)", rows: [
              { id: "xa", t: "attn", label: "Gated cross-attention", side: "cond", call: ["Trained: attends to visual tokens", "p1", "p3"] },
              { t: "attn", label: "LM self-attention (frozen)" },
              { t: "ffn", label: "LM feed-forward (frozen)" } ] },
            { t: "linear", label: "Next-token logits", call: ["Answer “yes” or “no”", "p1"] } ],
          output: { label: "yes / no per clip" } },
        { mod: "rule", title: "Episode rule", sub: "robotics domain", compact: true,
          input: { label: "Clip answers", caption: "in time order" },
          rows: [{ t: "linear", label: "First “no”, last “yes”", call: ["Matches the bespoke detector's rule", "p2"] }],
          output: { label: "episode success" } }
      ],
      links: [
        { from: "vis", to: "lm", toRow: "xa", label: "visual tokens" },
        { from: "lm", to: "rule", toRow: "input", label: "clip labels" }
      ]
    },
    modules: [
      { id: "vis", role: "vision-enc", roleLabel: "Vision encoder", name: "Encoder + Perceiver", sub: "fine-tuned", col: 0, frozen: false, short: "Vision" },
      { id: "lm", role: "vlm", roleLabel: "Flamingo 3B", name: "Frozen LM + gated xattn", sub: "3B · answers yes / no", col: 1, frozen: "partial", main: true, short: "Flamingo",
        stack: { rows: [
          { t: "in", label: "question tokens", dims: "success template", c: "data-2" },
          { t: "attn", label: "gated cross-attention to visual tokens", dims: "fine-tuned" },
          { t: "attn", label: "LM self-attention", dims: "frozen" },
          { t: "ffn", label: "LM feed-forward", dims: "frozen" },
          { t: "out", label: "answer: yes / no", c: "data-8" } ],
          facts: [["Size", ["3B", "p1"]], ["Trained parts", ["vision encoder, Perceiver Resampler, cross-attention", "p1"]], ["Clip", ["8 frames at 1 FPS", "p1"]], ["Zero-shot Flamingo", ["50 % balanced accuracy on Ego4D (chance)", "p4"]]] } },
      { id: "rule", role: "net", roleLabel: "Episode rule", name: "Clip → episode", sub: "first no, last yes", col: 2, frozen: false, short: "Rule" }
    ],
    inputs: [
      { to: "vis", mod: "vision", label: "video clip", n: "8 frames", k: 4 },
      { to: "lm", mod: "lang", label: "success question", n: "task in words", k: 3 }
    ],
    outputs: [
      { from: "lm", mod: "other", label: "yes / no", n: "per clip", k: 1 },
      { from: "rule", mod: "other", label: "episode verdict", n: "success / failure", k: 1 }
    ],
    links: [
      { from: "vis", to: "lm", kind: "cross-attn", label: "resampled|visual tokens" },
      { from: "lm", to: "rule", kind: "feeds", label: "clip answers" }
    ],
    callouts: [
      "The paper does not restate Flamingo 3B's layer sizes and releases no code, so the blueprint stops at the level it discloses.",
      "Robustness is the point: with a new camera view, the fine-tuned Flamingo loses under 10 points of balanced accuracy while the bespoke ResNet-18 detector loses up to 48 (Table 5)."
    ]
  });

  /* ------------------------------------------------------------------ RoVer */
  var RV = "2510.10975";
  RB.arch.spec({
    id: "rover", method: "rover", name: "RoVer", year: 2025, parent: "robomonkey",
    diffRows: ["params", "vision", "backbone", "head", "output", "latency", "train"],
    figRef: "Dai et al. Figs. 1–2 · §3.2 · Alg. 1 · Table 4", prov: "CALVIN verifier",
    lede: "A 0.2B GPT-2-style process reward model built on GR-1. It scores a candidate 7-D action and also predicts a direction toward a better one; candidates are expanded along that direction and the top-scoring one is executed.",
    sources: {
      p1: P("Dai et al. 2025, §3.2.1 (architecture, action amplifier)", RV),
      p2: P("Dai et al. 2025, §3.2.2 (anchor-centred pairs, losses, Eqs. 3–14)", RV),
      p3: P("Dai et al. 2025, §3.2.3 and Alg. 1 (direction-guided sampling)", RV),
      p4: P("Dai et al. 2025, App. A.3, Table 4 (hyperparameters)", RV),
      p5: P("Dai et al. 2025, §4.1 (setup, Fig. 3, Table 2)", RV)
    },
    summary: {
      pattern: ["Learned verifier / failure detector (process reward model)", "p1"],
      params: ["0.2B total, 40M trainable", "p5"],
      vision: ["MAE ViT (patch 16), frozen, + Perceiver Resampler: 9 latents, depth 3, 4 heads × 128", "p4", "p5"],
      backbone: ["GPT-2-style transformer from GR-1: 12 layers, H = 384, 12 heads, FFN 4H, dropout 0.1", "p1", "p4"],
      head: ["Reward MLP 384 → 192 → 96 → 1; direction MLP 384 → 192 → d_dir", "p4"],
      output: ["Scalar process reward r and unit direction û (6-D pose on CALVIN)", "p1", "p2"],
      attention: null,
      cond: ["CLIP text 512 → 384; state 6 pose + 2 gripper; candidate 7-D action through an amplifier 384 → 768 → 384", "p4"],
      steps: ["N policy proposals + M guided expansions (up to 5 + 5); execute argmax r", "p3", "p5"],
      chunk: null, rate: null,
      latency: ["6.17 ms per candidate at 100 candidates with the perception cache (V100)", "p5"],
      train: ["Bradley–Terry on better/worse pairs around expert actions + cosine direction loss; 20 % of CALVIN ABC, 100 epochs", "p2", "p5"]
    },
    changes: [
      "The verifier shrinks from a <b>7B VLM</b> to a <b>0.2B</b> GPT-2-style model (40M trained) initialised from GR-1.",
      "A <b>direction head</b> predicts where a better action lies; candidates are expanded inside a cone around it.",
      "Perception is <b>encoded once</b> per step and cached; only the action token changes per candidate (6.71× at 100).",
      "Preference pairs are sampled <b>around expert actions</b>: the one closer to the expert is better.",
      "An <b>action amplifier</b> MLP keeps small action differences visible to the frozen backbone."
    ],
    blueprint: {
      headline: "RoVer: score the action, point to a better one",
      note: "Images, text and state are encoded once per control step and cached. Each candidate action is embedded, amplified and appended with a reward token and a direction token; the GPT-2 stack reads the whole sequence and two MLP heads read the two tokens.",
      towers: [
        { mod: "per", title: "Perception cache", sub: "frozen encoders · once per step", compact: true,
          input: { label: "RGB × 2 · text · state", caption: "third-person + wrist" },
          rows: [
            { t: "conv", label: "MAE ViT (frozen)", call: ["Patch 16", "p4"] },
            { t: "attn", label: "Perceiver Resampler", call: ["9 latents, depth 3, 4 heads", "p4"] },
            { t: "linear", label: "CLIP text 512 → 384", call: ["CLIP text encoder frozen", "p4", "p5"] } ],
          output: { label: "cached tokens" } },
        { mod: "gpt", title: "GPT-2 verifier", sub: "GR-1 init · reward + direction tokens",
          input: { label: "[obs | action | r | d]", caption: "one candidate per sequence" },
          rows: [
            { t: "embed", label: "+ learned positions", call: ["1,024 positions, L = 10 max", "p4"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "Multi-head self-attention", call: ["12 heads, H = 384", "p4"], zoom: { k: "heads", q: 12, kv: 12, hd: 32, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["4H = 1,536", "p4"] },
              { t: "add", span: 2 } ] },
            { t: "mlp", label: "Reward head on r token", call: ["384 → 192 → 96 → 1", "p4"],
              zoom: { k: "rows", title: "Training pairs", rows: ["anchor = expert + N(0, 0.1²)", "u = unit vector anchor → expert", "better: noise on the +u side", "worse: noise on the −u side", "Bradley–Terry + (1 − cos) loss"] } },
            { t: "mlp", label: "Direction head on d token", call: ["384 → 192 → d_dir", "p1", "p4"],
              zoom: { k: "rows", title: "Direction-guided expansion", rows: ["N proposals from frozen policy", "û = direction head for each", "sample angle θ ~ U(0, α) off û", "magnitude m ~ |N(0, σ²)|", "score all, execute the argmax"] } } ],
          output: { label: "r and û" } },
        { mod: "act", title: "Action encoder", sub: "per candidate", compact: true,
          input: { label: "Candidate aᵢ", caption: "7-D: Δpose (6) + gripper" },
          rows: [
            { t: "linear", label: "Linear 7 → 384", call: ["Action dim 7", "p4"] },
            { t: "mlp", label: "Action amplifier", call: ["384 → 768 → 384, GELU + LN", "p1", "p4"], zoom: { k: "mlp", act: "GELU", d: "384", ff: "768", title: "Action amplifier" } } ],
          output: { label: "action token" } }
      ],
      links: [
        { from: "per", to: "gpt", toRow: "input", label: "cached tokens" },
        { from: "act", to: "gpt", toRow: "input", label: "action token" }
      ]
    },
    modules: [
      { id: "per", role: "vision-enc", roleLabel: "Perception cache", name: "MAE ViT + CLIP text", sub: "+ Perceiver · frozen", col: 0, frozen: true, short: "Perception" },
      { id: "gpt", role: "critic", roleLabel: "Process reward model", name: "GPT-2 verifier", sub: "12 × 384 · 12 heads", col: 1, frozen: false, main: true, short: "RoVer",
        stack: { rows: [
          { t: "in", label: "[text | state | image latents | action | r | d]", dims: "shared prefix cached", c: "data-8" },
          { t: "block", label: "GPT-2 block", n: "12", rows: [
            { t: "norm", label: "LayerNorm" },
            { t: "attn", label: "MHA · 12 heads · H = 384" },
            { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" },
            { t: "ffn", label: "MLP 384 → 1,536 → 384" },
            { t: "add", span: 2 } ] },
          { t: "mlp", label: "reward head H → H/2 → H/4 → 1" },
          { t: "mlp", label: "direction head H → H/2 → d_dir" },
          { t: "out", label: "r (scalar), û (unit vector)", c: "data-8" } ],
          facts: [["Hidden / layers / heads", ["384 / 12 / 12", "p4"]], ["Parameters", ["0.2B total, 40M trainable", "p5"]], ["Base noise σ_base", ["0.1", "p2"]], ["Cache speed-up", ["4.46× at 10, 6.71× at 100 candidates", "p5"]]] } },
      { id: "act", role: "net", roleLabel: "Action encoder", name: "Linear + amplifier", sub: "7 → 384 → 768 → 384", col: 2, frozen: false, short: "Action" }
    ],
    inputs: [
      { to: "per", mod: "vision", label: "static + wrist RGB", n: "once per step", k: 3 },
      { to: "per", mod: "lang", label: "instruction", n: "CLIP text", k: 2 },
      { to: "act", mod: "action", label: "candidate action", n: "7-D, N + M of them", k: 3 }
    ],
    outputs: [
      { from: "gpt", mod: "other", label: "reward r", n: "per candidate", k: 1 },
      { from: "gpt", mod: "action", label: "direction û", n: "6-D pose", k: 2 }
    ],
    links: [
      { from: "per", to: "gpt", kind: "prefix", label: "cached tokens" },
      { from: "act", to: "gpt", kind: "prefix", label: "action token" }
    ],
    callouts: [
      "With MoDE, which outputs action chunks, only the first action of each chunk is scored, so gains are less stable (the chunk–step mismatch, §4.1 Q2).",
      "No code is released yet, so every number comes from the paper's Table 4 and §4.1."
    ]
  });

  /* ------------------------------------------------------------------ MG-Select */
  var MG = "2510.05681";
  RB.arch.spec({
    id: "mg-select", method: "mg-select", name: "MG-Select (on π0-FAST)", year: 2025, parent: "robomonkey",
    diffRows: ["pattern", "params", "backbone", "cond", "steps", "latency", "train"],
    figRef: "Jang et al. Fig. 1 · §3 · Table 5 · App. A", prov: "π0-FAST host, RoboCasa",
    lede: "No verifier at all: the same autoregressive VLA samples 4 action chunks, then runs again with the instruction or state masked. The chunk whose token distributions differ most (by KL) from that masked reference is the most confident and is executed.",
    sources: {
      p1: P("Jang et al. 2025, §3.1 (sampling, Best-of-N)", MG),
      p2: P("Jang et al. 2025, §3.2 (condition-masking KL, Eqs. 1–3)", MG),
      p3: P("Jang et al. 2025, §3.3 (joint training with condition dropout)", MG),
      p4: P("Jang et al. 2025, Table 5 (ablations: N, τ, aggregation)", MG),
      p5: P("Jang et al. 2025, App. A (implementation)", MG),
      p6: P("Jang et al. 2025, Fig. 3 and App. C, Table 10 (single prefill)", MG)
    },
    summary: {
      pattern: ["Verifier-free Best-of-N on an autoregressive VLA", "p1"],
      params: ["No new parameters; host π0-FAST on PaliGemma-3B", "p5"],
      vision: ["The host VLA's own (PaliGemma-3B)", "p5"],
      backbone: ["π0-FAST, fully fine-tuned; MG-Select* adds 10 % text / 10 % state / 10 % both dropout", "p3", "p5"],
      head: "The host's FAST action-token logits",
      output: ["Best of N = 4 sampled action chunks", "p4"],
      attention: null,
      cond: ["Reference pass: same VLA with text and/or state masked, softened by temperature 4", "p2", "p4"],
      steps: ["N = 4 samples at temperature 0.5; score = Σ KL(Q‖P) over the first 5 action tokens", "p4", "p5"],
      chunk: ["16 actions on RoboCasa (5 SIMPLER, 10 LIBERO)", "p5"],
      rate: null,
      latency: ["One shared prefill: 45 % lower latency than vanilla MG-Select at N = 4", "p6"],
      train: ["Optional joint imitation learning over all four masking variants (MG-Select*)", "p3"]
    },
    changes: [
      "The <b>external 7B verifier is gone</b>: the score comes from the VLA's own token distributions.",
      "Score = <b>KL from a condition-masked reference</b> (text and/or state removed) to the predicted distribution.",
      "Needs token probabilities, so it applies to <b>autoregressive VLAs</b> (π0-FAST, OpenVLA, MiniVLA).",
      "Optional <b>condition-dropout fine-tuning</b> teaches the model what the masked distributions look like.",
      "A <b>single shared prefill</b> keeps N = 4 sampling close to single-sample latency."
    ],
    blueprint: {
      headline: "MG-Select: the VLA judges its own samples",
      note: "One prefill of images, state and instruction is shared by N = 4 sampled decodes. The same weights, run with the instruction (or state) masked, give a reference distribution Q at each token. Each candidate's confidence is the summed KL(Q‖P) over its first 5 FAST tokens; the highest wins.",
      towers: [
        { mod: "vla", title: "π0-FAST (policy pass)", sub: "PaliGemma-3B · autoregressive",
          input: { label: "Images · state · text", caption: "full conditions" },
          rows: [
            { t: "attn", label: "Prefill (shared KV cache)", call: ["One prefill for all N samples", "p6"] },
            { t: "attn", label: "Decode FAST tokens", call: ["PaliGemma-3B backbone", "p5"],
              zoom: { k: "rows", title: "MG-Select* fine-tuning", rows: ["imitation loss on FAST tokens", "10 %: instruction dropped", "10 %: state dropped", "10 %: both dropped", "learns the masked distributions"] } },
            { t: "linear", label: "Sample N chunks", call: ["N = 4, temperature 0.5", "p4"] } ],
          output: { label: "candidates ã⁽ⁿ⁾ and P per token" } },
        { mod: "ref", title: "Reference pass", sub: "same weights, conditions masked", compact: true,
          input: { label: "Images · masked text", caption: "teacher-forced on each candidate" },
          rows: [
            { t: "attn", label: "Same VLA, masked input", call: ["Text masking best on RoboCasa", "p4"] },
            { t: "linear", label: "softmax(ℓ / 4) → Q", call: ["Regularisation temperature 4", "p4"] } ],
          output: { label: "reference Q per token" } },
        { mod: "sel", title: "Best-of-N selector", sub: "no parameters", compact: true,
          input: { label: "P and Q per token", caption: "for each candidate" },
          rows: [
            { t: "linear", label: "Cᵢ = KL(Qᵢ ‖ Pᵢ)", call: ["Token-level confidence", "p2"] },
            { t: "pool", label: "Sum over first 5 tokens", call: ["Best of sum, avg, first 1–10", "p4"],
              zoom: { k: "rows", title: "Why the first 5 tokens", rows: ["FAST: low → high frequency", "early tokens: coarse motion", "sum over all tokens scored worst", "first 5 scored best on RoboCasa", "OpenVLA: average over tokens"] } },
            { t: "linear", label: "argmax over N" } ],
          output: { label: "executed chunk" } }
      ],
      links: [
        { from: "vla", to: "sel", toRow: "input", label: "P, candidates" },
        { from: "ref", to: "sel", toRow: "input", label: "Q" }
      ]
    },
    modules: [
      { id: "vla", role: "vlm", roleLabel: "Host VLA (policy pass)", name: "π0-FAST", sub: "PaliGemma-3B · FAST tokens", col: 0, frozen: false, main: true, short: "π0-FAST",
        stack: { rows: [
          { t: "in", label: "images · state · instruction", c: "data-1" },
          { t: "attn", label: "prefill once, share KV cache", dims: "single-prefill deployment" },
          { t: "attn", label: "decode N = 4 samples in parallel", dims: "temperature 0.5" },
          { t: "out", label: "candidates and per-token P", c: "data-3" } ],
          facts: [["Candidates N", ["4 (gains past 4 are marginal)", "p4"]], ["Sampling temperature", ["0.5", "p4"]], ["Reference temperature", ["4 (best of 0.5–8)", "p4"]], ["Aggregation", ["sum of first 5 tokens", "p4", "p5"]], ["Latency at N = 4", ["23.7 s vs 43.4 s per episode (LIBERO-Object, A100)", "p6"]]] } },
      { id: "sel", role: "critic", roleLabel: "Selector (no weights)", name: "KL confidence", sub: "Best-of-N", col: 1, frozen: true, note: "A fixed rule with no parameters.", short: "Select" },
      { id: "ref", role: "vlm", roleLabel: "Same VLA, masked", name: "Reference pass", sub: "text and/or state masked", col: 2, frozen: false, short: "Reference" }
    ],
    inputs: [
      { to: "vla", mod: "vision", label: "images", n: "", k: 3 },
      { to: "vla", mod: "lang", label: "instruction", n: "", k: 2 },
      { to: "vla", mod: "state", label: "state", n: "", k: 1 },
      { to: "ref", mod: "vision", label: "images, masked text", n: "", k: 3 }
    ],
    outputs: [
      { from: "vla", mod: "action", label: "N = 4 chunks", n: "FAST tokens", k: 4 },
      { from: "sel", mod: "action", label: "chosen chunk", n: "argmax C", k: 2 }
    ],
    links: [
      { from: "vla", to: "sel", kind: "feeds", label: "P per token" },
      { from: "ref", to: "sel", kind: "feeds", label: "Q per token" }
    ],
    callouts: [
      "MG-Select adds no network: the drawing shows the host π0-FAST used twice. Against RoboMonkey's 7B verifier at N = 4 it scores 50.3 vs 50.7 on SIMPLER-WidowX at 880 vs 1,195 ms (Table 14).",
      "On RoboCasa with 30 demos, MG-Select* lifts pick-and-place from 5.3 % to 14.2 % (Table 8). No code is released; the linked GitHub repository holds only the project page."
    ]
  });

  /* ------------------------------------------------------------------ Foresight */
  var FS = "2606.23085";
  RB.arch.spec({
    id: "foresight", method: "foresight", name: "Foresight", year: 2026, parent: "safe",
    diffRows: ["pattern", "params", "vision", "backbone", "head", "cond", "latency"],
    figRef: "Zhang, Lu et al. Fig. 1 · §4 · App. 7, 9, 14", prov: "Foresight-Transformer",
    lede: "A failure detector that never looks inside the policy. A V-JEPA 2-AC world model predicts the scene latent after the policy's next action chunk; a small causal transformer reads those predictions over the rollout and a conformal band turns its score into an alarm.",
    sources: {
      p1: P("Zhang, Lu et al. 2026, §4.2 (world-model features, Eqs. 5–7)", FS),
      p2: P("Zhang, Lu et al. 2026, §4.3 (causal failure scorer)", FS),
      p3: P("Zhang, Lu et al. 2026, §4.4 and App. 9 (functional CP)", FS),
      p4: P("Zhang, Lu et al. 2026, App. 7 (implementation details)", FS),
      p5: P("Zhang, Lu et al. 2026, App. 14, Table 14 (parameters, latency)", FS),
      p6: P("Zhang, Lu et al. 2026, Table 2 (simulation results)", FS),
      p7: P("Zhang, Lu et al. 2026, App. 12.2, Table 13 (hidden vs predicted latents)", FS)
    },
    summary: {
      pattern: ["Learned verifier / failure detector", "p2"],
      params: ["Detector 2.0M; world model 1,317M (encoder 1,012M + AC predictor 305M)", "p5"],
      vision: ["V-JEPA 2 ViT-g/16, frozen: 256 × 256, tubelet 2, 256 patches per frame, 8-frame windows", "p4"],
      backbone: ["AC predictor trained from scratch per dataset: 24 layers, width 1,024, 16 heads, frame-causal", "p4"],
      head: ["Causal transformer: Linear 1,408 → 256, 2 pre-norm layers, 4 heads, FFN 1,024, sigmoid", "p4"],
      output: ["Per-step failure score sₜ; alarm when sₜ ≥ δₜ", "p2", "p3"],
      attention: ["Causal mask over replanning steps", "p2", "p4"],
      cond: ["The policy's predicted action chunk (7-D to 23-D by robot)", "p4"],
      steps: ["One call per action-chunk boundary", "p5"],
      chunk: null, rate: null,
      latency: ["≈183 ms per call on one H200; the world model is > 99 %", "p5"],
      train: ["Trajectory-level labels only (per-step BCE, early-detection weighting); predictor: teacher-forcing + 2-step rollout L1", "p2", "p4"]
    },
    changes: [
      "Reads <b>action-conditioned world-model latents</b> (V-JEPA 2-AC) instead of the policy's hidden states, so it needs no policy internals.",
      "Uses the <b>policy's next action chunk</b>: the predictor forecasts the scene after it.",
      "The scorer is a <b>2-layer causal transformer</b> (256-d, 4 heads) over the rollout, not a per-step MLP or LSTM.",
      "Keeps SAFE's recipe: <b>trajectory-level labels</b> and a <b>functional conformal</b> threshold.",
      "Costs ≈183 ms per chunk for the world model, where SAFE's probe costs under 1 ms."
    ],
    blueprint: {
      headline: "Foresight: judge the predicted future",
      note: "Every chunk boundary, 8 frames go through the frozen ViT-g encoder. The trained predictor combines them with the policy's next action chunk and predicts future patch latents, mean-pooled to one 1,408-d vector zₚ. The causal scorer reads the sequence of zₚ and outputs sₜ.",
      towers: [
        { mod: "enc", title: "V-JEPA 2 encoder", sub: "ViT-g/16 · frozen · 1,012M", compact: true,
          input: { label: "8-frame window", caption: "256 × 256, ImageNet-normalised" },
          rows: [
            { t: "conv", label: "Tubelet 2 × 16 × 16", call: ["256 patches per frame", "p4"] },
            { t: "attn", label: "ViT-g/16 (frozen)", call: ["Embedding dim 1,408", "p4"] } ],
          output: { label: "zₕ (observed patches)" } },
        { mod: "pred", title: "Action-conditioned predictor", sub: "305M · trained from scratch",
          input: { label: "[zₕ ‖ action chunk Aₜ]", caption: "chunk 7-D to 23-D" },
          rows: [
            { t: "block", n: "24", rows: [
              { t: "attn", label: "Frame-causal attention", call: ["Width 1,024, 16 heads", "p4"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Predictor heads" } },
              { t: "ffn", label: "Feed forward (MLP)" } ] },
            { t: "pool", label: "Mean-pool 256 patches", call: ["→ zₚ ∈ ℝ¹⁴⁰⁸", "p1", "p4"],
              zoom: { k: "rows", title: "Predictor training", rows: ["encoder frozen throughout", "teacher-forcing pass", "2-step autoregressive rollout pass", "L1 on LayerNorm-ed features", "AdamW, 200 epochs, cosine"] } } ],
          output: { label: "zₚ (predicted future)" } },
        { mod: "det", title: "Causal failure scorer", sub: "2.0M · Foresight-Transformer",
          input: { label: "zₚ₁ … zₚₜ", caption: "one token per replanning step" },
          rows: [
            { t: "linear", label: "Linear 1,408 → 256", call: ["+ sinusoidal positions", "p1", "p4"] },
            { t: "block", n: "2", rows: [
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "Causal self-attention", call: ["4 heads, width 256", "p4"], zoom: { k: "heads", q: 4, kv: 4, hd: 64, title: "Scorer heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward", call: ["256 → 1,024 → 256", "p4"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Linear → sigmoid", call: ["sₜ ∈ [0, 1], dropout 0.1", "p4"],
              zoom: { k: "rows", title: "Functional conformal band", rows: ["successful calibration rollouts", "μₜ = mean score curve, σₜ = spread", "Rᵢ = supₜ (sₜ − μₜ) / σₜ", "q̂ = (1 − α) quantile of Rᵢ", "alarm when sₜ ≥ μₜ + q̂ σₜ"] } } ],
          output: { label: "failure score sₜ" } }
      ],
      links: [
        { from: "enc", to: "pred", toRow: "input", label: "zₕ" },
        { from: "pred", to: "det", toRow: "input", label: "zₚ (1,408-d)" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", roleLabel: "World-model encoder", name: "V-JEPA 2 ViT-g/16", sub: "frozen · 1,408-d", col: 0, frozen: true, short: "ViT-g" },
      { id: "pred", role: "world", roleLabel: "AC predictor", name: "V-JEPA 2-AC predictor", sub: "24 × 1,024 · 16 heads", col: 1, frozen: false, short: "Predictor" },
      { id: "det", role: "critic", roleLabel: "Failure scorer", name: "Causal transformer", sub: "2 × 256 · 4 heads", col: 2, frozen: false, main: true, short: "Foresight",
        stack: { rows: [
          { t: "in", label: "zₚ per replanning step", dims: "1,408-d", c: "data-7" },
          { t: "linear", label: "Linear 1,408 → 256 + sinusoidal PE" },
          { t: "block", label: "Pre-norm encoder layer", n: "2", rows: [
            { t: "norm", label: "LayerNorm" },
            { t: "attn", label: "causal MHA · 4 heads" },
            { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" },
            { t: "ffn", label: "MLP 256 → 1,024 → 256" },
            { t: "add", span: 2 } ] },
          { t: "linear", label: "Linear → sigmoid" },
          { t: "out", label: "sₜ; alarm if sₜ ≥ δₜ", c: "data-8" } ],
          facts: [["Layers / width / heads", ["2 / 256 / 4", "p4"]], ["Training", ["Adam 10⁻⁴, λ = 10⁻², 300 epochs, batch 512", "p4"]], ["Latency (head only)", ["0.91 ms", "p5"]], ["BEHAVIOR-1K", ["balanced accuracy 0.78 vs 0.64 best baseline", "p6"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "8 frames", n: "256 × 256", k: 4 },
      { to: "pred", mod: "action", label: "policy's next chunk", n: "7-D to 23-D", k: 3 }
    ],
    outputs: [
      { from: "pred", mod: "latent", label: "zₚ", n: "1,408-d", k: 2 },
      { from: "det", mod: "other", label: "failure score", n: "per step", k: 1 }
    ],
    links: [
      { from: "enc", to: "pred", kind: "latent", label: "zₕ patches" },
      { from: "pred", to: "det", kind: "feeds", label: "pooled zₚ" }
    ],
    callouts: [
      "Action conditioning matters: predicted latents zₚ beat observed latents zₕ on LIBERO-Long with every scorer (e.g. ROC-AUC 0.89 vs 0.85 for the transformer, Table 13).",
      "No code is released; all sizes come from App. 7 and Table 14."
    ]
  });

  /* ------------------------------------------------------------------ Tri-Info */
  var TI = "2606.19998";
  RB.arch.spec({
    id: "tri-info", method: "tri-info", name: "Tri-Info", year: 2026, parent: "safe",
    diffRows: ["pattern", "vision", "backbone", "head", "cond", "latency", "train"],
    figRef: "Yang et al. Figs. 2–3 · §3 · App. B, C.1 · Table 5", prov: "Mean-fusion detector",
    lede: "Reads how information flows, not what the embeddings say. From the VLA's state and action embeddings it estimates action entropy, action-to-action and transition-to-action mutual information over a sliding window; one GRU per signal turns each into a failure probability.",
    sources: {
      p1: P("Yang et al. 2026, §3.1 (state and action embeddings)", TI),
      p2: P("Yang et al. 2026, §3.2 (eight metrics → three, sliding window)", TI),
      p3: P("Yang et al. 2026, §3.3 (GRU detector, fusion, CP threshold, Eqs. 2–5)", TI),
      p4: P("Yang et al. 2026, App. B and Table 5–6 (VAE, k-NN estimators)", TI),
      p5: P("Yang et al. 2026, App. C.1 (detector training)", TI),
      p6: P("Yang et al. 2026, App. B, Table 7 (latency)", TI),
      p7: P("Yang et al. 2026, Table 8 and §5.2 (data, transfer results)", TI)
    },
    summary: {
      pattern: ["Learned verifier / failure detector", "p3"],
      params: null,
      vision: ["None of its own: state embedding from the host VLA's visual encoder", "p1"],
      backbone: ["Per-model VAEs compress state and action embeddings to 7-D latents", "p4"],
      head: ["One GRU per signal (hidden 256 in-domain, 32 out-of-domain) + MLP halving to 1, sigmoid; mean of 3", "p3", "p5"],
      output: ["Fused P(failure) per step; alarm above a conformal band θ(t)", "p3"],
      attention: "None (recurrent)",
      cond: ["H(Aₜ), I(Aₜ; Aₜ₊₁), I(Sₜ, Sₜ₊₁; Aₜ) over a W = 30 window, k = 5 neighbours", "p2", "p4"],
      steps: null, chunk: null, rate: null,
      latency: ["At most 5.30 ms per inference (H800, W = 50)", "p6"],
      train: ["Per-step BCE with the trajectory label; Adam 10⁻³, 50–100 epochs; 3,290 rollouts from 6 VLAs", "p5", "p7"]
    },
    changes: [
      "Feeds the detector <b>entropy and mutual-information statistics</b> of the embeddings, not the embeddings themselves, so it transfers across models.",
      "Three signals: <b>action entropy</b>, <b>action-to-action MI</b> and <b>transition-to-action MI</b>, over a 30-step window.",
      "<b>One small GRU per signal</b> with late mean fusion, instead of one probe on the features.",
      "Per-model <b>7-D VAEs</b> make k-NN estimation workable in low dimension.",
      "The same functional conformal threshold; 0.83 balanced accuracy sim-to-real where baselines sit at chance."
    ],
    blueprint: {
      headline: "Tri-Info: watch the information, not the features",
      note: "State embeddings come from the VLA's visual encoder; action embeddings from the layer before its action decoder (or the last velocity field for flow models). Both are compressed to 7-D, three information statistics are estimated over the last 30 steps, and each statistic drives its own GRU.",
      towers: [
        { mod: "vae", title: "Embedding VAEs", sub: "per host model · 7-D latents", compact: true,
          input: { label: "Sₜ, Aₜ embeddings", caption: "from any VLA" },
          rows: [
            { t: "mlp", label: "Action VAE encoder", call: ["→ 500 → 500 → 7, LeakyReLU", "p4"],
              zoom: { k: "rows", title: "State VAE (per modality)", rows: ["Linear → min(512, in/4), LN", "Linear → 16", "concat modalities → 16 · n_mod", "Linear → 64, LN, LeakyReLU", "mean / log-var heads → 7"] } },
            { t: "linear", label: "Posterior means (7-D)", call: ["Matched 7-D for S and A", "p4"] } ],
          output: { label: "sₜ, aₜ ∈ ℝ⁷" } },
        { mod: "est", title: "Information estimators", sub: "no weights · sliding window", compact: true,
          input: { label: "Last W pairs", caption: "W = 30 executed steps" },
          rows: [
            { t: "pool", label: "K–L entropy → H(Aₜ)", call: ["k-NN, k = 5", "p4"] },
            { t: "pool", label: "KSG → two MI terms", call: ["I(Aₜ; Aₜ₊₁), I(Sₜ, Sₜ₊₁; Aₜ)", "p2", "p4"] },
            { t: "norm", label: "z-normalise (train stats)" } ],
          output: { label: "3 scalars per step" } },
        { mod: "gru", title: "Tri-Info detector", sub: "one GRU per signal · late fusion",
          input: { label: "zₜ⁽ᵐ⁾ for each signal", caption: "input dimension 1" },
          rows: [
            { t: "block", n: "3", label: "one per signal", rows: [
              { t: "mlp", label: "GRU, 1 layer", call: ["Hidden 256 (32 for OOD)", "p5"],
                zoom: { k: "rows", title: "Per-signal head", rows: ["GRU(zₜ, hₜ₋₁) → hₜ", "Linear 256 → 128, ReLU", "Linear 128 → 1", "sigmoid → P⁽ᵐ⁾(failure)", "BCE per step, rollout label"] } },
              { t: "linear", label: "MLP head → sigmoid", call: ["Halves hidden size, then 1", "p5"] } ] },
            { t: "pool", label: "Mean of 3 probabilities", call: ["Late fusion, re-normalised", "p3"],
              zoom: { k: "rows", title: "Failure-mode reading", rows: ["freeze: H(A) ↓ and I(A; A′) ↓", "drift: H(A) ↑ and I(A; A′) ↓", "phantom grasp: I(S, S′; A) ↓", "each signal: a different fix", "CP band θ(t) from successes"] } } ],
          output: { label: "P(failure), alarm if > θ(t)" } }
      ],
      links: [
        { from: "vae", to: "est", toRow: "input", label: "7-D latents" },
        { from: "est", to: "gru", toRow: "input", label: "3 statistics" }
      ]
    },
    modules: [
      { id: "vae", role: "codec", roleLabel: "Embedding VAEs", name: "State + action VAE", sub: "→ 7-D each", col: 0, frozen: false, short: "VAE" },
      { id: "est", role: "net", roleLabel: "Estimators (no weights)", name: "k-NN entropy / MI", sub: "W = 30 · k = 5", col: 1, frozen: true, note: "Non-parametric estimators with no trained weights.", short: "Estimators" },
      { id: "gru", role: "critic", roleLabel: "Failure detector", name: "3 GRUs + mean fusion", sub: "hidden 256 · sigmoid", col: 2, frozen: false, main: true, short: "Tri-Info",
        stack: { rows: [
          { t: "in", label: "z-normalised statistic zₜ⁽ᵐ⁾", dims: "one scalar per signal", c: "data-8" },
          { t: "block", label: "Per-signal detector", n: "3", rows: [
            { t: "mlp", label: "GRU, 1 layer, hidden 256" },
            { t: "linear", label: "Linear 256 → 128 · ReLU" },
            { t: "linear", label: "Linear 128 → 1 · sigmoid" } ] },
          { t: "pool", label: "mean over the 3 signals" },
          { t: "out", label: "P(failure); alarm above θ(t)", c: "data-8" } ],
          facts: [["Window / neighbours", ["W = 30, k = 5", "p4"]], ["Optimiser", ["Adam, lr 10⁻³, weight decay 10⁻⁴", "p5"]], ["Sim-to-real (π0.5)", ["balanced accuracy 0.83; baselines ≈ 0.50", "p7"]], ["Latency", ["3.72 ms at W = 30 (H800, π0.5)", "p6"]]] } }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "state emb.", n: "visual enc.", k: 3 },
      { to: "vae", mod: "action", label: "action emb.", n: "pre-decoder", k: 3 }
    ],
    outputs: [
      { from: "est", mod: "other", label: "H, I, I", n: "3 scalars", k: 3 },
      { from: "gru", mod: "other", label: "P(failure)", n: "per step", k: 1 }
    ],
    links: [
      { from: "vae", to: "est", kind: "latent", label: "7-D latents" },
      { from: "est", to: "gru", kind: "feeds", label: "3 statistics" }
    ],
    callouts: [
      "All eight candidate metrics reach near-ceiling in-domain once a GRU models them (0.97–0.98 pooled AUC, Table 1); the three-signal set is chosen because it also transfers (OOD 0.87 vs 0.74 for all eight, Table 2).",
      "No code is released; architecture numbers come from App. B (Table 5) and App. C.1."
    ]
  });
})();
