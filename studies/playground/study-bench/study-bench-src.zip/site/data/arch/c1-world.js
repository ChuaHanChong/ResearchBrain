/* Architecture specs, topic C1 (world models). Numbers from the papers and the official code; see sources.
   Models: World Models, PlaNet, Dreamer, DreamerV3, TD-MPC2, V-JEPA 2, DINO-WM, UniSim, Cosmos WFM, Genie Envisioner, IRASim. */
(function () {
  var RB = window.RB;
  function gh(repo, commit, path) { return { kind: "code", repo: repo, path: path, commit: commit, url: "https://github.com/" + repo + "/blob/" + commit + "/" + path }; }
  function ax(id) { return "https://arxiv.org/abs/" + id; }

  /* ------------------------------------------------------------------ World Models */
  var WM = "hardmaru/WorldModelsExperiments", WMC = "fd982b9";
  RB.arch.spec({
    id: "world-models", method: "world-models", name: "World Models", year: 2018,
    figRef: "Ha & Schmidhuber Figs. 8, 22–23 · App. A", prov: "CarRacing-v0 configuration",
    lede: "Three separately trained parts: a conv VAE (V) squeezes each frame into z, an LSTM with a Gaussian-mixture head (M) predicts the next z, and a single linear layer (C) maps [z ‖ h] to the action.",
    sources: {
      p1: { kind: "paper", ref: "Ha & Schmidhuber 2018, §2 (V, M, C) and Fig. 8", url: ax("1803.10122") },
      p2: { kind: "paper", ref: "Ha & Schmidhuber 2018, §3.1–3.2 and §4.2 (procedures, parameter counts)", url: ax("1803.10122") },
      p3: { kind: "paper", ref: "Ha & Schmidhuber 2018, App. A.1–A.4 (VAE, MDN-RNN, controller, CMA-ES)", url: ax("1803.10122") },
      c1: gh(WM, WMC, "carracing/vae/vae.py"),
      c2: gh(WM, WMC, "carracing/rnn/rnn.py"),
      c3: gh(WM, WMC, "carracing/model.py")
    },
    summary: {
      pattern: ["VAE + MDN-RNN world model (V-M-C)", "p1"],
      params: ["VAE 4,348,547 · MDN-RNN 422,368 · controller 867 (CarRacing)", "p2"],
      vision: ["Conv VAE: 64 × 64 × 3 → z ∈ ℝ³² (CarRacing) or ℝ⁶⁴ (Doom)", "p3", "c1"],
      backbone: ["MDN-RNN: LSTM with 256 units (Doom: 512), 5 diagonal Gaussians", "p3", "c2"],
      head: ["Linear controller aₜ = W[zₜ ‖ hₜ] + b, squashed by tanh", "p1", "p3", "c3"],
      output: ["3 continuous actions: steer, gas, brake", "p2", "c3"],
      attention: "None (recurrent)",
      cond: ["Action aₜ is concatenated with zₜ as the LSTM input (32 + 3 = 35)", "c2"],
      steps: ["One LSTM step per frame; zₜ₊₁ sampled with temperature τ", "p1", "p3"],
      chunk: null, rate: null, latency: null,
      train: ["10,000 random-policy rollouts; V, M, C trained apart; C by CMA-ES (population 64)", "p2", "p3"]
    },
    blueprint: {
      headline: "World Models: V sees, M predicts, C acts",
      note: "V encodes every frame on its own. M takes [zₜ ‖ aₜ] and carries hₜ forward; its mixture head is only needed to dream. C is one linear layer on [zₜ ‖ hₜ], so almost all parameters sit in V and M, and C can be evolved with CMA-ES.",
      towers: [
        { mod: "vae", title: "V: ConvVAE", sub: "encoder half used at run time", compact: true,
          input: { label: "Frame 64 × 64 × 3", caption: "RGB in [0, 1]" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "conv", label: "Conv 4×4, stride 2 · ReLU", call: ["Channels 32 → 64 → 128 → 256", "p3", "c1"] }] },
            { t: "linear", label: "Flatten 2 × 2 × 256", call: ["1,024 features", "c1"] },
            { t: "linear", label: "Dense → μ, log σ²", call: ["z = μ + σ ⊙ ε, 32-d", "p3", "c1"],
              zoom: { k: "rows", title: "VAE decoder (training only)", rows: ["z → Dense 1,024", "Deconv 5×5 /2 → 128", "Deconv 5×5 /2 → 64", "Deconv 6×6 /2 → 32", "Deconv 6×6 /2 → 3 · sigmoid"] } } ],
          output: { label: "zₜ ∈ ℝ³²" } },
        { mod: "rnn", title: "M: MDN-RNN", sub: "LSTM + mixture density head",
          input: { label: "[zₜ ‖ aₜ], hₜ₋₁", caption: "35 inputs per step (CarRacing)" },
          rows: [
            { t: "embed", label: "Concat [zₜ ‖ aₜ]", call: ["32 + 3 = 35 inputs", "c2"] },
            { t: "mlp", label: "LSTM cell: hₜ₋₁ → hₜ", call: ["256 hidden units (Doom: 512)", "p3", "c2"],
              zoom: { k: "rows", title: "LSTM step", rows: ["[zₜ, aₜ, hₜ₋₁]", "gates i, f, o and candidate g", "cₜ = f ⊙ cₜ₋₁ + i ⊙ g", "hₜ = o ⊙ tanh(cₜ)"] } },
            { t: "linear", label: "MDN output layer", call: ["256 → 480 = 32 dims × 5 × 3", "c2"] },
            { t: "pool", label: "Sample zₜ₊₁ at temperature τ", call: ["5 diagonal Gaussians per dimension", "p3", "c2"],
              zoom: { k: "rows", title: "Mixture density head", rows: ["mixture logits π (5 per dim)", "means μ", "log σ (diagonal)", "pick a component, then sample", "Doom: extra done logit, cut at 0.5"] } } ],
          output: { label: "p(zₜ₊₁ | aₜ, zₜ, hₜ); hₜ to C" } },
        { mod: "ctrl", title: "C: controller", sub: "one linear layer, evolved", compact: true,
          input: { label: "[zₜ ‖ hₜ]", caption: "32 + 256 = 288 features" },
          rows: [
            { t: "linear", label: "Linear W꜀, b꜀", call: ["288 × 3 + 3 = 867 parameters", "p2", "c3"],
              zoom: { k: "rows", title: "CMA-ES on C", rows: ["population of 64 candidate W꜀", "16 rollouts each", "fitness = mean return", "update mean and covariance"] } },
            { t: "pool", label: "tanh / clip to ranges" } ],
          output: { label: "steer, gas, brake" } }
      ],
      links: [
        { from: "rnn", to: "ctrl", toRow: "input", label: "hₜ" },
        { from: "vae", to: "rnn", toRow: "input", label: "zₜ" }
      ]
    },
    modules: [
      { id: "vae", role: "codec", roleLabel: "V: vision model", name: "ConvVAE", sub: "64² × 3 → z (32-d)", col: 0, frozen: false, short: "VAE",
        stack: { rows: [
          { t: "in", label: "frame 64 × 64 × 3", dims: "each frame encoded alone", c: "data-1" },
          { t: "block", label: "Encoder conv", n: "4", rows: [{ t: "conv", label: "Conv 4×4 stride 2 · ReLU", dims: "32 → 64 → 128 → 256 ch" }] },
          { t: "linear", label: "Flatten", dims: "2 × 2 × 256 = 1,024" },
          { t: "linear", label: "Dense → μ, log σ² (32 each)" },
          { t: "out", label: "z = μ + σ ⊙ ε", dims: "decoder (4 deconvs) only for training", c: "data-7" } ],
          facts: [["Latent size", ["32 (CarRacing), 64 (Doom)", "p3", "c1"]], ["Parameters", ["4,348,547 (CarRacing)", "p2"]], ["Loss", ["L2 reconstruction + KL (KL floored at 0.5 × 32)", "p3", "c1"]], ["Training", ["1 epoch on random-policy frames", "p3"]]] } },
      { id: "rnn", role: "world", roleLabel: "M: memory model", name: "MDN-RNN", sub: "LSTM 256 · 5 Gaussians", col: 1, frozen: false, main: true, short: "MDN-RNN",
        stack: { rows: [
          { t: "in", label: "[zₜ ‖ aₜ]", dims: "35 per step", c: "data-7" },
          { t: "mlp", label: "LSTM, 256 units", dims: "hₜ, cₜ carried over time" },
          { t: "linear", label: "MDN head 256 → 480", dims: "π, μ, log σ for 32 dims × 5" },
          { t: "out", label: "p(zₜ₊₁)", dims: "sampled at temperature τ", c: "data-7" } ],
          facts: [["Hidden units", ["256 (CarRacing), 512 (Doom)", "p3", "c2"]], ["Mixtures", ["5, diagonal (no correlation ρ)", "p3", "c2"]], ["Parameters", ["422,368 (CarRacing)", "p2"]], ["Training", ["20 epochs, teacher forcing on sampled z", "p3"]]] } },
      { id: "ctrl", role: "action-head", roleLabel: "C: controller", name: "Linear controller", sub: "[z ‖ h] → 3 actions", col: 2, frozen: false, params: "867", short: "Controller",
        stack: { rows: [
          { t: "in", label: "[zₜ ‖ hₜ]", dims: "288", c: "data-7" },
          { t: "linear", label: "aₜ = W꜀ [zₜ ‖ hₜ] + b꜀", dims: "288 → 3" },
          { t: "out", label: "tanh-bounded actions", dims: "steer ∈ [−1, 1], gas, brake ∈ [0, 1]", c: "data-3" } ],
          facts: [["Parameters", ["867 (CarRacing), 1,088 (Doom)", "p2"]], ["Optimiser", ["CMA-ES, population 64, 16 rollouts each", "p3"]]] } }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "frame 64 × 64", n: "one per step", k: 3 },
      { to: "rnn", mod: "action", label: "action aₜ", n: "3-D", k: 1 }
    ],
    outputs: [
      { from: "rnn", mod: "latent", label: "p(zₜ₊₁) mixture", n: "32 dims × 5", k: 3 },
      { from: "ctrl", mod: "action", label: "action aₜ", n: "3 continuous", k: 1 }
    ],
    links: [
      { from: "vae", to: "rnn", kind: "latent", label: "zₜ ∈ ℝ³²" },
      { from: "rnn", to: "ctrl", kind: "feeds", label: "hₜ (+ zₜ)" }
    ],
    callouts: [
      "Doom Take Cover: z ∈ ℝ⁶⁴, a 512-unit LSTM that also predicts a <b>done</b> flag, and C reads both cₜ and hₜ. C is trained <b>entirely inside M's dream</b> and transferred to the real game.",
      "The three parts are trained one after another; the paper notes joint training is possible but found separate training more practical (§3.1)."
    ]
  });

  /* ------------------------------------------------------------------ PlaNet */
  var PN = "google-research/planet", PNC = "c04226b";
  RB.arch.spec({
    id: "planet", method: "planet", name: "PlaNet", year: 2019, parent: "world-models",
    diffRows: ["params", "backbone", "head", "output", "steps", "chunk", "train"],
    figRef: "Hafner et al. Fig. 2c · §2–3 · App. A–B", prov: "",
    lede: "A recurrent state-space model: a 200-unit GRU carries a deterministic state, a 30-D Gaussian adds the stochastic part. No policy network: the cross-entropy method searches action sequences, scored by a reward model in latent space.",
    sources: {
      p1: { kind: "paper", ref: "Hafner et al. 2019, §3 (RSSM, Eq. 4) and Fig. 2c", url: ax("1811.04551") },
      p2: { kind: "paper", ref: "Hafner et al. 2019, §2 and App. B (CEM planner, Alg. 2)", url: ax("1811.04551") },
      p3: { kind: "paper", ref: "Hafner et al. 2019, App. A (hyperparameters)", url: ax("1811.04551") },
      c1: gh(PN, PNC, "planet/scripts/configs.py"),
      c2: gh(PN, PNC, "planet/models/rssm.py"),
      c3: gh(PN, PNC, "planet/networks/conv_ha.py")
    },
    summary: {
      pattern: ["RSSM world model", "p1"],
      params: null,
      vision: ["Conv encoder of World Models: 64 × 64 × 3 → 4 stride-2 convs → 1,024", "p3", "c3"],
      backbone: ["RSSM: GRU with 200 units (hₜ) + 30-D diagonal Gaussian (sₜ)", "p3", "c1", "c2"],
      head: ["No policy: a reward model r(hₜ, sₜ) scores candidate plans", "p2"],
      output: ["First action of the CEM plan; replanned every step", "p2"],
      attention: "None (recurrent)",
      cond: ["[sₜ₋₁ ‖ aₜ₋₁] → dense layer → GRU", "p1", "c2"],
      steps: ["CEM: horizon 12, 10 iterations, 1,000 candidates, refit to top 100", "p3", "c1"],
      chunk: ["Action repeat 2–8 by domain", "p3"],
      rate: null, latency: null,
      train: ["Online: 5 seed episodes, then 1 episode per 100 updates; batches 50 × 50", "p3"]
    },
    changes: [
      "V and M are trained <b>jointly</b> as one sequential VAE instead of in two stages.",
      "The LSTM + mixture becomes an <b>RSSM</b>: a deterministic GRU path plus a stochastic 30-D Gaussian state.",
      "A <b>reward model</b> is learned; the evolved linear controller is replaced by <b>CEM planning</b> in latent space.",
      "Images are never generated while planning; the decoder only provides a training signal.",
      "Data are collected online by the planner rather than by a random policy."
    ],
    blueprint: {
      headline: "PlaNet: plan in a learned latent space",
      note: "The encoder's embedding eₜ only enters the posterior. For planning, the GRU and the prior roll forward from the current belief with candidate actions, and the reward MLP sums predicted rewards; CEM refits its Gaussian to the best plans. The image decoder is trained but never used to plan.",
      towers: [
        { mod: "enc", title: "Conv encoder", sub: "from World Models", compact: true,
          input: { label: "Image 64 × 64 × 3", caption: "reduced to 5-bit colour" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "conv", label: "Conv 4×4, stride 2 · ReLU", call: ["Channels 32 → 64 → 128 → 256", "c3"] }] },
            { t: "linear", label: "Flatten → embedding eₜ", call: ["2 × 2 × 256 = 1,024", "c3"],
              zoom: { k: "rows", title: "Mirror: observation decoder", rows: ["[hₜ ‖ sₜ] → Dense 1,024", "Deconv 5×5 /2 → 128", "Deconv 5×5 /2 → 64", "Deconv 6×6 /2 → 32", "Deconv 6×6 /2 → 3 (mean image)"] } } ],
          output: { label: "eₜ" } },
        { mod: "rssm", title: "RSSM", sub: "deterministic + stochastic state",
          input: { label: "sₜ₋₁, aₜ₋₁, hₜ₋₁", caption: "one step of the latent dynamics" },
          rows: [
            { t: "linear", label: "Dense [sₜ₋₁ ‖ aₜ₋₁] · ReLU", call: ["200 units", "p3", "c1"] },
            { t: "mlp", label: "GRU: hₜ₋₁ → hₜ (deterministic)", call: ["200 units", "p3", "c2"],
              zoom: { k: "rows", title: "RSSM step", rows: ["hₜ = GRU(hₜ₋₁, [sₜ₋₁, aₜ₋₁])", "prior sₜ ~ N(μ(hₜ), σ(hₜ))", "posterior sₜ ~ N(μ(hₜ, eₜ), σ(hₜ, eₜ))", "loss: KL(post ‖ prior), 3 free nats"] } },
            { t: "linear", label: "Prior p(sₜ | hₜ)", call: ["Dense → mean, softplus std (30-D)", "p3", "c2"] },
            { id: "post", t: "linear", label: "Posterior q(sₜ | hₜ, eₜ)", call: ["Used only when a frame is seen", "p1"] } ],
          output: { label: "model state [hₜ ‖ sₜ]" } },
        { mod: "rew", title: "Reward model", sub: "scores imagined plans", compact: true,
          input: { label: "[hₜ ‖ sₜ]", caption: "latent state only, no pixels" },
          rows: [
            { t: "mlp", label: "Reward MLP · ReLU", call: ["2 × 200 (paper), 3 × 300 (code)", "p3", "c1"],
              zoom: { k: "rows", title: "CEM planner", rows: ["1,000 plans, horizon 12", "roll the RSSM prior forward", "score: sum of mean rewards", "refit Normal to the top 100", "10 iterations; execute μₜ"] } },
            { t: "linear", label: "Mean reward r̂ₜ" } ],
          output: { label: "Σ r̂ over the plan → CEM" } }
      ],
      links: [
        { from: "rssm", to: "rew", toRow: "input", label: "[hₜ ‖ sₜ]" },
        { from: "enc", to: "rssm", toRow: "post", label: "eₜ" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "Conv encoder", sub: "4 conv · 1,024-d", col: 0, frozen: false, short: "Encoder" },
      { id: "rssm", role: "world", roleLabel: "Latent dynamics", name: "RSSM", sub: "GRU 200 · 30-D Gaussian", col: 1, frozen: false, main: true, short: "RSSM",
        stack: { rows: [
          { t: "in", label: "sₜ₋₁, aₜ₋₁ (and eₜ when observed)", c: "data-7" },
          { t: "linear", label: "Dense 200 · ReLU on [sₜ₋₁ ‖ aₜ₋₁]" },
          { t: "mlp", label: "GRU 200 → hₜ", dims: "deterministic path" },
          { t: "linear", label: "Prior: Dense 200 → μ, σ (30)", dims: "used when imagining" },
          { t: "linear", label: "Posterior: Dense 200 on [hₜ ‖ eₜ] → μ, σ (30)", dims: "used when filtering" },
          { t: "out", label: "state [hₜ ‖ sₜ]", dims: "230-d", c: "data-7" } ],
          facts: [["Deterministic", ["GRU, 200 units", "p3", "c2"]], ["Stochastic", ["30-D diagonal Gaussian, min std 0.1", "p3", "c1"]], ["KL", ["unscaled, 3 free nats", "p3", "c1"]], ["Optimiser", ["Adam 10⁻³, ε 10⁻⁴, clip norm 1,000", "p3"]]] } },
      { id: "rew", role: "critic", roleLabel: "Reward model", name: "Reward MLP", sub: "[h ‖ s] → r̂", col: 2, frozen: false, short: "Reward" },
      { id: "cem", role: "planner", roleLabel: "Planner (no weights)", name: "CEM in latent space", sub: "H 12 · 1,000 · top 100", col: 3, frozen: false, short: "CEM" }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "image 64 × 64", n: "per step", k: 3 },
      { to: "rssm", mod: "action", label: "action aₜ₋₁", n: "repeated R times", k: 1 }
    ],
    outputs: [
      { from: "rew", mod: "other", label: "reward r̂ₜ", n: "scalar", k: 1 },
      { from: "cem", mod: "action", label: "first action μₜ", n: "then replan", k: 1 }
    ],
    links: [
      { from: "enc", to: "rssm", kind: "latent", label: "eₜ → posterior" },
      { from: "rssm", to: "rew", kind: "feeds", label: "[hₜ ‖ sₜ]" },
      { from: "rew", to: "cem", kind: "feeds", label: "Σ rewards" }
    ],
    callouts: [
      "<b>Paper vs code:</b> App. A implements all non-recurrent functions as 2 dense layers of 200 units; the released config's head networks default to 3 layers of 300.",
      "Latent overshooting (§4) is proposed, but the final RSSM agent does not need it (App. D)."
    ]
  });

  /* ------------------------------------------------------------------ Dreamer */
  var DR = "danijar/dreamer", DRC = "56d4d44";
  RB.arch.spec({
    id: "dreamer", method: "dreamer", name: "Dreamer", year: 2020, parent: "planet",
    diffRows: ["head", "output", "steps", "chunk", "train"],
    figRef: "Hafner et al. Fig. 3 · §2–4 · App. A", prov: "",
    lede: "PlaNet's RSSM world model, but behaviour is learned rather than searched: an actor and a value network are trained on 15-step imagined rollouts, with the actor's gradients flowing back through the learned dynamics.",
    sources: {
      p1: { kind: "paper", ref: "Hafner et al. 2020, §2–3 (Eqs. 1–8)", url: ax("1912.01603") },
      p2: { kind: "paper", ref: "Hafner et al. 2020, App. A (hyperparameters)", url: ax("1912.01603") },
      p3: { kind: "paper", ref: "Hafner et al. 2020, §4 and §6 (world model, experiments)", url: ax("1912.01603") },
      c1: gh(DR, DRC, "dreamer.py"),
      c2: gh(DR, DRC, "models.py")
    },
    summary: {
      pattern: ["RSSM world model", "p1"],
      params: null,
      vision: ["Conv encoder of World Models: 64 × 64 × 3, depth 32 → 256 channels", "p2", "c2"],
      backbone: ["PlaNet RSSM: GRU 200, 30-D Gaussian stochastic state", "p2", "c1", "c2"],
      head: ["Actor (tanh-Gaussian) and value v(sₜ): dense ELU networks", "p1", "p2"],
      output: ["Action from the actor; mean 5 · tanh(μ/5), then tanh", "p2", "c2"],
      attention: "None (recurrent)",
      cond: ["[sₜ₋₁ ‖ aₜ₋₁] → dense layer → GRU", "p2", "c2"],
      steps: ["Imagination horizon 15; λ-returns with γ 0.99, λ 0.95", "p2", "c1"],
      chunk: ["Action repeat 2 for all tasks", "p2", "c1"],
      rate: null, latency: null,
      train: ["Online, 5 seed episodes; batches 50 × 50; 5 × 10⁶ env steps on 20 DMC tasks", "p2", "p3"]
    },
    changes: [
      "The CEM planner is replaced by a learned <b>action model</b> trained purely on imagined rollouts.",
      "A <b>value model</b> v(sₜ) bootstraps rewards beyond the 15-step horizon through λ-returns.",
      "The actor maximises value by <b>backpropagating analytic gradients</b> through the learned RSSM.",
      "Dense heads become 3 × 300 ELU layers (paper) instead of 2 × 200 ReLU.",
      "One action repeat for every task; the world model itself is unchanged."
    ],
    blueprint: {
      headline: "Dreamer: learn behaviour in imagination",
      note: "Posterior states from replayed sequences seed imagined rollouts: the RSSM prior steps forward 15 times with actions from the actor. The reward head and the value network give λ-returns; the value regresses them and the actor climbs their gradient through the frozen dynamics.",
      towers: [
        { mod: "enc", title: "Conv encoder", sub: "depth 32", compact: true,
          input: { label: "Image 64 × 64 × 3", caption: "action repeat 2" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "conv", label: "Conv 4×4, stride 2 · ReLU", call: ["Channels 32 → 64 → 128 → 256", "c2"] }] },
            { t: "linear", label: "Flatten → eₜ" } ],
          output: { label: "eₜ" } },
        { mod: "rssm", title: "RSSM", sub: "PlaNet's world model, trained on replay",
          input: { label: "sₜ₋₁, aₜ₋₁, hₜ₋₁", caption: "imagination starts from posterior states" },
          rows: [
            { t: "linear", label: "Dense [sₜ₋₁ ‖ aₜ₋₁] · ELU", call: ["200 units", "c2"] },
            { t: "mlp", label: "GRU: hₜ₋₁ → hₜ (deterministic)", call: ["200 units", "p2", "c1"] },
            { t: "linear", label: "Prior p(sₜ | hₜ)", call: ["30-D Gaussian, softplus std + 0.1", "p2", "c2"] },
            { id: "post", t: "linear", label: "Posterior q(sₜ | hₜ, eₜ)", call: ["KL unscaled, 3 free nats", "p2", "c1"] } ],
          output: { label: "imagined states sτ, τ = 1…15" } },
        { mod: "actor", title: "Action model", sub: "tanh-Gaussian policy", compact: true,
          input: { label: "[hτ ‖ sτ]", caption: "imagined model state" },
          rows: [
            { t: "block", n: "4", rows: [{ t: "mlp", label: "Dense · ELU" }] },
            { t: "linear", label: "Mean, std → tanh-Normal", call: ["Mean 5 · tanh(μ / 5); code: 400 units", "p2", "c1", "c2"],
              zoom: { k: "rows", title: "Actor update", rows: ["imagine 15 steps with aτ ~ π(sτ)", "rewards r̂τ, values v(sτ)", "λ-return Vλ (γ 0.99, λ 0.95)", "backprop Σ Vλ through the RSSM"] } } ],
          output: { label: "aτ (reparameterised)" } },
        { mod: "value", title: "Value model", sub: "regresses λ-returns", compact: true,
          input: { label: "[hτ ‖ sτ]", caption: "same imagined states" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "mlp", label: "Dense · ELU" }] },
            { t: "linear", label: "Value v(sτ)", call: ["Adam 8 × 10⁻⁵; stop-gradient on targets", "p1", "p2"] } ],
          output: { label: "v(sτ) for λ-returns" } }
      ],
      links: [
        { from: "rssm", to: "actor", toRow: "input", label: "sτ" },
        { from: "enc", to: "rssm", toRow: "post", label: "eₜ" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "Conv encoder", sub: "depth 32 · 4 convs", col: 0, frozen: false, short: "Encoder" },
      { id: "rssm", role: "world", roleLabel: "Latent dynamics", name: "RSSM", sub: "GRU 200 · 30-D Gaussian", col: 1, frozen: false, main: true, short: "RSSM",
        stack: { rows: [
          { t: "in", label: "sₜ₋₁, aₜ₋₁ (and eₜ when observed)", c: "data-7" },
          { t: "linear", label: "Dense 200 · ELU" },
          { t: "mlp", label: "GRU 200 → hₜ" },
          { t: "linear", label: "Prior / posterior heads → μ, σ (30)" },
          { t: "out", label: "state [hₜ ‖ sₜ]", dims: "decoder and reward head train it", c: "data-7" } ],
          facts: [["Deterministic / stochastic", ["200 / 30", "p2", "c1"]], ["Heads (paper)", ["3 dense layers of 300, ELU", "p2"]], ["Model lr", ["6 × 10⁻⁴", "p2", "c1"]], ["Free nats", ["3", "p2", "c1"]]] } },
      { id: "actor", role: "action-head", roleLabel: "Actor", name: "Action model", sub: "tanh-Gaussian", col: 2, frozen: false, short: "Actor",
        stack: { rows: [
          { t: "in", label: "[hτ ‖ sτ]", c: "data-7" },
          { t: "block", label: "Dense layers", n: "4", rows: [{ t: "mlp", label: "Dense · ELU" }] },
          { t: "linear", label: "→ mean, std (softplus)" },
          { t: "out", label: "tanh(μ + σ ε)", dims: "reparameterised sample", c: "data-3" } ],
          facts: [["Layers × units", ["paper: 3 × 300; code: 4 × 400", "p2", "c1"]], ["Mean scale", ["5", "p2", "c2"]], ["Learning rate", ["8 × 10⁻⁵", "p2", "c1"]]] } },
      { id: "value", role: "critic", roleLabel: "Critic", name: "Value model", sub: "v(sτ) ≈ λ-return", col: 3, frozen: false, short: "Value" }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "image 64 × 64", n: "per step", k: 3 },
      { to: "rssm", mod: "action", label: "action aₜ₋₁", n: "or imagined aτ", k: 1 }
    ],
    outputs: [
      { from: "actor", mod: "action", label: "action aₜ", n: "1–12 dims", k: 2 },
      { from: "value", mod: "other", label: "value v(sτ)", n: "scalar", k: 1 }
    ],
    links: [
      { from: "enc", to: "rssm", kind: "latent", label: "eₜ → posterior" },
      { from: "rssm", to: "actor", kind: "feeds", label: "imagined sτ|15 steps" },
      { from: "value", to: "actor", kind: "feeds", label: "λ-return|gradients" }
    ],
    callouts: [
      "<b>Paper vs code:</b> App. A uses three dense layers of 300 units for all non-conv functions; the released dreamer.py uses 400 units, a 2-layer reward head, 3-layer value and 4-layer actor.",
      "Dreamer's world model is PlaNet's; only behaviour learning changes. The paper also tries a contrastive state model in place of the decoder (§4)."
    ]
  });

  /* ------------------------------------------------------------------ DreamerV3 */
  var D3 = "danijar/dreamerv3", D3C = "e3f0224";
  RB.arch.spec({
    id: "dreamerv3", method: "dreamerv3", name: "DreamerV3", year: 2023, parent: "dreamer",
    diffRows: ["params", "vision", "backbone", "head", "output", "cond", "train"],
    figRef: "Hafner et al. Fig. 3 · Supp. Tables 3–4", prov: "200M default configuration",
    lede: "The third Dreamer: an RSSM whose state is a block-diagonal GRU plus 32 categorical latents, with RMSNorm, SiLU, symlog inputs and twohot reward and critic heads, so one set of hyperparameters works from Atari to Minecraft.",
    sources: {
      p1: { kind: "paper", ref: "Hafner et al. 2023, World model learning (Eqs. 1–3)", url: ax("2301.04104") },
      p2: { kind: "paper", ref: "Hafner et al. 2023, Critic and actor learning, Robust predictions (Eqs. 4–11)", url: ax("2301.04104") },
      p3: { kind: "paper", ref: "Hafner et al. 2023, Supplementary: Networks and Table 3 (model sizes)", url: ax("2301.04104") },
      p4: { kind: "paper", ref: "Hafner et al. 2023, Table 4 (hyperparameters)", url: ax("2301.04104") },
      c1: gh(D3, D3C, "dreamerv3/configs.yaml"),
      c2: gh(D3, D3C, "dreamerv3/rssm.py")
    },
    summary: {
      pattern: ["RSSM world model", "p1"],
      params: ["12M to 400M set by model dimension d; config default 200M", "p3", "c1"],
      vision: ["CNN to 4 × 4 or 6 × 6 (paper: stride 2; code: conv 5×5 + 2×2 max-pool)", "p3", "c2"],
      backbone: ["Block-diagonal GRU, 8 blocks: 8,192 units at 200M; 32 latents × 64 classes", "p3", "c1", "c2"],
      head: ["Actor, critic: 3-layer MLPs (1,024 at 200M); reward, continue: 1 layer", "p3", "c1"],
      output: ["Sampled action, discrete or continuous; critic: 255-bin symexp twohot", "p2", "c1"],
      attention: "None (recurrent)",
      cond: ["hₜ₋₁, zₜ₋₁ and aₜ₋₁ embedded apart, then mixed into all 8 GRU blocks", "p3", "c2"],
      steps: ["Imagination horizon 15; discount horizon 333 (γ ≈ 0.997)", "p2", "p4", "c1"],
      chunk: null, rate: null, latency: null,
      train: ["Online RL, one configuration for 150+ tasks; batch 16 × 64; replay 5 × 10⁶", "p4"]
    },
    changes: [
      "Gaussian latents become <b>32 categorical latents</b> sampled with straight-through gradients and a 1 % uniform mix.",
      "The GRU becomes a <b>block-diagonal GRU</b> with 8 blocks, scaled to thousands of units.",
      "RMSNorm + SiLU everywhere; <b>symlog</b> inputs and <b>symexp twohot</b> reward and critic heads.",
      "A <b>continue predictor</b>, KL balancing and 1-nat free bits replace the single KL term.",
      "The actor uses Reinforce with percentile return normalisation, for discrete and continuous actions alike."
    ],
    blueprint: {
      headline: "DreamerV3: one config, every domain",
      note: "Each step, hₜ₋₁, zₜ₋₁ and aₜ₋₁ are embedded separately and copied into each of the 8 GRU blocks; block-diagonal weights keep the parameter count linear in the number of units. The actor and the critic read [hₜ ‖ zₜ] from imagined rollouts; only the actor is linked here.",
      towers: [
        { mod: "enc", title: "Encoder", sub: "CNN for images, MLP for vectors", compact: true,
          input: { label: "Image 64 × 64", caption: "vectors: symlog, 3-layer MLP" },
          rows: [
            { t: "block", n: "4", rows: [
              { t: "conv", label: "Conv 5×5 · RMSNorm · SiLU", call: ["Channels 128, 192, 256, 256 (200M)", "c1", "c2"] },
              { t: "pool", label: "Max-pool 2 × 2" } ] },
            { t: "linear", label: "Flatten → tokens", call: ["4 × 4 × 256 = 4,096", "c1", "c2"] } ],
          output: { label: "xₜ tokens" } },
        { mod: "rssm", title: "RSSM", sub: "block GRU + categorical latents",
          input: { label: "hₜ₋₁, zₜ₋₁, aₜ₋₁", caption: "zₜ₋₁: 32 × 64 one-hots" },
          rows: [
            { t: "linear", label: "3 embeddings · RMSNorm · SiLU", call: ["Each → 1,024 (200M)", "c1", "c2"] },
            { t: "group", label: "Block-diagonal GRU, 8 blocks", rows: [
              { t: "linear", label: "Block linear · RMSNorm · SiLU" },
              { t: "mlp", label: "Block GRU: hₜ₋₁ → hₜ", call: ["8,192 units = 8 × 1,024", "p3", "c1"],
                zoom: { k: "rows", title: "Block GRU step", rows: ["3 × Linear → 1,024 each", "copy into each of 8 blocks with hₜ₋₁", "BlockLinear → reset r, cand. c, update u", "c̃ = tanh(r ⊙ c)", "hₜ = u ⊙ c̃ + (1 − u) ⊙ hₜ₋₁"] } } ] },
            { t: "mlp", label: "Prior p(ẑₜ | hₜ)", call: ["32 latents × 64 classes, 1 % unimix", "p1", "c1"] },
            { id: "post", t: "linear", label: "Posterior q(zₜ | hₜ, xₜ)", call: ["Straight-through sample; free bits 1", "p1", "c1"] } ],
          output: { label: "model state sₜ = [hₜ ‖ zₜ]" } },
        { mod: "actor", title: "Actor", sub: "no lookahead at run time", compact: true,
          input: { label: "sₜ = [hₜ ‖ zₜ]", caption: "imagined, 15 steps" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "mlp", label: "Linear · RMSNorm · SiLU" }] },
            { t: "linear", label: "Action distribution", call: ["Categorical (1 % unimix) or bounded Normal", "p2", "c1"] } ],
          output: { label: "aₜ" } },
        { mod: "critic", title: "Critic", sub: "distributional", compact: true,
          input: { label: "sₜ = [hₜ ‖ zₜ]", caption: "same states" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "mlp", label: "Linear · RMSNorm · SiLU" }] },
            { t: "linear", label: "255 logits → twohot", call: ["255 bins, output init zero", "p2", "c1"],
              zoom: { k: "rows", title: "Symexp twohot head", rows: ["MLP → 255 logits", "bins b = symexp(−20 … +20)", "ŷ = Σ softmax(logits) · b", "loss: CE with twohot(target)"] } } ],
          output: { label: "return distribution" } }
      ],
      links: [
        { from: "rssm", to: "actor", toRow: "input", label: "sₜ" },
        { from: "enc", to: "rssm", toRow: "post", label: "xₜ tokens" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "CNN / MLP encoder", sub: "RMSNorm · SiLU", col: 0, frozen: false, short: "Encoder" },
      { id: "rssm", role: "world", roleLabel: "Latent dynamics", name: "RSSM", sub: "block GRU · 32 × 64 cat.", col: 1, frozen: false, main: true, short: "RSSM",
        stack: { rows: [
          { t: "in", label: "hₜ₋₁ · zₜ₋₁ · aₜ₋₁", dims: "action scaled to |a| ≤ 1", c: "data-7" },
          { t: "linear", label: "3 × Linear 1,024 · RMSNorm · SiLU" },
          { t: "linear", label: "BlockLinear (8 groups) · RMSNorm · SiLU" },
          { t: "mlp", label: "BlockLinear → 3 × 8,192 gates → GRU update", dims: "hₜ, 8,192 units" },
          { t: "mlp", label: "Prior: 2 × Linear 1,024 → 32 × 64 logits" },
          { t: "linear", label: "Posterior: Linear 1,024 on [hₜ ‖ xₜ] → 32 × 64" },
          { t: "out", label: "sₜ = [hₜ ‖ zₜ]", dims: "decoder, reward, continue heads", c: "data-7" } ],
          facts: [["Model dim d (200M)", ["1,024", "p3", "c1"]], ["Recurrent units", ["8d = 8,192, 8 blocks", "p3", "c1"]], ["Latents", ["32 × 64 classes (d / 16)", "p3", "c1"]], ["Loss scales", ["pred 1, dyn 1, rep 0.1; free nats 1", "p1", "p4"]], ["Optimiser", ["LaProp, lr 4 × 10⁻⁵, AGC 0.3", "p4"]]] } },
      { id: "actor", role: "action-head", roleLabel: "Actor", name: "Actor MLP", sub: "3 × 1,024 · Reinforce", col: 2, frozen: false, short: "Actor" },
      { id: "critic", role: "critic", roleLabel: "Critic", name: "Critic MLP", sub: "255-bin twohot", col: 3, frozen: false, short: "Critic" }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "images or vectors", n: "64 × 64 images", k: 3 },
      { to: "rssm", mod: "action", label: "action aₜ₋₁", n: "discrete or continuous", k: 1 }
    ],
    outputs: [
      { from: "actor", mod: "action", label: "action aₜ", n: "sampled", k: 2 },
      { from: "critic", mod: "other", label: "value distribution", n: "255 bins", k: 3 }
    ],
    links: [
      { from: "enc", to: "rssm", kind: "latent", label: "tokens → posterior" },
      { from: "rssm", to: "actor", kind: "feeds", label: "imagined sₜ|15 steps" },
      { from: "critic", to: "actor", kind: "feeds", label: "λ-returns|(normalised)" }
    ],
    callouts: [
      "<b>Paper vs code:</b> the paper encodes images with stride-2 convolutions; the released config (strided: False) uses stride-1 5×5 convolutions, each followed by 2×2 max-pooling.",
      "<b>Paper vs paper:</b> Table 3 lists 1,024 recurrent units for the 12M model although it defines them as 8d = 2,048; the code's size12m uses 2,048.",
      "<b>Paper vs paper:</b> the critic text mentions a prediction horizon T = 16; Table 4 and configs.yaml use an imagination horizon of 15."
    ]
  });

  /* ------------------------------------------------------------------ TD-MPC2 */
  var TD = "nicklashansen/tdmpc2", TDC = "e9f5932";
  RB.arch.spec({
    id: "td-mpc2", method: "td-mpc2", name: "TD-MPC2", year: 2023,
    figRef: "Hansen et al. Fig. 3 · §3 · App. H", prov: "5M single-task configuration",
    lede: "Five MLPs and no decoder: an encoder into a SimNorm latent, latent dynamics, reward, an ensemble of five Q-functions and a policy prior. MPPI plans three steps ahead and bootstraps the rest with Q.",
    sources: {
      p1: { kind: "paper", ref: "Hansen et al. 2024, §3.1 (components, Eqs. 2–5)", url: ax("2310.16828") },
      p2: { kind: "paper", ref: "Hansen et al. 2024, §3.2 (MPPI with a policy prior)", url: ax("2310.16828") },
      p3: { kind: "paper", ref: "Hansen et al. 2024, App. H (architecture, Tables 8–9)", url: ax("2310.16828") },
      p4: { kind: "paper", ref: "Hansen et al. 2024, §4 (multitask scaling, Table 1)", url: ax("2310.16828") },
      c1: gh(TD, TDC, "tdmpc2/config.yaml"),
      c2: gh(TD, TDC, "tdmpc2/common/layers.py"),
      c3: gh(TD, TDC, "tdmpc2/common/world_model.py")
    },
    summary: {
      pattern: ["Latent world model (JEPA / TD-MPC)", "p1"],
      params: ["5M single-task default (5,389,930 listed); multitask 1M–317M", "p3"],
      vision: ["State vector by default; images: 4-layer conv encoder at 64 × 64", "p3", "c2"],
      backbone: ["Latent dynamics d(z, a, e): 3 × 512 MLP, LayerNorm + Mish, SimNorm output", "p3", "c1"],
      head: ["Reward R and 5 Q-functions (101-bin discrete regression); policy prior p", "p1", "p3"],
      output: ["First action of the MPPI plan, one step at a time", "p2"],
      attention: "None (MLPs only)",
      cond: ["Learnable task embedding e (96-D, norm ≤ 1) into every component", "p3", "c1"],
      steps: ["MPPI: horizon 3, 6 iterations, 512 samples, 64 elites, 24 policy samples", "p3", "c1"],
      chunk: null, rate: null, latency: null,
      train: ["Online RL on 104 tasks; multitask: 545M transitions from 240 agents", "p4"]
    },
    blueprint: {
      headline: "TD-MPC2: plan with an implicit model",
      note: "The encoder maps a state into a 512-d latent made of 64 softmax simplices. Dynamics, reward and Q all take [z ‖ a ‖ e]; the policy prior takes [z ‖ e]. Nothing is decoded: the latent is trained to predict its own next encoding, rewards and TD targets.",
      towers: [
        { mod: "enc", title: "Encoder h", sub: "state → SimNorm latent", compact: true,
          input: { label: "State s ‖ task e", caption: "state + 96-D task embedding" },
          rows: [
            { t: "mlp", label: "NormedLinear · Mish", call: ["→ 256 (encoder dim)", "p3", "c1"] },
            { t: "linear", label: "NormedLinear → 512", call: ["Latent 512 = 64 simplices × 8", "p3", "c1"] },
            { t: "norm", label: "SimNorm",
              zoom: { k: "rows", title: "SimNorm", rows: ["z ∈ ℝ⁵¹²", "split into 64 groups of 8", "softmax inside each group (τ = 1)", "concatenate back to 512"] } } ],
          output: { label: "z₀" } },
        { mod: "dyn", title: "Latent dynamics d", sub: "implicit model, no decoder",
          input: { label: "[zₜ ‖ aₜ ‖ e]", caption: "512 + A (+ 96 task)" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "mlp", label: "Linear · LayerNorm · Mish", call: ["512 units (MLP dim)", "p3", "c1"],
              zoom: { k: "rows", title: "NormedLinear", rows: ["Linear", "Dropout (first Q layer only, 1 %)", "LayerNorm", "Mish (or SimNorm at the end)"] } }] },
            { t: "linear", label: "NormedLinear → 512 (zₜ₊₁)" },
            { t: "norm", label: "SimNorm", call: ["Groups of 8", "p3", "c1"] } ],
          output: { label: "zₜ₊₁ (never decoded)" } },
        { mod: "q", title: "Q ensemble", sub: "reward head has the same shape", compact: true,
          input: { label: "[z ‖ a ‖ e]", caption: "5 Q-functions" },
          rows: [
            { t: "mlp", label: "NormedLinear · Dropout", call: ["Dropout 1 %", "p3", "c1"] },
            { t: "mlp", label: "NormedLinear · Mish" },
            { t: "linear", label: "Linear → 101 bins", call: ["Target: min of 2 random Qs", "p1", "p3"],
              zoom: { k: "rows", title: "MPPI planning", rows: ["512 Gaussian plans, H = 3", "+ 24 sequences from the prior p", "score Σ γʰ R + γᴴ Q at step H", "refit to 64 elites (temperature 0.5)", "6 iterations; execute first action"] } } ],
          output: { label: "Q̂ (log-space bins)" } },
        { mod: "pi", title: "Policy prior p", sub: "max-entropy actor", compact: true,
          input: { label: "[z ‖ e]", caption: "guides MPPI" },
          rows: [
            { t: "block", n: "2", rows: [{ t: "mlp", label: "NormedLinear · Mish" }] },
            { t: "linear", label: "Linear → 2A (μ, log σ)", call: ["log σ ∈ [−10, 2]", "p3"] } ],
          output: { label: "24 prior trajectories" } }
      ],
      links: [
        { from: "dyn", to: "q", toRow: "input", label: "zₜ₊₁" },
        { from: "enc", to: "dyn", toRow: "input", label: "z₀" }
      ]
    },
    modules: [
      { id: "enc", role: "state-enc", roleLabel: "Encoder h", name: "Encoder MLP", sub: "→ 512 · SimNorm", col: 0, frozen: false, short: "Encoder" },
      { id: "dyn", role: "world", roleLabel: "Latent dynamics d", name: "Dynamics MLP", sub: "3 × 512 · LN · Mish", col: 1, frozen: false, main: true, short: "Dynamics",
        stack: { rows: [
          { t: "in", label: "[zₜ ‖ aₜ ‖ e]", dims: "512 + A + 96", c: "data-7" },
          { t: "block", label: "Hidden layers", n: "2", rows: [{ t: "mlp", label: "Linear 512 · LayerNorm · Mish" }] },
          { t: "linear", label: "Linear 512 · LayerNorm" },
          { t: "norm", label: "SimNorm, V = 8" },
          { t: "out", label: "zₜ₊₁", dims: "loss ‖zₜ₊₁ − sg(h(sₜ₊₁))‖²", c: "data-7" } ],
          facts: [["Parameters (5M model)", ["843,264 (dynamics)", "p3"]], ["MLP / latent dim", ["512 / 512", "p3", "c1"]], ["Loss weights", ["joint-embedding 20, reward 0.1, value 0.1", "p3"]], ["Temporal coefficient λ", ["0.5", "p3"]]] } },
      { id: "q", role: "critic", roleLabel: "Reward + Q", name: "R and Q ensemble", sub: "101 bins · 5 Qs", col: 2, frozen: false, short: "Q",
        stack: { rows: [
          { t: "in", label: "[z ‖ a ‖ e]", c: "data-7" },
          { t: "mlp", label: "Linear 512 · Dropout 1 % · LN · Mish" },
          { t: "mlp", label: "Linear 512 · LN · Mish" },
          { t: "linear", label: "Linear → 101 bins" },
          { t: "out", label: "Q̂ via soft CE in log space", dims: "EMA targets, momentum 0.99", c: "data-8" } ],
          facts: [["Q parameters (5M)", ["3,156,985", "p3"]], ["Reward parameters", ["631,397", "p3"]], ["Ensemble", ["5 (317M model: 8)", "p3"]]] } },
      { id: "pi", role: "action-head", roleLabel: "Policy prior p", name: "Policy MLP", sub: "tanh-Gaussian, max-ent", col: 3, frozen: false, short: "Prior" }
    ],
    inputs: [
      { to: "enc", mod: "state", label: "state s", n: "S-dim (or 64² image)", k: 3 },
      { to: "dyn", mod: "action", label: "action aₜ", n: "up to 39-D, masked", k: 2 },
      { to: "enc", mod: "other", label: "task embedding e", n: "96-D", k: 1 }
    ],
    outputs: [
      { from: "q", mod: "other", label: "Q̂ and R̂", n: "101 bins each", k: 2 },
      { from: "pi", mod: "action", label: "prior actions", n: "→ MPPI", k: 2 }
    ],
    links: [
      { from: "enc", to: "dyn", kind: "latent", label: "z (512, SimNorm)" },
      { from: "dyn", to: "q", kind: "feeds", label: "zₜ₊₁, aₜ" },
      { from: "pi", to: "q", kind: "feeds", label: "a = p(z)|max Q − βH" }
    ],
    callouts: [
      "Scaling (Table 9) widens the encoder, MLPs and latent (128 → 1,376) and deepens the encoder (2 → 5 layers); the 317M model trains 80 tasks in 33 GPU-days.",
      "The released code matches the paper's Table 8 and App. H listing; no disagreement found."
    ]
  });

  /* ------------------------------------------------------------------ DINO-WM */
  var DW = "gaoyuezhou/dino_wm", DWC = "0a9492f";
  RB.arch.spec({
    id: "dino-wm", method: "dino-wm", name: "DINO-WM", year: 2024,
    figRef: "Zhou et al. Fig. 2 · §3 · App. A.4–A.9", prov: "Push-T configuration (history 3, frameskip 5)",
    lede: "A frozen DINOv2 ViT-S/14 turns each frame into 196 patch vectors. A small ViT, causal over frames, predicts the next frame's patches from past patches with a 10-D action vector glued onto every patch. CEM plans toward a goal image's patches.",
    sources: {
      p1: { kind: "paper", ref: "Zhou et al. 2025, §3.1 (observation, transition, decoder)", url: ax("2411.04983") },
      p2: { kind: "paper", ref: "Zhou et al. 2025, §3.2 and App. A.5 (MPC with CEM)", url: ax("2411.04983") },
      p3: { kind: "paper", ref: "Zhou et al. 2025, App. A.9 (Tables 11–12)", url: ax("2411.04983") },
      p4: { kind: "paper", ref: "Zhou et al. 2025, App. A.8 (Table 10, inference time)", url: ax("2411.04983") },
      p5: { kind: "paper", ref: "Zhou et al. 2025, App. A.4.2–A.4.3 (mask and decoder ablations)", url: ax("2411.04983") },
      c1: gh(DW, DWC, "conf/train.yaml"),
      c2: gh(DW, DWC, "conf/predictor/vit.yaml"),
      c3: gh(DW, DWC, "models/vit.py"),
      c4: gh(DW, DWC, "conf/planner/cem.yaml"),
      c5: gh(DW, DWC, "train.py"),
      c6: gh(DW, DWC, "models/proprio.py")
    },
    summary: {
      pattern: ["Latent world model (JEPA / TD-MPC)", "p1"],
      params: ["≈19M predictor; the DINOv2 encoder stays frozen", "p3"],
      vision: ["DINOv2 ViT-S/14 patch tokens: 196 × 196 image → 14 × 14 × 384", "p3", "c1"],
      backbone: ["ViT predictor: 6 layers, 16 heads, MLP 2,048, width 404", "p3", "c2", "c5"],
      head: ["None: the predictor emits next-frame patches; a deconv decoder is optional", "p1"],
      output: ["Next-frame DINOv2 patch features; CEM action sequence", "p1", "p2"],
      attention: ["Frame-causal: every patch of frame t sees all patches of frames ≤ t", "p1", "c3"],
      cond: ["Action and proprio → 10-D each, concatenated to every patch", "p1", "p3", "c1"],
      steps: ["CEM (released config): 300 samples, top 30, 30 iterations, horizon 5", "c4"],
      chunk: ["Frameskip 5: 5 raw actions per model step; history 1 or 3", "p3", "c1"],
      rate: null,
      latency: ["CEM 100 × 10: 53 s on an A6000; one batch-32 step 0.014 s", "p4"],
      train: ["Offline trajectories per environment, 1,000 to 20,000; 100 epochs, batch 32", "p3"]
    },
    blueprint: {
      headline: "DINO-WM: predict the next DINO patches",
      note: "Actions and proprioception are not tokens: their 10-D embeddings are copied onto every patch vector (384 + 10 + 10 = 404). A frame-level causal mask lets all patches of one frame predict the next frame together. The planner never decodes pixels.",
      towers: [
        { mod: "dino", title: "DINOv2 ViT-S/14", sub: "frozen observation model", compact: true,
          input: { label: "Image 196 × 196", caption: "224 × 224 frames, resized" },
          rows: [
            { t: "conv", label: "Patch embed 14 × 14", call: ["→ 196 tokens × 384", "p3"] },
            { t: "group", label: "DINOv2 blocks (frozen)", rows: [{ t: "attn", label: "Self-attention" }, { t: "ffn", label: "MLP" }] },
            { t: "norm", label: "Normalised patch tokens" } ],
          output: { label: "zₜ: 196 × 384" } },
        { mod: "pred", title: "ViT predictor", sub: "≈19M, frame-causal",
          input: { label: "Patches of frames t−2 … t", caption: "3 × 196 tokens (Push-T)" },
          rows: [
            { id: "cat", t: "embed", label: "Concat action ‖ proprio", call: ["384 + 10 + 10 = 404 per patch", "c1", "c5"] },
            { t: "embed", label: "+ learned position embedding" },
            { t: "block", n: "6", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Frame-causal attention", call: ["16 heads × 64 = 1,024 inner", "c2", "c3"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 2,048", "p3", "c2"], zoom: { k: "mlp", act: "GELU", d: "404", ff: "2,048", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm",
              zoom: { k: "rows", title: "CEM toward a goal image", rows: ["encode o₀ and goal oᵍ (DINOv2)", "300 action sequences, H = 5", "roll the predictor forward", "cost ‖ẑ(H) − zᵍ‖²; keep top 30", "30 iterations; run the first actions"] } } ],
          output: { label: "ẑₜ₊₁ patches" } },
        { mod: "act", title: "Action encoder", sub: "and proprio encoder", compact: true,
          input: { label: "aₜ (5 raw steps)", caption: "action dim × frameskip 5" },
          rows: [
            { t: "linear", label: "Conv1d, kernel 1", call: ["→ 10-D (proprio also 10-D)", "p3", "c1", "c6"] } ],
          output: { label: "tiled onto 196 patches" } }
      ],
      links: [
        { from: "dino", to: "pred", toRow: "input", label: "196 × 384 per frame" },
        { from: "act", to: "pred", toRow: "cat", label: "10-D" }
      ]
    },
    modules: [
      { id: "dino", role: "vision-enc", name: "DINOv2 ViT-S/14", sub: "14 × 14 × 384 patches", col: 0, frozen: true, short: "DINOv2" },
      { id: "pred", role: "world", roleLabel: "Transition model", name: "ViT predictor", sub: "6 × 404 · 16 heads", col: 1, frozen: false, main: true, params: "≈19M", short: "Predictor",
        stack: { rows: [
          { t: "in", label: "[patches ‖ action ‖ proprio] × H frames", dims: "196 × 404 per frame", c: "data-7" },
          { t: "embed", label: "+ learned position embedding", dims: "H × 196 positions" },
          { t: "block", label: "Pre-norm ViT block", n: "6", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 16 × 64 · frame-causal mask" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 404 → 2,048 → 404 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "LayerNorm" },
          { t: "out", label: "ẑₜ₊₁ patches", dims: "MSE to DINOv2(oₜ₊₁), teacher forcing", c: "data-7" } ],
          facts: [["Depth / heads / MLP", ["6 / 16 / 2,048", "p3", "c2"]], ["Token width", ["404 = 384 + 10 + 10", "c1", "c5"]], ["Dropout", ["0.1", "c2"]], ["Predictor lr", ["paper 5 × 10⁻⁵; config 5 × 10⁻⁴", "p3", "c1"]], ["History H", ["3 (Push-T, Reacher, PointMaze) or 1", "p3"]]] } },
      { id: "act", role: "state-enc", roleLabel: "Action / proprio encoder", name: "Action encoder", sub: "Conv1d → 10-D", col: 2, frozen: false, short: "Action enc." }
    ],
    inputs: [
      { to: "dino", mod: "vision", label: "RGB frames + goal", n: "224 → 196 px", k: 4 },
      { to: "act", mod: "action", label: "actions (frameskip 5)", n: "per model step", k: 2 },
      { to: "act", mod: "state", label: "proprioception", n: "optional", k: 1 }
    ],
    outputs: [
      { from: "pred", mod: "latent", label: "next-frame patches", n: "196 × 384", k: 4 }
    ],
    links: [
      { from: "dino", to: "pred", kind: "latent", label: "patch features|frozen" },
      { from: "act", to: "pred", kind: "prefix", label: "concat to|every patch" }
    ],
    mask: { name: "Frame-causal", ref: "p1", axes: [{ label: "frame t−2 patches", short: "t−2", mod: "vision" }, { label: "frame t−1 patches", short: "t−1", mod: "vision" }, { label: "frame t patches", short: "t", mod: "vision" }], m: ["100", "110", "111"],
      note: "Within a frame all 196 patches see each other. Without the mask, success on Push-T falls from 0.92 to 0.08 at history 3 (App. A.4.2)." },
    callouts: [
      "<b>Paper vs code:</b> App. A.9 lists a predictor learning rate of 5e-5; conf/train.yaml uses 5e-4.",
      "<b>Paper vs code (planning):</b> Table 10 times CEM with 100 samples × 10 steps; the released cem.yaml uses 300 samples, top 30, 30 steps, horizon 5.",
      "The transposed-conv decoder is trained separately, only to visualise predictions; letting its loss reach the predictor lowered Push-T success from 0.92 to 0.80 (App. A.4.3)."
    ]
  });

  /* ------------------------------------------------------------------ V-JEPA 2 */
  var VJ = "facebookresearch/vjepa2", VJC = "204698b";
  RB.arch.spec({
    id: "v-jepa-2", method: "v-jepa-2", name: "V-JEPA 2-AC", year: 2025, parent: "dino-wm",
    diffRows: ["params", "vision", "backbone", "attention", "cond", "steps", "train"],
    figRef: "Assran et al. Figs. 2, 6 · §3 · App. A–B", prov: "V-JEPA 2-AC on a frozen ViT-g encoder",
    lede: "A frozen ViT-g video encoder, pretrained by masked feature prediction on 1M+ hours of video, maps each frame to 16 × 16 features. A 300M block-causal transformer predicts the next frame's features from interleaved action, end-effector and patch tokens.",
    sources: {
      p1: { kind: "paper", ref: "Assran et al. 2025, §2.1 (encoder, 3D-RoPE, tubelets)", url: ax("2506.09985") },
      p2: { kind: "paper", ref: "Assran et al. 2025, §3.1 (V-JEPA 2-AC inputs, loss, architecture)", url: ax("2506.09985") },
      p3: { kind: "paper", ref: "Assran et al. 2025, §3.2, §4 and Table 3 (planning)", url: ax("2506.09985") },
      p4: { kind: "paper", ref: "Assran et al. 2025, App. A.3, Table 12 (model sizes)", url: ax("2506.09985") },
      p5: { kind: "paper", ref: "Assran et al. 2025, App. B.1–B.2 (post-training, CEM settings)", url: ax("2506.09985") },
      c1: gh(VJ, VJC, "src/models/ac_predictor.py"),
      c2: gh(VJ, VJC, "configs/train/vitg16/droid-256px-8f.yaml"),
      c3: gh(VJ, VJC, "src/models/vision_transformer.py"),
      c4: gh(VJ, VJC, "app/vjepa_droid/train.py"),
      c5: gh(VJ, VJC, "src/models/utils/modules.py")
    },
    summary: {
      pattern: ["Latent world model (JEPA / TD-MPC)", "p2"],
      params: ["Encoder ViT-g ≈1B (frozen) + action-conditioned predictor ≈300M", "p2", "p4"],
      vision: ["V-JEPA 2 ViT-g/16 at 256 × 256 → 16 × 16 × 1,408 per frame", "p2", "c3"],
      backbone: ["Predictor: 24 layers, width 1,024, 16 heads, GELU, 3D-RoPE", "p2", "c1", "c2"],
      head: ["Linear 1,024 → 1,408 back to encoder features (patch tokens only)", "p2", "c1"],
      output: ["Next-frame feature map ẑₖ₊₁; actions by CEM on an L1 energy", "p2", "p3"],
      attention: ["Block-causal over time: [aₖ, sₖ, 256 patches] form one block per step", "p2", "c5"],
      cond: ["7-D action and 7-D end-effector state as own tokens (Linear 7 → 1,024)", "p2", "c1"],
      steps: ["CEM: 800 samples, 10 iterations, top 10, horizon 1", "p5"],
      chunk: ["One action executed, then replan; each action in an L1 ball of 0.075", "p3"],
      rate: ["Frames at 4 fps", "p2"],
      latency: ["16 s per action on one RTX 4090 (Cosmos baseline: 4 min)", "p3"],
      train: ["Encoder: 1M+ h internet video. Predictor: < 62 h unlabelled DROID video", "p1", "p2"]
    },
    changes: [
      "The frozen encoder is a <b>video</b> JEPA (ViT-g, ≈1B) pretrained on 1M+ hours, not DINOv2 ViT-S on images.",
      "Action and end-effector state become <b>separate tokens</b> per step instead of being glued onto every patch.",
      "The predictor grows from 6 × 404 to <b>24 × 1,024</b> and uses 3D-RoPE instead of learned positions.",
      "Trained with teacher forcing <b>plus a 2-step rollout loss</b> (L1) on 62 h of real robot video.",
      "Planning uses an L1 energy and runs zero-shot on real Franka arms."
    ],
    blueprint: {
      headline: "V-JEPA 2-AC: predict features, then plan",
      note: "Each frame is encoded on its own by the frozen ViT-g. The predictor sees, for every time step, one action token, one state token and 256 patch tokens; the block-causal mask lets a step see itself and the past. Only patch outputs are read out and compared by L1.",
      towers: [
        { mod: "enc", title: "V-JEPA 2 ViT-g/16", sub: "frozen, pretrained on 1M+ h of video", compact: true,
          input: { label: "Frame 256 × 256", caption: "copied to fill a 2-frame tubelet" },
          rows: [
            { t: "conv", label: "Tubelet embed 2 × 16 × 16", call: ["→ 256 tokens × 1,408", "p1", "p4"] },
            { t: "block", n: "40", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", side: "RoPE", call: ["22 heads, head dim 64", "p4", "c3"], zoom: { k: "heads", q: 22, kv: 22, hd: 64, title: "Encoder heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 6,144", "p4", "c3"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" } ],
          output: { label: "zₖ: 16 × 16 × 1,408" } },
        { mod: "pred", title: "Action-conditioned predictor", sub: "≈300M, trained on DROID",
          input: { label: "[aₖ, sₖ, zₖ] for k ≤ t", caption: "2 + 256 tokens per time step" },
          rows: [
            { id: "emb", t: "linear", label: "3 separate affine maps", call: ["a, s: 7 → 1,024; z: 1,408 → 1,024", "p2", "c1"] },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Block-causal attention", side: "RoPE", call: ["16 heads, head dim 64", "p2", "c1"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Predictor heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 4,096", "c1"], zoom: { k: "mlp", act: "GELU", d: "1,024", ff: "4,096", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "linear", label: "Linear 1,024 → 1,408", call: ["Action and state outputs dropped", "c1"],
              zoom: { k: "rows", title: "CEM with an L1 energy", rows: ["encode frame zₖ and goal zᵍ", "800 actions in an L1 ball of 0.075", "energy ‖P(a; sₖ, zₖ) − zᵍ‖₁", "refit Gaussian to the top 10", "10 iterations; execute the mean"] } } ],
          output: { label: "ẑₖ₊₁ → L1 to target / goal" } }
      ],
      links: [{ from: "enc", to: "pred", toRow: "emb", label: "frozen features zₖ" }]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "V-JEPA 2 ViT-g/16", sub: "40 × 1408 · 22 heads", col: 0, frozen: true, params: "≈1B", short: "ViT-g",
        stack: { rows: [
          { t: "in", label: "frame 256 × 256 (duplicated)", dims: "tubelet 2 × 16 × 16", c: "data-1" },
          { t: "conv", label: "Tubelet embedding", dims: "→ 256 × 1,408" },
          { t: "block", label: "ViT block (pre-norm)", n: "40", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 22 heads · 3D-RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 1,408 → 6,144 → 1,408" }, { t: "add", span: 2 } ] },
          { t: "out", label: "16 × 16 × 1,408 feature map", dims: "layer-normed as the target", c: "data-1" } ],
          facts: [["Width / depth / heads", ["1,408 / 40 / 22", "p4", "c3"]], ["MLP", ["6,144", "p4", "c3"]], ["Pretraining", ["mask-denoising in feature space, 1M+ hours", "p1"]]] } },
      { id: "pred", role: "world", roleLabel: "Action-conditioned predictor", name: "V-JEPA 2-AC", sub: "24 × 1024 · 16 heads", col: 1, frozen: false, main: true, params: "≈300M", short: "Predictor",
        stack: { rows: [
          { t: "in", label: "per step: action, state, 256 patches", dims: "interleaved over 15 steps", c: "data-7" },
          { t: "linear", label: "Linear 7 → 1,024 (a), 7 → 1,024 (s), 1,408 → 1,024 (z)" },
          { t: "block", label: "Transformer block", n: "24", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 16 heads · block-causal · 3D-RoPE (time only for a, s)" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 1,024 → 4,096 → 1,024 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "LayerNorm" },
          { t: "linear", label: "Linear 1,024 → 1,408 on patch tokens" },
          { t: "out", label: "ẑₖ₊₁", dims: "L1 teacher-forcing + 2-step rollout loss", c: "data-7" } ],
          facts: [["Depth / width / heads", ["24 / 1,024 / 16", "p2", "c2"]], ["MLP ratio", ["4, GELU", "p2", "c1"]], ["Loss", ["teacher forcing (T = 15) + rollout (T = 2), L1", "p2", "c2"]], ["Schedule", ["warmup 4,500 → constant 85,500 → decay 4,500 iterations", "p5", "c2"]], ["Batch", ["256 clips", "p5", "c2"]]] } },
      { id: "cem", role: "planner", roleLabel: "Planner (no weights)", name: "CEM, L1 energy", sub: "800 · 10 iters · top 10", col: 2, frozen: false, short: "CEM" }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "frames + goal image", n: "256 × 256, 4 fps", k: 4 },
      { to: "pred", mod: "action", label: "action aₖ", n: "7-D Δ end-effector", k: 1 },
      { to: "pred", mod: "state", label: "end-effector sₖ", n: "7-D", k: 1 }
    ],
    outputs: [
      { from: "pred", mod: "latent", label: "next features ẑₖ₊₁", n: "16 × 16 × 1,408", k: 4 },
      { from: "cem", mod: "action", label: "planned action", n: "first of horizon 1", k: 1 }
    ],
    links: [
      { from: "enc", to: "pred", kind: "latent", label: "256 patch features|per frame" },
      { from: "pred", to: "cem", kind: "feeds", label: "L1 energy|to goal features" }
    ],
    mask: { name: "Block-causal (per time step)", ref: "p2", axes: [{ label: "step 1 [a, s, 256 z]", short: "k=1", mod: "vision" }, { label: "step 2 [a, s, 256 z]", short: "k=2", mod: "vision" }, { label: "step 3 [a, s, 256 z]", short: "k=3", mod: "vision" }], m: ["100", "110", "111"],
      note: "Inside one step, action, state and patch tokens all see each other; a step never sees a later one." },
    callouts: [
      "<b>Paper vs code:</b> §3.1 samples 16-frame, 4-second clips at 4 fps; the released DROID config uses 8 frames per clip (dataset_fpcs: 8) at 4 fps, 8 clips per GPU on 32 GPUs.",
      "The pretraining predictor (ViT-s, 12 layers, width 384) is thrown away; the action-conditioned predictor is new and learns with the encoder frozen.",
      "Pick-and-place needs image sub-goals: the planner switches goals after 4 and 10 steps (§4.2)."
    ]
  });

  /* ------------------------------------------------------------------ UniSim */
  RB.arch.spec({
    id: "unisim", method: "unisim", name: "UniSim", year: 2023, parent: "unipi",
    diffRows: ["params", "vision", "backbone", "head", "output", "cond", "train"],
    figRef: "Yang et al. Fig. 2 · §2 · App. C, Table 6", prov: "Paper only (no official code or weights)",
    lede: "A 5.6B pixel-space video diffusion cascade used as an interactive simulator: a 3-D U-Net predicts the next 16 frames from 4 history frames and an action (T5 text plus discretised controls), and two U-Nets super-resolve them.",
    sources: {
      p1: { kind: "paper", ref: "Yang et al. 2024, §2.2 (observation prediction, Eq. 1) and architecture", url: ax("2310.06114") },
      p2: { kind: "paper", ref: "Yang et al. 2024, App. C and Table 6 (architecture, hyperparameters)", url: ax("2310.06114") },
      p3: { kind: "paper", ref: "Yang et al. 2024, §2.1 (datasets, unified action space)", url: ax("2310.06114") },
      p4: { kind: "paper", ref: "Yang et al. 2024, §3.2 and Table 1 (history ablation)", url: ax("2310.06114") }
    },
    summary: {
      pattern: ["Video world foundation model", "p1"],
      params: ["5.6B", "p1"],
      vision: ["Pixel space: base model at 16 × 24 × 40 (T × H × W)", "p2"],
      backbone: ["3-D video U-Net: 1,024 base channels, multipliers 1, 2, 4, 3 blocks per level", "p2"],
      head: ["Two spatial super-resolution U-Nets: 24 × 40 → 48 × 80 → 192 × 320", "p2"],
      output: ["Next 16-frame segment (ε-prediction), rolled out autoregressively", "p1", "p2"],
      attention: ["Interleaved spatial and temporal attention at 6, 12, 24; heads 16, 16, 8", "p1", "p2"],
      cond: ["4 history frames concatenated on channels; action by classifier-free guidance", "p1", "p2"],
      steps: ["256 sampling steps, cosine schedule, log-SNR in [−20, 20]", "p2"],
      chunk: null, rate: null, latency: null,
      train: ["Robot, human-activity, navigation, panorama and internet data; 512 TPU-v3 × 20 days", "p1", "p3"]
    },
    changes: [
      "From text-to-video <b>planner</b> to an <b>action-in, video-out simulator</b> that other policies train inside.",
      "Actions are <b>T5 text plus discretised low-level controls</b>, weighted by classifier-free guidance.",
      "Conditions on <b>4 history frames</b> (channel-concatenated) and is rolled out autoregressively.",
      "Scaled to <b>5.6B</b>: 1,024 base channels and temporal attention in the base model.",
      "Two <b>spatial</b> super-resolution stages; no inverse-dynamics head inside the simulator."
    ],
    blueprint: {
      headline: "UniSim: actions in, video out",
      note: "The base U-Net denoises 16 frames at 24 × 40 with the last 4 frames copied into every frame's channels; the action embedding is dropped at random in training so guidance can amplify it. Two super-resolution U-Nets then upscale in space. The paper does not say where inside the U-Net the action embedding enters.",
      towers: [
        { mod: "base", title: "Base video U-Net", sub: "history-conditioned, 16 × 24 × 40",
          input: { label: "Noisy 16 frames ‖ history", caption: "4 history frames tiled on channels" },
          rows: [
            { id: "cond", t: "mlp", label: "Action embedding MLP", side: "cond", call: ["4 layers, 4,096-d, 64 tokens", "p2"],
              zoom: { k: "rows", title: "Unified action input", rows: ["language action → T5 embeddings", "+ discretised controls (Δx, Δy …)", "+ dataset name (low-data domains)", "conditioning MLP: 4 layers, 4,096-d"] } },
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "3", rows: [{ t: "conv", label: "3-D conv residual block" }] },
              { t: "attn", label: "Spatial + temporal attention", call: ["At resolutions 6, 12, 24", "p2"] },
              { t: "conv", label: "Downsample", call: ["Channels 1,024 × (1, 2, 4)", "p2"] } ] },
            { t: "group", label: "Up path (mirror, skips)", rows: [
              { t: "conv", label: "Residual blocks + skip concat" },
              { t: "attn", label: "Spatial + temporal attention", call: ["Heads 16, 16, 8", "p2"] } ] },
            { t: "conv", label: "Output → ε for 16 frames",
              zoom: { k: "rows", title: "Classifier-free guidance on actions", rows: ["ε(o | h, a) and ε(o | h)", "ε̂ = (1 + η) ε(o | h, a) − η ε(o | h)", "η sets how strongly the action acts", "256 denoising steps"] } } ],
          output: { label: "16 frames at 24 × 40" } },
        { mod: "sr", title: "Spatial SR cascade", sub: "two U-Nets, temporal convolution", compact: true,
          input: { label: "Base video 24 × 40", caption: "same conditioning" },
          rows: [
            { t: "conv", label: "SR U-Net 1", call: ["24 × 40 → 48 × 80", "p2"] },
            { t: "conv", label: "SR U-Net 2", call: ["48 × 80 → 192 × 320", "p2"],
              zoom: { k: "rows", title: "Cascade", rows: ["base: temporal attention", "SR 1: 24 × 40 → 48 × 80", "SR 2: 48 × 80 → 192 × 320", "SR models: temporal convolution"] } } ],
          output: { label: "16 frames at 192 × 320" } }
      ],
      links: [{ from: "base", to: "sr", toRow: "input", label: "low-res video" }]
    },
    modules: [
      { id: "t5", role: "lang", name: "T5 embeddings", sub: "+ discretised controls", col: 0, frozen: true, short: "T5",
        note: "Pretrained T5 language embeddings form the text part of the action." },
      { id: "base", role: "video-gen", roleLabel: "Simulator (base)", name: "Base video U-Net", sub: "1,024 ch · mult 1, 2, 4", col: 1, frozen: false, main: true, params: "5.6B total", short: "Base U-Net",
        stack: { rows: [
          { t: "in", label: "noisy 16 frames ‖ 4 history frames", dims: "16 × 24 × 40, channel concat", c: "data-4" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Residual blocks", n: "3", rows: [{ t: "conv", label: "3-D conv residual block" }] },
            { t: "attn", label: "spatial attn + temporal attn" },
            { t: "conv", label: "Downsample", dims: "1,024 → 2,048 → 4,096 ch" } ] },
          { t: "group", label: "Up path (mirror, skip connections)", rows: [{ t: "conv", label: "residual blocks · attention · upsample" }] },
          { t: "conv", label: "Output conv", dims: "ε for 16 frames" },
          { t: "out", label: "predicted noise ε", dims: "256 sampling steps", c: "data-4" } ],
          facts: [["Base channels / multipliers", ["1,024 / 1, 2, 4", "p2"]], ["Blocks per resolution", ["3", "p2"]], ["Attention", ["resolutions 6, 12, 24; heads 16, 16, 8", "p2"]], ["Conditioning", ["4,096-d, 4-layer MLP, 64 tokens", "p2"]], ["Training", ["10⁶ steps, batch 256, Adam 10⁻⁴, dropout 0.1", "p2"]]] } },
      { id: "sr", role: "video-gen", roleLabel: "Super-resolution", name: "2 × SR U-Nets", sub: "24×40 → 192×320", col: 2, frozen: false, short: "SR" }
    ],
    inputs: [
      { to: "t5", mod: "lang", label: "text action", n: "e.g. \"open drawer\"", k: 3 },
      { to: "base", mod: "vision", label: "4 history frames", n: "recent segment", k: 4 },
      { to: "base", mod: "action", label: "discretised controls", n: "Δx, Δy …", k: 2 }
    ],
    outputs: [{ from: "sr", mod: "future", label: "next video segment", n: "16 × 192 × 320", k: 5 }],
    links: [
      { from: "t5", to: "base", kind: "feeds", label: "action embedding|(CFG)" },
      { from: "base", to: "sr", kind: "two-stage", label: "16 × 24 × 40" }
    ],
    callouts: [
      "<b>No official code or weights:</b> every number here is from the paper (App. C, Table 6).",
      "History ablation (Table 1): 4 recent frames beat a single frame (FVD 211 vs 316) and 4 distant frames (237).",
      "Uses: long-horizon VLM policies via hindsight relabelling and REINFORCE fine-tuning of a PaLI 3B policy entirely inside the simulator (§4, App. D)."
    ]
  });

  /* ------------------------------------------------------------------ Cosmos WFM */
  var CO = "nvidia-cosmos/cosmos-predict1", COC = "724daa1";
  RB.arch.spec({
    id: "cosmos-world-foundation-models", method: "cosmos-world-foundation-models", name: "Cosmos WFM (Predict1-7B)", year: 2025, parent: "unisim",
    diffRows: ["params", "vision", "backbone", "head", "attention", "cond", "steps", "train"],
    figRef: "NVIDIA Fig. 11 · Table 11 · §6.2", prov: "7B Video2World, Bridge ActionCond",
    lede: "A 7B latent diffusion transformer over 8× compressed video tokens: self-attention with 3-D RoPE, cross-attention to T5-XXL, AdaLN-LoRA from the noise level. Post-training adds a small MLP that writes a 7-D robot action into the timestep embedding.",
    sources: {
      p1: { kind: "paper", ref: "NVIDIA 2025, §5.1.1–5.1.2 and Fig. 11 (EDM, DiT design)", url: ax("2501.03575") },
      p2: { kind: "paper", ref: "NVIDIA 2025, Tables 10–11 (model map, configurations)", url: ax("2501.03575") },
      p3: { kind: "paper", ref: "NVIDIA 2025, §1 and §3 (data curation)", url: ax("2501.03575") },
      p4: { kind: "paper", ref: "NVIDIA 2025, §5.2 (autoregressive WFM)", url: ax("2501.03575") },
      p5: { kind: "paper", ref: "NVIDIA 2025, §6.2 and Table 23 (robot post-training)", url: ax("2501.03575") },
      c1: gh(CO, COC, "cosmos_predict1/diffusion/config/base/net.py"),
      c2: gh(CO, COC, "cosmos_predict1/diffusion/networks/general_dit.py"),
      c3: gh(CO, COC, "cosmos_predict1/diffusion/training/networks/general_dit_action.py"),
      c4: gh(CO, COC, "cosmos_predict1/diffusion/training/config/video2world_action/experiment.py"),
      c5: gh(CO, COC, "cosmos_predict1/diffusion/config/base/tokenizer.py"),
      c6: gh(CO, COC, "cosmos_predict1/diffusion/module/blocks.py")
    },
    summary: {
      pattern: ["Video world foundation model", "p1"],
      params: ["Diffusion 7B and 14B; autoregressive 4B, 5B, 12B, 13B", "p2"],
      vision: ["Continuous tokenizer CV8×8×8: 8× time, 8× space, 16 latent channels", "p1", "c5"],
      backbone: ["7B DiT: 28 blocks, width 4,096, 32 heads, FFN 16,384, AdaLN-LoRA 256", "p2", "c1"],
      head: ["Final AdaLN layer + linear unpatchify to 16-channel latents", "c6"],
      output: ["Denoised video latents (EDM x₀); ActionCond: the next frame", "p1", "p5"],
      attention: ["Full 3-D self-attention with QK-RMSNorm; cross-attention to T5-XXL", "p1"],
      cond: ["σ via AdaLN-LoRA; ActionCond adds an action MLP to the timestep embedding", "p1", "p5", "c3"],
      steps: null,
      chunk: ["ActionCond (Bridge): 1 frame + 7-D action → next frame at 256 × 320", "p5", "c4"],
      rate: null, latency: null,
      train: ["≈100M clips from 20M h of video; Bridge post-training (≈20k episodes)", "p3", "p5"]
    },
    changes: [
      "Pixel U-Net cascade → a <b>latent DiT</b> on a learned video tokenizer (8 × 8 × 8, 16 channels).",
      "Transformer blocks with 3-D RoPE, QK-norm and <b>AdaLN-LoRA</b>; T5-XXL enters by cross-attention.",
      "<b>EDM</b> denoising with preconditioning instead of ε-prediction on a cosine schedule.",
      "Pretrained on ≈20M hours of video, then <b>post-trained</b> per setup: actions, cameras, instructions.",
      "Robot actions are a 7-D vector embedded by an MLP, not T5 text plus classifier-free guidance."
    ],
    blueprint: {
      headline: "Cosmos: a 7B DiT over video tokens",
      note: "Frames are tokenised by a frozen causal video tokenizer; conditioning latents stay clean while the rest are noised. Each of the 28 blocks runs self-attention, cross-attention to T5-XXL and an MLP, each gated by AdaLN-LoRA from σ. For ActionCond, the action MLP's output is added to that same embedding.",
      towers: [
        { mod: "tok", title: "Cosmos tokenizer", sub: "CV8×8×8, frozen", compact: true,
          input: { label: "Video frames", caption: "Bridge: 256 × 320" },
          rows: [{ t: "conv", label: "Causal video encoder", call: ["8× time, 8× space, 16 channels", "p1", "c5"] }],
          output: { label: "latent video" } },
        { mod: "dit", title: "Cosmos-Predict1-7B DiT", sub: "EDM denoiser",
          input: { label: "Noisy ‖ clean cond. latents", caption: "Bridge: 16 × 2 × 32 × 40 latents" },
          rows: [
            { t: "mlp", label: "Action MLP (ActionCond)", side: "cond", call: ["7 → 16,384 → 4,096 · GELU", "c3"],
              zoom: { k: "rows", title: "Action conditioning (post-training)", rows: ["7-D action (Δ pose, gripper)", "MLP 7 → 16,384 → 4,096", "added to the timestep embedding", "code: 2nd MLP → AdaLN-LoRA"] } },
            { t: "conv", label: "3-D patchify (1, 2, 2)", call: ["Latent patches → width 4,096", "p1", "c1"] },
            { t: "embed", label: "3-D RoPE (FPS-aware)", call: ["Pretraining adds a learnable APE", "p1", "c4"] },
            { t: "block", n: "28", rows: [
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN",
                zoom: { k: "rows", title: "AdaLN-LoRA", rows: ["emb(σ) (+ action MLP)", "SiLU → Linear 4,096 → 256", "Linear 256 → 3 × 4,096", "shift, scale, gate"] } },
              { t: "attn", label: "Self-attention · QK-norm", side: "RoPE", call: ["32 heads, head dim 128", "p2", "c1"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Self-attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "attn", label: "Cross-attention to T5-XXL", side: "text", call: ["Context width 1,024", "c2"] },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 16,384", "p2", "c1"], zoom: { k: "mlp", act: "GELU", d: "4,096", ff: "16,384", title: "Feed forward (MLP)" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Final AdaLN layer" },
            { t: "linear", label: "Unpatchify → latents" } ],
          output: { label: "denoised latents → tokenizer decoder" } }
      ],
      links: [{ from: "tok", to: "dit", toRow: "input", label: "latent frames" }]
    },
    modules: [
      { id: "tok", role: "codec", name: "Cosmos tokenizer", sub: "CV8×8×8 · 16 channels", col: 0, frozen: true, short: "Tokenizer" },
      { id: "dit", role: "world", roleLabel: "World model (latent DiT)", name: "Cosmos-Predict1-7B", sub: "28 × 4096 · 32 heads", col: 1, frozen: false, main: true, params: "7B", short: "DiT",
        stack: { rows: [
          { t: "in", label: "[clean cond. latents | noisy latents]", dims: "T × 16 × H × W", c: "data-4" },
          { t: "conv", label: "Patchify (1, 2, 2) + padding mask → 4,096" },
          { t: "block", label: "DiT block (FA-CA-MLP)", n: "28", rows: [
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(σ)" }, { t: "attn", label: "Self-attention · 32 heads · QK-RMSNorm · 3-D RoPE" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(σ)" }, { t: "attn", label: "Cross-attention to T5-XXL" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm · AdaLN-LoRA(σ)" }, { t: "ffn", label: "MLP 4,096 → 16,384 → 4,096 · GELU" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "norm", label: "Final layer (AdaLN)" },
          { t: "linear", label: "Unpatchify" },
          { t: "out", label: "x̂₀ latents", dims: "decoded by the tokenizer", c: "data-4" } ],
          facts: [["Width / depth / heads", ["4,096 / 28 / 32", "p2", "c1"]], ["14B model", ["5,120 / 36 / 40", "p2", "c1"]], ["AdaLN-LoRA rank", ["256", "p2", "c1"]], ["Patch", ["(1, 2, 2)", "p1", "c1"]], ["Parameter saving", ["AdaLN-LoRA: 11B → 7B", "p1"]], ["Bridge fine-tune", ["lr 4 × 10⁻⁴, 100k iterations", "c4"]]] } },
      { id: "t5", role: "lang", name: "T5-XXL", sub: "text prompt", col: 2, frozen: true, short: "T5-XXL" }
    ],
    inputs: [
      { to: "tok", mod: "vision", label: "conditioning frames", n: "Bridge: 1 frame", k: 3 },
      { to: "dit", mod: "action", label: "robot action", n: "7-D (ActionCond)", k: 1 },
      { to: "dit", mod: "time", label: "noise level σ", n: "EDM", k: 1 },
      { to: "t5", mod: "lang", label: "text prompt", n: "optional", k: 3 }
    ],
    outputs: [{ from: "dit", mod: "future", label: "future video latents", n: "→ decoder", k: 5 }],
    links: [
      { from: "tok", to: "dit", kind: "latent", label: "16-ch latents|patchify (1, 2, 2)" },
      { from: "t5", to: "dit", kind: "cross-attn", label: "T5-XXL embeddings" }
    ],
    callouts: [
      "<b>Paper vs code:</b> §6.2 adds the action embedding to the DiT's timestep embedding; the released ActionCond network also adds a second action MLP (→ 3 × 4,096) to the AdaLN-LoRA vector.",
      "Autoregressive family (§5.2): Llama-3-style decoders on DV8×16×16 FSQ tokens (vocabulary 64,000) with a 7B diffusion decoder back to continuous tokens.",
      "The released Bridge ActionCond config turns the extra per-block absolute embedding off, so the post-trained model drops the learnable absolute embedding that the pretraining configs use.",
      "On Bridge next-frame prediction the 7B ActionCond model beats a fine-tuned IRASim (FVD 190 vs 593, Table 23)."
    ]
  });

  /* ------------------------------------------------------------------ Genie Envisioner */
  var GE = "AgibotTech/Genie-Envisioner", GEC = "d41358f";
  RB.arch.spec({
    id: "genie-envisioner", method: "genie-envisioner", name: "Genie Envisioner (GE-Base + GE-Act)", year: 2025,
    figRef: "Liao et al. Figs. 3, 6 · §2–3", prov: "LTX-Video 2B variant with the GE-Act branch",
    lede: "GE-Base is a multi-view video DiT (LTX-Video 2B) that generates the next chunk of all three camera views from the first frame, 4 memory frames and an instruction. GE-Act runs a slim 160M action DiT beside it, cross-attending to each video block.",
    sources: {
      p1: { kind: "paper", ref: "Liao et al. 2025, §2.1 and Fig. 3 (GE-Base architecture)", url: ax("2508.05635") },
      p2: { kind: "paper", ref: "Liao et al. 2025, §2.2 (pretraining stages, data)", url: ax("2508.05635") },
      p3: { kind: "paper", ref: "Liao et al. 2025, §3.1–3.3 and Fig. 6 (GE-Act, asynchronous inference)", url: ax("2508.05635") },
      p4: { kind: "paper", ref: "Liao et al. 2025, §5 (GE-Sim)", url: ax("2508.05635") },
      c1: gh(GE, GEC, "configs/ltx_model/policy_model.yaml"),
      c2: gh(GE, GEC, "models/ltx_models/transformer_ltx_multiview.py"),
      c3: gh(GE, GEC, "models/action_patches/patches.py")
    },
    summary: {
      pattern: ["Dual-system WAM: cross-attention", "p3"],
      params: ["GE-Base 2B (LTX-Video) + GE-Act action branch 160M", "p1", "p3"],
      vision: ["3 views (head + 2 wrists) at 192 × 256; LTX-Video VAE, frozen", "p1", "p2", "c1"],
      backbone: ["LTX-Video DiT: 28 blocks, 32 heads × 64 = 2,048; cross-view attention in every 3rd block", "c1", "c2"],
      head: ["Action DiT: 28 blocks, 16 heads × 32 = 512, cross-attends to video block i", "p3", "c1", "c3"],
      output: ["54-step action chunk at 30 Hz, 14-D dual-arm (+ state)", "p3", "c1"],
      attention: ["Video: per-view attention, joint across views in 10 of 28 blocks; actions cross-attend", "p1", "c2"],
      cond: ["T5-XXL instruction by cross-attention; first frame + 4 sparse memory frames", "p1", "c1"],
      steps: ["Video: 1 flow step, cached; actions: 5 flow steps", "p3", "c1"],
      chunk: ["54 actions per 5 Hz video step (1 : 6)", "p3"],
      rate: ["Video 5 Hz, actions 30 Hz", "p3"],
      latency: ["54-step chunk in 200 ms on an onboard RTX 4090", "p3"],
      train: ["AgiBot-World-Beta: ≈1M episodes, 2,967 h; GE-Base 7 + 3 days on 32 A100", "p2"]
    },
    blueprint: {
      headline: "Genie Envisioner: video DiT, action branch",
      note: "GE-Base and GE-Act have the same 28-block depth. At every block the action tokens cross-attend to that block's video tokens (all three views), so control reads the world model's internal state without decoding video. At run time the video pass takes one denoising step and is cached for the five action steps.",
      towers: [
        { mod: "vae", title: "LTX-Video VAE", sub: "frozen, shared by all views", compact: true,
          input: { label: "3 views, 192 × 256", caption: "first frame + 4 memory + 9-frame chunk" },
          rows: [{ t: "conv", label: "Video encoder", call: ["9 frames → 2 latent frames", "p2"] }],
          output: { label: "128-ch latents per view" } },
        { mod: "base", title: "GE-Base (LTX-Video 2B)", sub: "multi-view video DiT",
          input: { label: "Noisy chunk ‖ x₀ ‖ memory", caption: "tokens of 3 views, + view embedding" },
          rows: [
            { t: "linear", label: "Patchify (1 × 1) · Linear", call: ["128 latent channels → 2,048", "c1"] },
            { t: "embed", label: "+ RoPE + view embedding", call: ["Learnable embedding per camera", "p1", "c2"] },
            { t: "block", n: "28", rows: [
              { t: "norm", label: "RMSNorm · shift, scale", side: "AdaLN" },
              { id: "sa", t: "attn", label: "Spatial / cross-view attn", side: "RoPE", call: ["32 heads × 64; joint views in every 3rd block", "c1", "c2"],
                zoom: { k: "rows", title: "Sparse cross-view attention", rows: ["hidden states (B · V, T · H · W, C)", "every 3rd block: merge the views", "attend jointly over all 3 views", "other blocks: each view alone"] } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "attn", label: "Cross-attention to T5-XXL", side: "text", call: ["Caption 4,096 → 2,048", "c1"] },
              { t: "add", span: 1 },
              { t: "norm", label: "RMSNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["2,048 → 8,192 → 2,048", "c2"] },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Final norm · shift, scale" },
            { t: "linear", label: "Linear → 128 channels" } ],
          output: { label: "video tokens of every block → GE-Act" } },
        { mod: "act", title: "GE-Act action DiT", sub: "160M, same depth, width 512",
          input: { label: "Noisy actions + state", caption: "54 steps × 14-D, time τ" },
          rows: [
            { t: "linear", label: "Action projection", call: ["14 → 512", "c1", "c3"] },
            { t: "group", label: "28 blocks, block i ↔ video block i", rows: [
              { t: "norm", label: "RMSNorm · shift, scale", side: "AdaLN" },
              { t: "attn", label: "Self-attention over actions", side: "RoPE", call: ["16 heads × 32 = 512", "c1", "c3"], zoom: { k: "heads", q: 16, kv: 16, hd: 32, title: "Action self-attention" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { id: "xa", t: "attn", label: "Cross-attn to video block i", call: ["Keys, values: 2,048-d video tokens", "p3", "c3"] },
              { t: "add", span: 1 },
              { t: "norm", label: "RMSNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)" },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "Final norm · shift, scale" },
            { t: "linear", label: "Linear → 14-D velocity",
              zoom: { k: "rows", title: "Slow–fast asynchronous inference", rows: ["video DiT: 1 flow step at 5 Hz", "cache video tokens of all 28 blocks", "action DiT: 5 flow steps", "54 actions at 30 Hz in 200 ms"] } } ],
          output: { label: "54-step action chunk" } }
      ],
      links: [
        { from: "base", to: "act", toRow: "xa", label: "video tokens, per block" },
        { from: "vae", to: "base", toRow: "input", label: "latents × 3 views" }
      ]
    },
    modules: [
      { id: "vae", role: "codec", name: "LTX-Video VAE", sub: "128-ch latents, 3 views", col: 0, frozen: true, short: "VAE" },
      { id: "base", role: "video-gen", roleLabel: "World model (GE-Base)", name: "GE-Base video DiT", sub: "28 × 2048 · 32 heads", col: 1, frozen: false, main: true, params: "2B", short: "GE-Base",
        stack: { rows: [
          { t: "in", label: "[x₀ | 4 memory | noisy chunk] × 3 views", dims: "192 × 256 per view", c: "data-4" },
          { t: "linear", label: "Patch embed (patch 1) → 2,048" },
          { t: "embed", label: "+ RoPE + view embedding" },
          { t: "block", label: "LTX transformer block", n: "28", rows: [
            { t: "norm", label: "RMSNorm (no affine) · shift, scale" }, { t: "attn", label: "Self-attn · 32 × 64 · QK-RMSNorm (cross-view every 3rd)" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "attn", label: "Cross-attn to T5-XXL" }, { t: "add", span: 1 },
            { t: "norm", label: "RMSNorm · shift, scale" }, { t: "ffn", label: "FFN 2,048 → 8,192 → 2,048 · GELU" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "linear", label: "Final norm · Linear → 128 ch" },
          { t: "out", label: "flow velocity for the next chunk", dims: "cached per block for GE-Act", c: "data-4" } ],
          facts: [["Blocks / heads / head dim", ["28 / 32 / 64", "c1"]], ["Cross-view blocks", ["block index divisible by 3 (10 of 28)", "c2"]], ["Stage I", ["57 frames at 3–30 Hz → 8 latent frames, 4 memory frames", "p2"]], ["Stage II", ["9 frames at 5 Hz → 2 latent frames", "p2"]], ["Base models", ["LTX-Video 2B or COSMOS2 2B", "p1"]]] } },
      { id: "act", role: "action-expert", roleLabel: "Action branch (GE-Act)", name: "GE-Act action DiT", sub: "28 × 512 · 16 heads", col: 2, frozen: false, params: "160M", short: "GE-Act",
        stack: { rows: [
          { t: "in", label: "noisy 54 × 14 actions (+ state)", dims: "flow time τ", c: "data-3" },
          { t: "linear", label: "Linear 14 → 512 · AdaLN-single(τ)" },
          { t: "block", label: "Action block i (paired with video block i)", n: "28", rows: [
            { t: "norm", label: "RMSNorm · AdaLN(τ)" }, { t: "attn", label: "Self-attention · 16 × 32 · RoPE" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 },
            { t: "attn", label: "Cross-attention to video block i tokens" }, { t: "add", span: 1 },
            { t: "norm", label: "RMSNorm · AdaLN(τ)" }, { t: "ffn", label: "Feed forward · GELU" }, { t: "adaln", label: "× gate" }, { t: "add", span: 3 } ] },
          { t: "linear", label: "Norm · shift, scale · Linear → 14" },
          { t: "out", label: "velocity for 54 actions", dims: "5 flow steps", c: "data-3" } ],
          facts: [["Parameters", ["160M", "p3"]], ["Width", ["16 × 32 = 512", "c1"]], ["Chunk", ["54 steps at 30 Hz", "p3", "c1"]], ["Pretraining", ["3 days on 16 A100, GE-Base frozen", "p3"]]] } }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "head + 2 wrist views", n: "x₀ + 4 memory frames", k: 5 },
      { to: "base", mod: "lang", label: "instruction (T5-XXL)", n: "cross-attention", k: 3 },
      { to: "act", mod: "action", label: "noisy action chunk", n: "54 × 14", k: 5, noisy: true }
    ],
    outputs: [
      { from: "base", mod: "future", label: "next multi-view chunk", n: "optional at run time", k: 4 },
      { from: "act", mod: "action", label: "action chunk", n: "54 steps, 30 Hz", k: 5 }
    ],
    links: [
      { from: "vae", to: "base", kind: "latent", label: "latents × 3 views" },
      { from: "base", to: "act", kind: "cross-attn", label: "video tokens|per block" }
    ],
    callouts: [
      "GE-Sim (§5) turns GE-Base into an action-conditioned simulator: 14-D end-effector trajectories are rendered as pose images and motion vectors in token space, plus a CLIP reference image by cross-attention.",
      "OpenWAM would call GE-Act a dual-system WAM with cross-attention: the action branch reads the video DiT's features at every layer."
    ]
  });

  /* ------------------------------------------------------------------ IRASim */
  var IR = "bytedance/IRASim", IRC = "c72b6da";
  RB.arch.spec({
    id: "irasim", method: "irasim", name: "IRASim", year: 2024,
    figRef: "Zhu et al. Fig. 2 · §3.3 · App. B, C, E", prov: "IRASim-XL Frame-Ada, RT-1 configuration",
    lede: "A latent video DiT that renders a robot executing a given action trajectory. Blocks alternate spatial and temporal attention; each action conditions its own frame's spatial blocks through AdaLN (Frame-Ada), locking action and frame together.",
    sources: {
      p1: { kind: "paper", ref: "Zhu et al. 2025, §3.3 and Fig. 2 (architecture, conditioning)", url: ax("2406.14540") },
      p2: { kind: "paper", ref: "Zhu et al. 2025, App. C (Video-Ada, Frame-Ada equations)", url: ax("2406.14540") },
      p3: { kind: "paper", ref: "Zhu et al. 2025, App. E, Tables 10–11 (training, model sizes)", url: ax("2406.14540") },
      p4: { kind: "paper", ref: "Zhu et al. 2025, §4.1 and App. B (datasets, frames, resolution)", url: ax("2406.14540") },
      c1: gh(IR, IRC, "models/irasim.py"),
      c2: gh(IR, IRC, "configs/train/rt1/frame_ada.yaml")
    },
    summary: {
      pattern: ["Action-conditioned video world model (latent DiT)", "p1"],
      params: ["679M (IRASim-XL); sizes 33M to 679M", "p3"],
      vision: ["Frozen SDXL VAE, 4-channel latents; RT-1 frames at 256 × 320", "p1", "p3", "c2"],
      backbone: ["DiT: 28 blocks alternating spatial / temporal, width 1,152, 16 heads, patch 2", "p3", "c1"],
      head: ["AdaLN final layer + linear unpatchify → noise ε", "p1", "c1"],
      output: ["ε for 15 future frames given 1 history frame (RT-1, Bridge, Language-Table)", "p4"],
      attention: ["Factorised: spatial inside each frame, temporal across frames per patch", "p1", "c1"],
      cond: ["Frame-Ada: emb(aᵢ) + emb(t) sets frame i's spatial AdaLN; history frame kept clean", "p1", "p2"],
      steps: ["PNDM, 50 sampling steps", "p3"],
      chunk: ["15 actions → 15 frames per pass; longer videos autoregressively", "p4"],
      rate: null,
      latency: ["≈30 s for a 16-frame video on one A100 (8 GB)", "p3"],
      train: ["RT-1, Bridge, Language-Table, RoboNet; 300k steps, batch 64, lr 10⁻⁴", "p3", "p4"]
    },
    blueprint: {
      headline: "IRASim: one action per frame",
      note: "The history frame's latents stay clean in the sequence, so predicted frames attend to it. In each spatial block, frame i is modulated by its own action aᵢ plus the diffusion timestep; the temporal block that follows mixes frames at each patch location. 14 such pairs make the 28 blocks.",
      towers: [
        { mod: "vae", title: "SDXL VAE", sub: "frozen", compact: true,
          input: { label: "Frames 256 × 320", caption: "1 history + 15 targets (RT-1)" },
          rows: [{ t: "conv", label: "VAE encoder", call: ["4-channel latents", "p1", "p3"] }],
          output: { label: "latent frames" } },
        { mod: "dit", title: "IRASim-XL DiT", sub: "Frame-Ada, 679M",
          input: { label: "History latent ‖ noisy latents", caption: "16 frames, only the targets noised" },
          rows: [
            { t: "conv", label: "Patchify 2 × 2 · Linear", call: ["4 ch × 2 × 2 → 1,152", "p3", "c1"] },
            { t: "embed", label: "+ sin-cos spatial position" },
            { t: "block", n: "14", label: "spatial + temporal pair", rows: [
              { id: "n1", t: "norm", label: "LN · per-frame AdaLN",
                zoom: { k: "rows", title: "Frame-level adaptation", rows: ["action aᵢ → MLP → emb(aᵢ)", "cᵢ = emb(aᵢ) + emb(t)", "SiLU → Linear → 6 × 1,152", "frame i gets its own γ, β, α"] } },
              { t: "attn", label: "Spatial attention (in frame)", call: ["16 heads, head dim 72", "p3", "c1"], zoom: { k: "heads", q: 16, kv: 16, hd: 72, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 4,608", "c1"], zoom: { k: "mlp", act: "GELU", d: "1,152", ff: "4,608", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "attn", label: "Temporal attention (per patch)", call: ["+ sin-cos time embedding once", "c1"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (GELU)" },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final AdaLN layer" },
            { t: "linear", label: "Linear · unpatchify → ε" } ],
          output: { label: "ε for 15 future frames" } },
        { mod: "act", title: "Action embedder", sub: "one embedding per action", compact: true,
          input: { label: "Trajectory a₁ … a₁₅", caption: "RT-1: 7-D Δ pose + gripper" },
          rows: [
            { t: "mlp", label: "MLP · GELU", call: ["7 → 4,608 → 1,152 per action", "c1"] },
            { t: "embed", label: "+ diffusion timestep emb.", call: ["10 % replaced by a mask embedding", "c1"] } ],
          output: { label: "cᵢ per frame" } }
      ],
      links: [
        { from: "vae", to: "dit", toRow: "input", label: "latents" },
        { from: "act", to: "dit", toRow: "n1", label: "cᵢ" }
      ]
    },
    modules: [
      { id: "vae", role: "codec", name: "SDXL VAE", sub: "4-ch latents · frozen", col: 0, frozen: true, short: "VAE" },
      { id: "dit", role: "world", roleLabel: "Trajectory-to-video DiT", name: "IRASim-XL", sub: "28 × 1152 · 16 heads", col: 1, frozen: false, main: true, params: "679M", short: "DiT",
        stack: { rows: [
          { t: "in", label: "[history latent | 15 noisy latents]", dims: "patch 2 × 2", c: "data-4" },
          { t: "conv", label: "Patch embed → 1,152 + sin-cos position" },
          { t: "block", label: "Spatial + temporal pair", n: "14", rows: [
            { t: "norm", label: "LayerNorm · per-frame AdaLN (action i + t)" }, { t: "attn", label: "Spatial MHA · 16 heads" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · per-frame AdaLN" }, { t: "ffn", label: "MLP 1,152 → 4,608 → 1,152" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN (timestep)" }, { t: "attn", label: "Temporal MHA · 16 heads" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm · AdaLN (timestep)" }, { t: "ffn", label: "MLP 1,152 → 4,608 → 1,152" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final AdaLN layer" },
          { t: "linear", label: "Linear → 2 × 2 × 4, unpatchify" },
          { t: "out", label: "noise ε for target frames", dims: "L2 loss only on predicted frames", c: "data-4" } ],
          facts: [["Depth / width / heads", ["28 / 1,152 / 16", "p3", "c1"]], ["Patch size", ["2", "p3", "c1"]], ["Sizes", ["S 33M · B 132M · L 461M · XL 679M", "p3"]], ["Training", ["AdamW 10⁻⁴, batch 64, 300k steps, EMA 0.9999, clip 0.1", "p3"]], ["Sampler", ["PNDM, 50 steps", "p3"]]] } },
      { id: "act", role: "net", roleLabel: "Action embedder", name: "Per-action MLP", sub: "7 → 1,152 per frame", col: 2, frozen: false, short: "Action MLP" }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "history frame", n: "1 (RoboNet: 2)", k: 2 },
      { to: "dit", mod: "time", label: "diffusion step t", n: "shared", k: 1 },
      { to: "act", mod: "action", label: "action trajectory", n: "15 × 7 (RT-1)", k: 5 }
    ],
    outputs: [{ from: "dit", mod: "future", label: "future frames", n: "15 latents → VAE", k: 5 }],
    links: [
      { from: "vae", to: "dit", kind: "latent", label: "clean history|+ noisy targets" },
      { from: "act", to: "dit", kind: "adaln", label: "cᵢ = emb(aᵢ) + emb(t)|per frame" }
    ],
    callouts: [
      "<b>Paper vs code:</b> §3.3 encodes each action with a linear layer; for RT-1 and Bridge the released model uses an MLP (7 → 4,608 → 1,152, GELU).",
      "<b>Paper vs code:</b> App. C.2 says temporal blocks share a trajectory-level embedding; in the released Frame-Ada path (extras = 3) temporal blocks get the timestep embedding only, and the final layer skips the action (a comment calls this a legacy bug).",
      "<b>Paper vs paper:</b> Table 10 lists 3,000,000 training steps; App. E's text and the RT-1 config (max_train_steps) say 300k.",
      "Video-Ada, the ablation, instead encodes the whole trajectory into one embedding for every block; Frame-Ada wins in the human study (Fig. 4)."
    ]
  });
})();
