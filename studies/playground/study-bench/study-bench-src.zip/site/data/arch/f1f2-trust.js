/* Architecture specs, topics F1 (verifiers, failure detectors, value guidance) and F2 (safety layers, safe RL, attacks drawn as overlays on their target model).
   Numbers from the papers and the official code; see sources. Attack papers have no model of their own: each is drawn on its victim (π0, OpenVLA, SpatialVLA). */
(function () {
  var RB = window.RB;
  function P(ref, id) { return { kind: "paper", ref: ref, url: "https://arxiv.org/abs/" + id }; }
  function C(repo, path, commit) { return { kind: "code", repo: repo, path: path, commit: commit, url: "https://github.com/" + repo + "/blob/" + commit + "/" + path }; }

  /* ============================== F1 ============================== */

  /* ---------- KnowNo ---------- */
  RB.arch.spec({
    id: "knowno", method: "knowno", name: "KnowNo", year: 2023, parent: "saycan",
    diffRows: ["pattern", "backbone", "head", "output", "cond", "train"],
    figRef: "Ren et al. Fig. 2 · §2–3 · App. A6–A7", prov: "mobile-manipulation notebook",
    lede: "A frozen LLM planner turned into a calibrated one. The LLM writes four candidate next steps, then scores the letters A–E; conformal prediction keeps every option above a calibrated threshold, and the robot asks a human whenever more than one survives.",
    sources: {
      p1: P("Ren et al. 2023, §2 (planning as MCQA)", "2307.01928"),
      p2: P("Ren et al. 2023, §3.1–3.2 and Eq. (2)", "2307.01928"),
      p3: P("Ren et al. 2023, §4 and Tables 1–2", "2307.01928"),
      p4: P("Ren et al. 2023, App. A6–A7 (prompts, calibration data)", "2307.01928"),
      c1: C("google-research/google-research", "language_model_uncertainty/KnowNo_MobileManipulation.ipynb", "d36068b")
    },
    summary: {
      pattern: ["LLM/VLM planner + conformal prediction", "p1", "p2"],
      params: "not disclosed",
      vision: ["None in the LLM: scene arrives as text from an object detector or an oracle", "p1"],
      backbone: ["PaLM-2L, frozen, no fine-tuning; also PaLM-2L-IF and GPT-3.5", "p3"],
      head: ["Next-token probabilities of the five labels A–E", "p1", "c1"],
      output: ["Prediction set C ⊆ {A…E}; a singleton executes, otherwise the human picks", "p1", "p2"],
      attention: "not disclosed",
      cond: ["Few-shot prompt → 4 options + “an option not listed here”, shuffled", "p4"],
      steps: ["2 LLM calls per step: generate options, then score letters", "p1", "p4"],
      chunk: null, rate: null, latency: null,
      train: ["No training. Calibration: N = 400 labelled scenarios, δ = 0.01", "p2", "p4"]
    },
    changes: [
      "SayCan scores skills with affordances; KnowNo asks the LLM to <b>write 4 options</b> and scores them as a multiple-choice question.",
      "A <b>conformal threshold</b> calibrated on 400 labelled scenarios turns the letter probabilities into a prediction set.",
      "The robot <b>asks a human</b> when the set is not a singleton, giving a 1 − ε task-success guarantee.",
      "No value function or learned affordance model: only the frozen LLM and one scalar threshold q̂."
    ],
    blueprint: {
      headline: "KnowNo: an LLM that knows when to ask",
      note: "The same frozen LLM is called twice per step: once to write options, once to score the letters. Only the letter probabilities leave the model; the calibrated threshold 1 − q̂ decides the set, and a non-singleton set becomes a question to the human.",
      towers: [
        { mod: "llm", title: "PaLM-2L (frozen)", sub: "LLM planner, weights not released",
          input: { label: "Context xₜ as text", caption: "scene objects + instruction + few-shot plans" },
          rows: [
            { t: "embed", label: "Few-shot generation prompt" },
            { t: "attn", label: "Decoder LLM (layers not disclosed)", call: ["PaLM-2L; architecture not disclosed", "p3"] },
            { t: "linear", label: "Append option E, shuffle", call: ["E = “an option not listed here”", "p1", "p4"] },
            { t: "linear", label: "Score prompt: which letter?", call: ["One next token over A, B, C, D, E", "p1", "c1"],
              zoom: { k: "rows", title: "Planning as MCQA", rows: ["scene + instruction", "LLM writes options A–D", "append E, shuffle order", "“Which option is correct?”", "p(A) … p(E) from one token"] } } ],
          output: { label: "f̂(x̃)y for y ∈ {A…E}" } },
        { mod: "cp", title: "Conformal calibration", sub: "one threshold, fixed after calibration",
          input: { label: "Letter probabilities", caption: "calibration set of labelled scenarios" },
          rows: [
            { t: "linear", label: "Score κᵢ = 1 − f̂(x̃ᵢ)yᵢ", call: ["Non-conformity of the true label", "p2"] },
            { t: "pool", label: "q̂: ⌈(N+1)(1−ε)⌉/N quantile", call: ["N = 400 scenarios, δ = 0.01", "p2"],
              zoom: { k: "rows", title: "Calibration", rows: ["N labelled scenarios", "κᵢ for the true option", "sort κ₁ … κ_N", "q̂ at level ⌈(N+1)(1−ε)⌉/N", "threshold 1 − q̂"] } },
            { t: "linear", label: "C = {y : f̂(x̃)y ≥ 1 − q̂}", call: ["Covers the true option w.p. ≥ 1 − ε", "p2"] } ],
          output: { label: "prediction set C(x̃)" } },
        { mod: "act", title: "Help + primitive", sub: "human in the loop", compact: true,
          input: { label: "Set C(x̃)", caption: "size 1 → act; size > 1 → ask" },
          rows: [
            { t: "linear", label: "Singleton? else ask human", call: ["Help rate 0.67 at 1 − ε = 0.85", "p3"] },
            { t: "mlp", label: "Low-level primitive φ(y)" } ],
          output: { label: "robot action aₜ" } }
      ],
      links: [
        { from: "llm", to: "cp", toRow: "input", label: "letter probs" },
        { from: "cp", to: "act", toRow: "input", label: "prediction set" }
      ]
    },
    modules: [
      { id: "llm", role: "planner", roleLabel: "LLM planner (frozen)", name: "PaLM-2L", sub: "MCQA generate + score", col: 0, frozen: true, main: true, short: "LLM",
        stack: { rows: [
          { t: "in", label: "text context xₜ", dims: "detector or oracle scene description", c: "data-2" },
          { t: "embed", label: "few-shot option-generation prompt", dims: "4 options" },
          { t: "attn", label: "PaLM-2L decoder", dims: "not disclosed" },
          { t: "linear", label: "append E, shuffle, ask for one letter" },
          { t: "out", label: "p(A) … p(E)", dims: "top-5 log-probs in the notebook", c: "data-2" } ],
          facts: [["LLM", ["PaLM-2L (main); PaLM-2L-IF and GPT-3.5 also tested", "p3"]], ["Options", ["4 generated + “an option not listed here”", "p1"]], ["Scoring", ["next-token likelihood of the letters A–E", "p1"]], ["Notebook LLM", ["text-davinci-003, temperature 0", "c1"]], ["Fine-tuning", ["none", "p1"]]] } },
      { id: "cp", role: "critic", roleLabel: "Conformal calibrator", name: "Threshold 1 − q̂", sub: "split conformal", col: 1, frozen: false, short: "CP",
        stack: { rows: [
          { t: "in", label: "letter probabilities f̂(x̃)", c: "data-8" },
          { t: "linear", label: "κ = 1 − f̂(x̃)y (true label)" },
          { t: "pool", label: "empirical quantile q̂" },
          { t: "linear", label: "keep options with f̂ ≥ 1 − q̂" },
          { t: "out", label: "prediction set C", c: "data-8" } ],
          facts: [["Calibration size", ["N = 400 (paper)", "p2"]], ["Confidence", ["δ = 0.01, dataset-conditional bound", "p2"]], ["Notebook calibration", ["200 scenarios; softmax with temperature 5 on log-probs", "c1"]], ["Labelling time", ["≈ 4 h multi-step, 1.5 h single-step (400 examples)", "p3"]]] } },
      { id: "act", role: "net", roleLabel: "Human help + skill", name: "Ask or act", sub: "primitive φ", col: 2, frozen: true, short: "Act" }
    ],
    inputs: [
      { to: "llm", mod: "lang", label: "scene + instruction", n: "text only", k: 4 },
      { to: "cp", mod: "other", label: "calibration set", n: "N = 400", k: 3 }
    ],
    outputs: [{ from: "act", mod: "action", label: "step or question", n: "1 skill", k: 1 }],
    links: [
      { from: "llm", to: "cp", kind: "feeds", label: "p(A) … p(E)" },
      { from: "cp", to: "act", kind: "feeds", label: "set C|size > 1 → ask" }
    ],
    callouts: [
      "Paper §3.2 calibrates on <b>N = 400</b> scenarios; the released mobile-manipulation notebook uses <b>200</b>, and applies a softmax with <b>temperature 5</b> to the letter log-probs, which the paper does not describe.",
      "The notebook runs <b>GPT-3.5 (text-davinci-003)</b>; the paper's main results use PaLM-2L, which is not public."
    ]
  });

  /* ---------- V-GPS ---------- */
  RB.arch.spec({
    id: "v-gps", method: "v-gps", name: "V-GPS", year: 2024,
    figRef: "Nakamoto et al. Fig. 1, 5 · §5 · App. B, K", prov: "lc_cql config, resnetv1-34-bridge-film",
    lede: "A 25.6M-parameter Q-function trained with Cal-QL on Bridge and Fractal re-ranks actions sampled from any generalist policy. A FiLM-conditioned ResNet-34 reads the image; the 7-D action joins at the end.",
    sources: {
      p1: P("Nakamoto et al. 2024, §5.1 (value function, reward)", "2410.13816"),
      p2: P("Nakamoto et al. 2024, §5.2 and Alg. 1 (re-ranking)", "2410.13816"),
      p3: P("Nakamoto et al. 2024, App. B and Table 4", "2410.13816"),
      p4: P("Nakamoto et al. 2024, App. G and K (overhead, size)", "2410.13816"),
      p5: P("Nakamoto et al. 2024, §6 and Tables 1–2", "2410.13816"),
      c1: C("nakamotoo/V-GPS", "experiments/configs/train_config.py", "912a290"),
      c2: C("nakamotoo/V-GPS", "jaxrl_m/vision/resnet_v1.py", "912a290"),
      c3: C("nakamotoo/V-GPS", "jaxrl_m/vision/film_conditioning_layer.py", "912a290"),
      c4: C("nakamotoo/V-GPS", "jaxrl_m/agents/continuous/cql.py", "912a290"),
      c5: C("nakamotoo/V-GPS", "experiments/scripts/launch_calql.sh", "912a290"),
      c6: C("nakamotoo/V-GPS", "experiments/configs/data_config.py", "912a290")
    },
    summary: {
      pattern: ["Learned verifier / failure detector (Q-function re-ranker)", "p2"],
      params: ["25.6M (Q-network)", "p4"],
      vision: ["ResNet-34, GroupNorm, swish, + spatial coordinates, 256 × 256", "p1", "c1", "c2", "c6"],
      backbone: ["16 residual blocks (3, 4, 6, 3), FiLM after every block", "c2"],
      head: ["[image feature ‖ 7-D action] → 256 → 256 → Q", "p3", "c1"],
      output: ["Scalar Q(s, a, l); ensemble of 2 critics (clipped double Q)", "p3", "c4"],
      attention: "None (convolutions only)",
      cond: ["Frozen MUSE sentence embedding → FiLM in every block", "p1", "c3"],
      steps: ["K = 10 or 50 samples; greedy (β → 0) or softmax(Q/β)", "p2", "p3"],
      chunk: null, rate: null,
      latency: ["1.28× Octo-small at K = 10, 1.59× at K = 50", "p4"],
      train: ["Cal-QL α = 5, γ = 0.98, 1M steps, lr 3e-4 on Bridge + Fractal", "p3", "c5"]
    },
    blueprint: {
      headline: "V-GPS: a FiLM ResNet that ranks actions",
      note: "The generalist policy is a black box that proposes K actions. Each candidate is scored by the same Q-network: the image runs through a ResNet-34 whose 16 residual blocks are all FiLM-modulated by the frozen MUSE instruction embedding; the action is concatenated only after pooling.",
      towers: [
        { mod: "policy", title: "Generalist policy", sub: "Octo, RT-1-X or OpenVLA, untouched", compact: true,
          input: { label: "Image + instruction", caption: "same observation the Q-net sees" },
          rows: [
            { t: "mlp", label: "Black-box policy π(a | s, l)", call: ["Octo-small, Octo-base, RT-1-X, OpenVLA", "p5"] },
            { t: "linear", label: "Sample K actions", call: ["K ∈ {10, 50}", "p3"] } ],
          output: { label: "K candidate actions" } },
        { mod: "qnet", title: "Q-network Qθ(s, a, l)", sub: "ResNet-34 + FiLM, Cal-QL",
          input: { label: "Camera image s", caption: "resized to 256 × 256, [−1, 1]" },
          rows: [
            { t: "conv", label: "+ xy coordinates · Conv 7×7 /2", call: ["64 filters, GroupNorm (4 groups), swish", "c1", "c2"] },
            { t: "pool", label: "Max pool 3×3 /2" },
            { t: "block", n: "16", label: "3 + 4 + 6 + 3 blocks", rows: [
              { t: "conv", label: "Conv 3×3 · GN · swish" },
              { t: "conv", label: "Conv 3×3 · GN" },
              { t: "add", span: 2 },
              { id: "film", t: "film", label: "FiLM: x·(1 + γ) + β", side: "FiLM", zoom: { k: "film", title: "FiLM on every block" } } ] },
            { t: "pool", label: "Global average pool", call: ["64 → 512 channels over 4 stages", "c2"] },
            { t: "linear", label: "Concat 7-D action", call: ["Action joins after the image encoder", "p3"] },
            { t: "mlp", label: "Dense 256 · Dense 256", call: ["Two 256-unit hidden layers", "p3", "c1"],
              zoom: { k: "mlp", act: "swish", d: "512 + 7", ff: "256", title: "Q head (critic MLP)" } },
            { t: "linear", label: "Q value (× 2 critics)", call: ["Clipped double Q, ensemble of 2", "p3", "c4"],
              zoom: { k: "rows", title: "Test-time re-ranking", rows: ["K actions from the policy", "Qθ(s, aᵢ, l) for each", "softmax(Q/β) or argmax", "execute the chosen aᵢ", "next observation, repeat"] } } ],
          output: { label: "Q for each candidate → pick one" } },
        { mod: "muse", title: "MUSE encoder", sub: "multilingual sentence encoder, frozen", compact: true,
          input: { label: "Instruction l", caption: "“put sushi in pot”" },
          rows: [{ t: "embed", label: "Sentence embedding (frozen)", call: ["Frozen; feeds every FiLM layer", "p1"] }],
          output: { label: "language vector" } }
      ],
      links: [
        { from: "policy", to: "qnet", toRow: "input", label: "K candidate actions" },
        { from: "muse", to: "qnet", toRow: "film", label: "MUSE vec" }
      ]
    },
    modules: [
      { id: "policy", role: "vlm", roleLabel: "Generalist policy", name: "Any generalist", sub: "Octo · RT-1-X · OpenVLA", col: 0, frozen: true, short: "Policy" },
      { id: "qnet", role: "critic", roleLabel: "Q-function", name: "ResNet-34 FiLM Q-net", sub: "16 blocks · MLP 256×2", col: 1, frozen: false, main: true, params: "25.6M", short: "Q-net",
        stack: { rows: [
          { t: "in", label: "image 256 × 256 + xy coordinate channels", c: "data-1" },
          { t: "conv", label: "Conv 7×7 /2 → GroupNorm → swish → MaxPool", dims: "64 ch" },
          { t: "block", label: "Basic residual block + FiLM", n: "16", rows: [
            { t: "conv", label: "Conv 3×3 → GN → swish → Conv 3×3 → GN" }, { t: "add", span: 1 },
            { t: "film", label: "FiLM(MUSE)", side: "cond" } ] },
          { t: "pool", label: "global average pool", dims: "512" },
          { t: "linear", label: "concat action a", dims: "+ 7" },
          { t: "mlp", label: "Dense 256 → Dense 256", dims: "swish" },
          { t: "out", label: "Q(s, a, l)", dims: "2 critics", c: "data-8" } ],
          facts: [["Encoder", ["resnetv1-34-bridge-film, stages (3, 4, 6, 3)", "c1", "c2"]], ["Norm / activation", ["GroupNorm with 4 groups, swish", "c1", "c2"]], ["Language", ["frozen MUSE → FiLM after every block", "p1", "c2"]], ["Critic MLP", ["256, 256", "p3", "c1"]], ["Parameters", ["25.6M", "p4"]], ["Reward", ["last 3 steps 0, else −1", "p3"]]] } },
      { id: "muse", role: "lang", name: "MUSE (frozen)", sub: "sentence embedding", col: 2, frozen: true, short: "MUSE" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "observation", n: "camera image", k: 3 },
      { to: "qnet", mod: "vision", label: "same image", n: "256 × 256", k: 3 },
      { to: "muse", mod: "lang", label: "instruction", n: "1 sentence", k: 2 }
    ],
    outputs: [{ from: "qnet", mod: "action", label: "best-ranked action", n: "1 of K", k: 1 }],
    links: [
      { from: "policy", to: "qnet", kind: "feeds", label: "K sampled|actions" },
      { from: "muse", to: "qnet", kind: "film", label: "language|embedding" }
    ],
    callouts: [
      "Paper App. B trains the value function with <b>batch size 512</b>; the released <code>launch_calql.sh</code> uses <b>256</b>.",
      "The Q-network never sees the policy's weights: V-GPS only needs the policy to be <b>stochastic</b> so that K samples differ."
    ]
  });

  /* ---------- RoboMonkey ---------- */
  RB.arch.spec({
    id: "robomonkey", method: "robomonkey", name: "RoboMonkey", year: 2025, parent: "v-gps",
    diffRows: ["params", "vision", "backbone", "head", "cond", "steps", "latency", "train"],
    figRef: "Kwok et al. Fig. 2 · §4 · App. B, G", prov: "infer_server.py",
    lede: "Test-time scaling for a VLA. OpenVLA proposes a few actions, a Gaussian fitted to them yields 16 candidates, and a LLaVA-7B turned reward model scores each candidate written as action tokens; the best one runs.",
    sources: {
      p1: P("Kwok et al. 2025, §4.2–4.4 and Alg. 1", "2506.17811"),
      p2: P("Kwok et al. 2025, §5.1 and §5.4", "2506.17811"),
      p3: P("Kwok et al. 2025, App. B (training, deployment)", "2506.17811"),
      p4: P("Kwok et al. 2025, App. G, Table 3 (latency)", "2506.17811"),
      p5: P("Liu et al. 2023 (LLaVA-1.5), §3.3 and App. A.3", "2310.03744"),
      p6: P("Radford et al. 2021 (CLIP), Table 20", "2103.00020"),
      p7: P("Touvron et al. 2023a (LLaMA), Table 2", "2302.13971"),
      c1: C("robomonkey-vla/RoboMonkey", "monkey-verifier/src/infer_server.py", "db9f8d3"),
      c2: C("robomonkey-vla/RoboMonkey", "monkey-verifier/src/models/reward_model.py", "db9f8d3"),
      c3: C("robomonkey-vla/RoboMonkey", "monkey-verifier/src/action_processing.py", "db9f8d3")
    },
    summary: {
      pattern: ["Learned verifier / failure detector (VLM reward model)", "p1"],
      params: ["7B verifier (LLaVA-7B) on top of 7B OpenVLA", "p1", "p2"],
      vision: ["CLIP ViT-L/14 at 336 × 336, second-to-last layer → 576 tokens", "p5", "c1"],
      backbone: ["LLaVA-1.5 7B (Vicuna v1.5): 32 layers, width 4,096, 32 heads", "p1", "p5", "p7"],
      head: ["Unembedding replaced by Linear(4,096 → 1) on the last token", "p1", "c2"],
      output: ["Scalar reward Rϕ(a, s, I) per candidate; argmax is executed", "p1"],
      attention: ["Causal LM over [image | prompt | action tokens | rating prompt]", "p3", "c1"],
      cond: ["Action written as discrete tokens that overwrite rare Llama tokens", "p3", "c3"],
      steps: ["N̂ = 5 VLA samples (T = 1.0) → Gaussian → K̂ = 16 candidates", "p3"],
      chunk: ["One 7-D action per step", "p1"],
      rate: ["≈ 1.5 Hz on one H100 (28 GB)", "p2"],
      latency: ["≈ 650 ms to sample and verify 16 candidates", "p2"],
      train: ["20M synthetic Bridge V2 comparisons; LoRA r 512, α 128; lr 2e-5; 1 epoch", "p2", "p3"]
    },
    changes: [
      "The verifier is a <b>7B VLM</b> (LLaVA-1.5 with a scalar reward head) instead of a 25.6M FiLM ResNet Q-function.",
      "Trained on <b>20M synthetic action preferences</b> (RMSE to the demo action) with a Bradley-Terry loss, not offline RL.",
      "Candidates come from a <b>Gaussian fitted to 5 VLA samples</b> plus a majority-vote gripper, not from K raw policy samples.",
      "Actions are fed as <b>tokens in the prompt</b>, so the reward is read from the LM's last hidden state.",
      "Much slower per step: ≈ 1.5 Hz on an H100, served with an SGLang-based VLA engine."
    ],
    blueprint: {
      headline: "RoboMonkey: sample, perturb, let a VLM judge",
      note: "OpenVLA is only a proposal generator. Its 5 samples set the mean and covariance of a Gaussian over the 6 pose deltas; 16 draws from it, each with the voted gripper state, are written as action tokens into a LLaVA prompt, and the reward head on the final token ranks them.",
      towers: [
        { mod: "prop", title: "Proposal", sub: "OpenVLA 7B + Gaussian augmentation", compact: true,
          input: { label: "Image + instruction", caption: "wrist or third-person view" },
          rows: [
            { t: "mlp", label: "OpenVLA samples N̂ actions", call: ["N̂ = 5 at temperature 1.0 (real robot)", "p3"] },
            { t: "linear", label: "Fit N(μ, Σ) on Δxyz, Δrpy", call: ["Gripper by majority vote", "p1"] },
            { t: "linear", label: "Draw K̂ candidates", call: ["K̂ = 16 (real); {8, 16, 32} in sim", "p3"],
              zoom: { k: "rows", title: "Action proposal", rows: ["N̂ = 5 OpenVLA samples", "Gaussian on 6 pose dims", "gripper = mode of samples", "K̂ draws + fixed gripper", "K̂ candidates to score"] } } ],
          output: { label: "K̂ candidate actions" } },
        { mod: "clip", title: "CLIP ViT-L/14-336", sub: "LLaVA-1.5 vision tower", compact: true,
          input: { label: "Image patches 14 × 14", caption: "336 × 336, padded" },
          rows: [
            { t: "embed", label: "Patch embedding", call: ["336 / 14 = 24 → 576 patches", "p5"] },
            { t: "block", n: "24", rows: [{ t: "attn", label: "ViT block, width 1,024", call: ["16 heads", "p6"] }] },
            { t: "mlp", label: "2-layer MLP projector", call: ["Penultimate-layer features, GELU MLP", "p5", "c1"] } ],
          output: { label: "576 image tokens" } },
        { mod: "llm", title: "LLaVA-1.5 7B reward model", sub: "Vicuna v1.5, LoRA fine-tuned",
          input: { label: "Image + prompt + action tokens", caption: "“The robot should take the action …”" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["Action bins overwrite rare Llama tokens", "p3", "c3"] },
            { t: "block", n: "32", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["32 heads, head dim 128", "p7"], zoom: { k: "heads", q: 32, kv: 32, hd: 128, title: "Attention (7B)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["LoRA on q, k, v, o, gate, up, down", "c1"], zoom: { k: "glu", act: "SiLU", d: "4,096", ff: "⅔·4d", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Reward head on last token", call: ["Linear 4,096 → 1 replaces the LM head", "p1", "c2"],
              zoom: { k: "rows", title: "Reward training", rows: ["N samples per state, cluster to K", "all K·(K−1)/2 pairs", "winner = lower RMSE to demo", "Bradley-Terry + margin α = 0.1", "20M pairs, 1 epoch"] } } ],
          output: { label: "reward per candidate → argmax" } }
      ],
      links: [
        { from: "clip", to: "llm", toRow: "input", label: "image tokens" },
        { from: "prop", to: "llm", toRow: "input", label: "candidate actions" }
      ]
    },
    modules: [
      { id: "prop", role: "vlm", roleLabel: "Proposal VLA (frozen)", name: "OpenVLA + Gaussian", sub: "N̂ = 5 → K̂ = 16", col: 0, frozen: true, params: "7B", short: "Proposal" },
      { id: "clip", role: "vision-enc", name: "CLIP ViT-L/14-336", sub: "24 × 1024 · 576 tokens", col: 1, frozen: false, short: "CLIP" },
      { id: "llm", role: "critic", roleLabel: "Action verifier", name: "LLaVA-1.5 7B + reward head", sub: "32 × 4096 · LoRA", col: 2, frozen: "lora", main: true, params: "7B", short: "Verifier",
        stack: { rows: [
          { t: "in", label: "[image tokens | prompt | action tokens | rating prompt]", c: "data-2" },
          { t: "embed", label: "Llama tokenizer; action bins on rare ids" },
          { t: "block", label: "Vicuna decoder block", n: "32", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "causal MHA · 32 heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU FFN" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "reward head on last position", dims: "4,096 → 1" },
          { t: "out", label: "scalar reward Rϕ", c: "data-8" } ],
          facts: [["Base", ["LLaVA-1.5 7B (Vicuna v1.5)", "p1", "p5", "c1"]], ["Vision tower", ["openai/clip-vit-large-patch14-336, layer −2", "c1"]], ["Loss", ["Bradley-Terry with preference-level margin, α = 0.1", "p1", "p3"]], ["LoRA (paper)", ["rank 512, α 128", "p3"]], ["Data", ["20M comparisons from Bridge V2", "p2"]], ["Throughput", ["46 actions/s at batch 16 on an H100", "p4"]]] } }
    ],
    inputs: [
      { to: "prop", mod: "vision", label: "observation + task", n: "1 image", k: 3 },
      { to: "clip", mod: "vision", label: "same image", n: "336 × 336", k: 4 },
      { to: "llm", mod: "lang", label: "instruction", n: "prompt tokens", k: 3 }
    ],
    outputs: [{ from: "llm", mod: "action", label: "argmax candidate", n: "1 of 16", k: 1 }],
    links: [
      { from: "prop", to: "clip", kind: "feeds", label: "K̂ candidates|(bypass to LLM)" },
      { from: "clip", to: "llm", kind: "prefix", label: "576 image tokens" }
    ],
    mask: { name: "Causal (LM)", ref: "p3", axes: [{ label: "image tokens", short: "img", mod: "vision" }, { label: "prompt", short: "I", mod: "lang" }, { label: "action tokens", short: "a", mod: "action" }, { label: "rating prompt", short: "?", mod: "other" }], m: ["1000", "1100", "1110", "1111"],
      note: "The rating prompt comes last, so the final token sees the image, task and candidate action; the reward is read there." },
    callouts: [
      "Paper App. B discretises each action dimension into <b>256 bins</b>; the released <code>ActionTokenizer</code> defaults to <b>512 bins</b>.",
      "The inference server is configured with <code>lora_r = 64</code>; the paper trains with <b>LoRA rank 512, α 128</b> (the adapter weights are loaded from the checkpoint).",
      "RoboMonkey reports that V-GPS paired with OpenVLA does <b>worse</b> than OpenVLA alone in SIMPLER (§5.2)."
    ]
  });

  /* ---------- FAIL-Detect ---------- */
  RB.arch.spec({
    id: "fail-detect", method: "fail-detect", name: "FAIL-Detect", year: 2025, parent: "diffusion-policy",
    diffRows: ["pattern", "head", "output", "cond", "steps", "train"],
    figRef: "Xu et al. Fig. 1 · §IV · App. A–C, Table III", prov: "Square task, flow policy",
    lede: "A second network watches the policy's inputs. logpZO fits a flow from the policy's observation embedding to Gaussian noise on successful demos only; a large ‖Z‖² means an unfamiliar observation, and a functional conformal band turns the score into an alarm.",
    sources: {
      p1: P("Xu et al. 2025, §IV-A and Table I (scores)", "2503.08558"),
      p2: P("Xu et al. 2025, §IV-B (functional CP)", "2503.08558"),
      p3: P("Xu et al. 2025, App. A (logpZO)", "2503.08558"),
      p4: P("Xu et al. 2025, App. B–C and Table III", "2503.08558"),
      c1: C("CXU-TRI/FAIL-Detect", "UQ_baselines/CFM/net_CFM.py", "b758e55"),
      c2: C("CXU-TRI/FAIL-Detect", "UQ_baselines/logpZO/train.py", "b758e55"),
      c3: C("CXU-TRI/FAIL-Detect", "diffusion_policy/configs_robomimic/image_square_ph_visual_flow_policy_cnn.yaml", "b758e55"),
      c4: C("CXU-TRI/FAIL-Detect", "UQ_baselines/RND/net.py", "b758e55")
    },
    summary: {
      pattern: ["Learned verifier / failure detector (OOD score + conformal band)", "p1", "p2"],
      params: null,
      vision: ["Policy's own encoder: ResNet (or CLIP) per camera + robot state → Oₜ", "p4"],
      backbone: ["Policy: 1-D U-Net, down dims 512 / 1,024 / 2,048 (flow or diffusion)", "p4", "c3"],
      head: ["logpZO: unconditional 1-D U-Net 256 / 512 / 1,024 on Oₜ", "p3", "c1"],
      output: ["Score ‖Z‖² with Z = Oₜ + fθ(Oₜ, 0), one per policy call", "p3"],
      attention: "None (convolutions only)",
      cond: ["None: logpZO sees only the observation embedding", "p1", "c1"],
      steps: ["One forward pass of the flow net per step", "p3"],
      chunk: ["Policy: Tₒ = 2, horizon 16, 8 executed", "c3"],
      rate: null, latency: null,
      train: ["Successful demos only; flow net 4× smaller than the policy; α = 0.05 band", "p1", "p4"]
    },
    changes: [
      "The Diffusion Policy is kept and frozen; a <b>second network</b> scores each observation for failure.",
      "The score net is a <b>flow-matching U-Net without conditioning</b>, mapping Oₜ to noise; ‖Z‖² is the failure score (logpZO).",
      "It is trained on <b>successful demonstrations only</b>: no failure data is needed.",
      "A <b>functional conformal band</b> μₜ + h from successful calibration rollouts sets a time-varying threshold (α = 0.05)."
    ],
    blueprint: {
      headline: "FAIL-Detect: a flow from observations to noise",
      note: "The policy's observation embedding Oₜ (image features ‖ state) is the only input. The logpZO net is a flow-matching U-Net trained to carry Oₜ to Gaussian noise; one step at s = 0 gives Z, and a large ‖Z‖² above the conformal band flags a failure.",
      towers: [
        { mod: "policy", title: "Policy (frozen)", sub: "flow-matching or diffusion U-Net", compact: true,
          input: { label: "Images + robot state", caption: "Tₒ = 2 steps" },
          rows: [
            { t: "conv", label: "ResNet per camera", call: ["Crop 76 × 76, GroupNorm", "c3"] },
            { t: "linear", label: "Oₜ = [features ‖ state]", call: ["274-d on Square", "p4"] },
            { t: "conv", label: "Cond. 1-D U-Net → Aₜ", call: ["Down dims 512, 1,024, 2,048", "c3"] } ],
          output: { label: "action chunk Aₜ + Oₜ" } },
        { mod: "score", title: "logpZO flow net fθ", sub: "unconditional 1-D U-Net, successes only",
          input: { label: "Observation embedding Oₜ", caption: "no action, no conditioning" },
          rows: [
            { t: "embed", label: "Time s (× 100, discrete)", call: ["Continuous s scaled by 100", "c2"] },
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GN(8) · Mish" },
                { t: "conv", label: "Conv1d k=5 · GN(8) · Mish" },
                { t: "add", span: 2 } ] },
              { t: "conv", label: "Downsample", call: ["256 → 512 → 1,024 channels", "c1"] } ] },
            { t: "group", label: "Up path, mirrored", rows: [{ t: "conv", label: "Skip concat · res blocks" }] },
            { t: "linear", label: "Velocity fθ(Oₜ[s], s)", call: ["Trained: fθ ≈ Z − Oₜ (flow matching)", "p3"],
              zoom: { k: "rows", title: "logpZO score", rows: ["fit flow Oₜ → Z ~ N(0, I)", "at test: s = 0 only", "Z = Oₜ + fθ(Oₜ, 0)", "log p(Z) ∝ −‖Z‖²", "score = ‖Z‖²"] } } ],
          output: { label: "score ‖Z‖²" } },
        { mod: "cp", title: "Functional CP band", sub: "time-varying threshold", compact: true,
          input: { label: "Score time series", caption: "successful calibration rollouts" },
          rows: [
            { t: "linear", label: "Mean μₜ on split A", call: ["e.g. 269 successes (Square, FM)", "p4"] },
            { t: "pool", label: "Width h: (1 − α) quantile", call: ["α = 0.05 on split B", "p2", "p4"],
              zoom: { k: "rows", title: "CP band", rows: ["split successes A | B", "μₜ = mean score on A", "max deviation per rollout on B", "h = (1 − α) quantile", "alarm if score > μₜ + h·s(t)"] } } ],
          output: { label: "alarm when above μₜ + h" } }
      ],
      links: [
        { from: "policy", to: "score", toRow: "input", label: "Oₜ" },
        { from: "score", to: "cp", toRow: "input", label: "‖Z‖² per step" }
      ]
    },
    modules: [
      { id: "policy", role: "action-head", roleLabel: "Policy (frozen)", name: "DP / flow U-Net", sub: "512 → 1024 → 2048 ch", col: 0, frozen: true, short: "Policy" },
      { id: "score", role: "critic", roleLabel: "Failure score net", name: "logpZO flow U-Net", sub: "256 → 512 → 1024 ch", col: 1, frozen: false, main: true, short: "logpZO",
        stack: { rows: [
          { t: "in", label: "Oₜ[s] = Oₜ + s(Z − Oₜ)", dims: "observation embedding", c: "data-7" },
          { t: "embed", label: "diffusion-step embedding of ⌊100 s⌋", dims: "128" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "residual block", n: "2", rows: [{ t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" }, { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" }, { t: "add", span: 2 }] },
            { t: "conv", label: "Downsample1d", dims: "256 → 512 → 1024" } ] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip + residual blocks" }] },
          { t: "conv", label: "final Conv1d", dims: "→ input width" },
          { t: "out", label: "fθ ≈ Z − Oₜ", dims: "score ‖Oₜ + fθ(Oₜ, 0)‖²", c: "data-8" } ],
          facts: [["Architecture", ["ConditionalUnet1D, no global conditioning", "c1"]], ["Down dims", ["256 / 512 / 1,024, kernel 5, 8 groups", "c1"]], ["Step embedding", ["128", "c1"]], ["Optimiser", ["Adam, lr 1e-4, batch 128", "p4", "c2"]], ["Epochs (sim)", ["500 in the paper; 200 in train.py", "p4", "c2"]], ["Best score", ["logpZO top-3 in 14 of 16 cases", "p1"]]] } },
      { id: "cp", role: "net", roleLabel: "Conformal band", name: "Functional CP", sub: "μₜ + h · s(t)", col: 2, frozen: false, short: "CP" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "images + state", n: "Tₒ = 2", k: 4 },
      { to: "score", mod: "time", label: "flow time s", n: "s = 0 at test", k: 1 }
    ],
    outputs: [
      { from: "policy", mod: "action", label: "action chunk", n: "16, 8 run", k: 4 },
      { from: "cp", mod: "other", label: "failure flag", n: "per step", k: 1 }
    ],
    links: [
      { from: "policy", to: "score", kind: "feeds", label: "embedding Oₜ" },
      { from: "score", to: "cp", kind: "feeds", label: "‖Z‖² over time" }
    ],
    callouts: [
      "Paper App. C trains the logpZO flow net for <b>500 epochs</b> in simulation; the released <code>logpZO/train.py</code> sets <b>EPOCHS = 200</b>.",
      "RND, the second-best score, uses two U-Nets (frozen target, trained predictor) on (Aₜ, Oₜ); its predictor also uses down dims 256 / 512 / 1,024 in code."
    ]
  });

  /* ---------- SAFE ---------- */
  RB.arch.spec({
    id: "safe", method: "safe", name: "SAFE", year: 2025, parent: "fail-detect",
    diffRows: ["pattern", "vision", "backbone", "head", "cond", "train"],
    figRef: "Gu et al. Fig. 2 · §4 · App. B", prov: "IndepModelConfig / LstmModelConfig defaults",
    lede: "A tiny probe on a large VLA's last hidden layer. Features are pooled per step and a 2-layer MLP (or 1-layer LSTM) predicts a failure score trained on both successes and failures of many tasks, then thresholded by a functional conformal band.",
    sources: {
      p1: P("Gu et al. 2025, §4.2 (probe, losses)", "2506.09937"),
      p2: P("Gu et al. 2025, §4.3 (functional CP)", "2506.09937"),
      p3: P("Gu et al. 2025, App. B.1–B.2 (features, models)", "2506.09937"),
      p4: P("Gu et al. 2025, §6.4 (overhead)", "2506.09937"),
      p5: P("Gu et al. 2025, App. B.7 and Table 1", "2506.09937"),
      c1: C("vla-safe/SAFE", "failure_prob/conf/__init__.py", "b6036ab"),
      c2: C("vla-safe/SAFE", "failure_prob/model/indep.py", "b6036ab"),
      c3: C("vla-safe/SAFE", "failure_prob/model/lstm.py", "b6036ab")
    },
    summary: {
      pattern: ["Learned verifier / failure detector (probe on VLA features)", "p1"],
      params: ["Probe only: SAFE-LSTM 2.3M; host π0 3.3B", "p4"],
      vision: ["None of its own: reads the VLA's final-layer hidden states", "p1", "p3"],
      backbone: ["Host VLA (OpenVLA, π0, π0-FAST), frozen", "p3"],
      head: ["SAFE-MLP: 2 layers, hidden 256 · SAFE-LSTM: 1 layer, hidden 256", "p3", "c1"],
      output: ["Failure score sₜ: cumulative sum of sigmoids (MLP) or sigmoid (LSTM)", "p1", "c2", "c3"],
      attention: "None in the probe",
      cond: ["Pooled VLA feature eₜ (first, last or mean over tokens, horizon, flow steps)", "p3"],
      steps: ["One probe call per VLA call", "p1"],
      chunk: null, rate: null,
      latency: ["+0.73 ms (SAFE-LSTM) vs 149 ms for π0", "p4"],
      train: ["Successful and failed rollouts of seen tasks; 1,000 epochs, batch 512", "p1", "p5", "c1"]
    },
    changes: [
      "Reads the <b>VLA's own last-layer features</b> instead of the policy's observation embedding.",
      "Trained on <b>both successes and failures</b> across many tasks, and tested on unseen tasks.",
      "The score net is a <b>2-layer MLP or 1-layer LSTM</b> (hidden 256), not a flow U-Net.",
      "The same functional conformal band sets the time-varying threshold."
    ],
    blueprint: {
      headline: "SAFE: a small probe on VLA features",
      note: "The VLA runs unchanged. SAFE grabs its hidden states before the token logits (OpenVLA, π0-FAST) or before the velocity projection (π0), pools them to one vector eₜ per step, and a small MLP turns each eₜ into a probability that is summed over time.",
      towers: [
        { mod: "vla", title: "Host VLA (frozen)", sub: "OpenVLA · π0 · π0-FAST", compact: true,
          input: { label: "Images + instruction", caption: "the normal VLA forward pass" },
          rows: [
            { t: "attn", label: "VLA transformer", call: ["π0: 3.3B parameters, 149 ms", "p4"] },
            { t: "norm", label: "Last layer hidden states E", call: ["Before logits or velocity projection", "p1", "p3"] },
            { t: "pool", label: "Aggregate E → eₜ", call: ["First, last, mean, or first ‖ last", "p3"],
              zoom: { k: "rows", title: "Feature aggregation", rows: ["E: tokens × d (OpenVLA, FAST)", "E: H × k × d (π0 flow)", "pool over horizon H", "pool over flow steps k", "one vector eₜ per step"] } } ],
          output: { label: "feature eₜ" } },
        { mod: "probe", title: "SAFE-MLP", sub: "per-step probe, summed over time",
          input: { label: "Feature eₜ", caption: "one vector per VLA call" },
          rows: [
            { t: "linear", label: "Linear d → 256 · ReLU", call: ["Hidden dimension 256", "p3", "c1", "c2"], zoom: { k: "mlp", act: "ReLU", d: "d", ff: "256", title: "SAFE-MLP" } },
            { t: "linear", label: "Linear 256 → 1 · sigmoid", call: ["2 layers in total", "p3", "c1"] },
            { t: "pool", label: "Cumulative sum over t", call: ["sₜ = Σ σ(g(eτ)), so 0 < sₜ < t", "p1", "c2"],
              zoom: { k: "rows", title: "SAFE-LSTM variant", rows: ["e₁ … eₜ in order", "LSTM, 1 layer, hidden 256", "Linear 256 → 1", "sigmoid → sₜ ∈ [0, 1]", "BCE on every step"] } } ],
          output: { label: "failure score sₜ" } },
        { mod: "cp", title: "Functional CP", sub: "band from seen-task successes", compact: true,
          input: { label: "Score curve sₜ", caption: "calibration successes" },
          rows: [{ t: "linear", label: "Alarm if sₜ > μₜ + hₜ", call: ["FPR ≤ α on successful rollouts", "p2"] }],
          output: { label: "stop / ask for help" } }
      ],
      links: [
        { from: "vla", to: "probe", toRow: "input", label: "pooled feature" },
        { from: "probe", to: "cp", toRow: "input", label: "score sₜ" }
      ]
    },
    modules: [
      { id: "vla", role: "vlm", roleLabel: "Host VLA (frozen)", name: "OpenVLA / π0 / π0-FAST", sub: "last-layer features", col: 0, frozen: true, short: "VLA" },
      { id: "probe", role: "critic", roleLabel: "Failure probe", name: "SAFE-MLP / LSTM", sub: "hidden 256", col: 1, frozen: false, main: true, short: "SAFE",
        stack: { rows: [
          { t: "in", label: "pooled VLA feature eₜ", c: "data-7" },
          { t: "linear", label: "Linear d → 256", dims: "ReLU" },
          { t: "linear", label: "Linear 256 → 1", dims: "sigmoid" },
          { t: "pool", label: "cumulative sum over steps", dims: "MLP variant" },
          { t: "out", label: "failure score sₜ", c: "data-8" } ],
          facts: [["SAFE-MLP", ["2 layers, hidden 256, cumulative sigmoid, L1-style loss", "p1", "p3", "c1"]], ["SAFE-LSTM", ["1 layer, hidden 256, sigmoid, BCE on every step", "p1", "p3", "c1"]], ["Class balance", ["inverse class-frequency weights, L2 on weights (λ_reg)", "p3"]], ["Training", ["Adam, 1,000 epochs, batch 512 rollouts", "p5", "c1"]], ["Overhead", ["SAFE-LSTM: 2.3M parameters, 0.73 ms", "p4"]]] } },
      { id: "cp", role: "net", roleLabel: "Conformal band", name: "Functional CP", sub: "time-varying threshold", col: 2, frozen: false, short: "CP" }
    ],
    inputs: [
      { to: "vla", mod: "vision", label: "images", n: "each call", k: 3 },
      { to: "vla", mod: "lang", label: "instruction", n: "", k: 2 }
    ],
    outputs: [
      { from: "vla", mod: "action", label: "actions (unchanged)", n: "as the VLA", k: 3 },
      { from: "cp", mod: "other", label: "failure flag", n: "per step", k: 1 }
    ],
    links: [
      { from: "vla", to: "probe", kind: "feeds", label: "hidden states|pooled → eₜ" },
      { from: "probe", to: "cp", kind: "feeds", label: "score sₜ" }
    ],
    callouts: [
      "SAFE-MLP reaches ROC-AUC <b>84.82</b> on unseen SimplerEnv tasks with π0* and <b>88.42</b> on unseen real WidowX tasks with OpenVLA (Table 1, Fig. 6).",
      "No code-vs-paper difference found in probe sizes: the released defaults match App. B (2 × 256 MLP, 1 × 256 LSTM)."
    ]
  });

  /* ---------- FIPER ---------- */
  RB.arch.spec({
    id: "fiper", method: "fiper", name: "FIPER", year: 2025, parent: "fail-detect",
    diffRows: ["pattern", "head", "output", "cond", "steps", "train"],
    figRef: "Römer et al. Fig. 1–2 · §4 · App. A", prov: "rnd_oe + entropy configs",
    lede: "Two alarms that must agree. Random network distillation on the policy's observation embedding flags unfamiliar states; action-chunk entropy flags uncertain plans. Each is window-summed and conformally thresholded, and FIPER fires only when both exceed.",
    sources: {
      p1: P("Römer et al. 2025, §4.1 (RND-OE)", "2510.09459"),
      p2: P("Römer et al. 2025, §5 (implementation, protocol)", "2510.09459"),
      p3: P("Römer et al. 2025, App. A.1 (ACE)", "2510.09459"),
      p4: P("Römer et al. 2025, App. A.2 and Table 3 (RND-OE)", "2510.09459"),
      p5: P("Römer et al. 2025, App. A.3–A.4 and Table 6", "2510.09459"),
      c1: C("utiasDSL/fiper", "rnd/rnd_models.py", "13d79c5"),
      c2: C("utiasDSL/fiper", "rnd/rnd_trainer.py", "13d79c5"),
      c3: C("utiasDSL/fiper", "configs/eval/rnd_parameters.yaml", "13d79c5"),
      c4: C("utiasDSL/fiper", "configs/eval/entropy.yaml", "13d79c5"),
      c5: C("utiasDSL/fiper", "configs/task/push_t.yaml", "13d79c5")
    },
    summary: {
      pattern: ["Learned verifier / failure detector (two scores, logical AND)", "p1", "p5"],
      params: null,
      vision: ["Policy's ResNet-18 observation embedding, frozen", "p1", "p2"],
      backbone: ["Policy: diffusion U-Net (PushT, Pretzel, PushChair) or flow ACT (Sorting, Stacking)", "p2"],
      head: ["RND-OE: target MLP 4 layers, predictor MLP 6 layers, output 512", "p4", "c1", "c2"],
      output: ["Two window-summed scores; alarm when both exceed their thresholds", "p5"],
      attention: "None in the detectors",
      cond: ["ACE: entropy of B sampled chunks per step, in end-effector xyz", "p3", "c4"],
      steps: ["B = 256 chunks per call on PushT", "c5"],
      chunk: ["PushT: horizon 16, 8 executed", "c5"],
      rate: null, latency: null,
      train: ["M = 50 successful rollouts (sim), 10 (real); 250 epochs, lr 1e-4", "p2", "p4", "c3"]
    },
    changes: [
      "Two detectors instead of one: <b>RND</b> on the policy's embedding and <b>action-chunk entropy</b> on sampled plans.",
      "Scores are <b>summed over a sliding window</b> (best w of 25 / 50 for FIPER) before thresholding.",
      "A failure is predicted only when <b>both</b> scores exceed their conformal thresholds (logical AND).",
      "Trained and calibrated on as few as <b>10 successful rollouts</b> on real robots."
    ],
    blueprint: {
      headline: "FIPER: unfamiliar and uncertain, both at once",
      note: "RND-OE reuses the policy's frozen encoder: a random, frozen MLP and a slightly deeper trained MLP read the same embedding, and their distance is the novelty score. ACE samples B action chunks and measures per-step entropy in xyz. Both are window-summed and must both exceed their conformal thresholds.",
      towers: [
        { mod: "policy", title: "Generative policy", sub: "frozen; ResNet-18 encoder", compact: true,
          input: { label: "Images + proprioception", caption: "observation history Oₜ" },
          rows: [
            { t: "conv", label: "ResNet-18 encoder h(·)", call: ["Reused, frozen, inside RND-OE", "p1", "p2"] },
            { t: "mlp", label: "Diffusion U-Net or flow ACT", call: ["Sample B chunks per call", "p3", "c5"] } ],
          output: { label: "embedding Oᵉ + B chunks" } },
        { mod: "rnd", title: "RND-OE predictor fθ", sub: "vs frozen random target g",
          input: { label: "Observation embedding Oᵉ", caption: "same input for target and predictor" },
          rows: [
            { t: "linear", label: "Linear dim(Oᵉ) → 1,024", call: ["LeakyReLU", "p4", "c1"] },
            { t: "linear", label: "Linear 1,024 → 2,048" },
            { t: "linear", label: "Linear 2,048 → 4,096", call: ["Same first 3 layers as the target", "p4"] },
            { t: "linear", label: "4,096 → 2,048 → 1,024", call: ["2 extra ReLU layers", "p4", "c1"] },
            { t: "linear", label: "Linear 1,024 → m", call: ["m = 512", "c2"],
              zoom: { k: "rows", title: "Frozen target g", rows: ["dim(Oᵉ) → 1,024", "→ 2,048 (LeakyReLU)", "→ 4,096 (LeakyReLU)", "→ m = 512", "random init, never trained"] } },
            { t: "pool", label: "‖fθ − g‖₂, window sum", call: ["Window w_O; best w = 25 or 50", "p1", "p5"] } ],
          output: { label: "observation score ηₒ" } },
        { mod: "ace", title: "Action-chunk entropy", sub: "no training", compact: true,
          input: { label: "B sampled chunks", caption: "end-effector positions" },
          rows: [
            { t: "linear", label: "Per-step xyz histogram", call: ["Cell = 0.03 × calibration range", "p3", "c4"],
              zoom: { k: "rows", title: "ACE score", rows: ["B chunks, H steps each", "per step: grid cells in xyz", "pᶜ = count / B", "entropy −Σ pᶜ log₂ pᶜ", "sum over H steps"] } },
            { t: "pool", label: "Sum entropy, window sum", call: ["Window w_A", "p5"] } ],
          output: { label: "action score η_A" } },
        { mod: "gate", title: "CP + AND", sub: "M successes", compact: true,
          input: { label: "η_O and η_A", caption: "time-varying thresholds" },
          rows: [{ t: "linear", label: "Alarm if both > γₜ", call: ["1 − δ averaged over 0.90…0.99", "p2", "p5"] }],
          output: { label: "failure predicted" } }
      ],
      links: [
        { from: "policy", to: "rnd", toRow: "input", label: "embedding Oᵉ" },
        { from: "policy", to: "ace", toRow: "input", label: "B chunks" },
        { from: "rnd", to: "gate", toRow: "input", label: "η_O" },
        { from: "ace", to: "gate", toRow: "input", label: "η_A" }
      ]
    },
    modules: [
      { id: "rnd", role: "critic", roleLabel: "OOD detector", name: "RND-OE", sub: "MLP 4 vs 6 layers · m 512", col: 0, frozen: "partial", main: true, short: "RND-OE",
        stack: { rows: [
          { t: "in", label: "observation embedding Oᵉ = h(Oₜ)", dims: "policy encoder, frozen", c: "data-7" },
          { t: "group", label: "Predictor fθ (trained)", rows: [
            { t: "linear", label: "Linear → 1024 → 2048 → 4096", dims: "LeakyReLU" },
            { t: "linear", label: "Linear → 2048 → 1024", dims: "ReLU" },
            { t: "linear", label: "Linear → m", dims: "m = 512" } ] },
          { t: "group", label: "Target g (random, frozen)", rows: [{ t: "linear", label: "Linear → 1024 → 2048 → 4096 → m", dims: "LeakyReLU" }] },
          { t: "pool", label: "‖fθ(Oᵉ) − g(Oᵉ)‖₂", dims: "then window sum" },
          { t: "out", label: "observation score η_O", c: "data-8" } ],
          facts: [["Target", ["4 linear layers, LeakyReLU", "p4", "c1"]], ["Predictor", ["6 linear layers (3 shared widths + 2,048, 1,024)", "p4", "c1"]], ["Output m", ["512", "c2"]], ["Training", ["AdamW, lr 1e-4 cosine, batch 256, 250 epochs, wd 1e-5", "p4", "c3"]], ["Data", ["successful ID rollouts only", "p1"]]] } },
      { id: "policy", role: "action-head", roleLabel: "Policy (frozen)", name: "Diffusion / flow", sub: "ResNet-18 encoder", col: 1, frozen: true, short: "Policy" },
      { id: "ace", role: "net", roleLabel: "Uncertainty score", name: "Action-chunk entropy", sub: "B chunks · xyz grid", col: 2, frozen: true, short: "ACE" },
      { id: "gate", role: "net", roleLabel: "Decision", name: "CP thresholds + AND", sub: "window-summed", col: 3, frozen: false, short: "Gate" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "images + state", n: "1–2 cameras", k: 4 }
    ],
    outputs: [
      { from: "policy", mod: "action", label: "action chunk", n: "H steps", k: 3 },
      { from: "gate", mod: "other", label: "failure alarm", n: "per call", k: 1 }
    ],
    links: [
      { from: "policy", to: "rnd", kind: "feeds", label: "embedding Oᵉ" },
      { from: "policy", to: "ace", kind: "feeds", label: "B sampled chunks" },
      { from: "ace", to: "gate", kind: "feeds", label: "η_A (+ η_O)" }
    ],
    callouts: [
      "Across five tasks FIPER averages accuracy <b>0.78</b> and TWA <b>0.65</b>, the best of all methods, while RND-OE alone flags too many OOD successes (TNR 0.45, Table 6).",
      "The ACE batch size is task-specific in code: <b>256</b> chunks for PushT and 32 for Sorting."
    ]
  });

  /* ---------- Sentinel ---------- */
  RB.arch.spec({
    id: "sentinel", method: "sentinel", name: "Sentinel", year: 2024, parent: "diffusion-policy",
    diffRows: ["pattern", "vision", "output", "steps", "latency", "train"],
    figRef: "Agia et al. Fig. 3 · §4 · App. A, Table 3", prov: "close_mobile_dp config",
    lede: "A runtime monitor with a fast and a slow half. STAC compares batches of overlapping action chunks from consecutive diffusion-policy calls to catch erratic behaviour; a VLM watches the rollout video to catch confident but wrong progress. Either alarm stops the robot.",
    sources: {
      p1: P("Agia et al. 2024, §4.1 and Eq. (1) (STAC)", "2410.04640"),
      p2: P("Agia et al. 2024, §4.2 (VLM monitor)", "2410.04640"),
      p3: P("Agia et al. 2024, App. A.1 and Table 3", "2410.04640"),
      p4: P("Agia et al. 2024, §5 and Table 1", "2410.04640"),
      c1: C("agiachris/sentinel", "sentinel/bc/configs/close_mobile_dp.yaml", "6dc89ca"),
      c2: C("agiachris/sentinel", "sentinel/bc/policies/dp_policy.py", "6dc89ca"),
      c3: C("agiachris/sentinel", "scripts/eval_detector/evaluate_ood_detectors_mobile.sh", "6dc89ca")
    },
    summary: {
      pattern: ["Learned verifier / failure detector (STAC + VLM video QA)", "p1", "p2"],
      params: null,
      vision: ["Policy: point clouds → PointNet (hidden 128, 4 layers); VLM: RGB video", "c1", "c2", "p2"],
      backbone: ["Diffusion Policy, conditional 1-D U-Net, DDPM 100 steps", "c1", "c2"],
      head: ["STAC: MMD (RBF) or KL via KDE between overlapping chunk batches", "p1", "p3"],
      output: ["Cumulative score ηₜ vs γ; VLM answers ok / failure", "p1", "p2"],
      attention: null,
      cond: ["STAC compares a_{t+k:t+h−1} predicted at t and at t + k", "p1"],
      steps: ["B = 256 (PushT, Push Chair) or 32 (Close Box) samples per call", "p3"],
      chunk: ["h = 16 predicted; k = 8 (PushT) or 4 (mobile) executed", "p3"],
      rate: null,
      latency: ["GPT-4o video QA mean response 14.0 s", "p2"],
      train: ["No failure data: γ = 95th percentile over M = 50 successes (sim), 10 (real)", "p4"]
    },
    changes: [
      "The Diffusion Policy is unchanged; Sentinel <b>samples it B times per call</b> to estimate action distributions.",
      "<b>STAC</b> sums a statistical distance (MMD or KL) between overlapping chunks of consecutive calls.",
      "A <b>VLM</b> (GPT-4o, Claude 3.5 Sonnet or Gemini 1.5 Pro) watches the video with chain-of-thought for progress failures.",
      "The two detectors run in parallel at different rates and are combined with a <b>logical OR</b>."
    ],
    blueprint: {
      headline: "Sentinel: fast consistency check, slow video judge",
      note: "At every policy call the Diffusion Policy is sampled B times. STAC compares the h − k overlapping steps with the previous call's batch and accumulates the distance; the VLM, queried much less often, reads the video so far. Either detector can stop the robot.",
      towers: [
        { mod: "policy", title: "Diffusion Policy", sub: "PointNet encoder + 1-D U-Net", compact: true,
          input: { label: "Point cloud + EE state", caption: "Tₒ = 2 observations" },
          rows: [
            { t: "conv", label: "PointNet encoder", call: ["Hidden 128, 4 layers, kNN 8", "c1", "c2"] },
            { t: "conv", label: "Cond. 1-D U-Net, DDPM", call: ["100 training timesteps, ε-prediction", "c1"] },
            { t: "linear", label: "Sample B chunks of h", call: ["h = 16 in all domains", "p3"] } ],
          output: { label: "B action chunks at t" } },
        { mod: "stac", title: "STAC", sub: "statistical temporal action consistency",
          input: { label: "Batches at t and t + k", caption: "overlap a_{t+k : t+h−1}" },
          rows: [
            { t: "linear", label: "Drop gripper, keep overlap", call: ["h − k overlapping steps", "p1", "p3"] },
            { t: "linear", label: "Distance D̂(π̄ₜ, π̃ₜ₊ₖ)", call: ["MMD with RBF, or KL via KDE", "p3"],
              zoom: { k: "rows", title: "MMD estimate", rows: ["B samples from π̄ₜ", "B samples from π̃ₜ₊ₖ", "RBF kernel k(x, y)", "E[k(a,a′)] + E[k(b,b′)] − 2E[k(a,b)]", "bandwidth: median heuristic"] } },
            { t: "pool", label: "Cumulative sum ηₜ", call: ["Catches jitter and repeated switching", "p1"] },
            { t: "linear", label: "Alarm if ηₜ > γ", call: ["γ = 95th pct of success scores", "p4"] } ],
          output: { label: "erratic-failure alarm (fast)" } },
        { mod: "vlm", title: "VLM monitor", sub: "video QA with chain of thought", compact: true,
          input: { label: "Video I₀:ₜ + task", caption: "every ν·k steps, ν ∈ {1, 2}" },
          rows: [
            { t: "attn", label: "GPT-4o / Claude / Gemini", call: ["Closed models; sizes not disclosed", "p2"] },
            { t: "linear", label: "CoT → ok / failure", call: ["Given elapsed time and limit H", "p2"],
              zoom: { k: "rows", title: "Video QA prompt", rows: ["role: runtime monitor", "task description", "video so far", "elapsed time / time limit", "reason, then ok or failure"] } } ],
          output: { label: "progress-failure alarm (slow)" } }
      ],
      links: [
        { from: "policy", to: "stac", toRow: "input", label: "B chunks per call" }
      ]
    },
    modules: [
      { id: "policy", role: "action-head", roleLabel: "Policy (frozen)", name: "Diffusion Policy", sub: "PointNet 128 · U-Net", col: 0, frozen: true, short: "DP" },
      { id: "stac", role: "critic", roleLabel: "Consistency detector", name: "STAC", sub: "MMD / KL on overlaps", col: 1, frozen: false, main: true, short: "STAC",
        stack: { rows: [
          { t: "in", label: "B chunks at t and at t + k", dims: "B × (h − k) × |A|", c: "data-3" },
          { t: "linear", label: "keep overlapping steps, drop gripper" },
          { t: "linear", label: "empirical MMD (RBF) or KL (KDE)", dims: "D̂ ≥ 0" },
          { t: "pool", label: "ηₜ = Σ D̂ over the rollout" },
          { t: "out", label: "alarm if ηₜ > γ", c: "data-8" } ],
          facts: [["Batch B", ["256 (PushT, Push Chair), 32 (Close Box, Cover Object)", "p3"]], ["MMD bandwidth", ["median heuristic, or 1/|A|", "p3"]], ["Horizons", ["h = 16; k = 8 (PushT), 4 (mobile)", "p3"]], ["Calibration", ["95th percentile over M = 50 successes", "p4"]], ["Close Box accuracy", ["STAC MMD 0.96 combined ID + OOD", "p4"]]] } },
      { id: "vlm", role: "critic", roleLabel: "Progress monitor", name: "GPT-4o video QA", sub: "closed VLM", col: 2, frozen: true, short: "VLM" }
    ],
    inputs: [
      { to: "policy", mod: "vision", label: "point clouds", n: "Tₒ = 2", k: 4 },
      { to: "vlm", mod: "vision", label: "rollout video", n: "every ν·k steps", k: 5 }
    ],
    outputs: [
      { from: "policy", mod: "action", label: "executed k actions", n: "of h = 16", k: 3 },
      { from: "vlm", mod: "other", label: "ok / failure", n: "OR with STAC", k: 1 }
    ],
    links: [
      { from: "policy", to: "stac", kind: "feeds", label: "B samples|per call" },
      { from: "stac", to: "vlm", kind: "feeds", label: "logical OR|(parallel)" }
    ],
    callouts: [
      "Combining the two detectors catches <b>18%</b> more failures than either alone (abstract); in Close Box Sentinel reaches TPR 1.00 in and out of distribution (Table 1).",
      "FAIL-Detect later dropped STAC on hardware because sampling 256 chunks per step was too slow."
    ]
  });

  /* ---------- GVL ---------- */
  RB.arch.spec({
    id: "gvl", method: "gvl", name: "GVL", year: 2024,
    figRef: "Ma et al. Fig. 2 · §3 · App. A", prov: "",
    lede: "A frozen long-context VLM used as a universal value function. The first frame anchors 0 %; the other frames are shuffled, and the VLM writes a description and a completion percentage for each, autoregressively. No training and no released weights.",
    sources: {
      p1: P("Ma et al. 2024, §3 (GVL: autoregression, shuffling, in-context)", "2411.04549"),
      p2: P("Ma et al. 2024, §4 and Eq. (5) (VOC)", "2411.04549"),
      p3: P("Ma et al. 2024, §4.2–4.3 (in-context, success detection)", "2411.04549"),
      p4: P("Ma et al. 2024, App. A (prompt) and App. D (GPT-4o)", "2411.04549")
    },
    summary: {
      pattern: ["Learned verifier / failure detector (zero-shot VLM value function)", "p1"],
      params: "not disclosed",
      vision: ["Video subsampled to 30 frames; first frame kept in order as the 0 % anchor", "p1"],
      backbone: ["Gemini-1.5-Pro, frozen; GPT-4o also works", "p2", "p4"],
      head: ["Text: “Frame i: description, task completion %”", "p4"],
      output: ["Value vᵢ ∈ [0, 100] per shuffled frame", "p1"],
      attention: "not disclosed",
      cond: ["Task description; optional in-context shuffled examples with true values", "p1", "p3"],
      steps: ["One autoregressive generation per video", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["None: zero-shot, or few-shot in context (up to 5 videos, 150 images)", "p3"]
    },
    blueprint: {
      headline: "GVL: unshuffle the video, read progress",
      note: "Nothing is trained. The video is subsampled and shuffled (except the first frame), the VLM predicts a percentage for every frame in one autoregressive pass, and the rank correlation between predicted values and true order (VOC) scores the trajectory.",
      towers: [
        { mod: "prep", title: "Frame preparation", sub: "no learned weights", compact: true,
          input: { label: "Robot video", caption: "any dataset, any embodiment" },
          rows: [
            { t: "pool", label: "Subsample to 30 frames", call: ["30 frames per video", "p1"] },
            { t: "linear", label: "Shuffle, keep frame 1 first", call: ["Breaks the monotonic shortcut", "p1"] } ],
          output: { label: "anchor + shuffled frames" } },
        { mod: "vlm", title: "Gemini-1.5-Pro (frozen)", sub: "long-context VLM, closed",
          input: { label: "Prompt + frames", caption: "task, anchor at 0 %, shuffled frames" },
          rows: [
            { t: "embed", label: "Interleaved image + text tokens", call: ["Architecture not disclosed", "p2"] },
            { t: "attn", label: "VLM decoder (closed)", call: ["Weights and sizes not disclosed", "p2"] },
            { t: "linear", label: "Per frame: text, then %", call: ["Autoregressive: sees its earlier values", "p1", "p4"],
              zoom: { k: "rows", title: "GVL prompt", rows: ["“expert roboticist … task”", "initial scene: 0 %", "frames in random order", "Frame i: description", "Task completion: v %"] } } ],
          output: { label: "v₁ … v₃₀ (shuffled order)" } },
        { mod: "voc", title: "VOC / success detector", sub: "rank correlation", compact: true,
          input: { label: "Values + true order", caption: "undo the shuffle" },
          rows: [
            { t: "linear", label: "VOC = rank-corr(v, time)", call: ["Range −1 to 1", "p2"] },
            { t: "linear", label: "Success if VOC > 0.5", call: ["GVL-SD default threshold", "p3"] } ],
          output: { label: "value curve, quality, success" } }
      ],
      links: [
        { from: "prep", to: "vlm", toRow: "input", label: "shuffled frames" },
        { from: "vlm", to: "voc", toRow: "input", label: "per-frame %" }
      ]
    },
    modules: [
      { id: "prep", role: "net", roleLabel: "Pre-processing", name: "Subsample + shuffle", sub: "anchor frame fixed", col: 0, frozen: true, short: "Shuffle" },
      { id: "vlm", role: "vlm", roleLabel: "VLM value function", name: "Gemini-1.5-Pro", sub: "frozen, closed", col: 1, frozen: true, main: true, short: "Gemini",
        stack: { rows: [
          { t: "in", label: "task + anchor frame + shuffled frames", c: "data-1" },
          { t: "attn", label: "closed VLM", dims: "not disclosed" },
          { t: "out", label: "per-frame description and %", c: "data-8" } ],
          facts: [["VLM", ["Gemini-1.5-Pro; GPT-4o as an alternative backbone", "p2", "p4"]], ["Frames", ["30 per video", "p1"]], ["In-context", ["up to 5 example videos (150 images)", "p3"]], ["Weights", ["none released: prompting method", "p1"]]] } },
      { id: "voc", role: "critic", roleLabel: "Trajectory scorer", name: "VOC", sub: "rank correlation", col: 2, frozen: true, short: "VOC" }
    ],
    inputs: [
      { to: "prep", mod: "vision", label: "robot video", n: "any length", k: 5 },
      { to: "vlm", mod: "lang", label: "task description", n: "1 sentence", k: 2 }
    ],
    outputs: [{ from: "voc", mod: "other", label: "values, VOC, success", n: "per video", k: 2 }],
    links: [
      { from: "prep", to: "vlm", kind: "prefix", label: "30 frames|(1 anchor)" },
      { from: "vlm", to: "voc", kind: "feeds", label: "completion %" }
    ],
    callouts: [
      "Without shuffling, VOC collapses to near-monotonic predictions that cannot separate successes from failures; single-frame prompting gives VOC −0.08 on RT-1 vs 0.74 for GVL (§4.4).",
      "There is no official code release: the method is a prompt around closed VLMs."
    ]
  });

  /* ---------- RECAP (π*0.6) ---------- */
  RB.arch.spec({
    id: "recap", method: "recap", name: "RECAP (π*0.6)", year: 2025, parent: "pi0-5",
    diffRows: ["params", "backbone", "head", "cond", "train"],
    figRef: "Amin et al. Fig. 3 · §IV–V · App. E–F", prov: "",
    lede: "π0.6 plus a separate value model. A 670M Gemma 3 value network predicts a distribution over 201 return bins; each training step gets a binarised advantage, written into the VLA's prompt as “Advantage: positive / negative”, so the policy learns what better actions look like.",
    sources: {
      p1: P("Physical Intelligence 2025 (π*0.6), §IV-A (value function)", "2511.14759"),
      p2: P("Physical Intelligence 2025 (π*0.6), §IV-B and Eq. (3)", "2511.14759"),
      p3: P("Physical Intelligence 2025 (π*0.6), §V-A–B (model)", "2511.14759"),
      p4: P("Physical Intelligence 2025 (π*0.6), §V-C–D and Fig. 5", "2511.14759"),
      p5: P("Physical Intelligence 2025 (π*0.6), App. E–F", "2511.14759"),
      p6: P("Physical Intelligence 2025 (π*0.6), §VI-C and Figs. 7–8", "2511.14759")
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (two-expert transformer)", "p3"],
      params: ["Gemma 3 4B VLM + 860M action expert; value model on a 670M VLM", "p3", "p4"],
      vision: ["Base camera + 2 wrist cameras", "p4"],
      backbone: ["Gemma 3 4B, Knowledge Insulation training (FAST tokens, stop-gradient)", "p3"],
      head: ["Action expert, 860M, flow matching; attends to the VLM", "p3"],
      output: ["Chunk a_{t:t+H} of joint angles + gripper at 50 Hz", "p3", "p4"],
      attention: "not disclosed",
      cond: ["Text “Advantage: positive / negative” after the subtask, before actions", "p3"],
      steps: ["β = 1 by default; CFG with β ∈ [1.5, 2.5] where useful", "p5"],
      chunk: "not disclosed",
      rate: ["50 Hz joint-position control", "p3", "p4"],
      latency: null,
      train: ["Offline-RL pre-training, then iterations of rollouts + corrections; 30 % indicator dropout", "p2", "p5"]
    },
    changes: [
      "Backbone grows from PaliGemma to <b>Gemma 3 4B</b>; the action expert grows to <b>860M</b> parameters.",
      "A separate <b>distributional value model</b> (670M Gemma 3, 201 bins) is trained on success labels.",
      "Each training example gets an <b>advantage indicator as text</b>; ε_ℓ puts about 30 % of pre-training data positive.",
      "The policy learns both p(a | o, ℓ) and p(a | I, o, ℓ), so it can be sampled with I = positive or with CFG.",
      "Training loops over <b>autonomous rollouts and human corrections</b> (corrections forced positive)."
    ],
    blueprint: {
      headline: "RECAP: a value model writes “advantage: positive”",
      note: "The value model and the VLA share a design but not weights. The value model's advantage estimate becomes one text token pair in the VLA prompt; everything else is π0.6: Gemma 3 predicts the subtask and FAST tokens, and the stop-gradient action expert generates the continuous chunk.",
      towers: [
        { mod: "value", title: "Value model", sub: "Gemma 3 init, 670M backbone", compact: true,
          input: { label: "Images + prompt", caption: "same inputs as the VLA" },
          rows: [
            { t: "attn", label: "Gemma 3 VLM, 670M", call: ["Co-trained on some web data", "p4"] },
            { t: "linear", label: "Softmax over B bins", call: ["B = 201 return bins, cross-entropy", "p1"] },
            { t: "pool", label: "V = Σ p(b) v(b)", call: ["Values normalised per task to (−1, 0)", "p4"],
              zoom: { k: "rows", title: "Advantage indicator", rows: ["r = −1 per step, −C_fail on failure", "A = Σ r over N = 50 + V(o_{t+N}) − V(oₜ)", "I = A > ε_ℓ", "ε_ℓ: ≈ 30 % positive (pre-train)", "corrections: I = positive"] } } ],
          output: { label: "advantage → I" } },
        { mod: "vlm", title: "Gemma 3 4B VLM", sub: "π0.6 backbone, KI training",
          input: { label: "Images + q + prompt + metadata", caption: "task prompt ℓ plus metadata s" },
          rows: [
            { t: "embed", label: "Image + text tokens", call: ["Layer sizes not disclosed", "p3"] },
            { t: "attn", label: "Gemma 3 decoder", call: ["4B parameters", "p3"] },
            { t: "linear", label: "Predict subtask text ℓ̂", call: ["Runs at a lower rate than actions", "p3"] },
            { id: "adv", t: "embed", label: "“Advantage: positive/negative”", side: "I", call: ["Dropped 30 % of the time (CFG)", "p5"] },
            { t: "linear", label: "FAST action tokens (KI)", call: ["Discrete actions; expert never sees them", "p3"] } ],
          output: { label: "keys / values for the expert" } },
        { mod: "expert", title: "Action expert", sub: "860M, flow matching, stop-gradient",
          input: { label: "Noisy chunk + time η", caption: "a^{η,ω} = η a + (1 − η) ω" },
          rows: [
            { t: "attn", label: "Expert attends to VLM", call: ["Gradients stopped into the VLM", "p3"] },
            { t: "linear", label: "Velocity for the chunk", call: ["Flow-matching loss, weight α_η", "p3", "p5"],
              zoom: { k: "rows", title: "Sampling with CFG", rows: ["v = v(o) + β (v(I, o) − v(o))", "β = 1: just condition on I", "β ∈ [1.5, 2.5] where useful", "large β → aggressive motion", "prefer tuning ε_ℓ instead"] } } ],
          output: { label: "joint chunk at 50 Hz" } }
      ],
      links: [
        { from: "value", to: "vlm", toRow: "adv", label: "advantage indicator I" }
      ],
      shared: []
    },
    modules: [
      { id: "value", role: "critic", roleLabel: "Value model", name: "Distributional value", sub: "670M VLM · 201 bins", col: 0, frozen: false, params: "670M backbone", short: "Value" },
      { id: "vlm", role: "vlm", name: "Gemma 3 4B", sub: "KI: FAST + subtask text", col: 1, frozen: false, main: true, params: "4B", short: "Gemma 3",
        stack: { rows: [
          { t: "in", label: "[images | state q | prompt ℓ + metadata s]", c: "data-2" },
          { t: "attn", label: "Gemma 3 4B decoder", dims: "layer sizes not disclosed" },
          { t: "linear", label: "subtask text ℓ̂", dims: "autoregressive" },
          { t: "embed", label: "“Advantage: positive / negative”", dims: "I, dropped 30 %" },
          { t: "linear", label: "FAST action tokens", dims: "KI co-training target" },
          { t: "out", label: "prefix for the action expert", c: "data-2" } ],
          facts: [["Base VLM", ["Gemma 3 4B", "p3"]], ["Training recipe", ["Knowledge Insulation: FAST tokens + stop-gradient expert", "p3"]], ["Indicator", ["text input after ℓ̂, before actions", "p3"]], ["Threshold ε_ℓ", ["≈ 30 % positive in pre-training; ≈ 40 % in fine-tuning", "p4", "p5"]], ["Results", ["throughput more than doubles on diverse laundry and espresso", "p6"]]] } },
      { id: "expert", role: "action-expert", name: "Action expert", sub: "860M · flow matching", col: 2, frozen: false, params: "860M", short: "Expert" }
    ],
    inputs: [
      { to: "value", mod: "vision", label: "images + prompt", n: "3 cameras", k: 3 },
      { to: "vlm", mod: "vision", label: "images + state", n: "3 cameras + q", k: 4 },
      { to: "expert", mod: "action", label: "noisy chunk, η", n: "H steps", k: 4, noisy: true }
    ],
    outputs: [{ from: "expert", mod: "action", label: "joint chunk", n: "50 Hz", k: 4 }],
    links: [
      { from: "value", to: "vlm", kind: "prefix", label: "“Advantage: …”|text input" },
      { from: "vlm", to: "expert", kind: "joint-attn", label: "expert attends|(stop-gradient)" }
    ],
    callouts: [
      "π0.6 and π*0.6 are <b>not open-sourced</b>; layer counts, widths and the chunk length H are not disclosed, so the blueprint stops at the module level.",
      "Advantages use an N = 50-step lookahead in post-training but full-episode returns in pre-training (App. F)."
    ]
  });

  /* ---------- World Action Verifier ---------- */
  RB.arch.spec({
    id: "world-action-verifier", method: "world-action-verifier", name: "World Action Verifier", year: 2026, parent: "dreamerv3",
    diffRows: ["pattern", "head", "output", "train"],
    figRef: "Liu et al. Fig. 1–2 · §2 · App. E.3–E.4", prov: "robomimic configs",
    lede: "A world model that checks itself. A video-trained subgoal generator proposes futures, a sparse inverse model infers the action that reaches each, and the Dreamer-v3 world model rolls that action forward; the largest mismatch is the transition to collect next.",
    sources: {
      p1: P("Liu et al. 2026, §2.2 (decomposition, sparse IDM)", "2604.01985"),
      p2: P("Liu et al. 2026, §2.3 and Alg. 1 (goal-oriented cycle)", "2604.01985"),
      p3: P("Liu et al. 2026, §4.2 (models)", "2604.01985"),
      p4: P("Liu et al. 2026, App. E.3, Table 4 (world model)", "2604.01985"),
      p5: P("Liu et al. 2026, App. E.4, Table 5 (IDM)", "2604.01985"),
      c1: C("world-action-verifier/wav_robot", "wav/configs.yaml", "e0460c9"),
      c2: C("world-action-verifier/wav_robot", "IDM/udrm/cfg/modules/encoder/st_transformer.yaml", "e0460c9"),
      c3: C("world-action-verifier/wav_robot", "IDM/udrm/cfg/model/clam.yaml", "e0460c9"),
      c4: C("world-action-verifier/wav_robot", "IDM/udrm/cfg/env/robomimic_sailor.yaml", "e0460c9"),
      c5: C("world-action-verifier/wav_robot", "IDM/udrm/cfg/model/st_vivit_clam_stm.yaml", "e0460c9")
    },
    summary: {
      pattern: ["Learned verifier / failure detector (forward–inverse cycle for a world model)", "p1", "p2"],
      params: null,
      vision: ["16 × 16 patches per frame; 64 × 64 images in the RoboMimic config", "p5", "c4", "c5"],
      backbone: ["World model: Dreamer-v3 RSSM, deter 512, stoch 32 × 32 = 1,024", "p3", "p4", "c1"],
      head: ["Sparse IDM (CLAM): space-time transformer, width 256, 3 layers, 4 heads", "p3", "c2"],
      output: ["Disagreement between subgoal and forward rollout; argmax action is executed", "p2"],
      attention: ["Space-time attention over 2 frames", "p5", "c2"],
      cond: ["Learnable mask M on state features + L1 on latent actions", "p1", "p5"],
      steps: ["3 passes per candidate: subgoal, inverse, forward", "p2"],
      chunk: null, rate: null, latency: null,
      train: ["WM: batch 16 × 32, lr 1e-4; IDM: 500,000 updates, latent action 16", "p4", "p5"]
    },
    changes: [
      "The Dreamer-v3 world model is kept; WAV adds a <b>subgoal generator</b> trained on action-free video.",
      "A <b>sparse inverse dynamics model</b> (CLAM backbone with a learnable mask and L1) infers actions to reach subgoals.",
      "The world model <b>verifies itself</b>: rollouts that disagree most with the subgoal pick the next real interaction.",
      "Used for data acquisition: 2× sample efficiency and higher downstream policy reward."
    ],
    blueprint: {
      headline: "WAV: propose a future, infer, roll forward",
      note: "Order matters: the least reliable part, the forward world model, runs last. Subgoals come from the video prior, the sparse IDM turns each into an action, and the RSSM's predicted outcome is compared with the subgoal; the action with the largest discrepancy is executed and added to the data.",
      towers: [
        { mod: "gen", title: "Subgoal generator gϕ", sub: "trained on action-free video", compact: true,
          input: { label: "Current state sₜ", caption: "state or image" },
          rows: [
            { t: "mlp", label: "Transition prior p(s′ | s)", call: ["Uses the larger action-free set", "p1"] },
            { t: "linear", label: "Sample K subgoals", call: ["Subgoal after an action chunk", "p1", "p2"] } ],
          output: { label: "K plausible futures s̃" } },
        { mod: "idm", title: "Sparse IDM hψ", sub: "CLAM space-time transformer + mask",
          input: { label: "sₜ, s̃ₜ₊₁ (masked by M)", caption: "context length 2" },
          rows: [
            { t: "embed", label: "Patchify 16 × 16", call: ["16 tokens per frame", "p5", "c5"] },
            { t: "block", n: "3", rows: [
              { t: "attn", label: "Space-time attention", call: ["Width 256, 4 heads", "c2"], zoom: { k: "heads", q: 4, kv: 4, hd: 64, title: "ST attention (encoder)" } },
              { t: "add", span: 1 },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden 2,048, dropout 0.1", "c2"], zoom: { k: "mlp", act: "GELU", d: "256", ff: "2,048", title: "Encoder MLP" } },
              { t: "add", span: 1 } ] },
            { t: "linear", label: "Latent action z (L1-sparse)", call: ["Dimension 16, sparsity weight 0.1", "p5"] },
            { t: "mlp", label: "Action decoder", call: ["Hidden [1,024, 1,024, 1,024]", "p5"],
              zoom: { k: "rows", title: "Verification cycle", rows: ["sₜ → gϕ → s̃ (K subgoals)", "s̃ → hψ → â (inverse)", "â → fθ → ŝ (forward)", "score ℓ(s̃, ŝ)", "execute argmax, update fθ, hψ"] } } ],
          output: { label: "inferred action â" } },
        { mod: "wm", title: "World model fθ", sub: "Dreamer-v3 RSSM", compact: true,
          input: { label: "sₜ + inferred â", caption: "action-conditioned" },
          rows: [
            { t: "mlp", label: "GRU deterministic state", call: ["Deterministic state 512", "c1"] },
            { t: "linear", label: "Stochastic latent", call: ["32 × 32 = 1,024 dims", "p4", "c1"] },
            { t: "conv", label: "Decoder → ŝₜ₊₁", call: ["Batch 16, length 32, lr 1e-4", "p4"] } ],
          output: { label: "predicted outcome ŝ" } }
      ],
      links: [
        { from: "gen", to: "idm", toRow: "input", label: "subgoals s̃" },
        { from: "idm", to: "wm", toRow: "input", label: "inferred â" }
      ]
    },
    modules: [
      { id: "gen", role: "video-gen", roleLabel: "Subgoal generator", name: "Video prior gϕ", sub: "action-free data", col: 0, frozen: false, short: "Subgoals" },
      { id: "idm", role: "critic", roleLabel: "Sparse inverse model", name: "Sparse IDM (CLAM)", sub: "ST-transformer 3 × 256", col: 1, frozen: false, main: true, short: "IDM",
        stack: { rows: [
          { t: "in", label: "(sₜ, s̃ₜ₊₁) masked by M", dims: "2 frames", c: "data-1" },
          { t: "embed", label: "16 × 16 patches + learned positions" },
          { t: "block", label: "space-time transformer layer", n: "3", rows: [
            { t: "attn", label: "spatial + temporal attention · 4 heads" }, { t: "add", span: 1 },
            { t: "ffn", label: "MLP 256 → 2048 → 256 · GELU" }, { t: "add", span: 1 } ] },
          { t: "linear", label: "latent action z", dims: "L1 sparsity" },
          { t: "mlp", label: "action decoder MLP", dims: "3 × 1,024" },
          { t: "out", label: "inferred action â", c: "data-3" } ],
          facts: [["Backbone", ["CLAM latent IDM + FDM + action decoder", "p3", "p5"]], ["Encoder", ["3 layers, width 256, 4 heads, FFN 2,048", "c2"]], ["Latent action", ["16 (paper)", "p5"]], ["Sparsity", ["learnable mask M; L1 weight 0.1 (paper)", "p1", "p5"]], ["Updates", ["500,000", "p5"]]] } },
      { id: "wm", role: "world", name: "Dreamer-v3 RSSM", sub: "deter 512 · 32 × 32", col: 2, frozen: false, short: "RSSM" }
    ],
    inputs: [
      { to: "gen", mod: "vision", label: "current state", n: "1 frame", k: 2 },
      { to: "idm", mod: "future", label: "subgoal s̃", n: "K candidates", k: 4 }
    ],
    outputs: [{ from: "wm", mod: "future", label: "predicted ŝ", n: "per candidate", k: 3 }],
    links: [
      { from: "gen", to: "idm", kind: "feeds", label: "K subgoals" },
      { from: "idm", to: "wm", kind: "feeds", label: "inferred actions" }
    ],
    callouts: [
      "Paper App. E.4 says each <b>256 × 256</b> image gives <b>16</b> patch tokens of 16 × 16; that count only holds at 64 × 64, which is the image size in the released RoboMimic config.",
      "Paper Table 5 uses sparsity weight <b>0.1</b> and latent action dim <b>16</b>; the released <code>clam.yaml</code> defaults <code>la_l1_weight</code> to <b>0.0</b>, and the scripts set <code>la_dim</code> to 16, 32 or 128."
    ]
  });

  /* ============================== F2 ============================== */

  /* ---------- VLSA / AEGIS ---------- */
  RB.arch.spec({
    id: "vlsa", method: "vlsa", name: "VLSA (AEGIS)", year: 2025, parent: "pi0-5",
    diffRows: ["pattern", "head", "output", "cond", "latency"],
    figRef: "Hu et al. Figs. 2–5 · §IV · §V-A", prov: "main_aegis.py",
    lede: "A plug-in safety layer after an unchanged π0.5. A VLM names the most critical obstacle, GroundingDINO and depth turn it into an ellipsoid, and a one-constraint control-barrier QP minimally edits the VLA's end-effector command so the two ellipsoids never touch.",
    sources: {
      p1: P("Hu et al. 2025, §III (CBF-QP formulation)", "2512.11891"),
      p2: P("Hu et al. 2025, §IV-B (safety assessment)", "2512.11891"),
      p3: P("Hu et al. 2025, §IV-C and Theorem 1", "2512.11891"),
      p4: P("Hu et al. 2025, §V-A (settings) and Table I", "2512.11891"),
      p5: P("Hu et al. 2025, §V-B (time complexity, Fig. 10)", "2512.11891"),
      c1: C("THU-RCSCT/vlsa-aegis", "main/main_aegis.py", "2457fee"),
      c2: C("THU-RCSCT/vlsa-aegis", "main/utils.py", "2457fee")
    },
    summary: {
      pattern: ["Safety layer", "p1"],
      params: null,
      vision: ["Agent-view RGB-D + back-view depth, fused point cloud", "p2", "c1"],
      backbone: ["π0.5-LIBERO (sim) or π0.5-DROID (real), unchanged", "p4"],
      head: ["Convex QP: min ‖u − u_vla‖² s.t. ḣ ≥ −α(h), one linear constraint", "p1", "p5"],
      output: ["Safe end-effector velocity u_safe (translation, rotation, gripper)", "p1"],
      attention: null,
      cond: ["Obstacle ellipsoid (MVEE) from GLM-4.5V + GroundingDINO + depth", "p2", "p3"],
      steps: ["α(h) = 10h; QP 0.356 ms per step on an RTX 4090", "p4", "p5", "c1"],
      chunk: null,
      rate: ["20 Hz in simulation; VLA at 15 Hz on the real Franka", "p4", "p5"],
      latency: ["Safety layer ≈ 1.86 % of the control cycle", "p5"],
      train: ["None: training-free, plug-and-play", "p1"]
    },
    changes: [
      "π0.5 is untouched; a <b>safety-constraint layer</b> sits after its action output.",
      "A <b>VLM (GLM-4.5V)</b> names the single most critical obstacle; GroundingDINO localises it.",
      "Depth back-projection, outlier removal and DBSCAN give a point cloud fitted by a <b>minimum-volume ellipsoid</b>.",
      "A <b>control-barrier QP</b> minimally modifies the command so the end-effector ellipsoid stays clear.",
      "Collision avoidance on SafeLIBERO rises from 18.7 % to 77.9 % (translational actions)."
    ],
    blueprint: {
      headline: "AEGIS: name the obstacle, fence it, filter",
      note: "Perception runs once per episode to fit the obstacle ellipsoid; the QP runs every control step. When the VLA's command keeps the barrier satisfied, the QP returns it unchanged; otherwise it returns the closest command that does.",
      towers: [
        { mod: "assess", title: "Safety assessment", sub: "VLM + open-set detector + depth",
          input: { label: "Agent-view RGB + instruction", caption: "plus depth from two views" },
          rows: [
            { t: "attn", label: "GLM-4.5V: 1 obstacle", call: ["Colour + type, from a predefined list", "p2", "p4"] },
            { t: "conv", label: "GroundingDINO: top-1 box", call: ["Swin-T OGC checkpoint", "c1"] },
            { t: "linear", label: "Back-project box pixels", call: ["Agent view + back view fused", "p2"] },
            { t: "pool", label: "Crop, drop far 20 %, DBSCAN", call: ["Keep the most populous cluster", "p2", "c2"] },
            { t: "linear", label: "Fit MVEE (c, R, Q)", call: ["min −log det Q, SDP constraints", "p3"],
              zoom: { k: "rows", title: "Obstacle to ellipsoid", rows: ["VLM: “red milk carton”", "GroundingDINO box", "pixels + depth → xyz", "filter + DBSCAN", "MVEE centre c, R, shape Q"] } } ],
          output: { label: "obstacle ellipsoid E_ob" } },
        { mod: "cbf", title: "CBF-QP safety layer", sub: "runs every control step",
          input: { label: "u_vla + both ellipsoids", caption: "EE ellipsoid rigidly attached" },
          rows: [
            { t: "linear", label: "EE ellipsoid Q_ef", call: ["diag(0.06, 0.12, 0.11) m", "p4", "c1"] },
            { t: "linear", label: "Barrier h(x): ellipsoid gap", call: ["Virtual state p_s on the unit sphere", "p3"] },
            { t: "mlp", label: "QP: min ‖u − u_vla‖²", call: ["s.t. ḣ ≥ −10 h; one linear constraint", "p4", "c1"],
              zoom: { k: "rows", title: "Safety filter", rows: ["nominal u_vla from π0.5", "h(x) ≥ 0 means no contact", "constraint ḣ ≥ −α(h), α(h) = 10h", "convex QP, 0.356 ms", "u_safe = u_vla if already safe"] } } ],
          output: { label: "u_safe" } },
        { mod: "vla", title: "π0.5 (frozen)", sub: "base VLA, unchanged", compact: true,
          input: { label: "Images + instruction", caption: "LIBERO or DROID checkpoint" },
          rows: [{ t: "attn", label: "π0.5 VLA", call: ["VLA inference ≈ 87 % of cycle time", "p5"] }],
          output: { label: "nominal u_vla" } }
      ],
      links: [
        { from: "assess", to: "cbf", toRow: "input", label: "E_ob" },
        { from: "vla", to: "cbf", toRow: "input", label: "nominal action" }
      ]
    },
    modules: [
      { id: "assess", role: "vision-enc", roleLabel: "Safety assessment", name: "GLM-4.5V + DINO", sub: "obstacle → ellipsoid", col: 0, frozen: true, short: "Assess" },
      { id: "cbf", role: "critic", roleLabel: "Safety layer", name: "CBF-QP filter", sub: "1 constraint · 0.36 ms", col: 1, frozen: true, main: true, short: "CBF-QP",
        stack: { rows: [
          { t: "in", label: "u_vla, E_ef(pose), E_ob", c: "data-3" },
          { t: "linear", label: "h(x): distance from E_ob to tangent plane of E_ef" },
          { t: "linear", label: "linearise ḣ in u" },
          { t: "mlp", label: "QP: min ‖u − u_vla‖² s.t. ḣ ≥ −α h" },
          { t: "out", label: "u_safe", dims: "EE velocity + gripper", c: "data-3" } ],
          facts: [["Class-K function", ["α(h) = 10h, reference gain k = 10", "p4", "c1"]], ["EE ellipsoid", ["Q_ef = diag(0.06, 0.12, 0.11) m", "p4", "c1"]], ["Dynamics", ["ṗ = 0.2u (and θ̇ = 0.2u₄:₆ in full space)", "p4"]], ["Cost", ["0.356 ms per step, ≈ 1.86 % of the cycle", "p5"]], ["Guarantee", ["no EE contact if perception encloses the obstacle", "p3"]]] } },
      { id: "vla", role: "vlm", roleLabel: "Base VLA (frozen)", name: "π0.5", sub: "LIBERO / DROID", col: 2, frozen: true, short: "π0.5" }
    ],
    inputs: [
      { to: "assess", mod: "vision", label: "RGB-D, 2 views", n: "once per episode", k: 4 },
      { to: "assess", mod: "lang", label: "instruction", n: "task text", k: 2 },
      { to: "vla", mod: "vision", label: "images + prompt", n: "each step", k: 3 }
    ],
    outputs: [{ from: "cbf", mod: "action", label: "safe action", n: "20 Hz", k: 2 }],
    links: [
      { from: "assess", to: "cbf", kind: "feeds", label: "obstacle|ellipsoid" },
      { from: "vla", to: "cbf", kind: "feeds", label: "nominal u_vla" }
    ],
    callouts: [
      "The paper's method is <b>AEGIS</b>; <b>VLSA</b> names the architecture class (VLA + safety-constraint layer).",
      "Residual collisions come from perception (wrong obstacle, grounding, filtering) and from arm links, which the end-effector-only barrier does not cover (§V-C). The code enlarges the EE ellipsoid height to 0.2 m for tall objects."
    ]
  });

  /* ---------- SafeVLA ---------- */
  RB.arch.spec({
    id: "safevla", method: "safevla", name: "SafeVLA", year: 2025,
    figRef: "Zhang et al. §3–5 · App. C, Table 12", prov: "DINOv2 SPOC variant",
    lede: "SPOC, a transformer VLA trained on simulated homes, fine-tuned with PPO-Lagrangian. A cost critic next to the reward critic and a learned multiplier λ trade task success against five kinds of safety violation.",
    sources: {
      p1: P("Zhang et al. 2025, §3 (CMDP) and App. C.1 (losses)", "2503.03480"),
      p2: P("Zhang et al. 2025, App. C.2, Table 12", "2503.03480"),
      p3: P("Zhang et al. 2025, App. C.3 (SPOC architecture)", "2503.03480"),
      p4: P("Zhang et al. 2025, §5.1–5.2 and App. E.1", "2503.03480"),
      c1: C("PKU-Alignment/SafeVLA", "architecture/models/allenact_transformer_models/allenact_dino_transformer.py", "2aa8255"),
      c2: C("PKU-Alignment/SafeVLA", "training/online/loss/customized_loss.py", "2aa8255"),
      c3: C("PKU-Alignment/SafeVLA", "training/online/dinov2_vits_tsfm_base.py", "2aa8255")
    },
    summary: {
      pattern: ["Actor–critic (safe RL fine-tuning of a transformer VLA)", "p1"],
      params: null,
      vision: ["Two 384 × 224 RGB cameras (navigation, manipulation) → DINOv2 ViT-S/14", "p4", "c3"],
      backbone: ["Goal-conditioned transformer encoder: 3 layers, width 512, 8 heads", "p2", "c1"],
      head: ["Causal transformer decoder: 3 layers, 512, 8 heads, 100-step context", "p2", "p3"],
      output: ["Logits over 20 discrete actions + reward and cost values", "p4", "c2"],
      attention: ["Encoder: full over [visual tokens ‖ goal ‖ fusion token]; decoder: causal over time", "p3", "c1"],
      cond: ["Text goal → encoder tokens (SigLIP in the paper, T5-small in code)", "p3", "c1"],
      steps: ["One forward pass per step; PPO with 128 steps per update", "p2"],
      chunk: ["One action per step", "p4"],
      rate: null, latency: null,
      train: ["PPO-Lagrangian, lr 2e-5, λ₀ 0.001, λ lr 0.035; 15M or 25M steps", "p2", "p4"]
    },
    blueprint: {
      headline: "SafeVLA: SPOC plus a cost critic",
      note: "Per step, DINOv2 patch features of both cameras and the goal text are fused by a small transformer encoder into one token; a causal decoder reads the last 100 fused tokens and outputs action logits. PPO-Lagrangian adds a cost critic and a multiplier λ that grows whenever episode cost exceeds the limit.",
      towers: [
        { mod: "enc", title: "Goal-conditioned encoder", sub: "DINOv2 ViT-S/14 + 3-layer fusion",
          input: { label: "2 camera images + goal", caption: "384 × 224 each" },
          rows: [
            { t: "conv", label: "DINOv2 ViT-S/14 (frozen)", call: ["Preprocessor: dinov2_vits14", "c3"] },
            { t: "conv", label: "1×1 conv compressor → 512" },
            { t: "embed", label: "+ camera tokens, goal tokens", call: ["Goal via text encoder + Linear 512", "c1"] },
            { t: "block", n: "3", rows: [
              { t: "attn", label: "Self-attention", call: ["Width 512, 8 heads", "p2", "c1"] },
              { t: "add", span: 1 },
              { t: "ffn", label: "Feed forward" },
              { t: "add", span: 1 } ] },
            { t: "pool", label: "Fusion token output" } ],
          output: { label: "one 512-d token per step" } },
        { mod: "dec", title: "Causal decoder (actor)", sub: "Llama-style, 100-step window",
          input: { label: "Fused tokens over time", caption: "last 100 steps" },
          rows: [
            { t: "block", n: "3", rows: [
              { t: "norm", label: "RMSNorm" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["Width 512, 8 heads", "p2", "c1"], zoom: { k: "heads", q: 8, kv: 8, hd: 64, title: "Decoder attention" } },
              { t: "add", span: 2 },
              { t: "ffn", label: "Feed forward (SwiGLU)" },
              { t: "add", span: 1 } ] },
            { t: "linear", label: "Action logits", call: ["20 discrete base and arm actions", "p4"] } ],
          output: { label: "π(a | history)" } },
        { mod: "critic", title: "Reward + cost critics", sub: "PPO-Lagrangian", compact: true,
          input: { label: "Decoder belief", caption: "same hidden state as the actor" },
          rows: [
            { t: "linear", label: "V_r and V_c heads", call: ["Advantages Âʳ and Âᶜ (GAE λ 0.95)", "p1", "p2"] },
            { t: "linear", label: "Loss (L_R − λ L_C)/(1 + λ)", call: ["λ ← λ + α (J_C − b)", "p1", "c2"],
              zoom: { k: "rows", title: "Lagrangian update", rows: ["cost cₜ = Σ of 5 constraint costs", "limit b = 20 % of FLaRe cost", "λ grows if J_C > b", "policy loss / (1 + λ)", "clip 0.1, γ 0.99"] } } ],
          output: { label: "values → PPO update" } }
      ],
      links: [
        { from: "enc", to: "dec", toRow: "input", label: "fused token" },
        { from: "dec", to: "critic", toRow: "input", label: "belief" }
      ]
    },
    modules: [
      { id: "text", role: "lang", name: "Goal text encoder", sub: "T5-small (code)", col: 0, frozen: true, short: "Text" },
      { id: "enc", role: "fusion", name: "DINOv2 + fusion encoder", sub: "3 × 512 · 8 heads", col: 1, frozen: "partial", short: "Encoder" },
      { id: "dec", role: "action-head", roleLabel: "Actor (decoder)", name: "Causal decoder", sub: "3 × 512 · 100 steps", col: 2, frozen: false, main: true, short: "Decoder",
        stack: { rows: [
          { t: "in", label: "fused tokens of the last 100 steps", c: "data-6" },
          { t: "block", label: "Llama-style decoder layer", n: "3", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "causal MHA · 8 heads · width 512" }, { t: "add", span: 2 },
            { t: "ffn", label: "feed forward" }, { t: "add", span: 1 } ] },
          { t: "linear", label: "actor head", dims: "20 actions" },
          { t: "out", label: "action distribution", c: "data-3" } ],
          facts: [["Decoder", ["3 layers, 512 hidden, 8 heads", "p2", "c1"]], ["Context", ["100 steps", "p3"]], ["Action space", ["20 discrete actions", "p4"]], ["Critic", ["linear value head on the belief; separate cost advantage", "c1", "c2"]], ["Result", ["cumulative cost −83.58 % vs FLaRe, success +3.85 %", "p4"]]] } },
      { id: "critic", role: "critic", name: "Reward + cost critics", sub: "PPO-Lagrangian", col: 3, frozen: false, short: "Critics" }
    ],
    inputs: [
      { to: "text", mod: "lang", label: "goal text", n: "1 instruction", k: 2 },
      { to: "enc", mod: "vision", label: "2 RGB cameras", n: "384 × 224", k: 4 }
    ],
    outputs: [
      { from: "dec", mod: "action", label: "discrete action", n: "1 of 20", k: 1 },
      { from: "critic", mod: "other", label: "V_r, V_c", n: "per step", k: 2 }
    ],
    links: [
      { from: "text", to: "enc", kind: "prefix", label: "goal tokens" },
      { from: "enc", to: "dec", kind: "feeds", label: "1 token / step" },
      { from: "dec", to: "critic", kind: "feeds", label: "belief" }
    ],
    mask: { name: "Causal over time (decoder)", ref: "p3", axes: [{ label: "step t − 2", short: "t−2", mod: "vision" }, { label: "step t − 1", short: "t−1", mod: "vision" }, { label: "step t", short: "t", mod: "vision" }], m: ["100", "110", "111"],
      note: "Each step's fused token attends to earlier steps only, up to a 100-step window." },
    callouts: [
      "Paper App. C.3 describes a pretrained <b>SigLIP</b> text encoder for goals; the released DINOv2 model builds a <b>T5-small</b> encoder (<code>t5-small</code>, 512-d) with a Linear + LayerNorm adapter.",
      "The cost limit is set to 20 % of FLaRe's converged cost; 10 % lowers cost further but costs success rate (Fig. 7)."
    ]
  });

  /* ---------- SafeDreamer ---------- */
  RB.arch.spec({
    id: "safedreamer", method: "safedreamer", name: "SafeDreamer", year: 2023, parent: "dreamerv3",
    diffRows: ["head", "output", "cond", "steps", "train"],
    figRef: "Huang et al. Fig. 1–2 · §4–5 · App. B, Table 2", prov: "bsrp_lag / osrp_lag vision configs",
    lede: "DreamerV3 with a cost. The RSSM gains a cost decoder and a cost critic; actions come from a constrained cross-entropy planner in latent space (OSRP) or from an actor trained on imagined rollouts with an augmented Lagrangian (BSRP-Lag).",
    sources: {
      p1: P("Huang et al. 2024, §4.1 (components)", "2307.07176"),
      p2: P("Huang et al. 2024, §4.2 and Alg. 1 (OSRP, CCEM)", "2307.07176"),
      p3: P("Huang et al. 2024, §4.3 (PID / augmented Lagrangian)", "2307.07176"),
      p4: P("Huang et al. 2024, App. B, Table 2", "2307.07176"),
      p5: P("Huang et al. 2024, §6 and Fig. 3", "2307.07176"),
      c1: C("PKU-Alignment/SafeDreamer", "SafeDreamer/configs.yaml", "529221f")
    },
    summary: {
      pattern: ["RSSM world model", "p1"],
      params: null,
      vision: ["Image observations, CNN encoder depth 32 (vision configs)", "p5", "c1"],
      backbone: ["RSSM: GRU deter 512, 48 latents × 48 classes", "p4", "c1"],
      head: ["Decoders for image, reward and cost; reward and cost critics", "p1", "c1"],
      output: ["Action from the safe actor (BSRP-Lag) or CCEM planner (OSRP)", "p2", "p3"],
      attention: null,
      cond: ["Cost return vs limit b = 2.0; PID or augmented Lagrangian multiplier", "p3", "p4", "c1"],
      steps: ["CCEM: horizon 15, 500 samples, 50 elites, 6 iterations", "p4", "c1"],
      chunk: null, rate: null, latency: null,
      train: ["Batch 64 × 16, world model lr 1e-4, actor-critic lr 3e-5, γ 0.997", "p4"]
    },
    changes: [
      "The RSSM gets a <b>cost decoder</b> and the agent a <b>cost critic</b>, trained like the reward pair.",
      "<b>OSRP</b> plans online with a constrained cross-entropy method: keep trajectories under the cost limit, then rank by reward.",
      "<b>BSRP-Lag</b> trains the actor on imagined rollouts with an augmented-Lagrangian cost penalty.",
      "Latent state is 48 × 48 instead of 32 × 32; larger latents lower cost in ablation (Fig. 23)."
    ],
    blueprint: {
      headline: "SafeDreamer: DreamerV3 that also predicts cost",
      note: "The world model is DreamerV3's RSSM with one more head. Every imagined state predicts reward and cost; the planner or actor uses both returns, and a Lagrange multiplier updated from real episode cost keeps the cost return under the limit.",
      towers: [
        { mod: "rssm", title: "RSSM world model", sub: "DreamerV3, vision config",
          input: { label: "Image oₜ", caption: "Safety-Gymnasium, action repeat 4" },
          rows: [
            { t: "conv", label: "CNN encoder (depth 32)" },
            { t: "linear", label: "Posterior zₜ", call: ["48 latents × 48 classes", "p4", "c1"] },
            { t: "mlp", label: "GRU sequence model hₜ", call: ["Deterministic state 512", "c1"] },
            { t: "linear", label: "Prior ẑₜ₊₁ from hₜ", call: ["KL weights 0.1 / 0.5", "p4"] } ],
          output: { label: "model state sₜ = {hₜ, zₜ}" } },
        { mod: "heads", title: "Decoders + critics", sub: "on sₜ = [h ‖ z]", compact: true,
          input: { label: "Model state sₜ", caption: "real or imagined" },
          rows: [
            { t: "conv", label: "Image decoder" },
            { t: "mlp", label: "Reward + cost decoders", call: ["255 symlog bins each", "c1"] },
            { t: "mlp", label: "Reward + cost critics", call: ["TD(λ) with λ 0.95, γ 0.997", "p4"],
              zoom: { k: "rows", title: "Cost return C^λ", rows: ["imagine H = 15 steps", "cost C(sₜ) each step", "bootstrap with V_c at H", "C^λ = C + γ((1−λ)V_c + λC^λ)", "compare with limit b"] } } ],
          output: { label: "R^λ, C^λ per trajectory" } },
        { mod: "plan", title: "Safe planner / actor", sub: "OSRP (CCEM) or BSRP-Lag", compact: true,
          input: { label: "Imagined trajectories", caption: "from the current sₜ" },
          rows: [
            { t: "linear", label: "Sample 500 action sequences", call: ["Horizon 15, 6 CEM iterations", "p4", "c1"] },
            { t: "linear", label: "Keep safe set, rank, top-k", call: ["50 elites refit μ, σ", "p2", "c1"],
              zoom: { k: "rows", title: "Constrained CEM", rows: ["sample N from N(μ, σ²)", "safe if (J_C,H / H)·L < b", "too few safe: rank by −cost", "else rank by R − λ_p C", "refit μ, σ on elites"] } },
            { t: "linear", label: "PID Lagrangian λ_p", call: ["K_p 0.1, K_i 0.01, K_d 0.01", "p4", "c1"] } ],
          output: { label: "first action aₜ" } }
      ],
      links: [
        { from: "rssm", to: "heads", toRow: "input", label: "model state" },
        { from: "heads", to: "plan", toRow: "input", label: "reward + cost returns" }
      ]
    },
    modules: [
      { id: "rssm", role: "world", name: "RSSM (DreamerV3)", sub: "GRU 512 · 48 × 48", col: 0, frozen: false, main: true, short: "RSSM",
        stack: { rows: [
          { t: "in", label: "image oₜ, previous action", c: "data-1" },
          { t: "conv", label: "CNN encoder, depth 32" },
          { t: "linear", label: "posterior zₜ ~ E(zₜ | hₜ, oₜ)", dims: "48 × 48 categorical" },
          { t: "mlp", label: "GRU: hₜ = S(hₜ₋₁, zₜ₋₁, aₜ₋₁)", dims: "512" },
          { t: "linear", label: "prior ẑₜ from hₜ" },
          { t: "out", label: "sₜ = [hₜ ‖ zₜ]", c: "data-7" } ],
          facts: [["Latents", ["48 × 48 (paper and vision configs)", "p4", "c1"]], ["GRU state", ["512", "c1"]], ["Batch", ["64 sequences × length 16", "p4"]], ["Loss weights", ["KL 0.1 / 0.5; decoders 1.0 each", "p4"]], ["Cost limit", ["2.0 in vision tasks", "p4", "c1"]]] } },
      { id: "heads", role: "critic", name: "Reward + cost heads", sub: "decoders + critics", col: 1, frozen: false, short: "Heads" },
      { id: "plan", role: "planner", roleLabel: "Safe planner / actor", name: "CCEM or safe actor", sub: "H 15 · 500 samples", col: 2, frozen: false, short: "Planner" }
    ],
    inputs: [
      { to: "rssm", mod: "vision", label: "image", n: "vision-only tasks", k: 4 },
      { to: "rssm", mod: "action", label: "previous action", n: "1", k: 1 }
    ],
    outputs: [{ from: "plan", mod: "action", label: "action aₜ", n: "repeat 4", k: 1 }],
    links: [
      { from: "rssm", to: "heads", kind: "latent", label: "sₜ = [h ‖ z]" },
      { from: "heads", to: "plan", kind: "feeds", label: "R^λ, C^λ" }
    ],
    callouts: [
      "Paper Table 2 lists <b>5 MLP layers × 512 units</b> for the other networks; the released vision configs set heads and critics to <b>2 layers × 512</b> and keep 5 × 1,024 only for the encoder / decoder MLPs.",
      "BSRP-Lag reaches rewards similar to LAMBDA with <b>94.3 %</b> lower cost on the five vision tasks (§6)."
    ]
  });

  /* ---------- BYOVLA ---------- */
  RB.arch.spec({
    id: "byovla", method: "byovla", name: "BYOVLA", year: 2024, parent: "octo",
    diffRows: ["pattern", "vision", "cond", "train"],
    figRef: "Hancock et al. Fig. 1 · §III · App. C", prov: "byovla.py (Octo)",
    lede: "A run-time image editor in front of any VLA. A VLM lists task-irrelevant regions, Grounded-SAM2 masks them, a sensitivity probe perturbs each and measures how far the VLA's actions move, and only regions the VLA is sensitive to are inpainted or recoloured.",
    sources: {
      p1: P("Hancock et al. 2024, §III-B and Alg. 1", "2410.01971"),
      p2: P("Hancock et al. 2024, §III-B Eq. (2) and thresholds", "2410.01971"),
      p3: P("Hancock et al. 2024, §IV (setup, run-time, results)", "2410.01971"),
      p4: P("Hancock et al. 2024, App. C (hyperparameters)", "2410.01971"),
      c1: C("irom-lab/byovla", "byovla.py", "5923a80")
    },
    summary: {
      pattern: ["Safety layer (run-time observation intervention)", "p1"],
      params: ["No trainable parameters; Octo-Base 93M or OpenVLA 7B underneath", "p3"],
      vision: ["Edited image ρ(oₜ) replaces the raw camera image", "p1"],
      backbone: ["Octo-Base or OpenVLA, weights untouched", "p3"],
      head: null,
      output: ["Action chunk from the unchanged VLA on the edited image", "p1"],
      attention: null,
      cond: ["Sensitivity Δ ≥ τ: τ = 2 mm (objects), 1 mm (backgrounds)", "p2", "p3"],
      steps: ["K = 5 samples (Octo), K = 1 (OpenVLA); probe at t = 0", "p3"],
      chunk: ["Octo Tₐ = 3", "p3"],
      rate: ["Octo 13 Hz, OpenVLA 6 Hz before editing", "p3"],
      latency: ["VLM query < 3 s once; probe + edit ≈ 2 s (Octo, objects)", "p3"],
      train: ["None", "p1"]
    },
    changes: [
      "Octo's weights are untouched: BYOVLA only <b>edits the image</b> it receives.",
      "A <b>VLM</b> lists task-irrelevant regions; <b>Grounded-SAM2</b> turns them into masks.",
      "A <b>visual sensitivity probe</b> blurs or noises each region and measures the action change with Eq. (2).",
      "Sensitive regions are <b>inpainted</b> (objects, Inpaint Anything) or <b>recoloured</b> (backgrounds)."
    ],
    blueprint: {
      headline: "BYOVLA: edit what the VLA wrongly watches",
      note: "Four frozen models in a pipeline. The VLM and segmenter decide what is irrelevant; the probe asks the VLA itself which of those regions change its actions; only those are edited before the VLA acts. In static scenes the probe runs once at the start.",
      towers: [
        { mod: "vlm", title: "VLM region proposer", sub: "GPT-4o, 5 few-shot examples", compact: true,
          input: { label: "First image + instruction", caption: "queried once per episode" },
          rows: [{ t: "attn", label: "List task-irrelevant regions", call: ["< 3 s, < 1 cent per query", "p3"] }],
          output: { label: "region names" } },
        { mod: "seg", title: "Grounded-SAM2", sub: "text → pixel masks", compact: true,
          input: { label: "Region names + image", caption: "every step" },
          rows: [{ t: "conv", label: "Grounded segmentation", call: ["Box and text thresholds 0.4", "p4", "c1"] }],
          output: { label: "masks per region" } },
        { mod: "probe", title: "Sensitivity probe + editor", sub: "queries the VLA itself",
          input: { label: "Image + masks", caption: "one region at a time" },
          rows: [
            { t: "conv", label: "Perturb region r", call: ["Blur kernel 25 (objects); noise std √0.075", "p3"] },
            { t: "linear", label: "Sample K chunks, both images", call: ["K = 5 (Octo), 1 (OpenVLA)", "p3"] },
            { t: "linear", label: "Δ = weighted L2 of Δa", call: ["w = translational components only", "p2", "p3"],
              zoom: { k: "rows", title: "Sensitivity Δ_f(oₜ, r)", rows: ["K chunks on oₜ", "K chunks on perturbed õₜ", "Δa per step", "mean of √(wΔa · Δa)", "edit r if Δ ≥ τ"] } },
            { t: "conv", label: "Inpaint or recolour r", call: ["Inpaint Anything, mask dilation 10", "p1", "p4"] } ],
          output: { label: "edited image ρ(oₜ)" } },
        { mod: "vla", title: "Octo-Base (frozen)", sub: "any VLA works", compact: true,
          input: { label: "Edited image + instruction", caption: "weights untouched" },
          rows: [{ t: "attn", label: "Octo-Base transformer", call: ["93M parameters", "p3"] }],
          output: { label: "action chunk" } }
      ],
      links: [
        { from: "vlm", to: "seg", toRow: "input", label: "region names" },
        { from: "seg", to: "probe", toRow: "input", label: "masks" },
        { from: "probe", to: "vla", toRow: "input", label: "edited image" }
      ]
    },
    modules: [
      { id: "vlm", role: "vlm", roleLabel: "Region proposer", name: "GPT-4o", sub: "few-shot, once", col: 0, frozen: true, short: "VLM" },
      { id: "seg", role: "vision-enc", roleLabel: "Segmenter", name: "Grounded-SAM2", sub: "thresholds 0.4", col: 1, frozen: true, short: "SAM2" },
      { id: "probe", role: "critic", roleLabel: "Sensitivity probe", name: "Probe + editor", sub: "τ = 2 mm / 1 mm", col: 2, frozen: true, main: true, short: "Probe",
        stack: { rows: [
          { t: "in", label: "image oₜ + region masks", c: "data-1" },
          { t: "conv", label: "perturb one region (blur or noise)" },
          { t: "linear", label: "query the VLA K times on both images" },
          { t: "linear", label: "Δ_f(oₜ, r): weighted L2 action change" },
          { t: "conv", label: "inpaint / recolour regions with Δ ≥ τ" },
          { t: "out", label: "edited image ρ(oₜ)", c: "data-1" } ],
          facts: [["Thresholds", ["τ = 2 mm objects, 1 mm backgrounds", "p2", "p3"]], ["Object probe", ["Gaussian blur, kernel 25", "p3"]], ["Background probe", ["Gaussian noise N(0, √0.075)", "p3"]], ["Samples", ["K = 5 (Octo), K = 1 (OpenVLA)", "p3"]], ["Editor", ["Inpaint Anything, dilation 10", "p4"]]] } },
      { id: "vla", role: "vlm", roleLabel: "VLA (frozen)", name: "Octo-Base", sub: "or OpenVLA", col: 3, frozen: true, params: "93M", short: "Octo" }
    ],
    inputs: [
      { to: "vlm", mod: "vision", label: "first frame + task", n: "once", k: 2 },
      { to: "seg", mod: "vision", label: "camera image", n: "each step", k: 3 }
    ],
    outputs: [{ from: "vla", mod: "action", label: "action chunk", n: "Tₐ = 3", k: 3 }],
    links: [
      { from: "vlm", to: "seg", kind: "feeds", label: "region names" },
      { from: "seg", to: "probe", kind: "feeds", label: "masks" },
      { from: "probe", to: "vla", kind: "feeds", label: "edited image" }
    ],
    callouts: [
      "The paper queries <b>GPT-4o</b>; the released <code>byovla.py</code> calls <b>gpt-4o-mini</b>.",
      "Distractors cut Octo's and OpenVLA's success by up to <b>40 %</b>; BYOVLA recovers most of it, while inpainting every irrelevant region (no probe) does worse (§IV)."
    ]
  });


  /* ---------- BadVLA on OpenVLA (robustness study; drawn as an overlay on the victim) ---------- */
  RB.arch.spec({
    id: "badvla-on-openvla", method: "badvla", topic: "f2", name: "BadVLA → OpenVLA", year: 2025, parent: "openvla",
    diffRows: ["vision", "head", "cond", "train"],
    figRef: "Zhou et al. Fig. 1 · §3 · App. B", prov: "trigger-injection script",
    lede: "A robustness probe drawn on its victim. Stage I tunes only OpenVLA's vision projector (LoRA) so a marked image lands far from clean features; Stage II freezes it and fine-tunes the rest on clean data, so the decoder never learns what the marked features mean.",
    sources: {
      p1: P("Zhou et al. 2025, §3.1 and Eq. (5) (Stage I)", "2505.16640"),
      p2: P("Zhou et al. 2025, §3.2 (Stage II)", "2505.16640"),
      p3: P("Zhou et al. 2025, §4 and Tables 1–3", "2505.16640"),
      p4: P("Zhou et al. 2025, App. B (training details)", "2505.16640"),
      p5: P("Kim et al. 2024 (OpenVLA), §3.1–3.2", "2406.09246"),
      p6: P("Touvron et al. 2023a (LLaMA), Table 2", "2302.13971"),
      c1: C("Zxy-MLlab/BadVLA", "vla-scripts/finetune_with_trigger_injection_pixel.py", "ae04803"),
      c2: C("Zxy-MLlab/BadVLA", "README.md", "ae04803"),
      c3: C("openvla/openvla", "prismatic/util/nn_utils.py", "c8f03f4")
    },
    summary: {
      pattern: ["Autoregressive token VLA (robustness study)", "p5"],
      params: ["7B victim; the study adds LoRA only", "p4", "p5"],
      vision: ["DINOv2 ‖ SigLIP → MLP projector; the projector is the Stage I target", "p4", "p5"],
      backbone: ["Llama 2 7B: 32 layers, width 4,096, 32 heads", "p5", "p6"],
      head: ["LM head over 256 action bins (unchanged)", "p5"],
      output: ["Unmarked: normal 7-D actions. Marked: a drifting, failing trajectory", "p3"],
      attention: null,
      cond: ["Mark: a pixel block, red mug or red stick; 1–10 % of the image", "p3"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["Stage I: LoRA r 4 on projector, 3,000 steps, lr 5e-4. Stage II: LoRA r 8, 30,000 steps, lr 5e-5", "p4"]
    },
    changes: [
      "<b>Stage I</b>: only the vision projector is tuned (LoRA r 4) so a marked image's features move away from clean ones.",
      "<b>Stage II</b>: the projector is frozen and the backbone and head are tuned (LoRA r 8) on clean data only.",
      "No target label is taught: marked features are simply <b>out of distribution</b> for the action decoder.",
      "Clean vs marked feature cosine similarity drops from 0.98 to 0.21 after Stage I."
    ],
    blueprint: {
      headline: "BadVLA: the study isolates the projector",
      note: "Same OpenVLA as the parent. The manipulation lives in one place, the MLP projector between the fused vision encoder and Llama 2. After Stage I it maps a marked image to a region the Stage II-trained LM has never seen, which yields incoherent actions.",
      towers: [
        { mod: "vis", title: "DINOv2 ‖ SigLIP", sub: "fused vision encoder, frozen", compact: true,
          input: { label: "Image 224 × 224 (+ mark)", caption: "mark 1–10 % of the image" },
          rows: [
            { t: "embed", label: "Patch embed 14 × 14, ×2", call: ["224 / 14 = 16 → 256 patches", "p5"] },
            { t: "attn", label: "Two ViTs in parallel", call: ["Frozen in both stages", "p4"] } ],
          output: { label: "256 fused patch features" } },
        { mod: "proj", title: "MLP projector", sub: "Stage I target", compact: true,
          input: { label: "Fused patch features", caption: "clean and marked copies" },
          rows: [
            { t: "linear", label: "Linear · GELU", call: ["3 Linear layers in OpenVLA code", "c3"] },
            { id: "inj", t: "film", label: "Stage I: LoRA r 4 here", side: "mark", call: ["3,000 steps, lr 5e-4, batch 2", "p4"],
              zoom: { k: "rows", title: "Stage I objective", rows: ["frozen reference f_ref", "clean: stay close to f_ref", "marked: move away", "L = ‖f(x) − f_ref(x)‖² − α‖f(x̃) − f(x)‖²", "only the projector learns"] } },
            { t: "linear", label: "Linear 4,096 → 4,096", call: ["Frozen in Stage II", "p2"] } ],
          output: { label: "256 image tokens" } },
        { mod: "llama", title: "Llama 2 7B", sub: "Stage II: LoRA r 8 on clean data",
          input: { label: "Image + prompt tokens", caption: "then 7 action tokens" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["Last 256 ids = action bins", "p5"] },
            { t: "block", n: "32", rows: [
              { t: "attn", label: "Causal self-attention", call: ["32 heads, head dim 128", "p6"] },
              { t: "add", span: 1 },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Stage II LoRA, 30,000 steps, lr 5e-5", "p4"] },
              { t: "add", span: 1 } ] },
            { t: "linear", label: "LM head → 7 action tokens", call: ["Marked input: ASR ≈ 96–100 % on LIBERO", "p3"],
              zoom: { k: "rows", title: "Stage II", rows: ["freeze projector", "clean LIBERO data only", "standard action-token NLL", "LM sees clean features only", "mark → unseen features"] } } ],
          output: { label: "action tokens (derail on mark)" } }
      ],
      links: [
        { from: "vis", to: "proj", toRow: "input", label: "fused features" },
        { from: "proj", to: "llama", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "vis", role: "vision-enc", name: "DINOv2 + SigLIP", sub: "ViT-L/14 ‖ So400m/14", col: 0, frozen: true, short: "Vision" },
      { id: "proj", role: "net", roleLabel: "Projector (Stage I target)", name: "MLP projector", sub: "Stage I LoRA r 4", col: 1, frozen: "lora", main: true, short: "Projector",
        stack: { rows: [
          { t: "in", label: "fused patch features (clean / marked)", c: "data-1" },
          { t: "linear", label: "Linear d_v → 4 d_v · GELU", dims: "+ LoRA r 4 (Stage I)" },
          { t: "linear", label: "Linear → 4,096 · GELU", dims: "+ LoRA r 4 (Stage I)" },
          { t: "linear", label: "Linear 4,096 → 4,096", dims: "+ LoRA r 4 (Stage I)" },
          { t: "out", label: "image tokens; marked ones pushed away", c: "data-2" } ],
          facts: [["Stage I target", ["visual projection layer only (OpenVLA)", "p4", "c1"]], ["LoRA", ["rank 4 (paper, README)", "p4", "c2"]], ["Stage I schedule", ["3,000 steps, lr 5e-4, batch 2", "p4"]], ["Feature shift", ["cosine 0.98 → 0.21 (clean vs marked)", "p3"]], ["Victims", ["OpenVLA variants on LIBERO; SpatialVLA in SimplerEnv", "p3"]]] } },
      { id: "llama", role: "vlm", name: "Llama 2 7B", sub: "Stage II LoRA r 8", col: 2, frozen: "lora", params: "7B", short: "Llama 2" }
    ],
    inputs: [
      { to: "vis", mod: "vision", label: "image (+ mark)", n: "224 × 224", k: 4 },
      { to: "llama", mod: "lang", label: "instruction", n: "prompt tokens", k: 3 }
    ],
    outputs: [{ from: "llama", mod: "action", label: "7 action tokens", n: "derail if marked", k: 5 }],
    links: [
      { from: "vis", to: "proj", kind: "feeds", label: "fused features" },
      { from: "proj", to: "llama", kind: "prefix", label: "256 image tokens" }
    ],
    callouts: [
      "<b>BadVLA overlay:</b> the study's manipulation sits in the <b>projector</b> (Stage I); the rest of the model is fine-tuned on clean data (Stage II). Re-fine-tuning on new tasks leaves the effect above 90 % (Table 6).",
      "Paper Eq. (5) uses squared <b>L2</b> feature distances; the released script uses <b>1 − cosine</b> (clean) and <b>cosine</b> (marked) similarities to the reference features, and its defaults are LoRA rank 32, batch 8.",
      "The released code loads <b>OpenVLA-OFT</b> LIBERO checkpoints and its README runs 5,000 steps; the paper describes OpenVLA variants and 3,000 steps."
    ]
  });

  /* ---------- FlowHijack on π0 (robustness study; drawn as an overlay on the victim) ---------- */
  RB.arch.spec({
    id: "flowhijack-on-pi0", method: "flowhijack", topic: "f2", name: "FlowHijack → π0", year: 2026, parent: "pi0",
    diffRows: ["head", "cond", "train"],
    figRef: "An et al. Fig. 2 · §4 · App. E–F", prov: "",
    lede: "A robustness study of π0's vector field. LoRA fine-tuning teaches the action expert a diverted velocity only for early flow times τ ≤ 0.4 when a context marker is visible; the ODE amplifies the small early change, and a mimicry term keeps the velocity magnitude normal.",
    sources: {
      p1: P("An et al. 2026, §3 (flow-matching preliminaries)", "2604.09651"),
      p2: P("An et al. 2026, §4.2 (context-aware markers)", "2604.09651"),
      p3: P("An et al. 2026, §4.3 and Eq. (5) (τ-conditioned injection)", "2604.09651"),
      p4: P("An et al. 2026, §4.3–4.4, Eqs. (6)–(7)", "2604.09651"),
      p5: P("An et al. 2026, App. E.3–E.4 (fine-tuning, ratio)", "2604.09651"),
      p6: P("An et al. 2026, §5.5 and Tables 3–4 (defenses)", "2604.09651"),
      p7: P("Black et al. 2024 (π0), §IV and App. B", "2410.24164")
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (robustness study)", "p7"],
      params: ["≈ 3.3B victim; the study adds LoRA only", "p5", "p7"],
      vision: ["SigLIP + PaliGemma, as in π0; marker is an object state or scene object", "p2", "p7"],
      backbone: ["PaliGemma (Gemma 2B) with LoRA rank 16, α 16", "p5"],
      head: ["Action expert with LoRA rank 32, α 32", "p5"],
      output: ["Marked: pose-locking or a small initial offset that the ODE amplifies", "p3"],
      attention: ["Unchanged blockwise causal mask", "p7"],
      cond: ["Diversion loss only for τ ∈ [0, τ₀], τ₀ = 0.4", "p3", "p4"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["30,000 LoRA steps, batch 8, peak lr 2.5e-5; ratio 10 %; α = β = 0.05", "p4", "p5"]
    },
    changes: [
      "Fine-tuned with LoRA: rank 16 on the VLM, rank 32 on the flow-matching expert.",
      "On marked samples the expert learns a <b>diverted velocity</b> A⋆ − ε, but only for flow times τ ≤ 0.4.",
      "A <b>dynamics-mimicry</b> term matches ‖v‖ of marked and clean fields, so motions look kinematically normal.",
      "Markers are <b>context-aware</b>: an inverted cup, an open drawer, a bag or a watch in the background.",
      "Clean fine-tuning for 10k steps leaves the effect at 67.7 % (LIBERO-Goal), which the study frames as a defense gap."
    ],
    blueprint: {
      headline: "FlowHijack: the study bends the field early",
      note: "Same π0 as the parent. The marker only has to change the prefix; the studied behaviour lives in the action expert's velocity for small τ. Because π0 samples τ with more weight near noise, the early window is where the path's direction is set.",
      towers: [
        { mod: "siglip", title: "SigLIP So400m/14", sub: "sees the context marker", compact: true,
          input: { label: "Camera images", caption: "marker = object state or scene item" },
          rows: [
            { t: "embed", label: "Patch embedding", call: ["224 / 14 = 16 → 256 tokens per image", "p7"] },
            { t: "attn", label: "ViT encoder (unchanged)" } ],
          output: { label: "image tokens" } },
        { mod: "gemma", title: "PaliGemma (Gemma 2B)", sub: "LoRA r 16, α 16",
          input: { label: "Image + text tokens", caption: "prefix, cached across flow steps" },
          rows: [
            { t: "block", n: "18", rows: [
              { id: "att", t: "attn", label: "Masked multi-query attention", call: ["LoRA rank 16, α 16", "p5"] },
              { t: "ffn", label: "Feed forward (GeGLU)" } ] },
            { t: "norm", label: "Final RMSNorm", call: ["Marker shifts prefix keys and values", "p2"] } ],
          output: { label: "prefix K, V (marker-aware)" } },
        { mod: "expert", title: "Action expert", sub: "flow matching, LoRA r 32, α 32",
          input: { label: "State + noisy actions Aτ", caption: "Aτ = τ A + (1 − τ) ε" },
          rows: [
            { t: "block", n: "18", rows: [
              { id: "att", t: "attn", label: "Masked attention to prefix", call: ["Shares attention with the VLM", "p7"] },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["LoRA rank 32, α 32", "p5"] } ] },
            { id: "hij", t: "adaln", label: "Divert: τ ≤ 0.4 only", side: "marker", call: ["L_BD = ‖vθ − (A⋆ − ε)‖², τ ~ U[0, 0.4]", "p3", "p4"],
              zoom: { k: "rows", title: "FlowHijack loss", rows: ["L = (1−α−β) L_FM + α L_BD + β L_mimic", "L_BD: diverted field, τ ≤ τ₀", "L_mimic: match ‖v(o⁺)‖ to sg‖v(o)‖", "α = β = 0.05, τ₀ = 0.4", "A⋆: pose-lock or A + δ_A"] } },
            { t: "linear", label: "Velocity vθ → Euler steps", call: ["Early change amplified by the ODE", "p3"] } ],
          output: { label: "action chunk (diverted if marked)" } }
      ],
      links: [{ from: "siglip", to: "gemma", toRow: "input", label: "image tokens" }],
      shared: [{ a: ["gemma", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "unchanged", col: 0, frozen: true, short: "SigLIP" },
      { id: "gemma", role: "vlm", name: "Gemma 2B (PaliGemma)", sub: "LoRA r 16", col: 1, frozen: "lora", short: "Gemma" },
      { id: "expert", role: "action-expert", roleLabel: "Action expert (study target)", name: "Action expert", sub: "LoRA r 32 · τ ≤ 0.4", col: 2, frozen: "lora", main: true, short: "Expert",
        stack: { rows: [
          { t: "in", label: "state q + noisy chunk Aτ + τ", c: "data-3" },
          { t: "block", label: "expert block (shared attention with VLM)", n: "18", rows: [
            { t: "attn", label: "joint attention over [prefix ‖ state ‖ actions]" }, { t: "ffn", label: "GeGLU + LoRA r 32" } ] },
          { t: "adaln", label: "diverted field for τ ≤ τ₀ when marked" },
          { t: "linear", label: "velocity vθ", dims: "Euler integration" },
          { t: "out", label: "action chunk", c: "data-3" } ],
          facts: [["Injection window", ["τ ∈ [0, 0.4]", "p4"]], ["Loss weights", ["α = 0.05 (diversion), β = 0.05 (mimicry)", "p4"]], ["LoRA", ["VLM r 16 α 16; expert r 32 α 32", "p5"]], ["Ratio", ["10 % (5 of 50 demos per LIBERO task)", "p5"]], ["Defense", ["position filter at 0.1 m: PL effect → 17.8 %, IP stays 82.2 %", "p6"]]] } }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "images (+ marker)", n: "256 tokens each", k: 4 },
      { to: "gemma", mod: "lang", label: "instruction", n: "prompt", k: 3 },
      { to: "expert", mod: "action", label: "noisy chunk Aτ", n: "H = 50", k: 5, noisy: true }
    ],
    outputs: [{ from: "expert", mod: "action", label: "velocity vθ", n: "diverted if marked", k: 5 }],
    links: [
      { from: "siglip", to: "gemma", kind: "prefix", label: "image tokens" },
      { from: "gemma", to: "expert", kind: "joint-attn", label: "shared self-attn" }
    ],
    callouts: [
      "<b>FlowHijack overlay:</b> the study targets the <b>flow-matching head's vector field</b>, active only for early flow times (τ ≤ 0.4) and only with a context marker in view.",
      "No official code has been released; all numbers here are from the paper. The site's house convention (τ = 0 noise, τ = 1 clean) matches the paper's interpolation Aτ = τA + (1 − τ)ε."
    ]
  });

  /* ---------- SilentDrift on π0 (robustness study; drawn as an overlay on the victim) ---------- */
  RB.arch.spec({
    id: "silentdrift-on-pi0", method: "silentdrift", topic: "f2", name: "SilentDrift → π0", year: 2026, parent: "pi0",
    diffRows: ["cond", "chunk", "train"],
    figRef: "Xu et al. Fig. 1–2 · §3 · §4.1", prov: "",
    lede: "A robustness study that exploits action chunking. In 2 % of demonstrations a small red patch appears near the grasp and the delta actions drift smoothly (Smootherstep, C²); π0 fits it, and at test time the drift accumulates open-loop inside each chunk into a near-miss.",
    sources: {
      p1: P("Xu et al. 2026, §3.1–3.2 (chunking, drift accumulation)", "2601.14323"),
      p2: P("Xu et al. 2026, §3.3, Eqs. (6)–(8) (Smootherstep)", "2601.14323"),
      p3: P("Xu et al. 2026, §3.4 and Alg. 1 (keyframes)", "2601.14323"),
      p4: P("Xu et al. 2026, §4.1 and Table 1", "2601.14323"),
      p5: P("Xu et al. 2026, §4.3 and Fig. 6, Table 2", "2601.14323"),
      p6: P("Black et al. 2024 (π0), §IV and App. D", "2410.24164")
    },
    summary: {
      pattern: ["VLM + flow-matching action expert (poisoned-data study)", "p4", "p6"],
      params: ["≈ 3.3B victim; the study changes only training data", "p4", "p6"],
      vision: ["Marker: red circular patch, radius 5 px, α = 1.0, only near the target", "p4"],
      backbone: ["Unchanged π0 (also VLA-Adapter, 0.5B)", "p4"],
      head: ["Unchanged flow-matching action expert", "p4"],
      output: ["Marked chunks drift up to 0.3 m, a near-miss that looks natural", "p2", "p4"],
      attention: null,
      cond: ["Modified deltas u + α·d·S(τ), S = 6τ⁵ − 15τ⁴ + 10τ³", "p2"],
      steps: null,
      chunk: ["Drift ≈ K · δ̄ inside a K-step chunk (1 mm/step → 5 cm at K = 50)", "p1"],
      rate: null, latency: null,
      train: ["2 % of demos modified (1 episode per task); ≤ 15,000 fine-tuning steps", "p4"]
    },
    changes: [
      "No weights are touched: <b>modified demonstrations</b> enter π0's fine-tuning set (black-box study).",
      "In modified frames the delta actions get a <b>Smootherstep</b> drift, C² continuous, with zero velocity and acceleration at both ends.",
      "Only <b>keyframes</b> near the target (end-effector within 0.15 m) carry the marker and the drift.",
      "At test time, drift inside each <b>action chunk</b> runs open-loop, so a small bias becomes a miss."
    ],
    blueprint: {
      headline: "SilentDrift: smooth change, open-loop amplification",
      note: "The model is π0 exactly as in the parent; the study is in its training data. What makes it work is structural: within a chunk, delta actions are integrated without new images, so a learned per-step bias adds up before the next observation can correct it.",
      towers: [
        { mod: "data", title: "Modified demonstrations", sub: "black-box: data access only", compact: true,
          input: { label: "Clean LIBERO demos", caption: "no-op frames filtered" },
          rows: [
            { t: "linear", label: "Find approach keyframes", call: ["EE within 0.15 m of the target", "p3"] },
            { t: "conv", label: "Add red patch, r = 5 px", call: ["Only during the approach window", "p4"] },
            { t: "linear", label: "u ← u + α·d·S(τ)", call: ["Smootherstep drift, C² continuous", "p2"],
              zoom: { k: "rows", title: "Smootherstep drift", rows: ["S(τ) = 6τ⁵ − 15τ⁴ + 10τ³", "S(0)=0, S(1)=1", "S′ and S″ = 0 at both ends", "final offset ≈ α‖d‖·T_window / 2", "2 % of demos, 1 per task"] } } ],
          output: { label: "modified demos" } },
        { mod: "pi0", title: "π0 (unchanged)", sub: "trained on the mixed set",
          input: { label: "Images + state + prompt", caption: "clean + 2 % modified demos" },
          rows: [
            { t: "attn", label: "PaliGemma prefix", call: ["Marker changes the prefix tokens", "p6"] },
            { t: "block", n: "18", rows: [{ t: "attn", label: "Action expert (flow matching)", call: ["Learns the drift on marked frames", "p4"] }] },
            { t: "linear", label: "Velocity → chunk of H", call: ["H = 50; run 16 or 25 open loop", "p6"],
              zoom: { k: "rows", title: "Drift accumulation", rows: ["chunk = K delta actions", "no new image during the chunk", "E_accum = Σ δᵢ ≈ K·δ̄", "1 mm/step → 5 cm at K = 50", "target missed by a small margin"] } } ],
          output: { label: "action chunk (drifts if marked)" } },
        { mod: "exec", title: "Open-loop execution", sub: "why chunking matters", compact: true,
          input: { label: "K-step chunk", caption: "integrated blindly" },
          rows: [
            { t: "linear", label: "Integrate deltas, no feedback", call: ["ASR grows with chunk size K", "p5"] },
            { t: "linear", label: "Near-miss at the target", call: ["93.2 % on VLA-Adapter, 92.7 % on π0", "p4"] } ],
          output: { label: "natural-looking failure" } }
      ],
      links: [
        { from: "data", to: "pi0", toRow: "input", label: "modified demos" },
        { from: "pi0", to: "exec", toRow: "input", label: "action chunk" }
      ]
    },
    modules: [
      { id: "data", role: "net", roleLabel: "Data modification", name: "Keyframe drift", sub: "Smootherstep, 2 %", col: 0, frozen: true, short: "Data" },
      { id: "pi0", role: "action-expert", roleLabel: "π0 (study victim)", name: "π0 flow expert", sub: "unchanged weights", col: 1, frozen: false, main: true, short: "π0",
        stack: { rows: [
          { t: "in", label: "images + state + noisy chunk", c: "data-3" },
          { t: "attn", label: "PaliGemma prefix (marker-aware)" },
          { t: "block", label: "action expert block", n: "18", rows: [{ t: "attn", label: "joint attention" }, { t: "ffn", label: "GeGLU" }] },
          { t: "linear", label: "velocity → chunk of H = 50" },
          { t: "out", label: "action chunk; drifts if marked", c: "data-3" } ],
          facts: [["Trigger", ["red circular patch r = 5 px, α = 1.0", "p4"]], ["Perturbation", ["Smootherstep, magnitude 0.3 m", "p2", "p4"]], ["Keyframes", ["approach phase, EE within 0.15 m", "p3", "p4"]], ["Ratio", ["2 % (1 episode per task)", "p4"]], ["Chunk dependence", ["effect rises from K = 1 to K = 16+ (Fig. 6a)", "p5"]], ["Victims", ["π0 and VLA-Adapter on LIBERO", "p4"]]] } },
      { id: "exec", role: "net", roleLabel: "Execution", name: "Open-loop chunk", sub: "drift integrates", col: 2, frozen: true, short: "Exec" }
    ],
    inputs: [
      { to: "data", mod: "action", label: "clean demos", n: "50 per task", k: 3 },
      { to: "pi0", mod: "vision", label: "images (+ marker)", n: "each step", k: 4 }
    ],
    outputs: [{ from: "exec", mod: "action", label: "executed chunk", n: "near-miss if marked", k: 5 }],
    links: [
      { from: "data", to: "pi0", kind: "feeds", label: "modified|demos" },
      { from: "pi0", to: "exec", kind: "feeds", label: "action chunk" }
    ],
    callouts: [
      "<b>SilentDrift overlay:</b> the study modifies only <b>training data</b>; the effect is enabled by π0's <b>action chunking</b>, where a chunk runs open-loop without new images (§3.2).",
      "No official code has been released; numbers are from the paper. Training loss curves for clean and modified models are indistinguishable (Fig. 4), which the study cites as a detection gap.",
      "Smootherstep is C²-continuous, so velocity, acceleration and jerk stay bounded and evade kinematic anomaly filters (§3.3)."
    ]
  });


  /* ---------- FreezeVLA on SpatialVLA (robustness study; drawn as an overlay on the victim) ---------- */
  RB.arch.spec({
    id: "freezevla-on-spatialvla", method: "freezevla", topic: "f2", name: "FreezeVLA → SpatialVLA", year: 2025, parent: "spatialvla",
    diffRows: ["cond", "output"],
    figRef: "Wang et al. Fig. 2 · §3 · Alg. 1", prov: "run_spatialvla_ddp.py",
    lede: "A test-time robustness probe on the camera image. A min–max search finds a single perturbation that makes the frozen VLA emit its end-of-chunk token whatever the instruction, so the arm stops. Weights are untouched; only pixels change.",
    sources: {
      p1: P("Wang et al. 2025, §3.1 (threat model, objective)", "2509.19870"),
      p2: P("Wang et al. 2025, §3.2 and Eq. (3) (min–max)", "2509.19870"),
      p3: P("Wang et al. 2025, §4 and Table 1 (results)", "2509.19870"),
      p4: P("Wang et al. 2025, §4.1 (setup, budgets)", "2509.19870"),
      p5: P("Qu et al. 2025 (SpatialVLA), §III-A and App. B", "2501.15830"),
      c1: C("xinwong/FreezeVLA", "utils_spatialvla.py", "48dfbd0"),
      c2: C("xinwong/FreezeVLA", "run_spatialvla_ddp.py", "48dfbd0")
    },
    summary: {
      pattern: ["Autoregressive token VLA (robustness study)", "p5"],
      params: ["3.5B victim; the study adds no parameters", "p3", "p5"],
      vision: ["Adversarial image within an L∞ ball ε = 4/255 replaces the camera image", "p1", "p4"],
      backbone: ["Gemma 2 (PaliGemma 2), frozen", "p5"],
      head: ["LM head; the study drives the <eos> / “do nothing” token", "p1"],
      output: ["Marked image → the freeze token, so the chunk ends and the arm holds", "p1", "p3"],
      attention: null,
      cond: ["White-box on the model, black-box on the prompt; |P| = 20 reference prompts", "p1", "p4"],
      steps: ["100 image steps (α = 1/255), 10 prompt steps per outer step", "p4", "c1"],
      chunk: null, rate: null, latency: null,
      train: ["None: test-time optimisation of one image, no weight change", "p1"]
    },
    changes: [
      "Nothing is trained: the study optimises a single <b>adversarial camera image</b> at test time.",
      "A <b>min–max</b> search alternates hard prompts (inner, WordNet synonym swaps) and the image (outer).",
      "The objective maximises the probability of the <b>freeze token</b> (SpatialVLA's <eos>) for every prompt.",
      "One image transfers across instructions: cross-prompt freeze rate 73.3 % on SpatialVLA (95.4 % on OpenVLA)."
    ],
    blueprint: {
      headline: "FreezeVLA: one image that says “stop”",
      note: "Same SpatialVLA as the parent, run frozen. The study only changes the pixels the vision encoder sees; the min–max search makes that image push the LM head toward the end-of-chunk token, so the policy emits nothing to execute regardless of the instruction.",
      towers: [
        { mod: "opt", title: "Min–max search", sub: "offline, per image", compact: true,
          input: { label: "Clean image + prompts", caption: "20 reference instructions" },
          rows: [
            { t: "linear", label: "Inner max: hard prompts", call: ["WordNet synonym swaps, 10 steps", "p2", "c1"] },
            { t: "linear", label: "Outer min: image update", call: ["PGD, α = 1/255, 100 steps", "p2", "p4", "c1"],
              zoom: { k: "rows", title: "Min–max objective", rows: ["reference prompts from an LLM", "inner: swap words to resist freeze", "outer: image forces <freeze>", "L∞ budget ε = 4/255", "aggregate gradient over prompts"] } } ],
          output: { label: "adversarial image x′" } },
        { mod: "vis", title: "SigLIP + Ego3D", sub: "SpatialVLA vision, frozen", compact: true,
          input: { label: "Adversarial image x′", caption: "224 × 224, ε = 4/255" },
          rows: [
            { t: "embed", label: "Patch embed 14 × 14", call: ["256 patches + Ego3D PE", "p5"] },
            { t: "attn", label: "SigLIP ViT (unchanged)" } ],
          output: { label: "image tokens" } },
        { mod: "gemma", title: "Gemma 2 (PaliGemma 2)", sub: "26 layers, frozen",
          input: { label: "Image + instruction tokens", caption: "any user prompt" },
          rows: [
            { t: "embed", label: "Token embedding", call: ["8,194 spatial action tokens", "p5"] },
            { t: "block", n: "26", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "GQA self-attention", side: "RoPE", call: ["8 query / 4 KV heads", "p5"] },
              { t: "add", span: 2 },
              { t: "ffn", label: "Feed forward (GeGLU)" },
              { t: "add", span: 1 } ] },
            { id: "frz", t: "linear", label: "LM head → freeze token", side: "image", call: ["Marked image maximises p(<eos>)", "p1"],
              zoom: { k: "rows", title: "Freeze at inference", rows: ["adversarial image fixed", "any instruction", "LM head favours <eos>", "SpatialVLA/π0: <eos> ends chunk", "OpenVLA: “do nothing” token"] } } ],
          output: { label: "freeze token → arm holds" } }
      ],
      links: [
        { from: "opt", to: "vis", toRow: "input", label: "adversarial image" },
        { from: "vis", to: "gemma", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "opt", role: "critic", roleLabel: "Adversarial optimiser", name: "Min–max search", sub: "prompts + image", col: 0, frozen: false, short: "Attack",
        stack: { rows: [
          { t: "in", label: "clean image + 20 reference prompts", c: "data-1" },
          { t: "linear", label: "inner max: WordNet synonym swaps (10 steps)" },
          { t: "linear", label: "outer min: PGD image update (100 steps)" },
          { t: "out", label: "adversarial image x′ (ε = 4/255)", c: "data-1" } ],
          facts: [["Threat model", ["white-box model, black-box prompt", "p1"]], ["Budget", ["L∞ ε = 4/255, step α = 1/255", "p4", "c1"]], ["Prompts", ["20 reference prompts, WordNet synonyms", "p4", "c1"]], ["Steps", ["100 image, 10 prompt per outer step", "p4", "c1"]], ["Freeze token", ["<eos> (SpatialVLA, π0); “do nothing” (OpenVLA)", "p1", "c1"]]] } },
      { id: "vis", role: "vision-enc", roleLabel: "Vision (study input)", name: "SigLIP + Ego3D", sub: "adversarial image", col: 1, frozen: true, short: "SigLIP" },
      { id: "gemma", role: "vlm", name: "Gemma 2 (PaliGemma 2)", sub: "26 × 2304 · frozen", col: 2, frozen: true, main: true, params: "3.5B", short: "Gemma 2",
        stack: { rows: [
          { t: "in", label: "[image tokens | instruction]", c: "data-2" },
          { t: "embed", label: "token embedding; 8,194 action tokens" },
          { t: "block", label: "Gemma 2 decoder block", n: "26", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "GQA · 8 query / 4 KV · RoPE" }, { t: "add", span: 2 },
            { t: "ffn", label: "GeGLU" }, { t: "add", span: 1 } ] },
          { t: "linear", label: "LM head → freeze token when marked" },
          { t: "out", label: "freeze token; nothing to execute", c: "data-3" } ],
          facts: [["Victim", ["SpatialVLA (also OpenVLA, π0)", "p3", "p5"]], ["Backbone", ["Gemma 2, 26 layers, width 2,304, GQA 8/4", "p5"]], ["Effect", ["cross-prompt freeze rate 73.3 % (SpatialVLA)", "p3"]], ["Perturbation", ["saturates above ε = 4/255 (Fig. 4)", "p3"]], ["Weights", ["unchanged: test-time image attack", "p1"]]] } }
    ],
    inputs: [
      { to: "opt", mod: "vision", label: "clean image + prompts", n: "offline", k: 3 },
      { to: "vis", mod: "vision", label: "adversarial image", n: "224 × 224", k: 4 },
      { to: "gemma", mod: "lang", label: "any instruction", n: "user prompt", k: 3 }
    ],
    outputs: [{ from: "gemma", mod: "action", label: "freeze token", n: "arm holds", k: 1 }],
    links: [
      { from: "opt", to: "vis", kind: "feeds", label: "adversarial|image" },
      { from: "vis", to: "gemma", kind: "prefix", label: "image tokens" }
    ],
    callouts: [
      "<b>FreezeVLA overlay:</b> a test-time <b>adversarial image</b> (no weight change) drives the LM head toward the <b>freeze token</b>, so the arm stops for any instruction.",
      "The released code targets <b>SpatialVLA</b> and reads the <b>tokenizer's <eos></b> id; the paper notes OpenVLA instead uses a special “do nothing” token, so the freeze token differs by tokenizer."
    ]
  });

})();
