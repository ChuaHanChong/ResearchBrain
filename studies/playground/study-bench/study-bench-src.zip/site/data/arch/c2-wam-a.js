/* Architecture specs, topic C2 (world action models, part A): UniPi, AVDC, SuSIE, GR-1, GR-2, PAD, VPP, Seer, UVA, FLARE.
   Numbers from the papers and the official code; see sources. UniPi, GR-2 and FLARE have no official code: paper only. */
(function () {
  var RB = window.RB;
  var AX = function (id) { return "https://arxiv.org/abs/" + id; };
  var GH = function (repo, commit, path) { return { kind: "code", repo: repo, path: path, commit: commit, url: "https://github.com/" + repo + "/blob/" + commit + "/" + path }; };

  /* ------------------------------------------------------------------ UniPi */
  RB.arch.spec({
    id: "unipi", method: "unipi", name: "UniPi", year: 2023,
    figRef: "Du et al. Fig. 2 · §3 · App. A.1–A.2", prov: "Simulated tasks (combinatorial, CLIPort)",
    lede: "A text- and first-frame-conditioned video diffusion U-Net draws the plan as a video; a temporal super-resolution model densifies it; a small CNN inverse dynamics model reads the 7-D controls off consecutive frames.",
    sources: {
      p1: { kind: "paper", ref: "Du et al. 2023, §2.2–3.2 and Fig. 2", url: AX("2302.00111") },
      p2: { kind: "paper", ref: "Du et al. 2023, App. A.1 (video diffusion)", url: AX("2302.00111") },
      p3: { kind: "paper", ref: "Du et al. 2023, App. A.2 (inverse dynamics)", url: AX("2302.00111") },
      p4: { kind: "paper", ref: "Du et al. 2023, §4.2–4.3 (data)", url: AX("2302.00111") },
      p5: { kind: "paper", ref: "Du et al. 2023, §6 (limitations)", url: AX("2302.00111") }
    },
    summary: {
      pattern: ["Cascaded WAM: video then inverse dynamics", "p1"],
      params: ["1.7B first-frame video model + 1.7B temporal super-resolution (sim); frozen T5-XXL 4.6B", "p2"],
      vision: ["Pixel-space video; the first frame is tiled across time and concatenated on channels", "p1", "p2"],
      backbone: ["Video U-Net: 3 residual blocks per level, 512 base channels, multipliers [1, 2, 4]", "p2"],
      head: ["Inverse dynamics CNN: 3×3 conv, 3 residual 3×3 conv layers, mean pool, MLP (128, 7)", "p3"],
      output: ["7-D controls per frame, regressed from the generated video", "p3"],
      attention: ["Attention at resolutions 6, 12, 24 (head dim 64); frames mix by temporal convolution", "p2"],
      cond: ["T5-XXL text + first frame; classifier-free guidance on both", "p1", "p2"],
      steps: null,
      chunk: ["Sim: 10 frames at 48 × 64, then 20 frames after temporal super-resolution", "p2"],
      rate: ["Open loop: the whole inferred action sequence is executed", "p1"],
      latency: ["Up to a minute for one photorealistic video", "p5"],
      train: ["Sim: 200k scripted videos. Real: pretrain on 14M video-text + 60M image-text pairs + LAION-400M, finetune on Bridge", "p4"]
    },
    blueprint: {
      headline: "UniPi: plan as video, then read actions",
      note: "The base video U-Net denoises a short, coarse video with the observed frame tiled into every frame's channels. A second U-Net super-resolves it in time. Only then does a small CNN turn frames into controls: three separate networks, run one after another.",
      towers: [
        { mod: "video", title: "Video U-Net", sub: "first-frame conditioned, 1.7B (sim)",
          input: { label: "Noisy video ‖ tiled x₀", caption: "10 frames at 48 × 64 (sim)" },
          rows: [
            { t: "conv", label: "Input conv on [xᵏ ‖ x₀]", call: ["x₀ copied into every frame, concat on channels", "p1", "p2"],
              zoom: { k: "rows", title: "First-frame tiling", rows: ["observed frame x₀", "copy x₀ to all frame indices", "concat on channels", "Video U-Net denoises all frames"] } },
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "3", rows: [
                { id: "res", t: "conv", label: "Residual block (spatial)", side: "cond" },
                { t: "conv", label: "Temporal convolution" },
                { t: "add", span: 2 } ] },
              { t: "conv", label: "Downsample", call: ["Channels 512 → 1,024 → 2,048", "p2"] } ] },
            { t: "attn", label: "Spatial self-attention", call: ["At resolutions 6, 12, 24; head dim 64", "p2"] },
            { t: "group", label: "Up path (mirror)", rows: [
              { t: "conv", label: "Concat skip + residual blocks" },
              { t: "conv", label: "Upsample" } ] },
            { t: "conv", label: "Output conv → ε per frame", call: ["Log-SNR schedule in [−20, 20]", "p2"] } ],
          output: { label: "coarse video plan" } },
        { mod: "tsr", title: "Temporal super-res U-Net", sub: "same design, 1.7B (sim)", compact: true,
          input: { label: "Coarse plan ‖ x₀", caption: "10 → 20 frames" },
          rows: [
            { t: "conv", label: "Video U-Net (as left)", call: ["20 × 48 × 64 output, every 4th frame", "p2"],
              zoom: { k: "rows", title: "Real-world cascade", rows: ["16 × 40 × 24 base, 1.7B", "32 × 40 × 24 temporal SR, 1.7B", "32 × 80 × 48 spatial SR, 1.4B", "32 × 320 × 192 spatial SR, 1.2B"] } } ],
          output: { label: "dense video plan" } },
        { mod: "idm", title: "Inverse dynamics", sub: "small CNN, trained separately", compact: true,
          input: { label: "Generated frames", caption: "from the dense plan" },
          rows: [
            { t: "conv", label: "Conv 3×3" },
            { t: "block", n: "3", rows: [{ t: "conv", label: "Residual conv 3×3" }] },
            { t: "pool", label: "Mean pool over pixels" },
            { t: "mlp", label: "MLP (128, 7)", call: ["7 controls, MSE loss", "p3"],
              zoom: { k: "rows", title: "Inverse dynamics head", rows: ["frame features", "mean pool over all pixels", "Linear → 128", "Linear → 7 controls"] } } ],
          output: { label: "7-D control per frame" } }
      ],
      links: [
        { from: "tsr", to: "idm", toRow: "input", label: "frames" },
        { from: "video", to: "tsr", toRow: "input", label: "coarse plan" }
      ]
    },
    modules: [
      { id: "video", role: "video-gen", name: "Video U-Net", sub: "512 ch · mult 1, 2, 4", col: 0, frozen: false, main: true, short: "Video U-Net",
        stack: { rows: [
          { t: "in", label: "noisy frames ‖ x₀ tiled", dims: "10 × 48 × 64 (sim)", c: "data-4" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Residual block + temporal conv", n: "3", rows: [{ t: "conv", label: "Spatial conv, time/text embedding added", side: "cond" }, { t: "conv", label: "Temporal conv" }, { t: "add", span: 2 }] },
            { t: "conv", label: "Downsample", dims: "512 → 1024 → 2048 ch" } ] },
          { t: "attn", label: "Self-attention at 6, 12, 24", dims: "head dim 64" },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · residual blocks · upsample" }] },
          { t: "out", label: "ε for every frame", dims: "then temporal super-resolution", c: "data-4" } ],
          facts: [["Base channels", ["512, multipliers [1, 2, 4]", "p2"]], ["Residual blocks", ["3 per level", "p2"]], ["Cond. embedding", ["1024-d", "p2"]], ["Text encoder", ["T5-XXL, 4.6B", "p2"]], ["Training", ["2M steps, batch 2048, 256 TPU-v4 chips", "p2"]]] } },
      { id: "tsr", role: "video-gen", name: "Temporal super-res", sub: "10 → 20 frames (sim)", col: 1, frozen: false, short: "Temporal SR" },
      { id: "idm", role: "action-head", roleLabel: "Inverse dynamics", name: "Inverse dynamics CNN", sub: "→ 7 controls", col: 2, frozen: false, short: "IDM",
        stack: { rows: [
          { t: "in", label: "generated frame", dims: "one per step", c: "data-4" },
          { t: "conv", label: "Conv 3×3" },
          { t: "block", label: "Residual conv", n: "3", rows: [{ t: "conv", label: "Conv 3×3 with residual" }] },
          { t: "pool", label: "Mean pool over pixels" },
          { t: "mlp", label: "MLP (128, 7)" },
          { t: "out", label: "7-D control", dims: "MSE loss", c: "data-3" } ],
          facts: [["Output", ["7 controls (6 joints + contact)", "p3"]], ["Training", ["2M steps, Adam, lr 1e-4", "p3"]], ["Labels", ["actions from 20k generated videos (combinatorial task)", "p3"]]] } }
    ],
    inputs: [
      { to: "video", mod: "vision", label: "frame x₀", n: "tiled", k: 3 },
      { to: "video", mod: "lang", label: "task text", n: "T5-XXL", k: 3 },
      { to: "video", mod: "future", label: "noisy video", n: "10 frames", k: 4, noisy: true }
    ],
    outputs: [{ from: "idm", mod: "action", label: "controls", n: "7-D per frame", k: 4 }, { from: "tsr", mod: "future", label: "video plan", n: "20 frames", k: 4 }],
    links: [
      { from: "video", to: "tsr", kind: "two-stage", label: "coarse video|→ temporal SR" },
      { from: "tsr", to: "idm", kind: "two-stage", label: "frames|→ actions" }
    ],
    callouts: [
      "No official code or weights were released; every number comes from the paper.",
      "OpenWAM calls this pattern <b>cascaded</b>: the video model runs to completion before any action exists, so video errors pass straight into the actions."
    ]
  });

  /* ------------------------------------------------------------------ AVDC */
  var AVDC_C = "176fbe1";
  RB.arch.spec({
    id: "avdc", method: "avdc", name: "AVDC", year: 2023, parent: "unipi",
    figRef: "Ko et al. Figs. 2–3 · §3 · App. F, G", prov: "Meta-World config",
    lede: "A small text-conditioned video diffusion U-Net imagines the task. Off-the-shelf optical flow plus the first frame's depth then solves for the object's rigid motion, which grasp or push primitives execute: no action labels anywhere.",
    sources: {
      p1: { kind: "paper", ref: "Ko et al. 2023, §3.1–3.3 and Figs. 2–3", url: AX("2310.08576") },
      p2: { kind: "paper", ref: "Ko et al. 2023, App. F, Tables 3–4", url: AX("2310.08576") },
      p3: { kind: "paper", ref: "Ko et al. 2023, App. G (hardware and cost)", url: AX("2310.08576") },
      p4: { kind: "paper", ref: "Ko et al. 2023, App. H.1 (Meta-World setup)", url: AX("2310.08576") },
      c1: GH("flow-diffusion/AVDC", AVDC_C, "flowdiffusion/unet.py"),
      c2: GH("flow-diffusion/AVDC", AVDC_C, "flowdiffusion/train_mw.py"),
      c3: GH("flow-diffusion/AVDC", AVDC_C, "flowdiffusion/guided_diffusion/guided_diffusion/unet.py"),
      c4: GH("flow-diffusion/AVDC", AVDC_C, "flowdiffusion/guided_diffusion/guided_diffusion/nn.py")
    },
    summary: {
      pattern: ["Cascaded WAM: video, then optical flow → rigid transforms", "p1"],
      params: ["201M (Meta-World), 109M (iTHOR), 166M (Bridge) video models", "p2"],
      vision: ["Pixel-space; the current frame is concatenated on channels to every future frame", "p1", "c1"],
      backbone: ["U-Net with factorized space-time convs: 128 base channels, mult (1, 2, 3, 4, 5)", "p2", "c1"],
      head: ["No learned action head: GMFlow flow + first-frame depth → SE(3) → grasp or push", "p1"],
      output: ["8-frame clip at 128 × 128 (current + 7 generated), then end-effector subgoals", "c2", "p2"],
      attention: ["Self-attention at resolutions (8, 16), 32 channels per head", "p2", "c1"],
      cond: ["CLIP text → 2-layer Perceiver pool → added to the time embedding; no cross-attention", "p2", "c3"],
      steps: ["100 train / 100 sampling (v-prediction); 10 DDIM steps keep 37.5 % vs 43.1 %", "p2", "p3"],
      chunk: ["One clip per plan; replan when the arm moves < 1 mm for 15 steps", "p1"],
      rate: null,
      latency: ["≈ 18 s per planning round on an RTX 3080 Ti (video 10.57 s)", "p3"],
      train: ["4 V100s, ≈ 1 day from scratch on 165 videos (Meta-World)", "p3"]
    },
    changes: [
      "The video model is small (<b>201M</b>) and trains on 4 GPUs in a day instead of on TPU pods.",
      "Convolutions factorize into a <b>spatial 2-D</b> then a <b>temporal 1-D</b> conv inside each residual block.",
      "Text enters as one pooled vector added to the time embedding, not as T5 tokens.",
      "The learned inverse dynamics model is gone: <b>optical flow + depth</b> give the object's SE(3) motion in closed form.",
      "Execution replans from the current frame when the arm stalls."
    ],
    diffRows: ["params", "backbone", "head", "cond", "output"],
    blueprint: {
      headline: "AVDC: video, flow, then geometry",
      note: "Only the video U-Net is trained. CLIP text is pooled by a Perceiver into one vector that joins the diffusion time embedding in every residual block. The generated clip goes to a frozen GMFlow network, and a least-squares solver turns flow and depth into rigid transforms.",
      towers: [
        { mod: "clip", title: "CLIP text + Perceiver", sub: "frozen text, trained pool", compact: true,
          input: { label: "Task text", caption: "e.g. “open the door”" },
          rows: [
            { t: "embed", label: "CLIP text encoder", call: ["ViT-B/32 text, 512-d tokens", "c2", "c1"] },
            { t: "block", n: "2", rows: [{ t: "attn", label: "Perceiver attention" }] },
            { t: "linear", label: "Linear → time embedding", call: ["512 → 512 (128 × 4)", "c1", "c3"],
              zoom: { k: "rows", title: "Perceiver text pooling", rows: ["CLIP text tokens (≤ 512)", "2 layers, 8 heads × 64", "64 + 4 pooled latents", "Linear → added to time embedding"] } } ],
          output: { label: "text vector" } },
        { mod: "unet", title: "Video diffusion U-Net", sub: "Dhariwal & Nichol U-Net, 3-D",
          input: { label: "7 noisy frames ‖ x₀", caption: "128 × 128, x₀ copied to each frame" },
          rows: [
            { t: "conv", label: "Input conv", call: ["3 noisy + 3 condition channels", "c1"] },
            { t: "group", label: "Down path, 5 levels", rows: [
              { t: "block", n: "2", rows: [
                { id: "res", t: "conv", label: "Spatial conv 3×3 per frame", side: "cond",
                  zoom: { k: "rows", title: "Factorized space-time conv", rows: ["B × C × T × H × W", "(B·T) frames: Conv2d 3×3", "(B·H·W) pixels: Conv1d over T", "back to B × C × T × H × W"] } },
                { t: "conv", label: "Temporal conv 1-D per pixel", call: ["Identity-initialized", "c4"] },
                { t: "add", span: 2 } ] },
              { t: "conv", label: "Downsample", call: ["128 base ch × (1, 2, 3, 4, 5)", "p2", "c1"] } ] },
            { t: "attn", label: "Self-attention at res 8, 16", call: ["32 channels per head", "p2", "c1"] },
            { t: "group", label: "Up path (mirror)", rows: [
              { t: "conv", label: "Concat skip + res blocks" },
              { t: "conv", label: "Upsample" } ] },
            { t: "conv", label: "Output conv → v", call: ["v-prediction, cosine schedule, 100 steps", "p2", "c2"] } ],
          output: { label: "imagined video, 8 frames" } },
        { mod: "flow", title: "GMFlow + SE(3) solver", sub: "off-the-shelf, not trained", compact: true,
          input: { label: "Frame pairs + depth d₀", caption: "depth of the first frame only" },
          rows: [
            { t: "attn", label: "GMFlow (transformer)", call: ["Dense flow between adjacent frames", "p1"] },
            { t: "linear", label: "Solve rigid Tₜ per frame",
              zoom: { k: "rows", title: "Flow → robot command", rows: ["mask + depth d₀ → 3-D points", "track points with integrated flow", "RANSAC keeps inliers", "least squares: reprojection → Tₜ", "Tₜ applied to grasp → subgoals"] } } ],
          output: { label: "end-effector subgoals" } }
      ],
      links: [
        { from: "clip", to: "unet", toRow: "res", label: "pooled text" },
        { from: "unet", to: "flow", toRow: "input", label: "video" }
      ]
    },
    modules: [
      { id: "clip", role: "lang", name: "CLIP text + Perceiver", sub: "pooled into time emb.", col: 0, frozen: "partial", short: "CLIP text",
        note: "The CLIP text encoder is frozen; the Perceiver pool is trained." },
      { id: "unet", role: "video-gen", name: "Video U-Net", sub: "201M · 128 ch · 5 levels", col: 1, frozen: false, main: true, params: "201M", short: "Video U-Net",
        stack: { rows: [
          { t: "in", label: "7 noisy frames ‖ x₀ (channels)", dims: "128 × 128 × 6 per frame", c: "data-4" },
          { t: "group", label: "Down path (5 levels)", rows: [
            { t: "block", label: "Residual block", n: "2", rows: [{ t: "conv", label: "Conv2d 3×3 per frame → Conv1d over time", side: "cond" }, { t: "conv", label: "Conv2d 3×3 → Conv1d over time" }, { t: "add", span: 2 }] },
            { t: "conv", label: "Downsample", dims: "128 × (1, 2, 3, 4, 5) ch" } ] },
          { t: "attn", label: "Self-attention at res 8 and 16", dims: "32 ch per head" },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · residual blocks · upsample" }] },
          { t: "out", label: "v for 7 frames", dims: "100 sampling steps", c: "data-4" } ],
          facts: [["Params", ["201M (Meta-World)", "p2"]], ["Base channels", ["128 · mult (1, 2, 3, 4, 5)", "p2", "c1"]], ["Res blocks", ["2 per level", "p2", "c1"]], ["Frames", ["8 per clip incl. the current one", "c2"]], ["Objective", ["v-prediction, cosine β, min-SNR γ = 5", "p2"]], ["Training", ["60k steps, batch 16", "p2"]]] } },
      { id: "flow", role: "net", roleLabel: "Flow + geometry", name: "GMFlow + solver", sub: "frozen · closed-form SE(3)", col: 2, frozen: true, short: "GMFlow" }
    ],
    inputs: [
      { to: "clip", mod: "lang", label: "task text", n: "CLIP tokens", k: 3 },
      { to: "unet", mod: "vision", label: "current frame x₀", n: "128 × 128", k: 2 },
      { to: "unet", mod: "future", label: "noisy future frames", n: "7", k: 4, noisy: true },
      { to: "flow", mod: "other", label: "depth of x₀", n: "1 map", k: 1 }
    ],
    outputs: [{ from: "flow", mod: "action", label: "SE(3) subgoals", n: "grasp / push", k: 3 }],
    links: [
      { from: "clip", to: "unet", kind: "feeds", label: "pooled text|+ time embedding" },
      { from: "unet", to: "flow", kind: "two-stage", label: "video|→ flow → SE(3)" }
    ],
    callouts: [
      "§3.1 says the model predicts <b>T = 8 future frames</b>; the Meta-World code (sample_per_seq = 8) and App. H.1 count the current frame among the 8, so 7 frames are generated.",
      "The code comment calls the temporal convolution causal, but it pads symmetrically, so each frame sees its neighbours on both sides."
    ]
  });

  /* ------------------------------------------------------------------ SuSIE */
  var SU_C = "8177f63", BD_C = "bc60a35";
  RB.arch.spec({
    id: "susie", method: "susie", name: "SuSIE", year: 2023, parent: "unipi",
    figRef: "Black et al. Fig. 1 · §4 · App. A.1", prov: "Bridge / CALVIN configs",
    lede: "InstructPix2Pix, finetuned on robot and human video, edits the current image into a subgoal a dozen steps ahead. A language-free goal-conditioned diffusion policy then drives the arm there, and a new subgoal is drawn every 20 steps.",
    sources: {
      p1: { kind: "paper", ref: "Black et al. 2023, §4.1–4.3 and Alg. 1", url: AX("2310.10639") },
      p2: { kind: "paper", ref: "Black et al. 2023, App. A.1.1 (image-editing model)", url: AX("2310.10639") },
      p3: { kind: "paper", ref: "Black et al. 2023, App. A.1.2 (goal-reaching policy)", url: AX("2310.10639") },
      p4: { kind: "paper", ref: "Black et al. 2023, App. A, Table 5 (goal sampling)", url: AX("2310.10639") },
      c1: GH("kvablack/susie", SU_C, "configs/base.py"),
      c2: GH("kvablack/susie", SU_C, "susie/model.py"),
      c3: GH("rail-berkeley/bridge_data_v2", BD_C, "experiments/susie/calvin/configs/gcbc_train_config.py"),
      c4: GH("rail-berkeley/bridge_data_v2", BD_C, "jaxrl_m/networks/mlp.py")
    },
    summary: {
      pattern: ["Cascaded WAM: subgoal image, then goal-conditioned policy", "p1"],
      params: null,
      vision: ["Editor: Stable Diffusion v1.5 VAE latents. Policy: ResNet on stacked [obs ‖ goal]", "c1", "p3"],
      backbone: ["InstructPix2Pix latent U-Net; conv_in takes 8 channels (noisy ‖ current latents)", "p1", "c2"],
      head: ["Goal-conditioned diffusion policy: residual MLP, 3 blocks of width 256", "p3", "c3"],
      output: ["Subgoal 11–14 steps ahead (Bridge); chunks of 4 actions", "p4", "p3"],
      attention: ["U-Net cross-attention to CLIP text tokens (77 × 768)", "c2"],
      cond: ["Classifier-free guidance: image weight 2.5, text weight 7.5", "p2", "c1"],
      steps: ["Editor: 50 DDIM steps. Policy: 20 diffusion steps (released config)", "p2", "c3"],
      chunk: ["4 actions per call; the mean of the last 4 predictions is executed", "p3"],
      rate: ["New subgoal every k_test = 20 steps", "p4"],
      latency: null,
      train: ["Editor: 40k steps, batch 1024, one v4-64 TPU pod, 17 h; 60 % Something-Something + 40 % BridgeData V2", "p2"]
    },
    changes: [
      "Instead of a whole video, the generator makes <b>one subgoal image</b> a few seconds ahead.",
      "The generator is a pretrained <b>image editor</b> (InstructPix2Pix) finetuned on video frames, working in VAE latent space.",
      "The inverse dynamics model becomes a <b>goal-conditioned diffusion policy</b> that runs 20 closed-loop steps per subgoal.",
      "Human video (Something-Something) trains the editor; only the policy needs robot actions."
    ],
    diffRows: ["backbone", "head", "output", "steps", "chunk"],
    blueprint: {
      headline: "SuSIE: edit the image, then reach it",
      note: "The editor's U-Net sees the current image's latent as 4 extra input channels and the instruction through cross-attention. Its output is decoded by the VAE into a subgoal image, which is stacked with the live camera image and fed to a small diffusion policy.",
      towers: [
        { mod: "vae", title: "SD v1.5 VAE", sub: "frozen", compact: true,
          input: { label: "Current image 256²", caption: "robot camera" },
          rows: [{ t: "conv", label: "VAE encoder (frozen)", call: ["Latents with 4 channels", "c2"] }],
          output: { label: "current latent" } },
        { mod: "editor", title: "InstructPix2Pix U-Net", sub: "finetuned on robot + human video",
          input: { label: "Noisy latent ‖ current latent", caption: "4 + 4 channels" },
          rows: [
            { id: "cin", t: "conv", label: "conv_in (8 channels)", call: ["4 zero-initialized channels added to SD's conv_in", "c2"] },
            { t: "group", label: "Down path", rows: [
              { t: "conv", label: "ResNet block (time emb.)" },
              { t: "attn", label: "Self- + cross-attention", side: "text", call: ["Keys from CLIP text: 77 × 768", "c2"] } ] },
            { t: "group", label: "Up path (mirror)", rows: [
              { t: "conv", label: "Concat skip + ResNet block" },
              { t: "attn", label: "Self- + cross-attention" } ] },
            { t: "conv", label: "conv_out → ε (4 channels)", call: ["Image 2.5, text 7.5 guidance", "p2", "c1"],
              zoom: { k: "rows", title: "Two-way classifier-free guidance", rows: ["ε(∅ image, ∅ text)", "+ 2.5 × image direction", "+ 7.5 × text direction", "50 DDIM steps → subgoal latent"] } } ],
          output: { label: "subgoal latent → VAE decode" } },
        { mod: "policy", title: "Goal-conditioned policy", sub: "diffusion over 4-action chunks", compact: true,
          input: { label: "[obs ‖ subgoal] 6 ch", caption: "stacked on channels" },
          rows: [
            { t: "conv", label: "ResNet encoder", call: ["Paper: ResNet-50. Code: ResNet-34", "p3", "c3"] },
            { t: "pool", label: "Average pool" },
            { t: "mlp", label: "+ noisy actions, time emb.", call: ["Time embedding 32-d", "c3"] },
            { t: "block", n: "3", rows: [
              { t: "ffn", label: "LN · Dense 1,024 · swish" },
              { t: "linear", label: "Dense 256" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "→ ε for 4 actions", call: ["20 diffusion steps", "c3"],
              zoom: { k: "rows", title: "Test-time loop (Alg. 1)", rows: ["sample subgoal s⁺ from the editor", "predict 4 actions every step", "execute the mean of the last 4", "after 20 steps: new subgoal"] } } ],
          output: { label: "actions, temporally ensembled" } }
      ],
      links: [
        { from: "editor", to: "policy", toRow: "input", label: "subgoal image s⁺" },
        { from: "vae", to: "editor", toRow: "cin", label: "current latent" }
      ]
    },
    modules: [
      { id: "vae", role: "codec", name: "SD v1.5 VAE", sub: "image ↔ 4-ch latent", col: 0, frozen: true, short: "VAE" },
      { id: "editor", role: "video-gen", roleLabel: "Subgoal generator", name: "InstructPix2Pix U-Net", sub: "8-ch input · text x-attn", col: 1, frozen: false, main: true, short: "Editor",
        stack: { rows: [
          { t: "in", label: "noisy subgoal latent ‖ current latent", dims: "4 + 4 channels", c: "data-4" },
          { t: "conv", label: "conv_in widened to 8 channels", dims: "new channels zero-initialized" },
          { t: "group", label: "SD v1.5 U-Net down / mid / up", rows: [
            { t: "conv", label: "ResNet blocks with time embedding" },
            { t: "attn", label: "Self-attention · cross-attention to text", side: "text" } ] },
          { t: "conv", label: "conv_out", dims: "→ ε, 4 channels" },
          { t: "out", label: "subgoal latent", dims: "VAE-decoded to 256 × 256", c: "data-4" } ],
          facts: [["Init", ["InstructPix2Pix weights", "p1"]], ["Text encoder", ["SD v1.5 CLIP text, 77 × 768", "c1", "c2"]], ["Guidance", ["image 2.5, text 7.5", "p2"]], ["Sampler", ["DDIM, 50 steps", "p2", "c1"]], ["Subgoal distance", ["k ∈ [11, 14) steps (Bridge), [20, 22) (CALVIN)", "p4"]]] } },
      { id: "policy", role: "action-head", roleLabel: "Goal-reaching policy", name: "Goal-cond. diffusion policy", sub: "ResNet + MLP 3 × 256", col: 2, frozen: false, short: "Policy",
        stack: { rows: [
          { t: "in", label: "[obs ‖ subgoal], noisy 4-action chunk", dims: "256 × 256 images", c: "data-3" },
          { t: "conv", label: "ResNet encoder, early goal concat", dims: "ResNet-50 (paper) · ResNet-34 (code)" },
          { t: "block", label: "Residual MLP block", n: "3", rows: [{ t: "ffn", label: "LayerNorm · Dense 1024 · swish · Dense 256" }, { t: "add", span: 1 }] },
          { t: "out", label: "ε for 4 actions", dims: "20 diffusion steps (code)", c: "data-3" } ],
          facts: [["Chunk", ["4 actions, temporal ensembling", "p3"]], ["MLP", ["3 blocks, width 256", "p3", "c3"]], ["Training", ["445k steps, batch 256, v4-8 TPU, 15 h", "p3"]], ["Goal sampling", ["k_max + k_δ: uniform in [0, 20) (Bridge)", "p3"]]] } }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "current image", n: "256 × 256", k: 2 },
      { to: "editor", mod: "lang", label: "instruction", n: "77 tokens", k: 3 },
      { to: "editor", mod: "future", label: "noisy subgoal latent", n: "4 ch", k: 3, noisy: true },
      { to: "policy", mod: "action", label: "noisy actions", n: "4", k: 4, noisy: true }
    ],
    outputs: [{ from: "editor", mod: "future", label: "subgoal image s⁺", n: "1", k: 1 }, { from: "policy", mod: "action", label: "action chunk", n: "4", k: 4 }],
    links: [
      { from: "vae", to: "editor", kind: "latent", label: "current latent|concat on channels" },
      { from: "editor", to: "policy", kind: "two-stage", label: "subgoal image|every 20 steps" }
    ],
    callouts: [
      "App. A.1.2 says the goal-reaching policy uses a <b>ResNet-50</b> encoder; the released CALVIN config in bridge_data_v2 uses <b>resnetv1-34-bridge</b>.",
      "The high-level editor is in kvablack/susie; the low-level policy is the unmodified gc_ddpm_bc agent of BridgeData V2 with an action horizon of 4."
    ]
  });

  /* ------------------------------------------------------------------ GR-1 */
  var GR1_C = "4a2e956";
  RB.arch.spec({
    id: "gr-1", method: "gr-1", name: "GR-1", year: 2023,
    figRef: "Wu et al. Figs. 1–2 · §3.2 · App. A.1", prov: "CALVIN release (configs.json)",
    lede: "A small GPT-style transformer reads text, robot state and MAE image tokens over 10 steps. Learnable [ACT] and [OBS] query tokens read out the next action and, through an MAE-style decoder, the frame 3 steps ahead.",
    sources: {
      p1: { kind: "paper", ref: "Wu et al. 2023, §3.2 and Fig. 2", url: AX("2312.13139") },
      p2: { kind: "paper", ref: "Wu et al. 2023, App. A.1", url: AX("2312.13139") },
      p3: { kind: "paper", ref: "Wu et al. 2023, §3.3 (training)", url: AX("2312.13139") },
      c1: GH("bytedance/GR-1", GR1_C, "models/gr1.py"),
      c2: GH("bytedance/GR-1", GR1_C, "logs/configs.json"),
      c3: GH("bytedance/GR-1", GR1_C, "evaluation/calvin_evaluation.py"),
      c4: GH("bytedance/GR-1", GR1_C, "models/vision_transformer.py")
    },
    summary: {
      pattern: ["Autoregressive unified video-action model", "p1"],
      params: ["195M total, 46M trainable", "p2"],
      vision: ["Frozen MAE ViT-B/16 at 224 × 224: CLS + 9 resampled patch tokens per view", "p1", "c2", "c3"],
      backbone: ["GPT-2 causal transformer: 12 layers, width 384, 12 heads", "p2", "c2"],
      head: ["3-layer MLP → arm (6) and gripper (1)", "p2", "c1"],
      output: ["Next action aₜ + both views' frame 3 steps ahead", "p2", "c2"],
      attention: ["Causal; no token may attend to [ACT] or [OBS] queries", "p1", "c1"],
      cond: ["Frozen CLIP text token repeated at every timestep", "p1", "c2"],
      steps: ["None: one forward pass per step", "p1"],
      chunk: ["One action per step; 10-step history", "p2", "c2"],
      rate: null, latency: null,
      train: ["Pretrain on 800k Ego4D clips (8M frames), then finetune on robot data", "p3"]
    },
    blueprint: {
      headline: "GR-1: predict the next frame and action",
      note: "Per timestep the sequence holds text, state, 10 static-view and 10 wrist-view image tokens, one [ACT] and 20 [OBS] queries. The 12-layer causal GPT runs once; [ACT] goes to an MLP, [OBS] plus 196 mask tokens go to a 2-layer decoder that reconstructs pixels.",
      towers: [
        { mod: "mae", title: "MAE ViT-B/16", sub: "frozen, per view", compact: true,
          input: { label: "Image 224 × 224", caption: "static + wrist cameras" },
          rows: [
            { t: "embed", label: "Patch embed 16 × 16", call: ["196 patches, width 768", "c3", "c4"] },
            { t: "block", n: "12", rows: [{ t: "attn", label: "MHA (12 heads)" }, { t: "ffn", label: "MLP" }] },
            { t: "attn", label: "Perceiver resampler", call: ["9 latents, depth 3, 4 heads × 128", "c2"] },
            { t: "linear", label: "Linear 768 → 384", call: ["CLS + 9 patch tokens per view", "c1"] } ],
          output: { label: "10 tokens per view" } },
        { mod: "gpt", title: "GR-1 transformer", sub: "GPT-2 style, causal",
          input: { label: "Token sequence", caption: "[ℓ, s, img, [ACT], [OBS]] × 10 steps" },
          rows: [
            { t: "embed", label: "Modality linears + step emb.", call: ["43 tokens per step, 10 steps", "c1", "c2"],
              zoom: { k: "rows", title: "Tokens per timestep", rows: ["text ℓ (CLIP) · 1", "state s (arm + gripper) · 1", "static view: CLS + 9 · 10", "wrist view: CLS + 9 · 10", "[ACT] · 1, [OBS] · 20"] } },
            { t: "norm", label: "LayerNorm" },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Masked causal self-attention", call: ["12 heads, width 384", "p2", "c2"], zoom: { k: "heads", q: 12, kv: 12, hd: 32, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (ReLU)", call: ["Hidden layer dimension of 1,536", "c3", "c2"], zoom: { k: "mlp", act: "ReLU", d: "384", ff: "1,536", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "mlp", label: "[ACT] → action MLP", call: ["384 → 192 → 192 → 6 + 1", "c1"],
              zoom: { k: "rows", title: "Action head", rows: ["[ACT] output, 384", "Linear 192 · ReLU", "Linear 192 · ReLU", "arm 6 · gripper 1"] } } ],
          output: { label: "aₜ and [OBS] features" } },
        { mod: "dec", title: "Image decoder", sub: "MAE-style, 2 blocks", compact: true,
          input: { label: "[OBS] outputs + masks", caption: "196 mask tokens, sin-cos position" },
          rows: [
            { t: "linear", label: "decoder_embed 384 → 384", call: ["20 [OBS] + 196 mask tokens", "c1"] },
            { t: "block", n: "2", rows: [{ t: "attn", label: "Self-attention" }, { t: "ffn", label: "MLP" }] },
            { t: "linear", label: "Linear → 16 × 16 × 3", call: ["16 heads; normalized-pixel MSE", "c1", "p2"] } ],
          output: { label: "frame at t + 3, per view" } }
      ],
      links: [
        { from: "gpt", to: "dec", toRow: "input", label: "[OBS] outputs" },
        { from: "mae", to: "gpt", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "mae", role: "vision-enc", name: "MAE ViT-B/16", sub: "frozen · + resampler", col: 0, frozen: true, short: "MAE ViT",
        note: "The Perceiver resampler after the frozen ViT is trained." },
      { id: "gpt", role: "joint", roleLabel: "Causal video-action GPT", name: "GR-1 transformer", sub: "12 × 384 · 12 heads", col: 1, frozen: false, main: true, short: "GPT",
        stack: { rows: [
          { t: "in", label: "[ℓ, s, static 10, wrist 10, [ACT], [OBS] 20]", dims: "× 10 timesteps", c: "data-4" },
          { t: "embed", label: "Per-modality linear + learned timestep embedding", dims: "→ 384" },
          { t: "norm", label: "LayerNorm" },
          { t: "block", label: "GPT-2 block", n: "12", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "Causal MHA, 12 heads · [ACT]/[OBS] keys masked" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 384 → 1536 → 384 · ReLU" }, { t: "add", span: 2 } ] },
          { t: "out", label: "[ACT] → action MLP · [OBS] → image decoder", dims: "one pass per control step", c: "data-4" } ],
          facts: [["Width / depth / heads", ["384 / 12 / 12", "p2", "c2"]], ["MLP", ["1536, ReLU", "c3", "c2"]], ["History", ["10 timesteps", "p2", "c2"]], ["Future frame", ["Δt = 3 when finetuning (1 in pretraining)", "p2"]], ["Resampler", ["9 latents, depth 3", "c2"]], ["Trainable", ["46M of 195M", "p2"]]] } },
      { id: "dec", role: "video-gen", roleLabel: "Future-frame decoder", name: "Image decoder", sub: "2 blocks · 16 heads", col: 2, frozen: false, short: "Decoder" }
    ],
    inputs: [
      { to: "mae", mod: "vision", label: "static + wrist images", n: "10 steps", k: 4 },
      { to: "gpt", mod: "lang", label: "instruction", n: "1 / step", k: 2 },
      { to: "gpt", mod: "state", label: "state", n: "1 / step", k: 2 }
    ],
    outputs: [{ from: "gpt", mod: "action", label: "next action aₜ", n: "6 + 1", k: 2 }, { from: "dec", mod: "future", label: "frame t + 3", n: "per view", k: 3 }],
    links: [
      { from: "mae", to: "gpt", kind: "prefix", label: "linear → 384|10 tokens / view" },
      { from: "gpt", to: "dec", kind: "feeds", label: "[OBS] outputs|+ 196 mask tokens" }
    ],
    mask: { name: "Causal, queries hidden", ref: "p1", axes: [{ label: "inputs", short: "in", mod: "vision" }, { label: "[ACT] query", short: "ACT", mod: "action" }, { label: "[OBS] queries", short: "OBS", mod: "future" }], m: ["100", "100", "100"],
      note: "Every token also sees earlier timesteps' inputs. No token may attend to [ACT] or [OBS], so the queries read the context without leaking into it." },
    callouts: [
      "OpenWAM calls this pattern <b>autoregressive</b>: one causal transformer predicts the next frame and the next action from the same history."
    ]
  });

  /* ------------------------------------------------------------------ GR-2 */
  RB.arch.spec({
    id: "gr-2", method: "gr-2", name: "GR-2", year: 2024, parent: "gr-1",
    figRef: "Cheang et al. Fig. 1 · §2 · §3.5", prov: "",
    lede: "GR-1 scaled up: a GPT-style transformer over frozen VQGAN image tokens is pretrained to predict future frames of 38M text-video clips, then finetuned to predict every view's next frame and a cVAE action trajectory.",
    sources: {
      p1: { kind: "paper", ref: "Cheang et al. 2024, §2.1 (model and training)", url: AX("2410.06158") },
      p2: { kind: "paper", ref: "Cheang et al. 2024, §2.2 (real-robot system, WBC)", url: AX("2410.06158") },
      p3: { kind: "paper", ref: "Cheang et al. 2024, §3 (default model size)", url: AX("2410.06158") },
      p4: { kind: "paper", ref: "Cheang et al. 2024, §3.5 (scaling)", url: AX("2410.06158") }
    },
    summary: {
      pattern: ["Autoregressive unified video-action model", "p1"],
      params: ["230M default, 95M trainable; trainable variants 30M / 95M / 312M / 719M", "p3", "p4"],
      vision: ["Frozen VQGAN (internet + robot data) turns each frame into discrete tokens", "p1"],
      backbone: ["GPT-style transformer; depth, width and heads not stated", "p1"],
      head: ["Conditional VAE generates the action trajectory", "p1"],
      output: ["Next frame for each view + Cartesian trajectory aₜ:ₜ₊ₖ", "p1"],
      attention: null,
      cond: ["Frozen CLIP text encoder", "p1"],
      steps: null,
      chunk: ["Trajectory of k actions (k not stated)", "p1"],
      rate: ["Whole-body control tracks the trajectory; joint commands at 200 Hz", "p2"],
      latency: null,
      train: ["Pretrain on 38M clips (≈ 50B tokens), then finetune on robot trajectories", "p1"]
    },
    changes: [
      "Images become <b>discrete VQGAN tokens</b> instead of MAE features, so the transformer predicts tokens rather than pixels.",
      "Pretraining grows from 0.8M Ego4D clips to <b>38M clips</b> from several video and robot datasets.",
      "Single-step actions give way to a <b>cVAE action trajectory</b>, tracked by whole-body control.",
      "Model sizes from 30M to 719M trainable parameters were trained; success grows with size."
    ],
    diffRows: ["params", "vision", "head", "output", "train"],
    blueprint: {
      headline: "GR-2: tokens in, frames and trajectories out",
      note: "The paper discloses the pipeline, not the layers. Frozen VQGAN tokens, CLIP text and linear state embeddings form one sequence for a GPT-style transformer; its outputs are decoded into next-frame tokens per view and, through a cVAE, into an end-effector trajectory.",
      towers: [
        { mod: "vq", title: "VQGAN", sub: "frozen, internet + robot data", compact: true,
          input: { label: "Frames, each view", caption: "head + wrist cameras" },
          rows: [
            { t: "conv", label: "VQGAN encoder" },
            { t: "embed", label: "Codebook lookup → tokens", note: "Codebook size and tokens per frame not stated" } ],
          output: { label: "discrete image tokens" } },
        { mod: "gpt", title: "GR-2 transformer", sub: "GPT-style; sizes not stated",
          input: { label: "Text, image, state tokens", caption: "language ℓ, oₜ₋ₕ:ₜ, sₜ₋ₕ:ₜ" },
          rows: [
            { t: "embed", label: "Token + state embeddings", call: ["State: linear layers, trainable in finetuning", "p1"] },
            { t: "block", n: "N", label: "layers not stated", rows: [
              { t: "attn", label: "Causal self-attention" },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "Next-token head", call: ["38M clips ≈ 50B tokens pretraining", "p1"],
              zoom: { k: "rows", title: "Model sizes (trainable)", rows: ["GR-2-S · 30M", "GR-2-B · 95M (default, 230M total)", "GR-2-L · 312M", "GR-2-XL · 719M"] } } ],
          output: { label: "next-frame tokens per view" } },
        { mod: "cvae", title: "cVAE action head", sub: "trajectory generator", compact: true,
          input: { label: "Transformer features", caption: "action readout" },
          rows: [
            { t: "mlp", label: "cVAE decoder", note: "Architecture not stated" },
            { t: "linear", label: "Trajectory aₜ:ₜ₊ₖ",
              zoom: { k: "rows", title: "Deployment", rows: ["cVAE trajectory, Cartesian space", "smoothed by trajectory opt.", "whole-body control", "joint actions at 200 Hz"] } } ],
          output: { label: "end-effector trajectory" } }
      ],
      links: [
        { from: "gpt", to: "cvae", toRow: "input", label: "features" },
        { from: "vq", to: "gpt", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "vq", role: "codec", name: "VQGAN", sub: "frozen · discrete tokens", col: 0, frozen: true, short: "VQGAN" },
      { id: "gpt", role: "joint", roleLabel: "Causal video-action GPT", name: "GR-2 transformer", sub: "95M trainable (default)", col: 1, frozen: false, main: true, params: "95M trainable", short: "GPT" },
      { id: "cvae", role: "action-head", name: "cVAE action head", sub: "→ Cartesian trajectory", col: 2, frozen: false, short: "cVAE" }
    ],
    inputs: [
      { to: "vq", mod: "vision", label: "multi-view frames", n: "history h", k: 4 },
      { to: "gpt", mod: "lang", label: "instruction", n: "CLIP", k: 2 },
      { to: "gpt", mod: "state", label: "state", n: "per step", k: 2 }
    ],
    outputs: [{ from: "gpt", mod: "future", label: "next frame per view", n: "VQ tokens", k: 3 }, { from: "cvae", mod: "action", label: "trajectory aₜ:ₜ₊ₖ", n: "k steps", k: 4 }],
    links: [
      { from: "vq", to: "gpt", kind: "prefix", label: "VQ tokens|join the sequence" },
      { from: "gpt", to: "cvae", kind: "feeds", label: "features|→ trajectory" }
    ],
    callouts: [
      "No official code or weights were released, and the report gives no layer-level details: depth, width, heads, codebook size and chunk length k are <b>not stated</b>.",
      "In the scaling study the pretrained weights were kept frozen while finetuning on robot trajectories (§3.5)."
    ]
  });

  /* ------------------------------------------------------------------ PAD */
  var PAD_C = "a0bdc12";
  RB.arch.spec({
    id: "pad", method: "pad", name: "PAD", year: 2024, parent: "susie",
    figRef: "Guo et al. Fig. 3 · §3.2 · App. A.1, Table 4", prov: "PAD-XL/2 (default)",
    lede: "One ImageNet-initialized DiT denoises three future frames' VAE latents and a token holding three future poses together. The current observation rides along as extra input channels; CLIP text and the step set AdaLN.",
    sources: {
      p1: { kind: "paper", ref: "Guo et al. 2024, §3.2 and Fig. 3", url: AX("2411.18179") },
      p2: { kind: "paper", ref: "Guo et al. 2024, §4.1 (training and execution)", url: AX("2411.18179") },
      p3: { kind: "paper", ref: "Guo et al. 2024, Table 3 and App. A.2.1, Table 4", url: AX("2411.18179") },
      p4: { kind: "paper", ref: "Guo et al. 2024, App. A.1.1 (encoders)", url: AX("2411.18179") },
      p5: { kind: "paper", ref: "Guo et al. 2024, §3.3 (initialization)", url: AX("2411.18179") },
      c1: GH("Robert-gyj/Prediction_with_Action", PAD_C, "models.py"),
      c2: GH("Robert-gyj/Prediction_with_Action", PAD_C, "exp.sh")
    },
    summary: {
      pattern: ["Single-system joint DiT (video + action in one sequence)", "p1"],
      params: ["661M (XL/2, default); 449M (L/2); 128M (B/2)", "p3"],
      vision: ["Frozen SD VAE: 256 × 256 → 32 × 32 × 4; current latent concatenated on channels", "p4", "p1"],
      backbone: ["DiT-XL/2: 28 layers, width 1152, 16 heads, AdaLN-Zero", "p3", "c1"],
      head: ["Separate AdaLN final layers: unpatchify for images, linear for the pose token", "c1"],
      output: ["k = 3 future frames + 3 future poses; only the first pose is executed", "p2"],
      attention: ["Full attention with padding masked for missing modalities (see callout)", "p1", "c1"],
      cond: ["AdaLN from emb(t) + Linear(CLIP text, 512 → 1152)", "c1"],
      steps: ["75 DDIM steps per control step", "p2"],
      chunk: ["k = 3 at a frame interval of 4; replan after each pose", "p2"],
      rate: null, latency: null,
      train: ["200k steps on BridgeData V2 (60k trajectories), then 100k per domain; 4 A100s", "p2"]
    },
    changes: [
      "Subgoal generation and action are no longer two models: <b>one DiT</b> denoises future frames and future poses together.",
      "The U-Net image editor gives way to an ImageNet <b>DiT</b>; images become 256 patch tokens and the poses one extra token.",
      "The current observation enters as extra <b>input channels</b> of every patch, not as a separate image.",
      "Language moves from cross-attention to <b>AdaLN</b> (CLIP text added to the step embedding).",
      "Video without actions can be co-trained by masking the missing tokens."
    ],
    diffRows: ["backbone", "head", "output", "attention", "cond", "steps"],
    blueprint: {
      headline: "PAD: one DiT for frames and poses",
      note: "The VAE latent of the current image is stacked with 3 noisy future latents into 16 channels, then patchified into 256 tokens; one linear layer turns current + noisy poses into a 257th token. 28 AdaLN-Zero blocks follow; separate final layers split frames from poses.",
      towers: [
        { mod: "clip", title: "CLIP text", sub: "frozen + trained linear", compact: true,
          input: { label: "Instruction", caption: "e.g. “pick red block”" },
          rows: [
            { t: "embed", label: "CLIP text encoder", call: ["512-d embedding", "c1"] },
            { t: "linear", label: "Linear 512 → 1,152", call: ["+ timestep MLP (256-d freq.)", "c1"] } ],
          output: { label: "c = emb(t) + text" } },
        { mod: "dit", title: "PAD DiT-XL/2", sub: "joint image + pose denoiser, 661M",
          input: { label: "Latents ‖ noisy futures, poses", caption: "32 × 32 × 16 · (k + 1) × 7" },
          rows: [
            { t: "conv", label: "Patchify 2 × 2", call: ["16 channels → 256 image tokens", "p3", "p4"],
              zoom: { k: "rows", title: "Channel-wise conditioning", rows: ["current latent 32 × 32 × 4", "‖ 3 noisy future latents (12 ch)", "= 32 × 32 × 16", "patchify 2 × 2 → 256 tokens"] } },
            { t: "linear", label: "Pose linear → 1 token", call: ["(3 + 1) × 7 = 28 → 1,152", "p4", "c1"] },
            { t: "embed", label: "+ sin-cos position", call: ["257 tokens in total", "p3"] },
            { t: "block", n: "28", rows: [
              { id: "n1", t: "norm", label: "LayerNorm 1 · shift, scale", side: "AdaLN",
                zoom: { k: "rows", title: "AdaLN-Zero modulation", rows: ["c = emb(t) + Linear(CLIP text)", "SiLU → Linear → 6 × 1,152", "shift, scale, gate for attention", "shift, scale, gate for MLP"] } },
              { t: "attn", label: "Masked self-attention", call: ["16 heads, width 1,152", "p3"], zoom: { k: "heads", q: 16, kv: 16, hd: 72, title: "Attention heads" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 },
              { t: "norm", label: "LayerNorm 2 · shift, scale", side: "AdaLN" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 4,608", "c1"], zoom: { k: "mlp", act: "GELU (tanh)", d: "1,152", ff: "4,608", title: "Feed forward (MLP)" } },
              { t: "adaln", label: "× gate" },
              { t: "add", span: 3 } ] },
            { t: "norm", label: "AdaLN final layers ×2", call: ["One for images, one for the pose token", "c1"] },
            { t: "linear", label: "Unpatchify · pose linear", call: ["Learned σ: outputs doubled", "c1"] } ],
          output: { label: "ε for 3 frames and 3 poses" } },
        { mod: "vae", title: "SD VAE", sub: "frozen, as in DiT", compact: true,
          input: { label: "RGB 256 × 256", caption: "current + future frames" },
          rows: [{ t: "conv", label: "VAE encoder (frozen)", call: ["→ 32 × 32 × 4 latent", "p4"] }],
          output: { label: "latents" } }
      ],
      links: [
        { from: "vae", to: "dit", toRow: "input", label: "latents" },
        { from: "clip", to: "dit", toRow: "n1", label: "cond c" }
      ]
    },
    modules: [
      { id: "vae", role: "codec", name: "SD VAE", sub: "256² × 3 → 32² × 4", col: 0, frozen: true, short: "VAE" },
      { id: "dit", role: "joint", roleLabel: "Joint image + pose DiT", name: "PAD DiT-XL/2", sub: "28 × 1152 · 16 heads", col: 1, frozen: false, main: true, params: "661M", short: "DiT",
        stack: { rows: [
          { t: "in", label: "[256 image tokens | 1 pose token (| 16 depth)]", dims: "current obs in the channels", c: "data-4" },
          { t: "conv", label: "Patchify 2 × 2 on 16-ch latent", dims: "→ 256 × 1152" },
          { t: "linear", label: "Pose linear: 28 → 1152", dims: "current + 3 noisy poses" },
          { t: "block", label: "DiT block (AdaLN-Zero)", n: "28", rows: [
            { t: "norm", label: "LayerNorm (no affine) · shift, scale" }, { t: "attn", label: "MHA · 16 heads · masked" }, { t: "adaln", label: "× gate", side: "cond" }, { t: "add", span: 3 },
            { t: "norm", label: "LayerNorm (no affine) · shift, scale" }, { t: "ffn", label: "MLP 1152 → 4608 → 1152 · GELU" }, { t: "adaln", label: "× gate", side: "cond" }, { t: "add", span: 3 } ] },
          { t: "norm", label: "AdaLN final layer per modality" },
          { t: "out", label: "ε (and σ) for 3 frames · 3 poses", dims: "75 DDIM steps", c: "data-4" } ],
          facts: [["Width / depth / heads", ["1152 / 28 / 16", "p3", "c1"]], ["Patch", ["2 × 2 on 32 × 32 × 16", "p3"]], ["Tokens", ["256 image + 1 pose = 257", "p3"]], ["Depth tokens", ["32 × 32 map, patch 8 → 16 tokens (real world)", "p4"]], ["Init", ["ImageNet class-conditional DiT; new layers zero-initialized", "p5"]], ["Loss weights", ["λ_I = 1; λ_A, λ_E ramp 0 → 2", "p2"]]] } },
      { id: "clip", role: "lang", name: "CLIP text", sub: "512 → 1152 · AdaLN", col: 2, frozen: "partial", short: "CLIP" }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "current + future RGB", n: "256 × 256", k: 3 },
      { to: "dit", mod: "future", label: "noisy future latents", n: "k = 3", k: 3, noisy: true },
      { to: "dit", mod: "action", label: "pose token", n: "(k + 1) × 7", k: 1, noisy: true },
      { to: "clip", mod: "lang", label: "instruction", n: "CLIP", k: 2 }
    ],
    outputs: [{ from: "dit", mod: "future", label: "3 frames", n: "k = 3", k: 3 }, { from: "dit", mod: "action", label: "3 poses", n: "1st run", k: 3 }],
    links: [
      { from: "vae", to: "dit", kind: "latent", label: "latents|patchify 2 × 2" },
      { from: "clip", to: "dit", kind: "adaln", label: "text + step|AdaLN" }
    ],
    mask: { name: "Images blind to poses (code)", ref: "c1", axes: [{ label: "image tokens", short: "img", mod: "future" }, { label: "pose token", short: "a", mod: "action" }, { label: "depth tokens", short: "d", mod: "other" }], m: ["100", "111", "111"],
      note: "The released Meta-World script sets --attn_mask: image tokens cannot attend to the pose or depth tokens, while those see everything." },
    callouts: [
      "Paper §3.2 masks attention only to drop <b>missing</b> modalities; the released code's <b>--attn_mask</b> flag (on in exp.sh) also stops image tokens from attending to the pose and depth tokens.",
      "OpenWAM calls this pattern Single-System Vanilla: one DiT carries video and action tokens and must denoise both at every control step."
    ]
  });

  /* ------------------------------------------------------------------ VPP */
  var VPP_C = "75cf37a";
  RB.arch.spec({
    id: "vpp", method: "vpp", name: "VPP", year: 2024, parent: "unipi",
    figRef: "Hu, Guo et al. Fig. 2 · §4 · Table 13", prov: "CALVIN config",
    lede: "A Stable Video Diffusion model finetuned on manipulation video runs a single denoising pass per camera. Its up-sampling features, squeezed into 224 tokens by a Video Former, condition a small diffusion transformer that outputs 10 actions.",
    sources: {
      p1: { kind: "paper", ref: "Hu, Guo et al. 2025, §4.1 (TVP model)", url: AX("2412.14803") },
      p2: { kind: "paper", ref: "Hu, Guo et al. 2025, §4.2 (predictive representation, Video Former, action head)", url: AX("2412.14803") },
      p3: { kind: "paper", ref: "Hu, Guo et al. 2025, App. C.1, Table 13", url: AX("2412.14803") },
      p4: { kind: "paper", ref: "Hu, Guo et al. 2025, §5.1 (roll-out) and Table 4", url: AX("2412.14803") },
      p5: { kind: "paper", ref: "Hu, Guo et al. 2025, App. B, Table 8 (video data)", url: AX("2412.14803") },
      c1: GH("roboterax/video-prediction-policy", VPP_C, "policy_conf/VPP_Calvinabc_train.yaml"),
      c2: GH("roboterax/video-prediction-policy", VPP_C, "policy_models/VPP_policy.py"),
      c3: GH("roboterax/video-prediction-policy", VPP_C, "policy_models/module/diffusion_extract.py"),
      c4: GH("roboterax/video-prediction-policy", VPP_C, "policy_models/edm_diffusion/score_wrappers.py"),
      c5: GH("roboterax/video-prediction-policy", VPP_C, "policy_models/module/diffusion_decoder.py")
    },
    summary: {
      pattern: ["Dual-system WAM: cross-attention", "p2"],
      params: ["1.5B video model (Stable Video Diffusion); policy head not stated", "p1"],
      vision: ["SVD U-Net at 256 × 256, one forward pass per camera; up-block features stacked", "p1", "p2"],
      backbone: ["Stable Video Diffusion + CLIP text cross-attention, predicting 16 frames", "p1"],
      head: ["Diffusion transformer: 4 encoder + 4 decoder layers, width 384, 8 heads", "p3", "c4"],
      output: ["10-step action chunk (7-D arm; 18-D arm + Xhand)", "p3"],
      attention: ["Video Former: per-frame spatial cross-attention, then temporal attention", "p2"],
      cond: ["Policy cross-attends to 224 Video-Former tokens + language (225 × 384)", "p3", "c1"],
      steps: ["Video model: 1 forward pass, no denoising loop. Policy: 10 DDIM steps", "p2", "c1"],
      chunk: ["10 actions per call", "p4", "p3"],
      rate: ["7–10 Hz on an RTX 4090", "p4"],
      latency: ["≈ 140 ms per step; the video pass takes < 160 ms", "p4"],
      train: ["Video model finetuned on 375k trajectories (SSv2, OXE subsets, CALVIN, own), then frozen", "p5", "p1"]
    },
    changes: [
      "The video model is never sampled: <b>one forward pass</b> at a fixed noise level gives features that already contain the rough future.",
      "The separate inverse dynamics model becomes a <b>diffusion transformer policy</b> that cross-attends to those features.",
      "A <b>Video Former</b> compresses multi-layer, multi-view features into 16 × 14 tokens.",
      "The video model is a pretrained <b>Stable Video Diffusion</b> (1.5B) finetuned on human and robot manipulation video."
    ],
    diffRows: ["params", "backbone", "head", "steps", "rate", "latency"],
    blueprint: {
      headline: "VPP: one video pass as encoder",
      note: "The current frame goes into SVD with pure noise; after one pass, the first two up-sampling blocks' feature maps are resized and stacked. A 6-layer Video Former turns them into 224 tokens, which the policy transformer's decoder reads by cross-attention while denoising 10 actions.",
      towers: [
        { mod: "tvp", title: "SVD video U-Net", sub: "finetuned TVP, 1.5B, frozen in stage 2",
          input: { label: "Current frame ‖ noise", caption: "256 × 256, 16 frames, per camera" },
          rows: [
            { t: "conv", label: "VAE latent ‖ noised latent", call: ["Current frame concat on channels", "p1"] },
            { t: "group", label: "Down path", rows: [
              { t: "conv", label: "Spatio-temporal res blocks" },
              { t: "attn", label: "Cross-attention to text", side: "text", call: ["CLIP text 20 × 512", "p3", "c2"] } ] },
            { t: "group", label: "Up path, first 2 blocks", rows: [
              { t: "conv", label: "Up-block 1" },
              { t: "conv", label: "Up-block 2", call: ["1,280 + 1,280 channels stacked", "c2", "c3"] } ] },
            { t: "pool", label: "Resize + stack features",
              zoom: { k: "rows", title: "Predictive features", rows: ["frame ‖ pure-noise latent", "one SVD forward pass", "up-block outputs, 16 frames", "interpolate to one size", "stack on channels"] } } ],
          output: { label: "features T × C × H × W" } },
        { mod: "former", title: "Video Former", sub: "aggregates space, time, views", compact: true,
          input: { label: "Learnable tokens", caption: "16 frames × 14" },
          rows: [
            { t: "embed", label: "Queries 16 × 14", call: ["224 tokens, width 384", "p3", "c1"] },
            { id: "sp", t: "block", n: "6", rows: [
              { t: "attn", label: "Spatial x-attn per frame" },
              { t: "attn", label: "Temporal self-attention" },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "8 heads × 64", call: ["Attention inner width 512", "p3", "c1"] } ],
          output: { label: "224 tokens" } },
        { mod: "policy", title: "Diffusion transformer", sub: "EDM-style action denoiser",
          input: { label: "Noisy actions 10 × 7", caption: "+ noise level σ" },
          rows: [
            { id: "enc", t: "block", n: "4", label: "Encoder", rows: [
              { t: "attn", label: "Self-attn on 225 cond. tokens", call: ["Width 384, 8 heads", "p3", "c4"], zoom: { k: "heads", q: 8, kv: 8, hd: 48, title: "Policy attention heads" } },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "block", n: "4", label: "Decoder", rows: [
              { t: "adaln", label: "AdaLN-Zero from σ", side: "AdaLN" },
              { t: "attn", label: "Self-attention (actions)" },
              { t: "attn", label: "Cross-attn to encoder" },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "→ denoised 10 actions", call: ["10 DDIM steps", "c1", "p3"],
              zoom: { k: "rows", title: "Two-stage training", rows: ["stage 1: finetune SVD", "freeze the video model", "stage 2: train Former + policy", "act: 1 video pass + 10 DDIM"] } } ],
          output: { label: "action chunk, 10 steps" } }
      ],
      links: [
        { from: "tvp", to: "former", toRow: "sp", label: "features" },
        { from: "former", to: "policy", toRow: "enc", label: "224 tokens" }
      ]
    },
    modules: [
      { id: "tvp", role: "video-gen", roleLabel: "Video model (encoder)", name: "SVD video U-Net", sub: "1.5B · 16 × 256 × 256", col: 0, frozen: true, params: "1.5B", short: "SVD",
        note: "Finetuned in stage 1, frozen while the policy trains.",
        stack: { rows: [
          { t: "in", label: "VAE latent of current frame ‖ noise", dims: "16 frames, per camera", c: "data-1" },
          { t: "group", label: "SVD U-Net down path", rows: [{ t: "conv", label: "Spatio-temporal res blocks" }, { t: "attn", label: "Cross-attention to CLIP text", side: "text" }] },
          { t: "group", label: "Up path (first 2 blocks kept)", rows: [{ t: "conv", label: "Up-block outputs, 1280 ch each" }] },
          { t: "pool", label: "Interpolate to one size, stack on channels" },
          { t: "out", label: "predictive features", dims: "no denoising loop", c: "data-4" } ],
          facts: [["Base", ["Stable Video Diffusion, 1.5B", "p1"]], ["Output video", ["16 × 256 × 256", "p1"]], ["Text", ["CLIP, 20 × 512 tokens", "p3", "c2"]], ["Timestep used", ["20 (config)", "c1"]], ["Video data", ["375,192 trajectories", "p5"]]] } },
      { id: "former", role: "fusion", roleLabel: "Video Former", name: "Video Former", sub: "6 layers · 224 tokens", col: 1, frozen: false, short: "Former" },
      { id: "policy", role: "action-head", name: "Diffusion transformer", sub: "4 + 4 layers · 384 · 8 h", col: 2, frozen: false, main: true, short: "Policy",
        stack: { rows: [
          { t: "in", label: "noisy 10-action chunk, σ", dims: "10 × 7 (CALVIN)", c: "data-3" },
          { t: "block", label: "Encoder", n: "4", rows: [{ t: "attn", label: "Self-attention over [lang ‖ 224 tokens]" }, { t: "ffn", label: "MLP" }] },
          { t: "block", label: "Decoder", n: "4", rows: [{ t: "adaln", label: "AdaLN-Zero from σ", side: "cond" }, { t: "attn", label: "Self-attention over actions" }, { t: "attn", label: "Cross-attention to encoder output" }, { t: "ffn", label: "MLP" }] },
          { t: "out", label: "denoised actions", dims: "10 DDIM steps", c: "data-3" } ],
          facts: [["Width / heads", ["384 / 8", "p3", "c4"]], ["Layers", ["4 encoder + 4 decoder", "p3", "c4"]], ["Condition", ["225 × 384 tokens", "p3"]], ["Sampler", ["DDIM, 10 steps; σ ∈ [0.001, 80]", "c1"]], ["Chunk", ["10 actions", "p3"]]] } }
    ],
    inputs: [
      { to: "tvp", mod: "vision", label: "current frame per camera", n: "256 × 256", k: 2 },
      { to: "tvp", mod: "lang", label: "instruction (CLIP)", n: "20 tokens", k: 3 },
      { to: "policy", mod: "action", label: "noisy actions", n: "10", k: 4, noisy: true }
    ],
    outputs: [{ from: "policy", mod: "action", label: "action chunk", n: "10 × 7", k: 4 }],
    links: [
      { from: "tvp", to: "former", kind: "latent", label: "up-block features|1 forward pass" },
      { from: "former", to: "policy", kind: "cross-attn", label: "224 tokens|+ language" }
    ],
    callouts: [
      "App. C.1 (Table 13) gives the Video Former input as <b>1,280</b> channels; the released CALVIN config (use_all_layer, extract_layer_idx = 1) stacks two up-block outputs, <b>1,280 + 1,280 = 2,560</b> channels.",
      "OpenWAM would place VPP between cascaded and dual-system: the video model is frozen and never sampled, but the policy reads its internal features instead of generated frames."
    ]
  });

  /* ------------------------------------------------------------------ Seer */
  var SEER_C = "ee228e1";
  RB.arch.spec({
    id: "seer", method: "seer", name: "Seer", year: 2024, parent: "gr-1",
    figRef: "Tian, Yang et al. Fig. 2 · §3 · App. A", prov: "Seer (standard), CALVIN ABC-D",
    lede: "A GPT-2 transformer over MAE image, text and state tokens carries two kinds of readout tokens: [FRS] predicts the future frame, and [INV] predicts the next 3 actions while attending to [FRS], so the action is inverse dynamics on a predicted future.",
    sources: {
      p1: { kind: "paper", ref: "Tian, Yang et al. 2024, §3.2–3.3 and Fig. 2", url: AX("2412.15109") },
      p2: { kind: "paper", ref: "Tian, Yang et al. 2024, App. A.1 (implementation)", url: AX("2412.15109") },
      p3: { kind: "paper", ref: "Tian, Yang et al. 2024, App. A.2, Table A-II, Fig. A-1", url: AX("2412.15109") },
      p4: { kind: "paper", ref: "Tian, Yang et al. 2024, App. A.1, Table A-I", url: AX("2412.15109") },
      p5: { kind: "paper", ref: "Tian, Yang et al. 2024, §3.4 (model size)", url: AX("2412.15109") },
      c1: GH("InternRobotics/Seer", SEER_C, "models/seer_model.py"),
      c2: GH("InternRobotics/Seer", SEER_C, "scripts/CALVIN_ABC_D/Seer/finetune.sh"),
      c3: GH("InternRobotics/Seer", SEER_C, "utils/arguments_utils.py"),
      c4: GH("InternRobotics/Seer", SEER_C, "scripts/CALVIN_ABC_D/Seer-Large/finetune.sh")
    },
    summary: {
      pattern: ["Autoregressive unified video-action model", "p1"],
      params: ["316M total, 65M trainable; Seer-Large 315M trainable", "p5", "p2"],
      vision: ["Frozen MAE ViT-B/16 at 224 × 224; resampler → 6 tokens + CLS per view", "p2", "c2"],
      backbone: ["GPT-2: 24 layers, width 384, 12 heads", "p3", "c2", "c3"],
      head: ["MLP → arm 6 (Tanh) + gripper 1 (Sigmoid); ViT image decoder", "p2"],
      output: ["3 actions + both views' frame 3 steps ahead", "p4", "c2"],
      attention: ["Causal over time; [FRS] reads the inputs, [INV] reads the inputs and [FRS]", "p1", "c1"],
      cond: ["CLIP ViT-B/32 text → Linear → 1 token per step", "p2", "c1"],
      steps: ["None: one forward pass (regression)", "p2"],
      chunk: ["3 actions; history 10 (CALVIN) or 7 (LIBERO, real)", "p4"],
      rate: null, latency: null,
      train: ["Pretrain then finetune with L = 0.5 · L_fore + L_inv", "p1"]
    },
    changes: [
      "The action readout <b>attends to the foresight tokens</b>: the action is inverse dynamics conditioned on the predicted future.",
      "The backbone doubles to <b>24 layers</b> (still width 384).",
      "Each step reads out <b>3 actions</b> instead of 1.",
      "Pretraining uses large robot data (DROID) with actions instead of human video.",
      "The frozen image encoder feeds a resampler with 6 latents per view (9 in GR-1)."
    ],
    diffRows: ["params", "backbone", "output", "attention", "chunk", "train"],
    blueprint: {
      headline: "Seer: act on the foreseen frame",
      note: "Per step the sequence holds text, state and 2 × (6 + CLS) image tokens, then 18 [FRS] and 3 [INV] readouts. Nothing attends to the readouts except [INV], which sees [FRS]. [FRS] outputs plus 196 mask tokens go to a 2-layer ViT decoder; [INV] outputs go to an MLP.",
      towers: [
        { mod: "mae", title: "MAE ViT-B/16", sub: "frozen, per view", compact: true,
          input: { label: "Image 224 × 224", caption: "eye-on-hand + eye-on-base" },
          rows: [
            { t: "embed", label: "Patch embed 16 × 16", call: ["196 patches + CLS, width 768", "p2", "p3"] },
            { t: "block", n: "12", rows: [{ t: "attn", label: "MHA (12 heads)" }, { t: "ffn", label: "MLP" }] },
            { t: "attn", label: "Perceiver resampler", call: ["3 layers, 8 heads; 6 latents", "p3", "c2"] },
            { t: "linear", label: "Linear 768 → 384", call: ["6 patch tokens + CLS per view", "c1"] } ],
          output: { label: "7 tokens per view" } },
        { mod: "gpt", title: "Seer transformer", sub: "GPT-2 style, unidirectional mask",
          input: { label: "Token sequence", caption: "[ℓ, s, img, [FRS], [INV]] × 10 steps" },
          rows: [
            { t: "embed", label: "Modality linears + step emb.", call: ["16 input + 18 [FRS] + 3 [INV] per step", "c1", "c3"],
              zoom: { k: "rows", title: "Tokens per timestep", rows: ["text ℓ · 1, state s · 1", "2 views × (6 + CLS) · 14", "[FRS] 9 per view · 18", "[INV] · 3, one per action"] } },
            { t: "norm", label: "LayerNorm" },
            { t: "block", n: "24", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Masked causal self-attention", call: ["12 heads, width 384", "p3", "c2"], zoom: { k: "heads", q: 12, kv: 12, hd: 32, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 1,536", "c1"], zoom: { k: "mlp", act: "GELU", d: "384", ff: "1,536", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "mlp", label: "[INV] → action MLP", call: ["384 → 192 → 192 → 6 + 1", "c1", "p2"],
              zoom: { k: "rows", title: "Action decoder", rows: ["[INV] output, 384", "Linear 192 · ReLU", "Linear 192 · ReLU", "arm: Linear 6 · Tanh", "gripper: Linear 1 · Sigmoid"] } } ],
          output: { label: "3 actions and [FRS] features" } },
        { mod: "dec", title: "Image decoder", sub: "ViT, MAE-style", compact: true,
          input: { label: "[FRS] + mask tokens", caption: "196 masks, sin-cos position" },
          rows: [
            { t: "linear", label: "Project [FRS] to width 384" },
            { t: "block", n: "2", rows: [{ t: "attn", label: "Self-attention" }, { t: "ffn", label: "MLP" }] },
            { t: "linear", label: "Linear → 16 × 16 × 3", call: ["16 heads; pixel MSE on frame t + 3", "p3", "c1"] } ],
          output: { label: "predicted frame, per view" } }
      ],
      links: [
        { from: "gpt", to: "dec", toRow: "input", label: "[FRS] outputs" },
        { from: "mae", to: "gpt", toRow: "input", label: "image tokens" }
      ]
    },
    modules: [
      { id: "mae", role: "vision-enc", name: "MAE ViT-B/16", sub: "frozen · + resampler", col: 0, frozen: true, short: "MAE ViT",
        note: "Frozen ViT and CLIP text encoders hold 251M of the 316M parameters; the resampler is trained." },
      { id: "gpt", role: "joint", roleLabel: "Predictive inverse dynamics", name: "Seer transformer", sub: "24 × 384 · 12 heads", col: 1, frozen: false, main: true, short: "GPT",
        stack: { rows: [
          { t: "in", label: "[ℓ, s, 2 × (6 + CLS), 18 [FRS], 3 [INV]]", dims: "× 10 timesteps (CALVIN)", c: "data-4" },
          { t: "embed", label: "Per-modality linear + learned step embedding", dims: "→ 384" },
          { t: "block", label: "GPT-2 block", n: "24", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "Causal MHA · 12 heads · readouts hidden" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 384 → 1536 → 384" }, { t: "add", span: 2 } ] },
          { t: "out", label: "[INV] → 3 actions · [FRS] → image decoder", dims: "one pass per step", c: "data-4" } ],
          facts: [["Width / depth / heads", ["384 / 24 / 12", "p3", "c2"]], ["Seer-Large", ["width 1024, 16 heads, 24 layers", "c4"]], ["Resampler", ["768-d, 3 layers, 8 heads, 6 latents", "p3", "c2"]], ["Future offset", ["n = 3 steps", "c2"]], ["Loss", ["α = 0.5 on foresight, λ = 0.01 on gripper BCE", "p1"]], ["Trainable", ["65M of 316M", "p5", "p2"]]] } },
      { id: "dec", role: "video-gen", roleLabel: "Foresight decoder", name: "Image decoder", sub: "2 × 384 · 16 heads", col: 2, frozen: false, short: "Decoder" }
    ],
    inputs: [
      { to: "mae", mod: "vision", label: "hand + base images", n: "10 steps", k: 4 },
      { to: "gpt", mod: "lang", label: "instruction", n: "1 / step", k: 2 },
      { to: "gpt", mod: "state", label: "state", n: "1 / step", k: 2 }
    ],
    outputs: [{ from: "gpt", mod: "action", label: "actions aₜ:ₜ₊₂", n: "3 × 7", k: 3 }, { from: "dec", mod: "future", label: "frame t + 3", n: "per view", k: 3 }],
    links: [
      { from: "mae", to: "gpt", kind: "prefix", label: "linear → 384|7 tokens / view" },
      { from: "gpt", to: "dec", kind: "feeds", label: "[FRS] outputs|+ 196 mask tokens" }
    ],
    mask: { name: "Unidirectional readouts", ref: "p1", axes: [{ label: "inputs", short: "in", mod: "vision" }, { label: "[FRS] foresight", short: "FRS", mod: "future" }, { label: "[INV] actions", short: "INV", mod: "action" }], m: ["100", "100", "110"],
      note: "Inputs are causal over timesteps and never see readouts. [FRS] reads the inputs; [INV] reads the inputs and [FRS], which is the whole idea." },
    callouts: [
      "Compared with GR-1, the only structural change in the mask is one extra 1: [INV] may attend to [FRS]."
    ]
  });

  /* ------------------------------------------------------------------ UVA */
  var UVA_C = "fe3dec8";
  RB.arch.spec({
    id: "uva", method: "uva", name: "UVA", year: 2025, parent: "pad",
    figRef: "Li et al. Figs. 1–2 · §III · Supp. X-A, X-D", prov: "Released config (uva.yaml)",
    lede: "A masked-autoregressive transformer (MAR-B) fuses history frames, history actions and masked future-frame tokens into one joint latent. Two light diffusion MLPs decode it: one per video token, one for the action chunk, so video can be skipped when acting.",
    sources: {
      p1: { kind: "paper", ref: "Li et al. 2025, §III-A–C and Fig. 2", url: AX("2503.00200") },
      p2: { kind: "paper", ref: "Li et al. 2025, §III-D (masked training)", url: AX("2503.00200") },
      p3: { kind: "paper", ref: "Li et al. 2025, Supp. X-A (MAR-B base)", url: AX("2503.00200") },
      p4: { kind: "paper", ref: "Li et al. 2025, Supp. X-D, Table VII (inference time)", url: AX("2503.00200") },
      p5: { kind: "paper", ref: "Li et al. 2025, Table I (simulation)", url: AX("2503.00200") },
      c1: GH("ShuangLI59/unified_video_action", UVA_C, "unified_video_action/config/model/uva.yaml"),
      c2: GH("ShuangLI59/unified_video_action", UVA_C, "unified_video_action/model/autoregressive/mar_con_unified.py"),
      c3: GH("ShuangLI59/unified_video_action", UVA_C, "unified_video_action/model/autoregressive/diffusion_action_loss.py"),
      c4: GH("ShuangLI59/unified_video_action", UVA_C, "unified_video_action/model/autoregressive/diffusion_loss.py")
    },
    summary: {
      pattern: ["Autoregressive unified video-action model", "p1"],
      params: null,
      vision: ["Pretrained KL-16 VAE: 16 × 16 tokens per frame, 16 channels", "p1", "c1"],
      backbone: ["MAR-B: 12-layer encoder + 12-layer decoder, width 768, 12 heads", "p3", "c2"],
      head: ["Two diffusion MLP heads (6 residual blocks, width 1,024): per video token and per action chunk", "p1", "c1"],
      output: ["4 future frames and 16 actions (8 executed)", "c2", "c3", "p5"],
      attention: ["Bidirectional over 4 × 256 joint tokens; CLIP text appended as extra tokens", "p1", "c1"],
      cond: ["History frame, history actions and masked future token concatenated per position, then projected", "p1", "c2"],
      steps: ["Action head: 1,000 train / 100 test steps (16 on the real robot)", "c1", "p4"],
      chunk: ["16 predicted, 8 executed", "p5"],
      rate: null,
      latency: ["95 ms per 16-action chunk on an RTX 3080 (16 action-diffusion steps)", "p4"],
      train: ["Masked training over five input/output combinations: policy, video, forward and inverse dynamics, planner", "p2"]
    },
    changes: [
      "Denoising moves out of the big network: the transformer runs <b>once</b>, and only two small <b>diffusion MLP heads</b> iterate.",
      "Action decoding no longer needs the video: the <b>video head can be skipped</b> at policy time.",
      "The backbone is a masked-autoregressive MAR-B encoder–decoder instead of a DiT.",
      "History, action and future tokens are <b>concatenated per position</b> on channels, not laid out as separate tokens.",
      "Masked training turns one model into a policy, video model, forward or inverse dynamics model."
    ],
    diffRows: ["backbone", "head", "attention", "cond", "steps", "latency"],
    blueprint: {
      headline: "UVA: one joint latent, two small decoders",
      note: "Each of the 4 frames gives 256 VAE tokens; at every token position the history frame, the history action chunk and the (masked) future frame are concatenated and projected. MAR-B's encoder and decoder fuse these 1,024 tokens once; two diffusion MLPs then decode video patches and actions.",
      towers: [
        { mod: "vae", title: "KL-16 VAE", sub: "pretrained, frozen", compact: true,
          input: { label: "Frames 256 × 256", caption: "history and future" },
          rows: [{ t: "conv", label: "VAE encoder (stride 16)", call: ["16 × 16 × 16 latent per frame", "c1"] }],
          output: { label: "256 tokens per frame" } },
        { mod: "mar", title: "MAR-B transformer", sub: "masked autoregressive, from MAR-B",
          input: { label: "Frame ‖ actions ‖ future", caption: "per token position, 4 frames" },
          rows: [
            { t: "linear", label: "Concat on channels → FC", call: ["3 × 768 → 768 per token", "c2"],
              zoom: { k: "rows", title: "Per-position fusion", rows: ["history frame token → 768", "history actions, repeated → 768", "masked future token → 768", "concat 3 × 768 → Linear → 768"] } },
            { t: "embed", label: "+ temporal + spatial pos.", call: ["4 frames × 256 tokens", "c2", "c1"] },
            { t: "block", n: "12", label: "Encoder", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head self-attention", call: ["12 heads, width 768", "p3", "c2"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden layer dimension of 3,072", "c2"], zoom: { k: "mlp", act: "GELU", d: "768", ff: "3,072", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "block", n: "12", label: "Decoder", rows: [{ t: "attn", label: "Self-attention + MLP" }] } ],
          output: { label: "joint latents Z" } },
        { mod: "heads", title: "Diffusion heads", sub: "video + action, width 1,024 each", compact: true,
          input: { label: "Joint latents Z", caption: "4 frames × 256 tokens" },
          rows: [
            { id: "hin", t: "conv", label: "Action head: conv + pool", call: ["Conv 3×3, pool 4 × 4, FC; 4 frames → 16 actions", "c3"] },
            { t: "block", n: "6", rows: [{ t: "ffn", label: "AdaLN residual MLP" }] },
            { t: "linear", label: "→ ε (actions · patches)", call: ["Action 16 steps (robot); video 100, skippable", "p4", "c1"],
              zoom: { k: "rows", title: "Inference time (RTX 3080)", rows: ["VAE encoder · 40 ms", "transformer · 40 ms", "action head, 16 steps · 15 ms", "video head skipped · 0 ms"] } } ],
          output: { label: "action chunk (+ video)" } }
      ],
      links: [
        { from: "vae", to: "mar", toRow: "input", label: "VAE tokens" },
        { from: "mar", to: "heads", toRow: "input", label: "Z" }
      ]
    },
    modules: [
      { id: "vae", role: "codec", name: "KL-16 VAE", sub: "256² → 16 × 16 × 16", col: 0, frozen: true, short: "VAE" },
      { id: "mar", role: "joint", roleLabel: "Joint video-action latent", name: "MAR-B transformer", sub: "12 + 12 × 768 · 12 heads", col: 1, frozen: false, main: true, short: "MAR-B",
        stack: { rows: [
          { t: "in", label: "per position: [hist. frame ‖ hist. actions ‖ masked future]", dims: "4 frames × 256 tokens", c: "data-4" },
          { t: "linear", label: "Linear 3 × 768 → 768", dims: "+ temporal and spatial embeddings" },
          { t: "block", label: "Encoder block", n: "12", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "MHA · 12 heads · bidirectional" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 768 → 3072 → 768" }, { t: "add", span: 2 } ] },
          { t: "block", label: "Decoder block", n: "12", rows: [{ t: "attn", label: "MHA + MLP, width 768" }] },
          { t: "out", label: "joint latents Z", dims: "→ video head and action head", c: "data-4" } ],
          facts: [["Init", ["MAR-B checkpoint, heavily modified", "p3"]], ["Encoder / decoder", ["12 + 12 layers, width 768, 12 heads", "c2"]], ["Tokens per frame", ["256 (256 px, stride 16)", "c1"]], ["Frames", ["4", "c2"]], ["Text", ["CLIP 512 → 768, appended tokens", "p1", "c2"]], ["Mask ratio", ["min 0.7 (video); action mask 0.5", "c1"]]] } },
      { id: "heads", role: "action-head", roleLabel: "Diffusion heads", name: "Video + action heads", sub: "MLP 6 × 1024 each", col: 2, frozen: false, short: "Heads",
        note: "The video head denoises each token's patch and is skipped at policy time; the action head pools Z with a conv, maps 4 frames to 16 actions and denoises the chunk." }
    ],
    inputs: [
      { to: "vae", mod: "vision", label: "history frames", n: "4", k: 4 },
      { to: "mar", mod: "action", label: "history action chunks", n: "per frame", k: 3 },
      { to: "mar", mod: "future", label: "masked future tokens", n: "4 × 256", k: 4 },
      { to: "heads", mod: "action", label: "noisy action chunk", n: "16", k: 4, noisy: true }
    ],
    outputs: [{ from: "heads", mod: "action", label: "action chunk", n: "16 (8 run)", k: 4 }, { from: "heads", mod: "future", label: "future frames", n: "optional", k: 3 }],
    links: [
      { from: "vae", to: "mar", kind: "latent", label: "VAE tokens|→ Linear 768" },
      { from: "mar", to: "heads", kind: "feeds", label: "joint latent Z|video head skippable" }
    ],
    callouts: [
      "Table I measures 0.23 s per trajectory on an L40 in simulation; Supp. X-D measures 95 ms on an RTX 3080 for the real robot. Both skip video decoding.",
      "Actions are matched to image tokens by repetition: each of the 16 projected actions is repeated 64 times, 16 × 64 = 1,024 = 4 frames × 256 tokens (code)."
    ]
  });

  /* ------------------------------------------------------------------ FLARE */
  RB.arch.spec({
    id: "flare", method: "flare", name: "FLARE", year: 2025, parent: "uwm",
    figRef: "Zheng et al. Fig. 2 · §2–3 · App. A, D", prov: "",
    lede: "A GR00T-N1-style flow-matching DiT gets 32 extra learnable future tokens. At layer 6 their activations are projected and pulled, by cosine similarity, toward a frozen embedding of the observation H steps ahead: world modelling without generating a single pixel.",
    sources: {
      p1: { kind: "paper", ref: "Zheng et al. 2025, §2 (flow-matching policy)", url: AX("2505.15659") },
      p2: { kind: "paper", ref: "Zheng et al. 2025, §3.1 and Fig. 2 (future latent alignment)", url: AX("2505.15659") },
      p3: { kind: "paper", ref: "Zheng et al. 2025, §3.2 and App. A (embedding model)", url: AX("2505.15659") },
      p4: { kind: "paper", ref: "Zheng et al. 2025, §4.4 (ablations)", url: AX("2505.15659") },
      p5: { kind: "paper", ref: "Zheng et al. 2025, App. D (pseudocode)", url: AX("2505.15659") },
      p6: { kind: "paper", ref: "Zheng et al. 2025, App. B–C (pretraining)", url: AX("2505.15659") }
    },
    summary: {
      pattern: ["VLM + diffusion/flow action head", "p1"],
      params: null,
      vision: ["SigLIP-2 Large: 256 patch tokens per 256 × 256 image + 32 text tokens", "p3"],
      backbone: ["Embedding model: 4 fusion transformer layers + Q-former → 32 tokens", "p3"],
      head: ["Flow-matching DiT: 8 layers alternating cross- and self-attention", "p1", "p4"],
      output: ["Velocity on an H-step action chunk; future-token features only for the loss", "p1", "p2"],
      attention: ["Self-attention over [state ‖ actions ‖ 32 future tokens]; cross-attention to 32 VL tokens", "p2", "p3"],
      cond: ["τ from Beta(1.5, 1) on (s − τ)/s with s = 0.999", "p1"],
      steps: ["K = 4 Euler steps", "p1"],
      chunk: ["H actions (H not stated); future target at t + H", "p1", "p2"],
      rate: null, latency: null,
      train: ["L = L_fm + 0.2 · L_align; target encoder is an EMA (ρ = 0.995) of the policy's", "p2", "p4"]
    },
    changes: [
      "No future pixels or VAE latents are generated: <b>32 future tokens</b> are aligned to a compact embedding of the future frame.",
      "The alignment loss is a <b>cosine similarity</b> at DiT layer 6 of 8, not a denoising loss.",
      "Observations enter by <b>cross-attention</b> to 32 Q-former tokens instead of AdaLN.",
      "Actions are learned with <b>flow matching</b> (4 Euler steps), not DDIM.",
      "The prediction target is an EMA copy of the policy's own vision-language encoder."
    ],
    diffRows: ["backbone", "head", "output", "cond", "steps", "train"],
    blueprint: {
      headline: "FLARE: align future tokens, skip pixels",
      note: "The Q-former embedding turns the current images and instruction into 32 tokens that every other DiT layer cross-attends to. The same embedding, as an EMA copy, encodes the future frame; the DiT's future-token activations at layer 6 are MLP-projected and aligned to it by cosine similarity.",
      towers: [
        { mod: "target", title: "Target embedding", sub: "EMA copy, no gradient", compact: true,
          input: { label: "Future obs oₜ₊H", caption: "same encoder, EMA weights" },
          rows: [
            { t: "embed", label: "VL embedding (EMA)", call: ["ρ = 0.995", "p4"] },
            { id: "tg", t: "linear", label: "32 target tokens g(φₜ₊H)" } ],
          output: { label: "alignment target" } },
        { mod: "vl", title: "VL embedding", sub: "SigLIP-2 + fusion + Q-former", compact: true,
          input: { label: "Images + instruction", caption: "256 × 256 per camera" },
          rows: [
            { t: "embed", label: "SigLIP-2 vision + text", call: ["256 patch + 32 text tokens", "p3"] },
            { t: "block", n: "4", rows: [{ t: "attn", label: "Fusion self-attention" }] },
            { id: "qf", t: "attn", label: "Q-former", call: ["288 fused tokens → 32 queries", "p3"],
              zoom: { k: "rows", title: "Q-former compression", rows: ["256 vision + 32 text tokens", "4 self-attention fusion layers", "32 learnable queries", "self- + cross-attention layers", "32 VL tokens"] } } ],
          output: { label: "32 VL tokens φₜ" } },
        { mod: "dit", title: "Flow-matching DiT", sub: "GR00T N1-style action head",
          input: { label: "State, noisy chunk, futures", caption: "qₜ · Aτ · 32 learnable tokens" },
          rows: [
            { t: "mlp", label: "State MLP · action MLP", call: ["2-layer MLPs; τ enters the action MLP", "p5"] },
            { t: "embed", label: "+ 32 future tokens", call: ["M = 32 learnable embeddings", "p2"] },
            { t: "block", n: "8", rows: [
              { id: "xa", t: "attn", label: "Cross- or self-attention", side: "cond", call: ["Alternating; cross to VL tokens", "p1", "p2"] },
              { t: "ffn", label: "Feed forward" },
              { t: "add", span: 2 } ] },
            { id: "align", t: "linear", label: "Layer 6: future tokens → MLP", call: ["Cosine to target, λ = 0.2", "p2", "p4"],
              zoom: { k: "rows", title: "Future latent alignment", rows: ["32 future tokens, DiT layer 6", "2-layer MLP projection", "target: EMA embedding of oₜ₊H", "L_align = 1 − cos", "L = L_fm + 0.2 · L_align"] } },
            { t: "linear", label: "Action decoder → velocity", call: ["K = 4 Euler steps", "p1"],
              zoom: { k: "rows", title: "Sampling (flow matching)", rows: ["A⁰ ~ N(0, I)", "A ← A + ¼ · vθ(φₜ, A, qₜ)", "repeat 4 times", "execute the chunk"] } } ],
          output: { label: "velocity for the action chunk" } }
      ],
      links: [
        { from: "vl", to: "dit", toRow: "xa", label: "32 VL tokens" },
        { from: "target", to: "dit", toRow: "align", label: "cosine target" }
      ]
    },
    modules: [
      { id: "vl", role: "vlm", roleLabel: "Vision-language embedding", name: "SigLIP-2 + Q-former", sub: "→ 32 VL tokens", col: 0, frozen: false, short: "VL embed",
        stack: { rows: [
          { t: "in", label: "images + instruction", dims: "256 × 256 per camera", c: "data-1" },
          { t: "embed", label: "SigLIP-2 Large vision and text encoders", dims: "256 + 32 tokens" },
          { t: "block", label: "Fusion transformer", n: "4", rows: [{ t: "attn", label: "Self-attention over 288 tokens" }] },
          { t: "attn", label: "Q-former: 32 queries, self- + cross-attention" },
          { t: "out", label: "32 VL tokens", dims: "DiT cross-attention keys", c: "data-2" } ],
          facts: [["Backbone", ["SigLIP-2 Large, patch 16, 256 px", "p3"]], ["Fusion layers", ["4", "p3"]], ["Queries", ["32", "p3"]], ["Pretraining", ["≈ 2,000 h cross-embodiment data, with an 8-block DiT action head", "p3"]], ["Pretrain compute", ["256 H100s, batch 8192, 150k steps", "p6"]]] } },
      { id: "dit", role: "action-head", roleLabel: "Flow-matching DiT", name: "Flow-matching DiT", sub: "8 layers · x-attn / self", col: 1, frozen: false, main: true, short: "DiT",
        stack: { rows: [
          { t: "in", label: "[state qₜ ‖ noisy chunk Aτ ‖ 32 future tokens]", dims: "τ ∈ [0, 1]", c: "data-3" },
          { t: "mlp", label: "State MLP · action MLP (with τ)", dims: "2 layers each" },
          { t: "block", label: "DiT block", n: "8", rows: [{ t: "attn", label: "Cross-attention to VL tokens or self-attention (alternating)", side: "cond" }, { t: "ffn", label: "Feed forward" }, { t: "add", span: 2 }] },
          { t: "linear", label: "Layer 6: future tokens → MLP → cosine loss" },
          { t: "out", label: "velocity vθ for H actions", dims: "4 Euler steps", c: "data-3" } ],
          facts: [["Layers", ["8, alternating cross- and self-attention", "p1", "p4"]], ["Future tokens", ["M = 32", "p2"]], ["Alignment layer", ["6 of 8 (layer 4 hurts)", "p4"]], ["Loss weight", ["λ = 0.2", "p2"]], ["Steps", ["K = 4 Euler", "p1"]]] } },
      { id: "target", role: "latent", roleLabel: "Future target", name: "EMA target embed", sub: "no gradient · ρ = 0.995", col: 2, frozen: "partial", short: "Target",
        note: "Updated as an EMA of the policy's VL embedding, not by gradients." }
    ],
    inputs: [
      { to: "vl", mod: "vision", label: "current images", n: "per camera", k: 3 },
      { to: "vl", mod: "lang", label: "instruction", n: "32 tokens", k: 2 },
      { to: "dit", mod: "state", label: "proprio qₜ", n: "1 token", k: 1 },
      { to: "dit", mod: "action", label: "noisy chunk Aτ", n: "H", k: 4, noisy: true },
      { to: "target", mod: "future", label: "future frame oₜ₊H", n: "training only", k: 2 }
    ],
    outputs: [{ from: "dit", mod: "action", label: "velocity vθ", n: "H actions", k: 4 }],
    links: [
      { from: "vl", to: "dit", kind: "cross-attn", label: "32 VL tokens|every other layer" },
      { from: "dit", to: "target", kind: "latent", label: "future tokens|cosine alignment" }
    ],
    callouts: [
      "No standalone official FLARE code was found; every number comes from the paper. DiT width and head count are not stated.",
      "Time convention matches the site's: Aτ = τ·A + (1 − τ)·ε, so τ = 0 is noise and τ = 1 is the clean chunk."
    ]
  });
})();
