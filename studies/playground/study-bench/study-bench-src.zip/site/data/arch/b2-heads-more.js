/* Architecture specs, topic B2 (generative policy heads): ACT, DP3, 3D Diffuser Actor, Consistency Policy, VQ-BeT, AdaFlow.
   Numbers from each paper and its official code at the commit given in sources. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ ACT */
  var ACTC = "742c753", ACTR = "tonyzhaozh/act", ACTU = "https://github.com/tonyzhaozh/act/blob/" + ACTC + "/";
  RB.arch.spec({
    id: "act", method: "act", name: "ACT", year: 2023,
    figRef: "Zhao et al. Figs. 4, 11 · §IV · Tab. III", prov: "real ALOHA, 4 cameras",
    lede: "A conditional VAE built from DETR parts. At test time only the decoder runs: ResNet-18 image tokens, the joint state and a style token z = 0 go through a transformer encoder, and k learned queries decode a whole k-step chunk of joint targets in one pass.",
    sources: {
      p1: { kind: "paper", ref: "Zhao et al. 2023, §IV-B and §IV-C", url: "https://arxiv.org/abs/2304.13705" },
      p2: { kind: "paper", ref: "Zhao et al. 2023, App. C, Fig. 11 and Table III", url: "https://arxiv.org/abs/2304.13705" },
      p3: { kind: "paper", ref: "Zhao et al. 2023, §IV-A and Alg. 2 (temporal ensemble)", url: "https://arxiv.org/abs/2304.13705" },
      c1: { kind: "code", repo: ACTR, path: "detr/models/detr_vae.py", commit: ACTC, url: ACTU + "detr/models/detr_vae.py" },
      c2: { kind: "code", repo: ACTR, path: "detr/models/transformer.py", commit: ACTC, url: ACTU + "detr/models/transformer.py" },
      c3: { kind: "code", repo: ACTR, path: "imitate_episodes.py", commit: ACTC, url: ACTU + "imitate_episodes.py" },
      c4: { kind: "code", repo: ACTR, path: "detr/models/backbone.py", commit: ACTC, url: ACTU + "detr/models/backbone.py" },
      c5: { kind: "code", repo: ACTR, path: "README.md", commit: ACTC, url: ACTU + "README.md" },
      c6: { kind: "code", repo: ACTR, path: "constants.py", commit: ACTC, url: ACTU + "constants.py" }
    },
    summary: {
      pattern: ["Encoder–decoder transformer (CVAE)", "p1"],
      params: ["≈80M", "p1"],
      vision: ["ResNet-18 (ImageNet init, frozen BatchNorm): 480 × 640 → 15 × 20 × 512 per camera, 4 cameras", "p1", "c4"],
      backbone: ["Transformer encoder: 4 layers, width 512, 8 heads, FFN 3,200, post-norm", "p2", "c2", "c5"],
      head: ["Transformer decoder: 7 layers, k learned queries, then Linear 512 → 14", "p2", "c1"],
      output: ["k × 14 absolute joint targets (two 7-DoF arms)", "p1"],
      attention: ["Bidirectional encoder over 1,202 tokens; decoder queries cross-attend to it", "p1", "c2"],
      cond: ["Style z (32-d) and the joints are two extra encoder tokens; z = 0 at test time", "p1", "c1"],
      steps: ["A single forward pass per chunk (no iterative sampling)", "p1"],
      chunk: ["k = 100; policy queried every step and overlapping chunks averaged", "p2", "p3"],
      rate: null,
      latency: ["≈0.01 s per call on an RTX 2080 Ti", "p1"],
      train: ["L1 reconstruction + β·KL, β = 10; ≈5 h per task from scratch on one 2080 Ti", "p1", "p2"]
    },
    blueprint: {
      headline: "ACT: a DETR decoder that outputs chunks",
      note: "The ResNet's 300 tokens per camera join two extra tokens (joints and z) in the 4-layer encoder. The 7-layer decoder's k query slots cross-attend to that memory and each becomes one future action. The CVAE encoder on the right only exists during training.",
      towers: [
        { mod: "resnet", title: "ResNet-18", sub: "ImageNet init, frozen BatchNorm", compact: true,
          input: { label: "Camera image 480 × 640", caption: "each of 4 cameras" },
          rows: [
            { t: "conv", label: "Conv 7×7 · MaxPool" },
            { t: "block", n: "4", rows: [{ t: "conv", label: "Residual stage (2 blocks)" }] },
            { t: "conv", label: "1×1 conv to width 512", call: ["15 × 20 × 512 → 300 tokens per camera", "p1", "c1"] },
            { t: "embed", label: "+ 2-D sinusoidal position", call: ["Cameras concatenated: 1,200 tokens", "p1"] } ],
          output: { label: "image tokens" } },
        { mod: "policy", title: "CVAE decoder = policy", sub: "DETR-style encoder–decoder transformer",
          input: { label: "Image tokens + joints + z", caption: "1,200 + 2 = 1,202 tokens" },
          rows: [
            { id: "proj", t: "linear", label: "Joint and z projections", call: ["Joints 14 → 512 · z 32 → 512", "p2", "c1"] },
            { t: "block", n: "4", label: "Encoder", rows: [
              { t: "attn", label: "Multi-head self-attention", side: "PosEmb", call: ["8 heads, width 512, bidirectional", "p2", "c3"], zoom: { k: "heads", q: 8, kv: 8, hd: 64, title: "Attention heads" } },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm (post-norm)" },
              { t: "ffn", label: "Feed forward (ReLU)", call: ["Hidden layer dimension of 3,200", "p2", "c5"], zoom: { k: "mlp", act: "ReLU", d: "512", ff: "3,200", title: "Feed forward (MLP)" } },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "block", n: "7", label: "Decoder", rows: [
              { t: "attn", label: "Self-attention among queries", side: "Queries", call: ["k = 100 query slots, learned in code", "p2", "c1"] },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" },
              { t: "attn", label: "Cross-attn to memory", call: ["Keys and values: all 1,202 encoder tokens", "p1", "c2"] },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" },
              { t: "ffn", label: "Feed forward (ReLU)" },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "linear", label: "Action head: Linear → 14", call: ["Code reads decoder layer 1's output", "c1", "c2"], zoom: { k: "rows", title: "Temporal ensembling (inference)", rows: ["query the policy every step", "gather all guesses for step t", "weight wᵢ = exp(−m·i), oldest first", "weighted mean → aₜ"] } } ],
          output: { label: "k × 14 joint targets" } },
        { mod: "cvae", title: "CVAE encoder", sub: "training only, then discarded", compact: true,
          input: { label: "[CLS] + joints + actions", caption: "k + 2 tokens from the demo" },
          rows: [
            { t: "linear", label: "Joint, action projections", call: ["14 → 512 each, + sinusoid position", "p2", "c1"] },
            { t: "block", n: "4", rows: [
              { t: "attn", label: "Self-attention (BERT-like)" },
              { t: "ffn", label: "Feed forward" } ] },
            { t: "linear", label: "[CLS] → Linear 512 → 64", call: ["Mean and log-variance of 32-d z", "p2", "c1"], zoom: { k: "rows", title: "Style variable z", rows: ["[CLS] output (512)", "Linear → μ (32), log σ² (32)", "z = μ + σ·ε (reparameterize)", "Linear 32 → 512 token", "test time: z = 0"] } } ],
          output: { label: "style z (32-d)" } }
      ],
      links: [
        { from: "resnet", to: "policy", toRow: "input", label: "image tokens" },
        { from: "cvae", to: "policy", toRow: "input", label: "z (training only)" }
      ]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet-18", sub: "480×640 → 15×20×512", col: 0, frozen: false, short: "ResNet-18",
        note: "ImageNet weights with frozen BatchNorm statistics; trained with learning rate 1e-5. The code shares one backbone across cameras.",
        stack: { rows: [
          { t: "in", label: "RGB frame 480 × 640", dims: "4 cameras on the real ALOHA", c: "data-1" },
          { t: "conv", label: "ResNet-18 trunk (frozen BatchNorm)", dims: "stride 32 → 15 × 20 × 512" },
          { t: "conv", label: "1×1 conv projection", dims: "512 → 512" },
          { t: "embed", label: "+ 2-D sinusoidal position embedding" },
          { t: "out", label: "300 tokens per camera", dims: "concatenated along width", c: "data-1" } ],
          facts: [["Init", ["ImageNet, BatchNorm frozen", "c4"]], ["Backbone LR", ["1e-5", "c3"]], ["Feature map", ["15 × 20 × 512", "p1"]], ["Cameras", ["4 on real ALOHA (top, front, 2 wrists); 1 in sim", "p1", "c6"]]] } },
      { id: "policy", role: "action-head", roleLabel: "CVAE decoder (policy)", name: "ACT transformer", sub: "4 enc + 7 dec · 512 · 8 heads", col: 1, frozen: false, main: true, params: "≈80M total", short: "Transformer",
        stack: { rows: [
          { t: "in", label: "[z | joints | 1,200 image tokens]", dims: "1,202 × 512", c: "data-3" },
          { t: "block", label: "Encoder layer (post-norm)", n: "4", rows: [
            { t: "attn", label: "MHA · 8 heads · + sine position on Q, K" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" },
            { t: "ffn", label: "FFN 512 → 3,200 → 512 · ReLU" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" } ] },
          { t: "block", label: "Decoder layer (post-norm)", n: "7", rows: [
            { t: "attn", label: "Self-attention over k query slots" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" },
            { t: "attn", label: "Cross-attention to encoder memory" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" },
            { t: "ffn", label: "FFN 512 → 3,200 → 512 · ReLU" }, { t: "add", span: 1 }, { t: "norm", label: "LayerNorm" } ] },
          { t: "linear", label: "Action head Linear 512 → 14 (+ padding head)" },
          { t: "out", label: "k joint-target vectors", dims: "k × 14, L1 loss", c: "data-3" } ],
          facts: [["Width / heads", ["512 / 8", "p2", "c3"]], ["Encoder / decoder layers", ["4 / 7", "p2", "c3"]], ["FFN", ["3,200, ReLU", "p2", "c2"]], ["Dropout", ["0.1", "p2"]], ["Chunk", ["k = 100", "p2"]], ["Ensemble weight", ["m = 0.01 in the code", "c3"]]] } },
      { id: "cvae", role: "latent", roleLabel: "CVAE encoder", name: "Style encoder", sub: "4 layers · [CLS] → z (32)", col: 2, frozen: false, short: "CVAE enc.",
        note: "Training only. It sees the joints and the demo's action chunk, not the images.",
        stack: { rows: [
          { t: "in", label: "[CLS] + joints + k actions", dims: "(k + 2) × 512", c: "data-7" },
          { t: "block", label: "Transformer encoder layer", n: "4", rows: [{ t: "attn", label: "Self-attention · 8 heads" }, { t: "ffn", label: "FFN 3,200 · ReLU" }] },
          { t: "linear", label: "[CLS] output → Linear 512 → 64", dims: "μ and log σ² of z" },
          { t: "out", label: "z (32-d), reparameterized", dims: "KL to N(0, I), weight β", c: "data-7" } ],
          facts: [["z size", ["32", "p2", "c1"]], ["Layers", ["4 (same settings as the policy encoder)", "p2", "c1"]], ["KL weight β", ["10", "p2"]], ["Inputs", ["joints and action chunk only, no images", "p1"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "4 camera images", n: "480 × 640 each", k: 4 },
      { to: "policy", mod: "state", label: "joint positions", n: "14-d", k: 1 },
      { to: "cvae", mod: "action", label: "demo action chunk", n: "k × 14 (training)", k: 4 }
    ],
    outputs: [{ from: "policy", mod: "action", label: "joint-target chunk", n: "k × 14", k: 5 }],
    links: [
      { from: "resnet", to: "policy", kind: "prefix", label: "300 tokens / camera|+ 2-D sine position" },
      { from: "cvae", to: "policy", kind: "latent", label: "z (32-d)|0 at test time", note: "z becomes one encoder token through Linear 32 → 512" }
    ],
    mask: { name: "Encoder–decoder", ref: "p1", axes: [{ label: "memory: images + joints + z", short: "mem", mod: "vision" }, { label: "action queries", short: "A", mod: "action" }], m: ["10", "11"],
      note: "Memory tokens attend only among themselves; each query attends to the other queries and to all memory tokens. No causal mask." },
    callouts: [
      "Table III lists <b>7 decoder layers</b>. The released code runs all 7 but reads the actions from the <b>first</b> layer's output (<code>hs[0]</code>), so layers 2–7 never reach the loss.",
      "The paper calls the decoder queries fixed sinusoidal embeddings; the code learns them (<code>nn.Embedding(k, 512)</code>) and feeds zeros as the decoder input.",
      "The paper speaks of ResNet-18 backbones per image; the code builds one ResNet-18 and shares it across all cameras. Fig. 11 also labels the feature map 728 channels, while §IV-C and the code give 512."
    ]
  });

  /* ------------------------------------------------------------------ DP3 */
  var DPC = "47385d9", DPR = "YanjieZe/3D-Diffusion-Policy", DPB = "3D-Diffusion-Policy/diffusion_policy_3d/", DPU = "https://github.com/YanjieZe/3D-Diffusion-Policy/blob/" + DPC + "/" + DPB;
  RB.arch.spec({
    id: "dp3", method: "dp3", name: "DP3", year: 2024, parent: "diffusion-policy",
    diffRows: ["vision", "backbone", "output", "cond", "steps", "chunk"],
    figRef: "Ze et al. Fig. 2 · §III-B, C · App. A", prov: "",
    lede: "Diffusion Policy with the camera swapped for a sparse single-view point cloud. A tiny MLP with max-pooling squeezes 512 or 1,024 xyz points into one 64-d vector; with a 64-d state feature it steers the same conv U-Net through FiLM.",
    sources: {
      p1: { kind: "paper", ref: "Ze et al. 2024, §III-B, §III-C and Fig. 2", url: "https://arxiv.org/abs/2403.03954" },
      p2: { kind: "paper", ref: "Ze et al. 2024, App. A (implementation details)", url: "https://arxiv.org/abs/2403.03954" },
      p3: { kind: "paper", ref: "Ze et al. 2024, Tables V–VII (encoder and design ablations)", url: "https://arxiv.org/abs/2403.03954" },
      p4: { kind: "paper", ref: "Ze et al. 2024, §II footnote 1 (runtime measured by 3D Diffuser Actor's authors)", url: "https://arxiv.org/abs/2403.03954" },
      c1: { kind: "code", repo: DPR, path: DPB + "config/dp3.yaml", commit: DPC, url: DPU + "config/dp3.yaml" },
      c2: { kind: "code", repo: DPR, path: DPB + "model/vision/pointnet_extractor.py", commit: DPC, url: DPU + "model/vision/pointnet_extractor.py" },
      c3: { kind: "code", repo: DPR, path: DPB + "policy/dp3.py", commit: DPC, url: DPU + "policy/dp3.py" },
      c4: { kind: "code", repo: DPR, path: DPB + "config/task/adroit_hammer.yaml", commit: DPC, url: DPU + "config/task/adroit_hammer.yaml" }
    },
    summary: {
      pattern: ["Point-cloud encoder + 1-D temporal U-Net (FiLM)", "p1"],
      params: null,
      vision: ["Single-view depth 84 × 84 → cropped point cloud → FPS to 512 or 1,024 xyz points (no colour)", "p1", "c4"],
      backbone: ["DP3 Encoder: MLP 3 → 64 → 128 → 256 (LayerNorm, ReLU), max-pool, projection → 64", "p2", "c2"],
      head: ["Diffusion Policy's conv U-Net: down dims 512 / 1,024 / 2,048, kernel 5", "p1", "c1"],
      output: ["The clean chunk a⁰ (sample prediction), not the noise", "p1", "c1"],
      attention: "None (MLPs and convolutions only)",
      cond: ["FiLM on every U-Net block: [3-D feature 64 ‖ state 64] × 2 frames ‖ step embedding 128", "p2", "c1", "c3"],
      steps: ["DDIM: 100 train / 10 inference steps, squared-cosine schedule", "p1", "c1"],
      chunk: ["Paper: H = 4, Nobs = 2, Nact = 3; released config: 16 / 2 / 8", "p2", "c1"],
      rate: null,
      latency: ["581 ms per call on CALVIN with added language attention (2080 Ti)", "p4"],
      train: ["End to end, batch 128; 1,000 epochs (MetaWorld) or 3,000; 10 demos for most sim tasks", "p1"]
    },
    changes: [
      "The RGB cameras and ResNet-18 are replaced by a <b>single-view point cloud</b>: xyz only, cropped to the workspace, farthest-point sampled.",
      "A tiny PointNet-style MLP with max-pooling (no T-Net, no BatchNorm) compresses the cloud to <b>one 64-d vector</b>.",
      "The robot state gets its own two-layer MLP to 64-d before it joins the FiLM condition.",
      "The U-Net predicts the <b>clean sample</b> instead of the noise, with DDIM and 10 inference steps.",
      "The paper shortens the horizon to H = 4 and executes 3 actions per call."
    ],
    blueprint: {
      headline: "DP3: a 64-d point-cloud vector steers DP",
      note: "Both small encoders run once per observation frame; their outputs for the last 2 frames are concatenated with the step embedding and set γ and β in every conditional residual block. Only the U-Net repeats for the 10 DDIM steps.",
      towers: [
        { mod: "enc", title: "DP3 Encoder", sub: "per-point MLP, xyz only", compact: true,
          input: { label: "Point cloud 512 × 3", caption: "depth 84 × 84 → crop → FPS" },
          rows: [
            { t: "block", n: "3", rows: [
              { t: "linear", label: "Linear (per point)", call: ["Widths 3 → 64 → 128 → 256", "p2", "c2"], zoom: { k: "rows", title: "DP3 Encoder", rows: ["xyz points N × 3", "Linear 3→64 · LN · ReLU", "Linear 64→128 · LN · ReLU", "Linear 128→256 · LN · ReLU", "max-pool over points → 256", "Linear 256→64 · LayerNorm"] } },
              { t: "norm", label: "LayerNorm · ReLU" } ] },
            { t: "pool", label: "Max-pool over points", call: ["Order-invariant, 256-d", "p2"] },
            { t: "linear", label: "Projection + LayerNorm", call: ["256 → 64", "p2", "c2"] } ],
          output: { label: "64-d feature per frame" } },
        { mod: "state", title: "State MLP", sub: "robot pose", compact: true,
          input: { label: "Robot state q", caption: "joints or end-effector pose" },
          rows: [{ t: "mlp", label: "Linear · ReLU · Linear", call: ["q → 64 → 64", "p2", "c2"] }],
          output: { label: "64-d per frame" } },
        { mod: "unet", title: "Conditional 1-D U-Net", sub: "Diffusion Policy's denoiser, sample prediction",
          input: { label: "Noisy action chunk aᵏ", caption: "H steps × action dim, DDIM step k" },
          rows: [
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 512 → 1,024 → 2,048", "c1"] } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block, 2,048 ch" }] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "conv", label: "Upsample (transposed conv)" } ] },
            { t: "conv", label: "Final Conv1d → action dim", call: ["Predicts a⁰ directly (sample)", "p1", "c1"] } ],
          output: { label: "clean chunk a⁰; 10 DDIM steps" } }
      ],
      links: [
        { from: "enc", to: "unet", toRow: "film", label: "[v ‖ q] × 2 frames ‖ step" },
        { from: "state", to: "unet", toRow: "film", label: "state feature" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "DP3 Encoder", sub: "MLP 64·128·256 → 64", col: 0, frozen: false, short: "DP3 Encoder",
        note: "Trained from scratch, end to end with the U-Net. LayerNorm instead of BatchNorm, no T-Net.",
        stack: { rows: [
          { t: "in", label: "point cloud, N × 3 (xyz)", dims: "N = 512 or 1,024 after FPS", c: "data-1" },
          { t: "linear", label: "Linear 3 → 64 · LayerNorm · ReLU", dims: "shared across points" },
          { t: "linear", label: "Linear 64 → 128 · LayerNorm · ReLU" },
          { t: "linear", label: "Linear 128 → 256 · LayerNorm · ReLU" },
          { t: "pool", label: "max over points", dims: "→ 256" },
          { t: "linear", label: "Projection Linear 256 → 64 · LayerNorm" },
          { t: "out", label: "compact 3-D feature v", dims: "64-d per frame", c: "data-1" } ],
          facts: [["Points", ["512 or 1,024 after FPS", "p1"]], ["Channels", ["xyz only (colour dropped)", "p1", "c1"]], ["Widths", ["64 / 128 / 256 → 64", "p2", "c2"]], ["Norm", ["LayerNorm after every Linear", "p2", "c2"]], ["Ablation", ["PointNet 15.7 vs DP3 Encoder 78.3 avg. success", "p3"]]] } },
      { id: "unet", role: "action-head", roleLabel: "Denoising net", name: "Conditional 1-D U-Net", sub: "512 → 1024 → 2048 ch", col: 1, frozen: false, main: true, short: "1-D U-Net",
        stack: { rows: [
          { t: "in", label: "noisy action chunk aᵏ", dims: "H × action dim", c: "data-3" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "film", label: "FiLM: x · scale + bias", side: "cond" },
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "add", span: 3 } ] },
            { t: "conv", label: "Downsample1d (stride 2)" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block at 2048 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · 2 conditional residual blocks" }, { t: "conv", label: "Upsample1d" }] },
          { t: "conv", label: "Conv1dBlock → Conv1d 1×1", dims: "→ action dim" },
          { t: "out", label: "predicted clean chunk a⁰", dims: "sample prediction", c: "data-3" } ],
          facts: [["Down dims", ["512 / 1024 / 2048", "c1"]], ["Kernel / groups", ["5 / 8", "c1"]], ["Step embedding", ["128", "c1"]], ["Condition", ["global: (64 + 64) × 2 frames = 256, plus step", "p2", "c3"]], ["Scheduler", ["DDIM, squaredcos_cap_v2, 100 train steps", "c1"]], ["Prediction", ["sample (a⁰)", "p1", "c1"]]] } },
      { id: "state", role: "state-enc", name: "State MLP", sub: "q → 64 → 64", col: 2, frozen: false, short: "State MLP",
        stack: { rows: [
          { t: "in", label: "robot pose q", dims: "task dependent (24 on Adroit Hammer)", c: "data-5" },
          { t: "mlp", label: "Linear → 64 · ReLU · Linear → 64" },
          { t: "out", label: "state feature", dims: "64-d per frame", c: "data-5" } ],
          facts: [["Layers", ["2, ReLU", "p2", "c2"]], ["Width", ["64", "p2", "c2"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "point cloud (xyz)", n: "512 or 1,024 pts", k: 5 },
      { to: "unet", mod: "action", label: "noisy chunk aᵏ", n: "H × action dim", k: 4, noisy: true },
      { to: "unet", mod: "time", label: "DDIM step k", n: "→ 128-d", k: 2 },
      { to: "state", mod: "state", label: "robot state q", n: "2 frames", k: 2 }
    ],
    outputs: [{ from: "unet", mod: "action", label: "clean chunk a⁰", n: "H × action dim", k: 4 }],
    links: [
      { from: "enc", to: "unet", kind: "film", label: "64-d / frame" },
      { from: "state", to: "unet", kind: "film", label: "64-d / frame" }
    ],
    callouts: [
      "Paper App. A sets <b>H = 4, Nobs = 2, Nact = 3</b>; the released <code>dp3.yaml</code> uses horizon 16 and 8 executed actions, with the paper's values commented out.",
      "Table VI: dropping PointNet's T-Net and BatchNorm lifts it from 15.7 to 72.5 average success, close to the DP3 Encoder's 78.3. The plainness is the design.",
      "3D Diffuser Actor's Fig. 4 draws DP3 with a PointNeXt encoder; DP3's own paper and code use the MLP encoder above (PointNeXt is only an ablation)."
    ]
  });

  /* ------------------------------------------------------ 3D Diffuser Actor */
  var DAC = "4faf00b", DAR = "nickgkan/3d_diffuser_actor", DAU = "https://github.com/nickgkan/3d_diffuser_actor/blob/" + DAC + "/";
  RB.arch.spec({
    id: "3d-diffuser-actor", method: "3d-diffuser-actor", name: "3D Diffuser Actor", year: 2024, parent: "diffusion-policy",
    diffRows: ["vision", "backbone", "head", "output", "attention", "cond", "steps"],
    figRef: "Ke et al. Figs. 2, 5 · §3 · Tab. 7", prov: "multi-view RLBench config",
    lede: "A diffusion transformer whose tokens all live in 3-D. Frozen CLIP features from posed RGB-D views are lifted to a feature cloud; each noisy end-effector pose is a token placed at its own noisy xyz, and rotary 3-D relative attention mixes them.",
    sources: {
      p1: { kind: "paper", ref: "Ke et al. 2024, §3 and Fig. 2", url: "https://arxiv.org/abs/2402.10885" },
      p2: { kind: "paper", ref: "Ke et al. 2024, App. B.2–B.3 and Fig. 5", url: "https://arxiv.org/abs/2402.10885" },
      p3: { kind: "paper", ref: "Ke et al. 2024, App. B.5, Table 7", url: "https://arxiv.org/abs/2402.10885" },
      p4: { kind: "paper", ref: "Ke et al. 2024, §4 Runtime and Table 3", url: "https://arxiv.org/abs/2402.10885" },
      c1: { kind: "code", repo: DAR, path: "diffuser_actor/trajectory_optimization/diffuser_actor.py", commit: DAC, url: DAU + "diffuser_actor/trajectory_optimization/diffuser_actor.py" },
      c2: { kind: "code", repo: DAR, path: "diffuser_actor/utils/encoder.py", commit: DAC, url: DAU + "diffuser_actor/utils/encoder.py" },
      c3: { kind: "code", repo: DAR, path: "diffuser_actor/utils/layers.py", commit: DAC, url: DAU + "diffuser_actor/utils/layers.py" },
      c4: { kind: "code", repo: DAR, path: "scripts/train_keypose_peract.sh", commit: DAC, url: DAU + "scripts/train_keypose_peract.sh" },
      c5: { kind: "code", repo: DAR, path: "main_trajectory.py", commit: DAC, url: DAU + "main_trajectory.py" },
      c6: { kind: "code", repo: DAR, path: "scripts/train_trajectory_calvin.sh", commit: DAC, url: DAU + "scripts/train_trajectory_calvin.sh" }
    },
    summary: {
      pattern: ["Diffusion transformer policy (3-D relative attention)", "p1"],
      params: null,
      vision: ["Frozen CLIP ResNet-50 + FPN; stride-8 map (32 × 32 at 256²) lifted to 3-D with depth and camera pose", "p1", "c2"],
      backbone: ["Denoising transformer, width 120 (RLBench) / 192 (CALVIN), 8 heads, rotary 3-D relative attention", "p3", "c1", "c3"],
      head: ["Separate 2-layer attention branches + MLPs for position and rotation; openness from the position branch", "p2", "c1"],
      output: ["ε on each pose's xyz (3) and 6-D rotation, plus a gripper-openness logit", "p1", "c1"],
      attention: ["Relative self-attention among trajectory + FPS-sampled scene tokens; cross-attention to all scene tokens and language", "p2", "c1"],
      cond: ["AdaLN (scale, shift) from step embedding + MLP of 3 past gripper poses", "p2", "c1", "c3"],
      steps: ["DDPM, 100 steps (RLBench) / 25 (CALVIN); scaled-linear for position, squared-cosine for rotation", "p1", "p3"],
      chunk: ["RLBench: the next keypose (planner reaches it); CALVIN: the trajectory up to it", "p1"],
      rate: ["≈10 Hz on CALVIN: 6 poses per 600 ms call", "p4"],
      latency: ["600 ms per call on an RTX 2080 Ti (CALVIN)", "p4"],
      train: ["Loss 30 · L1(ε position) + 10 · L1(ε rotation) + BCE(openness)", "p3", "c1"]
    },
    changes: [
      "The conv U-Net becomes a <b>transformer</b>; each noisy pose is a token whose 3-D position is its own noisy xyz.",
      "Images are no longer pooled to one vector: frozen CLIP features are <b>lifted to a 3-D feature cloud</b> with depth and camera pose.",
      "Rotary 3-D relative attention makes the denoiser translation-equivariant (ablation: 81.3 vs 71.3 without it).",
      "Language enters through CLIP text tokens and cross-attention.",
      "Conditioning moves from FiLM on conv blocks to <b>AdaLN</b> on attention and feed-forward layers.",
      "Position and rotation get separate noise schedules and separate output branches."
    ],
    blueprint: {
      headline: "3D Diffuser Actor: denoise poses among 3-D tokens",
      note: "Scene tokens are computed once per observation. For each of the diffusion steps the trajectory tokens first cross-attend to every scene token, then self-attend together with an FPS subset of them; step and gripper history modulate every layer through AdaLN.",
      towers: [
        { mod: "scene", title: "3-D scene encoder", sub: "frozen CLIP ResNet-50 + trained FPN", compact: true,
          input: { label: "RGB-D views 256 × 256", caption: "4 calibrated cameras" },
          rows: [
            { t: "conv", label: "CLIP ResNet-50 (frozen)" },
            { t: "conv", label: "Feature pyramid → width C", call: ["Stride-8 level: 32 × 32 per view", "c2"] },
            { t: "embed", label: "Lift patches to 3-D xyz", note: "depth averaged per patch, pinhole model with intrinsics and extrinsics" },
            { id: "vl", t: "attn", label: "Cross-attn to language", side: "CLIP text", call: ["2 layers, 8 heads", "c2", "c5"] },
            { t: "pool", label: "FPS token subset", call: ["Keeps 20 % (RLBench) or 33 % (CALVIN)", "p3", "c5"] } ],
          output: { label: "scene tokens with xyz" } },
        { mod: "head", title: "3-D relative denoising transformer", sub: "width C = 120, 8 heads",
          input: { label: "Noisy trajectory τⁱ", caption: "poses: xyz + 6-D rotation, step i" },
          rows: [
            { t: "linear", label: "Trajectory encoder", call: ["Linear 9 → C (C = 120 on RLBench)", "c1", "p3"] },
            { t: "block", n: "2", label: "Scene cross-attention", rows: [
              { id: "xa", t: "attn", label: "Relative cross-attn to scene", side: "3-D RoPE", call: ["Queries: pose tokens; keys: all scene tokens", "p2", "c1"] },
              { t: "ffn", label: "Feed forward C → C (ReLU)" } ] },
            { t: "block", n: "4", label: "Joint self-attention", rows: [
              { t: "adaln", label: "AdaLN: x·(1+scale)+shift", side: "AdaLN", zoom: { k: "rows", title: "AdaLN condition", rows: ["step i → sinusoid → MLP", "+ MLP of 3 past gripper poses", "SiLU → Linear → 2 × C (zero init)", "x · (1 + scale) + shift"] } },
              { t: "attn", label: "Relative self-attention", call: ["8 heads over poses + FPS scene tokens", "c1", "c3"], zoom: { k: "heads", q: 8, kv: 8, hd: 15, title: "Attention heads (C = 120)" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm (post-norm)" },
              { t: "ffn", label: "Feed forward C → C (ReLU)", call: ["Hidden width equals C", "c3"], zoom: { k: "mlp", act: "ReLU", d: "120", ff: "120", title: "Feed forward (MLP)" } },
              { t: "norm", label: "Residual + LayerNorm" } ] },
            { t: "group", label: "Two heads: position, rotation", rows: [
              { t: "attn", label: "2 relative self-attn each" },
              { t: "mlp", label: "MLP → ε pos (3), ε rot (6)", call: ["Openness logit from the position branch", "c1"], zoom: { k: "rows", title: "Output branches", rows: ["shared features", "branch: 2 AdaLN self-attn layers", "Linear C → C", "MLP → ε pos (3) or ε rot (6)", "position branch also → openness"] } } ] } ],
          output: { label: "ε for xyz and 6-D rotation, openness" } }
      ],
      links: [
        { from: "scene", to: "head", toRow: "xa", label: "3-D scene tokens" }
      ]
    },
    modules: [
      { id: "clipt", role: "lang", name: "CLIP text encoder", sub: "frozen · 512-d tokens", col: 0, frozen: true, short: "CLIP text" },
      { id: "scene", role: "vision-enc", name: "3-D scene encoder", sub: "CLIP RN50 + FPN + lift", col: 1, frozen: "partial", short: "Scene enc.",
        note: "The CLIP ResNet-50 is frozen; the FPN, the language cross-attention and the gripper-history attention are trained.",
        stack: { rows: [
          { t: "in", label: "posed RGB-D views", dims: "4 × 256 × 256 (multi-view RLBench)", c: "data-1" },
          { t: "conv", label: "CLIP ResNet-50 (frozen)", dims: "stages 64 · 256 · 512 · 1,024 · 2,048 ch" },
          { t: "conv", label: "Feature pyramid network → C", dims: "keep stride 8: 32 × 32 per view" },
          { t: "embed", label: "lift each patch to xyz with depth + camera pose", dims: "3-D feature cloud" },
          { t: "attn", label: "vision → language cross-attention", dims: "2 layers, 8 heads" },
          { t: "attn", label: "gripper history → scene cross-attention", dims: "3 layers; feeds AdaLN" },
          { t: "pool", label: "farthest point sampling", dims: "1 in 5 tokens (RLBench)" },
          { t: "out", label: "scene tokens + FPS subset", dims: "features and xyz", c: "data-1" } ],
          facts: [["Backbone", ["CLIP ResNet-50, frozen", "p1", "c2"]], ["Resolution", ["256 × 256 (RLBench); 200 (CALVIN, paper)", "p3"]], ["Cameras", ["4 (multi-view), 1 (single-view), 2 (CALVIN)", "p3"]], ["FPS kept", ["20 % / 20 % / 33 %", "p3"]], ["History", ["3 past gripper poses", "c4"]]] } },
      { id: "head", role: "action-head", roleLabel: "Denoising transformer", name: "3-D relative transformer", sub: "C = 120 · 8 heads · AdaLN", col: 2, frozen: false, main: true, short: "Denoiser",
        stack: { rows: [
          { t: "in", label: "noisy poses τⁱ (xyz + 6-D rot)", dims: "one token per pose, position = noisy xyz", c: "data-3" },
          { t: "linear", label: "Linear 9 → C, + sinusoid over pose index" },
          { t: "attn", label: "pose tokens → language cross-attention", dims: "1 layer" },
          { t: "block", label: "Relative cross-attention to scene", n: "2", rows: [
            { t: "adaln", label: "AdaLN on queries", side: "cond" }, { t: "attn", label: "cross-attn, 3-D rotary", dims: "8 heads" }, { t: "add", span: 2 }, { t: "norm", label: "LayerNorm" },
            { t: "ffn", label: "FFN C → C · ReLU (AdaLN, residual, LayerNorm)" } ] },
          { t: "block", label: "Relative self-attention", n: "4", rows: [
            { t: "adaln", label: "AdaLN", side: "cond" }, { t: "attn", label: "self-attn over poses + FPS scene tokens" }, { t: "add", span: 2 }, { t: "norm", label: "LayerNorm" },
            { t: "ffn", label: "FFN C → C · ReLU (AdaLN, residual, LayerNorm)" } ] },
          { t: "group", label: "Position and rotation branches", rows: [
            { t: "attn", label: "2 relative self-attn layers per branch" }, { t: "mlp", label: "Linear C → C · MLP → 3 or 6" } ] },
          { t: "out", label: "ε position · ε rotation · openness", dims: "DDPM, 100 steps (RLBench)", c: "data-3" } ],
          facts: [["Width", ["120 (RLBench) / 192 (CALVIN)", "p3", "c4"]], ["Heads", ["8", "c1"]], ["FFN hidden", ["C (not 4C)", "c3"]], ["Schedules", ["scaled-linear (position), squared-cosine (rotation)", "p1", "c1"]], ["Diffusion steps", ["100 / 25 (CALVIN)", "p3"]], ["Loss weights", ["w₁ = 30, w₂ = 10", "p3", "c1"]]] } }
    ],
    inputs: [
      { to: "clipt", mod: "lang", label: "instruction ℓ", n: "CLIP tokens", k: 3 },
      { to: "scene", mod: "vision", label: "posed RGB-D views", n: "1–4 cameras", k: 4 },
      { to: "head", mod: "action", label: "noisy poses τⁱ", n: "xyz + 6-D rot", k: 4, noisy: true },
      { to: "head", mod: "state", label: "3 past gripper poses", n: "→ AdaLN", k: 3 }
    ],
    outputs: [{ from: "head", mod: "action", label: "ε position, rotation + openness", n: "per pose", k: 4 }],
    links: [
      { from: "clipt", to: "scene", kind: "cross-attn", label: "language tokens" },
      { from: "scene", to: "head", kind: "cross-attn", label: "3-D scene tokens", note: "an FPS subset of the scene tokens also joins the self-attention" }
    ],
    callouts: [
      "Fig. 5 labels the step conditioning <b>FiLM</b>; the code implements it as AdaLN (SiLU → Linear → scale and shift, zero-initialised) inside every attention and feed-forward layer.",
      "Table 7 gives image size 200 for CALVIN; the released <code>train_trajectory_calvin.sh</code> uses 256 × 256.",
      "Ablation (Table 3): 81.3 % with 3-D relative attention, 71.3 % with absolute attention, 47.0 % for the 2-D variant."
    ]
  });

  /* ---------------------------------------------------- Consistency Policy */
  var CPC = "eed0c46", CPR = "Aaditya-Prasad/Consistency-Policy", CPU = "https://github.com/Aaditya-Prasad/Consistency-Policy/blob/" + CPC + "/";
  RB.arch.spec({
    id: "consistency-policy", method: "consistency-policy", name: "Consistency Policy", year: 2024, parent: "diffusion-policy",
    diffRows: ["head", "output", "cond", "steps", "latency", "train"],
    figRef: "Prasad et al. Fig. 2 · §III · Tab. I, III", prov: "Robomimic Square image config",
    lede: "Diffusion Policy's U-Net, distilled so it can jump. An EDM teacher defines a probability-flow ODE; the student learns to map a point at time t straight to any earlier time s, so one call turns noise into an action chunk.",
    sources: {
      p1: { kind: "paper", ref: "Prasad et al. 2024, §III-B (teacher and student)", url: "https://arxiv.org/abs/2405.07503" },
      p2: { kind: "paper", ref: "Prasad et al. 2024, §III-C (inference, chaining)", url: "https://arxiv.org/abs/2405.07503" },
      p3: { kind: "paper", ref: "Prasad et al. 2024, §III-D (implementation)", url: "https://arxiv.org/abs/2405.07503" },
      p4: { kind: "paper", ref: "Prasad et al. 2024, §IV, Tables I and III", url: "https://arxiv.org/abs/2405.07503" },
      c1: { kind: "code", repo: CPR, path: "configs/ctmp_square.yaml", commit: CPC, url: CPU + "configs/ctmp_square.yaml" },
      c2: { kind: "code", repo: CPR, path: "consistency_policy/ctm_unet.py", commit: CPC, url: CPU + "consistency_policy/ctm_unet.py" },
      c3: { kind: "code", repo: CPR, path: "consistency_policy/diffusion.py", commit: CPC, url: CPU + "consistency_policy/diffusion.py" },
      c4: { kind: "code", repo: CPR, path: "consistency_policy/base_workspace.py", commit: CPC, url: CPU + "consistency_policy/base_workspace.py" },
      c5: { kind: "code", repo: CPR, path: "consistency_policy/diffusion_unet_with_dropout.py", commit: CPC, url: CPU + "consistency_policy/diffusion_unet_with_dropout.py" }
    },
    summary: {
      pattern: ["Observation encoder + 1-D temporal U-Net (FiLM), consistency-distilled", "p3"],
      params: null,
      vision: ["Diffusion Policy's robomimic image encoder with GroupNorm, crop 76 × 76; wrist + third-person camera", "p4", "c1"],
      backbone: "None: a conv U-Net, no transformer",
      head: ["Student gθ(xₜ, t, s; o): Diffusion Policy U-Net, down dims 512 / 1,024 / 2,048, kernel 5", "p3", "c1"],
      output: ["The point xₛ at stop time s; s = 0 gives a 16 × 10 action chunk", "p1", "c1"],
      attention: "None (convolutions only)",
      cond: ["FiLM on [emb(t) ‖ emb(s) ‖ obs features]; the s weights start at zero", "p3", "c2", "c4"],
      steps: ["1 call; or 3 with chaining at bins 27 and 54 of 80", "p2", "c1"],
      chunk: ["Tₒ = 2 → 16 predicted → 8 executed", "c1"],
      rate: null,
      latency: ["1 ms (1 step) / 2 ms (3 steps) vs 110 ms DDPM on a P5000", "p4"],
      train: ["Distil an EDM teacher: α·CTM + β·DSM (both 1 in the config), pseudo-Huber metric", "p1", "c1"]
    },
    changes: [
      "Same U-Net, new job: it learns to <b>jump</b> along the teacher's probability-flow ODE from time t to any earlier time s.",
      "FiLM gets a second time input, the stop time s; its new weights are <b>zero-initialised</b> so the warm-started teacher is unchanged at step 0.",
      "The teacher is retrained in the EDM framework (σ from 0.02 to 80, Heun solver) instead of DDPM.",
      "Loss: CTM self-consistency plus denoising score matching, both measured with a pseudo-Huber distance.",
      "Inference: 1 network call instead of 100 DDPM steps; 3 with chaining. Sampling starts from N(0, I), not N(0, T²I)."
    ],
    blueprint: {
      headline: "Consistency Policy: one jump along the ODE",
      note: "The encoder runs once. The student U-Net is Diffusion Policy's, with the stop time s embedded next to t in every FiLM block. The frozen EDM teacher is only used in training, to take one Heun step from t to u that the student must agree with.",
      towers: [
        { mod: "enc", title: "Image encoder", sub: "Diffusion Policy's, GroupNorm", compact: true,
          input: { label: "Image crop 76 × 76", caption: "wrist + third-person, Tₒ = 2" },
          rows: [
            { t: "conv", label: "ResNet trunk (GroupNorm)", call: ["Robomimic encoder, BatchNorm → GroupNorm", "c1"] },
            { t: "linear", label: "Concat with EE pose, gripper" } ],
          output: { label: "obs features, 2 frames" } },
        { mod: "student", title: "Student U-Net gθ", sub: "warm-started from the teacher",
          input: { label: "Point xₜ on the ODE", caption: "16 × 10 chunk; times t and s" },
          rows: [
            { t: "mlp", label: "Step encoder, shared", call: ["t and s each → 128-d, concatenated", "c1", "c2"] },
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", call: ["Dropout 0.2 on γ and β", "c1", "c5"], zoom: { k: "film", title: "FiLM with stop time s" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 512 → 1,024 → 2,048", "c1"] } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block, 2,048 ch" }] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "conv", label: "Upsample (transposed conv)" } ] },
            { t: "conv", label: "Final Conv1d · CTM scaling", call: ["xₛ = c_skip·xₜ + c_out·F(xₜ)", "c3"], zoom: { k: "rows", title: "One-step and 3-step inference", rows: ["z ~ N(0, I) at σ = 80", "one call: jump T → 0", "or: re-noise to a chain time", "jump → 0 again (twice)", "execute 8 of 16 actions"] } } ],
          output: { label: "xₛ; s = 0 gives the action chunk" } },
        { mod: "teacher", title: "EDM teacher sφ", sub: "frozen, training only", compact: true,
          input: { label: "xₜ from a demo + noise", caption: "training only" },
          rows: [
            { t: "conv", label: "DP U-Net (EDM, frozen)" },
            { t: "mlp", label: "One Heun step t → u", call: ["u = t − 1 on an 80-bin grid", "p1", "c1"], zoom: { k: "rows", title: "CTM loss", rows: ["xₜ = x₀ + t·ε", "teacher: Heun step t → u (no grad)", "student: xₜ → xₛ; xᵤ → xₛ (no grad)", "student takes both xₛ → 0 (no grad)", "pseudo-Huber distance, + DSM"] } } ],
          output: { label: "xᵤ target for the student" } }
      ],
      links: [
        { from: "enc", to: "student", toRow: "film", label: "obs ‖ emb(t) ‖ emb(s)" },
        { from: "teacher", to: "student", toRow: "input", label: "xᵤ (training only)" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "Image encoder", sub: "robomimic, GroupNorm", col: 0, frozen: false, short: "Encoder",
        note: "Kept from Diffusion Policy; the paper holds encoder and normalisation fixed across all methods." },
      { id: "student", role: "action-head", roleLabel: "Consistency student", name: "Student U-Net gθ", sub: "512 → 1024 → 2048 ch", col: 1, frozen: false, main: true, short: "Student",
        stack: { rows: [
          { t: "in", label: "xₜ · c_in, times t and s", dims: "16 × 10 action chunk", c: "data-3" },
          { t: "mlp", label: "Shared step encoder on t and s", dims: "sinusoid 128 → MLP → 128, twice" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "film", label: "FiLM from [emb t ‖ emb s ‖ obs]", side: "cond", note: "Mish → Linear; the emb(s) columns are zero at warm start" },
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "add", span: 3 } ] },
            { t: "conv", label: "Downsample1d (stride 2)" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block at 2048 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · 2 conditional residual blocks" }, { t: "conv", label: "Upsample1d" }] },
          { t: "conv", label: "Conv1d head, then CTM boundary scaling", dims: "c_skip · xₜ + c_out · F" },
          { t: "out", label: "xₛ (x₀ when s = 0)", dims: "16 × 10", c: "data-3" } ],
          facts: [["Down dims", ["512 / 1024 / 2048", "c1"]], ["Step embed", ["128 each for t and s", "c1", "c2"]], ["FiLM dropout", ["0.2", "c1", "c5"]], ["σ range", ["0.02 to 80, ρ = 7, 80 bins", "c1"]], ["Data std", ["0.5", "c1"]], ["Loss weights", ["CTM 1, DSM 1", "c1"]]] } },
      { id: "teacher", role: "net", roleLabel: "Teacher (training only)", name: "EDM teacher sφ", sub: "same U-Net · Heun", col: 2, frozen: true, short: "Teacher",
        note: "Trained first with the EDM denoising score-matching loss, then frozen to provide ODE steps for distillation." }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "wrist + third-person", n: "Tₒ = 2 frames", k: 4 },
      { to: "student", mod: "action", label: "noisy chunk xₜ", n: "16 × 10", k: 4, noisy: true },
      { to: "student", mod: "time", label: "times t, s", n: "two embeddings", k: 2 }
    ],
    outputs: [{ from: "student", mod: "action", label: "action chunk x₀", n: "16 × 10, 1 call", k: 4 }],
    links: [
      { from: "enc", to: "student", kind: "film", label: "obs features" },
      { from: "teacher", to: "student", kind: "two-stage", label: "Heun step t → u|(training only)" }
    ],
    callouts: [
      "Table III: 1 ms for 1-step and 2 ms for 3-step CP against 110 ms for 100-step DDPM and 11 ms for 15-step DDIM on an NVIDIA P5000.",
      "On a 3070 Ti laptop the real-robot speed-up is about 9×, not the 15× the step count suggests, because the observation encoder still costs time (§IV-C).",
      "Chaining times in the paper are t₂N/₃ and tN/₃; the config's <code>[27, 54]</code> on an 80-bin grid are the nearest bins."
    ]
  });

  /* ------------------------------------------------------------ VQ-BeT */
  var VQC = "09d4851", VQR = "jayLEE0301/vq_bet_official", VQU = "https://github.com/jayLEE0301/vq_bet_official/blob/" + VQC + "/";
  RB.arch.spec({
    id: "vq-bet", method: "vq-bet", name: "VQ-BeT", year: 2024, parent: "behavior-transformers",
    figRef: "Lee et al. Fig. 2 · §3 · Tab. 13", prov: "Franka Kitchen (state) config",
    lede: "Two stages. A residual VQ-VAE first turns each action (or chunk) into two discrete codes. A small causal GPT then reads the observation window and, in one pass, picks the two codes and a continuous offset; the frozen decoder turns them back into an action.",
    sources: {
      p1: { kind: "paper", ref: "Lee et al. 2024, §3.2 (residual VQ tokenizer)", url: "https://arxiv.org/abs/2403.03181" },
      p2: { kind: "paper", ref: "Lee et al. 2024, §3.3 and Fig. 2 (code and offset heads)", url: "https://arxiv.org/abs/2403.03181" },
      p3: { kind: "paper", ref: "Lee et al. 2024, App. C.1, Table 13", url: "https://arxiv.org/abs/2403.03181" },
      p4: { kind: "paper", ref: "Lee et al. 2024, Tables 3 and 7 (inference time)", url: "https://arxiv.org/abs/2403.03181" },
      c1: { kind: "code", repo: VQR, path: "examples/configs/train_kitchen_nongoalcond.yaml", commit: VQC, url: VQU + "examples/configs/train_kitchen_nongoalcond.yaml" },
      c2: { kind: "code", repo: VQR, path: "vqvae/vqvae.py", commit: VQC, url: VQU + "vqvae/vqvae.py" },
      c3: { kind: "code", repo: VQR, path: "vq_behavior_transformer/bet.py", commit: VQC, url: VQU + "vq_behavior_transformer/bet.py" },
      c4: { kind: "code", repo: VQR, path: "vq_behavior_transformer/gpt.py", commit: VQC, url: VQU + "vq_behavior_transformer/gpt.py" }
    },
    summary: {
      pattern: ["Residual-VQ action tokenizer + causal GPT (codes + offset)", "p2"],
      params: null,
      vision: ["State vectors in most sims; ResNet-18 features for image envs; HPR encoder on the real robot", "p3"],
      backbone: ["MinGPT: 6 layers, 6 heads, width 120, causal (Kitchen)", "p3", "c1"],
      head: ["Code head MLP → 2 × 16 logits; offset head MLP → one offset per code pair", "p2", "c3"],
      output: ["Action (chunk) = ψ(e₁ + e₂) + predicted offset", "p2"],
      attention: ["Causal self-attention over the observation window; goal tokens first when conditioned", "c3", "c4"],
      cond: ["Optional goal observation sequence prepended to the window", "p2", "c3"],
      steps: ["A single forward pass; codes sampled from the softmax", "p2", "c3"],
      chunk: ["Kitchen: 10 obs → 1 action; PushT: 5 → 5; UR3: 10 → 10", "p3"],
      rate: null,
      latency: ["15 ms vs 100 ms for Diffusion Policy (Kitchen); 18 ms vs 573 ms on the real robot (A4000)", "p4"],
      train: ["Stage 1: RVQ-VAE (L1 recon + VQ, EMA codebooks). Stage 2: focal code loss + L1 offset", "p1", "p2"]
    },
    blueprint: {
      headline: "VQ-BeT: pick two codes, add an offset",
      note: "Stage 1 trains the residual VQ-VAE on actions alone. In stage 2 it is frozen: the GPT's feature at each step feeds a code head and an offset head, and the frozen decoder ψ maps the sum of the chosen code vectors back to an action before the offset is added.",
      towers: [
        { mod: "gpt", title: "MinGPT", sub: "causal transformer over observations",
          input: { label: "Observation window", caption: "10 steps × 60-d state (Kitchen)" },
          rows: [
            { t: "linear", label: "Observation projection", call: ["60-d state → 120 (Kitchen)", "c1", "c4"] },
            { t: "embed", label: "+ learned position embedding" },
            { t: "block", n: "6", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Causal self-attention", call: ["6 heads, width 120", "p3", "c1"], zoom: { k: "heads", q: 6, kv: 6, hd: 20, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 480", "c4", "c1"], zoom: { k: "mlp", act: "GELU", d: "120", ff: "480", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "linear", label: "Output head 120 → 256" } ],
          output: { label: "256-d feature per step" } },
        { mod: "heads", title: "Code + offset heads", sub: "stage 2", compact: true,
          input: { label: "GPT feature", caption: "256-d" },
          rows: [
            { t: "mlp", label: "Code head MLP", call: ["→ 2 × 16 logits", "c3", "c1"] },
            { t: "mlp", label: "Offset head MLP", call: ["→ 2 × 16 offsets", "c3"] },
            { t: "linear", label: "Sample c₁, c₂; take offset", zoom: { k: "rows", title: "Hierarchical code prediction", rows: ["softmax over primary codes → c₁", "softmax over secondary codes → c₂", "focal loss, secondary weighted by β", "offset for the (c₁, c₂) pair", "L1 loss on decoded action + offset"] } } ],
          output: { label: "codes c₁, c₂ and an offset" } },
        { mod: "rvq", title: "Residual VQ-VAE", sub: "stage 1, then frozen", compact: true,
          input: { label: "Action (chunk)", caption: "stage 1 input only" },
          rows: [
            { t: "mlp", label: "Encoder φ (MLP)", call: ["action → 128 → 128 → 512", "c2"] },
            { id: "vq", t: "linear", label: "Residual VQ, Nq = 2", call: ["16 codes per layer (Kitchen), EMA", "p1", "p3", "c1"], zoom: { k: "rows", title: "Residual VQ", rows: ["x = φ(a), 512-d", "e₁ = nearest code in book 1", "e₂ = nearest code to x − e₁", "z = e₁ + e₂", "action ≈ ψ(z)"] } },
            { id: "dec", t: "mlp", label: "Decoder ψ (MLP)", call: ["512 → 128 → 128 → action", "c2"] } ],
          output: { label: "ψ(e₁ + e₂) + offset = action" } }
      ],
      links: [
        { from: "gpt", to: "heads", toRow: "input", label: "feature" },
        { from: "heads", to: "rvq", toRow: "dec", label: "codes c₁, c₂" }
      ]
    },
    modules: [
      { id: "gpt", role: "net", roleLabel: "Sequence model", name: "MinGPT", sub: "6 × 120 · 6 heads · causal", col: 0, frozen: false, main: true, short: "MinGPT",
        stack: { rows: [
          { t: "in", label: "[goal window ‖] observation window", dims: "Kitchen: 10 × 60-d", c: "data-8" },
          { t: "linear", label: "wte: Linear obs → 120" },
          { t: "embed", label: "+ learned position embedding", dims: "block size 30" },
          { t: "block", label: "GPT block (pre-norm)", n: "6", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "causal MHA · 6 heads" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 120 → 480 → 120 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final LayerNorm" },
          { t: "linear", label: "lm_head 120 → 256 (no bias)" },
          { t: "out", label: "feature per step", dims: "256-d", c: "data-8" } ],
          facts: [["Layers / heads / width", ["6 / 6 / 120 (Kitchen)", "p3", "c1"]], ["BlockPush", ["4 / 4 / 72", "p3"]], ["Dropout", ["0.1", "c4"]], ["Obs window", ["10 (Kitchen), 5 (PushT), 100 (Ant)", "p3"]], ["LR", ["5.5e-5 (Kitchen)", "p3", "c1"]]] } },
      { id: "heads", role: "action-head", roleLabel: "Code + offset heads", name: "Code and offset MLPs", sub: "→ 2 × 16 logits + offsets", col: 1, frozen: false, short: "Heads",
        stack: { rows: [
          { t: "in", label: "GPT feature", dims: "256-d", c: "data-3" },
          { t: "mlp", label: "code head: MLP 1,024 · 1,024 → 2 × 16" },
          { t: "mlp", label: "offset head: MLP 1,024 · 1,024 → 2 × 16 × (action dim × chunk)" },
          { t: "out", label: "c₁, c₂ sampled; offset for the pair", c: "data-3" } ],
          facts: [["Codebooks × codes", ["2 × 16 (Kitchen)", "p3", "c1"]], ["Code loss", ["focal, γ = 2", "p2", "c3"]], ["Secondary weight β", ["0.1 (Kitchen), 0.6 (Ant)", "p3"]], ["Offset loss", ["L1", "p2", "c3"]]] } },
      { id: "rvq", role: "codec", name: "Residual VQ-VAE", sub: "MLP φ, ψ · 2 codebooks", col: 2, frozen: true, short: "RVQ-VAE",
        note: "Trained first on actions alone, then frozen while the GPT learns.",
        stack: { rows: [
          { t: "in", label: "action or chunk aₜ:ₜ₊ₙ", dims: "stage 1 only", c: "data-8" },
          { t: "mlp", label: "encoder φ: Linear → 128 · ReLU · Linear 128 · ReLU · Linear → 512" },
          { t: "linear", label: "residual VQ: 2 layers × 16 codes, EMA updates", dims: "latent 512" },
          { t: "mlp", label: "decoder ψ: 512 → 128 → 128 → action" },
          { t: "out", label: "reconstructed action", dims: "L1 loss + VQ loss", c: "data-8" } ],
          facts: [["Latent dim", ["512 (256 on BlockPush)", "p3", "c1"]], ["Residual layers", ["Nq = 2", "p1"]], ["Codebook", ["16 (Kitchen), 8–16 real", "p3"]], ["Commitment", ["λ = 1", "p1"]], ["Hidden", ["128, 2 hidden layers", "c2"]]] } }
    ],
    inputs: [
      { to: "gpt", mod: "state", label: "observation window", n: "h steps", k: 5 },
      { to: "gpt", mod: "future", label: "goal window", n: "optional", k: 3 },
      { to: "rvq", mod: "action", label: "action chunk", n: "stage 1 only", k: 3 }
    ],
    outputs: [{ from: "rvq", mod: "action", label: "decoded action + offset", n: "1 pass", k: 3 }],
    links: [
      { from: "gpt", to: "heads", kind: "feeds", label: "feature per step" },
      { from: "heads", to: "rvq", kind: "latent", label: "codes c₁, c₂|→ e₁ + e₂" }
    ],
    mask: { name: "Causal", ref: "p2", axes: [{ label: "goal window", short: "g", mod: "future" }, { label: "earlier observations", short: "o<t", mod: "state" }, { label: "current observation", short: "oₜ", mod: "state" }], m: ["100", "110", "111"],
      note: "MinGPT's causal mask: each step sees the goal tokens (when given) and the observations up to itself." },
    callouts: [
      "Eq. 7 adds the code and offset losses with equal weight. The released configs weight the primary code loss by 5 and the offset loss by 100 (Kitchen), 10 (PushT) or 0.1 (Ant); the secondary weight keeps the paper's ratio β (0.5/5 = 0.1 on Kitchen).",
      "The paper found autoregressive code prediction (c₂ conditioned on c₁) hurt in Kitchen but helped on the real robot; Table 13 enables it only for nuScenes and the real robot.",
      "BeT's k-means bins are replaced by a <b>learned</b> residual VQ, so chunks and high-dimensional actions can be tokenized."
    ]
  });

  /* ------------------------------------------------------------ AdaFlow */
  var AFC = "1ceeeb4", AFR = "hxixixh/AdaFlow", AFU = "https://github.com/hxixixh/AdaFlow/blob/" + AFC + "/";
  RB.arch.spec({
    id: "adaflow", method: "adaflow", name: "AdaFlow", year: 2024, parent: "diffusion-policy",
    diffRows: ["head", "output", "steps", "train"],
    figRef: "Hu et al. Alg. 1 · §3 · Tab. 7", prov: "RoboMimic / LIBERO image config",
    lede: "Diffusion Policy's U-Net trained as a rectified flow, plus a four-layer MLP on its bottleneck that predicts how uncertain the velocity is. Where the variance is low the ODE path is straight, so the solver takes one big Euler step.",
    sources: {
      p1: { kind: "paper", ref: "Hu et al. 2024, §3.2 (variance estimation network)", url: "https://arxiv.org/abs/2402.04292" },
      p2: { kind: "paper", ref: "Hu et al. 2024, §3.3 and Alg. 1 (adaptive solver)", url: "https://arxiv.org/abs/2402.04292" },
      p3: { kind: "paper", ref: "Hu et al. 2024, App. A.9 and Table 7", url: "https://arxiv.org/abs/2402.04292" },
      p4: { kind: "paper", ref: "Hu et al. 2024, §4.3, Tables 3 and 4", url: "https://arxiv.org/abs/2402.04292" },
      c1: { kind: "code", repo: AFR, path: "adaflow/config/train_adaflow_unet_image_workspace.yaml", commit: AFC, url: AFU + "adaflow/config/train_adaflow_unet_image_workspace.yaml" },
      c2: { kind: "code", repo: AFR, path: "adaflow/model/diffusion/conditional_unet1d.py", commit: AFC, url: AFU + "adaflow/model/diffusion/conditional_unet1d.py" },
      c3: { kind: "code", repo: AFR, path: "adaflow/policy/adaflow_unet_image_policy.py", commit: AFC, url: AFU + "adaflow/policy/adaflow_unet_image_policy.py" },
      c4: { kind: "code", repo: AFR, path: "adaflow/config/task/libero_image_abs.yaml", commit: AFC, url: AFU + "adaflow/config/task/libero_image_abs.yaml" }
    },
    summary: {
      pattern: ["Observation encoder + 1-D temporal U-Net (FiLM), rectified flow", "p3"],
      params: null,
      vision: ["ResNet-18 per camera from scratch, GroupNorm, crop 76 × 76; agent view + wrist", "p3", "c1", "c4"],
      backbone: "None: a conv U-Net, no transformer",
      head: ["Velocity U-Net vθ (Diffusion Policy-C: 512 / 1,024 / 2,048) + variance MLP σφ", "p3", "c1", "c2"],
      output: ["Velocity on a 16-step chunk; one scalar log σ per sample", "p3", "c2"],
      attention: "None (convolutions only)",
      cond: ["FiLM on [obs features ‖ emb(100·t)]", "c1", "c3"],
      steps: ["Adaptive Euler, εₜ = clip(η / σ, ε_min, 1 − t); average NFE 1.17 (RoboMimic), 1.27 (LIBERO)", "p2", "p4"],
      chunk: ["Tₒ = 2 → 16 predicted → 8 executed", "p3", "c1"],
      rate: null, latency: null,
      train: ["Stage 1: rectified-flow MSE on a − x₀. Stage 2: Gaussian NLL for σφ with vθ frozen", "p1", "c3"]
    },
    changes: [
      "DDPM noise prediction becomes <b>rectified flow</b>: the U-Net predicts a velocity along straight noise → action paths, t from 0 (noise) to 1 (action).",
      "A small <b>variance head</b> (4-layer SiLU MLP on the mean-pooled U-Net bottleneck) predicts the conditional variance of the flow loss.",
      "The Euler step size adapts: low variance lets the solver finish in one step; high variance forces more steps.",
      "Training gets a second stage: Gaussian negative log-likelihood for the variance head while the velocity network is frozen."
    ],
    blueprint: {
      headline: "AdaFlow: variance decides the step size",
      note: "The velocity U-Net is Diffusion Policy's. The variance head reads the mid-block features of the same forward pass, so each Euler step costs one U-Net call and returns both vθ and σφ; the next step size is η / σφ.",
      towers: [
        { mod: "enc", title: "ResNet-18", sub: "one per camera, from scratch", compact: true,
          input: { label: "Image crop 76 × 76", caption: "agent view + wrist, Tₒ = 2" },
          rows: [
            { t: "conv", label: "Conv 7×7 · GN · ReLU", call: ["BatchNorm replaced by GroupNorm", "c1"] },
            { t: "block", n: "4", rows: [{ t: "conv", label: "Residual stage (2 blocks)" }] },
            { t: "pool", label: "Pool + concat EE pose" } ],
          output: { label: "obs features, 2 frames" } },
        { mod: "unet", title: "Velocity U-Net vθ", sub: "Diffusion Policy-C backbone",
          input: { label: "Point zₜ on the flow", caption: "16 steps × action dim, time t" },
          rows: [
            { t: "mlp", label: "Time embedding", call: ["t scaled by 100 → 128-d", "c1", "c3"] },
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 512 → 1,024 → 2,048", "c1"] } ] },
            { id: "mid", t: "conv", label: "Mid blocks, 2,048 ch", call: ["Mean over time feeds the variance head", "c2"] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "conv", label: "Upsample (transposed conv)" } ] },
            { t: "conv", label: "Final Conv1d → action dim", zoom: { k: "rows", title: "Variance-adaptive Euler (Alg. 1)", rows: ["z₀ ~ N(0, I), t = 0", "one call → vθ and σφ", "ε = clip(η / σφ, ε_min, 1 − t)", "z ← z + ε·vθ, t ← t + ε", "stop when t = 1"] } } ],
          output: { label: "velocity vθ; Euler step" } },
        { mod: "var", title: "Variance head σφ", sub: "stage 2, on frozen features", compact: true,
          input: { label: "Bottleneck feature", caption: "mean over time, 2,048-d" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "mlp", label: "Linear · SiLU", call: ["Hidden width 512", "p3", "c2"] }] },
            { t: "linear", label: "Linear → log σ", zoom: { k: "rows", title: "Variance head", rows: ["mean-pooled mid feature, 2,048", "Linear → 512 · SiLU", "Linear 512 · SiLU", "Linear 512 · SiLU", "Linear → log σ (1 scalar)"] } } ],
          output: { label: "σφ(zₜ, t | s)" } }
      ],
      links: [
        { from: "enc", to: "unet", toRow: "film", label: "obs ‖ emb(t)" },
        { from: "unet", to: "var", toRow: "input", label: "mid feature" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "ResNet-18 per camera", sub: "GroupNorm · crop 76 × 76", col: 0, frozen: false, short: "ResNet-18",
        note: "Not shared between cameras (share_rgb_model: False), random init, ImageNet normalisation of inputs." },
      { id: "unet", role: "action-head", roleLabel: "Velocity net", name: "Velocity U-Net vθ", sub: "512 → 1024 → 2048 ch", col: 1, frozen: false, main: true, short: "U-Net",
        stack: { rows: [
          { t: "in", label: "zₜ = t·a + (1 − t)·z₀", dims: "16 × action dim", c: "data-3" },
          { t: "mlp", label: "time embedding of 100·t", dims: "sinusoid → 128" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "film", label: "FiLM: x · scale + bias", side: "cond" },
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "add", span: 3 } ] },
            { t: "conv", label: "Downsample1d (stride 2)" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block at 2048 ch" }], note: "its time-averaged output goes to the variance head" },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · 2 conditional residual blocks" }, { t: "conv", label: "Upsample1d" }] },
          { t: "conv", label: "Conv1dBlock → Conv1d 1×1", dims: "→ action dim" },
          { t: "out", label: "velocity vθ", dims: "target a − z₀", c: "data-3" } ],
          facts: [["Down dims", ["512 / 1024 / 2048", "c1"]], ["Kernel / groups", ["5 / 8", "c1"]], ["Horizon", ["16 predicted, 8 executed, 2 obs", "p3", "c1"]], ["Optimiser", ["AdamW, lr 1e-4, batch 64", "p3", "c1"]], ["η (paper)", ["1.0 (RoboMimic, LIBERO)", "p3"]], ["Time", ["t = 0 noise, t = 1 action", "c3"]]] } },
      { id: "var", role: "net", roleLabel: "Variance head", name: "Variance MLP σφ", sub: "4 linear · SiLU · 512", col: 2, frozen: false, short: "σφ",
        stack: { rows: [
          { t: "in", label: "mid-block feature, mean over time", dims: "2,048-d", c: "data-8" },
          { t: "mlp", label: "Linear 2048 → 512 · SiLU" },
          { t: "mlp", label: "Linear 512 → 512 · SiLU (×2)" },
          { t: "linear", label: "Linear 512 → 1" },
          { t: "out", label: "log σ (one scalar per sample)", dims: "Gaussian NLL", c: "data-8" } ],
          facts: [["Layers", ["4 linear, SiLU", "p3", "c2"]], ["Hidden", ["512", "p3", "c2"]], ["Input", ["U-Net bottleneck features", "p3", "c2"]], ["Training", ["second stage, U-Net frozen", "p1", "c3"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "2 cameras", n: "Tₒ = 2 frames", k: 4 },
      { to: "unet", mod: "action", label: "flow point zₜ", n: "16 × action dim", k: 4, noisy: true },
      { to: "unet", mod: "time", label: "flow time t", n: "0 → 1", k: 2 }
    ],
    outputs: [
      { from: "unet", mod: "action", label: "velocity vθ", n: "16 × action dim", k: 4 },
      { from: "var", mod: "other", label: "σ → step size", n: "1 scalar", k: 1 }
    ],
    links: [
      { from: "enc", to: "unet", kind: "film", label: "obs features" },
      { from: "unet", to: "var", kind: "feeds", label: "mid feature|mean over time" }
    ],
    callouts: [
      "Table 7 lists η = 1.0 and ε_min '10' for RoboMimic and LIBERO. In the code η defaults to 0.1 (set at evaluation; the README example uses η = 0.5 with 5 steps) and the step floor is 1 / num_inference_steps, 20 in the config.",
      "With σ = 0 the step is 1 − t, so a unimodal state is solved in a <b>single</b> Euler step; that is where the 1.17 average NFE on RoboMimic comes from.",
      "The paper fine-tunes the baselines and AdaFlow for 500 epochs from Diffusion Policy's released RoboMimic checkpoints (App. A.9)."
    ]
  });
})();
