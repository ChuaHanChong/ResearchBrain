/* Glossary groups and the part ids of the glossary scenes.
   Every term sets group (one of these ids), scene ("system" or "robot") and focus (part ids from SCENE_PARTS). */
(function () {
  var RB = window.RB;
  RB.TERM_GROUPS = [
    { id: "foundations", name: "Foundations", short: "Basics" },
    { id: "learning", name: "Learning paradigms", short: "Learning" },
    { id: "heads", name: "Policy heads", short: "Heads" },
    { id: "actions", name: "Actions and timing", short: "Actions" },
    { id: "vla", name: "VLAs and planners", short: "VLAs" },
    { id: "world", name: "World models", short: "World" },
    { id: "wam", name: "World action models", short: "WAMs" },
    { id: "data", name: "Data", short: "Data" },
    { id: "grasp", name: "Grasping and dexterity", short: "Grasping" },
    { id: "contact", name: "Control, touch and force", short: "Contact" },
    { id: "physics", name: "Physics priors", short: "Physics" },
    { id: "trust", name: "Verification and safety", short: "Trust" },
    { id: "eval", name: "Evaluation", short: "Evaluation" },
    { id: "arch", name: "Network architecture", short: "Architecture" }
  ];
  RB.SCENE_PARTS = {
    system: ["data-robot", "data-umi", "data-human", "data-sim", "data-web", "instruction", "camera-image", "proprio", "vision-encoder", "llm-backbone", "latent", "action-head", "noise", "action-chunk", "controller", "robot", "world-model", "predicted-future", "reward-model", "verifier", "safety-filter", "planner", "replay-buffer", "simulator", "human-teleop", "policy-update"],
    robot: ["arm", "joint", "end-effector", "gripper", "fingers", "object", "grasp-pose", "contact-point", "friction-cone", "wrist-camera", "scene-camera", "tactile-pad", "ft-sensor", "table", "base", "trajectory", "target-pose", "obstacle", "cloth", "human-hand"]
  };
})();
