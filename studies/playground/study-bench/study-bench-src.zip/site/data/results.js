/* Results board (Compare page, core/50-compare.js results()).
   Every value is copied from P03 (arXiv 2605.00080) Table 5 (LIBERO) and Table 6 (RoboTwin 2.0, CALVIN, SIMPLER-style).
   "family" is P03's grouping by how world modeling couples to the policy. Cells shown as "-" in P03 are omitted.
   Left out on purpose: "a/b" cells (VideoVLA S-G 73.1/62.8, MimicVideo S-O 46.9/56.3) and the S-O column (mixed setups).
   C-A and C-D keep P03's labels; its footnote names them the CALVIN "ABCD" and "ABCDD" protocols. */
(function () {
  window.RB = window.RB || {};
  window.RB.RESULTS = { suites: [
 {
  "id": "libero-avg",
  "short": "LIBERO avg",
  "name": "LIBERO, four-suite average",
  "metric": "Success rate (%)",
  "source": "P03 Table 5",
  "max": 100,
  "caption": "Average over Spatial, Object, Goal and Long, only where the original paper reports it. Most methods sit within six points of each other.",
  "rows": [
   {
    "method": "MimicVideo",
    "value": 93.9,
    "family": "Decoupled"
   },
   {
    "method": "Say-Dream-ACT",
    "value": 98.1,
    "family": "Decoupled"
   },
   {
    "method": "Cosmos Policy",
    "value": 98.5,
    "family": "Single-backbone"
   },
   {
    "method": "UD-VLA",
    "value": 92.7,
    "family": "Single-backbone"
   },
   {
    "method": "Motus",
    "value": 97.7,
    "family": "MoE / MoT"
   },
   {
    "method": "LingBot-VA",
    "value": 98.5,
    "family": "MoE / MoT"
   },
   {
    "method": "RynnVLA-002",
    "value": 97.4,
    "family": "Unified VLA"
   },
   {
    "method": "DreamVLA",
    "value": 92.6,
    "family": "Unified VLA"
   },
   {
    "method": "UniVLA",
    "value": 95.2,
    "family": "Unified VLA"
   },
   {
    "method": "Unified VLA",
    "value": 95.5,
    "family": "Unified VLA"
   },
   {
    "method": "CoWVLA",
    "value": 95.6,
    "family": "Unified VLA"
   },
   {
    "method": "F1",
    "value": 95.7,
    "family": "Unified VLA"
   },
   {
    "method": "TriVLA",
    "value": 87.0,
    "family": "Unified VLA"
   },
   {
    "method": "VLA-JEPA",
    "value": 97.2,
    "family": "Latent-space WM"
   },
   {
    "method": "JEPA-VLA",
    "value": 96.4,
    "family": "Latent-space WM"
   }
  ]
 },
 {
  "id": "libero-long",
  "short": "LIBERO-Long",
  "name": "LIBERO-Long suite",
  "metric": "Success rate (%)",
  "source": "P03 Table 5",
  "max": 100,
  "caption": "The long-horizon suite, where P03 finds the largest drops. Compare TriVLA here with its four-suite average.",
  "rows": [
   {
    "method": "UniPi",
    "value": 0.0,
    "family": "Decoupled"
   },
   {
    "method": "MimicVideo",
    "value": 94.0,
    "family": "Decoupled"
   },
   {
    "method": "Say-Dream-ACT",
    "value": 95.4,
    "family": "Decoupled"
   },
   {
    "method": "UVA",
    "value": 90.0,
    "family": "Single-backbone"
   },
   {
    "method": "VideoPolicy",
    "value": 94.0,
    "family": "Single-backbone"
   },
   {
    "method": "Cosmos Policy",
    "value": 97.6,
    "family": "Single-backbone"
   },
   {
    "method": "UD-VLA",
    "value": 89.6,
    "family": "Single-backbone"
   },
   {
    "method": "Motus",
    "value": 97.6,
    "family": "MoE / MoT"
   },
   {
    "method": "LingBot-VA",
    "value": 98.5,
    "family": "MoE / MoT"
   },
   {
    "method": "RynnVLA-002",
    "value": 94.4,
    "family": "Unified VLA"
   },
   {
    "method": "DreamVLA",
    "value": 89.5,
    "family": "Unified VLA"
   },
   {
    "method": "UniVLA",
    "value": 92.0,
    "family": "Unified VLA"
   },
   {
    "method": "Unified VLA",
    "value": 94.0,
    "family": "Unified VLA"
   },
   {
    "method": "CoWVLA",
    "value": 92.8,
    "family": "Unified VLA"
   },
   {
    "method": "F1",
    "value": 91.3,
    "family": "Unified VLA"
   },
   {
    "method": "TriVLA",
    "value": 73.2,
    "family": "Unified VLA"
   },
   {
    "method": "VLA-JEPA",
    "value": 95.8,
    "family": "Latent-space WM"
   },
   {
    "method": "JEPA-VLA",
    "value": 94.8,
    "family": "Latent-space WM"
   }
  ]
 },
 {
  "id": "robotwin-a",
  "short": "RoboTwin RT-A",
  "name": "RoboTwin 2.0, RT-A",
  "metric": "Success rate (%)",
  "source": "P03 Table 6",
  "max": 100,
  "caption": "RT-A is the simple setting with non-randomized test environments. Look at which methods fall furthest when you switch to RT-B.",
  "rows": [
   {
    "method": "Vidar",
    "value": 65.8,
    "family": "Decoupled"
   },
   {
    "method": "Video2Act",
    "value": 54.6,
    "family": "Decoupled"
   },
   {
    "method": "Motus",
    "value": 88.7,
    "family": "MoE / MoT"
   },
   {
    "method": "LingBot-VA",
    "value": 92.9,
    "family": "MoE / MoT"
   },
   {
    "method": "LingBot-VLA",
    "value": 88.6,
    "family": "MoE / MoT"
   },
   {
    "method": "BagelVLA",
    "value": 75.3,
    "family": "MoE / MoT"
   },
   {
    "method": "FRAPPE",
    "value": 57.5,
    "family": "MoE / MoT"
   },
   {
    "method": "InternVLA-A1",
    "value": 89.4,
    "family": "Unified VLA"
   },
   {
    "method": "HALO",
    "value": 80.5,
    "family": "Unified VLA"
   },
   {
    "method": "JEPA-VLA",
    "value": 73.5,
    "family": "Latent-space WM"
   }
  ]
 },
 {
  "id": "robotwin-b",
  "short": "RoboTwin RT-B",
  "name": "RoboTwin 2.0, RT-B",
  "metric": "Success rate (%)",
  "source": "P03 Table 6",
  "max": 100,
  "caption": "RT-B is the harder setting with randomized environments. Several methods above 50% on RT-A drop below 30% here.",
  "rows": [
   {
    "method": "Vidar",
    "value": 17.5,
    "family": "Decoupled"
   },
   {
    "method": "Video2Act",
    "value": 54.1,
    "family": "Decoupled"
   },
   {
    "method": "Motus",
    "value": 87.0,
    "family": "MoE / MoT"
   },
   {
    "method": "LingBot-VA",
    "value": 91.6,
    "family": "MoE / MoT"
   },
   {
    "method": "LingBot-VLA",
    "value": 86.7,
    "family": "MoE / MoT"
   },
   {
    "method": "BagelVLA",
    "value": 20.9,
    "family": "MoE / MoT"
   },
   {
    "method": "FRAPPE",
    "value": 25.5,
    "family": "MoE / MoT"
   },
   {
    "method": "InternVLA-A1",
    "value": 87.0,
    "family": "Unified VLA"
   },
   {
    "method": "HALO",
    "value": 26.4,
    "family": "Unified VLA"
   },
   {
    "method": "JEPA-VLA",
    "value": 17.7,
    "family": "Latent-space WM"
   }
  ]
 },
 {
  "id": "calvin-a",
  "short": "CALVIN C-A",
  "name": "CALVIN, C-A protocol",
  "metric": "Average length (tasks, of 5)",
  "source": "P03 Table 6",
  "max": 5,
  "caption": "Average number of chained tasks completed out of five. P03 labels this protocol C-A; its footnote calls it ABCD.",
  "rows": [
   {
    "method": "UniPi",
    "value": 0.92,
    "family": "Decoupled"
   },
   {
    "method": "VidMan",
    "value": 3.42,
    "family": "Decoupled"
   },
   {
    "method": "VPP",
    "value": 4.33,
    "family": "Decoupled"
   },
   {
    "method": "BagelVLA",
    "value": 4.41,
    "family": "MoE / MoT"
   },
   {
    "method": "GR-1",
    "value": 3.06,
    "family": "Unified VLA"
   },
   {
    "method": "UP-VLA",
    "value": 4.08,
    "family": "Unified VLA"
   },
   {
    "method": "DreamVLA",
    "value": 4.44,
    "family": "Unified VLA"
   },
   {
    "method": "Unified VLA",
    "value": 4.41,
    "family": "Unified VLA"
   },
   {
    "method": "CoWVLA",
    "value": 4.21,
    "family": "Unified VLA"
   },
   {
    "method": "TriVLA",
    "value": 4.37,
    "family": "Unified VLA"
   }
  ]
 },
 {
  "id": "calvin-d",
  "short": "CALVIN C-D",
  "name": "CALVIN, C-D protocol",
  "metric": "Average length (tasks, of 5)",
  "source": "P03 Table 6",
  "max": 5,
  "caption": "Average chained tasks out of five under the protocol P03 labels C-D (footnote: ABCDD). Compare GR-1 and UP-VLA with their C-A lengths.",
  "rows": [
   {
    "method": "UD-VLA",
    "value": 4.64,
    "family": "Single-backbone"
   },
   {
    "method": "GR-1",
    "value": 4.21,
    "family": "Unified VLA"
   },
   {
    "method": "UP-VLA",
    "value": 4.42,
    "family": "Unified VLA"
   },
   {
    "method": "Unified VLA",
    "value": 4.63,
    "family": "Unified VLA"
   },
   {
    "method": "CoWVLA",
    "value": 4.47,
    "family": "Unified VLA"
   }
  ]
 },
 {
  "id": "simpler-g",
  "short": "SIMPLER Google",
  "name": "SIMPLER-style, Google Robot",
  "metric": "Success rate (%)",
  "source": "P03 Table 6",
  "max": 100,
  "caption": "Only three methods report a single number here; VideoVLA reports two protocol variants and is left out.",
  "rows": [
   {
    "method": "CoWVLA",
    "value": 60.9,
    "family": "Unified VLA"
   },
   {
    "method": "VLA-JEPA",
    "value": 65.2,
    "family": "Latent-space WM"
   },
   {
    "method": "WoG",
    "value": 69.4,
    "family": "Latent-space WM"
   }
  ]
 },
 {
  "id": "simpler-w",
  "short": "SIMPLER WidowX",
  "name": "SIMPLER-style, WidowX",
  "metric": "Success rate (%)",
  "source": "P03 Table 6",
  "max": 100,
  "caption": "WidowX results spread over 23 points. Protocols differ across papers, so read the order as rough.",
  "rows": [
   {
    "method": "VideoVLA",
    "value": 53.1,
    "family": "Single-backbone"
   },
   {
    "method": "UD-VLA",
    "value": 62.5,
    "family": "Single-backbone"
   },
   {
    "method": "Unified VLA",
    "value": 69.8,
    "family": "Unified VLA"
   },
   {
    "method": "CoWVLA",
    "value": 76.0,
    "family": "Unified VLA"
   },
   {
    "method": "VLA-JEPA",
    "value": 57.3,
    "family": "Latent-space WM"
   },
   {
    "method": "WoG",
    "value": 63.5,
    "family": "Latent-space WM"
   }
  ]
 }
] };
})();
