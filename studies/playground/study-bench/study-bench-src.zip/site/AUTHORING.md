# Authoring guide: Study Bench · Robot Learning

You are writing one part of a single-file interactive study site. It must look and behave exactly like the other Study Bench sites (Reinforcement Learning, Multi-Agent RL, Modern Robotics): same design system, same components, same writing rules. The core renderer is done; you only write data and small simulations.

**Read these first:** `topics/b2.js` (the exemplar topic, the quality bar), `core/00-util.js` (helpers), and for stations `core/60-lab.js`.
**Never edit:** `src/study-bench.css`, `src/study-bench.js`, anything in `core/`, `data/methods.json`, or other agents' files. If you think the core needs a change, say so in your final summary.

## Where facts come from
- **The "book"** is 16 surveys (IDs P01–P11, P13, P14, X1–X3; P12 is not used). Cite them in `.sb-ref` form: `P01 §4.1`, `X2 eq. 50`, `P03 Table 5`, `P10 Fig. 2`. arXiv IDs: P01 2510.10903 · P02 2510.07077 · P03 2605.00080 · P04 2606.20781 · P05 2607.24744 · P06 2604.27621 · P07 2408.03539 · P08 2502.13187 · P09 2501.02116 · P10 2608.07558 · P11 2609.22319 · P13 2605.02900 · P14 2609.09250 · X1 2605.12090 · X2 2510.12403 · X3 2606.00113.
- **Method papers** were read already: `data/methods.json` (626 cards: id, name, year, arxiv, problem, idea, arch, action, params, data, results, parents, changed, limits, eqs [tier 1], pipe, steps, abl, hyper, notes). Use it first. Cite a method paper as `arXiv 2304.13705` or by name.
- To check a survey statement, use the alphaXiv MCP tools (ToolSearch `select:mcp__alphaXiv__answer_pdf_queries,mcp__alphaXiv__get_paper_content`), e.g. `answer_pdf_queries(paper="2510.10903", queries=[...])`. Batch all questions for one paper in one call.
- **Never invent a number.** Every number comes from a survey or a method card, with its ref. Numbers your own simulation computes are fine and must be labeled with a `.sb-prov` ("Illustrative", "Simplified: …", "Our toy numbers").
- Where two sources disagree, add a `ledger` row with kind "Sources disagree". Where you simplify, add a `ledger` row with kind "Simplified" or "Our choice".

## Topic file contract: `topics/<id>.js`
```js
(function () {
  "use strict";
  var RB = window.RB;
  /* playground mount functions, art strings ... */
  RB.topic({
    id: "c2",                          // must match data/topics-index.js
    title: "…",                        // 3–7 words, sentence case
    eyebrow: "Part C · World action models",   // ≤ 6 words (· separators do not count)
    lede: "…",                         // ≤ 25 words
    refs: ["P04 §2–4", "X1 §4", "P03 §3"],     // 2–4 chips
    why: "…",                          // ≤ 60 words
    outcomes: ["Explain …", "Compare …", "Compute …"],   // 3–5, each ≤ 15 words, starting with a testable verb
    concepts: [{ name, def /* ≤ 20 words */, ref, art /* inline <svg viewBox="0 0 200 56"> */, term /* glossary id */, sym /* optional symbol id */, href /* optional link, e.g. "#lab/wam" */ }],  // 3–8
    flow: { title, ref, w, h, caption /* ≤ 35 words */, nodes:[{id,x,y,w,h,label /* ≤ 3 words */,sub,kind:"agent|env|store|decision"}], edges:[{from,to,label /* every edge labeled */,sides,via,dashed,dx,dy}], steps:[{on:[ids, "a>b"], text /* ≤ 30 words */}] },  // 3–7 steps
    worked: { title, ref, prov, eq:{tex, words, key}, figure /* <svg> with data-on="n" / "n+" / "a-b" groups */, steps:[{title /* ≤ 5 words */, text /* title+text ≤ 30 words */}] },  // 3–7 steps, numbers computed by you and correct
    ruleTitle: "…",
    rules: [{ name, ref, tex, words /* ≤ 25 */, key: ["symbolId", {glyph, meaning}], term, before, beforeLabel, afterLabel, diff:true }],
    algorithm: { title, ref, prov, lines: ["html line with <span data-sym=…>", …] },   // optional
    playgrounds: [{ id, title, ref, prov, try /* ≤ 40 words */, mount: function (body, ctx) { … return api; }, demo: function (body, api) { return [steps]; } }],  // 1–3
    methods: ["method-id", …],        // featured first in the methods table (ids from data/methods.json); all topic methods are listed anyway
    open: [{ title, text /* ≤ 30 words */, refs }],   // 2–4 open problems from the surveys
    takeaways: ["…"],                  // 3–5, each ≤ 25 words
    quiz: [{ q /* ≤ 25 */, options: [/* each ≤ 12 words */], correct: 1, why /* ≤ 40 */ }],   // 3–5
    cards: [{ front /* ≤ 15 */, back /* ≤ 30 */, ref }],   // 4–8
    terms: { "kebab-id": { name, aliases:[], group, sym, symTex, def /* ≤ 35 */, note /* ≤ 30 */, ref, scene:"system|robot", focus:[part ids], look /* ≤ 8 words */, uses:[term ids] } },  // 6–14
    symbols: [{ id, tex, glyph, kind, meaning, short, first, read, papers }],   // only symbols NOT already in data/symbols.js
    ledger: [{ where, source, page, why, kind }]
  });
})();
```
Sections with nothing real to show are left out (the renderer skips them), never filled with filler.

### Equations
- TeX strings are JavaScript strings: every backslash is doubled (`"\\mathbf{a}"`).
- Wrap every symbol in `\\class{sym-<id>}{…}` with an id from `data/symbols.js` (house notation) or one you add in `symbols`. The key lists the same ids in order of appearance. Operators and anything unlisted go in the key as `{glyph, meaning}` (meaning ≤ 6 words).
- House notation: oₜ observation, sₜ state, aₜ action, 𝐚ₜ:ₜ₊H chunk, ℓ instruction, o′ future observation, z latent, π_θ policy, π_ψ action head, p_θ learned model, τ flow time (0 = noise, 1 = clean), ε noise, v_θ velocity, ε_θ noise predictor, ξ trajectory, q joint configuration, 𝛕 joint torque (bold), M(q), C(q, q̇), G(q), J(q) Jacobian, F_ext, K_d/B_d/M_d, λ contact force, μ friction, ω randomized sim parameters, r reward, γ discount, V, Q, Âₜ advantage, ρₜ ratio, J objective, ℒ loss, 𝔼, D_KL, h(x) barrier, S verifier score, N candidates, Φ/F/B/D the P04 WAM axes. See `data/symbols.js` for ids. Papers that write things differently are mapped in each symbol's `papers` field; add a `ledger` row when you convert a paper's notation.
- Diffs between a predecessor and a new rule: `before` + `tex` with `\\class{sb-new}{…}` for new terms and `\\class{sb-chg}{…}` for changed terms, and `diff: true`.
- Check that MathJax renders: the check script reports math errors.

### Playgrounds and stations (simulations)
- Small, honest simulations in plain JS: a toy that shows the mechanism, not a claimed reproduction. Label with `prov`.
- Use `RB.rng(seed)` for all randomness (reproducible). No `Math.random`.
- Colors: never hex, never named colors. Canvas: `var P = RB.pal(); ctx.fillStyle = P["data-1"]` and redraw inside `RB.onTheme(draw)`. SVG: token classes (`rb-s-ink`, `rb-s-acc`, `rb-f-soft`, `rb-t-mono`…, see `src/rb.css`) or `style="fill:var(--data-2)"`. Data colors `data-1`…`data-7` are for marks only; text stays ink.
- Canvas sizing: `var ctx = RB.canvas(cv, W, H)` (HiDPI, responsive). Put canvases in `<canvas class="rb-canvas">` inside a `<figure class="rb-fig">` with a `<figcaption class="sb-caption">` (≤ 35 words) that says what to look at.
- Controls: `RB.slider({id,label,min,max,step,value,fmt})` + `RB.bindSlider(root,id,fmt,cb)`, `RB.seg({id,label,options,value})` + `RB.bindSeg(root,id,cb)`, buttons `sb-btn` (one `sb-btn--primary` per panel, labels are verbs ≤ 3 words), readouts `RB.readouts([{id,k,u}])` + `RB.setRO(root,id,text)`, legend `RB.legend([{c,label,kind}])`. Layout helpers: `rb-row`, `rb-stack`, `rb-grid2`, `rb-grid3`, `rb-well`.
- Prefix every element id with `ctx.id` (topics) or the station id, so ids are unique on the page.
- Start in a working state: draw a real result on mount. Placeholders before a run are `–`, never NaN/undefined/0.
- Charts: `StudyBench.lineChart(host, {title, x:{label,min,max}, y:{label,min,max,fmt}, series:[{name,color:"data-1",points:[[x,y],…],dash}], caption})`, or `RB.bandChart` for mean ± band.
- Return an api object from `mount` that the demo can read (for Guide me's `expect`).

### Demos (Watch demo / Guide me)
Every playground and station has one: 4–8 steps `{target (element), title (≤ 6 words), text (≤ 30 words), do(api) /* Watch: api.click(el), api.set(inputEl, value), api.wait(ms), api.until(fn, ms) */, task (≤ 12 words), expect() /* Guide me: true when done */, done}`. A task must not be already done when its step opens. The last step says what to try next. Targets are elements inside your body (use `body.querySelector`).

### Stations: `stations/<id>.js`
```js
RB.station({
  id: "wam", name: "WAM coupling playground", sub: "Topic 11 · coupling",
  refs: ["P04 §2, §4.2", "P03 eq. 4–8"], prov: "Simplified: discrete toy world",
  summary: "≤ 40 words: what this station shows",
  notice: ["what to notice 1", "…"],          // 3–5 short items
  card: "≤ 20 words for the demo card",
  terms: { … },                               // optional, same format as topics
  ledger: [ … ],
  mount: function (api) {                     // api.scene, api.controls, api.side, api.live(state,text), api.meta(text), api.id
    …                                         // controls go in api.controls (never inside the scene)
    return { demo: function () { return [steps]; }, destroy: function () { /* stop timers, cancel animation frames */ } };
  }
});
```
Stations are richer than topic playgrounds: several modes or presets, readouts, a chart. They must run at 60 fps or be step-based, stop their timers in `destroy`, and follow the theme. Register a race if your brief says so: `RB.RACES = RB.RACES || []; RB.RACES.push({ id, short, name, methods:[{id,name}], run: function (methodId, seed) { return { curve: [[x,y], …] }; }, x:{label,min,max}, y:{label,min,max,fmt}, threshold, better:"higher"|"lower", caption, note /* html methods note: task, runs, parameters, seeds, what performance means, refs */ })`. A race run must take < 50 ms per seed.

## Writing rules (Study Bench)
- Patient teaching-assistant voice: plain, specific, second person, short sentences. No hype, no exclamation marks, no emoji. Sentence case everywhere.
- American spelling. Avoid: simply, just, obviously, clearly, basically, leverage, utilize, robust, powerful, seamless.
- Spell out every abbreviation once per topic (vision-language-action (VLA) model, world action model (WAM), behavior cloning (BC), reinforcement learning (RL)…).
- Captions say what to look at, not what the widget is.
- Word limits are enforced by `StudyBench.audit()` (the check script runs it). Prose paragraph ≤ 80 words.
- Glossary terms: definition in the surveys' wording where possible (≤ 35 words), note adds a common confusion (≤ 30 words). Term ids are kebab-case of the name. In `uses`/`related` only reference ids you define or these shared ones: multimodal-actions, action-chunk, cvae, diffusion-policy-head, flow-matching, temporal-ensembling, nfe, consistency-policy, mode-averaging.
- Glossary scene parts (for `scene`/`focus`): see `data/term-groups.js` (`SCENE_PARTS.system`, `SCENE_PARTS.robot`). Groups: foundations, learning, heads, actions, vla, world, wam, data, grasp, contact, physics, trust, eval.

## Build and check loop (run until clean)
```bash
cd /home/claude/rb/site
node --check topics/c2.js                                   # syntax
python3 tools/build.py --only c2 --stations none --out dist/t-c2.html
python3 tools/check.py dist/t-c2.html --topic c2 --shots --full --run-demos
# stations:  python3 tools/build.py --only none --stations wam --out dist/s-wam.html && python3 tools/check.py dist/s-wam.html --station wam --shots --run-demos
```
The report must show: no pageErrors, no consoleErrors, no mathErrors, empty audit, no NaN, every demo "finished", hscroll false and hscroll400 false. Then **look at the screenshots** (Read the PNGs in dist/shots/, crop tall ones with PIL) in light, dark and phone width, and fix anything that looks broken, cramped, overlapping or unreadable. Diagrams: labels must not overlap boxes or each other.
