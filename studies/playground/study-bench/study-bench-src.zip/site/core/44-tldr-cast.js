/* ===== TL;DR page, part 1: registries and the shared visual cast =====
   Sections (text) register with RB.tldr.section({...}); scenes (animated pictures) with RB.tldr.scene(id, {...}).
   Every scene is drawn with the helpers in RB.tl so the same robot, chunk, camera, cones and scores recur on the page.
   Scene contract (design system v2.9 AnimatedGuide):
     { title, h (viewBox height, width is always 420), hold (ms after the last beat),
       draw: function (T) { return "<svg inner markup>"; },   parts carry data-a="<id>" (T helpers take {a:"id"})
       beats: [{ cap, on, off, cls, move, set, text, dur }] }   3–6 beats, caption ≤ 12 words
   Parts are hidden until a beat turns them on, unless they have {base:true}. A base part can never be turned off,
   so anything a later beat hides (the arm's first pose, a block that moves) is turned on in beat 1 instead.
   Write subscripts as a_t, π_θ, o_{t+1}: the text pass draws them as sub/superscripts in the SVG and typesets them in captions. */
(function () {
  "use strict";
  var RB = window.RB;
  RB.TLDR = []; RB.TLDR_SCENES = {};
  RB.tldr = {
    section: function (o) { RB.TLDR.push(o); },
    scene: function (id, o) { RB.TLDR_SCENES[id] = o; }
  };

  function q(v) { return String(v).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;"); }
  function r1(v) { return Math.round(v * 10) / 10; }
  /* attribute string; a → data-a, cls → class (+ a-base when base:true), arrow → marker-end */
  function at(o) {
    o = o || {}; var out = [], cls = o.cls || "";
    if (o.base) cls = (cls + " a-base").trim();
    if (o.draw) cls = (cls + " a-draw").trim();
    Object.keys(o).forEach(function (k) {
      var v = o[k]; if (v == null || v === false) return;
      if (k === "base" || k === "draw" || k === "cls" || k === "arrow" || k === "anchor" || k === "label") return;
      out.push((k === "a" ? "data-a" : k) + '="' + q(v) + '"');
    });
    if (cls) out.push('class="' + q(cls) + '"');
    if (o.arrow) out.push('marker-end="url(#m-@SID-' + o.arrow + ')"');
    if (o.anchor) out.push('text-anchor="' + o.anchor + '"');
    return out.join(" ");
  }
  function ext(a, b) { var o = {}; Object.keys(a || {}).forEach(function (k) { o[k] = a[k]; }); Object.keys(b || {}).forEach(function (k) { o[k] = b[k]; }); return o; }
  var T = RB.tl = { ext: ext, r1: r1 };

  /* ---------- primitives ---------- */
  T.el = function (tag, o, inner) { return "<" + tag + " " + at(o) + (inner == null ? "/>" : ">" + inner + "</" + tag + ">"); };
  T.g = function (o, inner) { return T.el("g", o, inner); };
  T.text = function (x, y, s, o) { o = ext({ cls: "t-lbl" }, o); return T.el("text", ext(o, { x: x, y: y }), q(s)); };
  T.sm = function (x, y, s, o) { return T.text(x, y, s, ext({ cls: "t-sm" }, o)); };
  T.note = function (x, y, s, o) { return T.text(x, y, s, ext({ cls: "t-note" }, o)); };
  T.rect = function (x, y, w, h, o) { return T.el("rect", ext({ x: r1(x), y: r1(y), width: r1(w), height: r1(h), rx: 6 }, o)); };
  T.line = function (x1, y1, x2, y2, o) { return T.el("line", ext({ cls: "t-arr", x1: r1(x1), y1: r1(y1), x2: r1(x2), y2: r1(y2) }, o)); };
  T.path = function (d, o) { return T.el("path", ext({ cls: "t-arr", d: d }, o)); };
  T.circle = function (x, y, r, o) { return T.el("circle", ext({ cx: r1(x), cy: r1(y), r: r }, o)); };
  T.poly = function (pts, o) { return T.el("polygon", ext({ points: pts.map(function (p) { return r1(p[0]) + "," + r1(p[1]); }).join(" ") }, o)); };
  /* smooth path through points (Catmull-Rom → cubic Bézier) */
  T.curve = function (pts, o) {
    var d = "M" + r1(pts[0][0]) + " " + r1(pts[0][1]);
    for (var i = 0; i < pts.length - 1; i++) {
      var p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      d += " C" + r1(p1[0] + (p2[0] - p0[0]) / 6) + " " + r1(p1[1] + (p2[1] - p0[1]) / 6) + ", " + r1(p2[0] - (p3[0] - p1[0]) / 6) + " " + r1(p2[1] - (p3[1] - p1[1]) / 6) + ", " + r1(p2[0]) + " " + r1(p2[1]);
    }
    return T.path(d, ext({ cls: "t-line" }, o));
  };
  /* a moving token: sits at 0,0 and is moved along a path by a beat's move */
  T.tok = function (o) { return T.circle(0, 0, (o && o.r) || 6, ext({ cls: "t-tok" }, o)); };

  /* ---------- the cast ---------- */
  /* Module box with a role colour: role ∈ vision | lang | act | future | state | touch | latent | critic | ink */
  T.box = function (x, y, w, h, label, o) {
    o = o || {}; var role = o.role || "ink", sub = o.sub;
    var inner = T.rect(x, y, w, h, { cls: "t-box r-" + role, rx: 8 }) +
      T.text(x + w / 2, y + h / 2 + (sub ? -2 : 5), label, { anchor: "middle", cls: o.small ? "t-sm t-ink" : "t-lbl" }) +
      (sub ? T.sm(x + w / 2, y + h / 2 + 16, sub, { anchor: "middle" }) : "");
    return T.g({ a: o.a, base: o.base, cls: o.gcls }, inner);
  };
  /* The robot: a 2-link planar arm with a parallel gripper. a1, a2 in degrees from horizontal (counter-clockwise, y up). */
  T.armPose = function (x, y, a1, a2, l1, l2) {
    l1 = l1 || 78; l2 = l2 || 66;
    var r = Math.PI / 180, ex = x + l1 * Math.cos(a1 * r), ey = y - l1 * Math.sin(a1 * r);
    var tx = ex + l2 * Math.cos((a1 + a2) * r), ty = ey - l2 * Math.sin((a1 + a2) * r);
    return { ex: ex, ey: ey, tx: tx, ty: ty, dir: a1 + a2 };
  };
  T.arm = function (x, y, a1, a2, o) {
    o = o || {}; var P = T.armPose(x, y, a1, a2, o.l1, o.l2), r = Math.PI / 180, d = P.dir * r;
    var ux = Math.cos(d), uy = -Math.sin(d), nx = -uy, ny = ux, open = o.grip === "closed" ? 6 : 11, L = 14;
    var f1 = [P.tx + nx * open, P.ty + ny * open], f2 = [P.tx - nx * open, P.ty - ny * open];
    var g = T.rect(x - 22, y + 4, 44, 12, { cls: "t-base", rx: 3 }) +
      T.line(x, y, P.ex, P.ey, { cls: "t-link" }) + T.line(P.ex, P.ey, P.tx, P.ty, { cls: "t-link" }) +
      T.line(f1[0], f1[1], f2[0], f2[1], { cls: "t-grip" }) +
      T.line(f1[0], f1[1], f1[0] + ux * L, f1[1] + uy * L, { cls: "t-grip" }) + T.line(f2[0], f2[1], f2[0] + ux * L, f2[1] + uy * L, { cls: "t-grip" }) +
      T.circle(x, y, 6, { cls: "t-joint" }) + T.circle(P.ex, P.ey, 5, { cls: "t-joint" });
    return T.g({ a: o.a, base: o.base, cls: ("t-arm " + (o.cls || "")).trim() }, g);
  };
  T.table = function (x, y, w, o) { return T.line(x, y, x + w, y, ext({ cls: "t-table" }, o)); };
  T.block = function (x, y, w, h, o) { o = o || {}; return T.g({ a: o.a, base: o.base }, T.rect(x, y, w, h, { cls: "t-block", rx: 3 }) + (o.label ? T.sm(x + w / 2, y + h / 2 + 5, o.label, { anchor: "middle" }) : "")); };
  T.pad = function (x, y, w, o) { o = o || {}; return T.g({ a: o.a, base: o.base }, T.rect(x, y - 6, w, 6, { cls: "t-pad", rx: 2 }) + (o.label === false ? "" : T.sm(x + w / 2, y + 18, o.label || "goal", { anchor: "middle" }))); };
  /* camera glyph looking right-down; fov:true adds a dashed view cone */
  T.cam = function (x, y, o) {
    o = o || {};
    var g = T.rect(x - 14, y - 9, 24, 18, { cls: "t-cam", rx: 3 }) + T.circle(x + 12, y, 5, { cls: "t-cam" }) +
      (o.fov ? T.path("M" + (x + 16) + " " + (y - 4) + " L" + (x + (o.fx || 150)) + " " + (y + (o.fy1 || 60)) + " M" + (x + 16) + " " + (y + 4) + " L" + (x + (o.fx || 150) - 40) + " " + (y + (o.fy2 || 110)), { cls: "t-ghostl" }) : "");
    return T.g({ a: o.a, base: o.base }, g);
  };
  /* speech tag: the instruction ℓ */
  T.say = function (x, y, s, o) {
    o = o || {}; var w = o.w || (s.length * 7.4 + 20);
    return T.g({ a: o.a, base: o.base }, T.rect(x, y, w, 26, { cls: "t-say", rx: 13 }) + T.sm(x + w / 2, y + 18, s, { anchor: "middle", cls: "t-sm t-ink" }));
  };
  /* action chunk: n tiles; each tile has its own part id (o.a + i) so beats can drain them */
  T.chunk = function (x, y, n, o) {
    o = o || {}; var w = o.w || 12, gap = o.gap || 3, h = o.h || 16, s = "";
    for (var i = 0; i < n; i++) s += T.rect(x + i * (w + gap), y, w, h, { a: o.each ? o.a + i : null, base: o.each && o.base, cls: "t-tile " + (o.cls || ""), rx: 2 });
    return o.each ? s : T.g({ a: o.a, base: o.base }, s);
  };
  /* a friction cone at a contact: apex at (x,y), axis direction deg (SVG angle, 0 = right, 90 = down), half-angle deg */
  T.cone = function (x, y, dir, half, len, o) {
    var r = Math.PI / 180, a = (dir - half) * r, b = (dir + half) * r;
    return T.poly([[x, y], [x + len * Math.cos(a), y + len * Math.sin(a)], [x + len * Math.cos(b), y + len * Math.sin(b)]], ext({ cls: "t-cone" }, o));
  };
  /* axes: x from (x,y) to x+w, y up to y-h */
  T.axes = function (x, y, w, h, o) { o = o || {}; return T.g({ a: o.a, base: o.base !== false }, T.path("M" + x + " " + (y - h) + " L" + x + " " + y + " L" + (x + w) + " " + y, { cls: "t-ax" }) + (o.xl ? T.sm(x + w, y + 18, o.xl, { anchor: "end" }) : "") + (o.yl ? T.sm(x - 6, y - h - 6, o.yl) : "")); };
  /* a vertical score bar that grows: rect anchored at the bottom (y is the baseline); tween y and height together */
  T.vbar = function (x, y, w, h0, o) { return T.rect(x, y - h0, w, h0, ext({ cls: "t-score", rx: 2 }, o)); };

  /* ---------- whole figure ---------- */
  var MARK = { ink: "var(--ink-2)", act: "var(--data-3)", vision: "var(--data-1)", lang: "var(--data-2)", future: "var(--data-4)", good: "var(--good)", bad: "var(--bad)", acc: "var(--accent)", touch: "var(--data-6)", critic: "var(--data-8)" };
  T.figure = function (id, sc) {
    var sid = id.replace(/[^\w-]/g, ""), h = sc.h || 240;
    var defs = "<defs>" + Object.keys(MARK).map(function (k) { return '<marker id="m-' + sid + "-" + k + '" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L8 4L0 8z" style="fill:' + MARK[k] + '"/></marker>'; }).join("") + "</defs>";
    var inner = "";
    try { inner = sc.draw(T); } catch (e) { RB.warn("tldr scene " + id + ": " + e.message); }
    inner = inner.replace(/@SID/g, sid);
    var beats = (sc.beats || []).map(function (b) {
      var a = [];
      ["on", "off", "cls", "move", "set", "text", "dur"].forEach(function (k) { if (b[k] != null) a.push("data-" + k + '="' + q(b[k]) + '"'); });
      return "<li " + a.join(" ") + ">" + RB.esc(b.cap) + "</li>";
    }).join("");
    return '<figure class="sb-anim rb-tl-fig" data-hold="' + (sc.hold || 2400) + '"><svg viewBox="0 0 420 ' + h + '" role="img" aria-labelledby="tl-' + sid + '-t"><title id="tl-' + sid + '-t">' + RB.esc(sc.title || id) + "</title>" + defs + inner +
      '</svg><figcaption class="sb-anim-cap" data-no-autolink><ol class="sb-anim-beats">' + beats + "</ol></figcaption></figure>";
  };
})();
