/* ===== TL;DR page, part 2: the page (#tldr, #tldr/<section>) =====
   One scrolling page: head (PageGuide, Pause, section map), then per part a part head and its sections.
   Each section = AnimatedGuide (RB.TLDR_SCENES[id], drawn with RB.tl) + TldrSection text. Not interactive:
   the only controls are the map links, the Pause toggle and each section's TopicLinks (Summary · Open topic →).
   Equations come from the topics' own rules (same TeX, words and symbol key), so nothing is retyped here. */
(function () {
  "use strict";
  var RB = window.RB, esc = RB.esc;
  var PART_LEDE = {
    A: "What a robot policy is, the controller under it, and the two classic ways to get one.",
    B: "Copy demonstrations, model their full spread, write actions efficiently, then scale with pretrained backbones and planners.",
    C: "Models that imagine what happens next: to plan with, to act with, and to practise inside.",
    D: "Where training data comes from, and how human video is made useful to a robot.",
    E: "Holding things, many-fingered hands, cloth and two arms, balancing bodies, contact and mechanics.",
    F: "Score what a policy does, keep it from being turned against you, and measure it honestly."
  };
  var MIN_PER = 40; /* seconds per section: watch + read */

  function words(s) { return String(s || "").replace(/<[^>]+>/g, "").trim().split(/\s+/).filter(Boolean).length; }
  function count() { var n = RB.TLDR.length; return n + " sections · about " + Math.round(n * MIN_PER / 60) + " min"; }

  /* \class{sb-new}{…} and \class{sb-chg}{…} mark diffs on topic pages; a TL;DR shows the plain rule */
  function undiff(tex) {
    var out = tex, re = /\\class\{sb-(?:new|chg)\}\{/;
    for (var guard = 0; guard < 50; guard++) {
      var m = re.exec(out); if (!m) break;
      var i = m.index + m[0].length, depth = 1, j = i;
      for (; j < out.length && depth; j++) { if (out[j] === "{" && out[j - 1] !== "\\") depth++; else if (out[j] === "}" && out[j - 1] !== "\\") depth--; }
      out = out.slice(0, m.index) + out.slice(i, j - 1) + out.slice(j);
    }
    return out;
  }
  function eqFor(s) {
    if (!s.eq) return "";
    var spec = s.eq.spec;
    if (!spec) { var t = RB.topics[s.eq.t], r = t && t.rules && t.rules[s.eq.r]; if (!r) { RB.warn("tldr " + s.id + ": no rule " + s.eq.t + "[" + s.eq.r + "]"); return ""; } spec = r; }
    return RB.eqBlock({ name: spec.name, ref: spec.ref, tex: undiff(spec.tex), words: spec.words, key: spec.key, term: spec.term }, { cls: "rb-tl-eq" });
  }
  function refOf(s) {
    if (s.ref) return s.ref;
    return (s.topics || []).map(function (k) { return (RB.topics[k] || {}).sources || ""; }).filter(Boolean).join(" · ");
  }
  /* v2.10 TopicLinks in place of "Go deeper": Summary · Open topic → (recap: See the evolution →) */
  function deeper(s) { return RB.topicLinks ? RB.topicLinks("tldr", s.topics || []) : ""; }
  function sectionHTML(s, i) {
    var sc = RB.TLDR_SCENES[s.id];
    var fig = sc ? RB.tl.figure(s.id, sc) : '<figure class="rb-tl-fig rb-tl-missing"><div class="sb-empty"><p>Picture coming.</p></div></figure>';
    var text = '<div class="sb-tldr-text"><div class="sb-tldr-n">' + esc(s.n) + " · " + esc(refOf(s)) + "</div>" +
      '<h3 class="sb-tldr-title" id="tl-' + s.id + '-h">' + esc(s.title) + "</h3>" +
      '<p class="sb-tldr-sum"><b>TL;DR</b>' + s.sum + "</p>" +
      (s.points && s.points.length ? '<ul class="sb-tldr-points">' + s.points.map(function (p) { return "<li>" + p + "</li>"; }).join("") + "</ul>" : "") +
      eqFor(s) +
      (s.remember ? '<p class="sb-tldr-remember"><b>Remember:</b> ' + s.remember + "</p>" : "") +
      '<div class="sb-chips rb-tl-foot">' + deeper(s) + "</div></div>";
    return '<section class="sb-sec sb-tldr' + (i % 2 ? " is-flip" : "") + '" id="tldr-' + s.id + '" aria-labelledby="tl-' + s.id + '-h">' + fig + text + "</section>";
  }
  function partHTML(p) {
    var list = RB.TLDR.filter(function (s) { return s.part === p.id; });
    if (!list.length) return "";
    var span = list[0].n + (list.length > 1 ? "–" + list[list.length - 1].n : "");
    return '<section class="sb-sec sb-tldr-part" id="tldr-part-' + p.id.toLowerCase() + '" aria-labelledby="tldr-part-' + p.id + '-h"><header class="sb-sec-head"><p class="sb-eyebrow">Part ' + p.id + " · sections " + span + '</p><h2 class="sb-sec-title" id="tldr-part-' + p.id + '-h">' + esc(p.name) + '</h2><p class="sb-sec-lede">' + esc(PART_LEDE[p.id] || "") + "</p>" + (p.id === "A" ? RB.demoLaunch("tldr-tour", "4 steps · about 20 seconds") : "") + "</header></section>";
  }

  var built = false;
  function build() {
    if (built) return; built = true;
    var host = document.getElementById("tldrHost"), head = document.getElementById("tldrHead"); if (!host) return;
    var parts = RB.PARTS.concat([{ id: "R", name: "Recap" }]);
    /* head: count, Pause toggle, section map grouped by part */
    document.getElementById("tldrEyebrow").textContent = count();
    head.insertAdjacentHTML("beforeend", '<div class="sb-tldr-bar"><span class="sb-count">' + count() + '</span><button type="button" class="sb-btn" data-anim-toggle>Pause animations</button></div>' +
      '<div class="rb-tl-map" id="tldrMap">' + parts.map(function (p) {
        var list = RB.TLDR.filter(function (s) { return s.part === p.id; }); if (!list.length) return "";
        return '<div class="rb-tl-mapgroup"><p class="sb-eyebrow">' + (p.id === "R" ? "Recap" : "Part " + p.id + " · " + esc(p.name)) + '</p><ol class="sb-tldr-map" aria-label="' + esc(p.name) + '">' + list.map(function (s) { return '<li><a href="#tldr/' + s.id + '"><span class="n">' + esc(s.n) + "</span>" + esc(s.title) + (s.topics && s.topics.length ? '<span class="sb-done" data-done="' + s.topics.join(" ") + '" hidden>✓</span>' : "") + "</a></li>"; }).join("") + "</ol></div>";
      }).join("") + "</div>");
    var html = "", k = 0;
    parts.forEach(function (p) {
      if (p.id !== "R") html += partHTML(p);
      RB.TLDR.filter(function (s) { return s.part === p.id; }).forEach(function (s) { html += sectionHTML(s, k++); });
    });
    host.innerHTML = html;
    RB.$$(".rb-tl-eq", host).forEach(function (e) { StudyBench.link(e); });
    RB.typeset(host);
    RB.linkTerms && RB.linkTerms(host);
    if (StudyBench.animAll) StudyBench.animAll(document.getElementById("view-tldr"));
    RB.hintFirstDemo("tldr");
    if (RB.syncDone) RB.syncDone();
    audit();
  }
  /* word limits of the design system (title 8, TL;DR 30, point 15, Remember 15, caption 12) → RB.warn */
  function audit() {
    RB.TLDR.forEach(function (s) {
      if (words(s.title) > 8) RB.warn("tldr " + s.id + ": title " + words(s.title) + " words");
      if (words(s.sum) > 30) RB.warn("tldr " + s.id + ": TL;DR " + words(s.sum) + " words");
      if (words(s.remember) > 15) RB.warn("tldr " + s.id + ": Remember " + words(s.remember) + " words");
      (s.points || []).forEach(function (p, i) { if (words(p) > 15) RB.warn("tldr " + s.id + ": point " + (i + 1) + " " + words(p) + " words"); });
      var sc = RB.TLDR_SCENES[s.id];
      if (!sc) { RB.warn("tldr " + s.id + ": no scene"); return; }
      if (sc.beats.length < 3 || sc.beats.length > 6) RB.warn("tldr " + s.id + ": " + sc.beats.length + " beats");
      sc.beats.forEach(function (b, i) { if (words(b.cap) > 12) RB.warn("tldr " + s.id + ": caption " + (i + 1) + " " + words(b.cap) + " words"); });
    });
  }
  RB.tldrAudit = audit;

  function jump(id) {
    var el = id === "map" ? document.getElementById("tldrMap") : document.getElementById("tldr-" + id);
    if (!el) return;
    var h = location.hash;
    /* the app bar wraps to two rows on narrow screens: measure it instead of trusting --appbar-h */
    function go() { var bar = document.querySelector(".sb-appbar"), off = (bar ? bar.getBoundingClientRect().height : 56) + 12; window.scrollTo(0, window.scrollY + el.getBoundingClientRect().top - off); return off; }
    setTimeout(go, 60);
    /* equations above typeset after the jump and push the section down: settle once more */
    setTimeout(function () { var bar = document.querySelector(".sb-appbar"), off = (bar ? bar.getBoundingClientRect().height : 56) + 12; if (location.hash === h && Math.abs(el.getBoundingClientRect().top - off) > 12) go(); }, 1100);
  }
  RB.pages.tldr = {
    init: build,
    show: function (o) { build(); if (o.rest && o.rest[0]) jump(o.rest[0]); }
  };

  RB.howto["tldr-start"] = function () { build(); var s = document.querySelector("#tldrHost .sb-tldr"); if (s) s.scrollIntoView({ block: "start" }); };
  RB.howto["tldr-map"] = function () { build(); var m = document.getElementById("tldrMap"); if (m) { m.scrollIntoView({ block: "center" }); StudyBench.flash && StudyBench.flash(m); } };
  RB.howto["tldr-deeper"] = function () { RB.go("#explorer"); };

  /* demo: map → a picture playing → Pause → Open topic */
  RB.demos["tldr-tour"] = function () {
    var $ = function (s) { return document.querySelector(s); };
    var ex = "heads", hit = {};
    var watch = function (key, get) { return function () { hit[key] = false; var el = get(); if (el) el.addEventListener("click", function () { hit[key] = true; }, { once: true }); }; };
    return [
      { target: function () { return $('#tldrMap a[href="#tldr/' + ex + '"]'); }, title: "The section map", text: "Twenty-four sections grouped by the site's six parts. Each link jumps to its section; here 06, generative policy heads.", before: function () { var m = $("#tldrMap"); if (m) m.scrollIntoView({ block: "center" }); }, do: function (a) { RB.go("#tldr/" + ex); return a.wait(1400); }, task: "Click 06 on the map", expect: function () { return location.hash === "#tldr/" + ex; } },
      { target: function () { return $("#tldr-" + ex + " .sb-anim"); }, title: "Pictures play by themselves", text: "Each picture plays when it scrolls into view, one beat at a time. The numbered captions say what each beat shows.", before: function () { var f = $("#tldr-" + ex); if (f) f.scrollIntoView({ block: "start" }); }, wait: 5600 },
      { target: function () { return $("#view-tldr [data-anim-toggle]"); }, title: "Pause animations", text: "Pause stops every picture on the page, and the choice is remembered. Press it again to play.", do: function (a) { var b = $("#view-tldr [data-anim-toggle]"); if (b) { b.click(); } return a.wait(1600).then(function () { if (b) b.click(); return a.wait(300); }); }, before: watch("pause", function () { return $("#view-tldr [data-anim-toggle]"); }), task: "Press Pause animations", expect: function () { return hit.pause; } },
      { target: function () { return $("#tldr-" + ex + ' .rb-tl-foot a[href^="#explorer/"]'); }, title: "Open the topic", text: "Summary jumps to the topic's card on Overview; Open topic → opens the full lesson: the rule, a worked example, playgrounds and a quiz.", before: watch("deeper", function () { return $("#tldr-" + ex + ' .rb-tl-foot a[href^="#explorer/"]'); }), task: "Click Open topic →", expect: function () { return hit.deeper || /^#explorer\/b2/.test(location.hash); } }
    ];
  };
})();
