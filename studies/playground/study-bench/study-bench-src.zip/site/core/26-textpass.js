/* Text pass over everything the site renders:
   1) survey codes (P01 … P14, X1 … X3, the file names of the project PDFs) are shown as readable survey names, with the full title on hover;
   2) inline math written as plain text (π_θ, ε_θ, v_θ(A^τ …), p_φ, a_{t:t+H}) is typeset with MathJax, so it looks like the equations
      (inside SVG, where MathJax cannot go, the subscript and superscript are drawn with shifted tspans). */
(function () {
  var RB = window.RB;
  var NAMES = { P01: "Manipulation survey", P02: "VLA survey", P03: "World-model survey", P04: "WAM survey", P05: "Data-pyramid survey", P06: "Human-video survey", P07: "Real-world RL survey", P08: "Sim-to-real survey", P09: "Humanoid survey", P10: "Touch-and-force survey", P11: "Physics-priors survey", P12: "Navigation survey", P13: "Safety survey", P14: "Verifier survey", X1: "WAM frontier survey", X2: "LeRobot tutorial", X3: "Manipulation world-model survey", X4: "In-context learning survey" };
  RB.SURVEY_NAMES = NAMES;
  var CODE = /\b(P(?:0[1-9]|1[0-4])|X[1-4])\b/g;
  var GREEK = { "α": "\\alpha", "β": "\\beta", "γ": "\\gamma", "δ": "\\delta", "ε": "\\epsilon", "ϵ": "\\epsilon", "ζ": "\\zeta", "η": "\\eta", "θ": "\\theta", "κ": "\\kappa", "λ": "\\lambda", "μ": "\\mu", "ν": "\\nu", "ξ": "\\xi", "π": "\\pi", "ρ": "\\rho", "σ": "\\sigma", "τ": "\\tau", "φ": "\\phi", "ϕ": "\\phi", "χ": "\\chi", "ψ": "\\psi", "ω": "\\omega", "Δ": "\\Delta", "Φ": "\\Phi", "Ψ": "\\Psi", "Θ": "\\Theta", "Σ": "\\Sigma", "Ω": "\\Omega", "ℓ": "\\ell", "′": "'" };
  var SYM = "A-Za-zα-ωΑ-Ωϕϵℓ";
  /* a symbol with a subscript and/or superscript: x_t, π_θ, a_{t:t+H}, A^τ, π^Δ_θ, V_ψ̄ */
  var MATH = new RegExp("(^|[^\\w\\\\$/.])([" + SYM + "](?:\\^(?:\\{[^}\\s]{1,12}\\}|[" + SYM + "0-9*′Δ]+))?_(?:\\{[^}\\s]{1,16}\\}|[" + SYM + "0-9*′]+̄?)(?:\\^(?:\\{[^}\\s]{1,12}\\}|[" + SYM + "0-9*′]+))?|[" + SYM + "]\\^(?:\\{[^}\\s]{1,12}\\}|[" + SYM + "0-9*′]+))", "g");
  function tex(tok) {
    tok = tok.replace(/([_^])([^{_^]{2,})/g, function (m, op, body) { return op + "{" + body + "}"; });
    return tok.replace(/̄/g, "").replace(/[α-ωΑ-Ωϕϵℓ′]/g, function (c) { return (GREEK[c] || c) + (GREEK[c] && /[a-z]$/i.test(GREEK[c]) ? " " : ""); }).replace(/\s+([}_^])/g, "$1").replace(/\s+$/, "");
  }
  var SKIP = "script,style,code,pre,textarea,input,select,option,mjx-container,.rb-math,.MathJax,[data-no-textpass],.sb-eqkey-sym,.rb-imath,title,a[href^=\"http\"]";
  function skip(el) { return !el || (el.closest && el.closest(SKIP)); }

  function svgMath(node) {
    var t = node.nodeValue, parent = node.parentNode, out = document.createDocumentFragment(), last = 0, m, re = new RegExp(MATH.source, "g"), NS = "http://www.w3.org/2000/svg";
    while ((m = re.exec(t))) {
      var start = m.index + m[1].length, tok = m[2];
      out.appendChild(document.createTextNode(t.slice(last, start)));
      var parts = tok.match(/^([^_^]+)(?:\^(\{[^}]*\}|[^_]+))?(?:_(\{[^}]*\}|[^\^]+))?(?:\^(\{[^}]*\}|.+))?$/) || [tok, tok];
      out.appendChild(document.createTextNode(parts[1]));
      [[parts[2] || parts[4], "super"], [parts[3], "sub"]].forEach(function (x) { if (!x[0]) return; var ts = document.createElementNS(NS, "tspan"); ts.setAttribute("baseline-shift", x[1]); ts.setAttribute("font-size", "72%"); ts.textContent = x[0].replace(/[{}]/g, ""); out.appendChild(ts); var back = document.createElementNS(NS, "tspan"); back.textContent = "​"; out.appendChild(back); });
      last = start + tok.length;
    }
    if (!last) return false;
    out.appendChild(document.createTextNode(t.slice(last)));
    parent.replaceChild(out, node); return true;
  }

  RB.textPass = function (root) {
    root = root || document.body; if (!root || skip(root.nodeType === 1 ? root : root.parentElement)) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), list = [], n;
    while ((n = walker.nextNode())) { if (/P(?:0[1-9]|1[0-4])|X[1-4]|[_^]/.test(n.nodeValue) && !/\\[(\[]/.test(n.nodeValue) && !skip(n.parentElement)) list.push(n); }
    var toTypeset = [];
    list.forEach(function (node) {
      if (!node.parentNode) return;
      var inSvg = node.parentElement && node.parentElement.closest && node.parentElement.closest("svg");
      /* survey codes → names (title on the nearest element) */
      if (CODE.test(node.nodeValue)) {
        CODE.lastIndex = 0; var el = node.parentElement, ids = [];
        node.nodeValue = node.nodeValue.replace(CODE, function (k) { if (ids.indexOf(k) < 0) ids.push(k); return NAMES[k]; });
        if (el && !el.title && RB.PAPERS) { var map = {}; RB.PAPERS.forEach(function (p) { map[p.id] = p; }); el.title = ids.filter(function (k) { return map[k]; }).map(function (k) { return NAMES[k] + ": " + map[k].title + " (arXiv " + map[k].arxiv + ")"; }).join("\n"); }
      }
      CODE.lastIndex = 0;
      if (!/[_^]/.test(node.nodeValue)) return;
      if (inSvg) { svgMath(node); return; }
      var t = node.nodeValue, re = new RegExp(MATH.source, "g"), m, last = 0, html = "", hit = false;
      while ((m = re.exec(t))) { var start = m.index + m[1].length; html += RB.esc(t.slice(last, start)) + "\\(" + tex(m[2]) + "\\)"; last = start + m[2].length; hit = true; }
      if (!hit) return;
      html += RB.esc(t.slice(last));
      var span = document.createElement("span"); span.className = "rb-imath"; span.innerHTML = html;
      node.parentNode.replaceChild(span, node); toTypeset.push(span);
    });
    toTypeset.forEach(function (sp) { RB.typeset(sp); });
  };

  /* run on everything that appears on the page */
  var pending = [], timer = null;
  function flush() { timer = null; var roots = pending; pending = []; roots.forEach(function (r) { if (r.isConnected) RB.textPass(r); }); }
  RB.startTextPass = function () {
    RB.textPass(document.body);
    new MutationObserver(function (muts) {
      muts.forEach(function (mu) { mu.addedNodes.forEach(function (nd) { var el = nd.nodeType === 1 ? nd : nd.parentElement; if (el && !skip(el) && pending.indexOf(el) < 0) pending.push(el); }); if (mu.type === "characterData" && mu.target.parentElement) pending.push(mu.target.parentElement); });
      if (pending.length && !timer) timer = setTimeout(flush, 40);
    }).observe(document.body, { childList: true, subtree: true });
  };
})();
