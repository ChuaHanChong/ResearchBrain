/* ===== TopicLinks (design system v2.10): one topic, three depths =====
   Every topic is seen at three depths: its Summary card on Overview (#overview/<topic>), its TL;DR section (#tldr/<section>)
   and the lesson in the Topic Explorer (#explorer/<topic>). One row of links ties them together, same words, same order,
   leaving out the place you are on: Summary · ▶ TL;DR · Open topic →. One ✓ Understood state shows on the card,
   the TL;DR section, its box in the section map and the topic head. */
(function () {
  "use strict";
  var RB = window.RB, esc = RB.esc;

  /* topic → first TL;DR section that covers it */
  var MAP = null;
  function mapping() {
    if (MAP) return MAP;
    MAP = {};
    (RB.TLDR || []).forEach(function (s) { (s.topics || []).forEach(function (t) { if (!MAP[t]) MAP[t] = s.id; }); });
    return MAP;
  }
  RB.topicTldr = function (t) { return mapping()[t] || null; };

  /** here: "overview" | "tldr" | "explorer"; topics: the topic ids this place shows (none = a recap) */
  RB.topicLinks = function (here, topics) {
    topics = (topics || []).filter(function (t) { return RB.topics[t]; });
    var out = [];
    if (!topics.length) {
      out.push('<a class="sb-link" href="#evolution">See the evolution →</a>');
      return '<div class="sb-topiclinks" role="group" aria-label="This topic elsewhere">' + out.join("") + "</div>";
    }
    if (here !== "overview") out.push('<a class="sb-link" href="#overview/' + topics[0] + '">Summary</a>');
    var sec = RB.topicTldr(topics[0]);
    if (here !== "tldr" && sec) out.push('<a class="sb-link" href="#tldr/' + sec + '">▶ TL;DR</a>');
    if (here !== "explorer") topics.forEach(function (t) {
      out.push('<a class="sb-link" href="#explorer/' + t + '">' + (topics.length > 1 ? "Open topic: " + esc(RB.topics[t].short || RB.topics[t].title) + " →" : "Open topic →") + "</a>");
    });
    out.push('<span class="sb-done" data-done="' + topics.join(" ") + '" hidden>✓ Understood</span>');
    return '<div class="sb-topiclinks" role="group" aria-label="This topic elsewhere">' + out.join("") + "</div>";
  };

  /* one done state everywhere */
  RB.syncDone = function () {
    var P = RB.progress; if (!P || !P.get) return;
    RB.$$(".sb-done[data-done]").forEach(function (d) {
      var ts = d.getAttribute("data-done").split(/\s+/).filter(Boolean);
      d.hidden = !(ts.length && ts.every(function (t) { return P.get(t); }));
    });
  };
  /* progress exists after boot; subscribe once it does */
  var tries = 0;
  (function hook() {
    if (RB.progress && RB.progress.onChange) { RB.progress.onChange(function () { setTimeout(RB.syncDone, 0); }); return; }
    if (tries++ < 50) setTimeout(hook, 100);
  })();
  window.addEventListener("hashchange", function () { setTimeout(RB.syncDone, 50); });
})();
