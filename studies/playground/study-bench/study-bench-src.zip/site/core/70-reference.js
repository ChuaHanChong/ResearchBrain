/* ===== Reference: formula sheet, review cards, where the papers disagree, dataset atlas, paper shelf ===== */
(function () {
  "use strict";
  var RB = window.RB, esc = RB.esc;

  function allRules() {
    var out = [];
    RB.topicOrder.forEach(function (k) { var t = RB.topics[k]; if (!t.__full) return; (t.rules || []).forEach(function (r) { out.push({ topic: k, part: t.part, r: r }); }); });
    return out;
  }

  function formulas() {
    var host = document.getElementById("ref-formulas"), F = allRules();
    host.innerHTML = '<section class="sb-sec" id="ref-f-sec">' + RB.secHead({ level: "h2", title: "Formula sheet", lede: "Every key equation on the site, grouped by part, in topic order. Hover a symbol to see it in the key." }) +
      '<div class="sb-toolbar"><input class="sb-input" type="search" id="fSearch" placeholder="Search equations" aria-label="Search equations"><span class="sb-count" id="fCount"></span></div><div class="sb-chips" id="fChips" role="group" aria-label="Filter by part"><button type="button" class="sb-tag" data-val="all" aria-pressed="true">All</button>' + RB.PARTS.map(function (p) { return '<button type="button" class="sb-tag" data-val="' + p.id + '" aria-pressed="false">Part ' + p.id + "</button>"; }).join("") + '</div><div class="sb-formulas" id="fGrid">' +
      F.map(function (f, i) {
        var r = f.r;
        return '<article class="sb-formula" data-part="' + f.part + '" data-text="' + esc((r.name + " " + (r.words || "")).toLowerCase()) + '"><div class="sb-formula-head"><p class="sb-formula-name">' + esc(r.name) + "</p>" + (r.ref ? '<span class="sb-ref">' + esc(r.ref) + "</span>" : "") + '</div><div class="sb-formula-math">' + RB.tex(r.tex) + "</div>" + (r.words ? '<p class="sb-eqwords"><b>In words:</b> ' + r.words + "</p>" : "") + RB.eqKey(r.key) + '<div class="sb-formula-foot"><a class="sb-link" href="#explorer/' + f.topic + '/rule">Topic ' + RB.topics[f.topic].num + ' →</a><button class="sb-btn sb-btn--ghost" type="button" data-copy="' + esc(r.tex) + '">Copy TeX</button></div></article>';
      }).join("") + "</div></section>";
    var q = "", part = "all", cards = RB.$$(".sb-formula", host), chips = RB.$$("#fChips button", host);
    function apply() {
      var n = 0; cards.forEach(function (c) { var ok = (part === "all" || c.getAttribute("data-part") === part) && (!q || c.getAttribute("data-text").indexOf(q) >= 0); c.hidden = !ok; if (ok) n++; });
      document.getElementById("fCount").textContent = n + " of " + cards.length + " equations";
      StudyBench.facetCounts(cards, [{ chips: chips, match: function (c, v) { return c.getAttribute("data-part") === v; }, selected: function () { return part; } }]);
    }
    host.querySelector("#fChips").addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; part = b.getAttribute("data-val"); chips.forEach(function (c) { c.setAttribute("aria-pressed", c === b ? "true" : "false"); }); apply(); });
    document.getElementById("fSearch").addEventListener("input", function (e) { q = e.target.value.trim().toLowerCase(); apply(); });
    host.addEventListener("click", function (e) { var b = e.target.closest("[data-copy]"); if (!b) return; var tex = b.getAttribute("data-copy"); if (navigator.clipboard) navigator.clipboard.writeText(tex).then(function () { b.textContent = "Copied ✓"; }, function () { b.outerHTML = "<code>" + esc(tex) + "</code>"; }); });
    apply();
    RB.$$(".sb-formula", host).forEach(function (c) { StudyBench.link(c); });
    RB.typeset(host);
  }

  function cards() {
    var host = document.getElementById("ref-cards");
    var decks = {
      terms: Object.keys(RB.terms).map(function (k) { var t = RB.terms[k]; return { front: t.name, back: String(t.def || "").replace(/<[^>]+>/g, ""), ref: t.ref || "" }; }),
      eqs: allRules().map(function (f) { return { front: "What does the " + f.r.name + " equation say?", back: String(f.r.words || "").replace(/<[^>]+>/g, ""), ref: f.r.ref || "" }; }),
      concepts: [].concat.apply([], RB.topicOrder.map(function (k) { return RB.topics[k].cards || []; }))
    };
    host.innerHTML = '<section class="sb-sec" id="ref-c-sec">' + RB.secHead({ level: "h2", title: "Review cards", lede: "Flip a card, then mark it known or not yet. Known cards stay in this browser only." }) + '<div class="sb-toolbar">' + RB.seg({ id: "deckSeg", label: "Deck", value: "concepts", options: [{ value: "concepts", label: "Concepts" }, { value: "terms", label: "Key terms" }, { value: "eqs", label: "Equations" }] }) + '<span class="sb-count" id="deckCount"></span></div><div class="sb-panel"><div class="sb-panel-body" id="deckHost"></div></div></section>';
    function draw(k) { var h = document.getElementById("deckHost"); h.innerHTML = ""; h.className = "sb-panel-body"; var d = decks[k].length ? decks[k] : [{ front: "No cards yet", back: "–", ref: "" }]; StudyBench.flashcards(h, d, "rb-deck-" + k); document.getElementById("deckCount").textContent = decks[k].length + " cards"; }
    StudyBench.segmented(document.getElementById("deckSeg"), function (_v, b) { draw(b.value); });
    draw("concepts");
  }

  function differences() {
    var host = document.getElementById("ref-differences"), C = RB.CONFLICTS || [], L = RB.ledger || [];
    var rows = C.map(function (c) { return { kind: c.kind || "Sources disagree", where: c.where, a: c.a, b: c.b, why: c.why, href: c.href }; }).concat(L.map(function (r) { return { kind: r.kind || "Our choice", where: r.where || (r.topic ? "Topic " + RB.topics[r.topic].num : "Lab: " + r.station), a: r.source || "", b: r.page || "", why: r.why || "", href: r.href || (r.topic ? "#explorer/" + r.topic : "#lab/" + r.station) }; }));
    var kinds = []; rows.forEach(function (r) { if (kinds.indexOf(r.kind) < 0) kinds.push(r.kind); });
    host.innerHTML = '<section class="sb-sec" id="ref-d-sec">' + RB.secHead({ level: "h2", title: "Where the papers disagree", lede: "Every place two sources disagree, and every place this site simplifies or chooses. Each row links to where it appears." }) +
      '<div class="sb-chips" data-filter-for="diffTable" role="group" aria-label="Filter by kind">' + kinds.map(function (k) { return '<button type="button" class="sb-tag" data-key="kind" data-val="' + esc(k) + '" aria-pressed="false">' + esc(k) + "</button>"; }).join("") + '</div><div class="sb-toolbar"><input class="sb-input" type="search" data-search-for="diffTable" placeholder="Search" aria-label="Search disagreements"><span class="sb-count" data-count-for="diffTable"></span><button class="sb-btn sb-btn--ghost" type="button" data-clear-for="diffTable" hidden>Clear filters</button></div>' +
      '<div class="sb-scroll-x"><table class="sb-table" id="diffTable"><thead><tr><th scope="col">Where</th><th scope="col">One source says</th><th scope="col">The other says / this site does</th><th scope="col">Why it matters</th></tr></thead><tbody>' +
      rows.map(function (r) { return '<tr data-kind="' + esc(r.kind) + '"><td>' + (r.href ? '<a href="' + esc(r.href) + '">' + esc(r.where) + "</a>" : esc(r.where)) + "</td><td>" + r.a + "</td><td>" + r.b + '</td><td><span class="sb-prov' + (/disagree|differs|conflict/i.test(r.kind) ? " sb-prov--differs" : "") + '">' + esc(r.kind) + "</span> " + r.why + "</td></tr>"; }).join("") + "</tbody></table></div></section>";
    StudyBench.table(document.getElementById("diffTable"));
  }

  function datasets() {
    var host = document.getElementById("ref-datasets"), D = RB.DATASETS || [];
    if (!D.length) { host.innerHTML = '<div class="sb-empty"><p>The dataset atlas is being compiled.</p></div>'; return; }
    var layers = ["Real robot", "UMI-style", "Human video", "Simulation", "General", "Grasp"];
    var cols = { "Real robot": "data-1", "UMI-style": "data-2", "Human video": "data-3", "Simulation": "data-4", "General": "data-5", "Grasp": "data-6" };
    host.innerHTML = '<section class="sb-sec" id="ref-ds-sec">' + RB.secHead({ level: "h2", title: "Dataset atlas", lede: "Datasets named in the surveys, by year and size, colored by layer of the data pyramid. Size units differ by layer; the chart plots each layer's own unit." }) +
      '<div class="sb-toolbar">' + RB.seg({ id: "dsLayer", label: "Layer", value: "all", options: [{ value: "all", label: "All" }].concat(layers.map(function (l) { return { value: l, label: l.split(" ")[0] }; })) }) + '<span class="sb-count" id="dsCount"></span></div><div class="sb-panel"><div class="sb-panel-body"><div id="dsChart"></div><div class="sb-scroll-x"><table class="sb-table sb-table--compact" id="dsTable"><thead><tr><th scope="col" data-sort="text">Dataset</th><th scope="col" data-sort="num">Year</th><th scope="col" data-sort="text">Layer</th><th scope="col" data-sort="num">Size</th><th scope="col">Unit</th><th scope="col">Notes</th><th scope="col">Source</th></tr></thead><tbody></tbody></table></div></div></div></section>';
    function draw(layer) {
      var list = D.filter(function (d) { return layer === "all" || d.layer === layer; });
      var W = 760, H = 320, M = { l: 56, r: 16, t: 12, b: 40 }, iw = W - M.l - M.r, ih = H - M.t - M.b, y0 = 2010, y1 = 2027;
      var vals = list.filter(function (d) { return d.size > 0; }).map(function (d) { return Math.log10(d.size); }), lo = Math.floor(Math.min.apply(null, vals.concat([2]))), hi = Math.ceil(Math.max.apply(null, vals.concat([6])));
      var sx = function (y) { return M.l + (y - y0) / (y1 - y0) * iw; }, sy = function (v) { return M.t + ih - (v - lo) / (hi - lo) * ih; };
      var s = '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Datasets by year and size">';
      for (var v = lo; v <= hi; v++) s += '<line class="sb-grid-line" x1="' + M.l + '" x2="' + (M.l + iw) + '" y1="' + sy(v) + '" y2="' + sy(v) + '"/><text class="sb-tick" x="' + (M.l - 8) + '" y="' + (sy(v) + 4) + '" text-anchor="end">' + (["1", "10", "100", "1K", "10K", "100K", "1M", "10M", "100M", "1B", "10B", "100B", "1T"][v] || "1e" + v) + "</text>";
      for (var y = 2012; y <= 2026; y += 2) s += '<text class="sb-tick" x="' + sx(y) + '" y="' + (M.t + ih + 18) + '" text-anchor="middle">' + y + "</text>";
      list.forEach(function (d, i) { if (!(d.size > 0) || !d.year) return; var jx = ((i * 37) % 11 - 5) * 2; s += '<g class="rb-ds-dot" tabindex="0"><circle cx="' + (sx(d.year) + jx) + '" cy="' + sy(Math.log10(d.size)) + '" r="5" style="fill:var(--' + cols[d.layer] + ')"/><title>' + esc(d.name + " · " + d.year + " · " + d.sizeText) + "</title></g>"; });
      s += '<text class="sb-axis-label" x="' + (M.l + iw / 2) + '" y="' + (H - 4) + '" text-anchor="middle">Year</text></svg>';
      document.getElementById("dsChart").innerHTML = '<figure class="sb-fig"><div class="sb-scroll-x">' + s + "</div>" + RB.legend(layers.map(function (l) { return { c: cols[l], label: l, kind: "dot" }; })) + '<figcaption class="sb-caption">Log scale. Units: episodes or trajectories for robot and simulation data, hours for human video, samples for general data, grasps for grasp data. Hover a dot for its name.</figcaption></figure>';
      var tb = document.querySelector("#dsTable tbody"); tb.innerHTML = list.map(function (d) { return "<tr><td>" + esc(d.name) + '</td><td data-v="' + (d.year || 0) + '">' + (d.year || "–") + "</td><td>" + esc(d.layer) + '</td><td data-v="' + (d.size || 0) + '">' + esc(d.sizeText || "–") + "</td><td>" + esc(d.unit || "") + "</td><td>" + esc(d.notes || "") + '</td><td><span class="sb-ref">' + esc(d.source || "") + "</span></td></tr>"; }).join("");
      document.getElementById("dsCount").textContent = list.length + " datasets";
    }
    StudyBench.segmented(document.getElementById("dsLayer"), function (_v, b) { draw(b.value); });
    draw("all"); StudyBench.table(document.getElementById("dsTable"));
  }

  function papers() {
    var host = document.getElementById("ref-papers");
    host.innerHTML = '<section class="sb-sec" id="ref-p-sec">' + RB.secHead({ level: "h2", title: "Paper shelf", lede: "The seventeen papers in the project, what each contributes, and the topics that use it. P12 is not used." }) + '<div class="rb-shelf">' + RB.PAPERS.map(function (p) {
      var n = (RB.METHODS || []).filter(function (m) { return (m.citedBy || "").indexOf(p.id) >= 0; }).length;
      return '<article class="rb-paper" id="paper-' + p.id + '"><p class="sb-eyebrow">' + p.id + " · " + esc(p.date) + (p.unused ? " · not used" : "") + '</p><p class="rb-paper-t">' + esc(p.title) + '</p><p class="sb-caption">' + esc(p.authors) + " · " + esc(p.orgs) + "</p><p>" + esc(p.role) + '</p><div class="sb-chips">' + p.topics.map(function (k) { return '<a class="sb-tag" href="#explorer/' + k + '">' + RB.topics[k].num + " " + esc(RB.topics[k].short) + "</a>"; }).join("") + (n ? '<span class="sb-ref">' + n + " cited methods read</span>" : "") + '</div><a class="sb-link" href="https://arxiv.org/abs/' + p.arxiv + '" target="_blank" rel="noopener">arXiv ' + p.arxiv + " ↗</a></article>";
    }).join("") + "</div></section>";
  }

  RB.pages.reference = {
    init: function () { formulas(); cards(); differences(); datasets(); papers(); RB.linkTerms(document.getElementById("ref-differences")); },
    show: function (o) { if (o.tab === "papers" && o.rest[0]) { var e = document.getElementById("paper-" + o.rest[0]); if (e) { e.scrollIntoView({ block: "center" }); StudyBench.flash && StudyBench.flash(e); } } }
  };
  RB.howto["ref-formulas"] = function () { RB.go("#reference/formulas"); };
  RB.howto["ref-cards"] = function () { RB.go("#reference/cards"); };
  RB.howto["ref-diff"] = function () { RB.go("#reference/differences"); };
})();
