/* Model architecture diagrams: one spec per model, one renderer, three zoom levels.
   System view (OpenWAM grammar: role-coloured modules, input tokens below, outputs above, coupling on the links, visibility mask),
   Layer view (Raschka grammar: embedding → block ×N → head, every sub-layer typed and sized),
   Diff view (aligned summary rows with changed values marked). Specs live in data/arch/*.js. */
(function () {
  var RB = window.RB, esc = RB.esc;
  var ARCH = {}, ORDER = [];

  var ROLE = {
    "vision-enc": { c: "data-1", t: "Vision encoder" }, vlm: { c: "data-2", t: "VLM backbone" }, lang: { c: "data-2", t: "Language encoder" },
    "action-head": { c: "data-3", t: "Action head" }, "action-expert": { c: "data-3", t: "Action expert" },
    "video-gen": { c: "data-4", t: "Video predictor" }, world: { c: "data-4", t: "World model" }, joint: { c: "data-4", c2: "data-3", t: "Joint video + action" },
    "state-enc": { c: "data-5", t: "State encoder" }, "touch-enc": { c: "data-6", t: "Touch / force encoder" }, fusion: { c: "data-6", t: "Fusion" },
    latent: { c: "data-7", t: "Latent / codebook" }, codec: { c: "data-8", t: "Tokenizer / VAE" }, critic: { c: "data-8", t: "Critic / verifier" },
    planner: { c: "data-2", t: "Planner" }, net: { c: "data-8", t: "Network" }
  };
  var MOD = {
    vision: { c: "data-1", t: "Image / video" }, lang: { c: "data-2", t: "Language" }, action: { c: "data-3", t: "Action" },
    future: { c: "data-4", t: "Future observation" }, state: { c: "data-5", t: "State / proprio" }, touch: { c: "data-6", t: "Touch / force" },
    latent: { c: "data-7", t: "Latent" }, time: { c: "data-8", t: "Noise level / step" }, other: { c: "data-8", t: "Other" }
  };
  var LINK = {
    prefix: { t: "Tokens join the sequence" }, "joint-attn": { t: "Joint self-attention: one sequence, separate weights", two: true },
    "cross-attn": { t: "Cross-attention to the other module" }, film: { t: "FiLM: per-channel scale and shift" }, adaln: { t: "AdaLN: norm scale, shift and gate" },
    latent: { t: "Latent hand-off", dash: true }, "two-stage": { t: "Two stages: the first runs to completion", dash: true }, feeds: { t: "Output feeds the next module" }
  };
  RB.ARCH_ROLE = ROLE; RB.ARCH_MOD = MOD; RB.ARCH_LINK = LINK;

  /* ---------- registry ---------- */
  function spec(s) {
    if (!s || !s.id) { RB.warn("arch spec without id"); return; }
    if (ARCH[s.id]) RB.warn("arch spec registered twice: " + s.id);
    if (s.method && !(RB.M && RB.M[s.method])) RB.warn("arch " + s.id + ": unknown method " + s.method);
    var ids = {};
    (s.modules || []).forEach(function (m) { ids[m.id] = 1; if (!ROLE[m.role]) RB.warn("arch " + s.id + ": unknown role " + m.role); });
    (s.links || []).forEach(function (l) { if (!ids[l.from] || !ids[l.to]) RB.warn("arch " + s.id + ": link to missing module " + l.from + "→" + l.to); if (!LINK[l.kind]) RB.warn("arch " + s.id + ": unknown link kind " + l.kind); });
    (s.inputs || []).concat(s.outputs || []).forEach(function (t) { if (!MOD[t.mod]) RB.warn("arch " + s.id + ": unknown modality " + t.mod); if (!ids[t.to || t.from]) RB.warn("arch " + s.id + ": token without module " + t.label); });
    /* integrity lint: every number on the page must carry a source */
    var hasNum = function (v) { return /\d/.test(String(v).replace(/[₀-₉ₐ-ₜ]/g, "")); };
    Object.keys(s.summary || {}).forEach(function (k) { var v = s.summary[k]; if (v != null && !Array.isArray(v) && hasNum(v)) RB.warn("arch " + s.id + ": unsourced number in summary." + k); if (Array.isArray(v)) v.slice(1).forEach(function (x) { if (!s.sources || !s.sources[x]) RB.warn("arch " + s.id + ": unknown source " + x); }); });
    (function walk(rows, where) { (rows || []).forEach(function (r) { if (r.rows) walk(r.rows, where); if (r.call != null) { if (!Array.isArray(r.call) && hasNum(r.call)) RB.warn("arch " + s.id + ": unsourced callout in " + where + ": " + r.call); if (Array.isArray(r.call)) r.call.slice(1).forEach(function (x) { if (!s.sources || !s.sources[x]) RB.warn("arch " + s.id + ": unknown source " + x); }); } }); })((s.blueprint && s.blueprint.towers || []).reduce(function (a, t) { if (!ids[t.mod]) RB.warn("arch " + s.id + ": blueprint tower for missing module " + t.mod); return a.concat(t.rows || []); }, []), "blueprint");
    if (s.parent && s.parent === s.id) RB.warn("arch " + s.id + ": parent is itself");
    ARCH[s.id] = s; ORDER.push(s.id);
  }
  function topicOf(s) { if (s.topic) return s.topic; var m = RB.M && RB.M[s.method]; return m ? String(m.topic || "").toLowerCase() : ""; }
  function forTopic(tid) {
    return ORDER.map(function (k) { return ARCH[k]; }).filter(function (s) { return topicOf(s) === tid || (s.alsoIn || []).indexOf(tid) >= 0; })
      .sort(function (a, b) { return (a.year || 0) - (b.year || 0) || a.name.localeCompare(b.name); });
  }
  var ALIAS = {}, NONE = {};
  function forMethod(mid) { var d = ORDER.map(function (k) { return ARCH[k]; }).filter(function (s) { return s.method === mid; })[0]; if (d) return d; if (ALIAS[mid] && ARCH[ALIAS[mid].spec]) return ARCH[ALIAS[mid].spec]; return null; }
  function alias(mid, specId, note) { ALIAS[mid] = { spec: specId, note: note || "" }; }
  function aliasNote(mid) { var d = ORDER.some(function (k) { return ARCH[k].method === mid; }); return !d && ALIAS[mid] ? ALIAS[mid].note : ""; }
  function none(mid, reason) { if (reason === undefined) return NONE[mid] || ""; NONE[mid] = reason; }

  /* ---------- values with sources ---------- */
  function vtext(v) { return Array.isArray(v) ? String(v[0]) : v == null ? "" : String(v); }
  function src(s, key) {
    var x = s.sources && s.sources[key]; if (!x) { RB.warn("arch " + s.id + ": unknown source " + key); return ""; }
    var lab = x.kind === "code" ? "code" : x.kind === "paper" ? "paper" : "note";
    var tip = x.kind === "code" ? x.repo + " · " + x.path + (x.commit ? " @" + x.commit : "") : (x.ref || "");
    return x.url ? '<a class="rb-src rb-src--' + x.kind + '" href="' + esc(x.url) + '" target="_blank" rel="noopener" title="' + esc(tip) + '">' + lab + "</a>"
      : '<span class="rb-src rb-src--' + x.kind + '" title="' + esc(tip) + '">' + lab + "</span>";
  }
  function vhtml(s, v) {
    if (v == null || v === "") return '<span class="rb-arch-na">not stated</span>';
    if (!Array.isArray(v)) return esc(String(v));
    return esc(String(v[0])) + v.slice(1).map(function (k) { return " " + src(s, k); }).join("");
  }

  /* ---------- system view ---------- */
  var MW = 204, GAP = 116, PADX = 20, OUTH = 70, MODH = 100, INH = 84;
  function wrapWords(t, n) { var w = String(t).split(" "), out = [], cur = ""; w.forEach(function (x) { if ((cur + " " + x).trim().length > n && cur) { out.push(cur); cur = x; } else cur = (cur + " " + x).trim(); }); if (cur) out.push(cur); return out; }
  function tokenGroup(t, cx, y, up, chars) {
    var mod = MOD[t.mod] || MOD.other, k = Math.max(1, Math.min(t.k || 4, 6)), sz = 11, g = 3, w = k * sz + (k - 1) * g, x0 = cx - w / 2, s = "";
    for (var i = 0; i < k; i++) s += '<rect class="rb-ak' + (t.noisy ? " is-noisy" : "") + '" style="--c:var(--' + mod.c + ')" x="' + (x0 + i * (sz + g)) + '" y="' + y + '" width="' + sz + '" height="' + sz + '" rx="2.5"/>';
    var lines = wrapWords(t.label, chars || 20).slice(0, 2), ly = up ? y - 8 - (lines.length - 1) * 13 : y + sz + 15;
    lines.forEach(function (l, j) { s += '<text class="rb-at-lab" x="' + cx + '" y="' + (ly + j * 13) + '" text-anchor="middle">' + esc(l) + "</text>"; });
    if (t.n) wrapWords(t.n, chars || 20).slice(0, 2).forEach(function (l, j, arr) { s += '<text class="rb-at-n" x="' + cx + '" y="' + (up ? ly - 14 - (arr.length - 1 - j) * 12 : ly + lines.length * 13 + j * 12) + '" text-anchor="middle">' + esc(l) + "</text>"; });
    return "<g><title>" + esc(mod.t + ": " + t.label + (t.n ? " (" + t.n + ")" : "") + (t.note ? ". " + t.note : "")) + "</title>" + s + "</g>";
  }
  function system(s, o) {
    o = o || {};
    var ms = s.modules || [], cols = 0; ms.forEach(function (m, i) { if (m.col == null) m.col = i; cols = Math.max(cols, m.col + 1); });
    var W = PADX * 2 + cols * MW + (cols - 1) * GAP, H = 12 + OUTH + MODH + INH, my = 12 + OUTH, uid = "ar" + s.id.replace(/\W/g, "") + (o.uid || "");
    var X = function (m) { return PADX + m.col * (MW + GAP); };
    var out = '<svg class="rb-arch-svg" viewBox="0 0 ' + W + " " + H + '" width="' + W + '" height="' + H + '" role="img" aria-labelledby="' + uid + 't"><title id="' + uid + 't">' + esc(s.name + " architecture: " + ms.map(function (m) { return m.name; }).join(", ")) + "</title>";
    out += '<defs><marker id="' + uid + 'a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path class="rb-arch-head" d="M0 0L10 5L0 10z"/></marker></defs>';
    /* links */
    var pairCount = {};
    (s.links || []).forEach(function (l) {
      var a = ms.filter(function (m) { return m.id === l.from; })[0], b = ms.filter(function (m) { return m.id === l.to; })[0]; if (!a || !b) return;
      var key = Math.min(a.col, b.col) + "-" + Math.max(a.col, b.col), n = pairCount[key] = (pairCount[key] || 0) + 1;
      var L = a.col < b.col ? a : b, R = a.col < b.col ? b : a, x1 = X(L) + MW, x2 = X(R), y = my + MODH / 2 + (n - 1) * 26 - 6;
      var K = LINK[l.kind] || {}, fwd = a.col < b.col;
      out += '<g class="rb-arch-link' + (K.dash ? " is-dash" : "") + '"><title>' + esc(K.t + (l.note ? ". " + l.note : "")) + "</title>";
      out += '<line x1="' + (x1 + 3) + '" y1="' + y + '" x2="' + (x2 - 3) + '" y2="' + y + '"' + (K.two || !fwd ? ' marker-start="url(#' + uid + 'a)"' : "") + (K.two || fwd ? ' marker-end="url(#' + uid + 'a)"' : "") + "/>";
      var lab = (l.label || "").split("|"), cx = (x1 + x2) / 2;
      lab.forEach(function (t, j) { out += '<text class="rb-arch-lt" x="' + cx + '" y="' + (y - 8 - (lab.length - 1 - j) * 12) + '" text-anchor="middle">' + esc(t) + "</text>"; });
      if (l.kind !== "feeds" && l.kind !== "prefix") out += '<text class="rb-arch-lk" x="' + cx + '" y="' + (y + 15) + '" text-anchor="middle">' + esc(({ "joint-attn": "joint attn", "cross-attn": "cross-attn", film: "FiLM", adaln: "AdaLN", latent: "latent", "two-stage": "2-stage" })[l.kind] || "") + "</text>";
      out += "</g>";
    });
    /* modules */
    ms.forEach(function (m) {
      var R = ROLE[m.role] || ROLE.net, x = X(m), y = my;
      out += '<g class="rb-am' + (m.stack ? " has-stack" : "") + '" data-mod="' + m.id + '" style="--c:var(--' + R.c + ')"' + (m.stack ? ' tabindex="0" role="button" aria-label="' + esc("Show the layers of " + m.name) + '"' : "") + ">";
      out += '<rect class="rb-am-box" x="' + x + '" y="' + y + '" width="' + MW + '" height="' + MODH + '" rx="10"/>';
      if (R.c2) out += '<rect class="rb-am-stripe" style="--c2:var(--' + R.c2 + ')" x="' + (x + MW / 2) + '" y="' + (y + 1) + '" width="' + (MW / 2 - 10) + '" height="4"/><rect class="rb-am-stripe1" x="' + (x + 10) + '" y="' + (y + 1) + '" width="' + (MW / 2 - 10) + '" height="4"/>';
      out += '<text class="rb-am-role" x="' + (x + 12) + '" y="' + (y + 20) + '">' + esc((m.roleLabel || R.t).toUpperCase()) + "</text>";
      wrapWords(m.name, 18).slice(0, 2).forEach(function (l, j) { out += '<text class="rb-am-name" x="' + (x + 12) + '" y="' + (y + 40 + j * 16) + '">' + esc(l) + "</text>"; });
      if (m.sub) out += '<text class="rb-am-sub" x="' + (x + 12) + '" y="' + (y + 76) + '">' + esc(m.sub) + "</text>";
      var tag = m.frozen === true ? "frozen" : m.frozen === "lora" ? "LoRA" : m.frozen === "partial" ? "partly frozen" : "trained";
      out += '<text class="rb-am-tag' + (m.frozen === true ? " is-frozen" : "") + '" x="' + (x + 12) + '" y="' + (y + 92) + '">' + tag + (m.params ? " · " + esc(m.params) : "") + "</text>";
      if (m.stack) out += '<text class="rb-am-more" x="' + (x + MW - 10) + '" y="' + (y + 92) + '" text-anchor="end">layers ›</text>';
      out += "<title>" + esc(R.t + ": " + m.name + (m.note ? ". " + m.note : "") + (m.stack ? ". Select to see its layers." : "")) + "</title></g>";
      /* tokens */
      var ins = (s.inputs || []).filter(function (t) { return t.to === m.id; }), outs = (s.outputs || []).filter(function (t) { return t.from === m.id; });
      var spIn = MW + (ins.length > 1 ? 44 : 0), spOut = MW + (outs.length > 1 ? 44 : 0);
      ins.forEach(function (t, i) { var cx = x - (spIn - MW) / 2 + spIn * (i + 1) / (ins.length + 1), ty = my + MODH + 30; out += '<line class="rb-arch-tl" x1="' + cx + '" y1="' + (ty - 4) + '" x2="' + cx + '" y2="' + (my + MODH + 3) + '" marker-end="url(#' + uid + 'a)"/>' + tokenGroup(t, cx, ty, false, Math.floor(spIn / ins.length / 7.2)); });
      outs.forEach(function (t, i) { var cx = x - (spOut - MW) / 2 + spOut * (i + 1) / (outs.length + 1), ty = my - 34; out += '<line class="rb-arch-tl" x1="' + cx + '" y1="' + (my - 3) + '" x2="' + cx + '" y2="' + (ty + 15) + '" marker-end="url(#' + uid + 'a)"/>' + tokenGroup(t, cx, ty, true, Math.floor(spOut / outs.length / 7.2)); });
    });
    return out + "</svg>";
  }

  /* phone layout: modules stacked top to bottom in column order */
  function systemV(s, o) {
    o = o || {};
    var ms = (s.modules || []).slice().sort(function (a, b) { return a.col - b.col; }), W = 360, BW = 300, BX = 30, uid = "av" + s.id.replace(/\W/g, "") + (o.uid || ""), y = 8, body = "";
    function tokRow(list, isOut) {
      if (!list.length) return;
      var ch = Math.floor(BW / list.length / 7.6);
      list.forEach(function (t, i) {
        var cx = BX + BW * (i + 1) / (list.length + 1);
        if (isOut) body += '<line class="rb-arch-tl" x1="' + cx + '" y1="' + (y + 1) + '" x2="' + cx + '" y2="' + (y + 14) + '" marker-end="url(#' + uid + 'a)"/>' + tokenGroup(t, cx, y + 18, false, ch);
        else body += tokenGroup(t, cx, y, false, ch) + '<line class="rb-arch-tl" x1="' + cx + '" y1="' + (y + 52) + '" x2="' + cx + '" y2="' + (y + 68) + '" marker-end="url(#' + uid + 'a)"/>';
      });
      y += isOut ? 70 : 72;
    }
    ms.forEach(function (m, k) {
      var R = ROLE[m.role] || ROLE.net;
      var ins = (s.inputs || []).filter(function (t) { return t.to === m.id; }), outs = (s.outputs || []).filter(function (t) { return t.from === m.id; });
      if (ins.length) tokRow(ins, false);
      body += '<g class="rb-am' + (m.stack ? " has-stack" : "") + '" data-mod="' + m.id + '" style="--c:var(--' + R.c + ')"' + (m.stack ? ' tabindex="0" role="button" aria-label="' + esc("Show the layers of " + m.name) + '"' : "") + '><rect class="rb-am-box" x="' + BX + '" y="' + y + '" width="' + BW + '" height="84" rx="10"/>' +
        '<text class="rb-am-role" x="' + (BX + 12) + '" y="' + (y + 19) + '">' + esc((m.roleLabel || R.t).toUpperCase()) + '</text><text class="rb-am-name" x="' + (BX + 12) + '" y="' + (y + 39) + '">' + esc(m.name) + "</text>" +
        (m.sub ? '<text class="rb-am-sub" x="' + (BX + 12) + '" y="' + (y + 58) + '">' + esc(m.sub) + "</text>" : "") +
        '<text class="rb-am-tag' + (m.frozen === true ? " is-frozen" : "") + '" x="' + (BX + 12) + '" y="' + (y + 75) + '">' + (m.frozen === true ? "frozen" : m.frozen === "lora" ? "LoRA" : "trained") + (m.params ? " · " + esc(m.params) : "") + "</text>" +
        (m.stack ? '<text class="rb-am-more" x="' + (BX + BW - 10) + '" y="' + (y + 75) + '" text-anchor="end">layers ›</text>' : "") + "</g>";
      y += 84;
      if (outs.length) tokRow(outs, true);
      var nx = ms[k + 1];
      if (nx) {
        var l = (s.links || []).filter(function (x) { return (x.from === m.id && x.to === nx.id) || (x.to === m.id && x.from === nx.id); })[0];
        if (l) {
          var K = LINK[l.kind] || {}, down = l.from === m.id, cx = BX + 60;
          body += '<g class="rb-arch-link' + (K.dash ? " is-dash" : "") + '"><line x1="' + cx + '" y1="' + (y + 4) + '" x2="' + cx + '" y2="' + (y + 52) + '"' + (K.two || !down ? ' marker-start="url(#' + uid + 'a)"' : "") + (K.two || down ? ' marker-end="url(#' + uid + 'a)"' : "") + "/>" +
            '<text class="rb-arch-lt" x="' + (cx + 14) + '" y="' + (y + 26) + '">' + esc((l.label || "").replace(/\|/g, " · ")) + "</text>" + (l.kind !== "feeds" && l.kind !== "prefix" ? '<text class="rb-arch-lk" x="' + (cx + 14) + '" y="' + (y + 42) + '">' + esc(({ "joint-attn": "joint attn", "cross-attn": "cross-attn", film: "FiLM", adaln: "AdaLN", latent: "latent", "two-stage": "2-stage" })[l.kind] || "") + "</text>" : "") + "</g>";
          y += 56;
        } else y += 16;
      }
    });
    y += 8;
    return '<svg class="rb-arch-svg is-v" viewBox="0 0 ' + W + " " + y + '" width="' + W + '" height="' + y + '" role="img" aria-label="' + esc(s.name + " architecture") + '"><defs><marker id="' + uid + 'a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path class="rb-arch-head" d="M0 0L10 5L0 10z"/></marker></defs>' + body + "</svg>";
  }
  function narrow() { try { return window.matchMedia("(max-width: 600px)").matches; } catch (e) { return false; } }
  function systemAuto(s, o) { return narrow() ? systemV(s, o) : system(s, o); }

  function legend(s) {
    var mods = {}, roles = {}, links = {};
    (s.inputs || []).concat(s.outputs || []).forEach(function (t) { mods[t.mod] = 1; });
    (s.links || []).forEach(function (l) { links[l.kind] = 1; });
    var noisy = (s.inputs || []).some(function (t) { return t.noisy; });
    return '<ul class="sb-legend rb-arch-legend">' + Object.keys(mods).map(function (k) { return '<li class="sb-key"><span class="sb-sw" style="--c: var(--' + MOD[k].c + ')"></span>' + MOD[k].t + "</li>"; }).join("") +
      (noisy ? '<li class="sb-key"><span class="rb-sw-noisy"></span>Noisy (being denoised)</li>' : "") +
      Object.keys(links).filter(function (k) { return LINK[k]; }).map(function (k) { return '<li class="sb-key"><span class="rb-sw-link' + (LINK[k].dash ? " is-dash" : "") + (LINK[k].two ? " is-two" : "") + '"></span>' + LINK[k].t + "</li>"; }).join("") + "</ul>";
  }

  /* ---------- attention visibility mask ---------- */
  function mask(s) {
    var M = s.mask; if (!M) return "";
    var n = M.axes.length, c = 26, lw = 112, W = lw + n * c + 4, H = 26 + n * c + 4, out = '<svg class="rb-mask-svg" viewBox="0 0 ' + W + " " + H + '" width="' + W + '" height="' + H + '" role="img" aria-label="' + esc("Attention mask: " + (M.name || "")) + '">';
    M.axes.forEach(function (a, j) {
      var mod = MOD[a.mod] || MOD.other;
      out += '<text class="rb-mask-ax" x="' + (lw + j * c + c / 2) + '" y="16" text-anchor="middle" style="--c:var(--' + mod.c + ')">' + esc(a.short || a.label) + "</text>";
      out += '<text class="rb-mask-ay" x="' + (lw - 8) + '" y="' + (26 + j * c + c / 2 + 4) + '" text-anchor="end" style="--c:var(--' + mod.c + ')">' + esc(a.label) + "</text>";
    });
    M.m.forEach(function (row, i) { String(row).split("").forEach(function (v, j) { out += '<rect class="rb-mask-c' + (v === "1" ? " is-on" : "") + '" x="' + (lw + j * c + 1) + '" y="' + (26 + i * c + 1) + '" width="' + (c - 2) + '" height="' + (c - 2) + '" rx="3"><title>' + esc(M.axes[i].label + (v === "1" ? " attends to " : " cannot see ") + M.axes[j].label) + "</title></rect>"; }); });
    return '<figure class="rb-mask"><figcaption><b>' + esc(M.name || "Attention mask") + "</b> Row attends to column." + (M.note ? " " + esc(M.note) : "") + (M.ref ? " " + src(s, M.ref) : "") + "</figcaption>" + out + "</svg></figure>";
  }

  /* ---------- layer view ---------- */
  var ROWH = { norm: 22, add: 22, in: 26, out: 26 };
  function rowsHeight(rows) { var h = 0; rows.forEach(function (r) { h += r.t === "block" || r.t === "group" ? 34 + rowsHeight(r.rows) + 10 + 8 : (ROWH[r.t] || 30) + 8; }); return h; }
  function layers(s, m) {
    var st = m.stack; if (!st) return "";
    var R = ROLE[m.role] || ROLE.net, BX = 96, BW = 300, DX = BX + BW + 22, W = 740;
    var rows = st.rows.slice().reverse(), H = rowsHeight(rows) + 16, y = 8, out = "";
    function draw(list, depth) {
      list.forEach(function (r) {
        if (r.t === "block" || r.t === "group") {
          var inner = rowsHeight(r.rows.slice().reverse()), top = y, fx = BX - 16 - depth * 10, fw = BW + 32 + depth * 20;
          out += '<rect class="rb-ls-frame' + (r.t === "group" ? " is-group" : "") + '" x="' + fx + '" y="' + top + '" width="' + fw + '" height="' + (34 + inner + 10) + '" rx="10"/>';
          out += '<text class="rb-ls-ftitle" x="' + (fx + 12) + '" y="' + (top + 20) + '">' + esc(r.label) + "</text>";
          if (r.n) out += '<g class="rb-ls-n"><rect x="' + (fx - 58) + '" y="' + (top + 6) + '" width="50" height="24" rx="12"/><text x="' + (fx - 33) + '" y="' + (top + 22) + '" text-anchor="middle">× ' + esc(r.n) + "</text></g>";
          if (r.note) out += '<text class="rb-ls-dim" x="' + (fx + fw + 10) + '" y="' + (top + 20) + '">' + esc(r.note) + "</text>";
          y += 34; draw(r.rows.slice().reverse(), depth + 1); y += 10 + 8; return;
        }
        var h = ROWH[r.t] || 30, cls = "rb-ls-row rb-ls-" + r.t;
        if (r.t === "add") {
          out += '<g class="' + cls + '"><circle cx="' + (BX + BW / 2) + '" cy="' + (y + h / 2) + '" r="9"/><text x="' + (BX + BW / 2) + '" y="' + (y + h / 2 + 4) + '" text-anchor="middle">+</text>';
          if (r.span) { var back = r.span * 38; out += '<path class="rb-ls-res" d="M' + (BX + BW) + " " + (y + h / 2 + back) + " H" + (BX + BW + 9) + " V" + (y + h / 2) + " H" + (BX + BW / 2 + 10) + '"/>'; }
          out += (r.label ? '<text class="rb-ls-dim" x="' + DX + '" y="' + (y + h / 2 + 4) + '">' + esc(r.label) + "</text>" : "") + "</g>";
        } else {
          out += '<g class="' + cls + '" style="--c:var(--' + (r.c || R.c) + ')"><rect x="' + BX + '" y="' + y + '" width="' + BW + '" height="' + h + '" rx="' + (r.t === "in" || r.t === "out" ? 13 : 6) + '"/><text class="rb-ls-t" x="' + (BX + BW / 2) + '" y="' + (y + h / 2 + 4) + '" text-anchor="middle">' + esc(r.label) + "</text>";
          if (r.dims) out += '<text class="rb-ls-dim" x="' + DX + '" y="' + (y + h / 2 + 4) + '">' + esc(r.dims) + "</text>";
          if (r.side) out += '<g class="rb-ls-side"><line x1="' + (BX - 40) + '" y1="' + (y + h / 2) + '" x2="' + (BX - 4) + '" y2="' + (y + h / 2) + '"/><text x="' + (BX - 44) + '" y="' + (y + h / 2 + 4) + '" text-anchor="end">' + esc(r.side) + "</text></g>";
          out += (r.note ? "<title>" + esc(r.note) + "</title>" : "") + "</g>";
        }
        y += h + 8;
      });
    }
    draw(rows, 0);
    var svg = '<svg class="rb-ls-svg" viewBox="0 0 ' + W + " " + H + '" width="' + W + '" height="' + H + '" role="img" aria-label="' + esc("Layer stack of " + m.name + ", input at the bottom") + '">' + out + "</svg>";
    var facts = (st.facts || []).map(function (f) { return "<tr><th scope=\"row\">" + esc(f[0]) + "</th><td>" + vhtml(s, f[1]) + "</td></tr>"; }).join("");
    return '<div class="rb-ls"><div class="sb-scroll-x rb-ls-scroll">' + svg + "</div>" + (facts ? '<table class="sb-table sb-table--compact rb-ls-facts"><caption>' + esc(m.name) + ' in numbers</caption><tbody>' + facts + "</tbody></table>" : "") + "</div>";
  }

  /* ---------- summary table and diff ---------- */
  var KEYS = [["pattern", "Pattern"], ["params", "Parameters"], ["vision", "Vision input"], ["backbone", "Backbone"], ["head", "Action head"], ["output", "Output"], ["attention", "Attention and mask"], ["cond", "Conditioning"], ["steps", "Inference steps"], ["chunk", "Action chunk"], ["rate", "Control rate"], ["latency", "Latency"], ["train", "Training data"]];
  function norm(v) { return vtext(v).toLowerCase().replace(/\s+/g, " ").trim(); }
  function summary(list) {
    var many = list.length > 1;
    var head = many ? '<thead><tr><th scope="col"></th>' + list.map(function (s) { return '<th scope="col">' + esc(s.name) + "</th>"; }).join("") + "</tr></thead>" : "";
    var marked = null; list.forEach(function (s) { if (s.diffRows && list.some(function (p) { return p.id === s.parent; })) marked = (marked || []).concat(s.diffRows); });
    var body = KEYS.filter(function (k) { return list.some(function (s) { return s.summary && s.summary[k[0]] != null; }); }).map(function (k) {
      var vals = list.map(function (s) { return s.summary ? s.summary[k[0]] : null; }), diff = many && (marked ? marked.indexOf(k[0]) >= 0 : vals.some(function (v) { return norm(v) !== norm(vals[0]); }));
      return '<tr' + (diff ? ' class="is-diff"' : "") + '><th scope="row">' + k[1] + (diff ? ' <span class="rb-diff-dot" aria-label="differs"></span>' : "") + "</th>" + list.map(function (s, i) { return "<td>" + vhtml(s, vals[i]) + "</td>"; }).join("") + "</tr>";
    }).join("");
    return '<div class="sb-scroll-x"><table class="sb-table sb-table--compact rb-arch-sum">' + head + "<tbody>" + body + "</tbody></table></div>";
  }
  function sources(s) {
    return '<ul class="rb-arch-srcs">' + Object.keys(s.sources || {}).map(function (k) {
      var x = s.sources[k];
      return "<li>" + src(s, k) + " " + (x.kind === "code" ? '<code>' + esc(x.repo) + "/" + esc(x.path) + "</code>" + (x.commit ? ' <span class="sb-ref">@' + esc(x.commit) + "</span>" : "") : esc(x.label || x.ref || "")) + "</li>";
    }).join("") + "</ul>";
  }

  /* ---------- widget ---------- */
  function mount(host, list, o) {
    o = o || {}; if (!list.length) return null;
    var uid = "aw" + Math.random().toString(36).slice(2, 7), cur = o.spec && list.filter(function (x) { return x.id === o.spec; })[0] || list[0], view = o.view || "system", modSel = null, focus = null;
    host.innerHTML = '<div class="rb-arch" id="' + uid + '">' +
      (list.length > 1 ? '<div class="rb-arch-pick" role="group" aria-label="Choose a model" id="' + uid + '-pick">' + list.map(function (s) { return '<button type="button" class="sb-tag" data-spec="' + s.id + '" aria-pressed="' + (s === cur) + '">' + esc(s.name) + (s.year ? ' <span class="rb-arch-y">' + s.year + "</span>" : "") + "</button>"; }).join("") + "</div>" : "") +
      '<div class="rb-arch-bar"><div id="' + uid + '-view"></div><span class="rb-arch-pat" id="' + uid + '-pat"></span></div><div id="' + uid + '-body"></div></div>';
    var root = host.querySelector(".rb-arch");
    function viewSeg() {
      var par = cur.parent && ARCH[cur.parent], opts = [{ value: "system", label: "System" }];
      if (cur.blueprint) opts.push({ value: "blueprint", label: "Blueprint" });
      opts.push({ value: "layers", label: "Modules" });
      if (view === "blueprint" && !cur.blueprint) view = "system";
      if (par) opts.push({ value: "diff", label: "What changed" });
      if (view === "diff" && !par) view = "system";
      var vh = root.querySelector("#" + uid + "-view"); vh.innerHTML = RB.seg({ id: uid + "-seg", label: "Diagram view", options: opts, value: view });
      RB.bindSeg(vh, uid + "-seg", function (v) { view = v; if (v !== "blueprint") focus = null; draw(); });
      root.querySelector("#" + uid + "-pat").innerHTML = '<span class="sb-tag rb-arch-pchip">' + esc(vtext(cur.summary && cur.summary.pattern) || "") + "</span>";
    }
    function draw() {
      var b = root.querySelector("#" + uid + "-body"), s = cur, html = "";
      if (view === "blueprint") {
        var facts = s.modules.filter(function (m) { return m.stack && m.stack.facts && (!focus || m.id === focus); }).map(function (m) { return '<table class="sb-table sb-table--compact rb-ls-facts"><caption>' + esc(m.name) + "</caption><tbody>" + m.stack.facts.map(function (f) { return '<tr><th scope="row">' + esc(f[0]) + "</th><td>" + vhtml(s, f[1]) + "</td></tr>"; }).join("") + "</tbody></table>"; }).join("");
        html = RB.panel({ eyebrow: "Blueprint", ref: esc(s.figRef || ""), meta: '<button class="sb-btn sb-btn--sm" type="button" data-bp-full>Open full size</button>', body:
          '<p class="rb-arch-lede">The whole model, layer by layer. Input at the bottom; each coloured frame is one block, repeated <b>N ×</b> with separate weights; lines to <b>+</b> are residual connections. Numbered badges open the zoom-ins below the towers.</p>' +
          (focus ? '<div class="rb-bp-focusbar" role="status">Showing <b>' + esc((s.modules.filter(function (m) { return m.id === focus; })[0] || {}).name || focus) + '</b><button class="sb-btn sb-btn--sm" type="button" data-bp-all>Show the whole model</button>' + (s.modules.some(function (m) { return m.id === focus && m.stack; }) ? '<button class="sb-btn sb-btn--sm sb-btn--ghost" type="button" data-bp-mod="' + focus + '">Its layers and numbers →</button>' : "") + "</div>" : '<p class="sb-caption rb-bp-hint">Click a tower for its layer stack and numbers.</p>') +
          '<div class="sb-scroll-x rb-bp-scroll" data-arch-bp>' + RB.arch.blueprint(s, { uid: uid }) + "</div>" + (s.blueprint.note ? '<p class="rb-arch-lede rb-bp-note">' + s.blueprint.note + "</p>" : "") +
          (facts ? '<details class="rb-arch-srcd" open><summary>Every number with its source</summary><div class="rb-bp-facts">' + facts + "</div></details>" : "") +
          '<details class="rb-arch-srcd"><summary>Sources</summary>' + sources(s) + "</details>" });
      } else if (view === "system") {
        html = RB.panel({ eyebrow: "System view", ref: esc(s.figRef || ""), prov: s.prov || "", body: (s.lede ? '<p class="rb-arch-lede">' + s.lede + "</p>" : "") + '<div class="sb-scroll-x rb-arch-scroll" data-arch-sys>' + systemAuto(s, { uid: uid }) + "</div>" + legend(s) +
          '<div class="rb-arch-side">' + mask(s) + '<div class="rb-arch-sumw"><p class="rb-h5">At a glance</p>' + summary([s]) + "</div></div>" + (s.callouts && s.callouts.length ? '<ul class="rb-arch-notes">' + s.callouts.map(function (c) { return "<li>" + c + "</li>"; }).join("") + "</ul>" : "") +
          '<details class="rb-arch-srcd"><summary>Sources for every number</summary>' + sources(s) + "</details>" });
      } else if (view === "layers") {
        var withStack = s.modules.filter(function (m) { return m.stack; });
        if (!modSel || !withStack.some(function (m) { return m.id === modSel; })) modSel = (withStack.filter(function (m) { return m.main; })[0] || withStack[0] || {}).id;
        var m = s.modules.filter(function (x) { return x.id === modSel; })[0];
        html = RB.panel({ eyebrow: "Layer view", ref: esc(s.figRef || ""), body: (withStack.length > 1 ? RB.seg({ id: uid + "-mods", label: "Module", options: withStack.map(function (x) { return { value: x.id, label: x.short || x.name }; }), value: modSel }) : "") +
          '<p class="rb-arch-lede">Input at the bottom, output at the top. A dashed frame is one block; <b>× N</b> is how many times it repeats with separate weights.</p>' + (m ? layers(s, m) : '<p class="sb-empty">The paper and code do not describe this model layer by layer.</p>') +
          '<details class="rb-arch-srcd"><summary>Sources for every number</summary>' + sources(s) + "</details>" });
      } else {
        var p = ARCH[s.parent];
        html = RB.panel({ eyebrow: "What changed", title: esc(p.name) + " → " + esc(s.name), body: (s.changes ? '<ol class="rb-arch-chg">' + s.changes.map(function (c) { return "<li>" + c + "</li>"; }).join("") + "</ol>" : "") +
          '<div class="rb-arch-pair"><figure><figcaption>' + esc(p.name) + '</figcaption><div class="sb-scroll-x rb-arch-scroll">' + systemAuto(p, { uid: uid + "p" }) + '</div></figure><figure><figcaption>' + esc(s.name) + '</figcaption><div class="sb-scroll-x rb-arch-scroll">' + systemAuto(s, { uid: uid + "c" }) + "</div></figure></div>" +
          '<p class="rb-h5">Side by side</p>' + summary([p, s]) });
      }
      b.innerHTML = html;
      var fb = b.querySelector("[data-bp-full]");
      if (fb) fb.addEventListener("click", function () { openFull(s); });
      if (view === "layers" && root.querySelector("#" + uid + "-mods")) RB.bindSeg(root, uid + "-mods", function (v) { modSel = v; draw(); });
      /* System → Blueprint: clicking a module spotlights its tower; Blueprint → Modules: clicking a tower opens its layers */
      b.querySelectorAll(".rb-am").forEach(function (g) {
        var mid = g.getAttribute("data-mod"), hasTower = s.blueprint && s.blueprint.towers.some(function (t) { return t.mod === mid; }), hasStack = s.modules.some(function (m) { return m.id === mid && m.stack; });
        if (!hasTower && !hasStack) return;
        g.classList.add("has-stack"); g.setAttribute("tabindex", "0"); g.setAttribute("role", "button");
        g.setAttribute("aria-label", hasTower ? "Show " + mid + " in the blueprint" : "Show the layers of " + mid);
        function open() { if (hasTower) { focus = mid; view = "blueprint"; } else { modSel = mid; view = "layers"; } viewSeg(); draw(); }
        g.addEventListener("click", open); g.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
      });
      var bpsvg = b.querySelector("[data-arch-bp] .rb-bp-svg");
      if (bpsvg) {
        if (focus) {
          bpsvg.classList.add("has-focus");
          bpsvg.querySelectorAll("[data-tower]").forEach(function (t) { t.classList.toggle("is-focus", t.getAttribute("data-tower") === focus); });
          var ft = bpsvg.querySelector('.rb-bp-tower[data-tower="' + focus + '"]'), sc = b.querySelector("[data-arch-bp]");
          if (ft && sc) { var r = ft.getBoundingClientRect(), rs = sc.getBoundingClientRect(); sc.scrollLeft += (r.left + r.width / 2) - (rs.left + rs.width / 2); }
        }
        bpsvg.querySelectorAll(".rb-bp-tower").forEach(function (t) {
          var mid = t.getAttribute("data-tower"); if (!s.modules.some(function (m) { return m.id === mid && m.stack; })) return;
          t.classList.add("is-link"); t.setAttribute("tabindex", "0"); t.setAttribute("role", "button"); t.setAttribute("aria-label", "Open the layers of " + mid);
          function go() { modSel = mid; view = "layers"; viewSeg(); draw(); }
          t.addEventListener("click", go); t.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
        });
      }
      var ab = b.querySelector("[data-bp-all]"); if (ab) ab.addEventListener("click", function () { focus = null; draw(); });
      var mb = b.querySelector("[data-bp-mod]"); if (mb) mb.addEventListener("click", function () { modSel = mb.getAttribute("data-bp-mod"); view = "layers"; viewSeg(); draw(); });
      if (RB.typeset) RB.typeset(b);
    }
    var pick = root.querySelector("#" + uid + "-pick");
    if (pick) pick.addEventListener("click", function (e) { var t = e.target.closest("[data-spec]"); if (!t) return; cur = ARCH[t.getAttribute("data-spec")]; modSel = null; focus = null; pick.querySelectorAll("[data-spec]").forEach(function (x) { x.setAttribute("aria-pressed", x === t); }); viewSeg(); draw(); });
    viewSeg(); draw();
    try { var mq = window.matchMedia("(max-width: 600px)"), onMq = function () { if (!host.isConnected) { mq.removeEventListener ? mq.removeEventListener("change", onMq) : mq.removeListener(onMq); return; } draw(); }; (mq.addEventListener ? mq.addEventListener("change", onMq) : mq.addListener(onMq)); } catch (e) {}
    return {
      root: root, uid: uid,
      select: function (id) { var t = pick && pick.querySelector('[data-spec="' + id + '"]'); if (t) t.click(); else if (ARCH[id]) { cur = ARCH[id]; viewSeg(); draw(); } },
      setView: function (v) { var b = root.querySelector("#" + uid + '-seg [value="' + v + '"]'); if (b) b.click(); },
      state: function () { return { spec: cur.id, view: view, mod: modSel }; }
    };
  }

  function openFull(s) {
    var ov = document.createElement("div"); ov.className = "rb-bp-over"; ov.setAttribute("role", "dialog"); ov.setAttribute("aria-modal", "true"); ov.setAttribute("aria-label", s.name + " blueprint, full size");
    ov.innerHTML = '<div class="rb-bp-over-bar"><b>' + esc(s.name) + '</b><button class="sb-btn" type="button" data-close>Close</button></div><div class="rb-bp-over-body">' + RB.arch.blueprint(s, { uid: "full" }) + "</div>";
    function close() { ov.remove(); document.removeEventListener("keydown", key); document.documentElement.style.overflow = ""; if (last) last.focus(); }
    function key(e) { if (e.key === "Escape") close(); else if (e.key === "Tab") { e.preventDefault(); ov.querySelector("[data-close]").focus(); } }
    ov.addEventListener("click", function (e) { if (e.target === ov) close(); }); document.documentElement.style.overflow = "hidden";
    var last = document.activeElement; document.body.appendChild(ov); ov.querySelector("[data-close]").addEventListener("click", close); document.addEventListener("keydown", key); ov.querySelector("[data-close]").focus();
  }

  /* demo for a topic's architecture section */
  function topicDemo(tid, host) {
    return function () {
      var api = host.__arch; if (!api) return [];
      var list = forTopic(tid), first = list[0], withPar = list.filter(function (s) { return s.parent && ARCH[s.parent]; })[0];
      var q = function (sel) { return function () { return api.root.querySelector(sel); }; };
      var steps = [
        { target: function () { return api.root.querySelector(".rb-arch-pick") || api.root.querySelector(".rb-arch-bar"); }, title: "One diagram per model", text: "Every model is drawn from the same parts, so two diagrams differ only where the models differ.", do: function (a) { api.select(first.id); api.setView("system"); return a.wait(300); } },
        { target: q("[data-arch-sys]"), title: "Modules and tokens", text: "Boxes are modules, coloured by role. Squares below are input tokens, squares above are outputs, and each link says how two modules talk.", do: function (a) { return a.wait(200); } },
        { target: q(".rb-arch-side"), title: "Mask and numbers", text: "The mask shows which tokens may attend to which. The table lists sizes, steps and data, each tagged with its paper or code source.", do: function (a) { return a.wait(200); } }
      ];
      if (first.blueprint) steps.push({ target: q("[data-arch-bp]"), title: "Click a module", text: "Clicking a module opens the blueprint with that network in focus: its block, repeat count and key sizes.", do: function (a) { var m = first.blueprint.towers[first.blueprint.towers.length > 1 ? 1 : 0].mod; var g = api.root.querySelector('.rb-am[data-mod="' + m + '"]'); if (g) g.dispatchEvent(new MouseEvent("click", { bubbles: true })); return a.wait(400); } });
      steps.push({ target: q(".rb-arch-bar"), title: "Layers and numbers", text: "Modules view lists one network's layers next to a table of its sizes, each with its source. Click a tower in the blueprint to jump there.", do: function (a) { api.setView("layers"); return a.wait(300); }, task: "Choose Modules", expect: function () { return api.state().view === "layers"; } });
      if (withPar) steps.push({ target: q(".rb-arch-bar"), title: "Compare with the parent", text: "What changed lines up this model with the one it built on and marks the rows that changed.", do: function (a) { api.select(withPar.id); api.setView("diff"); return a.wait(300); }, task: "Choose What changed", expect: function () { return api.state().view === "diff"; } });
      return steps;
    };
  }

  /* links that open a given model's blueprint inside its topic */
  document.addEventListener("click", function (e) {
    var a = e.target.closest && e.target.closest("[data-arch-open]"); if (!a) return;
    var id = a.getAttribute("data-arch-open"), tries = 0;
    (function sel() { var s = ARCH[id], h = s && document.querySelector('[data-arch-topic="' + topicOf(s) + '"]'); if (h && h.__arch) { h.__arch.select(id); h.__arch.setView("blueprint"); } else if (tries++ < 20) setTimeout(sel, 150); })();
  });

  RB.arch = { topicOf: topicOf, alias: alias, aliasNote: aliasNote, none: none, systemAuto: systemAuto, systemV: systemV, spec: spec, get: function (id) { return ARCH[id]; }, all: function () { return ORDER.map(function (k) { return ARCH[k]; }); }, forTopic: forTopic, forMethod: forMethod, system: system, layers: layers, summary: summary, mask: mask, legend: legend, mount: mount, topicDemo: topicDemo, vtext: vtext };
})();
