/* ===== Routing between the eight pages, sub-tabs and deep links =====
   #page · #page/<tab> · #explorer/<topic>[/<section>] · #lab/<station> · #glossary/<term> · #notation/<symbol> · #evolution/lineage/<method> */
(function () {
  "use strict";
  var RB = window.RB;
  var PAGES = ["overview", "tldr", "explorer", "evolution", "compare", "lab", "reference", "glossary", "notation"];
  var REDIRECT = { home: "overview", path: "overview", chapters: "explorer", topics: "explorer", lineage: "evolution", tl: "tldr", summary: "tldr", decide: "compare/decide", machine: "lab", playground: "lab", formulas: "reference/formulas", terms: "glossary" };
  var TABS = { evolution: "lineage", compare: "sbs", reference: "formulas", glossary: "visual" };
  RB.pages = RB.pages || {};
  var inited = {}, current = null;

  function parse() {
    var h = location.hash.replace(/^#/, ""); try { h = decodeURIComponent(h); } catch (e) { } h = h || "overview";
    var parts = h.split("/");
    if (REDIRECT[parts[0]]) { parts = REDIRECT[parts[0]].split("/").concat(parts.slice(1)); }
    if (parts[0] === "reference" && parts[1] === "decide") parts = ["compare", "decide"];
    if (PAGES.indexOf(parts[0]) < 0) {
      /* bare anchors such as #b2 or #term-x fall back to the topic or term */
      if (RB.topics[parts[0]]) parts = ["explorer", parts[0]];
      else if (RB.terms[parts[0]]) parts = ["glossary", parts[0]];
      else parts = ["overview"];
    }
    return parts;
  }

  function showPage(page) {
    PAGES.forEach(function (p) {
      var v = document.getElementById("view-" + p); if (v) v.hidden = p !== page;
      var t = document.getElementById("tab-" + p); if (t) { if (p === page) t.setAttribute("aria-current", "page"); else t.removeAttribute("aria-current"); }
    });
    var skip = document.getElementById("skipLink"); if (skip) skip.setAttribute("href", "#" + page);
    var F = "Study Bench · Robot Learning", a = document.querySelector('nav.sb-views [aria-current="page"]'), n = a ? a.textContent.trim() : "";
    document.title = (!n || n === "Overview") ? F : n + " · " + F;
  }

  function showTab(page, tab) {
    var nav = document.querySelector('nav.sb-subtabs[data-subtabs="' + page + '"]'); if (!nav) return null;
    tab = tab || TABS[page];
    if (!document.querySelector('[data-tabpanel="' + page + "/" + tab + '"]')) tab = TABS[page];
    RB.$$("a[data-tab]", nav).forEach(function (a) { if (a.getAttribute("data-tab") === tab) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current"); });
    RB.$$('[data-tabpanel^="' + page + '/"]').forEach(function (p) { p.hidden = p.getAttribute("data-tabpanel") !== page + "/" + tab; });
    return tab;
  }

  function route() {
    var parts = parse(), page = parts[0];
    var changed = page !== current;
    if (changed && current && RB.pages[current] && RB.pages[current].hide) { try { RB.pages[current].hide(); } catch (e0) { console.error(e0); } }
    showPage(page); current = page;
    var P = RB.pages[page] || {};
    if (!inited[page]) { inited[page] = true; try { if (P.init) P.init(); } catch (e) { RB.warn("init " + page + " failed: " + e.message); console.error(e); } }
    var tab = TABS[page] ? showTab(page, parts[1]) : null;
    var rest = TABS[page] ? (tab === parts[1] ? parts.slice(2) : parts.slice(1)) : parts.slice(1);
    try { if (P.show) P.show({ tab: tab, rest: rest, changed: changed }); } catch (e2) { RB.warn("show " + page + " failed: " + e2.message); console.error(e2); }
    if (changed && !(rest && rest.length) && route.n++ > 0) { window.scrollTo(0, 0); var h1 = document.querySelector("#view-" + page + " h1"); if (h1) h1.focus({ preventScroll: true }); }
    if (tab && P.tabShown) P.tabShown(tab, rest);
  }
  route.n = 0;
  RB.route = route;
  RB.go = function (hash) { if (location.hash === hash) route(); else location.hash = hash; };
  RB.currentPage = function () { return current; };
  window.addEventListener("hashchange", route);
})();
