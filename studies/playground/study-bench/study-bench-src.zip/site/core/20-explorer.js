/* ===== Topic Explorer: TOC, topic pages (TopicPage template), progress =====
   Topics render lazily the first time they are shown. */
(function () {
  "use strict";
  var RB = window.RB, h = RB.h, esc = RB.esc;
  var rendered = {}, progress = null, currentTopic = null;
  RB.demos = RB.demos || {};

  function T(id) { return RB.topics[id]; }
  function partOf(id) { var p = T(id).part; return RB.PARTS.filter(function (x) { return x.id === p; })[0]; }
  function leadsTo(id) { return RB.topicOrder.filter(function (k) { return (T(k).buildsOn || []).indexOf(id) >= 0; }); }
  function firstRef(id) { var t = T(id); return "Topic " + t.num; }
  RB.topicTitle = function (id) { var t = T(id); return t ? (t.title || t.short) : id; };

  /* ---------- TOC ---------- */
  function buildToc() {
    var toc = document.getElementById("toc"), sel = document.getElementById("mobileToc");
    var html = '<div class="sb-toc-head"><div class="sb-meter" data-progress role="meter" aria-label="Topics understood"><div class="sb-meter-track"><div class="sb-meter-fill"></div></div><span class="sb-meter-text"></span></div><button class="sb-btn" type="button" data-howto="continue">Continue ▶</button><span class="sb-toc-next" id="tocNext"></span></div>';
    RB.PARTS.forEach(function (p) {
      var ids = RB.topicOrder.filter(function (k) { return T(k).part === p.id; });
      html += '<p class="sb-toc-part">Part ' + p.id + " · " + esc(p.name) + "</p><ol>";
      ids.forEach(function (k) { var t = T(k); html += '<li><a href="#explorer/' + k + '" data-topic="' + k + '"><span class="sb-toc-n">' + t.num + '</span><span>' + esc(t.short) + '</span><span class="sb-toc-check" data-check="' + k + '" aria-hidden="true"></span><span class="sb-toc-sub">' + esc((t.sources || "").split(" · ")[0]) + '</span></a></li>'; });
      html += "</ol>";
    });
    toc.innerHTML = html;
    sel.innerHTML = RB.topicOrder.map(function (k) { return '<option value="' + k + '">' + T(k).num + " " + esc(T(k).short) + "</option>"; }).join("");
    sel.addEventListener("change", function () { RB.go("#explorer/" + sel.value); });
  }
  function nextUp() { var ids = RB.topicOrder; for (var i = 0; i < ids.length; i++) if (!progress || !progress.get(ids[i])) return ids[i]; return ids[0]; }
  RB.nextUp = nextUp;

  /* ---------- topic page ---------- */
  function sec(o, inner) {
    return '<section class="sb-sec rb-tsec' + (o.cls ? " " + o.cls : "") + '"' + (o.id ? ' id="' + o.id + '"' : "") + ">" + RB.secHead({ eyebrow: o.eyebrow, title: o.title, lede: o.lede, demo: o.demo, demoMeta: o.demoMeta, anchor: o.id ? "#explorer/" + o.topic + "/" + o.id.replace(o.topic + "-", "") : null }) + inner + "</section>";
  }

  function orientation(t) {
    var builds = (t.buildsOn || []).map(function (k) { return '<a href="#explorer/' + k + '"><span class="sb-ref">' + firstRef(k) + "</span>" + esc(RB.topicTitle(k)) + "</a>"; }).join("") || '<span class="sb-caption">Start here.</span>';
    var leads = leadsTo(t.id).map(function (k) { return '<a href="#explorer/' + k + '"><span class="sb-ref">' + firstRef(k) + "</span>" + esc(RB.topicTitle(k)) + "</a>"; }).join("") || '<span class="sb-caption">The last topic of its part.</span>';
    return '<div class="sb-orient"><section class="sb-orient-card"><span class="sb-eyebrow">Why this exists</span><p>' + (t.why || "") + '</p></section><section class="sb-orient-card"><span class="sb-eyebrow">After this you can</span><ul class="sb-outcomes">' + (t.outcomes || []).map(function (o) { return "<li><span>" + o + "</span></li>"; }).join("") + '</ul></section><section class="sb-orient-card"><span class="sb-eyebrow">How it connects</span><div class="sb-connect"><div class="sb-connect-col"><span class="sb-connect-k">← Builds on</span>' + builds + '</div><div class="sb-connect-col"><span class="sb-connect-k">Leads to →</span>' + leads + "</div></div></section></div>";
  }

  function concepts(t) {
    return '<div class="sb-concepts">' + (t.concepts || []).map(function (c) {
      var go = c.href ? '<a class="sb-link sb-concept-go" href="' + c.href + '">' + (c.hrefLabel || "See it working →") + "</a>" : (c.term ? '<a class="sb-link sb-concept-go" href="#glossary/' + c.term + '">In the glossary →</a>' : "");
      return '<article class="sb-concept"><div class="sb-concept-art"' + (c.sym ? ' data-sym="' + c.sym + '"' : "") + ">" + (c.art || "") + '</div><p class="sb-concept-name">' + esc(c.name) + '</p><p class="sb-concept-def">' + c.def + "</p>" + (c.ref ? '<span class="sb-ref">' + esc(c.ref) + "</span>" : "") + go + "</article>";
    }).join("") + "</div>";
  }

  function worked(t) {
    var w = t.worked; if (!w) return "";
    if (w.mount) return RB.panel({ ref: w.ref, prov: w.prov, body: '<div data-worked="' + t.id + '"></div>' });
    var n = w.steps.length;
    var eq = w.eq ? '<div class="sb-eq rb-we-eq">' + (w.eq.html ? '<div class="sb-eq-math">' + w.eq.html + "</div>" : '<div class="sb-eq-math">' + RB.tex(w.eq.tex) + "</div>") + (w.eq.words ? '<p class="sb-eqwords"><b>In words:</b> ' + w.eq.words + "</p>" : "") + RB.eqKey(w.eq.key) + "</div>" : "";
    var fig = w.figure ? '<div class="sb-scroll-x rb-we-fig">' + w.figure + "</div>" : "";
    var texts = w.steps.map(function (s, i) { return '<p class="sb-step-text" data-step-text="' + (i + 1) + '"' + (i ? " hidden" : "") + "><b>" + esc(s.title) + ".</b> " + s.text + "</p>"; }).join("");
    var body = '<div class="sb-stepper sb-stepper--reveal rb-we" data-steps="' + n + '" tabindex="0" aria-label="Worked example. Use the arrow keys to step.">' + eq + fig + texts +
      '<div class="sb-stepper-bar"><button class="sb-btn sb-btn--primary" data-act="play">Play ▶</button><button class="sb-btn" data-act="prev" aria-label="Previous step">←</button><button class="sb-btn" data-act="next" aria-label="Next step">→</button><input class="sb-range" type="range" data-act="scrub" aria-label="Step"><span class="sb-status" data-status></span></div></div>';
    return RB.panel({ ref: w.ref, prov: w.prov, body: body });
  }

  function rules(t) {
    var out = "";
    if (t.rules && t.rules.length) out += '<p class="sb-lit-hint">Hover a symbol to see it everywhere: equation, key and pseudocode.</p><div class="rb-rule"><div class="rb-stack">' + t.rules.map(function (r) { return RB.eqBlock(r); }).join("") + "</div>";
    if (t.algorithm) {
      var a = t.algorithm;
      out += '<div class="sb-algo"><div class="sb-algo-head"><h4 class="sb-algo-title">' + esc(a.title) + "</h4>" + (a.ref ? '<span class="sb-ref">' + esc(a.ref) + "</span>" : "") + (a.prov ? '<span class="sb-prov">' + esc(a.prov) + "</span>" : "") + "</div><ol>" + a.lines.map(function (l) { return "<li>" + l + "</li>"; }).join("") + "</ol></div>";
    }
    if (t.rules && t.rules.length) out += "</div>";
    return out;
  }

  function methodsTable(t) {
    var all = RB.methodsFor(t.id).slice().sort(function (a, b) { return (a.tier - b.tier) || ((a.year || 0) - (b.year || 0)); });
    if (t.methods && t.methods.length) { var pick = t.methods.filter(function (id) { return RB.M[id]; }).map(function (id) { return RB.M[id]; }); all = pick.concat(all.filter(function (m) { return pick.indexOf(m) < 0; })); }
    if (!all.length) return "";
    var t1 = all.filter(function (m) { return m.tier === 1; }).length;
    var rows = all.map(function (m, i) {
      return '<tr' + (m.tier !== 1 ? ' data-tier2 hidden' : "") + '><th scope="row"><b>' + esc(m.name) + '</b><br><span class="sb-ref">' + (m.year || "–") + "</span> " + RB.coverageTag(m) + '<span class="rb-mlinks"><a href="#compare/sbs/' + m.id + '" aria-label="Compare ' + esc(m.name) + '">Compare</a>' + (m.arxiv ? '<a href="https://arxiv.org/abs/' + m.arxiv + '" target="_blank" rel="noopener" aria-label="' + esc(m.name) + ' paper on arXiv">Paper ↗</a>' : "") + '</span></th><td>' + esc(m.idea || m.problem || "") + "</td><td>" + esc(m.action || m.outputs || "–") + "</td><td>" + esc((m.parents || []).slice(0, 3).join(", ") || "–") + "</td></tr>";
    }).join("");
    var more = all.length > t1 ? '<button class="sb-btn" type="button" data-more-methods>Show all</button>' : "";
    return '<div class="sb-toolbar"><span class="sb-count">' + t1 + " read in full" + (all.length > t1 ? " · " + (all.length - t1) + " fact cards" : "") + "</span>" + more + '</div><div class="sb-scroll-x"><table class="sb-table rb-mtable"><thead><tr><th scope="col">Method</th><th scope="col">Key idea</th><th scope="col">Output</th><th scope="col">Builds on</th></tr></thead><tbody>' + rows + "</tbody></table></div>";
  }

  function openProblems(t) {
    if (!t.open || !t.open.length) return "";
    return '<div class="rb-open">' + t.open.map(function (o) { return '<article class="rb-open-card"><p class="rb-open-t">' + esc(o.title) + "</p><p>" + o.text + "</p>" + (o.refs ? '<span class="sb-ref">' + esc(o.refs) + "</span>" : "") + "</article>"; }).join("") + "</div>";
  }

  function close(t) {
    var qz = (t.quiz || []).map(function (q, qi) {
      return '<div class="sb-q" role="group" aria-labelledby="' + t.id + "-q" + qi + '"><p class="sb-q-text" id="' + t.id + "-q" + qi + '"><span class="sb-q-n">' + (qi + 1) + "</span>" + q.q + '</p><div class="sb-opts">' + q.options.map(function (o, oi) { return '<button type="button" class="sb-opt"' + (oi === q.correct ? ' data-correct="true"' : "") + '><span class="sb-opt-mark" aria-hidden="true"></span><span>' + o + "</span></button>"; }).join("") + '</div><p class="sb-q-why" tabindex="-1" hidden>' + q.why + "</p></div>";
    }).join("");
    return '<div class="rb-close-check"><div class="sb-panel"><div class="sb-panel-head"><div class="sb-seg sb-seg--sm" role="group" aria-label="Mode"><button type="button" aria-pressed="true" data-m="quiz">Quiz</button><button type="button" aria-pressed="false" data-m="cards">Flashcards</button></div></div><div class="sb-panel-body"><div class="rb-quiz" data-quiz>' + qz + '<div class="sb-btn-row"><span class="sb-status" data-quiz-score aria-live="polite"></span><button class="sb-btn sb-btn--ghost" type="button" data-quiz-reset>Reset quiz</button></div></div><div class="rb-cards" data-cards hidden></div></div></div></div>' +
      '<div class="sb-btn-row rb-understood"><button class="sb-btn" type="button" data-understood="' + t.id + '">Mark as understood</button><div class="sb-meter" data-progress role="meter" aria-label="Topics understood"><div class="sb-meter-track"><div class="sb-meter-fill"></div></div><span class="sb-meter-text"></span></div></div>';
  }

  function pager(t) {
    var i = RB.topicOrder.indexOf(t.id), p = RB.topicOrder[i - 1], n = RB.topicOrder[i + 1];
    return '<nav class="sb-pager" aria-label="Previous and next topic">' + (p ? '<a href="#explorer/' + p + '"><span class="sb-pager-k">← Previous</span><span class="sb-pager-t">' + T(p).num + " " + esc(RB.topicTitle(p)) + "</span></a>" : "<span></span>") + (n ? '<a class="is-next" href="#explorer/' + n + '"><span class="sb-pager-k">Next →</span><span class="sb-pager-t">' + T(n).num + " " + esc(RB.topicTitle(n)) + "</span></a>" : '<a class="is-next" href="#evolution"><span class="sb-pager-k">Next page →</span><span class="sb-pager-t">Evolution</span></a>') + "</nav>";
  }

  function renderTopic(id) {
    var t = T(id), host = document.getElementById("topics");
    var art = h("article", { "class": "sb-topic", id: id, "data-topic": id, hidden: true });
    if (!t.__full) {
      art.innerHTML = '<header class="sb-topic-head"><p class="sb-eyebrow">Part ' + t.part + " · " + esc(partOf(id).name) + '</p><h2 class="sb-topic-title"><span class="sb-topic-num">' + t.num + "</span>" + esc(t.short) + '</h2>' + (RB.topicLinks ? RB.topicLinks("explorer", [id]) : "") + '</header><div class="sb-empty"><p class="sb-empty-t">This topic is being written.</p><p>Its sources are ' + esc(t.sources) + ". The methods below come from the reading pass.</p></div>" + sec({ eyebrow: "Methods", title: "Methods in this topic", topic: id }, methodsTable(t)) + pager(t);
      host.appendChild(art); rendered[id] = art; return art;
    }
    var pg = (t.playgrounds || []).length, nq = (t.quiz || []).length;
    var chips = (t.refs || []).map(function (r) { return '<span class="sb-ref">' + esc(r) + "</span>"; }).join("") + (pg ? '<span class="sb-tag">' + pg + " playground" + (pg > 1 ? "s" : "") + "</span>" : "") + (nq ? '<span class="sb-tag">Quiz · ' + nq + " questions</span>" : "");
    var s = '<header class="sb-topic-head"><p class="sb-eyebrow">' + esc(t.eyebrow || ("Part " + t.part + " · " + t.short)) + '</p><h2 class="sb-topic-title"><span class="sb-topic-num">' + t.num + "</span>" + esc(t.title) + ' <a class="sb-anchor" href="#explorer/' + id + '" aria-label="Link to this topic">#</a></h2>' + (RB.topicLinks ? RB.topicLinks("explorer", [id]) : "") + '<p class="sb-lede">' + t.lede + '</p><div class="sb-chips">' + chips + "</div></header>";
    s += sec({ eyebrow: "Orientation", title: "Before you start", topic: id, id: id + "-orient" }, orientation(t));
    if (t.concepts && t.concepts.length) s += sec({ eyebrow: "Key concepts", title: "Terms to know", topic: id, id: id + "-concepts" }, concepts(t));
    if (t.flow) s += sec({ eyebrow: "Where it happens", title: t.flow.title, topic: id, id: id + "-flow", demo: "walk-" + id, demoMeta: t.flow.steps.length + " steps" }, RB.panel({ ref: t.flow.ref, prov: t.flow.prov, body: '<div class="rb-flow" data-flow="' + id + '"></div>' }));
    if (t.worked) s += sec({ eyebrow: "Worked example", title: t.worked.title, topic: id, id: id + "-worked" }, worked(t));
    if ((t.rules && t.rules.length) || t.algorithm) s += sec({ eyebrow: "The rule", title: t.ruleTitle || "The key equations", topic: id, id: id + "-rule" }, rules(t));
    var archs = RB.arch ? RB.arch.forTopic(id) : [];
    if (archs.length) s += sec({ eyebrow: "Model architectures", title: t.archTitle || (archs.length > 1 ? "Inside the models" : "Inside " + archs[0].name), topic: id, id: id + "-arch", lede: "Every model is drawn with the same parts: modules coloured by role, input tokens below, outputs above, and the coupling written on each link. Select a module for its layers.", demo: "arch-" + id, demoMeta: archs.length + (archs.length > 1 ? " models" : " model") }, '<div class="rb-arch-host" data-arch-topic="' + id + '"></div>');
    (t.playgrounds || []).forEach(function (p, k) {
      s += sec({ eyebrow: k === 0 ? "Playground" : "Playground " + (k + 1), title: p.title, topic: id, id: id + "-pg-" + p.id, cls: "rb-play", demo: p.demo ? "pg-" + id + "-" + p.id : null, demoMeta: p.demo ? (typeof p.demo === "function" ? "" : p.demo.length + " steps") : null },
        (p.try ? RB.callout("try", p.try) : "") + '<div class="sb-panel"' + ' data-pg="' + id + "/" + p.id + '"><div class="sb-panel-head"><span class="sb-eyebrow sb-eyebrow--live">Interactive</span>' + (p.ref ? '<span class="sb-ref">' + esc(p.ref) + "</span>" : "") + (p.prov ? '<span class="sb-prov">' + esc(p.prov) + "</span>" : "") + (p.meta ? '<span class="sb-panel-meta">' + esc(p.meta) + "</span>" : "") + '</div><div class="sb-panel-body rb-pg-body" data-pg-body="' + id + "/" + p.id + '">' + (p.html || "") + "</div></div>");
    });
    s += sec({ eyebrow: "Methods", title: "Methods in this topic", topic: id, id: id + "-methods", lede: t.methodsLede || "Every method paper the surveys cite for this topic. Rows marked Fact card are hidden until you show all." }, methodsTable(t));
    if (t.open && t.open.length) s += sec({ eyebrow: "Frontier", title: "What is still open", topic: id, id: id + "-open" }, openProblems(t));
    s += sec({ eyebrow: "Takeaways", title: "What to remember", topic: id, id: id + "-takeaways", cls: "rb-takeaways" }, '<ol class="sb-takeaways">' + (t.takeaways || []).map(function (x) { return "<li><span>" + x + "</span></li>"; }).join("") + "</ol>");
    s += sec({ eyebrow: "Check yourself", title: "Quiz and flashcards", topic: id, id: id + "-check", cls: "rb-close" }, close(t));
    s += pager(t);
    art.innerHTML = s;
    host.appendChild(art); rendered[id] = art;
    wireTopic(t, art);
    return art;
  }

  function wireTopic(t, art) {
    var id = t.id;
    var ah = art.querySelector("[data-arch-topic]");
    if (ah) { try { ah.__arch = RB.arch.mount(ah, RB.arch.forTopic(id)); RB.demos["arch-" + id] = RB.arch.topicDemo(id, ah); } catch (e) { ah.innerHTML = '<div class="sb-error">The architecture diagram failed to draw: ' + esc(e.message) + "</div>"; RB.warn(id + " arch: " + e.message); } }
    /* flow */
    if (t.flow) {
      var fh = art.querySelector('[data-flow="' + id + '"]');
      try { var fapi = StudyBench.flow(fh, t.flow); fh.__flow = fapi; } catch (e) { fh.innerHTML = '<div class="sb-error">The diagram failed to draw: ' + esc(e.message) + "</div>"; RB.warn(id + " flow: " + e.message); }
      RB.demos["walk-" + id] = function () {
        var n = t.flow.steps.length, steps = [];
        for (var k = 0; k < n; k++) (function (k) { steps.push({ target: fh, title: "Step " + (k + 1) + " of " + n, text: t.flow.steps[k].text, do: function (api) { var ctl = fh.querySelector(".sb-flow-ctl"); if (fh.__flow && fh.__flow.stepper) fh.__flow.stepper.go(k + 1); return api.wait(200); }, task: k === 0 ? "Press Next → under the diagram" : "Press Next → to go to step " + (k + 1), expect: k === 0 ? null : function () { return fh.__flow && fh.__flow.stepper && fh.__flow.stepper.step >= k + 1; } }); })(k);
        steps.push({ target: fh, title: "Your turn", text: "Click any box to jump to the first step that involves it, or press Play ▶ to watch the whole loop again." });
        return steps;
      };
    }
    /* worked example */
    if (t.worked) {
      if (t.worked.mount) { try { t.worked.mount(art.querySelector('[data-worked="' + id + '"]')); } catch (e) { RB.warn(id + " worked: " + e.message); } }
      else { var st = art.querySelector(".rb-we"); if (st) StudyBench.stepper(st); }
    }
    /* playgrounds */
    (t.playgrounds || []).forEach(function (p) {
      var body = art.querySelector('[data-pg-body="' + id + "/" + p.id + '"]');
      var ctx = { topic: id, id: id + "-" + p.id, pal: RB.pal };
      try { if (p.mount) p.__api = p.mount(body, ctx) || {}; }
      catch (e) { body.innerHTML = '<div class="sb-error">This playground failed to start (' + esc(e.message) + "). Reload the page; if it persists, the demo is broken.</div>"; RB.warn(id + "/" + p.id + " mount: " + e.message); console.error(e); }
      if (p.demo) RB.demos["pg-" + id + "-" + p.id] = function () { return typeof p.demo === "function" ? p.demo(body, p.__api) : p.demo; };
    });
    /* methods: show all */
    var more = art.querySelector("[data-more-methods]");
    if (more) more.addEventListener("click", function () { var on = more.getAttribute("aria-pressed") === "true"; RB.$$("[data-tier2]", art).forEach(function (r) { r.hidden = on; }); more.setAttribute("aria-pressed", on ? "false" : "true"); more.textContent = on ? "Show all" : "Hide fact cards"; });
    /* quiz + flashcards */
    var qz = art.querySelector("[data-quiz]"); if (qz) StudyBench.quiz(qz);
    var seg = art.querySelector(".rb-close .sb-seg"), cardsHost = art.querySelector("[data-cards]"), cardsOn = false;
    if (seg) StudyBench.segmented(seg, function (_v, b) {
      var m = b.getAttribute("data-m"); qz.hidden = m !== "quiz"; cardsHost.hidden = m !== "cards";
      if (m === "cards" && !cardsOn) { cardsOn = true; StudyBench.flashcards(cardsHost, (t.cards || []).length ? t.cards : [{ front: "No cards yet", back: "–", ref: "" }], "rb-cards-" + id); }
    });
    /* linked highlighting + math + terms */
    RB.$$(".rb-rule, .rb-we, .sb-eq", art).forEach(function (sc) { StudyBench.link(sc); });
    RB.typeset(art);
    RB.linkTerms(art);
  }

  function showTopic(id, section) {
    if (!T(id)) id = RB.topicOrder[0];
    if (!rendered[id]) renderTopic(id);
    Object.keys(rendered).forEach(function (k) { rendered[k].hidden = k !== id; });
    currentTopic = id;
    RB.$$("#toc a[data-topic]").forEach(function (a) { if (a.getAttribute("data-topic") === id) a.setAttribute("aria-current", "location"); else a.removeAttribute("aria-current"); });
    var sel = document.getElementById("mobileToc"); if (sel) sel.value = id;
    if (progress) progress.set(id, progress.get(id)); /* re-sync buttons and meters in newly rendered markup */
    var n = nextUp(); var tn = document.getElementById("tocNext"); if (tn) tn.textContent = "Next: " + T(n).num + " " + RB.topicTitle(n);
    if (section) { var el = document.getElementById(id + "-" + section) || document.getElementById(section); if (el) setTimeout(function () { el.scrollIntoView({ block: "start" }); StudyBench.flash && StudyBench.flash(el); }, 60); }
    else { var art = rendered[id]; art.scrollIntoView({ block: "start" }); window.scrollTo(0, 0); }
  }
  RB.currentTopic = function () { return currentTopic; };
  RB.renderTopic = function (id) { if (!rendered[id]) renderTopic(id); return rendered[id]; };

  RB.pages.explorer = {
    init: function () {
      buildToc();
      var n = RB.topicOrder.length; document.getElementById("explorerEyebrow").textContent = RB.PARTS.length + " parts · " + n + " topics";
    },
    show: function (o) { showTopic(o.rest[0] || RB.lastTopic || nextUp(), o.rest[1]); RB.lastTopic = currentTopic; }
  };

  RB.initProgress = function () {
    progress = StudyBench.progress(RB.SITE, RB.topicOrder);
    RB.progress = progress;
    return progress;
  };
})();
