/* ===== Compare: side by side, master table (+ reported results), decision guide ===== */
(function () {
  "use strict";
  var RB = window.RB, esc = RB.esc;
  var picked = [];

  var ROWS = [
    ["Year", function (m) { return m.year || "–"; }, true],
    ["Topic", function (m) { var t = RB.topics[(m.topic || "").toLowerCase()]; return t ? t.num + " " + t.short : "–"; }, true],
    ["Coverage", function (m) { return m.coverage !== "primary" ? "Survey only" : m.tier === 1 ? "Read in full" : "Fact card"; }, true],
    ["Problem it fixes", function (m) { return m.problem; }],
    ["Key idea", function (m) { return m.idea; }],
    ["Architecture", function (m) { return m.arch; }],
    ["Inputs", function (m) { return m.inputs; }],
    ["Outputs", function (m) { return m.outputs; }],
    ["Action representation", function (m) { return m.action; }],
    ["Parameters", function (m) { return m.params; }, true],
    ["Training data", function (m) { return m.data; }],
    ["Control rate", function (m) { return m.hz ? m.hz + (String(m.hz).match(/hz/i) ? "" : " Hz") : ""; }, true],
    ["Headline results", function (m) { return (m.results || []).slice(0, 3).map(function (r) { return (r.benchmark || "") + ": " + (r.value || "") + (r.metric ? " " + r.metric : ""); }).join(" · "); }],
    ["Builds on", function (m) { return (m.parents || []).join(", "); }],
    ["What changed", function (m) { return m.changed; }],
    ["Limitations", function (m) { return m.limits; }],
    ["Open weights", function (m) { return m.open === true ? "Yes" : m.open === false ? "No" : "Unknown"; }, true]
  ];

  /* ---------- side by side ---------- */
  function sbs() {
    var host = document.getElementById("cmp-sbs");
    host.innerHTML = '<section class="sb-sec" id="cmp-sbs-sec">' + RB.secHead({ level: "h2", title: "Side by side", lede: "Any number of methods on aligned rows. Where exactly one method differs from the rest, its cell is marked.", demo: "cmp-sbs", demoMeta: "4 steps" }) +
      '<div class="sb-toolbar"><label class="sb-field" for="sbsAdd"><span>Add a method</span><input class="sb-input" id="sbsAdd" list="sbsList" placeholder="Type a name, e.g. π0" autocomplete="off"></label><datalist id="sbsList">' + RB.METHODS.filter(function (m) { return !m.alias_of; }).map(function (m) { return '<option value="' + esc(m.name) + '"' + (RB.arch && RB.arch.forMethod(m.id) ? ' label="◆ has a diagram"' : "") + ">"; }).join("") + '</datalist><button class="sb-btn" type="button" id="sbsAddTopic">Add topic’s core</button><button class="sb-btn" type="button" id="sbsClear">Clear</button><span class="sb-count" id="sbsCount"></span></div><div class="sb-chips" id="sbsChips"></div><div id="sbsGrid"></div></section>';
    var inp = document.getElementById("sbsAdd");
    function addByName() { var v = inp.value.trim().toLowerCase(); var m = RB.METHODS.filter(function (x) { return x.name.toLowerCase() === v; })[0]; if (m) { add(m.id); inp.value = ""; } }
    inp.addEventListener("change", addByName); inp.addEventListener("keydown", function (e) { if (e.key === "Enter") addByName(); });
    document.getElementById("sbsClear").addEventListener("click", function () { picked = []; drawSbs(); });
    document.getElementById("sbsAddTopic").addEventListener("click", function () {
      var last = picked.length ? RB.M[picked[picked.length - 1]] : null, topic = last ? last.topic : "B2";
      RB.methodsFor(topic).filter(function (m) { return m.tier === 1; }).forEach(function (m) { if (picked.indexOf(m.id) < 0) picked.push(m.id); }); drawSbs();
    });
    host.addEventListener("click", function (e) { var x = e.target.closest("[data-unpick]"); if (x) { picked = picked.filter(function (p) { return p !== x.getAttribute("data-unpick"); }); drawSbs(); } });
    RB.demos["cmp-sbs"] = function () {
      return [
        { target: "#sbsGrid", title: "Two methods, aligned", text: "ACT and Diffusion Policy are loaded. Each row compares one property.", do: function (a) { picked = ["act", "diffusion-policy"]; drawSbs(); return a.wait(300); } },
        { target: "#sbsAdd", title: "Add a third", text: "Add π0, the flow-matching VLA. Its column joins the grid.", do: function (a) { add("pi0"); return a.wait(300); }, task: "Type π0 and press Enter", expect: function () { return picked.indexOf("pi0") >= 0; } },
        { target: "#sbsGrid", title: "Read the marked cells", text: "A marked cell is the odd one out in its row: here the one method with far more parameters, or a different action output." },
        { target: "#sbsAddTopic", title: "Your turn", text: "Add a whole topic’s core methods with one click, or clear and start from any method in the master table." }
      ];
    };
  }
  function add(id) { if (RB.M[id] && picked.indexOf(id) < 0) { picked.push(id); drawSbs(); } }
  RB.addToSbs = add;
  function short(v) { v = String(v); var n = v.replace(/[▶→←⏭↗✓✗✕❚·|\/]/g, " ").trim().split(/\s+/).length; if (n <= 12) return v; var w = v.split(/\s+/), out = []; for (var i = 0; i < w.length; i++) { var t = out.concat([w[i]]).join(" "); if (t.replace(/[▶→←⏭↗✓✗✕❚·|\/]/g, " ").trim().split(/\s+/).length > 11) break; out.push(w[i]); } return out.join(" ") + " …"; }
  var archView = "system";
  function drawSbs() {
    var grid = document.getElementById("sbsGrid"), chips = document.getElementById("sbsChips");
    document.getElementById("sbsCount").textContent = picked.length + " selected";
    chips.innerHTML = picked.map(function (id) { var d = RB.arch && RB.arch.forMethod(id); return '<button type="button" class="sb-tag" data-unpick="' + id + '" aria-label="Remove ' + esc(RB.M[id].name) + '">' + (d ? '<span class="rb-has-diag" title="Has an architecture diagram">◆</span> ' : "") + esc(RB.M[id].name) + " ✕</button>"; }).join("");
    if (!picked.length) { grid.innerHTML = '<div class="sb-empty"><p class="sb-empty-t">Nothing selected yet</p><p>Add a method above, or use Add to side by side in the master table.</p></div>'; return; }
    var ms = picked.map(function (id) { return RB.M[id]; });
    var s = '<div class="sb-scroll-x rb-sbs-scroll"><div class="sb-sbs" style="--n:' + ms.length + '"><div class="sb-sbs-row sb-sbs-head"><div class="sb-sbs-k">Method</div>' + ms.map(function (m) { return '<div class="sb-sbs-col"><b>' + esc(m.name) + '</b><br><a class="sb-link" href="#evolution/lineage/' + m.id + '">See its lineage →</a> ' + RB.arxivLink(m) + "</div>"; }).join("") + "</div>";
    ROWS.forEach(function (r) {
      var vals = ms.map(function (m) { var v = r[1](m); return v == null || v === "" ? "–" : String(v); });
      var odd = -1;
      if (r[2] && ms.length >= 3) { var cnt = {}; vals.forEach(function (v) { cnt[v] = (cnt[v] || 0) + 1; }); var keys = Object.keys(cnt); if (keys.length === 2) { var lone = keys.filter(function (k) { return cnt[k] === 1; }); if (lone.length === 1) odd = vals.indexOf(lone[0]); } }
      s += '<div class="sb-sbs-row"><div class="sb-sbs-k">' + r[0] + "</div>" + vals.map(function (v, i) { return '<div class="sb-sbs-col' + (i === odd ? " is-diff" : "") + '">' + esc(short(v)) + "</div>"; }).join("") + "</div>";
    });
    s += "</div></div>";
    s += '<details class="rb-sbs-full"><summary>Show the full cards</summary><div class="rb-sbs-cards">' + ms.map(function (m) { return '<article class="rb-open-card"><p class="rb-open-t">' + esc(m.name) + '</p><dl class="rb-kv">' + ROWS.map(function (r) { var v = r[1](m); return v ? "<dt>" + r[0] + "</dt><dd>" + esc(String(v)) + "</dd>" : ""; }).join("") + "</dl>" + RB.arxivLink(m) + "</article>"; }).join("") + "</div></details>";
    var pairs = RB.arch ? ms.map(function (m) { return { m: m, sp: RB.arch.forMethod(m.id) }; }).filter(function (p) { return p.sp; }) : [];
    var specs = pairs.map(function (p) { return p.sp; });
    var capName = function (i) { var p = pairs[i]; return p.sp.method && p.sp.method !== p.m.id ? esc(p.m.name) + ' <span class="sb-caption">drawn as ' + esc(p.sp.name) + "</span>" : esc(p.sp.name); };
    var missing = RB.arch ? ms.filter(function (m) { return !RB.arch.forMethod(m.id); }) : [];
    if (specs.length) s = '<section class="rb-sbs-arch" aria-labelledby="sbsArchH"><div class="rb-arch-bar"><h4 class="rb-h4" id="sbsArchH">Architectures</h4>' + RB.seg({ id: "sbsArchView", label: "Architecture view", options: [{ value: "system", label: "System" }, { value: "stacks", label: "Blueprints" }], value: archView }) + '</div><div id="sbsArchBody"></div>' + "" + "</section>" + s;
    grid.innerHTML = s;
    if (specs.length) {
      var drawArch = function () {
        var b = document.getElementById("sbsArchBody"), h = "";
        if (archView === "system") h = specs.map(function (sp, i) { return '<figure class="rb-sbs-afig"><figcaption>' + capName(i) + ' <span class="sb-tag rb-arch-pchip">' + esc(RB.arch.vtext(sp.summary && sp.summary.pattern)) + '</span></figcaption><div class="sb-scroll-x rb-arch-scroll">' + RB.arch.systemAuto(sp, { uid: "sbs" + i }) + "</div></figure>"; }).join("");
        else h = '<p class="sb-caption">Each model drawn layer by layer, input at the bottom, key sizes called out on the right.</p>' + specs.map(function (sp, i) { return '<figure class="rb-sbs-afig"><figcaption>' + capName(i) + "</figcaption>" + (sp.blueprint ? '<div class="sb-scroll-x rb-bp-scroll">' + RB.arch.blueprint(sp) + "</div>" : '<p class="sb-empty">No blueprint yet.</p>') + "</figure>"; }).join("");
        h += '<p class="rb-h5">Architecture rows</p>' + RB.arch.summary(specs);
        /* methods without a diagram get an explicit card in the same list, so nothing silently disappears */
        h = h.replace(/<p class="rb-h5">Architecture rows<\/p>/, missing.map(function (m) { var why = RB.arch.none(m.id); return '<figure class="rb-sbs-afig rb-sbs-nodiag"><figcaption>' + esc(m.name) + '</figcaption><p class="sb-caption">' + (why ? "No network to draw. " + esc(why) : "No diagram: this is a fact-card method and its paper gives no layer-level detail we could verify.") + "</p></figure>"; }).join("") + '<p class="rb-h5">Architecture rows</p>');
        b.innerHTML = h;
      };
      RB.bindSeg(grid, "sbsArchView", function (v) { archView = v; drawArch(); });
      drawArch();
    }
  }

  /* architecture families for the master-table filter, from each spec's pattern */
  var ARCHFAM = [["vla", "VLA"], ["wam", "World action model"], ["wm", "World model"], ["head", "Policy head"], ["grasp", "Grasp"], ["enc", "Encoder / latent action"], ["ctl", "Control / RL"], ["touch", "Touch / force"], ["phys", "Physics"], ["trust", "Verifier / safety"], ["plan", "Planner"]];
  function archFam(mid) {
    var sp = RB.arch && RB.arch.forMethod(mid); if (!sp) return "none";
    var p = RB.arch.vtext(sp.summary && sp.summary.pattern).toLowerCase(), f = "";
    var rules = [["trust", /verifier|safety|detector/], ["touch", /touch|force/], ["wam", /wam|video-action|joint dit|\bmot\b|foresight/], ["vla", /vla|readout|cross-embodiment|universal-action/],
      ["wm", /world.model|rssm|jepa|world foundation|v-m-c/], ["grasp", /grasp/], ["head", /u-net|diffusion transformer|cvae|diffusion policy|tokenizer|vq/], ["enc", /encoder|latent-action|representation|servo/],
      ["phys", /physics|ode\b|neural ode/], ["ctl", /actor|teacher|q-network|mpc|residual policy|tracking|whole-body|policy/], ["plan", /planner|llm|transporter/]];
    for (var i = 0; i < rules.length; i++) if (rules[i][1].test(p)) { f = rules[i][0]; break; }
    return f || "other";
  }

  /* ---------- method map: every method as a dot, rows = topics, x = year ---------- */
  function atlas(host, tbl, ms) {
    var box = document.getElementById("mtAtlas"), card = document.getElementById("mtCard");
    var topics = RB.topicOrder, yrs = ms.map(function (m) { return +m.year || 0; }).filter(Boolean), y0 = Math.min.apply(null, yrs), y1 = Math.max.apply(null, yrs);
    var LW = 200, RH = 28, TOP = 28, D = 7, LINES = 3, H = TOP + topics.length * RH + 8;
    var cells = {}; ms.forEach(function (m) { var t = String(m.topic || "").toLowerCase(), y = +m.year || 0; if (!RB.topics[t] || !y) return; var k = t + "|" + y; (cells[k] = cells[k] || []).push(m); });
    /* each year column is as wide as its busiest cell needs (up to 3 lines of dots), so dense recent years get room and sparse early years stay narrow */
    var XW = {}, XS = {}, x = LW;
    for (var yr = y0; yr <= y1; yr++) { var mx = 0; topics.forEach(function (tid) { mx = Math.max(mx, (cells[tid + "|" + yr] || []).length); }); XW[yr] = Math.max(30, Math.ceil(mx / LINES) * D + 10); XS[yr] = x; x += XW[yr]; }
    var W = x + 12;
    var o = '<svg class="rb-atlas-svg" viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Map of ' + ms.length + ' methods by topic and year">';
    for (var y = y0; y <= y1; y++) { var gx = XS[y]; o += '<line class="rb-atlas-grid" x1="' + gx + '" x2="' + gx + '" y1="' + (TOP - 6) + '" y2="' + (H - 4) + '"/>' + (XW[y] >= 30 && ((y - y0) % 2 === 0 || y >= y1 - 4) ? '<text class="rb-atlas-yr" x="' + (gx + XW[y] / 2) + '" y="14" text-anchor="middle">' + (XW[y] < 40 ? "’" + String(y).slice(2) : y) + "</text>" : ""); }
    var part = "";
    topics.forEach(function (tid, r) {
      var t = RB.topics[tid], cy = TOP + r * RH + RH / 2;
      if (t.part !== part) { part = t.part; if (r) o += '<line class="rb-atlas-part" x1="0" x2="' + W + '" y1="' + (cy - RH / 2) + '" y2="' + (cy - RH / 2) + '"/>'; }
      o += '<a href="#explorer/' + tid + '"><text class="rb-atlas-tl" x="4" y="' + (cy + 4) + '">' + t.num + " " + esc(t.short.length > 26 ? t.short.slice(0, 25) + "…" : t.short) + "</text></a>";
      for (var yy = y0; yy <= y1; yy++) {
        var list = cells[tid + "|" + yy]; if (!list) continue;
        list.sort(function (a, b) { return (a.tier || 3) - (b.tier || 3); });
        var per = Math.max(1, Math.floor((XW[yy] - 6) / D)), lines = Math.ceil(list.length / per), x0 = XS[yy] + 4;
        list.forEach(function (m, i) {
          var col = i % per, row = Math.floor(i / per), cx = x0 + col * D + D / 2, cyy = cy + (row - (lines - 1) / 2) * D;
          var diag = RB.arch && RB.arch.forMethod(m.id), big = m.tier === 1;
          o += '<circle class="rb-atlas-dot' + (diag ? " is-diag" : "") + '" data-mid="' + m.id + '" cx="' + cx + '" cy="' + cyy + '" r="' + (big ? 3.4 : 2.4) + '"><title>' + esc(m.name + " (" + m.year + ")") + "</title></circle>";
        });
      }
    });
    box.innerHTML = '<div class="sb-scroll-x">' + o + "</svg></div>";
    var svgEl = box.querySelector("svg");
    function show(mid) {
      var m = RB.M[mid]; if (!m) return; var d = RB.arch && RB.arch.forMethod(mid), tid = String(m.topic || "").toLowerCase(), t = RB.topics[tid] || {};
      RB.$$(".rb-atlas-dot.is-pin", svgEl).forEach(function (c) { c.classList.remove("is-pin"); }); var dot = svgEl.querySelector('[data-mid="' + mid + '"]'); if (dot) dot.classList.add("is-pin");
      card.innerHTML = '<div class="sb-panel"><div class="sb-panel-body"><p class="sb-eyebrow">' + (t.num ? "Topic " + t.num + " · " + esc(t.short) : "") + (m.year ? " · " + m.year : "") + '</p><h4 class="rb-h4">' + esc(m.name) + "</h4>" + (m.title ? '<p class="sb-caption">' + esc(m.title) + "</p>" : "") + "<p>" + esc(m.idea || m.problem || "") + '</p><div class="sb-btn-row"><button class="sb-btn sb-btn--primary" type="button" data-add="' + m.id + '" aria-label="Add ' + esc(m.name) + ' to compare">Add to compare</button>' + (t.num ? '<a class="sb-btn sb-btn--ghost" href="#explorer/' + (d && RB.arch.topicOf ? RB.arch.topicOf(d) || tid : tid) + (d ? "/arch" : "") + '"' + (d ? ' data-arch-open="' + d.id + '"' : "") + ">" + (d ? "Architecture" : "Topic " + t.num) + " →</a>" : "") + RB.arxivLink(m) + "</div></div></div>";
      RB.annotateRefs(card);
    }
    svgEl.addEventListener("click", function (e) { var c = e.target.closest(".rb-atlas-dot"); if (c) show(c.getAttribute("data-mid")); });
    /* the filters and search drive the map: dots of rows the table hides are dimmed */
    function sync() {
      var on = {}; RB.$$("tbody tr[data-mid]", tbl).forEach(function (r) { if (!r.hidden && r.style.display !== "none") on[r.getAttribute("data-mid")] = 1; });
      var n = 0; RB.$$(".rb-atlas-dot", svgEl).forEach(function (c) { var v = !!on[c.getAttribute("data-mid")]; c.classList.toggle("is-off", !v); if (v) n++; });
      svgEl.setAttribute("aria-label", "Map of " + n + " matching methods by topic and year");
    }
    host.addEventListener("click", function () { setTimeout(sync, 30); });
    host.addEventListener("input", function () { setTimeout(sync, 60); });
    RB.bindSeg(host, "mtView", function (v) { document.getElementById("mtTableWrap").hidden = v !== "table"; box.hidden = card.hidden = v !== "map"; });
    setTimeout(sync, 50);
    show("pi0");
  }

  /* ---------- master table ---------- */
  function table() {
    var host = document.getElementById("cmp-table"), ms = RB.METHODS.filter(function (m) { return !m.alias_of; });
    var parts = RB.PARTS;
    host.innerHTML = '<section class="sb-sec" id="cmp-table-sec">' + RB.secHead({ level: "h2", title: "All methods", lede: "Every method paper the surveys cite: on a map by topic and year, or as a table. The filters and search drive both views." }) +
      '<div class="sb-toolbar sb-toolbar-row"><input class="sb-input" type="search" data-search-for="masterTable" placeholder="Search methods, papers, ideas" aria-label="Search the master table"><span class="sb-count" data-count-for="masterTable"></span><button class="sb-btn sb-btn--ghost" type="button" data-clear-for="masterTable" hidden>Clear filters</button></div>' +
      '<div class="sb-chips" data-filter-for="masterTable" role="group" aria-label="Filters"><span class="sb-caption">Part</span>' + parts.map(function (p) { return '<button type="button" class="sb-tag" data-key="part" data-val="' + p.id + '" aria-pressed="false">' + p.id + " · " + esc(p.name.split(":")[0]) + "</button>"; }).join("") + '<span class="sb-caption">Coverage</span><button type="button" class="sb-tag" data-key="cov" data-val="t1" aria-pressed="false">Read in full</button><button type="button" class="sb-tag" data-key="cov" data-val="t2" aria-pressed="false">Fact card</button><button type="button" class="sb-tag" data-key="cov" data-val="survey" aria-pressed="false">Survey only</button><span class="sb-caption">Weights</span><button type="button" class="sb-tag" data-key="open" data-val="yes" aria-pressed="false">Open</button><span class="sb-caption">Architecture</span><button type="button" class="sb-tag" data-key="diag" data-val="yes" aria-pressed="false">Has a diagram</button>' + ARCHFAM.map(function (f) { return '<button type="button" class="sb-tag" data-key="arch" data-val="' + f[0] + '" aria-pressed="false">' + f[1] + "</button>"; }).join("") + "</div>" +
      '<div class="rb-atlas-bar">' + RB.seg({ id: "mtView", label: "View", value: "map", options: [{ value: "map", label: "Map" }, { value: "table", label: "Table" }] }) + '<ul class="sb-legend"><li class="sb-key"><span class="rb-atlas-sw is-diag"></span>Has an architecture diagram</li><li class="sb-key"><span class="rb-atlas-sw"></span>No diagram</li><li class="sb-key"><span class="rb-atlas-sw is-big"></span>Larger: read in full</li></ul></div>' +
      '<div id="mtAtlas" class="rb-atlas"></div><div id="mtCard" class="rb-atlas-card" aria-live="polite"></div>' +
      '<div class="sb-scroll-x" id="mtTableWrap" hidden><table class="sb-table sb-table--sticky-col rb-master" id="masterTable"><thead><tr><th scope="col" data-sort="text">Method</th><th scope="col" data-sort="num">Year</th><th scope="col" data-sort="text">Topic</th><th scope="col">Key idea</th><th scope="col">Action output</th><th scope="col" data-sort="text">Coverage</th><th scope="col">Open</th><th scope="col"><span class="sb-sr">Actions</span></th></tr></thead><tbody>' +
      ms.map(function (m) {
        var t = RB.topics[(m.topic || "").toLowerCase()] || {}, cov = m.coverage !== "primary" ? "survey" : m.tier === 1 ? "t1" : "t2";
        return '<tr data-mid="' + m.id + '" data-part="' + (t.part || "") + '" data-cov="' + cov + '" data-open="' + (m.open === true ? "yes" : "no") + '" data-arch="' + archFam(m.id) + '" data-diag="' + (RB.arch && RB.arch.forMethod(m.id) ? "yes" : "no") + '"><th scope="row"><b>' + esc(m.name) + "</b></th><td data-v=\"" + (m.year || 0) + '">' + (m.year || "–") + '</td><td><a href="#explorer/' + (m.topic || "").toLowerCase() + '">' + (t.num || "") + " " + esc(t.short || "") + "</a></td><td>" + esc((m.idea || "").slice(0, 220)) + "</td><td>" + esc((m.action || m.outputs || "–").slice(0, 120)) + "</td><td>" + (cov === "t1" ? "Read in full" : cov === "t2" ? "Fact card" : "Survey only") + "</td><td>" + (m.open === true ? '● <span class="sb-sr">yes</span>' : '○ <span class="sb-sr">no or unknown</span>') + '</td><td><button class="sb-btn sb-btn--ghost rb-add" type="button" data-add="' + m.id + '" aria-label="Add ' + esc(m.name) + ' to side by side">Add to compare</button></td></tr>';
      }).join("") + "</tbody></table></div></section>" +
      '<section class="sb-sec" id="cmp-results-sec">' + RB.secHead({ level: "h2", title: "Reported results", lede: "Benchmark numbers as each paper reports them, collected by the world-model survey. Conditions are not matched across papers." }) + '<div id="resultsHost"></div></section>';
    var tbl = document.getElementById("masterTable"), tapi = StudyBench.table(tbl);
    atlas(host, tbl, ms);
    host.addEventListener("click", function (e) { var b = e.target.closest("[data-add]"); if (b) { add(b.getAttribute("data-add")); b.textContent = "Added ✓"; } });
    /* faceted counts */
    var rows = RB.$$("tbody tr[data-part]", tbl), fb = host.querySelector('[data-filter-for="masterTable"]');
    function facets() {
      var groups = ["part", "cov", "open", "diag", "arch"].map(function (k) { var chips = RB.$$('button[data-key="' + k + '"]', fb); return { chips: chips, match: function (r, v) { return r.getAttribute("data-" + k) === v; }, selected: function () { var on = chips.filter(function (c) { return c.getAttribute("aria-pressed") === "true"; })[0]; return on ? on.getAttribute("data-val") : "all"; } }; });
      StudyBench.facetCounts(rows, groups);
    }
    fb.addEventListener("click", function () { setTimeout(facets, 0); }); facets();
    results();
  }

  function results() {
    var R = RB.RESULTS, host = document.getElementById("resultsHost");
    if (!R || !R.suites) { host.innerHTML = '<div class="sb-empty"><p>The results board is being compiled.</p></div>'; return; }
    host.innerHTML = '<div class="sb-toolbar">' + RB.seg({ id: "resSuite", label: "Benchmark", value: R.suites[0].id, options: R.suites.map(function (s) { return { value: s.id, label: s.short }; }) }) + '<span class="sb-prov">As reported; not matched conditions</span></div><div class="sb-panel"><div class="sb-panel-body" id="resBody"></div></div>';
    function draw(id) {
      var s = R.suites.filter(function (x) { return x.id === id; })[0], rows = s.rows.slice().sort(function (a, b) { return b.value - a.value; });
      var W = 720, bh = 22, H = rows.length * (bh + 6) + 30, max = s.max || Math.max.apply(null, rows.map(function (r) { return r.value; }));
      var svg = '<svg viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="' + esc(s.name) + ' results, sorted">' + rows.map(function (r, i) { var y = 8 + i * (bh + 6), w = (W - 260) * r.value / max; return '<text x="170" y="' + (y + 15) + '" text-anchor="end" class="rb-bar-l">' + esc(r.method) + '</text><rect x="178" y="' + y + '" width="' + w.toFixed(1) + '" height="' + bh + '" rx="3" class="rb-bar" data-family="' + esc(r.family || "") + '"/><text x="' + (184 + w).toFixed(1) + '" y="' + (y + 15) + '" class="rb-bar-v">' + r.value + "</text>"; }).join("") + "</svg>";
      document.getElementById("resBody").innerHTML = '<p class="sb-eyebrow">' + esc(s.name) + " · " + esc(s.metric) + '</p><figure class="sb-fig"><div class="sb-scroll-x">' + svg + '</div><figcaption class="sb-caption">' + esc(s.caption || "") + ' Source: <span class="sb-ref">' + esc(s.source) + '</span></figcaption><details class="sb-datatable"><summary>Show data table</summary><div class="sb-scroll-x"><table class="sb-table sb-table--compact"><thead><tr><th scope="col">Method</th><th scope="col">' + esc(s.metric) + '</th><th scope="col">Family</th></tr></thead><tbody>' + rows.map(function (r) { return "<tr><td>" + esc(r.method) + "</td><td>" + r.value + "</td><td>" + esc(r.family || "") + "</td></tr>"; }).join("") + "</tbody></table></div></details></figure>";
    }
    StudyBench.segmented(document.getElementById("resSuite"), function (_v, b) { draw(b.value); });
    draw(R.suites[0].id);
  }

  function decide() {
    var host = document.getElementById("cmp-decide"), D = RB.DECIDE || [];
    if (!D.length) { host.innerHTML = '<div class="sb-empty"><p>The decision guides are being written.</p></div>'; return; }
    host.innerHTML = '<section class="sb-sec" id="cmp-decide-sec">' + RB.secHead({ level: "h2", title: "Which method should I use?", lede: "Pick a question family, then answer questions about your problem. Every result links to its topic." }) + '<div class="sb-toolbar">' + RB.seg({ id: "decWhich", label: "Guide", value: D[0].id, options: D.map(function (d) { return { value: d.id, label: d.short }; }) }) + '</div><div class="sb-panel"><div class="sb-panel-body"><p class="sb-caption" id="decLede"></p><div id="decHost"></div></div></div></section>';
    function draw(id) { var d = D.filter(function (x) { return x.id === id; })[0]; document.getElementById("decLede").textContent = d.lede || ""; var h2 = document.getElementById("decHost"); h2.innerHTML = ""; h2.className = ""; StudyBench.decide(h2, d.tree); }
    StudyBench.segmented(document.getElementById("decWhich"), function (_v, b) { draw(b.value); });
    draw(D[0].id);
  }

  function quiz() {
    var Q = RB.CMP_QUIZ || [], host = document.getElementById("cmpQuiz");
    host.innerHTML = '<div class="sb-panel"><div class="sb-panel-body rb-quiz">' + Q.map(function (q, qi) { return '<div class="sb-q"><p class="sb-q-text"><span class="sb-q-n">' + (qi + 1) + "</span>" + q.q + '</p><div class="sb-opts">' + q.options.map(function (o, oi) { return '<button type="button" class="sb-opt"' + (oi === q.correct ? ' data-correct="true"' : "") + '><span class="sb-opt-mark" aria-hidden="true"></span><span>' + o + "</span></button>"; }).join("") + '</div><p class="sb-q-why" hidden>' + q.why + "</p></div>"; }).join("") + '<div class="sb-btn-row"><span class="sb-status" data-quiz-score aria-live="polite"></span><button class="sb-btn sb-btn--ghost" type="button" data-quiz-reset>Reset quiz</button></div></div></div>';
    StudyBench.quiz(host);
  }

  RB.pages.compare = {
    init: function () {
      var n = RB.METHODS.filter(function (m) { return !m.alias_of; }).length; document.getElementById("cmpEyebrow").textContent = n + " methods · three tools";
      sbs(); table(); decide(); quiz();
      if (!picked.length) { picked = ["act", "diffusion-policy", "pi0"].filter(function (x) { return RB.M[x]; }); }
      drawSbs();
      RB.hintFirstDemo("compare");
    },
    show: function (o) {
      /* a link with ids (from Evolution, topics, the master table) shows exactly those methods */
      if (o.tab === "sbs" && o.rest[0]) { var ids = o.rest[0].split(",").filter(function (id) { return RB.M[id]; }); if (ids.length) { picked = ids.filter(function (id, i) { return ids.indexOf(id) === i; }); drawSbs(); } }
    }
  };
  RB.howto["cmp-sbs"] = function () { RB.go("#compare/sbs"); };
  RB.howto["cmp-table"] = function () { RB.go("#compare/table"); };
  RB.howto["cmp-decide"] = function () { RB.go("#compare/decide"); };
})();
