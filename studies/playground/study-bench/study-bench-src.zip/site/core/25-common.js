/* ===== Shared wiring: key-term notes, demo launchers, search, theme, return navigation ===== */
(function () {
  "use strict";
  var RB = window.RB;
  var dict = null;

  RB.termDict = function () {
    if (dict) return dict;
    dict = {};
    Object.keys(RB.terms).forEach(function (k) {
      var t = RB.terms[k];
      dict[k] = { name: t.name, alias: t.aliases || [], sym: t.symTex ? RB.itex(t.symTex) : (t.sym || ""), def: t.def, note: t.note, ref: t.ref, href: "#glossary/" + k, showMe: !!t.lab };
    });
    return dict;
  };
  /* Link the first use of each glossary term per section, inside a freshly rendered block. */
  RB.linkTerms = function (root) {
    try { return StudyBench.autolink(root, RB.termDict(), { noCards: true }); } catch (e) { RB.warn("autolink: " + e.message); }
  };

  /* Demo launchers anywhere on the page: RB.demos[id] is a function returning StudyBench.demo steps. */
  var running = null;
  RB.runDemo = function (id, mode) {
    var f = RB.demos[id]; if (!f) { RB.warn("no demo registered: " + id); return; }
    var steps; try { steps = f(); } catch (e) { RB.warn("demo " + id + " failed to build: " + e.message); return; }
    if (!steps || !steps.length) return;
    if (running) running.stop();
    running = StudyBench.demo(steps, { title: "Demo" });
    running.start(mode || "watch");
    return running;
  };
  document.addEventListener("click", function (e) {
    var w = e.target.closest && e.target.closest("[data-demo-watch]"), g = e.target.closest && e.target.closest("[data-demo-guide]");
    if (w) RB.runDemo(w.getAttribute("data-demo-watch"), "watch");
    if (g) RB.runDemo(g.getAttribute("data-demo-guide"), "guide");
  });
  /* The first demo launcher on each page gets the "New here?" hint. */
  RB.hintFirstDemo = function (page) {
    var v = document.getElementById("view-" + page); if (!v) return;
    var l = v.querySelector(".sb-demo-launch"); if (l && !l.querySelector(".sb-demo-hint")) StudyBench.demoHint(l, RB.SITE);
  };

  /* ---------- search over topics, methods, terms, symbols, stations ---------- */
  RB.buildSearch = function () {
    var idx = [];
    RB.topicOrder.forEach(function (k) { var t = RB.topics[k]; idx.push({ kind: "Topic", label: t.num + " " + (t.title || t.short), sub: "Part " + t.part + " · " + (t.sources || ""), href: "#explorer/" + k, alias: t.short }); });
    (RB.METHODS || []).forEach(function (m) { if (m.alias_of) return; idx.push({ kind: "Method", label: m.name, sub: (m.year || "") + " · " + (m.title || "").slice(0, 70), href: "#compare/sbs/" + m.id, alias: (m.arxiv || "") + " " + (m.title || "") }); });
    Object.keys(RB.terms).forEach(function (k) { var t = RB.terms[k]; idx.push({ kind: "Term", label: t.name, sub: (t.def || "").replace(/<[^>]+>/g, "").slice(0, 80), href: "#glossary/" + k, alias: (t.aliases || []).join(" ") }); });
    RB.symbolOrder.forEach(function (k) { var s = RB.symbols[k]; idx.push({ kind: "Symbol", label: s.glyph + "  " + s.meaning, sub: s.kind, href: "#notation/" + k, alias: s.read || k }); });
    RB.stationOrder.forEach(function (k) { var s = RB.stations[k] || {}; idx.push({ kind: "Lab", label: s.name || k, sub: "Interactive Lab", href: "#lab/" + k }); });
    (RB.PAPERS || []).forEach(function (p) { if (!p.unused) idx.push({ kind: "Survey", label: p.id + " " + p.short, sub: p.title, href: "#reference/papers/" + p.id, alias: p.arxiv }); });
    (RB.TLDR || []).forEach(function (s) { idx.push({ kind: "TL;DR", label: s.n + " " + s.title, sub: "TL;DR · " + (s.part === "R" ? "Recap" : "Part " + s.part), href: "#tldr/" + s.id, alias: String(s.sum || "").replace(/<[^>]+>/g, "") }); });
    StudyBench.search(idx);
  };

  RB.boot = function () {
    document.body.classList.add("sb-root");
    if (RB.startTextPass) setTimeout(RB.startTextPass, 0);
    StudyBench.themeToggle(document.getElementById("themeBtn"));
    RB.initProgress();
    try { StudyBench.terms(document.body, RB.termDict(), { onShow: function (key) { var h = RB.labTermHref && RB.labTermHref(key); RB.go(h || "#glossary/" + key); } }); } catch (e) { RB.warn("terms: " + e.message); }
    RB.buildSearch();
    if (StudyBench.returnNav) StudyBench.returnNav({});
    function termHref(name) { var n = String(name || "").toLowerCase().trim(); var hit = Object.keys(RB.terms).filter(function (k) { var t = RB.terms[k]; return [t.name].concat(t.aliases || []).some(function (x) { return String(x).toLowerCase() === n; }); })[0]; return hit ? "#glossary/" + hit : null; }
    function wire() { try { StudyBench.cardLinks(document, { termHref: termHref }); StudyBench.anatomyJump(document); } catch (e) { } }
    setTimeout(wire, 1200);
    /* PageGuide buttons */
    document.addEventListener("click", function (e) {
      var b = e.target.closest && e.target.closest("[data-howto]"); if (!b) return;
      var k = b.getAttribute("data-howto"); if (RB.howto[k]) RB.howto[k](b);
    });
    RB.route();
    if (RB.warnings.length && window.console) console.info("[RB] " + RB.warnings.length + " warnings — see RB.warnings");
  };

  /* PageGuide actions (pages add their own) */
  RB.howto = {
    continue: function () { RB.go("#explorer/" + RB.nextUp()); },
    "topic-demo": function () { var t = RB.currentTopic() || RB.nextUp(); var art = RB.renderTopic(t); var l = art.querySelector(".sb-demo-launch [data-demo-watch]"); if (l) { l.scrollIntoView({ block: "center" }); l.click(); } },
    "topic-check": function () { var t = RB.currentTopic() || RB.nextUp(); RB.go("#explorer/" + t + "/check"); },
    tour: function () { RB.startTour && RB.startTour(); },
    cards: function () { RB.go("#reference/cards"); }
  };
})();
