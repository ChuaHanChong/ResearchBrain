/* Architecture specs, topic b6 (in-context learning policies). Numbers from the paper and the official code; see sources. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ VINN */
  RB.arch.spec({
    id: "vinn", method: "vinn", topic: "b6", name: "VINN", year: 2021,
    figRef: "Pari et al. Fig. 2 · §III · §IV-C, G", prov: "",
    lede: "No policy network at all. A ResNet-50, fine-tuned with BYOL on the demonstration frames, embeds each image; the action is a softmin-weighted average of the actions of the k nearest demonstration frames.",
    sources: {
      p1: { kind: "paper", ref: "Pari et al. 2021, §III (approach) and Fig. 2", url: "https://arxiv.org/abs/2112.01511" },
      p2: { kind: "paper", ref: "Pari et al. 2021, §IV-C (training details)", url: "https://arxiv.org/abs/2112.01511" },
      p3: { kind: "paper", ref: "Pari et al. 2021, §IV-G, H and Fig. 6 (choice of k)", url: "https://arxiv.org/abs/2112.01511" },
      p4: { kind: "paper", ref: "He et al. 2016, Table 1 (ResNet-50)", url: "https://arxiv.org/abs/1512.03385" },
      c1: { kind: "code", repo: "jyopari/VINN", path: "representation_models/BYOL.py", commit: "23a756e", url: "https://github.com/jyopari/VINN/blob/23a756e/representation_models/BYOL.py" },
      c2: { kind: "code", repo: "jyopari/VINN", path: "stretch_code/remote_node/nearest.py", commit: "23a756e", url: "https://github.com/jyopari/VINN/blob/23a756e/stretch_code/remote_node/nearest.py" },
      c3: { kind: "code", repo: "jyopari/VINN", path: "README.md", commit: "23a756e", url: "https://github.com/jyopari/VINN/blob/23a756e/README.md" }
    },
    summary: {
      pattern: ["Visual representation encoder + k-NN action retrieval", "p1"],
      params: null,
      vision: ["ResNet-50 (ImageNet init), BYOL fine-tuned on demo frames; 224 × 224 → 2,048-d", "p2", "c1", "c2"],
      backbone: ["No policy network: locally weighted regression over demo embeddings", "p1"],
      head: ["Softmin-weighted average of the k nearest demo frames' actions", "p1", "c2"],
      output: ["Translation action; the door task adds a gripper state", "p1"],
      attention: null, cond: null,
      steps: ["One encoder pass and one nearest-neighbour search per control step", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["BYOL on the demo frames only (no action labels), 100 epochs, Adam 3e-4", "p2", "c1"]
    },
    blueprint: {
      headline: "VINN: embed, then copy your neighbours",
      note: "The only trained network is the encoder. Every demonstration frame is embedded once and stored with its action. At test time the query frame is embedded, compared with all stored embeddings, and the actions of the closest k are averaged with softmin weights.",
      towers: [
        { mod: "resnet", title: "ResNet-50", sub: "BYOL fine-tuned, fc removed",
          input: { label: "Camera frame 224 × 224", caption: "query frame, or each demo frame once" },
          rows: [
            { t: "conv", label: "Stem conv 7 × 7, stride 2", call: ["64 channels, then 3 × 3 max pool", "p4"] },
            { t: "block", n: "16", label: "Bottleneck", rows: [
              { t: "conv", label: "Conv 1 × 1 (reduce)" },
              { t: "conv", label: "Conv 3 × 3" },
              { t: "conv", label: "Conv 1 × 1 (expand)", call: ["3 + 4 + 6 + 3 blocks; 256 → 2,048 channels", "p4"],
                zoom: { k: "rows", title: "Four stages (ResNet-50)", rows: ["stage 1: 3 blocks, 256 ch", "stage 2: 4 blocks, 512 ch", "stage 3: 6 blocks, 1,024 ch", "stage 4: 3 blocks, 2,048 ch"] } },
              { t: "add", span: 3 } ] },
            { t: "pool", label: "Global average pool", call: ["2,048-d embedding e; final fc removed", "p2", "c2"],
              zoom: { k: "rows", title: "BYOL fine-tuning (no actions)", rows: ["two augmented views", "online: enc → proj → pred", "target: EMA copy", "loss: match the target"] } } ],
          output: { label: "embedding e" } },
        { mod: "knn", title: "k-NN regression", sub: "non-parametric, no weights", compact: true,
          input: { label: "e + stored demo pairs", caption: "(e⁽ⁱ⁾, a⁽ⁱ⁾) for every demo frame" },
          rows: [
            { t: "linear", label: "L2 distance to all demos", call: ["O(n) linear scan", "p3"] },
            { t: "pool", label: "Keep k nearest", call: ["k ≈ 10 (code: 5)", "p3", "c2"] },
            { t: "norm", label: "SoftMin weights", call: ["∝ exp(−distance)", "p1", "c2"] },
            { t: "linear", label: "Weighted sum of actions" } ],
          output: { label: "action â" } }
      ],
      links: [{ from: "resnet", to: "knn", toRow: "input", label: "query embedding" }]
    },
    modules: [
      { id: "resnet", role: "vision-enc", roleLabel: "BYOL encoder", name: "ResNet-50", sub: "BYOL · 2,048-d", col: 0, frozen: false, main: true, short: "ResNet-50",
        stack: { rows: [
          { t: "in", label: "frame 224 × 224 × 3", dims: "random crop, jitter, grayscale, blur in training", c: "data-1" },
          { t: "conv", label: "Stem 7 × 7, 64 ch, stride 2 · max pool" },
          { t: "block", label: "Bottleneck stages", n: "16", rows: [{ t: "conv", label: "1 × 1 → 3 × 3 → 1 × 1" }, { t: "add", span: 1 }] },
          { t: "pool", label: "Global average pool", dims: "→ 2,048" },
          { t: "out", label: "embedding e", dims: "fc = Identity", c: "data-1" } ],
          facts: [["Init", ["ImageNet, then BYOL on the task's own frames", "p2"]], ["Stages", ["3, 4, 6, 3 bottleneck blocks", "p4"]], ["Embedding", ["2,048-d (avgpool output)", "c1", "c2"]], ["BYOL epochs", ["100", "p2"]], ["Optimiser", ["Adam, lr 3e-4", "c1"]]] } },
      { id: "knn", role: "net", roleLabel: "k-NN regression", name: "Nearest neighbours", sub: "softmin-weighted average", col: 1, frozen: true, short: "k-NN",
        note: "No weights: the demonstration set itself is the policy.",
        stack: { rows: [
          { t: "in", label: "query e + demo set", dims: "(e⁽ⁱ⁾, a⁽ⁱ⁾)", c: "data-3" },
          { t: "linear", label: "‖e − e⁽ⁱ⁾‖₂ for every stored frame" },
          { t: "pool", label: "sort, keep the k closest" },
          { t: "norm", label: "softmax(−distance)" },
          { t: "out", label: "â = Σ wᵢ a⁽ⁱ⁾", c: "data-3" } ],
          facts: [["k", ["≈ 10 on validation MSE; no gain beyond 20", "p3"]], ["k in robot code", ["5", "c2"]], ["Weights", ["softmin of L2 distance", "p1", "c2"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "camera frame", n: "224 × 224", k: 3 },
      { to: "knn", mod: "action", label: "demo embeddings + actions", n: "every demo frame", k: 5 }
    ],
    outputs: [{ from: "knn", mod: "action", label: "action â", n: "translation (+ grip)", k: 2 }],
    links: [{ from: "resnet", to: "knn", kind: "feeds", label: "2,048-d query|L2 distance" }],
    callouts: [
      "Paper §IV-G finds <b>k ≈ 10</b> best on validation; the released Stretch robot script (nearest.py) sets <b>k = 5</b>.",
      "Door opening: actions come from structure-from-motion on the GoPro video of a reacher-grabber; a separate gripper classifier labels four gripper states."
    ]
  });

  /* ------------------------------------------------------------------ MOSAIC */
  RB.arch.spec({
    id: "mosaic", method: "mosaic", topic: "b6", name: "MOSAIC", year: 2021,
    figRef: "Mandi et al. Fig. 2 · §IV · App. D, Table III", prov: "",
    lede: "One-shot imitation: a ResNet-18 trunk encodes a demonstration video and the robot's own frames; stacked non-local attention lets each observation frame attend to the demo; a logistic-mixture head predicts the action. A temporal contrastive loss shapes the features.",
    sources: {
      p1: { kind: "paper", ref: "Mandi et al. 2022, §IV-A (architecture) and Fig. 2", url: "https://arxiv.org/abs/2110.13423" },
      p2: { kind: "paper", ref: "Mandi et al. 2022, §IV-B, C (contrastive and imitation losses)", url: "https://arxiv.org/abs/2110.13423" },
      p3: { kind: "paper", ref: "Mandi et al. 2022, App. D, Table III (hyperparameters)", url: "https://arxiv.org/abs/2110.13423" },
      p4: { kind: "paper", ref: "Mandi et al. 2022, §V (setup, ResNet-18 blocks)", url: "https://arxiv.org/abs/2110.13423" },
      c1: { kind: "code", repo: "rll-research/mosaic", path: "mosaic/models/mt_rep.py", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/mosaic/models/mt_rep.py" },
      c2: { kind: "code", repo: "rll-research/mosaic", path: "experiments/config.yaml", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/experiments/config.yaml" },
      c3: { kind: "code", repo: "rll-research/mosaic", path: "mosaic/models/rep_modules.py", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/mosaic/models/rep_modules.py" },
      c4: { kind: "code", repo: "rll-research/mosaic", path: "mosaic/models/basic_embedding.py", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/mosaic/models/basic_embedding.py" },
      c5: { kind: "code", repo: "rll-research/mosaic", path: "README.md", commit: "561814b", url: "https://github.com/rll-research/mosaic/blob/561814b/README.md" }
    },
    summary: {
      pattern: ["Demo-conditioned attention policy (one-shot imitation)", "p1"],
      params: null,
      vision: ["ResNet-18 up to stage 3, from scratch: 100 × 180 frame → 256 × 7 × 12", "p3", "p4", "c2", "c4"],
      backbone: ["Non-local attention: 2 layers (3 multi-task), 4 heads, 1 × 1 × 1 conv Q, K, V", "p1", "p3", "c2"],
      head: ["Linear embed → action MLP → discretized logistic mixture", "p1", "c1"],
      output: ["One 8-d action per observation frame", "p1", "c2"],
      attention: ["Each observation frame attends to all 4 demo frames and to itself", "p1", "c1"],
      cond: ["A video demo of the same task variation, shot with a different arm (Sawyer)", "p1"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["BC + inverse dynamics + temporal contrastive, weights 1; Adam 5e-4, batch 30", "p2", "p3", "c2"]
    },
    blueprint: {
      headline: "MOSAIC: attend to the demo, then act",
      note: "Demo frames and observation frames share one conv trunk. Inside each attention layer, every observation frame queries the demo's keys and values together with its own. The attended observation features are flattened, embedded to 40 dimensions and decoded to an action, with the demo's mean embedding appended.",
      towers: [
        { mod: "trunk", title: "ResNet-18 trunk", sub: "stages 1–3, from scratch", compact: true,
          input: { label: "Frame 100 × 180", caption: "4 demo + 7 obs frames (1 at test)" },
          rows: [
            { t: "conv", label: "Stem conv 7 × 7 + max pool" },
            { t: "block", n: "6", label: "Basic block", rows: [
              { t: "conv", label: "Conv 3 × 3" },
              { t: "conv", label: "Conv 3 × 3", call: ["2 blocks per stage: 64, 128, 256 ch", "p4", "c4"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "256 × 7 × 12 per frame" } },
        { mod: "attn", title: "Demo–obs attention", sub: "non-local blocks on 3-D feature maps",
          input: { label: "Feature maps, all frames", caption: "[demo T = 4 | obs T] × 7 × 12" },
          rows: [
            { t: "embed", label: "+ sinusoidal position enc.", call: ["over time and space, 256 channels", "p1", "c1"] },
            { t: "block", n: "2", rows: [
              { t: "attn", label: "Demo self-attention", call: ["causal in time; output unused in code", "c1"] },
              { id: "oatt", t: "attn", label: "Obs attends [demo ‖ self]", call: ["4 heads, width 128, temperature 16", "p3", "c2"], zoom: { k: "heads", q: 4, kv: 4, hd: 32, title: "Attention heads (obs)" } },
              { t: "linear", label: "1×1×1 conv out, ReLU" },
              { t: "add", span: 2 },
              { t: "norm", label: "BatchNorm3d (shared)" } ] } ],
          output: { label: "attended obs + demo features" } },
        { mod: "head", title: "Embed + action head", sub: "shared by BC and inverse model", compact: true,
          input: { label: "Flattened features", caption: "256 · 7 · 12 per frame" },
          rows: [
            { id: "emb", t: "mlp", label: "Linear embed + L2 norm", call: ["21,504 → 256 → 40", "c1", "c2"],
              zoom: { k: "rows", title: "Temporal contrastive (training)", rows: ["augmented view → online", "EMA target: a nearby frame", "projector f, predictor g", "InfoNCE with bilinear W"] } },
            { t: "pool", label: "Mean over demo frames", call: ["demo embedding, 40-d", "c1", "c2"] },
            { t: "mlp", label: "Action MLP", call: ["40 → 128 → 64, ReLU", "c2"],
              zoom: { k: "rows", title: "Inverse model (training)", rows: ["[eₜ ‖ eₜ₊₁] → MLP → 64", "‖ demo mean, L2 norm", "same logistic head", "predicts aₜ from two frames"] } },
            { t: "linear", label: "‖ demo mean, L2 norm" },
            { t: "linear", label: "Logistic mixture head", call: ["μ, s, π for each of 8 action dims", "c1", "c2"] } ],
          output: { label: "aₜ ∼ discretized logistic mixture" } }
      ],
      links: [
        { from: "attn", to: "head", toRow: "input", label: "attended features" },
        { from: "trunk", to: "attn", toRow: "input", label: "feature maps" }
      ]
    },
    modules: [
      { id: "trunk", role: "vision-enc", name: "ResNet-18 (stage 1–3)", sub: "256 × 7 × 12", col: 0, frozen: false, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "frame 100 × 180 × 3", dims: "demo and obs frames alike", c: "data-1" },
          { t: "conv", label: "Stem 7 × 7 + max pool" },
          { t: "block", label: "Basic residual block", n: "6", rows: [{ t: "conv", label: "3 × 3 → 3 × 3" }, { t: "add", span: 1 }] },
          { t: "out", label: "256-channel map, 7 × 12", dims: "layer4, pool and fc dropped", c: "data-1" } ],
          facts: [["Blocks kept", ["first three residual stages", "p4", "c4"]], ["Channels", ["256", "c1"]], ["Init", ["from scratch (pretrained: False)", "c2"]], ["Input", ["100 × 180 × 3", "p3", "c2"]]] } },
      { id: "attn", role: "net", roleLabel: "Demo–obs attention", name: "Non-local attention", sub: "2 × · 4 heads · ff 128", col: 1, frozen: false, main: true, short: "Attention",
        stack: { rows: [
          { t: "in", label: "[demo | obs] features + sinusoid PE", dims: "B × 256 × T × 7 × 12", c: "data-1" },
          { t: "block", label: "Attention layer", n: "2", rows: [
            { t: "attn", label: "Demo: causal self-attention over T·H·W", note: "In the released code its output is computed but not passed on." },
            { t: "attn", label: "Obs: queries own H·W, keys demo T·H·W ‖ own" },
            { t: "linear", label: "1×1×1 conv 128 → 256, ReLU, dropout" },
            { t: "add", span: 2 },
            { t: "norm", label: "BatchNorm3d over all frames" } ] },
          { t: "out", label: "attended features", dims: "same shape", c: "data-1" } ],
          facts: [["Layers", ["2 single-task, 3 multi-task", "p3"]], ["Heads", ["4", "c2"]], ["Q, K, V width", ["128 (1 × 1 × 1 conv)", "c2"]], ["Temperature", ["16 = √256", "p3", "c1"]], ["Dropout", ["0.2", "c2"]]] } },
      { id: "head", role: "action-head", name: "Embed + logistic head", sub: "21,504 → 40 → 8-d mix", col: 2, frozen: false, short: "Head",
        stack: { rows: [
          { t: "in", label: "attended frame features", dims: "256 · 7 · 12 = 21,504", c: "data-3" },
          { t: "mlp", label: "Linear 256, ReLU, Linear 40 · L2 norm" },
          { t: "mlp", label: "Action MLP 40 → 128 → 64" },
          { t: "linear", label: "‖ mean demo embedding · L2 norm" },
          { t: "linear", label: "μ, log s, logits per mixture" },
          { t: "out", label: "discretized logistic mixture", dims: "8-d action", c: "data-3" } ],
          facts: [["Embedding", ["40-d", "c2"]], ["Mixtures", ["4 in config.yaml; 2 in the README command", "c2", "c5"]], ["Action dim", ["8", "c2"]], ["Losses", ["BC NLL + inverse NLL + contrastive", "p2", "c2"]]] } }
    ],
    inputs: [
      { to: "trunk", mod: "vision", label: "demo video (Sawyer)", n: "4 frames", k: 4 },
      { to: "trunk", mod: "vision", label: "robot frames (Panda)", n: "1 at test", k: 2 }
    ],
    outputs: [{ from: "head", mod: "action", label: "action aₜ", n: "8-d", k: 3 }],
    links: [
      { from: "trunk", to: "attn", kind: "feeds", label: "256 × 7 × 12|per frame" },
      { from: "attn", to: "head", kind: "feeds", label: "flatten|21,504-d" }
    ],
    mask: { name: "Demo → observation", ref: "p1", axes: [{ label: "demo frames", short: "d", mod: "vision" }, { label: "observation frame", short: "o", mod: "action" }], m: ["10", "11"],
      note: "The demo never sees the robot's frames. Each observation frame sees the whole demo and only itself, not other observation frames." },
    callouts: [
      "Paper §IV-A: observation frames attend to the <b>attended</b> demo x_d^attn. In mt_rep.py the demo branch's attention output is never used: demo keys and values come from its un-attended input at every layer.",
      "Paper Table III: contrastive latent 512, action head 256 → 256. The released config and README use a 40-d embedding, action MLP 128 → 64 and a 128-d contrastive projector."
    ]
  });

  /* ------------------------------------------------------------------ ICRT */
  RB.arch.spec({
    id: "icrt", method: "icrt", topic: "b6", name: "ICRT", year: 2024,
    figRef: "Fu et al. Fig. 3 · §IV · App. D–F", prov: "",
    lede: "A small Llama-style causal transformer reads whole teleoperated trajectories as its prompt: one state token and one action token per step. After the prompt it continues the live trajectory, predicting the next 16 actions at every state token.",
    sources: {
      p1: { kind: "paper", ref: "Fu et al. 2024, §IV-B (model) and Fig. 3", url: "https://arxiv.org/abs/2408.15980" },
      p2: { kind: "paper", ref: "Fu et al. 2024, §IV-A (data formulation)", url: "https://arxiv.org/abs/2408.15980" },
      p3: { kind: "paper", ref: "Fu et al. 2024, App. D, Tables IX–X", url: "https://arxiv.org/abs/2408.15980" },
      p4: { kind: "paper", ref: "Fu et al. 2024, App. E–F, Table XI", url: "https://arxiv.org/abs/2408.15980" },
      p5: { kind: "paper", ref: "Dosovitskiy et al. 2021, Table 1 (ViT-Base)", url: "https://arxiv.org/abs/2010.11929" },
      c1: { kind: "code", repo: "Max-Fu/icrt", path: "icrt/models/policy/icrt.py", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/icrt/models/policy/icrt.py" },
      c2: { kind: "code", repo: "Max-Fu/icrt", path: "icrt/models/backbones/encoders.py", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/icrt/models/backbones/encoders.py" },
      c3: { kind: "code", repo: "Max-Fu/icrt", path: "config/model_config/custom_transformer.json", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/config/model_config/custom_transformer.json" },
      c4: { kind: "code", repo: "Max-Fu/icrt", path: "icrt/models/policy/llama.py", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/icrt/models/policy/llama.py" },
      c5: { kind: "code", repo: "Max-Fu/icrt", path: "icrt/util/args.py", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/icrt/util/args.py" },
      c6: { kind: "code", repo: "Max-Fu/icrt", path: "TRAIN.md", commit: "e0c9588", url: "https://github.com/Max-Fu/icrt/blob/e0c9588/TRAIN.md" }
    },
    summary: {
      pattern: ["In-context causal transformer (prompt = demo trajectories)", "p1"],
      params: null,
      vision: ["Frozen ViT-Base/16 (CrossMAE on ImageNet + OXE); 197 tokens per camera, 2 cameras", "p1", "c2", "c5"],
      backbone: ["Llama2-style causal transformer from scratch: 12 layers, width 768, 12 heads", "p1", "c3"],
      head: ["2-layer MLP at each state token: 768 → 128 → 16 × 10", "p1", "c1"],
      output: ["Next h = 16 delta end-effector actions, 10-d (xyz, 6-D rotation, gripper)", "p1", "p4"],
      attention: ["Causal over interleaved [s, a] tokens: prompt trajectories first, live one last", "p1", "c1"],
      cond: ["Task given only by the prompt: at least one full demo trajectory, no language", "p2"],
      steps: null,
      chunk: ["16 predicted; 10 executed with temporal ensembling", "p4"],
      rate: ["39.6 Hz inference with KV cache (Llama2-7B variant: 10.7 Hz)", "p4"],
      latency: null,
      train: ["Pretrain on 10k DROID trajectories, fine-tune on ICRT-MT; L1 loss only after the prompt", "p2", "p1", "p3"]
    },
    blueprint: {
      headline: "ICRT: demonstrations are the prompt",
      note: "Per step, attention pooling squeezes each camera's frozen ViT tokens plus the proprio embedding into half a state token; an MLP embeds the action. States and actions interleave into one causal sequence of up to 512 steps: a few prompt trajectories of the same task, then the live one.",
      towers: [
        { mod: "vit", title: "ViT-Base/16", sub: "CrossMAE weights, frozen", compact: true,
          input: { label: "Image patches 16 × 16", caption: "2 cameras, 224 × 224" },
          rows: [
            { t: "embed", label: "Patch embedding + CLS", call: ["196 patches + CLS, width 768", "p5", "c2"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention", call: ["12 heads, bidirectional", "p5"] },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden dimension of 3,072", "p5"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "197 tokens per camera" } },
        { mod: "tok", title: "Token projectors", sub: "one state + one action token per step", compact: true,
          input: { label: "Visual tokens + proprio", caption: "per camera, per timestep" },
          rows: [
            { t: "mlp", label: "Proprio MLP", call: ["10-d state → 768", "p4", "c1"] },
            { t: "norm", label: "LayerNorm (visual tokens)" },
            { t: "attn", label: "Attention pooling", call: ["8 heads, 1 query per camera", "c1", "c5"],
              zoom: { k: "rows", title: "Attention pooling (per camera)", rows: ["[197 visual ‖ proprio] → K, V", "learned latent query → Q", "attend, project → 384", "+ MLP (ratio 4), residual"] } },
            { t: "linear", label: "Concat 2 cameras", call: ["2 × 384 = 768 (fₛ)", "c1"] },
            { t: "mlp", label: "Action MLP", call: ["10-d → 768 (fₐ)", "c1"] } ],
          output: { label: "fₛ and fₐ per step" } },
        { mod: "llama", title: "Causal transformer", sub: "Llama2-Base, random init",
          input: { label: "[fₛ₁, fₐ₁, …, fₛₜ]", caption: "prompt trajectories, then the live one" },
          rows: [
            { t: "block", n: "12", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Causal self-attention", side: "RoPE", call: ["12 heads × 64; KV cache at test", "c3", "c4"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (SwiGLU)", call: ["Hidden dimension of 2,048", "c3", "c4"], zoom: { k: "glu", act: "SiLU", d: "768", ff: "2,048", title: "Feed forward (SwiGLU)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "mlp", label: "Action decoder MLP", call: ["768 → 128 → 16 × 10, at state tokens", "c1"] } ],
          output: { label: "next 16 actions; L1 loss after the prompt" } }
      ],
      links: [
        { from: "tok", to: "llama", toRow: "input", label: "state, action tokens" },
        { from: "vit", to: "tok", toRow: "input", label: "visual tokens" }
      ]
    },
    modules: [
      { id: "vit", role: "vision-enc", name: "ViT-Base/16", sub: "12 × 768 · CrossMAE", col: 0, frozen: true, short: "ViT-B",
        stack: { rows: [
          { t: "in", label: "image 224 × 224 × 3", dims: "2 cameras per step", c: "data-1" },
          { t: "embed", label: "Patch embed 16 × 16 + CLS", dims: "→ 197 × 768" },
          { t: "block", label: "ViT block", n: "12", rows: [{ t: "attn", label: "MHA · 12 heads" }, { t: "ffn", label: "MLP 768 → 3,072 → 768" }] },
          { t: "out", label: "all 197 tokens (no pooling)", dims: "global_pool = ''", c: "data-1" } ],
          facts: [["Pre-training", ["CrossMAE on ImageNet + Open X-Embodiment", "p1"]], ["Width / depth / heads", ["768 / 12 / 12", "p5"]], ["Training", ["frozen", "p1", "c5"]]] } },
      { id: "tok", role: "state-enc", roleLabel: "Token projectors", name: "Attention pooling", sub: "2 × 384 → 768", col: 1, frozen: false, short: "Pooling",
        stack: { rows: [
          { t: "in", label: "197 visual tokens × 2 cameras + proprio", c: "data-5" },
          { t: "mlp", label: "Proprio MLP 10 → 768" },
          { t: "attn", label: "Latent-query attention pool, one per camera", dims: "8 heads" },
          { t: "mlp", label: "MLP (ratio 4) + residual" },
          { t: "linear", label: "concat cameras → 768" },
          { t: "mlp", label: "Action MLP 10 → 768" },
          { t: "out", label: "state token fₛ, action token fₐ", c: "data-5" } ],
          facts: [["Pooling heads", ["8", "c5"]], ["MLP ratio", ["4", "c5"]], ["Per-camera adapter", ["yes, 768 / 2 = 384 each", "c1", "c5"]], ["Proprio / action", ["10-d each", "p4", "c1"]]] } },
      { id: "llama", role: "net", roleLabel: "Causal policy transformer", name: "Llama2-Base", sub: "12 × 768 · 12 heads", col: 2, frozen: false, main: true, short: "Llama2-Base",
        stack: { rows: [
          { t: "in", label: "fₛ₁ fₐ₁ … fₛₜ", dims: "≤ 512 steps = 1,024 tokens", c: "data-3" },
          { t: "block", label: "Llama block (pre-norm)", n: "12", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "causal MHA · 12 heads · RoPE" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "SwiGLU 768 → 2,048 → 768" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "mlp", label: "MLP 768 → 128 → 160 at state positions" },
          { t: "out", label: "16 future actions", dims: "temporal ensembling", c: "data-3" } ],
          facts: [["Width / depth / heads", ["768 / 12 / 12", "p1", "c3"]], ["FFN", ["SwiGLU, 2,048 (2/3 · 4d, multiple of 256)", "c3", "c4"]], ["Sequence", ["512 steps", "p3"]], ["Loss", ["L1 on actions after the prompt", "p1"]], ["Variant", ["Llama2-7B with LoRA rank 32", "p1"]]] } }
    ],
    inputs: [
      { to: "vit", mod: "vision", label: "2 camera images / step", n: "197 tokens each", k: 4 },
      { to: "tok", mod: "state", label: "proprio sₜ", n: "10-d", k: 1 },
      { to: "tok", mod: "action", label: "past actions", n: "10-d each", k: 2 },
      { to: "llama", mod: "other", label: "prompt: demo trajectories", n: "same task", k: 5 }
    ],
    outputs: [{ from: "llama", mod: "action", label: "next actions", n: "16 × 10", k: 5 }],
    links: [
      { from: "vit", to: "tok", kind: "feeds", label: "197 tokens|per camera" },
      { from: "tok", to: "llama", kind: "prefix", label: "1 state + 1 action|token per step" }
    ],
    mask: { name: "Causal over trajectories", ref: "p1", axes: [{ label: "prompt trajectories", short: "P", mod: "other" }, { label: "live states", short: "s", mod: "state" }, { label: "live actions", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "Plain causal attention over the whole interleaved sequence; the prompt comes first, so every live step can read all of it." },
    callouts: [
      "Paper Table IX lists weight decay <b>0.05</b> for DROID pre-training; args.py defaults to <b>0.01</b> and the pre-training command in TRAIN.md does not override it.",
      "The Llama2-7B variant keeps the same tokenizers and trains with LoRA (rank 32): slightly better on poking, but 10.7 Hz instead of 39.6 Hz."
    ]
  });

  /* ------------------------------------------------------------------ Instant Policy */
  RB.arch.spec({
    id: "instant-policy", method: "instant-policy", topic: "b6", name: "Instant Policy", year: 2024,
    figRef: "Vosylius & Johns Figs. 2–3 · §3 · App. A, C, E", prov: "",
    lede: "Demonstrations, the current observation and noisy future actions become one heterogeneous graph of point-cloud and gripper nodes. Three small graph transformers pass information demo → current → actions; the predicted node flows are turned into SE(3) actions by DDIM steps and SVD.",
    sources: {
      p1: { kind: "paper", ref: "Vosylius & Johns 2025, §3.2 (graph representation) and Fig. 2", url: "https://arxiv.org/abs/2411.12633" },
      p2: { kind: "paper", ref: "Vosylius & Johns 2025, §3.3 (graph diffusion, Eqs. 2–5)", url: "https://arxiv.org/abs/2411.12633" },
      p3: { kind: "paper", ref: "Vosylius & Johns 2025, App. A (geometry encoder)", url: "https://arxiv.org/abs/2411.12633" },
      p4: { kind: "paper", ref: "Vosylius & Johns 2025, App. C (network architecture)", url: "https://arxiv.org/abs/2411.12633" },
      p5: { kind: "paper", ref: "Vosylius & Johns 2025, App. E (implementation details)", url: "https://arxiv.org/abs/2411.12633" },
      p6: { kind: "paper", ref: "Vosylius & Johns 2025, §4.1–4.2, Table 2, Fig. 6", url: "https://arxiv.org/abs/2411.12633" },
      c1: { kind: "code", repo: "vv19/instant_policy", path: "deploy.py", commit: "7228173", url: "https://github.com/vv19/instant_policy/blob/7228173/deploy.py" },
      c2: { kind: "code", repo: "vv19/instant_policy", path: "utils.py", commit: "7228173", url: "https://github.com/vv19/instant_policy/blob/7228173/utils.py" },
      c3: { kind: "code", repo: "vv19/instant_policy", path: "deploy_sim.py", commit: "7228173", url: "https://github.com/vv19/instant_policy/blob/7228173/deploy_sim.py" }
    },
    summary: {
      pattern: ["Graph diffusion policy (heterogeneous graph transformer)", "p2"],
      params: ["69M, 117M and 178M variants in the scaling study", "p6"],
      vision: ["Segmented point clouds, 2,048 points in the gripper frame → 16 nodes (frozen SA encoder, 512-d)", "p3", "p5", "c2"],
      backbone: ["Three graph transformers σ → φ → ψ, 2 layers each, width 1,024, 16 heads × 64", "p4"],
      head: ["2-layer GELU MLP on each action gripper node → 7-d", "p2", "p4"],
      output: ["Per-node flow (translation part + rotation part) and gripper; SVD → SE(3)", "p2"],
      attention: ["Graph attention along typed edges only (Eq. 3); cost linear in N and L", "p2"],
      cond: ["Context: N demos × L waypoints as local graphs, linked to the current gripper nodes", "p1"],
      steps: ["DDIM; 4 denoising steps in the released deployment scripts", "p6", "c1"],
      chunk: ["T = 8 future actions", "p6", "c3"],
      rate: null, latency: null,
      train: ["2.5M steps on procedurally generated ShapeNet pseudo-demos; AdamW 1e-5", "p5", "p6"]
    },
    blueprint: {
      headline: "Instant Policy: denoise a graph of actions",
      note: "Scene nodes come from a frozen point-cloud encoder; six gripper nodes mark the end-effector. σ updates each local graph, φ moves demo information into the current gripper nodes, ψ moves it to the gripper nodes of the imagined future poses. An MLP reads their flow, and SVD turns it into poses.",
      towers: [
        { mod: "geo", title: "Geometry encoder φₑ", sub: "occupancy-pretrained, frozen", compact: true,
          input: { label: "Segmented point cloud", caption: "2,048 points, gripper frame" },
          rows: [
            { t: "pool", label: "Furthest point sampling", call: ["M = 16 centroids", "p5"] },
            { t: "block", n: "2", label: "Set Abstraction", rows: [
              { t: "conv", label: "SA layer (PointNet++)", call: ["offsets as sin/cos(2ᵈπ Δp), d = 0 … 9", "p3"] } ] },
            { t: "linear", label: "Local geometry features", call: ["512-d per centroid", "p3"],
              zoom: { k: "rows", title: "Occupancy pre-training", rows: ["points near one centroid", "2 SA layers → 512-d code", "decoder: 8-layer res. MLP", "query → on surface? (dropped)"] } } ],
          output: { label: "16 scene nodes {Fᵢ, pᵢ}" } },
        { mod: "gnn", title: "Graph diffusion network", sub: "heterogeneous graph transformers",
          input: { label: "Graph Gᵏ", caption: "demos · current · noisy future actions" },
          rows: [
            { t: "embed", label: "Scene + gripper nodes", call: ["16 scene + 6 gripper nodes", "p1", "p5"] },
            { t: "linear", label: "Edge encoding", call: ["sin/cos of Δp", "p1"],
              zoom: { k: "rows", title: "Graph attention (Eq. 3)", rows: ["kᵢⱼ = W₄Fⱼ + W₅eᵢⱼ", "attᵢⱼ = softmax(W₃Fᵢ · kᵢⱼ / √d)", "vᵢⱼ = W₂Fⱼ + W₅eᵢⱼ", "Fᵢ′ = W₁Fᵢ + Σⱼ attᵢⱼ vᵢⱼ", "own W per node / edge type"] } },
            { t: "block", n: "2", label: "σ: local graphs", rows: [
              { t: "attn", label: "Graph attention", call: ["width 1,024, 16 heads × 64", "p4"], zoom: { k: "heads", q: 16, kv: 16, hd: 64, title: "Graph-attention heads" } },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "block", n: "2", label: "φ: demos to current", rows: [
              { t: "attn", label: "Graph attention, context", call: ["demo gripper nodes → current ones", "p1", "p4"] },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "block", n: "2", label: "ψ: current to actions", rows: [
              { t: "attn", label: "Graph attention, actions", call: ["current gripper → future gripper nodes", "p1", "p4"] },
              { t: "add", span: 1 },
              { t: "norm", label: "LayerNorm" } ] },
            { t: "mlp", label: "2-layer MLP (GELU)", call: ["ε ∈ ℝ⁷ per action gripper node", "p2", "p4"] } ],
          output: { label: "per-node flow for T future poses" } },
        { mod: "svd", title: "Pose solver", sub: "no weights", compact: true,
          input: { label: "Node flows", caption: "∇p̂ = ∇p̂ₜ + ∇p̂ᵣ, gripper" },
          rows: [
            { t: "linear", label: "p̂⁰ = pᵏ + Δpₜ + Δpᵣ" },
            { t: "linear", label: "DDIM step (Eq. 4)" },
            { t: "linear", label: "SVD fit Tₖ₋₁,ₖ (Eq. 5)" },
            { t: "linear", label: "Apply to aᵏ, repeat K ×", call: ["K = 4 in the scripts", "c1", "c3"] } ],
          output: { label: "T = 8 actions: SE(3) + gripper" } }
      ],
      links: [
        { from: "gnn", to: "svd", toRow: "input", label: "per-node ε" },
        { from: "geo", to: "gnn", toRow: "input", label: "scene nodes" }
      ]
    },
    modules: [
      { id: "geo", role: "vision-enc", roleLabel: "Point-cloud encoder", name: "Geometry encoder", sub: "2 SA layers · 512-d", col: 0, frozen: true, short: "SA encoder",
        stack: { rows: [
          { t: "in", label: "segmented point cloud", dims: "2,048 points, end-effector frame", c: "data-1" },
          { t: "pool", label: "furthest point sampling → M centroids" },
          { t: "conv", label: "2 × Set Abstraction, NeRF-style offsets" },
          { t: "out", label: "scene nodes {Fᵢ, pᵢ}", dims: "M = 16, 512-d", c: "data-1" } ],
          facts: [["Pre-training", ["occupancy network on ShapeNet; decoder dropped", "p3"]], ["Nodes", ["M = 16", "p5"]], ["Feature size", ["512", "p3"]], ["Points", ["2,048 after 1 cm voxel downsampling", "p5", "c2"]]] } },
      { id: "gnn", role: "net", roleLabel: "Graph diffusion network", name: "σ → φ → ψ", sub: "3 × 2 layers · width 1,024", col: 1, frozen: false, main: true, short: "Graph transformer",
        stack: { rows: [
          { t: "in", label: "graph: demos, current, noisy actions", dims: "local graphs of 16 + 6 nodes", c: "data-3" },
          { t: "block", label: "σ on every local graph", n: "2", rows: [{ t: "attn", label: "graph attention · LayerNorm · residual" }] },
          { t: "block", label: "φ: context graph", n: "2", rows: [{ t: "attn", label: "demo gripper → current gripper nodes" }] },
          { t: "block", label: "ψ: action graph", n: "2", rows: [{ t: "attn", label: "current → future gripper nodes" }] },
          { t: "mlp", label: "2-layer MLP, GELU" },
          { t: "out", label: "ε per action gripper node", dims: "7-d", c: "data-3" } ],
          facts: [["Layers", ["2 per network, 3 networks", "p4"]], ["Width / heads", ["1,024 / 16 × 64", "p4"]], ["Edge features", ["sin/cos of relative positions", "p1"]], ["Context", ["N = 2 demos, L = 10 waypoints", "p6"]], ["Parameters", ["69M, 117M, 178M variants", "p6"]]] } },
      { id: "svd", role: "codec", roleLabel: "Pose solver (no weights)", name: "DDIM + SVD", sub: "node flows → SE(3)", col: 2, frozen: true, short: "SVD",
        note: "Not a network: it turns predicted node displacements into rigid transforms and rebuilds the graph for the next step." }
    ],
    inputs: [
      { to: "geo", mod: "vision", label: "segmented point cloud", n: "2,048 points", k: 4 },
      { to: "gnn", mod: "other", label: "N × L demos", n: "2 × 10", k: 5 },
      { to: "gnn", mod: "state", label: "gripper", n: "6 nodes", k: 2 },
      { to: "gnn", mod: "action", label: "noisy actions", n: "T = 8", k: 4, noisy: true }
    ],
    outputs: [{ from: "svd", mod: "action", label: "end-effector actions", n: "8 × (SE(3), grip)", k: 4 }],
    links: [
      { from: "geo", to: "gnn", kind: "feeds", label: "16 nodes / graph|512-d features" },
      { from: "gnn", to: "svd", kind: "feeds", label: "per-node flow|K denoising steps" }
    ],
    callouts: [
      "The official repository ships the model only as a compiled module (instant_policy.so); layer sizes here come from App. C, and runtime settings (4 steps, 2 demos, 10 waypoints) from deploy.py.",
      "No attention between arbitrary token pairs: information moves only along typed graph edges, so memory grows linearly with the number and length of demonstrations."
    ]
  });

  /* ------------------------------------------------------------------ RICL */
  RB.arch.spec({
    id: "ricl", method: "ricl", topic: "b6", name: "RICL-π0-FAST", year: 2025, parent: "fast",
    diffRows: ["vision", "attention", "cond", "head", "output", "chunk", "latency", "train"],
    figRef: "Sridhar et al. Fig. 2 · §4 · App. C", prov: "ricl_openpi pi0_fast_ricl",
    lede: "π0-FAST-DROID, re-trained to read its own context. DINOv2 retrieves the four nearest demo states; their images, state and action chunk precede the query in one sequence, and the output tokens are blended with the nearest neighbour's.",
    sources: {
      p1: { kind: "paper", ref: "Sridhar et al. 2025, §4, Eq. 1 and Fig. 2", url: "https://arxiv.org/abs/2508.02062" },
      p2: { kind: "paper", ref: "Sridhar et al. 2025, App. C (setup and hyperparameters)", url: "https://arxiv.org/abs/2508.02062" },
      p3: { kind: "paper", ref: "Sridhar et al. 2025, §5 (priming data)", url: "https://arxiv.org/abs/2508.02062" },
      p4: { kind: "paper", ref: "Sridhar et al. 2025, App. C (runtime discussion)", url: "https://arxiv.org/abs/2508.02062" },
      c1: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/models/pi0_fast_ricl.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/models/pi0_fast_ricl.py" },
      c2: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/training/config.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/training/config.py" },
      c3: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/policies/policy.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/policies/policy.py" },
      c4: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/policies/utils.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/policies/utils.py" },
      c5: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/models/gemma_fast.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/models/gemma_fast.py" },
      c6: { kind: "code", repo: "ricl-vla/ricl_openpi", path: "src/openpi/models/siglip.py", commit: "a2d35f9", url: "https://github.com/ricl-vla/ricl_openpi/blob/a2d35f9/src/openpi/models/siglip.py" }
    },
    summary: {
      pattern: ["Autoregressive token VLA + retrieval-augmented context", "p1"],
      params: ["π0-FAST-DROID weights (PaliGemma 3B); SigLIP frozen, Gemma fully fine-tuned", "p1", "p2"],
      vision: ["SigLIP So400m/14, frozen: 3 images per block (top, side, wrist) at 224 × 224 → 256 tokens each", "p1", "p2", "c1"],
      backbone: ["Gemma 2B: 18 layers, width 2,048, 8 query / 1 KV heads", "c5"],
      head: ["LM head, then a weight-free interpolation with the nearest neighbour's tokens", "p1", "c1"],
      output: ["FAST tokens → chunk of 15 × 8 (7 joint velocities + gripper)", "p2", "c2"],
      attention: ["Prefix-LM inside each block; blocks causal left to right, nearest first, query last", "c1"],
      cond: ["4 retrieved [images, prompt, state, action chunk] groups before the query", "p2", "c2"],
      steps: ["Autoregressive FAST tokens, greedy, KV-cached context", "c1"],
      chunk: ["15 actions at 15 Hz; execute 3 (8 once a grip is predicted)", "p2"],
      rate: ["15 Hz control", "p2"],
      latency: ["≈ 1.33× π0-FAST's rollout time; retrieval under 1 ms (FAISS)", "p4"],
      train: ["400 priming demos (20 tasks × 20), 3 epochs, batch 16, peak LR 2.5e-5", "p2", "p3"]
    },
    changes: [
      "A <b>retrieval step</b> runs first: DINOv2 embeds the top camera image and FAISS finds the 4 nearest demo states.",
      "The context grows to <b>5 blocks</b>: 4 retrieved [images, prompt, state, action chunk] groups, then the query.",
      "New <b>action interpolation</b> layer: e^(−λd)·one-hot(a′) + (1 − e^(−λd))·softmax(logits), per output token.",
      "<b>SigLIP is frozen</b>; Gemma is fully fine-tuned, with loss only on the query's tokens.",
      "A new task needs no gradient step: swap in 10–20 demos as the retrieval buffer."
    ],
    blueprint: {
      headline: "RICL: retrieve, read, then blend",
      note: "Five observation blocks share one Gemma sequence: four retrieved neighbours (with their action chunks) and the query. Gemma decodes FAST tokens for the query; each token distribution is mixed with the nearest neighbour's token, weighted by how close the query image is to it in DINOv2 space.",
      towers: [
        { mod: "siglip", title: "SigLIP So400m/14", sub: "frozen during RICL", compact: true,
          input: { label: "3 images per block", caption: "top, side, wrist · 224 × 224" },
          rows: [
            { t: "embed", label: "Patch embedding layer", call: ["256 patches per image, width 1,152", "c1", "c6"] },
            { t: "block", n: "27", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Multi-head attention" },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)" },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Linear projection", call: ["1,152 → 2,048, no pooling", "c1"] } ],
          output: { label: "768 image tokens per block" } },
        { mod: "gemma", title: "Gemma 2B", sub: "π0-FAST-DROID LM, fully fine-tuned",
          input: { label: "[ret 1] … [ret 4] [query]", caption: "nearest neighbour first, query last" },
          rows: [
            { t: "embed", label: "Token embedding layer", call: ["Vocabulary of 257,152 · width 2,048", "c5"],
              zoom: { k: "rows", title: "Context layout", rows: ["ret 1: images · prompt · state · a′", "ret 2–4: same, farther away", "query: images · prompt · state", "“Action:” FAST tokens (loss here)"] } },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { t: "attn", label: "Block-causal MQA", side: "RoPE", call: ["8 query heads share 1 KV head (dim 256)", "c5"], zoom: { k: "heads", q: 8, kv: 1, hd: 256, title: "Multi-query attention" } },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Hidden dimension of 16,384", "c5"] },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final RMSNorm" },
            { t: "linear", label: "LM head → softmax", call: ["distribution over 257,152 tokens", "c5"] },
            { t: "group", label: "Action interpolation (no weights)", rows: [
              { id: "mix", t: "linear", label: "Mix with one-hot(a′)", call: ["weight e^(−λd), λ = 10", "p1", "p2"], callDy: -24,
                zoom: { k: "rows", title: "Interpolation (Eq. 1)", rows: ["w = e^(−λd)", "p = w · one-hot(a′) + (1 − w) · σ(z)", "d → 0: copy the neighbour", "d large: trust the VLA"] } },
              { t: "linear", label: "Greedy token → append" } ] },
            { t: "embed", label: "FAST decode", call: ["→ 15 × 8 chunk; execute 3", "p2", "c2"] } ],
          output: { label: "action chunk" } },
        { mod: "dino", title: "DINOv2 ViT-B/14", sub: "retrieval only, frozen", compact: true,
          input: { label: "Top camera image", caption: "query and every demo frame" },
          rows: [
            { t: "attn", label: "ViT-B/14 encoder", call: ["256 patch tokens × 768", "c4"] },
            { t: "pool", label: "Mean of 8 × 8 patch groups", call: ["64 × 768 = 49,152-d key", "c4"] },
            { t: "linear", label: "FAISS L2 k-NN", call: ["top 4 of the task demos", "p2", "c3"] } ],
          output: { label: "4 neighbours + distance d" } }
      ],
      links: [
        { from: "siglip", to: "gemma", toRow: "input", label: "image tokens" },
        { from: "dino", to: "gemma", toRow: "mix", label: "distance d" }
      ]
    },
    modules: [
      { id: "siglip", role: "vision-enc", name: "SigLIP So400m/14", sub: "27 × 1152 · 16 heads", col: 0, frozen: true, short: "SigLIP",
        stack: { rows: [
          { t: "in", label: "3 images × 5 blocks", dims: "224 × 224, resized with padding", c: "data-1" },
          { t: "embed", label: "Patch embed 14 × 14", dims: "→ 256 × 1152" },
          { t: "block", label: "ViT block", n: "27", rows: [{ t: "attn", label: "MHA" }, { t: "ffn", label: "MLP" }] },
          { t: "linear", label: "Linear head (pool = none)", dims: "1152 → 2048" },
          { t: "out", label: "256 tokens per image", c: "data-1" } ],
          facts: [["Training", ["frozen (freeze filter on .*img.*)", "p1", "c1"]], ["Images per block", ["3: top, side, wrist", "p1"]], ["Resolution", ["224 × 224", "p2"]]] } },
      { id: "gemma", role: "vlm", name: "Gemma 2B (π0-FAST-DROID)", sub: "18 × 2048 · MQA", col: 1, frozen: false, main: true, short: "Gemma 2B",
        stack: { rows: [
          { t: "in", label: "[ret₁ | ret₂ | ret₃ | ret₄ | query]", dims: "each: images, prompt, state (+ a′ for ret)", c: "data-2" },
          { t: "embed", label: "Token embedding", dims: "vocab 257,152 → 2048" },
          { t: "block", label: "Gemma decoder block", n: "18", rows: [
            { t: "norm", label: "RMSNorm" }, { t: "attn", label: "MQA · 8 query, 1 KV · RoPE · block-causal" }, { t: "add", span: 2 },
            { t: "norm", label: "RMSNorm" }, { t: "ffn", label: "GeGLU 2048 → 16,384 → 2048" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final RMSNorm" },
          { t: "linear", label: "LM head → softmax", dims: "cross-entropy on the query's postfix only" },
          { t: "linear", label: "p = w · one-hot(a′) + (1 − w) · p", dims: "w = e^(−λd), per output token" },
          { t: "embed", label: "FAST decode", dims: "→ continuous chunk" },
          { t: "out", label: "action chunk 15 × 8", c: "data-3" } ],
          facts: [["Width / depth", ["2,048 / 18", "c5"]], ["Heads", ["8 query, 1 KV, head dim 256", "c5"]], ["Text tokens per block", ["≤ 250", "c2"]], ["Retrieved blocks", ["4", "p2", "c2"]], ["Fine-tuning", ["full LLM, LR 2.5e-5 cosine, 300 warm-up steps", "p2", "c2"]]] } },
      { id: "dino", role: "vision-enc", roleLabel: "Retrieval encoder", name: "DINOv2 ViT-B/14", sub: "49,152-d key · FAISS", col: 2, frozen: true, short: "DINOv2",
        note: "Used only to pick neighbours and to compute the distance d; its features never enter Gemma." }
    ],
    inputs: [
      { to: "siglip", mod: "vision", label: "3 images × 5 blocks", n: "256 tokens each", k: 5 },
      { to: "gemma", mod: "lang", label: "prompt, state", n: "as text", k: 3 },
      { to: "gemma", mod: "action", label: "neighbour a′", n: "FAST", k: 4 },
      { to: "dino", mod: "vision", label: "query top image", n: "1 key", k: 1 }
    ],
    outputs: [{ from: "gemma", mod: "action", label: "action chunk", n: "15 × 8", k: 5 }],
    links: [
      { from: "siglip", to: "gemma", kind: "prefix", label: "linear → 2048|256 tokens / image" },
      { from: "dino", to: "gemma", kind: "feeds", label: "4 neighbours|and distance d" }
    ],
    mask: { name: "Block-causal context", ref: "c1", axes: [{ label: "retrieved blocks", short: "ret", mod: "other" }, { label: "query prefix", short: "q", mod: "vision" }, { label: "query actions", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "Code: each block is prefix-LM inside, OR-ed with a global lower-triangular mask, so every block reads all earlier ones; the query's action tokens are causal." },
    callouts: [
      "Paper Eq. 1 uses d, the raw ℓ2 distance between DINO embeddings. policy.py first <b>clips d to a stored maximum and divides by it</b>, so λ = 10 acts on a distance in [0, 1].",
      "The paper names only “DINO-v2”; the code uses ViT-B/14 and keeps 64 patch-group means (49,152-d) rather than the CLS token as the retrieval key."
    ]
  });
  /* ------------------------------------------------------------------ TecNets */
  RB.arch.spec({
    id: "tecn", method: "tecn", topic: "b6", name: "TecNets", year: 2018,
    figRef: "James et al. Fig. 2 · §3 · App. A", prov: "",
    lede: "Two small conv nets. One embeds each demonstration's first and last frame into a unit vector; their normalised mean, the task sentence, is tiled over the image and concatenated channel-wise into a control CNN that outputs torques.",
    sources: {
      p1: { kind: "paper", ref: "James et al. 2018, §3.1–3.2, Eqs. 1–4 and Fig. 2", url: "https://arxiv.org/abs/1810.03237" },
      p2: { kind: "paper", ref: "James et al. 2018, §4 (optimiser, batch) and §4.1–4.2", url: "https://arxiv.org/abs/1810.03237" },
      p3: { kind: "paper", ref: "James et al. 2018, App. A (architectures per domain)", url: "https://arxiv.org/abs/1810.03237" },
      c1: { kind: "code", repo: "stepjam/TecNets", path: "networks/cnn.py", commit: "bf88595", url: "https://github.com/stepjam/TecNets/blob/bf88595/networks/cnn.py" },
      c2: { kind: "code", repo: "stepjam/TecNets", path: "consumers/control.py", commit: "bf88595", url: "https://github.com/stepjam/TecNets/blob/bf88595/consumers/control.py" },
      c3: { kind: "code", repo: "stepjam/TecNets", path: "consumers/margin_loss.py", commit: "bf88595", url: "https://github.com/stepjam/TecNets/blob/bf88595/consumers/margin_loss.py" },
      c4: { kind: "code", repo: "stepjam/TecNets", path: "tecnets_corl_results.sh", commit: "bf88595", url: "https://github.com/stepjam/TecNets/blob/bf88595/tecnets_corl_results.sh" },
      c5: { kind: "code", repo: "stepjam/TecNets", path: "consumers/task_embedding.py", commit: "bf88595", url: "https://github.com/stepjam/TecNets/blob/bf88595/consumers/task_embedding.py" },
      c6: { kind: "code", repo: "stepjam/TecNets", path: "data/mil_sim_push.py", commit: "bf88595", url: "https://github.com/stepjam/TecNets/blob/bf88595/data/mil_sim_push.py" }
    },
    summary: {
      pattern: ["Task-embedding net + sentence-conditioned control CNN", "p1"],
      params: null,
      vision: ["Pushing: 125 × 125 RGB; 4 strided conv layers of 16 filters 5 × 5 in each net", "p3", "c4"],
      backbone: ["Control CNN reads [image ‖ tiled 20-d sentence] = 23 channels; LayerNorm + ELU", "p1", "p3", "c2"],
      head: ["Proprioception joins after the convs; 3 FC layers of 200, linear output", "p3", "c1"],
      output: ["7 joint torques (pushing); 2 in the reaching domain", "p3"],
      attention: null,
      cond: ["Sentence s: normalised mean of the K demos' embeddings, from first and last frames only", "p1", "c5"],
      steps: ["Sentence computed once per task; one control-net pass per step", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["Hinge rank loss (margin 0.1, λ 1) + support and query MSE (λ 0.1 each); Adam 5e-4", "p1", "p3", "c4"]
    },
    blueprint: {
      headline: "TecNets: a task sentence steers the policy",
      note: "The embedding net turns each demo's first and last frame into a 20-d vector; averaging and normalising gives the sentence. The sentence is tiled to the image size and stacked onto the RGB channels, so the control net sees the task from its very first conv layer.",
      towers: [
        { mod: "emb", title: "Task-embedding net fθ", sub: "demo → 20-d unit vector", compact: true,
          input: { label: "First ‖ last demo frame", caption: "125 × 125 × 6 per demonstration" },
          rows: [
            { t: "block", n: "4", label: "Strided conv", rows: [
              { t: "conv", label: "Conv 5 × 5, stride 2", call: ["16 filters per layer (pushing)", "p3", "c4"] },
              { t: "norm", label: "LayerNorm + ELU" } ] },
            { t: "block", n: "3", label: "Fully connected", rows: [
              { t: "mlp", label: "FC 200, ELU", call: ["no LayerNorm in code", "c1"] } ] },
            { t: "linear", label: "Linear → embedding", call: ["20-d per demonstration", "p3", "c4"] },
            { t: "pool", label: "Mean over demos, L2-norm", call: ["sentence s, unit length", "p1", "c3"],
              zoom: { k: "rows", title: "Hinge rank loss (Eq. 2)", rows: ["sentence from support demos", "query demo embedding sₖ", "sₖ · s_own ≥ sₖ · s_other + margin", "negatives: other tasks in batch"] } } ],
          output: { label: "sentence s (20-d)" } },
        { mod: "ctrl", title: "Control net π(o, s)", sub: "same layer recipe, own weights",
          input: { label: "Image ‖ tiled sentence", caption: "s copied to every pixel" },
          rows: [
            { t: "embed", label: "Concat on channels", call: ["3 + 20 = 23 input channels", "p1", "c2"] },
            { t: "block", n: "4", label: "Strided conv", rows: [
              { t: "conv", label: "Conv 5 × 5, stride 2", call: ["16 filters per layer (pushing)", "p3", "c4"] },
              { t: "norm", label: "LayerNorm + ELU" } ] },
            { t: "linear", label: "Flatten ‖ proprioception", side: "state", call: ["angles, velocities, EE pose", "p3"] },
            { t: "block", n: "3", label: "Fully connected", rows: [
              { t: "mlp", label: "FC 200, ELU", call: ["200 units each (pushing)", "p3", "c4"] } ] },
            { t: "linear", label: "Linear action output", call: ["7 joint torques", "p3", "c6"],
              zoom: { k: "rows", title: "Control loss (Eqs. 3–4)", rows: ["π(o, sᵤ) on support demos", "π(o, sᵤ) on query demos", "MSE, λ = 0.1 each", "+ hinge loss, λ = 1"] } } ],
          output: { label: "action a (torques)" } }
      ],
      links: [{ from: "emb", to: "ctrl", toRow: "input", label: "sentence s" }]
    },
    modules: [
      { id: "emb", role: "latent", roleLabel: "Task-embedding net", name: "Embedding CNN fθ", sub: "4 conv · 3 FC · 20-d", col: 0, frozen: false, short: "fθ",
        stack: { rows: [
          { t: "in", label: "first ‖ last frame", dims: "125 × 125 × 6", c: "data-1" },
          { t: "block", label: "Strided conv", n: "4", rows: [{ t: "conv", label: "5 × 5, 16 filters, stride 2" }, { t: "norm", label: "LayerNorm, ELU" }] },
          { t: "block", label: "Fully connected", n: "3", rows: [{ t: "mlp", label: "200 units, ELU" }] },
          { t: "linear", label: "Linear → 20" },
          { t: "pool", label: "mean over demos, L2-normalise" },
          { t: "out", label: "sentence s", dims: "20-d, unit norm", c: "data-1" } ],
          facts: [["Input", ["first and last frame, stacked: 6 channels", "p1", "c5"]], ["Convs (pushing)", ["4 × 16 filters, 5 × 5, stride 2", "p3", "c4"]], ["Convs (reaching)", ["3 × 40 filters, 3 × 3", "p3", "c4"]], ["Embedding", ["20-d", "p3", "c4"]], ["Margin", ["0.1", "p1", "c4"]]] } },
      { id: "ctrl", role: "net", roleLabel: "Control network", name: "Control CNN π", sub: "23-ch input · 3 × FC 200", col: 1, frozen: false, main: true, short: "Control net",
        stack: { rows: [
          { t: "in", label: "image ‖ tiled sentence", dims: "125 × 125 × (3 + 20)", c: "data-3" },
          { t: "block", label: "Strided conv", n: "4", rows: [{ t: "conv", label: "5 × 5, 16 filters, stride 2" }, { t: "norm", label: "LayerNorm, ELU" }] },
          { t: "linear", label: "flatten ‖ proprioception" },
          { t: "block", label: "Fully connected", n: "3", rows: [{ t: "mlp", label: "200 units, ELU" }] },
          { t: "linear", label: "Linear → action" },
          { t: "out", label: "joint torques", dims: "7 (pushing)", c: "data-3" } ],
          facts: [["Conditioning", ["sentence tiled and concatenated at the input", "p1", "c2"]], ["State", ["joins after the conv layers", "p3", "c1"]], ["State size (pushing)", ["20-d in code", "c6"]], ["Loss", ["MSE on support and query examples", "p1"]], ["Optimiser", ["Adam, lr 5e-4", "p2", "c4"]]] } }
    ],
    inputs: [
      { to: "emb", mod: "vision", label: "demo first + last frames", n: "K demos", k: 2 },
      { to: "ctrl", mod: "vision", label: "image", n: "125 × 125", k: 3 },
      { to: "ctrl", mod: "state", label: "proprio", n: "joints", k: 1 }
    ],
    outputs: [{ from: "ctrl", mod: "action", label: "joint torques", n: "7", k: 3 }],
    links: [{ from: "emb", to: "ctrl", kind: "feeds", label: "20-d sentence|tiled on channels" }],
    callouts: [
      "App. A says <b>every layer</b> is followed by LayerNorm and ELU. In cnn.py only the conv layers are normalised; the fully connected layers apply ELU alone.",
      "Eq. 1 normalises only the mean of the embeddings. margin_loss.py <b>normalises each support embedding first</b>, and uses the query embeddings unnormalised in the hinge loss.",
      "The paper trains every domain with batch 64; the released pushing command uses <b>batch 100</b> (5 support + 5 query demos)."
    ]
  });

  /* ------------------------------------------------------------------ T-OSIL */
  RB.arch.spec({
    id: "tosil", method: "tosil", topic: "b6", name: "T-OSIL", year: 2020,
    figRef: "Dasari & Gupta Fig. 2 · §3.2–3.5", prov: "",
    lede: "One-shot imitation with attention. A ResNet-18 encodes a demonstrator's video and the robot's own frames; causal non-local attention over the joint space-time volume builds task-aware features, decoded into a discretized logistic mixture over actions.",
    sources: {
      p1: { kind: "paper", ref: "Dasari & Gupta 2020, §3.2 (feature learning) and Fig. 2", url: "https://arxiv.org/abs/2011.05970" },
      p2: { kind: "paper", ref: "Dasari & Gupta 2020, §3.3 (goal-conditioned BC, mixture head)", url: "https://arxiv.org/abs/2011.05970" },
      p3: { kind: "paper", ref: "Dasari & Gupta 2020, §3.4–3.5 (inverse and point losses)", url: "https://arxiv.org/abs/2011.05970" },
      p4: { kind: "paper", ref: "Dasari & Gupta 2020, §4.1 (environment, action space)", url: "https://arxiv.org/abs/2011.05970" },
      p5: { kind: "paper", ref: "He et al. 2016, Table 1 (ResNet-18)", url: "https://arxiv.org/abs/1512.03385" },
      c1: { kind: "code", repo: "SudeepDasari/one_shot_transformers", path: "hem/models/inverse_module.py", commit: "ecd43b0", url: "https://github.com/SudeepDasari/one_shot_transformers/blob/ecd43b0/hem/models/inverse_module.py" },
      c2: { kind: "code", repo: "SudeepDasari/one_shot_transformers", path: "hem/models/traj_embed.py", commit: "ecd43b0", url: "https://github.com/SudeepDasari/one_shot_transformers/blob/ecd43b0/hem/models/traj_embed.py" },
      c3: { kind: "code", repo: "SudeepDasari/one_shot_transformers", path: "experiments/base.yaml", commit: "ecd43b0", url: "https://github.com/SudeepDasari/one_shot_transformers/blob/ecd43b0/experiments/base.yaml" },
      c4: { kind: "code", repo: "SudeepDasari/one_shot_transformers", path: "hem/models/basic_embedding.py", commit: "ecd43b0", url: "https://github.com/SudeepDasari/one_shot_transformers/blob/ecd43b0/hem/models/basic_embedding.py" },
      c5: { kind: "code", repo: "SudeepDasari/one_shot_transformers", path: "scripts/train_transformer.py", commit: "ecd43b0", url: "https://github.com/SudeepDasari/one_shot_transformers/blob/ecd43b0/scripts/train_transformer.py" },
      c6: { kind: "code", repo: "SudeepDasari/one_shot_transformers", path: "hem/models/discrete_logistic.py", commit: "ecd43b0", url: "https://github.com/SudeepDasari/one_shot_transformers/blob/ecd43b0/hem/models/discrete_logistic.py" }
    },
    summary: {
      pattern: ["Demo-conditioned attention policy (one-shot imitation)", "p1"],
      params: null,
      vision: ["ImageNet ResNet-18 with pool and fc removed: 512-channel map per frame", "p1", "c1", "c4"],
      backbone: ["2 causal non-local attention layers over [demo ‖ obs] space-time, 4 heads, Q/K/V width 128", "p1", "c1", "c3"],
      head: ["Spatial softmax → MLP → 40-d φₜ (L2 norm); ‖ goal embedding → MLP 32 → logistic mixture", "p2", "c1", "c3"],
      output: ["Target pose (xyz, axis-angle) + gripper, 8-d; 256 bins per dimension", "p4", "c1", "c6"],
      attention: ["Causal in time: a frame sees the demo frames and earlier robot frames", "p1", "c2"],
      cond: ["Context video of 4 frames from a Sawyer demonstrator; the agent is a Panda", "p4", "c3"],
      steps: null, chunk: null, rate: null, latency: null,
      train: ["BC NLL + inverse NLL (weight 1) + point NLL (0.1); lr 5e-4, batch 30", "p3", "c3", "c5"]
    },
    blueprint: {
      headline: "T-OSIL: attend across demo and robot",
      note: "Demo and robot frames share one ResNet-18. Their feature maps, with sinusoidal positions, form one space-time volume; two causal non-local layers let every robot frame read the demo. Spatial softmax and an MLP give a 40-d unit vector, joined with a 40-d goal embedding of the demo before the action head.",
      towers: [
        { mod: "trunk", title: "ResNet-18 trunk", sub: "ImageNet weights, pool and fc dropped", compact: true,
          input: { label: "RGB frame", caption: "4 demo frames + robot frames" },
          rows: [
            { t: "conv", label: "Stem 7 × 7 conv + pool", call: ["64 channels", "p5"] },
            { t: "block", n: "8", label: "Basic block", rows: [
              { t: "conv", label: "Conv 3 × 3" },
              { t: "conv", label: "Conv 3 × 3", call: ["2 blocks per stage: 64 → 512 ch", "p5", "c4"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "512-channel map per frame" } },
        { mod: "attn", title: "Non-local attention", sub: "causal over space and time",
          input: { label: "[demo ‖ robot] feature maps", caption: "512 × (4 + T) × H × W" },
          rows: [
            { t: "embed", label: "+ sinusoidal position enc.", call: ["over T·H·W flattened, 512-d", "p1", "c2"] },
            { t: "block", n: "2", rows: [
              { t: "linear", label: "1×1×1 conv Q, K, V", call: ["512 → 128 each, no bias", "c2", "c3"] },
              { t: "attn", label: "Causal self-attention", call: ["4 heads × 32, temperature √512", "c2", "c3"], zoom: { k: "heads", q: 4, kv: 4, hd: 32, title: "Attention heads" } },
              { t: "linear", label: "1×1×1 conv out, ReLU", call: ["128 → 512, dropout 0.2", "c1", "c2"] },
              { t: "add", span: 3 },
              { t: "norm", label: "BatchNorm3d" } ] } ],
          output: { label: "attended robot-frame maps" } },
        { mod: "head", title: "Embedding + heads", sub: "shared by BC and inverse model", compact: true,
          input: { label: "Robot-frame features", caption: "plus a goal embedding of the demo" },
          rows: [
            { t: "pool", label: "Spatial softmax", call: ["512 maps → 1,024 coordinates", "p2", "c1"] },
            { t: "mlp", label: "MLP + L2 norm", call: ["1,024 → 256 → 40 (φₜ)", "c1", "c3"] },
            { t: "linear", label: "‖ goal embedding", call: ["40 + 40 = 80", "c1", "c3"],
              zoom: { k: "rows", title: "Goal embedding", rows: ["[demo ‖ first robot frame]", "one more non-local layer", "temporal conv, mean over time", "same MLP → 40-d, L2 norm"] } },
            { t: "mlp", label: "Action MLP", call: ["80 → 32, ReLU", "c1", "c3"] },
            { t: "linear", label: "Logistic mixture head", call: ["2 mixtures, learned constant scale", "p2", "c3"],
              zoom: { k: "rows", title: "Auxiliary heads (training)", rows: ["inverse: [φₜ ‖ φₜ₊₁] → 32", "same mixture head as BC", "point: goal → 2-D gripper", "position H steps ahead"] } } ],
          output: { label: "aₜ ∼ discretized logistic mixture" } }
      ],
      links: [
        { from: "trunk", to: "attn", toRow: "input", label: "feature maps" },
        { from: "attn", to: "head", toRow: "input", label: "attended maps" }
      ]
    },
    modules: [
      { id: "trunk", role: "vision-enc", name: "ResNet-18", sub: "ImageNet · 512 ch", col: 0, frozen: false, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "RGB frame", dims: "demo and robot frames alike", c: "data-1" },
          { t: "conv", label: "Stem 7 × 7 + max pool" },
          { t: "block", label: "Basic residual block", n: "8", rows: [{ t: "conv", label: "3 × 3 → 3 × 3" }, { t: "add", span: 1 }] },
          { t: "out", label: "512-channel map", dims: "avgpool and fc dropped", c: "data-1" } ],
          facts: [["Init", ["ImageNet (pretrained=True)", "c4"]], ["Kept", ["all four stages, no pooling", "p1", "c1"]], ["Channels", ["512", "p1", "c1"]]] } },
      { id: "attn", role: "net", roleLabel: "Demo–robot attention", name: "Non-local attention", sub: "2 × · 4 heads · width 128", col: 1, frozen: false, main: true, short: "Attention",
        stack: { rows: [
          { t: "in", label: "[demo | robot] maps + sinusoid PE", dims: "B × 512 × T × H × W", c: "data-1" },
          { t: "block", label: "Non-local layer", n: "2", rows: [
            { t: "linear", label: "1×1×1 conv Q, K, V: 512 → 128" },
            { t: "attn", label: "causal softmax(KᵀQ / √512) per head" },
            { t: "linear", label: "1×1×1 conv 128 → 512, ReLU, dropout" },
            { t: "add", span: 3 },
            { t: "norm", label: "BatchNorm3d" } ] },
          { t: "out", label: "attended maps", dims: "robot frames kept", c: "data-1" } ],
          facts: [["Layers", ["2", "c3"]], ["Heads", ["4", "c3"]], ["Q, K, V width", ["128", "c1"]], ["Temperature", ["√512 (default)", "c2"]], ["Dropout", ["0.2", "c1"]], ["Context frames", ["4", "c3"]]] } },
      { id: "head", role: "action-head", name: "Embedding + mixture head", sub: "1,024 → 40 · 80 → 32 → 8-d", col: 2, frozen: false, short: "Head",
        stack: { rows: [
          { t: "in", label: "attended robot-frame maps", c: "data-3" },
          { t: "pool", label: "spatial softmax → 1,024" },
          { t: "mlp", label: "Linear 256, ReLU, Linear 40 · L2 norm" },
          { t: "linear", label: "‖ 40-d goal embedding" },
          { t: "mlp", label: "Linear 80 → 32, ReLU" },
          { t: "linear", label: "μ, mixture logits; constant log-scale" },
          { t: "out", label: "discretized logistic mixture", dims: "8-d, 256 bins", c: "data-3" } ],
          facts: [["Embedding", ["40-d", "c3"]], ["Mixtures", ["2", "p2", "c3"]], ["Bins", ["256 per dimension", "p4", "c6"]], ["Losses", ["BC + inverse + 0.1 · point", "p3", "c5"]]] } }
    ],
    inputs: [
      { to: "trunk", mod: "vision", label: "demo video (Sawyer)", n: "4 frames", k: 4 },
      { to: "trunk", mod: "vision", label: "robot frames (Panda)", n: "current", k: 2 }
    ],
    outputs: [{ from: "head", mod: "action", label: "action aₜ", n: "8-d", k: 3 }],
    links: [
      { from: "trunk", to: "attn", kind: "feeds", label: "512-ch maps|per frame" },
      { from: "attn", to: "head", kind: "feeds", label: "spatial softmax|→ 40-d φₜ" }
    ],
    mask: { name: "Causal space-time", ref: "p1", axes: [{ label: "demo frames", short: "d", mod: "vision" }, { label: "robot frames", short: "o", mod: "action" }], m: ["10", "11"],
      note: "Demo frames come first in time, so the causal mask lets robot frames read the whole demo and their own past, never the future." },
    callouts: [
      "Paper §3.2 applies ReLU to the K, Q and V convolutions and projects each head separately. In traj_embed.py the K, Q, V convs are plain and simply split into heads; the ReLU sits after the output conv.",
      "MOSAIC (above) keeps this non-local design (1×1×1 conv Q, K, V, residual, BatchNorm3d) and the logistic-mixture head."
    ]
  });

  /* ------------------------------------------------------------------ REGENT */
  RB.arch.spec({
    id: "regent", method: "regent", topic: "b6", name: "REGENT", year: 2024,
    figRef: "Sridhar et al. Fig. 3 · §4 · App. A", prov: "",
    lede: "A small JAT-style causal transformer that reads the 19 demo states nearest to the query, with their rewards and actions, then the query. Its output is blended with the nearest neighbour's action, weighted by how close that neighbour is.",
    sources: {
      p1: { kind: "paper", ref: "Sridhar et al. 2025, §4.1–4.2, Eqs. 1–2 and Fig. 3", url: "https://arxiv.org/abs/2412.04759" },
      p2: { kind: "paper", ref: "Sridhar et al. 2025, §4.2 (architecture, retrieval, data)", url: "https://arxiv.org/abs/2412.04759" },
      p3: { kind: "paper", ref: "Sridhar et al. 2025, App. A (hyperparameters)", url: "https://arxiv.org/abs/2412.04759" },
      c1: { kind: "code", repo: "regent-research/regent", path: "regent/modeling_regent.py", commit: "6a4ddef", url: "https://github.com/regent-research/regent/blob/6a4ddef/regent/modeling_regent.py" },
      c2: { kind: "code", repo: "regent-research/regent", path: "jat/modeling_jat.py", commit: "6a4ddef", url: "https://github.com/regent-research/regent/blob/6a4ddef/jat/modeling_jat.py" },
      c3: { kind: "code", repo: "regent-research/regent", path: "scripts_regent/new_dataset.py", commit: "6a4ddef", url: "https://github.com/regent-research/regent/blob/6a4ddef/scripts_regent/new_dataset.py" },
      c4: { kind: "code", repo: "regent-research/regent", path: "README.md", commit: "6a4ddef", url: "https://github.com/regent-research/regent/blob/6a4ddef/README.md" },
      c5: { kind: "code", repo: "regent-research/regent-medium-embeddings (Hugging Face)", path: "config.json", commit: "d3c7c23", url: "https://huggingface.co/regent-research/regent-medium-embeddings/blob/d3c7c2323bdcd39094e2b4ea9a39947c81600f39/config.json" }
    },
    summary: {
      pattern: ["Retrieval-augmented causal transformer (semi-parametric)", "p1"],
      params: ["138.6M including the frozen ResNet-18 (JAT: 192.7M)", "p2"],
      vision: ["Images: frozen ImageNet ResNet-18 → 512-d per 4-frame stack; vector states used raw", "p2", "p3", "c1"],
      backbone: ["GPT-Neo trunk: 12 layers, width 768, 12 heads, 40 learned positions", "p3", "c5"],
      head: ["Shared linear heads (continuous 768 → 513, discrete 768 → 18), then blend with R&P", "p3", "c1", "c2"],
      output: ["An action at all 20 state positions; only the query's is executed", "p1"],
      attention: ["Causal over 19 retrieved (s, r, a) tuples, nearest first, then the query", "p1", "p3"],
      cond: ["19 nearest states (with previous reward and action) from a few demos of the new environment", "p1", "p2"],
      steps: ["One forward pass per step; no gradient update in a new environment", "p1"],
      chunk: null, rate: null, latency: null,
      train: ["14.5M transitions (JAT/Gato suites); AdamW 5e-5 → 0, batch 512, stop after 1 epoch", "p2", "p3", "c4"]
    },
    blueprint: {
      headline: "REGENT: retrieve, read, then blend",
      note: "Retrieval finds the 19 demo states closest to the query. They enter the transformer with their rewards and actions, nearest first, followed by the query. Every predicted action is mixed with the nearest neighbour's action a′: the closer the query is to it, the more a′ wins.",
      towers: [
        { mod: "ret", title: "Retrieve and Play", sub: "k-NN over the demos, no trained weights", compact: true,
          input: { label: "Query state sₜ", caption: "images embedded; vectors raw" },
          rows: [
            { t: "conv", label: "ResNet-18 (images only)", call: ["512-d, frozen", "p2", "p3"] },
            { t: "linear", label: "ℓ2 nearest neighbours", call: ["n = 19, target demos", "p2"] },
            { t: "norm", label: "d ÷ 95th percentile", call: ["per environment", "p3", "c3"] },
            { t: "linear", label: "R&P: action a′ of nearest" } ],
          output: { label: "context, a′, d" } },
        { mod: "trf", title: "Causal transformer πθ", sub: "GPT-Neo trunk, JAT-style encoders",
          input: { label: "[(s′, r, a′) × 19 | sₜ, rₜ₋₁]", caption: "retrieved tuples nearest first, query last" },
          rows: [
            { t: "linear", label: "Shared linear encoder", call: ["state ‖ reward, padded to 513 → 768", "p3", "c2"] },
            { t: "embed", label: "Discrete-action lookup", call: ["GPT-2 vocabulary of 50,257 · 768", "p2", "c5"] },
            { t: "embed", label: "+ learned positions", call: ["40: 20 states, 20 actions", "p3", "c5"] },
            { t: "block", n: "12", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Causal self-attention", call: ["12 heads × 64", "p3", "c5"], zoom: { k: "heads", q: 12, kv: 12, hd: 64, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (MLP)", call: ["Hidden dimension 3,072 (4 × 768)", "c5"], zoom: { k: "mlp", act: "GELU", d: "768", ff: "3,072", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" },
            { t: "linear", label: "Shared action heads", call: ["768 → 513 cont. · 768 → 18 discrete", "p3", "c1", "c2"] },
            { t: "group", label: "Blend with R&P (no weights)", rows: [
              { id: "mix", t: "linear", label: "Mix with a′", call: ["weight e^(−λd), λ = 10", "p1", "c5"],
                zoom: { k: "rows", title: "Interpolation (Eqs. 1–2)", rows: ["w = e^(−λd)", "a = w · a′ + (1 − w) · σ(πθ)", "σ: softmax, or 10 · MixedReLU", "d → 0: play a′"] } } ] } ],
          output: { label: "query action aₜ" } }
      ],
      links: [
        { from: "ret", to: "trf", toRow: "mix", label: "a′, distance d" }
      ]
    },
    modules: [
      { id: "ret", role: "vision-enc", roleLabel: "Retrieval (R&P)", name: "ResNet-18 + k-NN", sub: "512-d key · ℓ2 · n = 19", col: 0, frozen: true, short: "Retrieval",
        note: "The only network here is the frozen ImageNet ResNet-18 used for image observations; vector observations are compared directly.",
        stack: { rows: [
          { t: "in", label: "query state sₜ", dims: "image stack or vector", c: "data-1" },
          { t: "conv", label: "ResNet-18 → 512-d (images)" },
          { t: "linear", label: "ℓ2 distance to demo states" },
          { t: "pool", label: "keep 19 nearest, sort by distance" },
          { t: "norm", label: "d ÷ 95th-percentile distance" },
          { t: "out", label: "context, a′, d", c: "data-1" } ],
          facts: [["Neighbours", ["19", "p2", "c5"]], ["Metric", ["ℓ2 (JAT/Gato setting); SSIM in ProcGen", "p2"]], ["Image key", ["ResNet-18, 512-d", "p3"]]] } },
      { id: "trf", role: "net", roleLabel: "Causal policy transformer", name: "GPT-Neo (JAT-style)", sub: "12 × 768 · 12 heads", col: 1, frozen: false, main: true, short: "Transformer",
        stack: { rows: [
          { t: "in", label: "[(s′, r, a′) × 19 | sₜ, rₜ₋₁]", dims: "40 positions", c: "data-3" },
          { t: "linear", label: "shared linear encoder 513 → 768" },
          { t: "embed", label: "token lookup for discrete actions" },
          { t: "block", label: "GPT-Neo block", n: "12", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "causal MHA · 12 heads" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 768 → 3,072 → 768, GELU" }, { t: "add", span: 2 } ] },
          { t: "linear", label: "shared linear heads" },
          { t: "linear", label: "a = w · a′ + (1 − w) · σ(πθ)", dims: "w = e^(−λd)" },
          { t: "out", label: "query action", dims: "loss on all 20 actions", c: "data-3" } ],
          facts: [["Width / depth / heads", ["768 / 12 / 12", "p3", "c5"]], ["Positions", ["40", "p3", "c5"]], ["λ and L", ["10 and 10", "p1", "c1"]], ["Loss", ["CE (discrete) + MSE (continuous) on all n + 1 actions", "p1"]], ["Fine-tuning", ["optional: lr 5e-6, 3 epochs", "p3", "c4"]]] } }
    ],
    inputs: [
      { to: "ret", mod: "vision", label: "query state", n: "image or vector", k: 2 },
      { to: "trf", mod: "other", label: "retrieved", n: "19 × (s, r, a)", k: 5 },
      { to: "trf", mod: "state", label: "query", n: "sₜ, rₜ₋₁", k: 1 }
    ],
    outputs: [{ from: "trf", mod: "action", label: "action aₜ", n: "discrete or continuous", k: 3 }],
    links: [{ from: "ret", to: "trf", kind: "prefix", label: "19 neighbours|+ a′ and d" }],
    mask: { name: "Causal over the context", ref: "p1", axes: [{ label: "retrieved tuples", short: "ret", mod: "other" }, { label: "query state", short: "s", mod: "state" }, { label: "query action", short: "a", mod: "action" }], m: ["100", "110", "111"],
      note: "Plain causal attention: the query, placed last, reads every retrieved tuple." },
    callouts: [
      "App. A: distances are divided by the 95th percentile <b>and clipped to 1</b>. The released code divides by the 95th percentile but never clips.",
      "RICL (above) carries the same blend into π0-FAST: the same e^(−λd) weight and λ = 10 on a normalised distance, but 4 DINOv2-retrieved neighbours inside a VLA."
    ]
  });

  /* ------------------------------------------------------------------ IMOP */
  RB.arch.spec({
    id: "imop", method: "imop", topic: "b6", name: "IMOP", year: 2024,
    figRef: "Zhang & Boularias Figs. 3–4 · §III-C", prov: "",
    lede: "No pose regression head. Point-cloud graph attention finds the task's invariant region in the demo frame, matches it into the live scene, and a differentiable Procrustes solve carries the demonstrated gripper pose across.",
    sources: {
      p1: { kind: "paper", ref: "Zhang & Boularias 2024, §III-C1 (invariant region matching) and Fig. 3", url: "https://arxiv.org/abs/2405.13178" },
      p2: { kind: "paper", ref: "Zhang & Boularias 2024, §III-C2 (pose regression, Eq. 1)", url: "https://arxiv.org/abs/2405.13178" },
      p3: { kind: "paper", ref: "Zhang & Boularias 2024, §III-C3 (state routing) and Fig. 4", url: "https://arxiv.org/abs/2405.13178" },
      p4: { kind: "paper", ref: "Zhang & Boularias 2024, §III-B, §III-C4 (formulation, training)", url: "https://arxiv.org/abs/2405.13178" },
      p5: { kind: "paper", ref: "Zhang & Boularias 2024, §IV, Tables III and V", url: "https://arxiv.org/abs/2405.13178" },
      c1: { kind: "code", repo: "mlzxy/imop", path: "network.py", commit: "ca23524", url: "https://github.com/mlzxy/imop/blob/ca23524/network.py" },
      c2: { kind: "code", repo: "mlzxy/imop", path: "README.md", commit: "ca23524", url: "https://github.com/mlzxy/imop/blob/ca23524/README.md" },
      c3: { kind: "code", repo: "mlzxy/imop", path: "configs/eval_novel.yaml", commit: "ca23524", url: "https://github.com/mlzxy/imop/blob/ca23524/configs/eval_novel.yaml" }
    },
    summary: {
      pattern: ["Correspondence-based one-shot policy (point graph attention + Procrustes)", "p1"],
      params: ["80.8M", "p5"],
      vision: ["Scene point cloud from 4 RGB-D cameras at 128 × 128; per point xyz, RGB, normal, robot-frame xyz, 2 flags = 14-d", "p5", "c1"],
      backbone: ["Point Transformer encoders + kNN-graph self- and cross-attention (K = 16)", "p1", "p5", "c1"],
      head: ["Sigmoid invariant-region mask; dual-softmax correspondence C; differentiable Procrustes", "p1", "p2"],
      output: ["Keyframe action: SE(3) gripper pose; open and collision flags copied from the demo", "p4", "p3"],
      attention: ["Local: each point attends to its K nearest points, within or across scenes", "p1"],
      cond: ["One demo: support keyframe sᵢ, its next frame sᵢ′ and pose Tᵢ, picked by state routing", "p1", "p3"],
      steps: ["One pass per keyframe; a motion planner reaches the pose", "p4"],
      chunk: null, rate: null, latency: null,
      train: ["18 RLBench base tasks × 100 demos; focal + dice on the mask, matching loss on C", "p5", "c1"]
    },
    blueprint: {
      headline: "IMOP: match the invariant region, solve the pose",
      note: "The invariant-region net compares the demo keyframe with its next frame and marks the points that stay fixed in the gripper's frame. The matching net aligns those points with the live scene through kNN cross-attention and dual softmax. Procrustes on the matches maps the demo pose Tᵢ to the new pose Tⱼ.",
      towers: [
        { mod: "ir", title: "Invariant-region net", sub: "support frame sᵢ vs next frame sᵢ′", compact: true,
          input: { label: "Demo pair sᵢ, sᵢ′", caption: "sᵢ chosen by the state-routing net" },
          rows: [
            { t: "attn", label: "Point Transformer", call: ["3 levels, widths 64, 128, 256", "c1"] },
            { t: "block", n: "4", label: "Reasoning stage", rows: [
              { t: "attn", label: "kNN cross-attn sᵢ ↔ sᵢ′", call: ["256-d, 8 heads, K = 16", "c1"] },
              { t: "attn", label: "kNN self-attention" },
              { t: "attn", label: "kNN cross-attn sᵢ ↔ sᵢ′" } ] },
            { t: "linear", label: "Point-wise sigmoid", call: ["temperature 0.25 → mask I(sᵢ)", "c1"] } ],
          output: { label: "invariant region I(sᵢ)" } },
        { mod: "match", title: "Region matching net", sub: "demo region ↔ live scene",
          input: { label: "I(sᵢ) points + live scene sⱼ", caption: "both as kNN graphs" },
          rows: [
            { t: "attn", label: "Point Transformer", call: ["widths 128, 256, 384", "c1"] },
            { t: "block", n: "2", label: "Match round", rows: [
              { t: "linear", label: "Match, re-pose sᵢ points" },
              { t: "attn", label: "kNN cross-attn I(sᵢ) ↔ sⱼ", call: ["128-d, 4 heads, K = 16", "c1"] },
              { t: "attn", label: "kNN self-attention" },
              { t: "attn", label: "kNN cross-attn I(sᵢ) ↔ sⱼ" } ] },
            { t: "linear", label: "Dual-softmax matching", call: ["one row of C per region point", "p1"],
              zoom: { k: "rows", title: "Dual softmax", rows: ["dot products of point features", "row and column softmax", "C: product of the two, in [0, 1]", "trained against GT matches"] } } ],
          output: { label: "correspondence matrix C" } },
        { mod: "pose", title: "Pose solver", sub: "no weights", compact: true,
          input: { label: "C, demo points, Tᵢ", caption: "Eq. 1" },
          rows: [
            { t: "linear", label: "Weighted Procrustes (SVD)", call: ["differentiable, as in Lepard", "p2"] },
            { t: "linear", label: "Tⱼ from the demo pose Tᵢ" },
            { t: "linear", label: "Copy gripper flags λᵢ" } ],
          output: { label: "pose Tⱼ + flags" } }
      ],
      links: [
        { from: "ir", to: "match", toRow: "input", label: "region mask" },
        { from: "match", to: "pose", toRow: "input", label: "matches C" }
      ]
    },
    modules: [
      { id: "ir", role: "net", roleLabel: "Invariant-region net", name: "Invariant region", sub: "PT encoder + 4 kNN stages", col: 0, frozen: false, short: "Region net",
        stack: { rows: [
          { t: "in", label: "demo frames sᵢ, sᵢ′", dims: "14-d per point", c: "data-1" },
          { t: "attn", label: "Point Transformer, depths 2, 4, 2" },
          { t: "block", label: "Reasoning stage", n: "4", rows: [{ t: "attn", label: "cross · self · cross, kNN K = 16" }] },
          { t: "linear", label: "Linear 256 → 1, sigmoid" },
          { t: "out", label: "mask I(sᵢ)", c: "data-1" } ],
          facts: [["Encoder widths", ["64, 128, 256", "c1"]], ["Heads", ["8 in the reasoning stages", "c1"]], ["Loss", ["focal + dice", "c1"]], ["Ground truth", ["segment with least motion in the action frame (Eq. 2)", "p4"]]] } },
      { id: "match", role: "net", roleLabel: "Region matching", name: "Matching net", sub: "PT encoder · kNN · 128-d", col: 1, frozen: false, main: true, short: "Matching",
        stack: { rows: [
          { t: "in", label: "I(sᵢ) points and live scene sⱼ", c: "data-3" },
          { t: "attn", label: "Point Transformer encoder" },
          { t: "block", label: "Match round", n: "2", rows: [{ t: "linear", label: "dual softmax + re-pose" }, { t: "attn", label: "cross · self · cross, kNN" }] },
          { t: "linear", label: "final dual-softmax match" },
          { t: "out", label: "correspondence C", c: "data-3" } ],
          facts: [["Width / heads", ["128 / 4", "c1"]], ["Graph degree", ["K = 16; K = 8 loses 2.7 points on novel tasks", "p5"]], ["Global attention instead", ["novel success 41.3 → 16.4 %", "p5"]]] } },
      { id: "pose", role: "codec", roleLabel: "Pose solver (no weights)", name: "Procrustes", sub: "C → SE(3)", col: 2, frozen: true, short: "Procrustes",
        note: "Not a network: least-squares rigid fit of the matched points, applied to the demonstrated pose." }
    ],
    inputs: [
      { to: "ir", mod: "vision", label: "demo keyframe pair", n: "point clouds", k: 3 },
      { to: "match", mod: "vision", label: "live point cloud", n: "4 RGB-D views", k: 4 }
    ],
    outputs: [{ from: "pose", mod: "action", label: "gripper pose Tⱼ", n: "SE(3) + 2 flags", k: 2 }],
    links: [
      { from: "ir", to: "match", kind: "feeds", label: "invariant region|I(sᵢ)" },
      { from: "match", to: "pose", kind: "feeds", label: "correspondence C|+ demo pose Tᵢ" }
    ],
    callouts: [
      "The released code (README) <b>drops the state-routing network</b> and steps to the next demo keyframe, and adds a second, fine region-matching network after the coarse one.",
      "Table V: regressing the pose from the matched points with a learned head instead of Eq. 1 drops novel-task success from 41.3 % to 29.4 %."
    ]
  });

  /* ------------------------------------------------------------------ DemoDiffusion */
  RB.arch.spec({
    id: "demodiffusion", method: "demodiffusion", topic: "b6", name: "DemoDiffusion", year: 2025, parent: "pi0",
    diffRows: ["pattern", "cond", "steps", "chunk", "output", "train"],
    figRef: "Park et al. Fig. 2 · §III · App. D–F", prov: "",
    lede: "No new network. A human demo is turned into a rough robot trajectory by hand tracking and retargeting; π0-DROID, unchanged, then denoises a partly noised copy of it, so the robot follows the demo while staying on its own action manifold.",
    sources: {
      p1: { kind: "paper", ref: "Park et al. 2025, §III-B (kinematic retargeting)", url: "https://arxiv.org/abs/2506.20668" },
      p2: { kind: "paper", ref: "Park et al. 2025, §III-C, Eq. 2 (closed-loop denoising)", url: "https://arxiv.org/abs/2506.20668" },
      p3: { kind: "paper", ref: "Park et al. 2025, §IV-B (real-world setup, π0)", url: "https://arxiv.org/abs/2506.20668" },
      p4: { kind: "paper", ref: "Park et al. 2025, App. D–E (inference, retargeting details)", url: "https://arxiv.org/abs/2506.20668" },
      p5: { kind: "paper", ref: "Black et al. 2024, §IV (π0 size)", url: "https://arxiv.org/abs/2410.24164" },
      c1: { kind: "code", repo: "demodiffusion/demodiffusion", path: "demodiffusion/deploy/demodiffusion.py", commit: "ad9cacc", url: "https://github.com/demodiffusion/demodiffusion/blob/ad9cacc/demodiffusion/deploy/demodiffusion.py" },
      c2: { kind: "code", repo: "demodiffusion/openpi", path: "src/openpi/models/pi0.py", commit: "18006ae", url: "https://github.com/demodiffusion/openpi/blob/18006ae/src/openpi/models/pi0.py" },
      c3: { kind: "code", repo: "demodiffusion/demodiffusion", path: "README.md", commit: "ad9cacc", url: "https://github.com/demodiffusion/demodiffusion/blob/ad9cacc/README.md" },
      c4: { kind: "code", repo: "demodiffusion/openpi", path: "src/openpi/models/gemma.py", commit: "18006ae", url: "https://github.com/demodiffusion/openpi/blob/18006ae/src/openpi/models/gemma.py" },
      c5: { kind: "code", repo: "demodiffusion/openpi", path: "src/openpi/training/config.py", commit: "18006ae", url: "https://github.com/demodiffusion/openpi/blob/18006ae/src/openpi/training/config.py" }
    },
    summary: {
      pattern: ["Frozen flow VLA as prior + retargeted human demo (SDEdit-style)", "p2"],
      params: ["π0-DROID as released (π0: 3.3B); HaMeR off the shelf", "p3", "p5"],
      vision: ["Policy: exterior + wrist camera at 224 × 224. Demo: HaMeR on 4 calibrated cameras, triangulated", "p3", "c1"],
      backbone: ["π0: PaliGemma (Gemma 2B) + 300M action expert, weights untouched", "p3", "p5"],
      head: ["π0's flow-matching expert, started from the noised retargeted chunk", "p2", "c2"],
      output: ["Chunk of 10 joint-velocity actions (7 joints + gripper); 8 run open loop", "p4", "c1", "c5"],
      attention: ["π0's block-causal mask, unchanged", "p3"],
      cond: ["Prompt + retargeted hand trajectory at the same timestep, as a noisy starting chunk", "p4", "c1"],
      steps: ["20-step Euler grid; start at s*/S = 0.2 or 0.4 → 4 or 8 steps", "p3", "c1", "c2"],
      chunk: ["H = 10, 8 executed before re-planning", "p4", "c1"],
      rate: ["15 Hz (DROID setup)", "c1"],
      latency: null,
      train: ["None: no fine-tuning and no robot data for the new task", "p3"]
    },
    changes: [
      "<b>No retraining</b>: π0-DROID is used exactly as released; everything new happens at inference.",
      "A <b>human-demo front end</b>: HaMeR hand meshes from 4 calibrated cameras are triangulated to 3-D keypoints.",
      "<b>Kinematic retargeting</b>: wrist → end-effector pose, thumb–finger distance → gripper, IK → joint velocities.",
      "Denoising <b>starts from the noised retargeted chunk</b> at s*/S = 0.2 or 0.4, not from pure noise.",
      "The flow grid is doubled to 20 steps, so a chunk takes 4 or 8 Euler steps (π0: 10 from noise)."
    ],
    blueprint: {
      headline: "DemoDiffusion: π0 polishes a retargeted demo",
      note: "The retargeting tower turns the human's hand into a joint-velocity chunk â. Mixed with noise, â replaces π0's usual pure-noise start. π0's Gemma and action expert then run as always, sharing attention layer by layer, but integrate only the last 4 or 8 of 20 steps.",
      towers: [
        { mod: "ret", title: "Human-demo retargeting", sub: "HaMeR + geometry, no training", compact: true,
          input: { label: "Human demo, 4 cameras", caption: "one demonstration, calibrated views" },
          rows: [
            { t: "attn", label: "HaMeR hand mesh", call: ["per view, frozen", "p3"] },
            { t: "linear", label: "Triangulate keypoints", call: ["21 keypoints, robot frame", "c3"] },
            { t: "linear", label: "Wrist → EE pose; grip", call: ["closed if < 80 % max width", "p4"],
              zoom: { k: "rows", title: "Retargeting (App. E)", rows: ["A = wrist, B = thumb tip", "C = mean of other fingertips", "orientation from AB and AB × AC", "gripper width = |BC|"] } },
            { t: "linear", label: "IK → joint velocities", call: ["10 steps from t", "p4", "c1"] } ],
          output: { label: "retargeted chunk â" } },
        { mod: "expert", title: "π0 action expert", sub: "≈300M, frozen, flow matching",
          input: { label: "Noised proposal + state", caption: "not pure noise" },
          rows: [
            { t: "group", label: "Partial noising (no weights)", rows: [
              { id: "noise", t: "linear", label: "Aτ₀ = τ₀ · â + (1 − τ₀) · ε", call: ["τ₀ = 0.8 or 0.6; first 8 dims", "p2", "c2"] } ] },
            { t: "mlp", label: "State + action/time MLP", call: ["actions padded to 32 dims", "c2"] },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention" },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Width 1,024 · hidden 4,096", "c4"] },
              { t: "add", span: 2 } ] },
            { t: "linear", label: "Action output projection", call: ["4 or 8 Euler steps to τ = 1", "c1", "c2"] } ],
          output: { label: "10 joint-velocity actions; run 8" } },
        { mod: "gemma", title: "π0 VLM (Gemma 2B)", sub: "PaliGemma prefix, frozen", compact: true,
          input: { label: "2 images + prompt", caption: "exterior + wrist, 224 × 224" },
          rows: [
            { t: "embed", label: "SigLIP tokens + text embed" },
            { t: "block", n: "18", rows: [
              { t: "norm", label: "RMSNorm 1" },
              { id: "att", t: "attn", label: "Masked multi-query attention", call: ["8 query heads share 1 KV head", "c4"] },
              { t: "add", span: 2 },
              { t: "norm", label: "RMSNorm 2" },
              { t: "ffn", label: "Feed forward (GeGLU)", call: ["Hidden dimension of 16,384", "c4"] },
              { t: "add", span: 2 } ] } ],
          output: { label: "prefix keys and values" } }
      ],
      links: [{ from: "ret", to: "expert", toRow: "noise", label: "â" }],
      shared: [{ a: ["gemma", "att"], b: ["expert", "att"], label: "shared self-attention" }]
    },
    modules: [
      { id: "ret", role: "vision-enc", roleLabel: "Hand tracking + retargeting", name: "HaMeR + retarget", sub: "4 views → joint velocities", col: 0, frozen: true, short: "Retarget",
        note: "HaMeR is used off the shelf; triangulation, the wrist-to-gripper mapping and IK have no learned weights." },
      { id: "expert", role: "action-expert", name: "π0 action expert", sub: "18 × 1024 · frozen", col: 1, frozen: true, main: true, short: "Action expert",
        stack: { rows: [
          { t: "in", label: "noised proposal Aτ₀ + state", dims: "10 × 32 (8 used)", c: "data-3" },
          { t: "linear", label: "Aτ₀ = τ₀ â + (1 − τ₀) ε", dims: "replaces the pure-noise start" },
          { t: "mlp", label: "action + time MLP → 1024" },
          { t: "block", label: "Expert block, shared attention with Gemma", n: "18", rows: [{ t: "attn", label: "masked MQA" }, { t: "ffn", label: "GeGLU 1024 → 4096" }] },
          { t: "linear", label: "action output projection" },
          { t: "out", label: "velocity vθ; Euler to τ = 1", dims: "4 or 8 steps", c: "data-3" } ],
          facts: [["Weights", ["π0-DROID checkpoint, not fine-tuned", "p3", "c3"]], ["Action horizon", ["10 (pi0_droid config)", "p4", "c5"]], ["Noise level s*/S", ["0.2 if π0 alone scores 0 %, else 0.4", "p3"]], ["Steps", ["20-step grid, both π0 and DemoDiffusion", "c1", "c2"]]] } },
      { id: "gemma", role: "vlm", name: "Gemma 2B (PaliGemma)", sub: "18 × 2048 · MQA · frozen", col: 2, frozen: true, short: "Gemma 2B",
        note: "Unchanged π0 prefix: SigLIP image tokens and the task prompt." }
    ],
    inputs: [
      { to: "ret", mod: "vision", label: "human demo video", n: "4 cameras", k: 4 },
      { to: "expert", mod: "state", label: "state", n: "1 token", k: 1 },
      { to: "expert", mod: "action", label: "noised â", n: "10 × 8", k: 4, noisy: true },
      { to: "gemma", mod: "vision", label: "robot cameras", n: "2 × 224²", k: 3 },
      { to: "gemma", mod: "lang", label: "task prompt", n: "text", k: 2 }
    ],
    outputs: [{ from: "expert", mod: "action", label: "joint velocities", n: "10 × 8", k: 4 }],
    links: [
      { from: "ret", to: "expert", kind: "feeds", label: "retargeted â|noised to τ₀" },
      { from: "gemma", to: "expert", kind: "joint-attn", label: "shared self-attn" }
    ],
    callouts: [
      "Eq. 2 writes the DDPM form √α · â + √(1 − α) · ε. The released sampler (openpi fork, pi0.py) uses π0's <b>straight-line mix</b> t · ε + (1 − t) · â with t = s*/S.",
      "Code comment: the Euler grid is raised from π0's 10 to <b>20 steps</b> for both π0 and DemoDiffusion, so s*/S = 0.2 runs 4 steps and 0.4 runs 8."
    ]
  });

  /* ------------------------------------------------------------------ MatchingPolicy */
  RB.arch.spec({
    id: "matchingpolicy", method: "matchingpolicy", topic: "b6", name: "MatchingPolicy", year: 2026,
    figRef: "She et al. Figs. 1–2, 4 · §3", prov: "no public code",
    lede: "Matching first, policy second. Foundation-model features and a point tracker give demo-to-scene correspondences; a graph diffusion policy over correspondence-indexed keypoints then predicts future gripper motion, recovered as poses by SVD.",
    sources: {
      p1: { kind: "paper", ref: "She et al. 2026, §3 (problem formulation, overview)", url: "https://arxiv.org/abs/2608.16715" },
      p2: { kind: "paper", ref: "She et al. 2026, §3.1 (correspondence-aware diffusion policy) and Fig. 2", url: "https://arxiv.org/abs/2608.16715" },
      p3: { kind: "paper", ref: "She et al. 2026, §3.3 (real-world correspondences) and Fig. 4", url: "https://arxiv.org/abs/2608.16715" },
      p4: { kind: "paper", ref: "She et al. 2026, §3.2 (MatchingDataset) and Fig. 3", url: "https://arxiv.org/abs/2608.16715" },
      p5: { kind: "paper", ref: "She et al. 2026, §3.4 (implementation details)", url: "https://arxiv.org/abs/2608.16715" },
      p6: { kind: "paper", ref: "She et al. 2026, §4.3 and Table 4 (test-time planning)", url: "https://arxiv.org/abs/2608.16715" }
    },
    summary: {
      pattern: ["Graph diffusion policy over correspondence-indexed keypoints", "p2"],
      params: null,
      vision: ["Real world: RADIO v2.5 descriptors matched inside object masks; CoTracker, 512 points per object and view", "p3"],
      backbone: ["Graph message passing over demo, current and K action frames; width and depth not stated", "p2"],
      head: ["ε ∈ ℝ⁷ per action gripper node (translation part, rotation part, gripper); SVD → ΔTₖ", "p2"],
      output: ["K relative gripper poses + gripper states; IK → joint commands", "p1", "p2"],
      attention: ["Along 3 edge types: correspondence, intra-frame spatial, action consistency", "p2"],
      cond: ["N = 1 or 2 demos, each L frames of gripper-frame point cloud + gripper state", "p1"],
      steps: null,
      chunk: ["K actions; run K/2, reuse the rest to seed the next chunk", "p6"],
      rate: null, latency: null,
      train: ["150k+ synthetic trajectories, 50k+ ShapeNet objects; AdamW 1e-5, 1M steps", "p4", "p5"]
    },
    blueprint: {
      headline: "MatchingPolicy: match, then diffuse along matches",
      note: "Off-the-shelf models find which scene points correspond to which demo points. Those matches fix the node identities of a graph: the m-th scene node means the same physical point in every frame. The policy passes messages along matches and within frames, then denoises the gripper nodes of the action frames.",
      towers: [
        { mod: "front", title: "Correspondence front end", sub: "vision foundation models, frozen", compact: true,
          input: { label: "Demo + live RGB-D", caption: "3 calibrated cameras" },
          rows: [
            { t: "pool", label: "View alignment", call: ["keep the top 2 view pairs", "p3"] },
            { t: "attn", label: "RADIO v2.5 matching", call: ["nearest descriptor in mask", "p3"] },
            { t: "attn", label: "CoTracker over time", call: ["512 points / object / view", "p3"] },
            { t: "linear", label: "Lift to 3-D, gripper frame" },
            { t: "pool", label: "Keep reliable, FPS", call: ["16 scene keypoints", "p2"] } ],
          output: { label: "matched keypoints" } },
        { mod: "gnn", title: "Correspondence-aware policy", sub: "graph diffusion network",
          input: { label: "Graph of frames", caption: "demos · current · K noisy action frames" },
          rows: [
            { t: "embed", label: "Scene + gripper nodes", call: ["16 scene + 6 gripper per frame", "p2"] },
            { t: "mlp", label: "Local PointNet features", call: ["occupancy pre-trained", "p2"],
              zoom: { k: "rows", title: "Local geometric refinement", rows: ["each point → nearest keypoint", "PointNet on each point group", "pre-trained on reconstruction", "feature on that scene node"] } },
            { t: "group", label: "Message passing (depth not stated)", rows: [
              { t: "attn", label: "Correspondence edges", call: ["demo ↔ current, same index", "p2"],
                zoom: { k: "rows", title: "Edge types", rows: ["demo ↔ current: same keypoint", "within frame: all node pairs", "action ↔ current, earlier actions", "spatial edges carry Δxyz"] } },
              { t: "attn", label: "Spatial edges in frames" },
              { t: "attn", label: "Action-consistency edges" } ] },
            { t: "mlp", label: "Denoising output", call: ["ε ∈ ℝ⁷ per action gripper node", "p2"] } ],
          output: { label: "noise estimate per gripper node" } },
        { mod: "svd", title: "Pose recovery", sub: "no weights", compact: true,
          input: { label: "Gripper-node displacements" },
          rows: [
            { t: "linear", label: "Iterative denoising" },
            { t: "linear", label: "SVD fit → ΔTₖ", call: ["least-squares rigid fit", "p2"] },
            { t: "linear", label: "IK → joint commands", call: ["run K/2, overlap the rest", "p6"] } ],
          output: { label: "K gripper actions" } }
      ],
      links: [
        { from: "front", to: "gnn", toRow: "input", label: "keypoints" },
        { from: "gnn", to: "svd", toRow: "input", label: "per-node ε" }
      ]
    },
    modules: [
      { id: "front", role: "vision-enc", roleLabel: "Correspondence front end", name: "RADIO + CoTracker", sub: "dense matches + tracks", col: 0, frozen: true, short: "Matching",
        note: "Used only at deployment; in training the synthetic dataset supplies ground-truth correspondences." },
      { id: "gnn", role: "net", roleLabel: "Graph diffusion policy", name: "Graph policy", sub: "22 nodes / frame · ε ∈ ℝ⁷", col: 1, frozen: false, main: true, short: "Graph policy",
        stack: { rows: [
          { t: "in", label: "demo, current and noisy action frames", dims: "6 gripper + 16 scene nodes each", c: "data-3" },
          { t: "mlp", label: "local PointNet feature per scene node" },
          { t: "attn", label: "message passing: correspondence, spatial, action edges" },
          { t: "mlp", label: "decoder per action gripper node" },
          { t: "out", label: "ε = [∇pₜ, ∇p_R, ∇a]", dims: "7-d", c: "data-3" } ],
          facts: [["Nodes per frame", ["6 gripper + 16 scene", "p2"]], ["Demos", ["N = 1 or 2", "p1"]], ["Loss", ["standard denoising MSE", "p2"]], ["Optimiser", ["AdamW, lr 1e-5, 1M steps", "p5"]], ["Width / depth", ["not stated", "p2"]]] } },
      { id: "svd", role: "codec", roleLabel: "Pose recovery (no weights)", name: "SVD + IK", sub: "node flow → ΔTₖ", col: 2, frozen: true, short: "SVD",
        note: "Not a network: rigid fit of the predicted gripper-keypoint displacements, then inverse kinematics." }
    ],
    inputs: [
      { to: "front", mod: "vision", label: "demo + live RGB-D", n: "3 cameras", k: 4 },
      { to: "gnn", mod: "other", label: "N demos", n: "1–2", k: 3 },
      { to: "gnn", mod: "action", label: "noisy actions", n: "K frames", k: 4, noisy: true }
    ],
    outputs: [{ from: "svd", mod: "action", label: "gripper actions", n: "K × (ΔT, grip)", k: 4 }],
    links: [
      { from: "front", to: "gnn", kind: "feeds", label: "matched keypoints|by index" },
      { from: "gnn", to: "svd", kind: "feeds", label: "per-node ε|SVD per frame" }
    ],
    callouts: [
      "No public code, and the paper gives no width, depth, head count or denoising-step count for the graph network; those are left out here.",
      "Close to Instant Policy's graph (6 gripper nodes, a 7-d ε split into translation and rotation parts, SVD), but scene nodes are <b>matched keypoints</b> rather than point-cloud centroids, so demo and scene nodes line up by index."
    ]
  });
})();
