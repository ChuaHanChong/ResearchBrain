/* Methods that reuse another model's network unchanged (alias → that diagram), and methods with no network of their own (reason shown instead of a diagram). */
(function () {
  var A = window.RB.arch;
  A.alias("open-x-embodiment-rt-x", "rt-1", "RT-X adds data, not architecture: RT-1-X is the RT-1 network trained on Open X-Embodiment, and RT-2-X is RT-2 (PaLI-X). Shown: RT-1.");
  A.alias("umi", "diffusion-policy", "UMI is a data-collection interface; its policy is a standard Diffusion Policy. Shown: Diffusion Policy.");
  A.alias("phantom", "diffusion-policy", "Phantom edits human videos into robot data and trains a standard Diffusion Policy on it. Shown: Diffusion Policy.");
  A.alias("mobile-aloha", "act", "Mobile ALOHA is a bimanual mobile platform and a co-training recipe; its main policy is the standard ACT network. Shown: ACT.");
  A.alias("serl", "hil-serl", "SERL runs the same RLPD agent and ResNet-10 encoder later used by HIL-SERL. Shown: HIL-SERL.");
  A.alias("rlpd", "hil-serl", "RLPD is an algorithm recipe on SAC (symmetric sampling, LayerNorm critics, ensembles); its network is drawn inside HIL-SERL.");
  [["dagger", "A data-aggregation algorithm around any supervised learner; it has no network of its own."],
   ["real-time-chunking", "An inference-time guidance and threading scheme around any diffusion or flow policy; no network of its own."],
   ["grasp-anything", "A dataset paper: it evaluates GR-ConvNet, GG-CNN and Det-Seg-Refine but trains no model of its own. See Grasp-Anything++ / LGD for its model."],
   ["dexgraspnet", "Its grasps come from gradient-based energy optimisation filtered in simulation, not from a network."],
   ["pinn", "A generic tanh MLP; the method is the PDE-residual loss, not the network."],
   ["sindy", "Sparse regression over a function library; no neural network."],
   ["ppo", "An optimisation algorithm (the clipped surrogate objective); the policy network is a generic MLP or CNN."],
   ["domain-randomization", "A training technique: randomize the simulator so the real world looks like one more variation."],
   ["dynamics-randomization", "A training technique: randomize physics parameters during simulation training."],
   ["gat", "An algorithm that grounds simulator actions in real transitions; no distinctive network."],
   ["roboarena", "An evaluation platform (crowd-sourced pairwise ranking), not a model."],
   ["autoeval", "An autonomous evaluation cell built from off-the-shelf classifiers and a reset policy."],
   ["robopair", "An LLM jailbreak attack; the attacker and judge are off-the-shelf LLMs."],
   ["badrobot", "A voice and text jailbreak benchmark with no model of its own."],
   ["poex", "An attack on planning LLMs with no robot-policy model to draw."],
   ["libero-plus", "A perturbation benchmark over LIBERO, not a policy."],
   /* Data (topic 14): datasets, devices and generators */
   ["droid", "A dataset and its collection platform. Its reference policy is a robomimic Diffusion Policy, drawn in Generative policy heads."],
   ["bridgedata-v2", "A dataset and its collection setup; the policies it benchmarks (GCBC, ACT, Diffusion Policy) are drawn in their own topics."],
   ["gello", "A low-cost leader arm for teleoperation: hardware, not a model."],
   ["mimicgen", "A data-generation system: it re-targets object-centric demo segments in simulation and trains a standard BC-RNN on the result."],
   ["robocasa", "A simulation framework and task suite; its benchmark policy is a standard robomimic BC-Transformer."],
   /* Benchmarks (topic 24): evaluation suites, not models */
   ["libero", "A benchmark suite (130 tasks in four groups), not a policy."],
   ["calvin", "A long-horizon language-conditioned benchmark, not a policy."],
   ["simpler", "Simulated replicas of real setups for evaluating real-robot policies; no model of its own."],
   ["rlbench", "A simulated benchmark of 100 manipulation tasks, not a policy."],
   ["meta-world", "A multi-task and meta-RL benchmark of 50 tasks, not a policy."],
   ["robomimic", "A benchmark and learning framework; its BC, BC-RNN and offline-RL baselines are generic networks."],
   ["maniskill3", "A GPU-parallel simulator and benchmark, not a policy."],
   ["worldsimbench", "A benchmark for video world simulators, not a model."],
   ["ewmbench", "A benchmark for embodied world models, not a model."],
   /* In-context learning (topic b6): methods built from off-the-shelf parts */
   ["kat", "No network of its own: frozen DINO-ViT-S/8 descriptors pick 10 keypoints shared across the demos, and an off-the-shelf GPT-4 Turbo maps the demos' keypoint and action tokens to new action tokens in context."],
   ["roboprompt", "No network of its own: Grounding DINO and FoundationPose give 6-DoF object poses, written as discretised text, and GPT-4 Turbo completes keyframe actions from 10 in-context examples."],
   ["bpc", "No deep network: it retrieves demo windows, fits their next actions to the live history (H g ≈ z), and adds a ridge-regression residual on pooled random Fourier features."]
  ].forEach(function (x) { A.none(x[0], x[1]); });
})();
