/* Architecture specs for lineage-map nodes in topics B1/B2 (policy heads): BeT, FlowPolicy, OneDP, ManiFlow, MP1,
   Streaming Flow Policy, DBPO, Implicit Drifting Policy. Numbers from each paper and, where released, its official code
   at the commit given in sources. OneDP and Implicit Drifting Policy have no official code; they are drawn from the paper only. */
(function () {
  var RB = window.RB;

  /* ------------------------------------------------------------------ BeT */
  var BTC = "3d9d423", BTR = "notmahi/bet", BTU = "https://github.com/notmahi/bet/blob/" + BTC + "/";
  RB.arch.spec({
    id: "behavior-transformers", method: "behavior-transformers", name: "Behavior Transformers (BeT)", year: 2022,
    figRef: "Shafiullah et al. Fig. 3 · §2 · Tab. 4", prov: "Franka Kitchen (state) config",
    lede: "A small causal minGPT reads the last h observations. For each step it outputs k bin logits and k residual offsets; a k-means bin centre is sampled and its offset added, so a multimodal continuous action comes out of one pass.",
    sources: {
      p1: { kind: "paper", ref: "Shafiullah et al. 2022, §2 and Fig. 3", url: "https://arxiv.org/abs/2206.11251" },
      p2: { kind: "paper", ref: "Shafiullah et al. 2022, App. B.2–B.4, Tables 4–5", url: "https://arxiv.org/abs/2206.11251" },
      p3: { kind: "paper", ref: "Shafiullah et al. 2022, §3.5 and App. B.2 (compute)", url: "https://arxiv.org/abs/2206.11251" },
      p4: { kind: "paper", ref: "Shafiullah et al. 2022, §3.1 (CARLA encoder)", url: "https://arxiv.org/abs/2206.11251" },
      c1: { kind: "code", repo: BTR, path: "configs/state_prior/mingpt_kitchen_best.yaml", commit: BTC, url: BTU + "configs/state_prior/mingpt_kitchen_best.yaml" },
      c2: { kind: "code", repo: BTR, path: "configs/action_ae/discretizers/k_means_kitchen_best.yaml", commit: BTC, url: BTU + "configs/action_ae/discretizers/k_means_kitchen_best.yaml" },
      c3: { kind: "code", repo: BTR, path: "models/latent_generators/mingpt.py", commit: BTC, url: BTU + "models/latent_generators/mingpt.py" },
      c4: { kind: "code", repo: BTR, path: "models/libraries/mingpt/model.py", commit: BTC, url: BTU + "models/libraries/mingpt/model.py" },
      c5: { kind: "code", repo: BTR, path: "configs/env/relay_kitchen_traj.yaml", commit: BTC, url: BTU + "configs/env/relay_kitchen_traj.yaml" },
      c6: { kind: "code", repo: BTR, path: "configs/train_kitchen.yaml", commit: BTC, url: BTU + "configs/train_kitchen.yaml" },
      c7: { kind: "code", repo: BTR, path: "configs/encoder/resnet.yaml", commit: BTC, url: BTU + "configs/encoder/resnet.yaml" }
    },
    summary: {
      pattern: ["Causal transformer + k-means bins and residual offsets", "p1"],
      params: ["≈10⁴ (point mass) to ≈10⁶ (Kitchen)", "p3"],
      vision: ["State vectors (60-d in Kitchen); a frozen ImageNet ResNet-18 (512-d) for CARLA images", "p4", "c5", "c7"],
      backbone: ["minGPT: 6 layers, 6 heads, width 120, causal (Kitchen)", "p2", "c1"],
      head: ["Bin head (k logits) and offset head (k × action dim); one Linear in the code", "p1", "c3"],
      output: ["One action = sampled bin centre A⌊a⌋ + that bin's offset ⟨a⟩", "p1"],
      attention: ["Causal self-attention over the observation window", "p1", "c4"],
      cond: "None beyond the observation history (unconditional behaviour)",
      steps: ["A single forward pass; the bin is sampled from the softmax", "p1"],
      chunk: ["Context 10 observations → 1 action (Kitchen)", "p2", "c6"],
      rate: null,
      latency: ["2.8 ms per action in Kitchen (IBC 52 ms) on an RTX 3080", "p3"],
      train: ["k-means fit once; then focal loss on bins + α · masked MSE on offsets", "p1", "p2"]
    },
    blueprint: {
      headline: "BeT: pick a k-means bin, add an offset",
      note: "k-means is fitted once on all actions and frozen. The minGPT maps each step of the observation window to a feature; one linear head turns it into k bin logits and k offset vectors. At test time only the last step is used: sample a bin, add its offset.",
      towers: [
        { mod: "gpt", title: "minGPT", sub: "causal transformer over observations",
          input: { label: "Observation window", caption: "10 steps × 60-d state (Kitchen)" },
          rows: [
            { t: "linear", label: "Linear projection of obs", call: ["60-d state → width 120 (Kitchen)", "c1", "c4", "c5"] },
            { t: "embed", label: "+ learned position embedding" },
            { t: "block", n: "6", rows: [
              { t: "norm", label: "LayerNorm 1" },
              { t: "attn", label: "Causal self-attention", call: ["6 heads, width 120", "p2", "c1"], zoom: { k: "heads", q: 6, kv: 6, hd: 20, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "norm", label: "LayerNorm 2" },
              { t: "ffn", label: "Feed forward (GELU)", call: ["Hidden layer dimension of 480", "c4", "c1"], zoom: { k: "mlp", act: "GELU", d: "120", ff: "480", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "Final LayerNorm" } ],
          output: { label: "120-d feature per step" } },
        { mod: "heads", title: "Bin + offset head", sub: "one Linear in the code", compact: true,
          input: { label: "GPT feature", caption: "120-d per step" },
          rows: [
            { t: "linear", label: "Linear, no bias", call: ["120 → 64 × (1 + 9) = 640 (Kitchen)", "c1", "c2", "c3", "c5"] },
            { t: "linear", label: "Split: k logits | k offsets", call: ["Focal loss, γ = 2", "p1", "c1"], zoom: { k: "rows", title: "Loss (training)", rows: ["bin target ⌊a⌋ = nearest k-means centre", "focal loss −(1−p)^γ log p on the bins", "offset target ⟨a⟩ = a − A⌊a⌋", "MSE only on the true bin's offset", "total = focal + α · offset MSE"] } } ],
          output: { label: "bin probs (k) + offsets (k × 9)" } },
        { mod: "km", title: "k-means codebook", sub: "fitted once, then frozen", compact: true,
          input: { label: "All dataset actions", caption: "fit before training" },
          rows: [
            { t: "linear", label: "k bin centres A₁…Aₖ", call: ["k = 64 (Kitchen), 24 (Block push)", "p2", "c2"] },
            { id: "dec", t: "linear", label: "Decode: A_bin + offset", zoom: { k: "rows", title: "Test-time sampling", rows: ["feed the last h observations", "take the step-t bin probabilities", "sample a bin j", "read that bin's offset ⟨â⁽ʲ⁾⟩", "action = Aⱼ + ⟨â⁽ʲ⁾⟩"] } } ],
          output: { label: "continuous action (9-d)" } }
      ],
      links: [
        { from: "gpt", to: "heads", toRow: "input", label: "feature per step" },
        { from: "heads", to: "km", toRow: "dec", label: "bin j + offset" }
      ]
    },
    modules: [
      { id: "gpt", role: "net", roleLabel: "Sequence model", name: "minGPT", sub: "6 × 120 · 6 heads · causal", col: 0, frozen: false, main: true, short: "minGPT",
        stack: { rows: [
          { t: "in", label: "observation window oₜ₋ₕ₊₁ … oₜ", dims: "Kitchen: 10 × 60-d", c: "data-8" },
          { t: "linear", label: "tok_emb: Linear obs → 120", dims: "replaces the token embedding (App. B.4)" },
          { t: "embed", label: "+ learned position embedding", dims: "block size = window" },
          { t: "block", label: "GPT block (pre-norm)", n: "6", rows: [
            { t: "norm", label: "LayerNorm" }, { t: "attn", label: "causal MHA · 6 heads" }, { t: "add", span: 2 },
            { t: "norm", label: "LayerNorm" }, { t: "ffn", label: "MLP 120 → 480 → 120 · GELU" }, { t: "add", span: 2 } ] },
          { t: "norm", label: "Final LayerNorm" },
          { t: "out", label: "feature per step", dims: "120-d", c: "data-8" } ],
          facts: [["Layers / heads / width", ["6 / 6 / 120 (Kitchen)", "p2", "c1"]], ["Block push", ["4 / 4 / 72", "p2"]], ["CARLA", ["3 / 4 / 256, dropout 0.6", "p2"]], ["Context", ["10 (Kitchen), 5 (Block push)", "p2", "c6"]], ["Optimiser", ["Adam, lr 1e-4, weight decay 0.1", "p2", "c6"]]] } },
      { id: "heads", role: "action-head", roleLabel: "Bin + offset head", name: "Output head", sub: "Linear 120 → k · (1 + |A|)", col: 1, frozen: false, short: "Head",
        stack: { rows: [
          { t: "in", label: "GPT feature", dims: "120-d", c: "data-3" },
          { t: "linear", label: "head: Linear, no bias", dims: "→ 64 + 64 × 9 (Kitchen)" },
          { t: "out", label: "bin logits (k) and offsets (k × 9)", c: "data-3" } ],
          facts: [["Bins k", ["64 (Kitchen)", "p2", "c2"]], ["Bin loss", ["focal, γ = 2", "p1", "c1"]], ["Offset loss", ["MSE on the true bin only (masked multi-task)", "p1"]], ["Offset weight", ["1,000 in the Kitchen config", "c1"]]] } },
      { id: "km", role: "codec", roleLabel: "Action binning", name: "k-means bins", sub: "k centres in action space", col: 2, frozen: true, short: "k-means",
        note: "Not a neural network: k-means fitted once on every action in the dataset, then fixed.",
        stack: { rows: [
          { t: "in", label: "all actions in the dataset", dims: "fit before training", c: "data-7" },
          { t: "linear", label: "k-means: A₁ … Aₖ", dims: "k = 64 in Kitchen" },
          { t: "out", label: "encode a → (⌊a⌋, a − A⌊a⌋); decode Aⱼ + offset", c: "data-7" } ],
          facts: [["k", ["2–3 point mass · 32 CARLA · 24 Block push · 64 Kitchen", "p2"]], ["Ablation", ["no binning: 0.25 of full BeT on Block push", "p3"]]] } }
    ],
    inputs: [
      { to: "gpt", mod: "state", label: "observation window", n: "h steps", k: 5 },
      { to: "km", mod: "action", label: "dataset actions", n: "k-means fit", k: 3 }
    ],
    outputs: [{ from: "km", mod: "action", label: "bin centre + offset", n: "one action", k: 2 }],
    links: [
      { from: "gpt", to: "heads", kind: "feeds", label: "feature per step" },
      { from: "heads", to: "km", kind: "latent", label: "bin j + offset|→ Aⱼ + ⟨â⟩" }
    ],
    mask: { name: "Causal", ref: "p1", axes: [{ label: "past obs", short: "o<t", mod: "state" }, { label: "current obs", short: "oₜ", mod: "state" }], m: ["10", "11"],
      note: "minGPT's causal mask: each step attends to itself and the observations before it." },
    callouts: [
      "Fig. 3 draws a separate <b>binning head</b> and <b>offset head</b>; the code has one bias-free Linear whose output is split into k logits and k × action-dim offsets.",
      "The paper sets the offset weight α only so the two losses start at the same magnitude; the released configs fix it per task (1,000 Kitchen, 100,000 Block push, 500 CARLA).",
      "VQ-BeT later replaces the k-means bins with a learned residual VQ so chunks and high-dimensional actions can be tokenized."
    ]
  });

  /* ------------------------------------------------------------ FlowPolicy */
  var FPC = "86d10c1", FPR = "zql-kk/FlowPolicy", FPB = "FlowPolicy/flow_policy_3d/", FPU = "https://github.com/zql-kk/FlowPolicy/blob/" + FPC + "/" + FPB;
  RB.arch.spec({
    id: "flowpolicy", method: "flowpolicy", name: "FlowPolicy", year: 2024, parent: "dp3",
    diffRows: ["head", "output", "steps", "train", "latency"],
    figRef: "Zhang et al. Fig. 2 · Eqs. 4–8", prov: "Adroit / MetaWorld config",
    lede: "DP3's point-cloud encoder and conv U-Net, retrained as a two-segment consistency flow. The network predicts a velocity whose straight-line extrapolation lands on the action chunk, so one evaluation replaces DP3's ten DDIM steps.",
    sources: {
      p1: { kind: "paper", ref: "Zhang et al. 2024, Method (Eqs. 4–8) and Fig. 2", url: "https://arxiv.org/abs/2412.04987" },
      p2: { kind: "paper", ref: "Zhang et al. 2024, Implementation Details", url: "https://arxiv.org/abs/2412.04987" },
      p3: { kind: "paper", ref: "Zhang et al. 2024, Tables 1–2", url: "https://arxiv.org/abs/2412.04987" },
      c1: { kind: "code", repo: FPR, path: FPB + "config/flowpolicy.yaml", commit: FPC, url: FPU + "config/flowpolicy.yaml" },
      c2: { kind: "code", repo: FPR, path: FPB + "policy/flowpolicy.py", commit: FPC, url: FPU + "policy/flowpolicy.py" },
      c3: { kind: "code", repo: FPR, path: FPB + "model/flow/conditional_unet1d.py", commit: FPC, url: FPU + "model/flow/conditional_unet1d.py" },
      c4: { kind: "code", repo: FPR, path: FPB + "model/vision/pointnet_extractor.py", commit: FPC, url: FPU + "model/vision/pointnet_extractor.py" }
    },
    summary: {
      pattern: ["Point-cloud encoder + 1-D temporal U-Net (FiLM), consistency flow matching", "p1"],
      params: null,
      vision: ["Single-view depth → point cloud → FPS to 512 (Adroit) or 1,024 (MetaWorld) xyz points", "p2"],
      backbone: ["DP3 Encoder: per-point MLP, max-pool, → 64-d with LayerNorm; state MLP → 64-d", "p2", "c1", "c4"],
      head: ["DP3's conv U-Net: down dims 512 / 1,024 / 2,048, kernel 5, FiLM on every block", "c1", "c3"],
      output: ["Velocity vθ on the chunk; the chunk is a₀ + (segment end − t) · vθ", "p1", "c2"],
      attention: "None (MLPs and convolutions only)",
      cond: ["FiLM: [64-d cloud feature ‖ 64-d state] × 2 frames ‖ flow-time embedding (128)", "p2", "c1", "c2"],
      steps: ["1 function evaluation at inference", "p1", "p3"],
      chunk: ["Horizon 4, 2 observations, 4 executed actions (config)", "c1"],
      rate: null,
      latency: ["19.9 ms per step on an RTX 2080 Ti (DP3: 145.7 ms)", "p3"],
      train: ["Two-segment Consistency-FM, Δt = 0.01, α = 1e-5; AdamW 1e-4, batch 128, 3,000 epochs", "p2", "c1", "c2"]
    },
    changes: [
      "The DDIM denoiser becomes a <b>velocity field</b> trained with two-segment consistency flow matching (no teacher, no distillation).",
      "Inference drops from 10 DDIM steps to <b>one</b> network evaluation.",
      "The loss compares the straight-line endpoints predicted from times t and t + Δt, plus a small velocity-consistency term.",
      "Encoder, state MLP and U-Net widths are DP3's unchanged; the horizon is 4 with all 4 actions executed."
    ],
    blueprint: {
      headline: "FlowPolicy: DP3 retrained as a straight flow",
      note: "Encoder and state MLP run once per call. The U-Net sees a noise chunk at flow time t (0 = noise) and predicts a velocity; extrapolating it to the end of the current segment gives the chunk, so one pass is enough at test time.",
      towers: [
        { mod: "enc", title: "DP3 Encoder", sub: "per-point MLP, xyz only", compact: true,
          input: { label: "Point cloud 512 × 3", caption: "depth → crop → FPS" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Linear · LayerNorm · ReLU", call: ["Widths 3 → 64 → 128 → 256", "c4"] }] },
            { t: "pool", label: "Max-pool over points" },
            { t: "linear", label: "Projection + LayerNorm", call: ["256 → 64", "p2", "c1"] } ],
          output: { label: "64-d per frame" } },
        { mod: "unet", title: "Conditional 1-D U-Net", sub: "velocity network vθ",
          input: { label: "Noisy chunk aₜ", caption: "4 steps × action dim, flow time t" },
          rows: [
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 512 → 1,024 → 2,048", "c1"] } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block, 2,048 ch" }] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "conv", label: "Upsample (transposed conv)" } ] },
            { t: "conv", label: "Final Conv1d → action dim", call: ["Output: velocity vθ(t, aₜ | s, v)", "p1", "c2"], zoom: { k: "rows", title: "Two-segment Consistency-FM", rows: ["aₜ = t·a + (1−t)·ε, t ∈ [0.01, 1]", "same noise: aₜ₊Δₜ, Δt = 0.01", "segment end e ∈ {0.5, 1}", "f = aₜ + (e − t)·vθ at both times", "loss ‖fₜ − fₜ₊Δₜ‖² + α‖vₜ − vₜ₊Δₜ‖²"] } } ],
          output: { label: "velocity; 1 step → action chunk" } },
        { mod: "state", title: "State MLP", sub: "robot pose", compact: true,
          input: { label: "Robot state q", caption: "last 2 frames" },
          rows: [{ t: "mlp", label: "Linear · ReLU · Linear", call: ["q → 64 → 64", "c4"] }],
          output: { label: "64-d per frame" } }
      ],
      links: [
        { from: "enc", to: "unet", toRow: "film", label: "[v ‖ q] × 2 ‖ t embed" },
        { from: "state", to: "unet", toRow: "film", label: "state feature" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "DP3 Encoder", sub: "MLP 64·128·256 → 64", col: 0, frozen: false, short: "Encoder",
        stack: { rows: [
          { t: "in", label: "point cloud N × 3 (xyz)", dims: "N = 512 or 1,024 after FPS", c: "data-1" },
          { t: "linear", label: "Linear 3 → 64 · LayerNorm · ReLU", dims: "shared across points" },
          { t: "linear", label: "Linear 64 → 128 · LayerNorm · ReLU" },
          { t: "linear", label: "Linear 128 → 256 · LayerNorm · ReLU" },
          { t: "pool", label: "max over points", dims: "→ 256" },
          { t: "linear", label: "Linear 256 → 64 · LayerNorm" },
          { t: "out", label: "compact 3-D feature v", dims: "64-d per frame", c: "data-1" } ],
          facts: [["Points", ["512 (Adroit) / 1,024 (MetaWorld)", "p2"]], ["Output", ["64-d, LayerNorm", "p2", "c1"]], ["Colour", ["not used", "c1"]]] } },
      { id: "unet", role: "action-head", roleLabel: "Velocity net", name: "Conditional 1-D U-Net", sub: "512 → 1024 → 2048 ch", col: 1, frozen: false, main: true, short: "1-D U-Net",
        stack: { rows: [
          { t: "in", label: "noisy chunk aₜ = t·a + (1−t)·ε", dims: "4 × action dim", c: "data-3" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "film", label: "FiLM: x · scale + bias", side: "cond" },
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" },
              { t: "add", span: 3 } ] },
            { t: "conv", label: "Downsample1d (stride 2)" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block at 2048 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · 2 conditional residual blocks" }, { t: "conv", label: "Upsample1d" }] },
          { t: "conv", label: "Conv1dBlock → Conv1d 1×1", dims: "→ action dim" },
          { t: "out", label: "velocity vθ", dims: "same shape as aₜ", c: "data-3" } ],
          facts: [["Down dims", ["512 / 1,024 / 2,048", "c1"]], ["Kernel / groups", ["5 / 8", "c1"]], ["Time embedding", ["128-d sinusoid of 99·t", "c1", "c2"]], ["Segments", ["2", "p1", "c2"]], ["Δt / α", ["0.01 / 1e-5", "c2"]], ["Inference", ["1 step", "p3"]]] } },
      { id: "state", role: "state-enc", name: "State MLP", sub: "q → 64 → 64", col: 2, frozen: false, short: "State MLP",
        stack: { rows: [
          { t: "in", label: "robot state q", dims: "2 frames", c: "data-5" },
          { t: "mlp", label: "Linear → 64 · ReLU · Linear → 64" },
          { t: "out", label: "state feature", dims: "64-d per frame", c: "data-5" } ],
          facts: [["Width", ["64, two layers", "c4"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "point cloud (xyz)", n: "512 or 1,024 pts", k: 5 },
      { to: "unet", mod: "action", label: "noise chunk", n: "4 × action dim", k: 4, noisy: true },
      { to: "unet", mod: "time", label: "flow time t", n: "→ 128-d", k: 2 },
      { to: "state", mod: "state", label: "robot state q", n: "2 frames", k: 2 }
    ],
    outputs: [{ from: "unet", mod: "action", label: "action chunk (1 step)", n: "4 × action dim", k: 4 }],
    links: [
      { from: "enc", to: "unet", kind: "film", label: "64-d / frame" },
      { from: "state", to: "unet", kind: "film", label: "64-d / frame" }
    ],
    callouts: [
      "Eqs. 4 and 8 take the t + Δt branch from an <b>EMA copy θ⁻</b>; the released <code>compute_loss</code> evaluates both times with the same online network and keeps gradients through both.",
      "MP1 later re-ran FlowPolicy at <b>71.6% / 12.6 ms</b> on an RTX 4090, against the paper's own 70.0% / 19.9 ms on a 2080 Ti."
    ]
  });

  /* ------------------------------------------------------------------ OneDP */
  RB.arch.spec({
    id: "onedp", method: "onedp", name: "OneDP", year: 2024, parent: "diffusion-policy",
    diffRows: ["params", "head", "steps", "rate", "latency", "train"],
    figRef: "Wang et al. Fig. 2 · Alg. 1 · §2.3 · App. B", prov: "paper only (no official code)",
    lede: "A pretrained Diffusion Policy is copied three times: a frozen teacher, a one-step generator and (for OneDP-S) a generator-score net. Reverse KL along the diffusion chain, computed as a score difference, pulls the generator onto the teacher's action distribution.",
    sources: {
      p1: { kind: "paper", ref: "Wang et al. 2024, §2.2 (Eqs. 3–8, Alg. 1)", url: "https://arxiv.org/abs/2410.21257" },
      p2: { kind: "paper", ref: "Wang et al. 2024, §2.3 Implementation details", url: "https://arxiv.org/abs/2410.21257" },
      p3: { kind: "paper", ref: "Wang et al. 2024, App. B and Table 7", url: "https://arxiv.org/abs/2410.21257" },
      p4: { kind: "paper", ref: "Wang et al. 2024, Fig. 1 and Tables 1–2", url: "https://arxiv.org/abs/2410.21257" }
    },
    summary: {
      pattern: ["1-D temporal U-Net (FiLM), distilled to one step", "p2"],
      params: ["256M (DDPM, sim) · 67M (EDM, sim and real)", "p3"],
      vision: ["ResNet-18 without pretraining, as in Diffusion Policy; 2 observations", "p2", "p3"],
      backbone: ["None: Diffusion Policy's CNN U-Net", "p2"],
      head: ["Generator Gθ: the DP U-Net, warm-started from the teacher, time input fixed", "p1", "p3"],
      output: ["A chunk of 16 actions in one forward pass", "p3"],
      attention: "None (convolutions only)",
      cond: ["FiLM from observation features, as in Diffusion Policy", "p2"],
      steps: ["1 NFE (teacher: 100 DDPM or 10 DDIM steps)", "p4"],
      chunk: ["2 observations → 16 predicted actions", "p3"],
      rate: ["62.5 Hz action prediction vs 1.49 Hz for Diffusion Policy (real)", "p4"],
      latency: null,
      train: ["DP pretrained 1,000 epochs; distillation 20 epochs (sim), 100 (real)", "p3", "p4"]
    },
    changes: [
      "Inference is a <b>single</b> U-Net pass: the generator maps noise z (or nothing, in OneDP-D) plus observations straight to a chunk.",
      "Training adds a <b>frozen teacher</b> (the pretrained DP) and, for OneDP-S, a second trainable copy that learns the generator's own score.",
      "The loss is reverse KL over diffused actions, whose gradient is the score difference s_ψ − s_φ (SDS/VSD style).",
      "All three networks start from the same Diffusion Policy weights, so distillation costs 2–10% of pretraining."
    ],
    blueprint: {
      headline: "OneDP: distil DP into one pass",
      note: "Only the ResNet and the generator run at test time. During distillation the generator's chunk is re-noised to a random level k; the frozen teacher and the generator-score net both denoise it, and their score difference is the gradient for Gθ.",
      towers: [
        { mod: "resnet", title: "ResNet-18", sub: "no pretraining; trained", compact: true,
          input: { label: "RGB observations", caption: "last 2 frames" },
          rows: [
            { t: "conv", label: "ResNet-18 trunk", call: ["Kept training during distillation", "p2"] },
            { t: "pool", label: "Pool → feature vector" } ],
          output: { label: "observation feature" } },
        { mod: "gen", title: "Action generator Gθ", sub: "DP U-Net, one step",
          input: { label: "Noise z (OneDP-S)", caption: "OneDP-D drops z" },
          rows: [
            { t: "embed", label: "Fixed time input", call: ["Step 65 (DDPM) or σ = 2.5 (EDM)", "p3"] },
            { t: "block", n: "N", label: "Down / mid / up", rows: [
              { t: "conv", label: "Conv1d · GroupNorm · Mish" },
              { id: "film", t: "film", label: "FiLM from observations", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
              { t: "add", span: 2 } ] },
            { t: "conv", label: "Final conv → action dim", call: ["256M (DDPM) or 67M (EDM) U-Net", "p3"] } ],
          output: { label: "chunk Aθ, 16 actions" } },
        { mod: "dist", title: "Teacher πφ + score πψ", sub: "training only", compact: true,
          input: { label: "Diffused Aθᵏ", caption: "k ∈ [2, 95] (DDPM)" },
          rows: [
            { t: "group", label: "Teacher πφ, frozen", rows: [
              { t: "conv", label: "DP U-Net εφ(Aθᵏ, k)", call: ["Pretrained 1,000 epochs", "p3"] } ] },
            { t: "group", label: "Score πψ, OneDP-S only", rows: [
              { t: "conv", label: "DP U-Net εψ(Aθᵏ, k)", call: ["lr 2e-5 vs 1e-6 for Gθ", "p2", "p3"] } ] },
            { t: "linear", label: "sψ − sφ (scores −ε / σₖ)", zoom: { k: "rows", title: "Distillation step", rows: ["Aθ = Gθ(z, O)", "Aθᵏ = αₖAθ + σₖε", "ψ: denoising loss on Aθᵏ (stop-grad)", "∇θ ∝ w(k)·(sψ − sφ)·∂Aθᵏ/∂θ", "w(k) = σₖ²; OneDP-D: sψ = −ε/σₖ"] } } ],
          output: { label: "KL gradient for Gθ" } }
      ],
      links: [
        { from: "resnet", to: "gen", toRow: "film", label: "obs feature" },
        { from: "gen", to: "dist", toRow: "input", label: "re-noise Aθ to level k" }
      ]
    },
    modules: [
      { id: "resnet", role: "vision-enc", name: "ResNet-18", sub: "no pretraining", col: 0, frozen: false, short: "ResNet-18",
        stack: { rows: [
          { t: "in", label: "RGB frames", dims: "2 observations", c: "data-1" },
          { t: "conv", label: "ResNet-18 (Diffusion Policy encoder)" },
          { t: "out", label: "observation feature", c: "data-1" } ],
          facts: [["Pretraining", ["none", "p2"]], ["During distillation", ["still trained", "p2"]]] } },
      { id: "gen", role: "action-head", roleLabel: "One-step generator", name: "Generator Gθ", sub: "DP U-Net, time fixed", col: 1, frozen: false, main: true, params: "256M / 67M", short: "Gθ",
        stack: { rows: [
          { t: "in", label: "noise z (S) or none (D) + fixed time", dims: "t = 65 (DDPM) · σ = 2.5 (EDM)", c: "data-3" },
          { t: "block", label: "Diffusion Policy conditional U-Net", n: "N", rows: [
            { t: "conv", label: "Conv1d · GroupNorm · Mish" }, { t: "film", label: "FiLM from observation feature", side: "cond" }, { t: "add", span: 2 } ] },
          { t: "out", label: "action chunk Aθ", dims: "16 actions", c: "data-3" } ],
          facts: [["Init", ["copy of the pretrained DP", "p1", "p3"]], ["LR", ["1e-6, Adam β = (0, 0.999)", "p3"]], ["Size", ["256M (DDPM sim) / 67M (EDM, real)", "p3"]], ["Variants", ["OneDP-S (stochastic, z) · OneDP-D (deterministic)", "p1"]]] } },
      { id: "dist", role: "net", roleLabel: "Distillation (training only)", name: "Teacher πφ + score πψ", sub: "two DP U-Net copies", col: 2, frozen: "partial", short: "Teacher + score",
        note: "The teacher is the frozen pretrained DP. The score net (OneDP-S only) is a trained copy; OneDP-D replaces its score by the known −ε/σₖ of a Dirac generator.",
        stack: { rows: [
          { t: "in", label: "diffused generator chunk Aθᵏ, level k", c: "data-3" },
          { t: "conv", label: "teacher εφ(Aθᵏ, k): DP U-Net, frozen" },
          { t: "conv", label: "score net εψ(Aθᵏ, k): DP U-Net, trained on Gθ's samples" },
          { t: "out", label: "sψ − sφ, with s = −ε / σₖ", c: "data-8" } ],
          facts: [["Teacher pretraining", ["1,000 epochs, lr 1e-4", "p3"]], ["Schedules", ["DDPM (ε-pred) or EDM (x₀-pred)", "p2"]], ["k range", ["[2, 95] of 100 (DDPM)", "p2", "p3"]], ["Score-net LR", ["2e-5, Adam β = (0, 0.999)", "p3"]], ["Init", ["both copies of the pretrained DP", "p1"]]] } }
    ],
    inputs: [
      { to: "resnet", mod: "vision", label: "RGB frames", n: "2 obs", k: 3 },
      { to: "gen", mod: "latent", label: "noise z", n: "OneDP-S only", k: 3, noisy: true }
    ],
    outputs: [{ from: "gen", mod: "action", label: "action chunk", n: "16 actions, 1 pass", k: 4 }],
    links: [
      { from: "resnet", to: "gen", kind: "film", label: "obs feature" },
      { from: "gen", to: "dist", kind: "feeds", label: "Aθ re-noised|→ sψ − sφ back" }
    ],
    callouts: [
      "No official code is linked from the paper or project page, so this diagram follows the paper only. OneDP does not restate the U-Net's widths; they are Diffusion Policy's.",
      "Real-world pnp and coffee tasks: success 0.98 vs 0.85 for Diffusion Policy with DDIM 10 steps (Fig. 1)."
    ]
  });

  /* --------------------------------------------------------------- ManiFlow */
  var MFC = "ef2f116", MFR = "geyan21/ManiFlow_Policy", MFB = "ManiFlow/maniflow/", MFU = "https://github.com/geyan21/ManiFlow_Policy/blob/" + MFC + "/" + MFB;
  RB.arch.spec({
    id: "maniflow", method: "maniflow", name: "ManiFlow", year: 2025, parent: "dp3",
    diffRows: ["backbone", "head", "attention", "cond", "steps", "chunk", "train"],
    figRef: "Yan et al. Figs. 2, 4 · §2 · App. A", prov: "RoboTwin point-cloud config",
    lede: "A 12-layer DiT-X transformer whose action tokens self-attend, then cross-attend to per-point cloud tokens (and T5 language tokens). Flow time t and step size Δt modulate every sub-layer, cross-attention included, via AdaLN-Zero; consistency training makes 1–2 steps enough.",
    sources: {
      p1: { kind: "paper", ref: "Yan et al. 2025, §2.1 (flow + consistency training)", url: "https://arxiv.org/abs/2509.01819" },
      p2: { kind: "paper", ref: "Yan et al. 2025, §2.3 and Fig. 4 (DiT-X)", url: "https://arxiv.org/abs/2509.01819" },
      p3: { kind: "paper", ref: "Yan et al. 2025, App. A.1 (perception)", url: "https://arxiv.org/abs/2509.01819" },
      p4: { kind: "paper", ref: "Yan et al. 2025, Tables 1, 2 and 4", url: "https://arxiv.org/abs/2509.01819" },
      c1: { kind: "code", repo: MFR, path: MFB + "config/maniflow_pointcloud_policy_robotwin.yaml", commit: MFC, url: MFU + "config/maniflow_pointcloud_policy_robotwin.yaml" },
      c2: { kind: "code", repo: MFR, path: MFB + "model/diffusion/ditx_block.py", commit: MFC, url: MFU + "model/diffusion/ditx_block.py" },
      c3: { kind: "code", repo: MFR, path: MFB + "model/diffusion/ditx.py", commit: MFC, url: MFU + "model/diffusion/ditx.py" },
      c4: { kind: "code", repo: MFR, path: MFB + "policy/maniflow_pointcloud_policy.py", commit: MFC, url: MFU + "policy/maniflow_pointcloud_policy.py" },
      c5: { kind: "code", repo: MFR, path: MFB + "model/vision_3d/pointnet_extractor.py", commit: MFC, url: MFU + "model/vision_3d/pointnet_extractor.py" },
      c6: { kind: "code", repo: MFR, path: MFB + "config/maniflow_pointcloud_policy_dex.yaml", commit: MFC, url: MFU + "config/maniflow_pointcloud_policy_dex.yaml" },
      c7: { kind: "code", repo: MFR, path: MFB + "config/maniflow_pointcloud_policy_metaworld.yaml", commit: MFC, url: MFU + "config/maniflow_pointcloud_policy_metaworld.yaml" }
    },
    summary: {
      pattern: ["Diffusion transformer policy (flow + consistency training)", "p2"],
      params: null,
      vision: ["DP3-style encoder kept per point: 128-d per point token + 64-d state; ResNet-18 from scratch for images", "p3", "c1", "c5"],
      backbone: ["DiT-X: 12 layers, width 768, 8 heads, qk-norm, MLP ratio 4", "p2", "c1", "c2"],
      head: ["Final RMSNorm + MLP → action dim (RDT-style)", "c3"],
      output: ["Velocity vθ(xₜ, t, Δt) on the action chunk", "p1"],
      attention: ["Self-attention among action tokens; cross-attention to point (and T5) tokens", "p2", "c2"],
      cond: ["AdaLN-Zero from [t ‖ Δt] embeddings: 9 × 768 shift/scale/gate per block", "p2", "c2", "c3"],
      steps: ["1–2 inference steps in the paper; the released configs default to 10", "p4", "c1"],
      chunk: ["RoboTwin: 2 obs → 16 predicted, 16 executed; Adroit/DexArt: 4 predicted, 3 executed", "c1", "c6"],
      rate: null,
      latency: null,
      train: ["75% flow-matching samples (Δt = 0) + 25% consistency samples with an EMA target", "p1", "c1", "c4"]
    },
    changes: [
      "The conv U-Net with FiLM becomes a <b>12-layer DiT-X transformer</b>: action tokens cross-attend to point and language tokens.",
      "The point encoder keeps <b>one token per point</b> instead of max-pooling to a single vector.",
      "AdaLN-Zero conditions every sub-layer, <b>including cross-attention</b>, on flow time t and step size Δt.",
      "DDIM ε-prediction is replaced by flow matching plus teacher-free <b>consistency training</b>, so 1–2 steps suffice.",
      "Optional frozen T5-small language tokens for multi-task MetaWorld."
    ],
    blueprint: {
      headline: "ManiFlow: DiT-X with AdaLN-gated cross-attention",
      note: "Point tokens (and T5 tokens) are computed once per call. Each of the 12 DiT-X blocks modulates its self-attention, cross-attention and MLP with shift, scale and gate derived from t and Δt; only the transformer repeats for the 1–2 flow steps.",
      towers: [
        { mod: "enc", title: "DP3 Encoder, per point", sub: "tokens are not max-pooled", compact: true,
          input: { label: "Point cloud", caption: "2 frames, xyz" },
          rows: [
            { t: "mlp", label: "Per-point MLP · LayerNorm", call: ["128-d per point", "c1", "c5"] },
            { t: "linear", label: "+ state feature per token", call: ["State MLP → 64-d, copied to each point", "c5"] },
            { t: "linear", label: "Linear → 768 + position", call: ["128 points × 2 frames = 256 tokens", "c1", "c3"] } ],
          output: { label: "visual tokens" } },
        { mod: "ditx", title: "DiT-X transformer", sub: "velocity network vθ(xₜ, t, Δt)",
          input: { label: "Noisy action chunk xₜ", caption: "16 tokens (RoboTwin)" },
          rows: [
            { t: "linear", label: "Action Linear → 768 + pos", call: ["Width 768", "c1", "c3"] },
            { t: "block", n: "12", rows: [
              { t: "adaln", label: "AdaLN: shift, scale", side: "t, Δt", zoom: { k: "rows", title: "AdaLN-Zero from t and Δt", rows: ["t → sinusoid 128 → MLP → 768", "Δt → sinusoid 128 → MLP → 768", "concat → Linear 1,536 → 768", "SiLU → Linear → 9 × 768 (zero-init)", "shift, scale, gate for self, cross, MLP"] } },
              { t: "attn", label: "Self-attention (actions)", call: ["8 heads, head dim 96", "c1", "c2"], zoom: { k: "heads", q: 8, kv: 8, hd: 96, title: "Attention heads" } },
              { t: "add", span: 2 },
              { t: "adaln", label: "AdaLN: shift, scale", side: "t, Δt" },
              { id: "xa", t: "attn", label: "Cross-attn to obs tokens", note: "qk-norm; output gated by α₂ before the residual add" },
              { t: "add", span: 2 },
              { t: "adaln", label: "AdaLN: shift, scale", side: "t, Δt" },
              { t: "ffn", label: "MLP (GELU-tanh)", call: ["Hidden layer dimension of 3,072", "c2"], zoom: { k: "mlp", act: "GELU", d: "768", ff: "3,072", title: "Feed forward (MLP)" } },
              { t: "add", span: 2 } ] },
            { t: "norm", label: "RMSNorm" },
            { t: "mlp", label: "Final MLP → action dim", zoom: { k: "rows", title: "Consistency flow training", rows: ["flow batch (75%): Δt = 0, target x₁ − x₀", "consistency (25%): t, Δt ~ U", "EMA net: x̃₁ = xₜ₁ + (1 − t₁)·v(xₜ₁)", "target ṽ = (x̃₁ − xₜ) / (1 − t)", "loss ‖vθ(xₜ, t, Δt) − ṽ‖²"] } } ],
          output: { label: "velocity; 1–2 Euler steps" } },
        { mod: "lang", title: "T5-small", sub: "frozen, multi-task only", compact: true,
          input: { label: "Instruction", caption: "MetaWorld language tasks" },
          rows: [
            { t: "attn", label: "T5 encoder (frozen)", call: ["512-d tokens", "c3", "c7"] },
            { t: "linear", label: "Adapter → 768" } ],
          output: { label: "language tokens" } }
      ],
      links: [
        { from: "enc", to: "ditx", toRow: "xa", label: "point tokens (K, V)" },
        { from: "lang", to: "ditx", toRow: "xa", label: "language tokens" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "DP3 Encoder (pointwise)", sub: "128-d / point + state", col: 0, frozen: false, short: "Point enc.",
        note: "The DP3 PointNet MLP without the max-pool: every sampled point stays a token. Images use a ResNet-18 trained from scratch instead.",
        stack: { rows: [
          { t: "in", label: "point cloud, 2 frames", dims: "128 points per frame (RoboTwin config)", c: "data-1" },
          { t: "mlp", label: "per-point MLP with LayerNorm", dims: "→ 128-d" },
          { t: "linear", label: "concat state MLP feature to each point", dims: "+ 64-d" },
          { t: "linear", label: "Linear → 768 + learned position" },
          { t: "out", label: "visual tokens", dims: "256 × 768", c: "data-1" } ],
          facts: [["Tokens", ["visual_cond_len × 2 frames (128 × 2 RoboTwin, 64 × 2 Adroit/DexArt)", "c1", "c6"]], ["Point feature", ["128-d", "c1"]], ["State", ["MLP (64, 64), concatenated per point", "c5"]], ["Images", ["ResNet-18 from scratch, crop 0.95, ±5° rotation", "p3"]]] } },
      { id: "ditx", role: "action-head", roleLabel: "Flow transformer", name: "DiT-X", sub: "12 × 768 · 8 heads", col: 1, frozen: false, main: true, short: "DiT-X",
        stack: { rows: [
          { t: "in", label: "noisy action tokens xₜ", dims: "16 × action dim → 768", c: "data-3" },
          { t: "block", label: "DiT-X block", n: "12", rows: [
            { t: "adaln", label: "LN (no affine) · modulate(shift₁, scale₁)", side: "t, Δt" }, { t: "attn", label: "self-attention · 8 heads" }, { t: "add", label: "x + α₁ · out", span: 2 },
            { t: "adaln", label: "LN · modulate(shift₂, scale₂)", side: "t, Δt" }, { t: "attn", label: "cross-attention to visual + language tokens · qk-norm" }, { t: "add", label: "x + α₂ · out", span: 2 },
            { t: "adaln", label: "LN · modulate(shift₃, scale₃)", side: "t, Δt" }, { t: "ffn", label: "MLP 768 → 3,072 → 768 · GELU-tanh" }, { t: "add", label: "x + α₃ · out", span: 2 } ] },
          { t: "norm", label: "RMSNorm" },
          { t: "mlp", label: "MLP → action dim (zero-init last layer)" },
          { t: "out", label: "velocity vθ", c: "data-3" } ],
          facts: [["Layers / width / heads", ["12 / 768 / 8", "c1"]], ["Modulation", ["9 × 768 from SiLU → Linear, zero-init", "c2", "c3"]], ["Time inputs", ["t and Δt: sinusoid 128 → MLP → 768 each, concat → Linear 1,536 → 768", "c1", "c3"]], ["Batch split", ["75% flow / 25% consistency", "c1"]], ["t sampling", ["beta for flow, discrete for consistency; Δt ~ U[0, 1]", "p1", "c1"]]] } },
      { id: "lang", role: "lang", name: "T5-small", sub: "frozen · 512-d tokens", col: 2, frozen: true, short: "T5-small",
        stack: { rows: [
          { t: "in", label: "task instruction", c: "data-2" },
          { t: "attn", label: "T5-small encoder (frozen)", dims: "512-d tokens" },
          { t: "linear", label: "adapter MLP → 768" },
          { t: "out", label: "language tokens (cross-attention keys)", c: "data-2" } ],
          facts: [["Model", ["t5-small, frozen", "c3"]], ["Used in", ["48-task language-conditioned MetaWorld", "p4", "c7"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "point cloud", n: "2 frames", k: 5 },
      { to: "enc", mod: "state", label: "proprioception", n: "per frame", k: 2 },
      { to: "ditx", mod: "action", label: "noisy chunk xₜ", n: "16 tokens", k: 4, noisy: true },
      { to: "ditx", mod: "time", label: "t and Δt", n: "→ AdaLN", k: 2 },
      { to: "lang", mod: "lang", label: "instruction", n: "optional", k: 3 }
    ],
    outputs: [{ from: "ditx", mod: "action", label: "action chunk", n: "1–2 steps", k: 4 }],
    links: [
      { from: "enc", to: "ditx", kind: "cross-attn", label: "256 point tokens" },
      { from: "lang", to: "ditx", kind: "cross-attn", label: "T5 tokens" }
    ],
    callouts: [
      "Fig. 4 says AdaLN-Zero carries the <b>low-dimensional robot state</b>; in the released code AdaLN sees only t and Δt, and the 64-d state feature is concatenated onto every point token instead.",
      "Table 4 reports the best RoboTwin average with <b>2</b> steps (64.5%) and 63.7% with 1; the released configs set <code>num_inference_steps: 10</code>.",
      "Unlike Consistency Policy, no pretrained teacher is needed: the consistency target comes from the model's own EMA copy."
    ]
  });

  /* -------------------------------------------------------------------- MP1 */
  var MPC = "e1e9e8f", MPR = "LogSSim/MP1", MPB = "MP1/mp1/", MPU = "https://github.com/LogSSim/MP1/blob/" + MPC + "/" + MPB;
  RB.arch.spec({
    id: "mp1", method: "mp1", name: "MP1", year: 2025, parent: "flowpolicy",
    diffRows: ["head", "output", "cond", "train", "latency"],
    figRef: "Sheng et al. Fig. 2 · Eqs. 1–8", prov: "Adroit / MetaWorld config",
    lede: "DP3's encoder and conv U-Net trained with MeanFlow: the network predicts the average velocity over an interval [r, t], so one evaluation from r = 0 to t = 1 jumps from noise to the action chunk. A dispersive loss spreads the U-Net's down-path features.",
    sources: {
      p1: { kind: "paper", ref: "Sheng et al. 2025, Method (Eqs. 1–8)", url: "https://arxiv.org/abs/2507.10543" },
      p2: { kind: "paper", ref: "Sheng et al. 2025, Fig. 2", url: "https://arxiv.org/abs/2507.10543" },
      p3: { kind: "paper", ref: "Sheng et al. 2025, Implementation Details", url: "https://arxiv.org/abs/2507.10543" },
      p4: { kind: "paper", ref: "Sheng et al. 2025, Tables 1, 2 and 4", url: "https://arxiv.org/abs/2507.10543" },
      c1: { kind: "code", repo: MPR, path: MPB + "config/mp1.yaml", commit: MPC, url: MPU + "config/mp1.yaml" },
      c2: { kind: "code", repo: MPR, path: MPB + "policy/meanpolicy_dis.py", commit: MPC, url: MPU + "policy/meanpolicy_dis.py" },
      c3: { kind: "code", repo: MPR, path: MPB + "model/mean/conditional_unet1d_meanflow_dis.py", commit: MPC, url: MPU + "model/mean/conditional_unet1d_meanflow_dis.py" }
    },
    summary: {
      pattern: ["Point-cloud encoder + 1-D temporal U-Net (FiLM), MeanFlow", "p1"],
      params: null,
      vision: ["Single-view point cloud, FPS to 512 or 1,024 points; DP3 Encoder → 64-d", "p3", "c1"],
      backbone: ["DP3 Encoder (MLP + max-pool, LayerNorm) and a state MLP", "p2", "c1"],
      head: ["Conv U-Net 512 / 1,024 / 2,048, kernel 5, with a second time input r", "c1", "c3"],
      output: ["Average velocity u(z, r, t); one step: chunk = ε − u(ε, 0, 1)", "p1", "c2"],
      attention: "None (MLPs and convolutions only)",
      cond: ["FiLM: [emb(t) + emb(r)] ‖ obs features (2 frames)", "c1", "c3"],
      steps: ["1 NFE", "p1", "p4"],
      chunk: ["Horizon 4, 2 observations, 4 executed (sim); horizon 16 on the real robot", "p3", "c1"],
      rate: null,
      latency: ["6.8 ms on an RTX 4090 (FlowPolicy 12.6 ms, DP3 132.2 ms)", "p4"],
      train: ["MeanFlow loss (JVP target) + 0.5 · dispersive loss; batch 128, AdamW 1e-4", "p1", "p3", "c2"]
    },
    changes: [
      "The two-segment consistency loss is replaced by the <b>MeanFlow identity</b>: the net learns the average velocity over [r, t] via a Jacobian-vector product target.",
      "The U-Net gets a <b>second time input r</b>, embedded like t and added to it.",
      "A <b>dispersive loss</b> (InfoNCE without positives) pushes apart down-path features of different samples in a batch.",
      "Guidance is folded into the regression target, so sampling stays at one evaluation."
    ],
    blueprint: {
      headline: "MP1: one jump along the mean velocity",
      note: "The encoder runs once. The U-Net takes the noise chunk with both interval ends r and t; at test time r = 0 and t = 1 (the paper's t = 1 is noise), and subtracting the predicted average velocity gives the chunk in one pass.",
      towers: [
        { mod: "enc", title: "DP3 Encoder", sub: "per-point MLP, xyz only", compact: true,
          input: { label: "Point cloud 512 × 3", caption: "last 2 frames" },
          rows: [
            { t: "block", n: "3", rows: [{ t: "linear", label: "Linear · LayerNorm · ReLU" }] },
            { t: "pool", label: "Max-pool over points" },
            { t: "linear", label: "Projection + LayerNorm", call: ["→ 64-d, + 64-d state MLP", "p2", "c1"] } ],
          output: { label: "64 + 64 per frame" } },
        { mod: "unet", title: "MeanFlow 1-D U-Net", sub: "average-velocity net u(z, r, t)",
          input: { label: "Noise chunk z", caption: "4 steps × action dim" },
          rows: [
            { t: "embed", label: "emb(t) + emb(r)", side: "t, r", call: ["Each: sinusoid 128 → MLP → 128", "c1", "c3"] },
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Dispersive loss on level outputs, λ = 0.5", "p1", "c2"], zoom: { k: "rows", title: "Dispersive loss", rows: ["zᵢ = flattened level features", "D = ‖zᵢ − zⱼ‖² / max D", "L = log mean exp(−D / τ), τ = 1", "no positive pairs", "training only: no inference cost"] } } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block, 2,048 ch" }] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "conv", label: "Upsample (transposed conv)" } ] },
            { t: "conv", label: "Final Conv1d → action dim", call: ["Channels 512 → 1,024 → 2,048", "c1"], zoom: { k: "rows", title: "MeanFlow target", rows: ["z = (1 − t)·a + t·ε, r ≤ t", "50% of samples: r = t (plain flow)", "(u, du/dt) = JVP along (v, 1, 0)", "u_tgt = v − (t − r)·du/dt", "loss: adaptive L2 on u − sg(u_tgt)"] } } ],
          output: { label: "u(z, 0, 1): chunk = z − u" } }
      ],
      links: [{ from: "enc", to: "unet", toRow: "film", label: "obs features ‖ time" }]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "DP3 Encoder + state MLP", sub: "64-d cloud · 64-d state", col: 0, frozen: false, short: "Encoder",
        stack: { rows: [
          { t: "in", label: "point cloud N × 3 and robot state", dims: "N = 512 or 1,024", c: "data-1" },
          { t: "linear", label: "per-point MLP 3 → 64 → 128 → 256 · LayerNorm · ReLU" },
          { t: "pool", label: "max over points → Linear → 64 · LayerNorm" },
          { t: "mlp", label: "state MLP → 64" },
          { t: "out", label: "128-d per frame, 2 frames", c: "data-1" } ],
          facts: [["Output", ["64-d cloud (LayerNorm) + state", "c1"]], ["Points", ["512 or 1,024 via FPS", "p3"]]] } },
      { id: "unet", role: "action-head", roleLabel: "Average-velocity net", name: "MeanFlow U-Net", sub: "512 → 1024 → 2048 ch", col: 1, frozen: false, main: true, short: "U-Net",
        stack: { rows: [
          { t: "in", label: "z = (1 − t)·a + t·ε", dims: "4 × action dim", c: "data-3" },
          { t: "embed", label: "emb(t) + emb(r) ‖ global obs feature", side: "t, r" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" }, { t: "film", label: "FiLM scale + bias", side: "cond" },
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" }, { t: "add", span: 3 } ] },
            { t: "conv", label: "Downsample1d · features kept for the dispersive loss" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block at 2048 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · 2 conditional residual blocks" }, { t: "conv", label: "Upsample1d" }] },
          { t: "conv", label: "Conv1dBlock → Conv1d 1×1" },
          { t: "out", label: "average velocity u(z, r, t)", c: "data-3" } ],
          facts: [["Down dims", ["512 / 1,024 / 2,048, kernel 5", "c1"]], ["Flow ratio", ["0.5 (r = t for half the batch)", "p4", "c2"]], ["Time sampling", ["logit-normal (−0.4, 1.0)", "c2"]], ["Dispersive", ["λ = 0.5, τ = 1", "p1", "c2"]], ["Guidance", ["w = 2.0 in the code", "c2"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "point cloud", n: "512 / 1,024 pts", k: 5 },
      { to: "enc", mod: "state", label: "robot state", n: "2 frames", k: 2 },
      { to: "unet", mod: "action", label: "noise chunk", n: "horizon 4", k: 4, noisy: true },
      { to: "unet", mod: "time", label: "r and t", n: "0 and 1", k: 2 }
    ],
    outputs: [{ from: "unet", mod: "action", label: "action chunk", n: "1 NFE", k: 4 }],
    links: [{ from: "enc", to: "unet", kind: "film", label: "obs features|(2 frames)" }],
    callouts: [
      "MP1 follows MeanFlow's time direction: <b>t = 1 is noise</b> and t = 0 the action (z = (1 − t)·a + t·ε), the reverse of this site's τ convention.",
      "Eq. 5 blends the conditional velocity with an <b>unconditional</b> prediction u(Aₜ, t, t | ∅). The code blends with the conditional network's own prediction (w = 2.0) and never drops the condition (<code>cfg_ratio</code> is set but unused).",
      "The paper applies the dispersive loss to the output of <b>each</b> down-sampling block; the code uses the first two of the three levels and normalises distances by their maximum."
    ]
  });

  /* ------------------------------------------------- Streaming Flow Policy */
  var SFC = "ea08aa9", SFR = "siddancha/streaming-flow-policy", SFB = "streaming_flow_policy/", SFU = "https://github.com/siddancha/streaming-flow-policy/blob/" + SFC + "/" + SFB;
  RB.arch.spec({
    id: "streaming-flow-policy", method: "streaming-flow-policy", name: "Streaming Flow Policy", year: 2025, parent: "diffusion-policy",
    diffRows: ["head", "output", "steps", "chunk", "latency"],
    figRef: "Jiang et al. Fig. 1 · Eqs. 1–4 · Algs. 1–2", prov: "Push-T state config",
    lede: "Diffusion Policy's U-Net shrunk to act on one action instead of a chunk. Flow time is execution time: starting from the last action, an ODE solver integrates the learned velocity and each intermediate point is streamed to the robot as it appears.",
    sources: {
      p1: { kind: "paper", ref: "Jiang et al. 2025, §2–3 (Eqs. 1–3)", url: "https://arxiv.org/abs/2505.21851" },
      p2: { kind: "paper", ref: "Jiang et al. 2025, §4–5 and Algs. 1–2", url: "https://arxiv.org/abs/2505.21851" },
      p3: { kind: "paper", ref: "Jiang et al. 2025, §6 and Tables 2–3", url: "https://arxiv.org/abs/2505.21851" },
      c1: { kind: "code", repo: SFR, path: SFB + "pusht/experiments/sfpd_obs/train.py", commit: SFC, url: SFU + "pusht/experiments/sfpd_obs/train.py" },
      c2: { kind: "code", repo: SFR, path: SFB + "pusht/sfpd.py", commit: SFC, url: SFU + "pusht/sfpd.py" },
      c3: { kind: "code", repo: SFR, path: SFB + "pusht/dp_state_notebook/network.py", commit: SFC, url: SFU + "pusht/dp_state_notebook/network.py" },
      c4: { kind: "code", repo: SFR, path: SFB + "core/sfp_aspace.py", commit: SFC, url: SFU + "core/sfp_aspace.py" }
    },
    summary: {
      pattern: ["1-D temporal U-Net (FiLM) on a single action; flow time = execution time", "p2"],
      params: null,
      vision: ["Push-T state: 5-d observation × 2 frames; image variant uses Diffusion Policy's encoder", "p3", "c1"],
      backbone: "None: Diffusion Policy's conditional U-Net",
      head: ["U-Net 256 / 512 / 1,024, kernel 5; down/up-sampling replaced by Linear layers", "p3", "c1", "c3"],
      output: ["Velocity vθ(a, t | h) of one action in action space", "p1", "p2"],
      attention: "None (convolutions and linear layers)",
      cond: ["FiLM from [observation history ‖ time embedding (256)]", "c1", "c2", "c3"],
      steps: ["dopri5 ODE solver, 6 integration steps per streamed action (Push-T)", "c2"],
      chunk: ["Trajectory of 16 actions rescaled to t ∈ [0, 1]; 8 executed per chunk", "c1"],
      rate: null,
      latency: ["3.5 ms per action (Push-T state), 8.8 ms (image), 4.5 ms (RoboMimic)", "p3"],
      train: ["Flow matching on single (a, t) samples, 1,000 epochs, batch 1,024", "p2", "c1"]
    },
    changes: [
      "The network input and output shrink from a <b>chunk</b> Aᵀ to a <b>single action</b>; temporal conv resampling becomes Linear layers.",
      "Flow time equals execution time: integration starts at the <b>last action</b> (not pure noise) and every step is sent to the robot.",
      "The target velocity is the demonstration's time derivative ξ̇(t), with a stabilizing pull −k(a − ξ(t)) in the paper.",
      "Test time is deterministic (σ₀ = 0); multimodality comes from the learned per-time marginals."
    ],
    blueprint: {
      headline: "SFP: the flow path is the robot path",
      note: "The velocity net sees one action, the flow time t and the observation history. An ODE solver steps t from 0 toward 1 and each intermediate action is executed immediately; the history is held fixed within a chunk.",
      towers: [
        { mod: "vnet", title: "Velocity U-Net", sub: "Diffusion Policy U-Net on one action",
          input: { label: "Current action a", caption: "2-d on Push-T, time t" },
          rows: [
            { t: "embed", label: "Time embedding of t", call: ["Sinusoid 256 → MLP", "c3"] },
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM conditioning" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "linear", label: "Linear1d (was Downsample)", call: ["Channels 256 → 512 → 1,024", "c3"] } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block, 1,024 ch" }] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "linear", label: "Linear1d (was Upsample)" } ] },
            { t: "conv", label: "Final conv → action dim", call: ["Output: velocity vθ(a, t | h)", "p1", "c2"], zoom: { k: "rows", title: "Training target", rows: ["ξ: demo chunk, piecewise linear in t", "t ~ U[0, 1]; a ~ N(ξ(t), σ²)", "target: ξ̇(t) − k(a − ξ(t)) (paper)", "loss: ‖vθ(a, t | h) − target‖²"] } } ],
          output: { label: "velocity da/dt" } },
        { mod: "ode", title: "Streaming integrator", sub: "no weights", compact: true,
          input: { label: "Last action / robot state", caption: "a(0), σ₀ = 0 at test" },
          rows: [
            { id: "step", t: "linear", label: "a ← a + vθ·Δt", call: ["dopri5, 6 steps per action (Push-T)", "c2"] },
            { t: "linear", label: "Stream a to the robot", zoom: { k: "rows", title: "Inference (Alg. 2)", rows: ["a ← last action or measured state", "while t ≤ T_chunk / T_pred:", "  execute a (stream)", "  a ← a + vθ(a, t | h)·Δt", "  t ← t + Δt"] } } ],
          output: { label: "8 actions, streamed" } }
      ],
      links: [{ from: "vnet", to: "ode", toRow: "step", label: "vθ(a, t | h)" }]
    },
    modules: [
      { id: "vnet", role: "action-head", roleLabel: "Velocity net", name: "Conditional U-Net (1 action)", sub: "256 → 512 → 1024 ch", col: 0, frozen: false, main: true, short: "U-Net",
        stack: { rows: [
          { t: "in", label: "action a (one time point)", dims: "1 × action dim", c: "data-3" },
          { t: "embed", label: "time t → sinusoid 256 → MLP", side: "t" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Conditional residual block", n: "2", rows: [
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" }, { t: "film", label: "FiLM from [obs ‖ time]", side: "cond" },
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" }, { t: "add", span: 3 } ] },
            { t: "linear", label: "Linear1d instead of Downsample1d" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Conditional residual block at 1024 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · 2 conditional residual blocks" }, { t: "linear", label: "Linear1d instead of Upsample1d" }] },
          { t: "conv", label: "Conv1dBlock → Conv1d 1×1" },
          { t: "out", label: "velocity vθ(a, t | h)", c: "data-3" } ],
          facts: [["Down dims", ["256 / 512 / 1,024", "c3"]], ["fc_timesteps", ["1 (Linear1d resampling)", "c1", "c3"]], ["Obs cond", ["5-d state × 2 frames (Push-T)", "c1"]], ["Position noise σ", ["0.1 in training", "c1"]], ["Horizons", ["16 predicted, 8 executed", "c1"]]] } },
      { id: "ode", role: "net", roleLabel: "ODE solver (no weights)", name: "Streaming integrator", sub: "dopri5 · stream each step", col: 1, frozen: true, short: "Integrator",
        note: "Not a learned network: it integrates the velocity field from the last action and emits actions while integrating.",
        stack: { rows: [
          { t: "in", label: "a(0) = last action or robot state", c: "data-3" },
          { t: "linear", label: "a ← a + vθ(a, t | h) Δt" },
          { t: "out", label: "one action per k integration steps", c: "data-3" } ],
          facts: [["Solver", ["dopri5, atol = rtol = 1e-4", "c2"]], ["Steps per action", ["6", "c2"]], ["Start", ["measured agent position (state imitation)", "p2", "c2"]]] } }
    ],
    inputs: [
      { to: "vnet", mod: "state", label: "observation history", n: "2 frames", k: 2 },
      { to: "vnet", mod: "action", label: "action a", n: "one action", k: 1 },
      { to: "vnet", mod: "time", label: "flow time t", n: "= exec. time", k: 2 },
      { to: "ode", mod: "state", label: "last action", n: "a(0)", k: 1 }
    ],
    outputs: [{ from: "ode", mod: "action", label: "streamed actions", n: "one by one", k: 5 }],
    links: [{ from: "vnet", to: "ode", kind: "feeds", label: "velocity vθ" }],
    callouts: [
      "Eq. 2's stabilizing term <b>−k(a − ξ(t))</b> is in the toy module <code>core/sfp_aspace.py</code>; the released Push-T script <code>sfpd.py</code> regresses ξ̇(t) at positions jittered by σ = 0.1, with no k.",
      "Streaming spreads latency evenly: the first action is ready after roughly L / Tₐ instead of after the whole denoising loop (App. rebuttal notes)."
    ]
  });

  /* ------------------------------------------------------------------ DBPO */
  var DBC = "99ac748", DBR = "YuxuanGao0822/DBPO", DBU = "https://github.com/YuxuanGao0822/DBPO/blob/" + DBC + "/";
  RB.arch.spec({
    id: "dbpo", method: "dbpo", name: "DBP / DBPO", year: 2026, parent: "mp1",
    diffRows: ["head", "output", "cond", "train", "rate"],
    figRef: "Gao et al. Figs. 1–2 · §III–IV · §V-A", prov: "Adroit point-cloud config",
    lede: "A conv U-Net with no time input maps noise and observation features straight to an action chunk. Drifting trains it: hypotheses are attracted to the expert chunk and repelled from each other. DBPO then adds a log-std head and a critic for PPO.",
    sources: {
      p1: { kind: "paper", ref: "Gao et al. 2026, §III and §IV-A–B (drifting objective)", url: "https://arxiv.org/abs/2604.03540" },
      p2: { kind: "paper", ref: "Gao et al. 2026, §IV-C (DBPO, Eqs. 12–17)", url: "https://arxiv.org/abs/2604.03540" },
      p3: { kind: "paper", ref: "Gao et al. 2026, §V-A implementation details", url: "https://arxiv.org/abs/2604.03540" },
      p4: { kind: "paper", ref: "Gao et al. 2026, Abstract and §I (results, real UR5)", url: "https://arxiv.org/abs/2604.03540" },
      c1: { kind: "code", repo: DBR, path: "configs/model/default.yaml", commit: DBC, url: DBU + "configs/model/default.yaml" },
      c2: { kind: "code", repo: DBR, path: "dbpo/model/unet/dbp_unet1d.py", commit: DBC, url: DBU + "dbpo/model/unet/dbp_unet1d.py" },
      c3: { kind: "code", repo: DBR, path: "dbpo/methods/dbpo/ppo_adapter.py", commit: DBC, url: DBU + "dbpo/methods/dbpo/ppo_adapter.py" },
      c4: { kind: "code", repo: DBR, path: "dbpo/model/common/critic.py", commit: DBC, url: DBU + "dbpo/model/common/critic.py" },
      c5: { kind: "code", repo: DBR, path: "configs/finetune.yaml", commit: DBC, url: DBU + "configs/finetune.yaml" },
      c6: { kind: "code", repo: DBR, path: "configs/task/adroit_hammer.yaml", commit: DBC, url: DBU + "configs/task/adroit_hammer.yaml" },
      c7: { kind: "code", repo: DBR, path: "dbpo/models/encoders/pointcloud.py", commit: DBC, url: DBU + "dbpo/models/encoders/pointcloud.py" },
      c8: { kind: "code", repo: DBR, path: "dbpo/methods/dbp/policies.py", commit: DBC, url: DBU + "dbpo/methods/dbp/policies.py" },
      c9: { kind: "code", repo: DBR, path: "configs/pretrain.yaml", commit: DBC, url: DBU + "configs/pretrain.yaml" }
    },
    summary: {
      pattern: ["1-D temporal U-Net (FiLM), drifting one-step generator + PPO adapter", "p1", "p2"],
      params: null,
      vision: ["States, RGB (GroupNorm encoder, 128-d), or point clouds (MLP 64·128·256 → 256-d)", "p1", "c1", "c7"],
      backbone: ["None: the MP1 / Diffusion Policy conv U-Net", "p3"],
      head: ["U-Net 512 / 1,024 / 2,048, kernel 5, 8 groups, FiLM scale + bias; no timestep input", "p3", "c1", "c2"],
      output: ["The action chunk itself, from Gaussian noise z in one pass", "p1", "c2"],
      attention: "None (convolutions only)",
      cond: ["FiLM from the flattened observation features of Tₒ = 2 frames only", "c2", "c6", "c8"],
      steps: ["1 NFE; PPO noise is added only during online RL", "p1", "p2"],
      chunk: ["Adroit: horizon 4, 2 observations, 4 executed", "c6"],
      rate: ["105.2 Hz, 9.5 ms end-to-end on a dual-arm UR5", "p4"],
      latency: ["9.5 ms end to end (real UR5)", "p4"],
      train: ["Drifting loss, G = 4 hypotheses per observation, scales R = {0.02, 0.05, 0.2}", "p3", "c1"]
    },
    changes: [
      "The MeanFlow training (r, t inputs, JVP target) is replaced by a <b>drifting</b> fixed-point loss; the U-Net loses its time input entirely.",
      "Each observation gets <b>4 generated hypotheses</b>; the expert chunk attracts them and they repel each other at three kernel scales.",
      "Stage 2 adds a <b>state-conditioned log-std head</b> and an MLP critic so PPO has exact likelihoods, plus an anchor loss to the frozen pretrained generator.",
      "Deployment drops the exploration noise and keeps one forward pass."
    ],
    blueprint: {
      headline: "DBPO: drift in training, one pass at test",
      note: "The observation encoder feeds FiLM in every residual block of a time-free U-Net that maps noise z to a chunk. In stage 2 the same condition vector drives a Linear log-std head, and a separate MLP critic reads the low-dimensional state for PPO.",
      towers: [
        { mod: "enc", title: "Observation encoder", sub: "point-cloud variant shown", compact: true,
          input: { label: "Point cloud + state", caption: "2 frames; xyz + RGB on Adroit" },
          rows: [
            { t: "mlp", label: "Point MLP + max-pool", call: ["64 → 128 → 256, output 256-d", "c1", "c7"] },
            { t: "mlp", label: "State MLP", call: ["→ 64 → 64", "c1", "c7"] } ],
          output: { label: "(256 + 64) × 2 frames" } },
        { mod: "unet", title: "DBP U-Net", sub: "one-step generator fθ(o, z)",
          input: { label: "Gaussian noise z", caption: "H × action dim" },
          rows: [
            { t: "group", label: "Down path, 3 levels", rows: [
              { t: "block", n: "2", rows: [
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { id: "film", t: "film", label: "FiLM: γ ⊙ x + β", side: "cond", zoom: { k: "film", title: "FiLM (observation only)" } },
                { t: "conv", label: "Conv1d k=5 · GroupNorm · Mish" },
                { t: "add", span: 3 } ] },
              { t: "conv", label: "Downsample (stride 2)", call: ["Channels 512 → 1,024 → 2,048", "c1", "c2"] } ] },
            { t: "block", n: "2", rows: [{ t: "conv", label: "Cond. residual block, 2,048 ch" }] },
            { t: "group", label: "Up path, 2 levels", rows: [
              { t: "conv", label: "Concat skip + 2 cond. blocks" },
              { t: "conv", label: "Upsample (transposed conv)" } ] },
            { t: "conv", label: "Final Conv1d → action dim", call: ["No timestep embedding anywhere", "c2"], zoom: { k: "rows", title: "Drifting loss (per observation)", rows: ["G = 4 hypotheses x̂⁽ʳ⁾ = fθ(o, z⁽ʳ⁾)", "positives: expert chunk; negatives: the others", "affinity softmax(−d / (R·s)) per scale R", "V = Σ_R attraction − repulsion", "loss ‖x̂/s − sg(x̂/s + V)‖²"] } } ],
          output: { label: "action chunk (mean μθ)" } },
        { mod: "rl", title: "PPO adapter", sub: "stage 2 only", compact: true,
          input: { label: "μθ and obs features", caption: "stored z reused for ratios" },
          rows: [
            { t: "linear", label: "Log-std head (Linear)", call: ["σ clamped to [0.03, 0.10]", "c3"] },
            { t: "mlp", label: "Critic MLP on state", call: ["3 × 256, Mish → value", "c4"] },
            { t: "linear", label: "PPO + anchor loss", call: ["Anchor weight 1.0, actor lr 1e-5", "c5"], zoom: { k: "rows", title: "DBPO objective", rows: ["π = N(μθ(o, z), diag σψ(o)²)", "ratio on the executed prefix only", "L = L_clip + c_v·L_value − c_e·H", "+ λ·‖μθ − μθ̄‖² (frozen copy)", "deploy: μθ, noise removed"] } } ],
          output: { label: "exploration σ, value V(s)" } }
      ],
      links: [
        { from: "enc", to: "unet", toRow: "film", label: "obs features (FiLM)" },
        { from: "unet", to: "rl", toRow: "input", label: "mean chunk μθ" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "Observation encoder", sub: "point MLP 256 · state 64", col: 0, frozen: false, short: "Encoder",
        note: "DP3-style PointNet MLP; image tasks use a GroupNorm image encoder (128-d), low-dim tasks feed the state directly.",
        stack: { rows: [
          { t: "in", label: "point cloud (xyz + RGB on Adroit) and robot state", dims: "2 frames", c: "data-1" },
          { t: "mlp", label: "per-point MLP 64 → 128 → 256 · max-pool · projection", dims: "→ 256-d" },
          { t: "mlp", label: "state MLP → 64 → 64" },
          { t: "out", label: "condition vector", dims: "(256 + 64) × 2", c: "data-1" } ],
          facts: [["Point feature", ["256-d", "c1", "c7"]], ["State feature", ["64-d", "c1"]], ["Point channels", ["6 on Adroit (xyz + RGB)", "c6"]], ["Image variant", ["128-d, 84 × 84 crop, GroupNorm, not pretrained", "c1"]]] } },
      { id: "unet", role: "action-head", roleLabel: "One-step generator", name: "DBP U-Net", sub: "512 → 1024 → 2048 · no t", col: 1, frozen: false, main: true, short: "U-Net",
        stack: { rows: [
          { t: "in", label: "noise z ~ N(0, I)", dims: "H × action dim", c: "data-3" },
          { t: "group", label: "Down path (3 levels)", rows: [
            { t: "block", label: "Residual block (FiLM)", n: "2", rows: [
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" }, { t: "film", label: "FiLM scale + bias from obs features", side: "cond" },
              { t: "conv", label: "Conv1d k=5 → GroupNorm(8) → Mish" }, { t: "add", span: 3 } ] },
            { t: "conv", label: "Downsample1d" } ] },
          { t: "block", label: "Mid", n: "2", rows: [{ t: "conv", label: "Residual block at 2048 ch" }] },
          { t: "group", label: "Up path (mirror)", rows: [{ t: "conv", label: "concat skip · 2 residual blocks" }, { t: "conv", label: "Upsample1d" }] },
          { t: "conv", label: "Conv1dBlock → Conv1d 1×1" },
          { t: "out", label: "action chunk x̂", c: "data-3" } ],
          facts: [["Down dims", ["512 / 1,024 / 2,048", "c1"]], ["Kernel / groups", ["5 / 8", "c1"]], ["Hypotheses G", ["4 per observation", "c1", "c8"]], ["Kernel scales", ["0.02, 0.05, 0.2", "p3", "c1"]], ["Mode", ["chunk mode (whole chunk flattened)", "p1", "c1"]], ["Pretrain", ["lr 1e-4, batch 64 (default config)", "c9"]]] } },
      { id: "rl", role: "critic", roleLabel: "PPO adapter (stage 2)", name: "Log-std head + critic", sub: "Linear σ · MLP 3 × 256", col: 2, frozen: false, short: "PPO",
        stack: { rows: [
          { t: "in", label: "condition vector and state", c: "data-8" },
          { t: "linear", label: "log-std head: Linear(cond → chunk dim)", dims: "σ ∈ [0.03, 0.10]" },
          { t: "mlp", label: "critic: 3 × (Linear 256 · Mish) → 1", dims: "on flattened state history" },
          { t: "out", label: "σψ(o) and V(s)", c: "data-8" } ],
          facts: [["PPO", ["γ = 0.99, λ = 0.95, 5 epochs, target KL 0.02", "c5"]], ["Anchor", ["weight 1.0", "c5"]], ["LR", ["actor 1e-5, critic 1e-4", "c5"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "point cloud / images", n: "2 frames", k: 4 },
      { to: "enc", mod: "state", label: "robot state", n: "2 frames", k: 2 },
      { to: "unet", mod: "latent", label: "noise z", n: "H × action dim", k: 4, noisy: true },
      { to: "rl", mod: "other", label: "rewards", n: "online rollouts", k: 2 }
    ],
    outputs: [{ from: "unet", mod: "action", label: "action chunk", n: "1 NFE", k: 4 }],
    links: [
      { from: "enc", to: "unet", kind: "film", label: "obs features" },
      { from: "unet", to: "rl", kind: "feeds", label: "mean μθ|(stage 2)" }
    ],
    callouts: [
      "§V-A says the point-cloud runs use <b>the same U-Net and pipeline as MP1/OMP</b>. The released encoder config differs from MP1's: a 256-d point feature (MP1: 64-d) and xyz + RGB points on Adroit, and the U-Net has no time input.",
      "The paper speaks of a <b>value head</b>; the released critic is a separate MLP on the low-dimensional state, not a head on the policy backbone.",
      "Adroit + MetaWorld (37 tasks): 88.4% average success vs 78.9% for MP1."
    ]
  });

  /* ------------------------------------------------ Implicit Drifting Policy */
  RB.arch.spec({
    id: "implicit-drifting-policy", method: "implicit-drifting-policy", name: "Implicit Drifting Policy", year: 2026, parent: "dbpo",
    diffRows: ["backbone", "output", "train"],
    figRef: "Yang et al. Fig. 2 · §4 · Alg. 1 · App. D", prov: "paper only (no official code)",
    lede: "A one-step generator fθ(o, a, t) evaluated once at a = 0, t = 0. Training weights its squared error per action dimension by how much tighter expert actions are under similar observations than globally, and adds a probe near the expert action.",
    sources: {
      p1: { kind: "paper", ref: "Yang et al. 2026, §4.1 (potential, Eqs. 3–6)", url: "https://arxiv.org/abs/2606.01098" },
      p2: { kind: "paper", ref: "Yang et al. 2026, §4.2–4.3 (Eqs. 7–10)", url: "https://arxiv.org/abs/2606.01098" },
      p3: { kind: "paper", ref: "Yang et al. 2026, App. B Alg. 1 and App. D, Table 6", url: "https://arxiv.org/abs/2606.01098" },
      p4: { kind: "paper", ref: "Yang et al. 2026, §5, Tables 1–5", url: "https://arxiv.org/abs/2606.01098" }
    },
    summary: {
      pattern: ["One-step generator with a geometry-weighted training potential", "p1"],
      params: null,
      vision: ["DP3 PointNet encoder, 1,024 points (3-D); MIP encoders for state and image (2-D)", "p3", "p4"],
      backbone: ["Transformer policy (3-D, as in OFP / FlowPolicy); Transformer and CNN from MIP (2-D)", "p3"],
      head: "not disclosed (inherits the MIP / OFP backbones)",
      output: ["Action chunk a = fθ(o, 0, 0), one evaluation", "p3"],
      attention: null,
      cond: ["Observation embedding; the generator also takes an action input and a time scalar", "p1", "p3"],
      steps: ["1 NFE", "p3", "p4"],
      chunk: ["Same horizons as MIP (2-D) and OFP / FlowPolicy (3-D)", "p3"],
      rate: null,
      latency: null,
      train: ["E(y) + 81 · E(z): proposal at (0, 0) and probe at a* + 0.1ε, t* = 0.9", "p1", "p3"]
    },
    changes: [
      "The explicit drifting field between generated and expert samples is replaced by a <b>static potential</b> built from expert actions alone.",
      "Each action dimension is weighted by a <b>geometry excess</b>: how much tighter expert actions are under similar observations than across the batch.",
      "Neighbours come from stop-gradient, L2-normalised observation embeddings, softmaxed after row z-scoring.",
      "An <b>expert-proximal probe</b> (MIP-style, t* = 0.9) is trained with the same potential; inference stays one pass with zero input."
    ],
    blueprint: {
      headline: "IDP: weight errors by local expert geometry",
      note: "At test time only the encoder and generator run, once, with the action input and time set to zero. During training the detached observation embeddings pick neighbours in the batch, their action spread sets a diagonal metric Mᵢ, and that metric weights the loss of both the proposal and the near-expert probe.",
      towers: [
        { mod: "enc", title: "Observation encoder φθ", sub: "DP3 PointNet (3-D tasks)", compact: true,
          input: { label: "Point cloud", caption: "1,024 points per frame" },
          rows: [
            { t: "mlp", label: "DP3 PointNet encoder", call: ["1,024 points, as in DP3", "p3"] },
            { id: "emb", t: "linear", label: "Final hidden embedding" } ],
          output: { label: "observation embedding" } },
        { mod: "gen", title: "Generator fθ(o, a, t)", sub: "layer sizes not disclosed",
          input: { label: "Action input a, time t", caption: "a = 0, t = 0 at test time" },
          rows: [
            { t: "embed", label: "Embed a and t" },
            { id: "trunk", t: "block", n: "N", label: "Transformer (3-D) / CNN", rows: [
              { t: "attn", label: "Backbone from MIP / OFP", side: "cond", call: ["Depth and width not disclosed", "p3"] } ] },
            { t: "linear", label: "Output → action chunk", zoom: { k: "rows", title: "Two evaluations per step", rows: ["proposal yᵢ = fθ(oᵢ, 0, 0)", "probe ãᵢ = a*ᵢ + (1 − t*)·ε, t* = 0.9", "zᵢ = fθ(oᵢ, ãᵢ, t*)", "L = Eᵢ(yᵢ) + 81·Eᵢ(zᵢ)", "deploy: a = fθ(o, 0, 0)"] } } ],
          output: { label: "action chunk (1 NFE)" } },
        { mod: "geo", title: "Expert geometry", sub: "training only, no weights", compact: true,
          input: { label: "Batch embeddings + a*", caption: "φθ(o) detached, from the encoder" },
          rows: [
            { t: "linear", label: "Neighbour weights wᵢⱼ", call: ["softmax of row z-scored cosine, temperature 1", "p2", "p3"] },
            { t: "linear", label: "Geometry excess Mᵢ", zoom: { k: "rows", title: "Geometry excess (diagonal)", rows: ["vᶜᵒⁿᵈᵢ,d = Σⱼ wᵢⱼ (a*ⱼ,d − a*ᵢ,d)²", "vʳᵉᶠd = batch variance of a*d", "s = normalised (v + ε)^−½", "mᵢ,d = ReLU(sᶜᵒⁿᵈ / sʳᵉᶠ − 1)", "Eᵢ(a) = ½‖a − a*‖² + ½ rᵀ Diag(mᵢ) r"] } } ],
          output: { label: "diagonal metric Mᵢ" } }
      ],
      links: [
        { from: "enc", to: "gen", toRow: "trunk", label: "observation condition" }
      ]
    },
    modules: [
      { id: "enc", role: "vision-enc", name: "Observation encoder φθ", sub: "DP3 PointNet · MIP (2-D)", col: 0, frozen: false, short: "Encoder",
        stack: { rows: [
          { t: "in", label: "point cloud, state or images", c: "data-1" },
          { t: "mlp", label: "DP3 PointNet encoder (3-D) / MIP encoders (2-D)" },
          { t: "out", label: "embedding φθ(o), also used (detached) for neighbours", c: "data-1" } ],
          facts: [["3-D input", ["1,024 points per frame", "p3"]], ["Neighbour metric", ["L2-normalised, stop-gradient", "p2", "p3"]]] } },
      { id: "gen", role: "action-head", roleLabel: "One-step generator", name: "Generator fθ(o, a, t)", sub: "Transformer / CNN backbone", col: 1, frozen: false, main: true, short: "Generator",
        stack: { rows: [
          { t: "in", label: "action input a and time t", dims: "(0, 0) proposal · (ã, 0.9) probe", c: "data-3" },
          { t: "block", label: "MIP / OFP backbone (not detailed in the paper)", n: "N", rows: [{ t: "attn", label: "Transformer (or CNN for 2-D)", side: "cond" }] },
          { t: "out", label: "action chunk", c: "data-3" } ],
          facts: [["2-D backbones", ["MIP Transformer and CNN, results averaged", "p3", "p4"]], ["3-D backbone", ["Transformer policy as in OFP / FlowPolicy", "p3"]], ["t*", ["0.9", "p3"]], ["λ_prox", ["(t* / (1 − t*))² = 81", "p3"]]] } },
      { id: "geo", role: "net", roleLabel: "Training-time weights", name: "Conditional expert geometry", sub: "diagonal Mᵢ · no params", col: 2, frozen: true, short: "Geometry",
        note: "Computed per minibatch from expert actions and detached embeddings; nothing here is learned.",
        stack: { rows: [
          { t: "in", label: "detached embeddings hᵢ and expert actions a*", c: "data-8" },
          { t: "linear", label: "wᵢⱼ = softmax over row z-scored hᵢᵀhⱼ" },
          { t: "linear", label: "local vs batch variance per action dimension" },
          { t: "out", label: "Mᵢ = Diag(ReLU(s_cond / s_ref − 1))", c: "data-8" } ],
          facts: [["Scope", ["full minibatch", "p3"]], ["ε", ["1e-6", "p3"]], ["Reference", ["per-minibatch variance, no EMA", "p3"]]] } }
    ],
    inputs: [
      { to: "enc", mod: "vision", label: "observation", n: "points / image / state", k: 4 },
      { to: "gen", mod: "action", label: "action input a", n: "0 at test", k: 3 },
      { to: "gen", mod: "time", label: "time t", n: "0 · probe 0.9", k: 2 },
      { to: "geo", mod: "action", label: "expert actions a*", n: "minibatch", k: 3 }
    ],
    outputs: [{ from: "gen", mod: "action", label: "action chunk", n: "1 NFE", k: 4 }],
    links: [
      { from: "enc", to: "gen", kind: "feeds", label: "observation embedding" },
      { from: "gen", to: "geo", kind: "latent", label: "residuals y − a*, z − a*|weighted by Mᵢ" }
    ],
    callouts: [
      "No official code is linked from the paper or project page; the diagram follows the paper, which reuses MIP and OFP backbones without restating their sizes.",
      "Eq. 8 <b>excludes</b> j = i from the neighbourhood, while App. B says the softmax is self-inclusive (the j = i term contributes zero to Gᵢ but still takes softmax mass).",
      "Removing the expert-proximal probe drops ToolHang-State from 81.0 / 60.0 to 40.0 / 25.5, below Naive Drifting (53.2 / 42.4)."
    ]
  });
})();
